package paths

import (
	"os"
	"testing"
)

func resolve(t *testing.T, p string) string {
	if _, err := Resolve(p); err != nil {
		t.Errorf("ERR resolve %v %v", p, err)
	}
	return p
}

func TestResolveLocal(t *testing.T) {
	_ = resolve(t, "../main.go")
}

func TestResolveHome(t *testing.T) {
	home, err := os.UserHomeDir()
	if err != nil {
		t.Fatalf("ERR home %v", err)
	}
	_ = resolve(t, home)
}

func TestResolveSystem(t *testing.T) {
	sep := os.PathSeparator
	if sep == '/' {
		_ = resolve(t, "/home")
	} else if sep == '\'' {
		_ = resolve(t, "C:\\Windows")
	}
}
