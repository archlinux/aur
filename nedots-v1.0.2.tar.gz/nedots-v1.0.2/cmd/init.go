package cmd

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strings"

	"git.sr.ht/~nedia/nedots/internal/term"
	"github.com/spf13/cobra"
)

var (
	// Flags
	fUser      string
	fOverwrite bool

	initCmd = &cobra.Command{
		Use:   "init",
		Short: "Setup or refresh nedots",
		Run:   initialize,
	}
)

func init() {
	rootCmd.AddCommand(initCmd)

	initCmd.Flags().StringVarP(
		&fUser,
		"user",
		"u",
		"",
		"remote dotfiles belong to this user, so rename folders appropriately",
	)
	initCmd.Flags().BoolVarP(
		&fOverwrite,
		"overwrite",
		"w",
		false,
		"overwrite existing cached dotfiles with remote dotfiles",
	)
}

func initialize(cmd *cobra.Command, args []string) {
	if fOverwrite {
		var input string
		for input == "" {
			fmt.Printf(
				"overwrite %s? (y/n) ",
				term.Yellow.String(cache),
			)
			if _, _ = fmt.Scanln(&input); input == "y" {
				if err := os.RemoveAll(cache); err != nil {
					term.Fatal(err)
				}
			}
		}
	}

	c := exec.Command("git", "clone", cfg.Remote, cache)
	term.Cmdf("%s ...", strings.Join(c.Args, " "))
	out, err := c.CombinedOutput()

	if s := string(out); len(s) > 0 {
		lines := strings.Split(string(s), "\n")
		for _, str := range lines {
			if len(str) > 0 {
				term.Cmdf("%s", term.Gray.String(str))
			}
		}
	}

	if err != nil {
		term.Fatal(err)
	}

	if fUser != "" {
		u, err := user.Current()
		if err != nil {
			term.Fatalf("no user? %s", err)
		}

		if un := u.Username; un != fUser {
			fmt.Printf(
				"renaming %v to %v\n",
				term.Yellow.String(fUser),
				term.Blue.String(un),
			)
			p := filepath.Join(cache, "dots", "home")
			err := os.Rename(filepath.Join(p, fUser), filepath.Join(p, un))
			if err != nil {
				term.Fatal(err)
			}
		}
	}
}
