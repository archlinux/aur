package cmd

import (
	"fmt"
	"os/exec"
	"strings"
	"time"

	"git.sr.ht/~nedia/nedots/internal/term"
	"github.com/spf13/cobra"
)

var (
	fGather bool

	syncCmd = &cobra.Command{
		Use:     "sync",
		Short:   "Sync dotfiles  with remote",
		Example: "nedots sync -g",
		Run:     sync,
	}
)

func init() {
	rootCmd.AddCommand(syncCmd)

	syncCmd.Flags().BoolVarP(
		&fGather,
		"gather",
		"g",
		false,
		"gather files & sync repositories first",
	)
}

func sync(cmd *cobra.Command, args []string) {
	if fGather {
		gather(cmd, args)
	}

	run := func(args ...string) ([]byte, error) {
		cmd := exec.Command(
			"git",
			append([]string{"-C", cache}, args...)...,
		)

		term.Cmdf("%s ...", strings.Join(cmd.Args, " "))
		return cmd.CombinedOutput()
	}

	out, err := run("pull")
	if err == nil {
		out, err = run("add", ".")
		if err == nil {
			// Discard output & errors from `git commit`, we don't care if there's
			// nothing to commit.
			now := fmt.Sprintf("Latest %s", time.Now().String())
			_, _ = run("commit", "-q", "-m", now)

			out, err = run("push")
		}
	}

	if s := string(out); len(s) > 0 {
		lines := strings.Split(string(s), "\n")
		for _, str := range lines {
			if len(str) > 0 {
				term.Cmdf("%s", term.Gray.String(str))
			}
		}
	}

	if err != nil {
		term.Error(err)
	} else {
		term.Okayf("sync %s %s", term.Bold.String(cfg.Remote), cache)
	}
}
