package cop

import (
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	fp "path/filepath"

	"git.sr.ht/~nedia/nedots/internal/term"
	"git.sr.ht/~nedia/nedots/paths"
)

var CopyDirError = errors.New("cannot operate on dir, see CopyOperation.Copy")

type CopyOperation struct {
	src, dst        string
	depth           int
	total, complete int
}

func New(src, dst string) *CopyOperation {
	return &CopyOperation{src: src, dst: dst}
}

func (co *CopyOperation) From(path string) *CopyOperation {
	co.src = path
	return co
}

func (co *CopyOperation) To(path string) *CopyOperation {
	co.dst = path
	return co
}

func (co *CopyOperation) Source() string {
	return co.src
}

func (co *CopyOperation) Destination() string {
	return co.dst
}

func (co CopyOperation) String() string {
	var errors string
	if e := co.total - co.complete; e > 0 {
		errors = term.Red.String(fmt.Sprint(e))
	} else {
		errors = term.Green.String(fmt.Sprint(e))
	}

	return fmt.Sprintf(
		"%d/%d (%d%%, depth %d, errors %s)",
		co.complete,
		co.total,
		co.complete/co.total*100,
		co.depth,
		errors,
	)
}

// Accounts for directories - when we are sure that we're handling regular
// files, [Copy] takes over.
func (co *CopyOperation) Copy(overwrite bool) error {
	if err := Copy(co.src, co.dst, overwrite); errors.Is(err, CopyDirError) {
		// [Copy] returned a [CopyDirError] since we're dealing with a directory so
		// increase depth.
		co.depth++

		entries, err := os.ReadDir(co.src)
		if err != nil {
			return err
		}

		count := len(entries)
		ops := make(chan *CopyOperation, count)
		errors := make(chan error, count)
		for _, e := range entries {
			go func(op *CopyOperation, ow bool, ops chan *CopyOperation, errors chan error) {
				errors <- op.Copy(ow)
				ops <- op
			}(
				New(fp.Join(co.src, e.Name()), fp.Join(co.dst, e.Name())),
				overwrite,
				ops,
				errors,
			)
		}

		for range entries {
			op := <-ops
			co.total += op.total
			co.complete += op.complete
			co.depth += op.depth
			if err := <-errors; err != nil {
				return err
			}
		}
	} else if err != nil {
		co.total++
		return err
	} else {
		co.total++
		co.complete++
	}

	return nil
}

// Will [ChunkyCopy] in chunks this size at max.
const MaxBufferSize int = 512

// The raw copy function. Opens [src], creates [dst] (overwriting whatever is
// there with an empty file) and copies bytes in chunks of [bufsize] until
// complete.
func ChunkyCopy(src, dst string, bufsize int) error {
	s, _ := os.Open(src)
	defer s.Close()

	d, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer d.Close()

	buf := make([]byte, bufsize)
	for {
		n, err := s.Read(buf)
		if err != nil && err != io.EOF {
			return err
		}

		// We've finished.
		if n == 0 {
			return nil
		}

		if _, err := d.Write(buf[:n]); err != nil {
			return fmt.Errorf("copy: writing to destination (%s)", err)
		}
	}
}

// Does not respect directories. Excepts [src] to be a regular file, otherwise
// returns [CopyDirError].
//
// If [src] and [dst] are the same according to [FileInfo.Equals], or [dst] was
// modified after [src] (and [overwrite] is false), we will fail.
func Copy(src, dst string, overwrite bool) error {
	s, err := paths.Open(src)
	if err != nil {
		return err
	}

	if s.IsDir {
		return CopyDirError
	}

	// log.Printf("%s copy %s\n", term.Bold.String("INF"), dst)
	if paths.Exists(dst) {
		d, _ := paths.Open(dst)
		if s.Equals(&d) {
			return nil
		} else if !overwrite && d.Newer(&s) {
			return fmt.Errorf(
				"dst(1) is newer than src(2)\n * 1. %s\n * 2. %s",
				s.ModifiedString(),
				d.ModifiedString(),
			)
		}
	} else if dir := fp.Dir(dst); !paths.Exists(dir) {
		if err := os.MkdirAll(dir, fs.ModePerm); err != nil {
			return err
		}
	}

	bufsize := MaxBufferSize
	if s := int(s.Size); s < MaxBufferSize {
		bufsize = s
	}

	if err := ChunkyCopy(src, dst, bufsize); err != nil {
		return err
	}

	return nil
}
