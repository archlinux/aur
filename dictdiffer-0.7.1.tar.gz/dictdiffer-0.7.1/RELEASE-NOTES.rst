===================
 Dictdiffer v0.7.1
===================

Dictdiffer v0.7.1 was released on May 4, 2018.

About
-----

Dictdiffer is a helper module that helps you to diff and patch
dictionaries.

Bug fixes
---------

- Resolves issue with keys containing dots.  (#101)

Installation
------------

   $ pip install dictdiffer==0.7.1

Documentation
-------------

   http://dictdiffer.readthedocs.io/en/v0.7.1

Happy hacking and thanks for flying Dictdiffer.

| Invenio Development Team
|   Email: info@inveniosoftware.org
|   IRC: #invenio on irc.freenode.net
|   Twitter: http://twitter.com/inveniosoftware
|   GitHub: https://github.com/inveniosoftware/dictdiffer
