#pragma once
#include <stdlib.h>
#include "table.h"

void get_dimensions(Table *table, size_t *out_col_widths, size_t *out_row_heights);
