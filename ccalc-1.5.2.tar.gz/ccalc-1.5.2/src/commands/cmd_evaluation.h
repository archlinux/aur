#pragma once
#include <stdbool.h>

int cmd_evaluation_check(char *input);
bool cmd_evaluation_exec(char *input, int code);
