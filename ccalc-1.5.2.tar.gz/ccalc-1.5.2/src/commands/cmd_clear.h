#pragma once
#include <stdbool.h>

int cmd_clear_check(char *input);
bool cmd_clear_exec(char *input, int code);
