document.addEventListener('DOMContentLoaded', function() {
    const statusPill = document.getElementById('status-pill');
    const statusText = document.getElementById('status-text'); // Ensure this matches your HTML

    if (!statusText) {
        console.error('Element with ID "status-text" not found.');
        return; // Exit the function early if the element is not found
    }

    function checkStatus() {
        fetch('http://100.119.91.31:8097/status.txt')
       .then(response => {
                if (response.ok) {
                    statusPill.classList.remove('red');
                    statusPill.classList.add('green');
                    statusText.textContent = "Online, reconnecting..";

                    // Set a timeout to redirect after 3 seconds (3000 milliseconds)
                    setTimeout(function() {
                        window.location.href = "./splash.html"; // Replace with your local file path
                    }, 3000);
                } else {
                    statusPill.classList.remove('green');
                    statusPill.classList.add('red');
                    statusText.textContent = "Offline";
                }
            })
       .catch(() => {
                statusPill.classList.remove('green');
                statusPill.classList.add('red');
                statusText.textContent = "Offline";
            });
    }

    checkStatus(); // Initial check
    setInterval(checkStatus, 60 * 1000); // Check every minute
});

