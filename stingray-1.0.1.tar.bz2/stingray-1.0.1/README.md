![picture](https://i.imgur.com/z86B6XY.png)

Custom client for a private Jellyfin server.

 ### Author
  * Corey Bruce
