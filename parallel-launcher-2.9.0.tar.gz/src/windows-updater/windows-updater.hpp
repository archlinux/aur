#ifndef SRC_WINDOWS_UPDATER_WINDOWS_UPDATER_HPP_
#define SRC_WINDOWS_UPDATER_WINDOWS_UPDATER_HPP_

namespace WindowsUpdater {
	extern void checkForUpdates();
}

#endif /* SRC_WINDOWS_UPDATER_WINDOWS_UPDATER_HPP_ */
