#include "src/windows-updater/update-dialog.hpp"
#include "ui_update-dialog.h"

#include "src/ui/icons.hpp"
#include "src/core/version.hpp"

UpdateDialog::UpdateDialog( const Version &latestVersion, const QString &changelog ) :
	QDialog( nullptr ),
	m_ui( new Ui::UpdateDialog ),
	m_latestVersion( latestVersion )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );

	m_ui->changelog->setHtml( changelog );
	m_ui->versionLabel->setText( ("v"s + CurrentVersion::Application.toString() + " → v" + m_latestVersion.toString()).c_str() );
}

UpdateDialog::~UpdateDialog() {
	delete m_ui;
}

bool UpdateDialog::stopReminders() const {
	return m_ui->noReminderCheckbox->isChecked();
}
