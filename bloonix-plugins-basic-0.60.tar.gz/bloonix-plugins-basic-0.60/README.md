# Bloonix Plugins Basic

## Plugins

    check-cluster
    check-dbconnect
    check-dns
    check-filestat
    check-ftp
    check-http
    check-imap
    check-logfile
    check-nagios-wrapper
    check-pop3
    check-smtp
    check-snmp-cpu
    check-snmp-disk
    check-snmp-if
    check-snmp-mem
    check-snmp-nprocs
    check-snmp-process
    check-snmp-service
    check-tcp
    check-udp

## About Bloonix

For general information about Bloonix, questions, ratings or other things please visit our base repository:

* https://github.com/bloonix/bloonix
