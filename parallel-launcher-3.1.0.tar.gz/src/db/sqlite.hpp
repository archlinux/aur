#ifndef SRC_DB_SQLITE_HPP_
#define SRC_DB_SQLITE_HPP_

#include <sqlite3.h>
#include "src/core/filesystem.hpp"
#include "src/core/uuid.hpp"
#include "src/types.hpp"

#define DATA_COPY true
#define DATA_REF false

class DataRecordIterator final {

	private:
	sqlite3_stmt *m_statement;
	int m_status;

	public:
	DataRecordIterator( sqlite3_stmt *statement ) noexcept;
	DataRecordIterator( DataRecordIterator &&other ) noexcept;
	DataRecordIterator( const DataRecordIterator &other ) = delete;
	~DataRecordIterator() noexcept;

	bool moveNext() noexcept;
	void close() noexcept;

	inline int status() const noexcept { return m_status; }
	inline bool good() const noexcept {
		return m_status == SQLITE_DONE || m_status == SQLITE_ROW || m_status == SQLITE_OK;
	}

	inline int isNull( int index ) const noexcept {
		return sqlite3_column_type( m_statement, index ) == SQLITE_NULL;
	}

	inline int getInt( int index ) const noexcept {
		return sqlite3_column_int( m_statement, index );
	}

	inline int64 getLong( int index ) const noexcept {
		return sqlite3_column_int64( m_statement, index );
	}

	inline double getFloat( int index ) const noexcept {
		return sqlite3_column_double( m_statement, index );
	}

	inline string getString( int index ) const {
		return string( (const char*)sqlite3_column_text( m_statement, index ) );
	}

	inline Uuid getUuid( int index ) const noexcept {
		return Uuid( (const ubyte*)sqlite3_column_blob( m_statement, index ) );
	}

	inline bool getBool( int index ) const noexcept { return getInt( index ) != 0; }
	inline uint getUInt( int index ) const noexcept { return (uint)getLong( index ); }
	inline fs::path getPath( int index ) const { return fs::to_path( getString( index ) ); }

	inline uint64 getULong( int index ) const noexcept {
		const int64 value = getLong( index );
		return reinterpret_cast<const uint64&>( value );
	}

};

class SqlCommand final {

	private:
	sqlite3_stmt *m_statement;
	int m_bindingIndex;

	public:
	SqlCommand( const char *sql ) noexcept;
	SqlCommand( SqlCommand &&other ) noexcept;
	SqlCommand( const SqlCommand &other ) = delete;
	~SqlCommand() noexcept;

	void execNonQuery( int *status = nullptr ) noexcept;

	[[nodiscard]] inline DataRecordIterator execQuery() {
		m_bindingIndex = 0;
		return DataRecordIterator( m_statement );
	}

	inline int addParameter( int value ) noexcept {
		return sqlite3_bind_int( m_statement, ++m_bindingIndex, value );
	}

	inline int addParameter( int64 value ) noexcept {
		return sqlite3_bind_int64( m_statement, ++m_bindingIndex, value );
	}

	inline int addParameter( double value ) noexcept {
		return sqlite3_bind_double( m_statement, ++m_bindingIndex, value );
	}

	inline int addParameter( const char *value, bool copy ) noexcept {
		return sqlite3_bind_text( m_statement, ++m_bindingIndex, value, -1, copy ? SQLITE_TRANSIENT : SQLITE_STATIC );
	}

	inline int addParameter( const string &value, bool copy ) noexcept {
		return sqlite3_bind_text( m_statement, ++m_bindingIndex, value.c_str(), (int)value.length() + 1, copy ? SQLITE_TRANSIENT : SQLITE_STATIC );
	}

	inline int addParameter( const Uuid &value, bool copy ) noexcept {
		return sqlite3_bind_blob( m_statement, ++m_bindingIndex, (const void*)value.data(), 16, copy ? SQLITE_TRANSIENT : SQLITE_STATIC );
	}

	inline int addParameter( bool value ) noexcept { return addParameter( (int)value ); }
	inline int addParameter( ubyte value ) noexcept { return addParameter( (int)value ); }
	inline int addParameter( ushort value ) noexcept { return addParameter( (int)value ); }
	inline int addParameter( uint value ) noexcept { return addParameter( (int64)value ); }

	inline int addParameter( uint64 value ) noexcept { return addParameter( reinterpret_cast<int64&>( value ) ); }

};

#endif /* SRC_DB_SQLITE_HPP_ */
