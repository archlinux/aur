#include "src/db/data-provider.hpp"

#include "src/db/sqlite.hpp"

void DataProvider::addRomInfo( const RomInfo &romInfo ) noexcept {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO ROMS(
	sha1,
	name,
	internal_name,
	emulator,
	parallel_plugin,
	mupen_plugin,
	overclock_cpu,
	overclock_vi,
	widescreen,
	input_mode_id,
	last_played,
	play_time,
	crc32
) VALUES (
	?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13
);
)#"
	);

	s_cmd.addParameter( romInfo.sha1, DATA_REF );
	s_cmd.addParameter( romInfo.name, DATA_REF );
	s_cmd.addParameter( romInfo.internalName, DATA_REF );
	s_cmd.addParameter( (int)romInfo.emulator );
	s_cmd.addParameter( (int)romInfo.parallelPlugin );
	s_cmd.addParameter( (int)romInfo.mupenPlugin );
	s_cmd.addParameter( romInfo.overclockCPU );
	s_cmd.addParameter( romInfo.overclockVI );
	s_cmd.addParameter( romInfo.widescreen );
	s_cmd.addParameter( romInfo.inputModeId, DATA_REF );
	s_cmd.addParameter( romInfo.lastPlayed );
	s_cmd.addParameter( romInfo.playTime );
	s_cmd.addParameter( (int64)romInfo.crc32 );
	s_cmd.execNonQuery();

	for( const string &group : romInfo.groups ) {
		static SqlCommand s_cmd2( R"#(
INSERT OR IGNORE INTO ROM_GROUPS( sha1, group_name )
VALUES( ?1, ?2 )
)#"
		);

		s_cmd2.addParameter( romInfo.sha1, DATA_REF );
		s_cmd2.addParameter( group, DATA_REF );
		s_cmd2.execNonQuery();
	}
}

void DataProvider::addRomFile( const RomFile &romFile ) {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO ROM_PATHS( path, last_modified, sha1 )
VALUES( ?1, ?2, ?3 )
)#"
	);

	s_cmd.addParameter( romFile.path.u8string(), DATA_COPY );
	s_cmd.addParameter( romFile.lastModified );
	s_cmd.addParameter( romFile.sha1, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::addGroup( const string &groupName ) noexcept {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO PERSISTENT_GROUPS( name )
VALUES( ?1 )
)#"
	);

	s_cmd.addParameter( groupName, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::deleteGroup( const string &groupName ) noexcept {
	static SqlCommand s_cmd( R"#(
DELETE FROM PERSISTENT_GROUPS 
WHERE name = ?1;

DELETE FROM ROM_GROUPS
WHERE group_name = ?1;
)#"
	);

	s_cmd.addParameter( groupName, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::renameGroup( const string &oldName, const string &newName ) noexcept {
	static SqlCommand s_cmd( R"#(
DELETE FROM PERSISTENT_GROUPS( name )
VALUES( ?1 );

INSERT OR IGNORE INTO PERSISTENT_GROUPS( name )
VALUES( ?2 );

UPDATE ROM_GROUPS
SET group_name = ?2
WHERE group_name = ?1
)#"
	);

	s_cmd.addParameter( oldName, DATA_REF );
	s_cmd.addParameter( newName, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomEmulator( const string &sha1, EmulatorCore core ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET emulator = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( (int)core );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomParallelPlugin( const string &sha1, GfxPlugin plugin ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET parallel_plugin = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( (int)plugin );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomMupenPlugin( const string &sha1, GfxPlugin plugin ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET mupen_plugin = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( (int)plugin );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomCpuOverclocking( const string &sha1, bool overclock ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET overclock_cpu = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( overclock );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomViOverclocking( const string &sha1, bool overclock ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET overclock_vi = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( overclock );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomWidescreen( const string &sha1, bool widescreen ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET widescreen = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( widescreen );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomInputMode( const string &sha1, const Uuid &inputModeId ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS
SET input_mode_id = ?2
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( inputModeId, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::updatePlayTime(
	const string &sha1,
	int64 lastPlayed,
	int64 playTime
) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROMS SET
	last_played = ?2,
	play_time = ?3
WHERE sha1 = ?1)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( lastPlayed );
	s_cmd.addParameter( playTime );
	s_cmd.execNonQuery();
}

static void addGroups( std::set<string> &groups, const string &groupsString ) {
	size_t nameStart = 0;
	for( size_t i = 0; i < groupsString.length(); i++ ) {
		if( groupsString[i] != '\n' ) continue;
		if( i != nameStart ) {
			groups.insert( groupsString.substr( nameStart, i - nameStart ) );
		}
		nameStart = i + 1;
	}

	if( nameStart < groupsString.length() ) {
		groups.insert( groupsString.substr( nameStart ) );
	}
}

bool DataProvider::tryFetchRomByHash( const string &sha1, bool includeGroups, RomInfo *romInfo ) noexcept {
	static SqlCommand s_cmdWithoutGroups( R"#(
SELECT name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32
FROM ROMS
WHERE sha1 = ?1
)#"
	);

	static SqlCommand s_cmdWithGroups( R"#(
SELECT name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32, groups
FROM TAGGED_ROMS
WHERE sha1 = ?1
)#"
	);

	SqlCommand &cmd = (includeGroups && romInfo != nullptr) ? s_cmdWithGroups : s_cmdWithoutGroups;
	cmd.addParameter( sha1, DATA_REF );

	DataRecordIterator results = cmd.execQuery();
	if( !results.moveNext() ) return false;

	if( romInfo != nullptr ) {
		romInfo->sha1 = sha1;
		romInfo->name = results.getString( 0 );
		romInfo->internalName = results.getString( 1 );
		romInfo->emulator = (EmulatorCore)results.getInt( 2 );
		romInfo->parallelPlugin = (GfxPlugin)results.getInt( 3 );
		romInfo->mupenPlugin = (GfxPlugin)results.getInt( 4 );
		romInfo->overclockCPU = results.getBool( 5 );
		romInfo->overclockVI = results.getBool( 6 );
		romInfo->widescreen = results.getBool( 7 );
		romInfo->inputModeId = results.getUuid( 8 );
		romInfo->lastPlayed = results.getLong( 9 );
		romInfo->playTime = results.getLong( 10 );
		romInfo->crc32 = results.getUInt( 11 );
		romInfo->groups = std::set<string>();

		if( includeGroups && !results.isNull( 12 ) ) {
			addGroups( romInfo->groups, results.getString( 12 ) );
		}
	}

	return true;
}

bool DataProvider::tryFetchRomByPath( const fs::path &filePath, bool includeGroups, RomInfo *romInfo, RomFile *romFile ) {
	static SqlCommand s_cmdWithoutGroups( R"#(
SELECT sha1, name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32, last_modified
FROM ROMS INNER JOIN ROM_PATHS USING( sha1 )
WHERE path = ?1
)#"
	);

	static SqlCommand s_cmdWithGroups( R"#(
SELECT sha1, name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32, last_modified, groups
FROM TAGGED_ROMS INNER JOIN ROM_PATHS USING( sha1 )
WHERE path = ?1
)#"
	);

	SqlCommand &cmd = (includeGroups && romInfo != nullptr) ? s_cmdWithGroups : s_cmdWithoutGroups;
	cmd.addParameter( filePath.u8string(), DATA_COPY );

	DataRecordIterator results = cmd.execQuery();
	if( !results.moveNext() ) return false;

	if( romInfo != nullptr ) {
		romInfo->sha1 = results.getString( 0 );
		romInfo->name = results.getString( 1 );
		romInfo->internalName = results.getString( 2 );
		romInfo->emulator = (EmulatorCore)results.getInt( 3 );
		romInfo->parallelPlugin = (GfxPlugin)results.getInt( 4 );
		romInfo->mupenPlugin = (GfxPlugin)results.getInt( 5 );
		romInfo->overclockCPU = results.getBool( 6 );
		romInfo->overclockVI = results.getBool( 7 );
		romInfo->widescreen = results.getBool( 8 );
		romInfo->inputModeId = results.getUuid( 9 );
		romInfo->lastPlayed = results.getLong( 10 );
		romInfo->playTime = results.getLong( 11 );
		romInfo->crc32 = results.getUInt( 12 );
		romInfo->groups = std::set<string>();

		if( includeGroups && !results.isNull( 14 ) ) {
			addGroups( romInfo->groups, results.getString( 14 ) );
		}
	}

	if( romFile != nullptr ) {
		romFile->path = filePath;
		romFile->lastModified = results.getLong( 13 );
		romFile->sha1 = results.getString( 0 );
	}

	return true;
}

bool DataProvider::tryFetchRomFile( const fs::path &filePath, RomFile *romFile ) {
	static SqlCommand s_cmd( R"#(
SELECT last_modified, sha1
FROM ROM_PATHS INNER JOIN ROMS USING( sha1 )
WHERE path = ?1
)#"
	);

	s_cmd.addParameter( filePath.u8string(), DATA_COPY );
	DataRecordIterator results = s_cmd.execQuery();
	if( results.moveNext() ) {
		if( romFile != nullptr ) {
			romFile->path = filePath;
			romFile->lastModified = results.getLong( 0 );
			romFile->sha1 = results.getString( 1 );
		}
		return true;
	} else return false;
}

bool DataProvider::tryFetchRomPathWithCrc32( uint crc32, fs::path &filePath ) {
	static SqlCommand s_cmd( R"#(
SELECT path
FROM ROMS INNER JOIN ROM_PATHS USING( sha1 )
WHERE crc32 = ?1
)#"
	);

	s_cmd.addParameter( crc32 );

	DataRecordIterator results = s_cmd.execQuery();
	while( results.moveNext() ) {
		filePath = results.getPath( 0 );
		if( fs::exists( filePath ) ) return true;
	}

	return false;
}

int DataProvider::countRomFilesWithSha1( const string &sha1 ) noexcept {
	static SqlCommand s_cmd( R"#(
SELECT COUNT(*)
FROM ROM_PATHS
WHERE sha1 = ?1
)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	DataRecordIterator results = s_cmd.execQuery();
	return results.moveNext() ? results.getInt( 0 ) : 0;
}

int DataProvider::countRomsInGroup( const string &groupName ) noexcept {
	static SqlCommand s_cmd( R"#(
SELECT COUNT(*)
FROM ROM_PATHS INNER JOIN ROM_GROUPS USING( sha1 )
WHERE group_name = ?1
)#"
	);

	s_cmd.addParameter( groupName, DATA_REF );
	DataRecordIterator results = s_cmd.execQuery();
	return results.moveNext() ? results.getInt( 0 ) : 0;
}

bool DataProvider::romWithSha1Exists( const string &sha1 ) noexcept {
	static SqlCommand s_cmd( R"#(
SELECT 1
FROM ROMS
WHERE sha1 = ?1
)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	return s_cmd.execQuery().moveNext();
}

bool DataProvider::romWithPathExists( const fs::path &filePath ) {
	static SqlCommand s_cmd( R"#(
SELECT 1
FROM ROMS INNER JOIN ROM_PATHS USING( sha1 )
WHERE path = ?1
)#"
	);

	s_cmd.addParameter( filePath.u8string(), DATA_COPY );
	return s_cmd.execQuery().moveNext();
}

std::set<string> DataProvider::fetchPersistentGroups() {
	static SqlCommand s_cmd( R"#(
SELECT name FROM PERSISTENT_GROUPS
ORDER BY name ASC
)#"
	);

	std::set<string> results;
	DataRecordIterator iterator = s_cmd.execQuery();
	while( iterator.moveNext() ) {
		results.insert( iterator.getString( 0 ) );
	}

	return results;
}

std::vector<string> DataProvider::fetchAllGroups() {
	static SqlCommand s_cmd( R"#(
SELECT DISTINCT group_name AS name FROM ROM_GROUPS
UNION
SELECT name FROM PERSISTENT_GROUPS
ORDER BY name ASC
)#"
	);

	std::vector<string> results;
	DataRecordIterator iterator = s_cmd.execQuery();
	while( iterator.moveNext() ) {
		results.push_back( iterator.getString( 0 ) );
	}

	return results;
}

std::vector<RomFile> DataProvider::fetchRomFiles() {
	static SqlCommand s_cmd( R"#(
SELECT path, last_modified, sha1
FROM ROM_PATHS
)#"
	);

	std::vector<RomFile> results;
	DataRecordIterator iterator = s_cmd.execQuery();
	while( iterator.moveNext() ) {
		results.push_back({
			iterator.getPath( 0 ),
			iterator.getLong( 1 ),
			iterator.getString( 2 )
		});
	}

	return results;
}

HashMap<string,RomInfo> DataProvider::fetchAllRomInfo() {
	static SqlCommand s_cmd( R"#(
SELECT sha1, name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32, groups
FROM TAGGED_ROMS INNER JOIN ROM_PATHS USING( sha1 )
)#"
	);

	HashMap<string,RomInfo> results;
	DataRecordIterator iterator = s_cmd.execQuery();
	while( iterator.moveNext() ) {
		string sha1 = iterator.getString( 0 );
		RomInfo &romInfo = results[sha1];
		romInfo.sha1 = std::move( sha1 );
		romInfo.name = iterator.getString( 1 );
		romInfo.internalName = iterator.getString( 2 );
		romInfo.emulator = (EmulatorCore)iterator.getInt( 3 );
		romInfo.parallelPlugin = (GfxPlugin)iterator.getInt( 4 );
		romInfo.mupenPlugin = (GfxPlugin)iterator.getInt( 5 );
		romInfo.overclockCPU = iterator.getBool( 6 );
		romInfo.overclockVI = iterator.getBool( 7 );
		romInfo.widescreen = iterator.getBool( 8 );
		romInfo.inputModeId = iterator.getUuid( 9 );
		romInfo.lastPlayed = iterator.getLong( 10 );
		romInfo.playTime = iterator.getLong( 11 );
		romInfo.crc32 = iterator.getUInt( 12 );
		romInfo.groups = std::set<string>();
		if( !iterator.isNull( 13 ) ) {
			addGroups( romInfo.groups, iterator.getString( 13 ) );
		}
	}

	return results;
}

std::vector<fs::path> DataProvider::fetchManualRomPaths() {
	static SqlCommand s_cmd( R"#(
SELECT path
FROM MANUAL_ROM_PATHS
ORDER BY path ASC
)#" );

	std::vector<fs::path> results;
	DataRecordIterator iterator = s_cmd.execQuery();
	while( iterator.moveNext() ) {
		results.push_back( iterator.getPath( 0 ) );
	}

	return results;
}

void DataProvider::addManualRomPath( const fs::path &path ) {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO MANUAL_ROM_PATHS( path )
VALUES( ?1 )
)#"
	);

	s_cmd.addParameter( path.u8string(), DATA_COPY );
	s_cmd.execNonQuery();
}

void DataProvider::deleteManualRomPath( const fs::path &path ) {
	static SqlCommand s_cmd( R"#(
DELETE FROM MANUAL_ROM_PATHS
WHERE path = ?1
)#"
	);

	s_cmd.addParameter( path.u8string(), DATA_COPY );
	s_cmd.execNonQuery();
}

void DataProvider::deleteAllManualRomPaths() noexcept {
	static SqlCommand s_cmd( "DELETE FROM MANUAL_ROM_PATHS" );
	s_cmd.execNonQuery();
}

void DataProvider::updateRomFile( const RomFile &romFile ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE ROM_PATHS SET
	last_modified = ?2,
	sha1 = ?3
WHERE path = ?1
)#"
	);

	s_cmd.addParameter( romFile.path.u8string(), DATA_COPY );
	s_cmd.addParameter( romFile.lastModified );
	s_cmd.addParameter( romFile.sha1, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::moveOrDeleteRomInfo( const string &oldSha1, const string &newSha1 ) noexcept {
	static SqlCommand s_cmd( R"#(
UPDATE OR IGNORE ROMS
SET sha1 = ?2
WHERE sha1 = ?1;

DELETE FROM ROMS
WHERE sha1 = ?1;
)#"
	);

	s_cmd.addParameter( oldSha1, DATA_REF );
	s_cmd.addParameter( newSha1, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::cloneRomInfo(
	const string &oldSha1,
	const string &newSha1,
	const string &internalName,
	uint crc32
) noexcept {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO ROMS(
	sha1, name, internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, crc32
)
SELECT(
	?2 AS sha1, name, ?3 AS internal_name, emulator, parallel_plugin, mupen_plugin, overclock_cpu, overclock_vi, widescreen, input_mode_id, last_played, play_time, ?4 AS crc32
) FROM ROMS
WHERE sha1 = ?1 
ON CONFLICT DO UPDATE SET
	internal_name = excluded.internal_name,
	crc32 = excluded.crc32,
	last_played = max( ROM.last_played, excluded.last_played ),
	play_time = ROM.play_time + excluded.play_time
)#"
	);

	s_cmd.addParameter( oldSha1, DATA_REF );
	s_cmd.addParameter( newSha1, DATA_REF );
	s_cmd.addParameter( internalName, DATA_REF );
	s_cmd.addParameter( crc32 );
	s_cmd.execNonQuery();
}

void DataProvider::deleteRomPath( const fs::path &filePath ) {
	static SqlCommand s_cmd( R"#(
DELETE FROM ROM_PATHS
WHERE path = ?1
)#"
	);

	s_cmd.addParameter( filePath.u8string(), DATA_COPY );
	s_cmd.execNonQuery();
}

void DataProvider::addToGroup( const string &sha1, const string &groupName ) noexcept {
	static SqlCommand s_cmd( R"#(
INSERT OR IGNORE INTO ROM_GROUPS( sha1, group_name )
VALUES( ?1, ?2 )
)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( groupName, DATA_REF );
	s_cmd.execNonQuery();
}

void DataProvider::removeFromGroup( const string &sha1, const string &groupName ) noexcept {
	static SqlCommand s_cmd( R"#(
DELETE FROM ROM_GROUPS
WHERE sha1 = ?1
AND group_name = ?2
)#"
	);

	s_cmd.addParameter( sha1, DATA_REF );
	s_cmd.addParameter( groupName, DATA_REF );
	s_cmd.execNonQuery();
}
