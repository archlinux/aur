#ifndef SRC_UI_MAIN_WINDOW_HPP_
#define SRC_UI_MAIN_WINDOW_HPP_

#include <QWidget>
#include <QMainWindow>
#include <memory>
#include <vector>
#include "src/core/controller.hpp"
#include "src/core/settings.hpp"
#include "src/core/async.hpp"
#include "src/core/rom.hpp"

namespace Ui {
	class MainWindow;
}

class MainWindow : public QMainWindow {
	Q_OBJECT

	private:
	Ui::MainWindow *m_ui;
	bool m_showAllPlugins;
	AppSettings m_settings;
	std::shared_ptr<bool> m_exists;
	CancellationToken m_romSearch;

	void launchEmulator(
		const RomReference &rom,
		const std::vector<PlayerController> &players,
		bool bindSavestate
	);

	private slots:
	void reloadSettings();

	void refreshRomList();

	void romSelectionChanged();
	void overclockCpuToggled();
	void overclockViToggled();
	void widescreenToggled();
	void morePluginsToggled();
	void playSingleplayer();
	void playMultiplayer();
	void configureController();
	void configureKeyboard();
	void manageRomSources();
	void editSettings();
	void emulatorChanged();
	void parallelPluginChanged( int pluginId, bool checked );
	void mupenPluginChanged( int pluginId, bool checked );
	void inputModeChanged();
	void editSave( fs::path saveFilePath );

	public:
	MainWindow();
	virtual ~MainWindow();

	protected:
	virtual void closeEvent( QCloseEvent *event ) override;

};



#endif /* SRC_UI_MAIN_WINDOW_HPP_ */
