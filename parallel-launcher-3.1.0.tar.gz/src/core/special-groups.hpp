#ifndef SRC_CORE_SPECIAL_GROUPS_HPP_
#define SRC_CORE_SPECIAL_GROUPS_HPP_

#include <QString>
#include "src/types.hpp"

namespace SpecialGroups {

	extern const string Favourites;
	extern const string AutomaticallyAdded;
	extern const string Uncategorized;

}

namespace GroupName {
	extern QString localize( const string &groupName );
}



#endif /* SRC_CORE_SPECIAL_GROUPS_HPP_ */
