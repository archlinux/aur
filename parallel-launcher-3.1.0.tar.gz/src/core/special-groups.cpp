#include "src/core/special-groups.hpp"

const string SpecialGroups::Favourites = "\x01""10";
const string SpecialGroups::AutomaticallyAdded = "\x01""80";
const string SpecialGroups::Uncategorized = "\x01""90";


QString GroupName::localize( const string &groupName ) {
	// TODO: actually localize these
	if( groupName == SpecialGroups::Favourites ) {
		return QString( "Favourites" );
	} else if( groupName == SpecialGroups::AutomaticallyAdded ) {
		return QString( "Automatically Added" );
	} else if( groupName == SpecialGroups::Uncategorized ) {
		return QString( "Uncategorized" );
	}

	return QString( groupName.c_str() );
}
