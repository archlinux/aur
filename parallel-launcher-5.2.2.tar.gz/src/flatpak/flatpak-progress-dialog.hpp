#ifndef SRC_FLATPAK_FLATPAK_PROGRESS_DIALOG_HPP_
#define SRC_FLATPAK_FLATPAK_PROGRESS_DIALOG_HPP_

#include <QDialog>
#include <functional>
#include "src/flatpak/flatpak.hpp"

namespace Ui {
	class FlatpakProgressDialog;
}

class FlatpakProgressDialog : private QDialog {
	Q_OBJECT

	private:
	Ui::FlatpakProgressDialog *m_ui;

	FlatpakProgressDialog( QWidget *parent );

	public:
	~FlatpakProgressDialog() {}

	static bool run(
		Flatpak::CancelFunc(*operation)(const Flatpak::AsyncCallbacks&),
		const char *dialogTitle,
		const char *initialMessage,
		const char *successMessage,
		const char *failureMessage,
		const char *confirmMessage = nullptr,
		QWidget *parent = nullptr
	);

};



#endif /* SRC_FLATPAK_FLATPAK_PROGRESS_DIALOG_HPP_ */
