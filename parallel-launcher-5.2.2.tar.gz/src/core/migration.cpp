#include "src/core/migration.hpp"

#include <fstream>
#include <thread>
#include <memory>
#include <unordered_map>
#include <QProgressDialog>
#include <QProgressBar>
#include <QCloseEvent>
#include "src/polyfill/base-directory.hpp"
#include "src/polyfill/sha1.hpp"
#include "src/db/sqlite.hpp"
#include "src/db/data-provider.hpp"
#include "src/db/transaction.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/hotkeys.hpp"
#include "src/core/json.hpp"
#include "src/core/qthread.hpp"
#include "src/core/special-groups.hpp"
#ifdef _WIN32
#include "src/polyfill/windows/unicode.hpp"
#endif

class StubbornProgressDialog : public QProgressDialog {

	private:
	bool *m_migrationFinished;

	public:
	StubbornProgressDialog( bool *migrationStatus ) :
		QProgressDialog( nullptr ),
		m_migrationFinished( migrationStatus )
	{
		setModal( true );
		setWindowModality( Qt::ApplicationModal );
		setLabelText( "Computing ROM Checksums..." );
		setCancelButton( nullptr );
		setAutoClose( false );

		QProgressBar *progressBar = new QProgressBar();
		progressBar->setOrientation( Qt::Horizontal );
		progressBar->setFormat( "%v/%m" );
		progressBar->setTextVisible( true );

		setBar( progressBar );
		setRange( 0, 0 );
	}

	virtual ~StubbornProgressDialog() {}

	protected:
	virtual void closeEvent( QCloseEvent *event ) override {
		if( *m_migrationFinished ) {
			QProgressDialog::closeEvent( event );
		} else {
			event->ignore();
		}
	}

};

static inline string removeNewlines( const string &str ) {
	string safeString;
	safeString.reserve( str.size() );
	for( char c : str ) {
		if( c != '\n' ) safeString += c;
	}
	return safeString;
}

static inline void processRom(
	const Json &json,
	HashMap<string,RomInfo> &romInfoTable,
	std::vector<RomFile> &romFiles,
	[[maybe_unused]] bool fixEncoding
) {
	string romName = json["name"].getOrDefault<string>( "" );
	if( romName.empty() ) return;

	string romPathString = json["file_path"].getOrDefault<string>( "" );
	if( romPathString.empty() ) return;

#ifdef _WIN32
	if( fixEncoding ) {
		romPathString = Unicode::latinToUtf8( romPathString );
	}
#endif

	const fs::path romPath = fs::to_path( romPathString );
	if( !fs::existsSafe( romPath ) ) return;

	Uuid inputModeId;
	if( !Uuid::tryParse( json["input_mode"].getOrDefault<string>( "" ), inputModeId ) ) {
		inputModeId = DefaultInputModes::Normal.id;
	}

	std::set<string> groups;
	if( json["tags"].isArray() ) {
		for( const Json &group : json["tags"].array() ) {
			string groupName = removeNewlines( group.getOrDefault<string>( "" ) );
			if( groupName.empty() ) continue;
			if( groupName == "Favourites" ) groupName = SpecialGroups::Favourites;
			if( groupName == "Automatically Added" ) groupName = SpecialGroups::AutomaticallyAdded;
			groups.insert( std::move( groupName ) );
		}
	}

	const int64 lastPlayed = json["last_played"].getOrDefault<int64>( 0 );
	const int64 playTime = json["play_time"].getOrDefault<int64>( 0 );

	string sha1 = Sha1::compute( romPath );
	if( romInfoTable.count( sha1 ) > 0 ) {
		RomInfo &romInfo = romInfoTable[sha1];
		if( romInfo.lastPlayed < lastPlayed ) romInfo.lastPlayed = lastPlayed;
		romInfo.playTime += playTime;
		romInfo.groups.insert( groups.begin(), groups.end() );
	} else {
		romInfoTable[sha1] = RomInfo{
			sha1,
			std::move( romName ),
			RomUtil::getInternalName( romPath ),
			json["emulator_core"].getOrDefault<EmulatorCore>( EmulatorCore::ParallelN64 ),
			json["gfx_plugin"].getOrDefault<GfxPlugin>( GfxPlugin::UseDefault ),
			json["gfx_plugin_mupen"].getOrDefault<GfxPlugin>( GfxPlugin::UseDefault ),
			false,
			true,
			true,
			lastPlayed,
			playTime,
			std::move( groups ),
			json["overclock_cpu"].getOrDefault<bool>( true ),
			json["overclock_vi"].getOrDefault<bool>( false ),
			RomUtil::getCrc32( romPath ),
			std::move( inputModeId ),
			json["widescreen"].getOrDefault( false )
		};
	}

	romFiles.push_back({
		romPath,
		RomUtil::getLastModified( romPath ),
		sha1,
		true
	});
}

static inline void migrateRomsToSqlite( bool fixEncoding ) {
	const fs::path filePath = BaseDir::data() / "roms.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream romListFile( filePath.u8string() );
	const Json romListJson = Json::parse( romListFile );
	romListFile.close();

	if( !romListJson.isArray() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &romList = romListJson.array();
	if( romList.empty() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	bool migrationFinished = false;
	std::shared_ptr<bool> dialogExists = std::shared_ptr<bool>( new bool( true ) );
	StubbornProgressDialog dialog( &migrationFinished );
	dialog.setRange( 0, (int)romList.size() );

	HashMap<string,RomInfo> romInfoTable;
	std::vector<RomFile> romFiles;
	romFiles.reserve( romList.size() );

	std::thread migrationWorker( [&](){
		int romsProcessed = 0;
		for( const Json &rom : romList ) {
			QtThread::safeAsync( [dialogExists,romsProcessed,&dialog](){
				if( !*dialogExists ) return;
				dialog.setValue( romsProcessed );
			});

			processRom( rom, romInfoTable, romFiles, fixEncoding );
			romsProcessed++;
		}

		QtThread::safeAsync( [dialogExists,&dialog](){
			if( !*dialogExists ) return;
			dialog.setLabelText( "Moving rom information to the database..." );
			dialog.setRange( 0, 0 );
			dialog.setValue( 0 );
		});

		SqlTransaction transaction;
		foreach_cvalue( romInfo, romInfoTable ) {
			DataProvider::addRomInfo( romInfo );
		}
		for( const RomFile &romFile : romFiles ) {
			DataProvider::addRomFile( romFile );
		}
		transaction.commit();

		QtThread::safeAsync( [dialogExists,&migrationFinished,&dialog](){
			if( !*dialogExists ) return;
			migrationFinished = true;
			dialog.close();
		});
	});

	dialog.exec();

	*dialogExists = false;
	migrationWorker.join();

	fs::error_code err;
	fs::remove( filePath, err );
}

static inline void migrateGroupsToSqlite() {
	const fs::path filePath = BaseDir::data() / "groups.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream groupsFile( filePath.u8string() );
	const Json groupListJson = Json::parse( groupsFile );
	groupsFile.close();

	if( !groupListJson.isArray() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &groups = groupListJson.array();
	if( groups.empty() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	SqlTransaction transaction;
	for( const Json &group : groups ) {
		const string groupName = group.getOrDefault<string>( "" );
		if( groupName.empty() || groupName == "Favourites" ) continue;
		DataProvider::addGroup( groupName );
	}
	DataProvider::addGroup( SpecialGroups::Favourites );
	transaction.commit();


	fs::error_code err;
	fs::remove( filePath, err );
}

static inline void migrateManualRomPaths() {
	const fs::path filePath = BaseDir::data() / "sources2.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream pathsFile( filePath.u8string() );
	const Json pathListJson = Json::parse( pathsFile );
	pathsFile.close();

	if( !pathListJson.isArray() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &romPaths = pathListJson.array();
	if( romPaths.empty() ) {
		fs::error_code err;
		fs::remove( filePath, err );
	}

	SqlTransaction transaction;
	for( const Json &romPath : romPaths ) {
		const fs::path path = fs::to_path( romPath.getOrDefault<string>( "" ) );
		if( path.empty() || !fs::existsSafe( path ) ) continue;
		DataProvider::addManualRomPath( path );
	}
	transaction.commit();

	fs::error_code err;
	fs::remove( filePath, err );
}

static inline void removeNullTerminators() {
	SqlBatch( R"#(
UPDATE ROMS SET
sha1 = substr( sha1, 0 ),
name = substr( name, 0 ),
internal_name = substr( internal_name, 0 );

UPDATE ROM_PATHS SET
path = substr( path, 0 ),
sha1 = substr( sha1, 0 );

UPDATE ROM_GROUPS SET
sha1 = substr( sha1, 0 ),
group_name = substr( group_name, 0 );

UPDATE PERSISTENT_GROUPS SET
name = substr( name, 0 );

UPDATE MANUAL_ROM_PATHS SET
path = substr( path, 0 );
)#"
	).execNonQuery();
}

static inline void clearRomNameField() {
	SqlCommand cmd( R"#(
UPDATE ROMS
SET name = ?1
)#"
	);
	cmd.addParameter( "", DATA_COPY );
	cmd.execNonQuery();
}

static inline void cleanupOrphanedData() {
	SqlCommand( R"#(
DELETE FROM ROM_GROUPS
WHERE sha1 NOT IN( SELECT sha1 FROM ROMS )
)#"
	).execNonQuery();
}

static inline void fixMissingInternalRomNames() {
	SqlCommand( R"#(
UPDATE ROM_PATHS
SET last_modified = 0
WHERE local = 1
AND sha1 IN (
	SELECT sha1 FROM ROMS
	WHERE internal_name = ''
	OR crc32 = 0
)
)#"
	).execNonQuery();
}

static inline void clearBadNameOverrides() {
	SqlCommand( R"#(
UPDATE ROMS
SET name = ''
WHERE sha1 IN (
	SELECT sha1 FROM ROM_PATHS
	INNER JOIN ROMS USING( sha1 )
		WHERE local = 1
		AND name != ''
		AND like( printf( '%%/%s.z64', name ), path )
	UNION
	SELECT sha1 FROM ROMS
	INNER JOIN RHDC_HACK_VERSIONS USING( sha1 )
	INNER JOIN RHDC_HACKS USING( id )
		WHERE ROMS.name = RHDC_HACKS.name
)
)#"
	).execNonQuery();
}

static inline void fixBadMupenPlugins() {
	SqlCommand( R"#(
UPDATE ROMS
SET mupen_plugin = 4
WHERE mupen_plugin = 2
OR mupen_plugin =  5
)#"
	).execNonQuery();
}

static inline void migrateHotkeys() {
	std::vector<KeyId> hotkeys = FileController::loadHotkeys();

	if( hotkeys.size() != (size_t)Hotkey::NUM_HOTKEYS ) {
		hotkeys = std::vector<KeyId>( Hotkeys::Default, Hotkeys::Default + (int)Hotkey::NUM_HOTKEYS );
		FileController::saveHotkeys( hotkeys );
		return;
	}

	bool defaultInitialized = true;
	for( size_t i = 0; i < hotkeys.size(); i++ ) {
		if( hotkeys[i] != Hotkeys::Default[i] ) {
			defaultInitialized = false;
			break;
		}
	}

	if( defaultInitialized ) return;

	for( KeyId &key : hotkeys ) {
		switch( (int)key ) {
			case Qt::Key_QuoteDbl:
			case Qt::Key_Apostrophe: key = KeyId::Space; break;
			case Qt::Key_Plus:
			case Qt::Key_Equal:key = KeyId::Equals; break;
			case Qt::Key_Less:
			case Qt::Key_Comma: key = KeyId::Comma; break;
			case Qt::Key_Underscore:
			case Qt::Key_Minus: key = KeyId::Hyphen; break;
			case Qt::Key_Greater:
			case Qt::Key_Period: key = KeyId::Period; break;
			case Qt::Key_Question:
			case Qt::Key_Slash: key = KeyId::Slash; break;
			case Qt::Key_Colon:
			case Qt::Key_Semicolon: key = KeyId::Semicolon; break;
			case Qt::Key_AsciiTilde:
			case Qt::Key_QuoteLeft: key = KeyId::Grave; break;
			case Qt::Key_Print:
			case Qt::Key_SysReq: key = KeyId::PrintScreen; break;
			case Qt::Key_Return:
			case Qt::Key_Enter: key = KeyId::Enter; break;
			case Qt::KeypadModifier | Qt::Key_Return:
			case Qt::KeypadModifier | Qt::Key_Enter: key = KeyId::NumpadEnter; break;
			case Qt::Key_Space: key = KeyId::Space; break;
			case Qt::Key_0: key = KeyId::Num0; break;
			case Qt::Key_1: key = KeyId::Num1; break;
			case Qt::Key_2: key = KeyId::Num2; break;
			case Qt::Key_3: key = KeyId::Num3; break;
			case Qt::Key_4: key = KeyId::Num4; break;
			case Qt::Key_5: key = KeyId::Num5; break;
			case Qt::Key_6: key = KeyId::Num6; break;
			case Qt::Key_7: key = KeyId::Num7; break;
			case Qt::Key_8: key = KeyId::Num8; break;
			case Qt::Key_9: key = KeyId::Num9; break;
			case Qt::Key_A: key = KeyId::A; break;
			case Qt::Key_B: key = KeyId::B; break;
			case Qt::Key_C: key = KeyId::C; break;
			case Qt::Key_D: key = KeyId::D; break;
			case Qt::Key_E: key = KeyId::E; break;
			case Qt::Key_F: key = KeyId::F; break;
			case Qt::Key_G: key = KeyId::G; break;
			case Qt::Key_H: key = KeyId::H; break;
			case Qt::Key_I: key = KeyId::I; break;
			case Qt::Key_J: key = KeyId::J; break;
			case Qt::Key_K: key = KeyId::K; break;
			case Qt::Key_L: key = KeyId::L; break;
			case Qt::Key_M: key = KeyId::M; break;
			case Qt::Key_N: key = KeyId::N; break;
			case Qt::Key_O: key = KeyId::O; break;
			case Qt::Key_P: key = KeyId::P; break;
			case Qt::Key_Q: key = KeyId::Q; break;
			case Qt::Key_R: key = KeyId::R; break;
			case Qt::Key_S: key = KeyId::S; break;
			case Qt::Key_T: key = KeyId::T; break;
			case Qt::Key_U: key = KeyId::U; break;
			case Qt::Key_V: key = KeyId::V; break;
			case Qt::Key_W: key = KeyId::W; break;
			case Qt::Key_X: key = KeyId::X; break;
			case Qt::Key_Y: key = KeyId::Y; break;
			case Qt::Key_Z: key = KeyId::Z; break;
			case Qt::Key_BracketLeft: key = KeyId::LeftBracket; break;
			case Qt::Key_Backslash: key = KeyId::Backslash; break;
			case Qt::Key_BracketRight: key = KeyId::RightBracket; break;
			case Qt::Key_Escape: key = KeyId::Escape; break;
			case Qt::Key_Tab: key = KeyId::Tab; break;
			case Qt::Key_Backspace: key = KeyId::Backspace; break;
			case Qt::Key_Insert: key = KeyId::Insert; break;
			case Qt::Key_Delete: key = KeyId::Delete; break;
			case Qt::Key_Pause: key = KeyId::Break; break;
			case Qt::Key_Home: key = KeyId::Home; break;
			case Qt::Key_End: key = KeyId::End; break;
			case Qt::Key_Left: key = KeyId::ArrowLeft; break;
			case Qt::Key_Up: key = KeyId::ArrowUp; break;
			case Qt::Key_Right: key = KeyId::ArrowRight; break;
			case Qt::Key_Down: key = KeyId::ArrowDown; break;
			case Qt::Key_PageUp: key = KeyId::PageUp; break;
			case Qt::Key_PageDown: key = KeyId::PageDown; break;
			case Qt::Key_Shift: key = KeyId::LeftShift; break;
			case Qt::Key_Control: key = KeyId::LeftControl; break;
			case Qt::Key_CapsLock: key = KeyId::CapsLock; break;
			case Qt::Key_NumLock: key = KeyId::NumLock; break;
			case Qt::Key_ScrollLock: key = KeyId::ScrollLock; break;
			case Qt::Key_F1: key = KeyId::F1; break;
			case Qt::Key_F2: key = KeyId::F2; break;
			case Qt::Key_F3: key = KeyId::F3; break;
			case Qt::Key_F4: key = KeyId::F4; break;
			case Qt::Key_F5: key = KeyId::F5; break;
			case Qt::Key_F6: key = KeyId::F6; break;
			case Qt::Key_F7: key = KeyId::F7; break;
			case Qt::Key_F8: key = KeyId::F8; break;
			case Qt::Key_F9: key = KeyId::F9; break;
			case Qt::Key_F10: key = KeyId::F10; break;
			case Qt::Key_F11: key = KeyId::F11; break;
			case Qt::Key_F12: key = KeyId::F12; break;
			case Qt::Key_F13: key = KeyId::F13; break;
			case Qt::Key_F14: key = KeyId::F14; break;
			case Qt::Key_F15: key = KeyId::F15; break;
			case Qt::Key_F16: key = KeyId::F16; break;
			case Qt::Key_F17: key = KeyId::F17; break;
			case Qt::Key_F18: key = KeyId::F18; break;
			case Qt::Key_F19: key = KeyId::F19; break;
			case Qt::Key_F20: key = KeyId::F20; break;
			case Qt::Key_F21: key = KeyId::F21; break;
			case Qt::Key_F22: key = KeyId::F22; break;
			case Qt::Key_F23: key = KeyId::F23; break;
			case Qt::Key_F24: key = KeyId::F24; break;
			case Qt::KeypadModifier | Qt::Key_Asterisk: key = KeyId::NumpadAsterisk; break;
			case Qt::KeypadModifier | Qt::Key_Plus: key = KeyId::NumpadPlus; break;
			case Qt::KeypadModifier | Qt::Key_Minus: key = KeyId::NumpadMinus; break;
			case Qt::KeypadModifier | Qt::Key_Period: key = KeyId::NumpadPeriod; break;
			case Qt::KeypadModifier | Qt::Key_Slash: key = KeyId::NumpadSlash; break;
			case Qt::KeypadModifier | Qt::Key_0: key = KeyId::Numpad0; break;
			case Qt::KeypadModifier | Qt::Key_1: key = KeyId::Numpad1; break;
			case Qt::KeypadModifier | Qt::Key_2: key = KeyId::Numpad2; break;
			case Qt::KeypadModifier | Qt::Key_3: key = KeyId::Numpad3; break;
			case Qt::KeypadModifier | Qt::Key_4: key = KeyId::Numpad4; break;
			case Qt::KeypadModifier | Qt::Key_5: key = KeyId::Numpad5; break;
			case Qt::KeypadModifier | Qt::Key_6: key = KeyId::Numpad6; break;
			case Qt::KeypadModifier | Qt::Key_7: key = KeyId::Numpad7; break;
			case Qt::KeypadModifier | Qt::Key_8: key = KeyId::Numpad8; break;
			case Qt::KeypadModifier | Qt::Key_9: key = KeyId::Numpad9; break;
			default: key = KeyId::INVALID; break;
		}
	}
	FileController::saveHotkeys( hotkeys );
}

static inline void clearLayouts() {
	fs::error_code err;
	fs::remove_all( BaseDir::data() / "jsml", err );
	fs::remove_all( BaseDir::data() / "layouts", err );
}

void Migration::run() {
	AppSettings settings = FileController::loadAppSettings();

	if( settings.migrationState < 2 ) {
		RetroArch::migrateSaves();
	}

	if( settings.migrationState < 3 ) {
		migrateRomsToSqlite( settings.migrationState < 1 );
		migrateGroupsToSqlite();
		migrateManualRomPaths();
	}

	if( settings.migrationState < 4 ) {
		removeNullTerminators();
		clearRomNameField();
	}

	if( settings.migrationState < 5 ) {
		cleanupOrphanedData();
	}

	if( settings.migrationState < 6 ) {
		settings.glidenAntiAliasing = true;
	}

#ifdef __APPLE__
	if( settings.migrationState < 7 && RetroArch::isRetroArchInstalled() ) {
		RetroArch::installAssets();
	}
#endif

	if( settings.migrationState < 8 ) {
		fixMissingInternalRomNames();
		clearBadNameOverrides();
	}

	if( settings.migrationState < 9 ) {
		fixBadMupenPlugins();
	}

	if( settings.migrationState < 10 ) {
		migrateHotkeys();
	}

#ifdef __APPLE__
	if( settings.migrationState < 11 ) {
		FileController::saveControllerProfiles({{ DefaultProfile::XBox360.name, DefaultProfile::XBox360 }});
	}
#endif

	if( settings.migrationState < 12 ) {
		clearLayouts();
	}

	settings.migrationState = 12;
	FileController::saveAppSettings( settings );
}
