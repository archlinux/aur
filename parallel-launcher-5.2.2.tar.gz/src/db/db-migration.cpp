#include "src/core/migration.hpp"

#include "src/core/file-controller.hpp"
#include "src/db/transaction.hpp"
#include "src/db/sqlite.hpp"

// Migration 01: added rom-specific options for ParaLLEl and GLideN64
inline static void migration_01() {
	SqlCommand checkCmd( R"#(
SELECT 1
FROM pragma_table_info('ROMS')
WHERE name = 'upscale_texrects'
)#"
	);

	if( checkCmd.execQuery().moveNext() ) {
		return;
	}

	SqlTransaction transaction;

	SqlBatch( R"#(
DROP VIEW TAGGED_ROMS;
DROP INDEX ix_rom_by_crc;

CREATE TABLE ROMS_v2(
	sha1 TEXT NOT NULL PRIMARY KEY,
	name TEXT NOT NULL,
	internal_name TEXT NOT NULL,
	emulator INTEGER NOT NULL,
	parallel_plugin INTEGER NOT NULL,
	mupen_plugin INTEGER NOT NULL,
	upscale_texrects INTEGER NOT NULL,
	emulate_framebuffer INTEGER NOT NULL,
	n64_depth_compare INTEGER NOT NULL,
	overclock_cpu INTEGER NOT NULL,
	overclock_vi INTEGER NOT NULL,
	widescreen INTEGER NOT NULL,
	input_mode_id BLOB NOT NULL,
	last_played INTEGER NOT NULL,
	play_time INTEGER NOT NULL,
	crc32 INTEGER NOT NULL
);
)#"
	).execNonQuery();

	SqlCommand migration( R"#(
INSERT INTO ROMS_v2(
	sha1,
	name,
	internal_name,
	emulator,
	parallel_plugin,
	mupen_plugin,
	upscale_texrects,
	emulate_framebuffer,
	n64_depth_compare,
	overclock_cpu,
	overclock_vi,
	widescreen,
	input_mode_id,
	last_played,
	play_time,
	crc32
)
SELECT
	sha1,
	name,
	internal_name,
	emulator,
	parallel_plugin,
	mupen_plugin,
	?1 AS upscale_texrects,
	?2 AS emulate_framebuffer,
	?3 AS n64_depth_compare,
	overclock_cpu,
	overclock_vi,
	widescreen,
	input_mode_id,
	last_played,
	play_time,
	crc32
FROM ROMS
)#"
	);

	const AppSettings &settings = FileController::loadAppSettings();
	migration.addParameter( settings.parallelTexRectUpscaling );
	migration.addParameter( settings.glidenFramebufferEmulation );
	migration.addParameter( settings.glidenCorrectDepthCompare );
	migration.execNonQuery();

	SqlCommand( "DROP TABLE ROMS" ).execNonQuery();

	SqlCommand( R"#(
ALTER TABLE ROMS_v2 RENAME TO ROMS;
CREATE INDEX ix_rom_by_crc ON ROMS( crc32 );
)#"
	).execNonQuery();

	SqlCommand( R"#(
CREATE VIEW TAGGED_ROMS AS
SELECT ROMS.*, group_concat( group_name, x'0A' ) AS groups
FROM ROMS LEFT JOIN ROM_GROUPS USING( sha1 )
GROUP BY sha1
)#"
	).execNonQuery();

	transaction.commit();
}

// Migration 02: Added local column to ROM_PATHS
inline static void migration_02() {
	SqlCommand checkCmd( R"#(
SELECT 1
FROM pragma_table_info('ROM_PATHS')
WHERE name = 'local'
)#"
	);

	if( checkCmd.execQuery().moveNext() ) {
		return;
	}

	SqlCommand( R"#(
CREATE TABLE IF NOT EXISTS ROM_PATHS_v2(
	path TEXT NOT NULL PRIMARY KEY,
	last_modified INTEGER NOT NULL,
	sha1 TEXT NOT NULL,
	local INTEGER NOT NULL
)
)#"
	).execNonQuery();

	SqlCommand( R"#(
INSERT INTO ROM_PATHS_v2( path, last_modified, sha1, local )
SELECT path, last_modified, sha1, 1 AS local FROM ROM_PATHS;
)#"
	).execNonQuery();

	SqlCommand( "DROP INDEX IF EXISTS ix_paths_by_sha1" ).execNonQuery();
	SqlCommand( "DROP TABLE ROM_PATHS" ).execNonQuery();
	SqlCommand( "ALTER TABLE ROM_PATHS_v2 RENAME TO ROM_PATHS" ).execNonQuery();
	SqlCommand( "CREATE INDEX ix_paths_by_sha1 ON ROM_PATHS( sha1 )" ).execNonQuery();
}

// Migration 03: Added version_name and sort_orer to RHDC_HACK_VERSIONS
inline static void migration_03() {
	SqlCommand checkCmd( R"#(
SELECT 1
FROM pragma_table_info('RHDC_HACK_VERSIONS')
WHERE name = 'version_name'
)#"
	);

	if( checkCmd.execQuery().moveNext() ) {
		return;
	}

	SqlCommand( R"#(
CREATE TABLE IF NOT EXISTS RHDC_HACK_VERSIONS_v2(
	sha1 TEXT NOT NULL PRIMARY KEY,
	id TEXT NOT NULL,
	version_name TEXT NOT NULL,
	sort_order INTEGER NOT NULL
)
)#"
	).execNonQuery();

	SqlCommand( R"#(
INSERT INTO RHDC_HACK_VERSIONS_v2( sha1, id, version_name, sort_order )
SELECT sha1, id, 'Unknown' AS version_name, 0 AS sort_order FROM RHDC_HACK_VERSIONS
)#"
	).execNonQuery();

	SqlCommand( "DROP INDEX IF EXISTS ix_hack_versions_by_id" ).execNonQuery();
	SqlCommand( "DROP TABLE RHDC_HACK_VERSIONS" ).execNonQuery();
	SqlCommand( "ALTER TABLE RHDC_HACK_VERSIONS_v2 RENAME TO RHDC_HACK_VERSIONS" ).execNonQuery();
	SqlCommand( "CREATE INDEX IF NOT EXISTS ix_hack_versions_by_id ON RHDC_HACK_VERSIONS( id )" ).execNonQuery();
}

// Migration 04: For beta testers- Fix primary key in RHDC_LAST_PLAYED_VERSIONS table
inline static void migration_04() {
	SqlCommand checkCmd( R"#(
SELECT 1
FROM pragma_table_info('RHDC_LAST_PLAYED_VERSIONS')
WHERE name = 'sha1'
AND pk > 0
)#"
	);

	if( !checkCmd.execQuery().moveNext() ) {
		return;
	}

	SqlCommand( "DROP TABLE RHDC_LAST_PLAYED_VERSIONS" ).execNonQuery();
	SqlCommand( R"#(
CREATE TABLE RHDC_LAST_PLAYED_VERSIONS(
	id TEXT NOT NULL PRIMARY KEY,
	sha1 TEXT NOT NULL
)
)#"
	).execNonQuery();
}

void Migration::updateDatabaseSchema() {
	migration_01();
	migration_02();
	migration_03();
	migration_04();
}
