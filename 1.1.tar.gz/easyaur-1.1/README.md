# EasyAUR
Easy-to-use wrapper for different commands and processess ( e.g. building packages from AUR ) and to manage an archlinux repository.
