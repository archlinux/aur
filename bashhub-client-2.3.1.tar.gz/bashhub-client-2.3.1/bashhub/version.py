import platform

__version__ = '2.3.1'

version_str = 'Bashhub {0} (python {1})'.format(__version__, platform.python_version())
