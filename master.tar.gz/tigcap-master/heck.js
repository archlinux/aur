//require("electron").clipboard.writeText("hecking")
require("repl").start()
