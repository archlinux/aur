# TIGCap

TIGCap is a simple, but **powerful** cross-platform screenshot software made in Electron!
