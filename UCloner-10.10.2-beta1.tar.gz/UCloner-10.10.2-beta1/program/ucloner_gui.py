#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    作者： ptptptptptpt < ptptptptptpt@163.com >
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#


import gtk
import os
import vte
import sys
import commands
import time
import signal

import functions






import gettext
APP_NAME="ucloner"
LOCALE_DIR=os.path.abspath("locale")
if not os.path.exists(LOCALE_DIR):
    LOCALE_DIR="/usr/share/locale"
gettext.bindtextdomain(APP_NAME, LOCALE_DIR)
gettext.textdomain(APP_NAME)
_ = gettext.gettext




import gtk.glade
gtk.glade.bindtextdomain(APP_NAME, LOCALE_DIR)
gtk.glade.textdomain(APP_NAME)








# 目标分区，grub设备，新主机名
class TargetParts(object):
    def __init__(self):
        
        self.builder = gtk.Builder()
        self.builder.add_from_file('./glade/target_partitions.glade')
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)

        self.vbox = self.builder.get_object('vbox1')


        # liststore：分区列表
        self.liststore_partitions = gtk.ListStore(str, str)
        self.list_partitions = []

        # liststore：文件系统
        self.liststore_fstype = gtk.ListStore(str, str)
        self.liststore_fstype.append( [ 'current', _('  -->  Do NOT format. Use current filesystem.') ] )
        self.liststore_fstype.append( [ 'ext4', _('  -->  Create ext4 filesystem. All data will be destroyed!') ] )
        self.liststore_fstype.append( [ 'ext3', _('  -->  Create ext3 filesystem. All data will be destroyed!') ] )
        self.liststore_fstype.append( [ 'reiserfs', _('  -->  Create reiserfs filesystem. All data will be destroyed!') ] )
        
        # liststore：grub设备
        self.liststore_grubdev = gtk.ListStore(str)
        

        # 目标分区：/
        self.comboboxentry_root = self.builder.get_object('comboboxentry_root')       
        self.comboboxentry_root.set_model(self.liststore_partitions)
        self.comboboxentry_root.set_text_column(0)
        cell_root = gtk.CellRendererText()
        self.comboboxentry_root.pack_start(cell_root, True)
        self.comboboxentry_root.add_attribute(cell_root, 'text', 1)
        self.comboboxentry_root.child.connect("changed", self.on_root_changed)

        # 目标分区：/home
        self.comboboxentry_home = self.builder.get_object('comboboxentry_home')
        self.comboboxentry_home.set_model(self.liststore_partitions)
        self.comboboxentry_home.set_text_column(0)
        cell_home = gtk.CellRendererText()
        self.comboboxentry_home.pack_start(cell_home, True)
        self.comboboxentry_home.add_attribute(cell_home, 'text', 1)
        self.comboboxentry_home.child.connect("changed", self.on_home_changed)

        # 目标分区：swap
        self.comboboxentry_swap = self.builder.get_object('comboboxentry_swap')
        self.comboboxentry_swap.set_model(self.liststore_partitions)
        self.comboboxentry_swap.set_text_column(0)
        cell_swap = gtk.CellRendererText()
        self.comboboxentry_swap.pack_start(cell_swap, True)
        self.comboboxentry_swap.add_attribute(cell_swap, 'text', 1)
        
        # 文件系统：/
        self.comboboxentry_rootfs = self.builder.get_object('comboboxentry_rootfs')
        self.comboboxentry_rootfs.set_text_column(0)
        cell_rootfs = gtk.CellRendererText()
        self.comboboxentry_rootfs.pack_start(cell_rootfs, True)
        self.comboboxentry_rootfs.add_attribute(cell_rootfs, 'text', 1)
        
        # 文件系统：/home
        self.comboboxentry_homefs = self.builder.get_object('comboboxentry_homefs')
        self.comboboxentry_homefs.set_text_column(0)
        cell_homefs = gtk.CellRendererText()
        self.comboboxentry_homefs.pack_start(cell_homefs, True)
        self.comboboxentry_homefs.add_attribute(cell_homefs, 'text', 1)
        
        # 按钮：刷新分区列表
        #self.button_refreshPartList = self.builder.get_object('button_refreshPartList')
        #self.button_refreshPartList.connect('clicked', self.on_button_refreshPartList_clicked )

        # grub 设备
        self.comboboxentry_grubdev = self.builder.get_object('comboboxentry_grubdev')
        self.comboboxentry_grubdev.set_model(self.liststore_grubdev)
        self.comboboxentry_grubdev.set_text_column(0)

        # 新主机名
        self.entry_new_hostname = self.builder.get_object('entry_new_hostname')
        

        


        # 底部按钮 
        self.builder2 = gtk.Builder()
        self.builder2.add_from_file("./glade/bottom.glade")

        self.bottom = self.builder2.get_object('hbox1')
        
        self.vbox.pack_start(self.bottom, False, False)

        # 底部按钮：退出
        self.button_quit = self.builder2.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)
        # 底部按钮：后退
        self.button_back = self.builder2.get_object('button_back')
        self.button_back.connect('clicked', self.on_button_back_clicked)
        # 底部按钮：前进
        self.button_forward = self.builder2.get_object('button_forward')
        


        self.back_win = None
        self.forward_win = None


    def set_back_window( self, back ):
        self.back_win = back

    def set_forward_window( self, forward ):
        self.forward_win = forward

    # 后退
    def on_button_back_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.back_win.mainWin.move(x,y)
        self.back_win.mainWin.resize(w,h)
        self.mainWin.hide_all()
        self.back_win.mainWin.show_all()
        
    # 前进
    #def on_button_forward_clicked(self, widget ):


    # 按下 刷新分区列表 按钮时
    #def on_button_refreshPartList_clicked(self, widget ):
    def on_button_refreshPartList_clicked(self ):
        self.comboboxentry_root.child.set_text('')
        self.comboboxentry_home.child.set_text('')
        self.comboboxentry_swap.child.set_text('')
        
        self.list_partitions = []
        self.liststore_partitions.clear()
        
        self.liststore_partitions.append( ['', 'Do not use a separate partition.'] )
        HDs = commands.getoutput('echo /dev/[hs]d[a-z]').split()
        for each_hd in HDs:
            ret = commands.getstatusoutput("parted -s %s unit B  print | grep -e '^[ ,0-9][0-9]' | grep -v 'extended' " %each_hd)
            if ( ret[0] != 0 ) or ( not ret[1] ) :
                pass
            else:
                for each_line in ret[1].split('\n'):
                    details = []
                    aaa = each_line.split()
                    size_B = int( aaa[3][0:-1] )
                    size_G = str( size_B/1073741824 ) + '.' + str( (size_B % 1073741824) / 107374182 ) + ' GB'
                    details.append( size_G )
                    partNO = aaa[0]
                    tmp = commands.getstatusoutput( 'blkid -p %s'%(each_hd + partNO) )
                    if tmp[0] == 0:
                        bbb = tmp[1].split()
                        bbb.sort()
                        for each in bbb:
                            if each[0:5] == 'LABEL':
                                details.append( each )
                            if each[0:4] == 'TYPE':
                                details.append( each )
                            if each[0:7] == 'VERSION':
                                details.append( each )
                    self.liststore_partitions.append( [ each_hd + partNO,  '   ' + ',   '.join(details) + '   ' ] )
                    self.list_partitions.append( each_hd + partNO )
        self.liststore_partitions.append( ['', 'Do not use a separate partition.'] )


    # root 分区改变时
    def on_root_changed(self, widget ):
        rootPart = self.comboboxentry_root.child.get_text()
        if rootPart in self.list_partitions:
            self.comboboxentry_rootfs.set_model(self.liststore_fstype)
            self.comboboxentry_rootfs.set_active(0)
            # 重置 grub 设备选单
            rootHD = rootPart[0:8]
            self.liststore_grubdev.clear()
            self.liststore_grubdev.append( [ '' ] )
            self.liststore_grubdev.append( [ rootHD ] )
            self.liststore_grubdev.append( [ rootPart ] )
            self.comboboxentry_grubdev.set_active(0)
        else:
            self.comboboxentry_rootfs.set_model(None)
            self.comboboxentry_rootfs.child.set_text('')
            # 重置 grub 设备选单
            self.liststore_grubdev.clear()
            self.comboboxentry_grubdev.child.set_text('')


    # home 分区改变时
    def on_home_changed(self, widget ):
        homePart = self.comboboxentry_home.child.get_text()
        if homePart in self.list_partitions:
            self.comboboxentry_homefs.set_model(self.liststore_fstype)
            self.comboboxentry_homefs.set_active(0)
        else:
            self.comboboxentry_homefs.set_model(None)
            self.comboboxentry_homefs.child.set_text('')


    # 获取所有参数
    def get_all_args(self):
        args = []
        
        root_part = self.comboboxentry_root.child.get_text()
        root_part_fs = self.comboboxentry_rootfs.child.get_text()
        home_part = self.comboboxentry_home.child.get_text()
        home_part_fs = self.comboboxentry_homefs.child.get_text()
        swap_part = self.comboboxentry_swap.child.get_text()
        grub_device = self.comboboxentry_grubdev.child.get_text()
        new_hostname = self.entry_new_hostname.get_text()

        if root_part:
            args.append( "/=" + root_part )
        if root_part_fs:
            args.append( "/_fs=" + root_part_fs )
        if home_part:
            args.append( "/home=" + home_part )
        if home_part_fs:
            args.append( "/home_fs=" + home_part_fs )
        if swap_part:
            args.append( "swap=" + swap_part )
        if grub_device:
            args.append( "grubdev=" + grub_device )
        if new_hostname:
            args.append( "newhostname=" + new_hostname )

        return args







class EstimateWindow(object):
    def __init__(self, parent, tittle, cmd, args ):
        self.parent = parent
        self.parent.set_sensitive(False)

        self.builder2 = gtk.Builder()
        self.builder2.add_from_file("./glade/estimate.glade")
        
        self.vteWin = self.builder2.get_object('window1')
        self.vteWin.connect('destroy', self.on_window_closed)
        self.vteWin.set_title(tittle)
        #self.vteWin.set_icon_from_file('ucloner.png')
        self.vteWin.set_position(gtk.WIN_POS_CENTER)
        self.vteWin.set_size_request(550, 300)
        self.vteWin.set_resizable(False)

        self.vteTerminal = vte.Terminal()
        self.vteTerminal.set_cursor_blinks(False)
        self.vteTerminal.set_scrollback_lines(600)
        self.vteTerminal.connect ("child-exited", self.on_vte_exit, None)

        scrollbar = gtk.VScrollbar()
        adjustment = self.vteTerminal.get_adjustment()
        scrollbar.set_adjustment(adjustment)
        
        hbox_vte = self.builder2.get_object('hbox_vte')
        hbox_vte.pack_start(self.vteTerminal)
        hbox_vte.pack_start(scrollbar, False, False)
        
        self.button_stop_task = self.builder2.get_object('button_stop_task')
        self.button_stop_task.connect('clicked', self.stop_task )

        self.button_close = self.builder2.get_object('button_close')
        self.button_close.set_sensitive(False)
        self.button_close.connect('clicked', self.on_button_close_clicked )

        self.vteWin.show_all()
        
        self.id_subproc = self.vteTerminal.fork_command( command=cmd, argv=[cmd,] + args )



    def on_window_closed(self, widget):
        self.parent.set_sensitive(True)
        try:
            os.kill( self.id_subproc, signal.SIGKILL )
        except:
            pass


    def stop_task(self, widget):
        try:
            os.kill( self.id_subproc, signal.SIGKILL )
        except:
            pass


    def on_button_close_clicked(self, widget):
        self.vteWin.destroy()
            

    def on_vte_exit(self, vte, data):
        self.button_stop_task.set_sensitive(False)
        self.button_close.set_sensitive(True)
        
        status = self.vteTerminal.get_child_exit_status()
        # 若正常退出
        if status == 0:
            pass
        # 若异常退出 或 被用户中止
        else:
            self.vteTerminal.feed('\r\n\n' + _('Program stoped.'))






# 排除目录
class Excludes(object):
    def __init__(self):

        self.builder = gtk.Builder()
        self.builder.add_from_file('./glade/excludes.glade')
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)

        self.vbox = self.builder.get_object('vbox2')

        # 排除目录 
        self.exclude_default = functions.get_default_excludes()
        self.exclude_user = []

        self.textview_excludes = self.builder.get_object('textview_excludes')

        # 估算体积
        self.button_estimate = self.builder.get_object('button_estimate')
        self.button_estimate.connect('clicked', self.on_button_estimate_clicked )
        
        # 增加排除目录
        self.button_add_dir = self.builder.get_object('button_add_dir')
        self.button_add_dir.connect('clicked', self.on_button_add_dir_clicked)
                
        # 增加排除文件
        self.button_add_file = self.builder.get_object('button_add_file')
        self.button_add_file.connect('clicked', self.on_button_add_file_clicked)
        
        # 重设
        self.button_reset = self.builder.get_object('button_reset')
        self.button_reset.connect('clicked', self.on_button_reset_clicked)


        # 初始化
        self.refresh_textview_excludes()


        # 底部按钮 
        self.builder2 = gtk.Builder()
        self.builder2.add_from_file("./glade/bottom.glade")

        self.bottom = self.builder2.get_object('hbox1')
        
        self.vbox.pack_start(self.bottom, False, False)

        # 底部按钮：退出
        self.button_quit = self.builder2.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)
        # 底部按钮：后退
        self.button_back = self.builder2.get_object('button_back')
        self.button_back.connect('clicked', self.on_button_back_clicked)
        # 底部按钮：前进
        self.button_forward = self.builder2.get_object('button_forward')
        self.button_forward.connect('clicked', self.on_button_forward_clicked )


        self.back_win = None
        self.forward_win = None


    def set_back_window( self, back ):
        self.back_win = back

    def set_forward_window( self, forward ):
        self.forward_win = forward



        
    # 后退
    def on_button_back_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.back_win.mainWin.move(x,y)
        self.back_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.back_win.mainWin.show_all()
        
    # 前进
    def on_button_forward_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.forward_win.mainWin.move(x,y)
        self.forward_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.forward_win.mainWin.show_all()



    # 刷新显示 排除目录 
    def refresh_textview_excludes(self):
        text_buffer = gtk.TextBuffer()
        text_buffer.set_text( '\n'.join( self.exclude_user + self.exclude_default ) )
        self.textview_excludes.set_buffer(text_buffer)

    # 增加排除目录
    def on_button_add_dir_clicked(self, widget ):
        dialog = gtk.FileChooserDialog('UCloner', None, gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER, 
                                        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK,  gtk.RESPONSE_OK))
        res = dialog.run()
        if res == gtk.RESPONSE_OK:
            self.exclude_user.append( dialog.get_filename() )
        dialog.destroy()
        self.refresh_textview_excludes()
        

    # 增加排除文件
    def on_button_add_file_clicked(self, widget ):
        dialog = gtk.FileChooserDialog('UCloner', None, gtk.FILE_CHOOSER_ACTION_OPEN, 
                                        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK,  gtk.RESPONSE_OK))
        res = dialog.run()
        if res == gtk.RESPONSE_OK:
            self.exclude_user.append( dialog.get_filename() )
        dialog.destroy()
        self.refresh_textview_excludes()
        
        
        
    # 重设排除内容
    def on_button_reset_clicked(self, widget ):
        self.exclude_user = []
        self.refresh_textview_excludes()

    # 返回排除内容
    def get_all_excludes(self):
        return self.exclude_default + self.exclude_user

    # 估算体积
    def on_button_estimate_clicked(self, widget):
        a = self.get_all_excludes()
        excludesWriteTo = functions.new_path('/tmp/excludesWriteTo_estimate')
        f = file( excludesWriteTo, 'w' )
        f.write( '\n'.join( a ) )
        f.close()
        cmd = './estimate_size.py'
        args = ['backup', excludesWriteTo]
        win = EstimateWindow( self.mainWin, 'UCloner', cmd, args )










# 映像文件保存路径
class BackupPath(object):
    def __init__(self):

        self.builder = gtk.Builder()
        self.builder.add_from_file('./glade/backup_path.glade')
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)

        self.vbox = self.builder.get_object('vbox1')

        # 保存目录
        self.entry_backup_dir = self.builder.get_object('entry_backup_dir')
        # 浏览
        self.button_browse = self.builder.get_object('button_browse')
        self.button_browse.connect('clicked', self.on_button_browse_clicked )
        # 文件名
        self.entry_backup_filename = self.builder.get_object('entry_backup_filename')
        self.entry_backup_filename.set_text( time.strftime('%Y-%m-%d_%H%M%S') + '.squashfs' )


        # 底部按钮 
        self.builder2 = gtk.Builder()
        self.builder2.add_from_file("./glade/bottom.glade")

        self.bottom = self.builder2.get_object('hbox1')
        
        self.vbox.pack_start(self.bottom, False, False)

        # 底部按钮：退出
        self.button_quit = self.builder2.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)
        # 底部按钮：后退
        self.button_back = self.builder2.get_object('button_back')
        self.button_back.connect('clicked', self.on_button_back_clicked)
        # 底部按钮：前进
        self.button_forward = self.builder2.get_object('button_forward')
        #self.button_forward.connect('clicked', self.on_button_forward_clicked )


        self.back_win = None
        self.forward_win = None


    def set_back_window( self, back ):
        self.back_win = back

    def set_forward_window( self, forward ):
        self.forward_win = forward

        
    # 后退
    def on_button_back_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.back_win.mainWin.move(x,y)
        self.back_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.back_win.mainWin.show_all()
        
    # 前进
    #def on_button_forward_clicked(self, widget ):



    # 指定映像文件保存目录
    def on_button_browse_clicked(self, widget ):
        dialog = gtk.FileChooserDialog('UCloner', None, gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER, 
                                        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK,  gtk.RESPONSE_OK))
        res = dialog.run()
        if res == gtk.RESPONSE_OK:
            self.entry_backup_dir.set_text( dialog.get_filename().rstrip('/') + '/' )
        dialog.destroy()


    def get_backup_to(self):
        saveDir = self.entry_backup_dir.get_text()
        fileName = self.entry_backup_filename.get_text()
        if saveDir and fileName:
            backup_to = os.path.join(saveDir, fileName)
        else:
            backup_to = ''
        return backup_to







class VteWindow(object):
    def __init__(self):

        self.builder = gtk.Builder()
        self.builder.add_from_file("./glade/vte.glade")
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)


        self.vteTerminal = vte.Terminal()
        self.vteTerminal.set_cursor_blinks(False)
        self.vteTerminal.set_scrollback_lines(600)
        self.vteTerminal.set_size_request(360, 200)
        self.vteTerminal.connect ("child-exited", self.on_vte_child_exit, None)

        scrollbar = gtk.VScrollbar()
        adjustment = self.vteTerminal.get_adjustment()
        scrollbar.set_adjustment(adjustment)
        
        hbox_vte = self.builder.get_object('hbox_vte')
        hbox_vte.pack_start(self.vteTerminal)
        hbox_vte.pack_start(scrollbar, False, False)
        
        self.checkbutton_auto_shutdown = self.builder.get_object('checkbutton_auto_shutdown')


        # 底部按钮：停止
        self.button_stop = self.builder.get_object('button_stop')
        self.button_stop.set_sensitive(False)
        self.button_stop.connect('clicked', self.stop_task )
        # 底部按钮：退出
        self.button_quit = self.builder.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)
        # 底部按钮：后退
        self.button_back = self.builder.get_object('button_back')
        self.button_back.connect('clicked', self.on_button_back_clicked)


        self.back_win = None
        self.forward_win = None


    def set_back_window( self, back ):
        self.back_win = back


        
    # 后退
    def on_button_back_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.back_win.mainWin.move(x,y)
        self.back_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.back_win.mainWin.show_all()


    def on_window_closed(self, widget):
        self.parent.set_sensitive(True)
        try:
            os.kill( self.id_subproc, signal.SIGKILL )
        except:
            pass

    def stop_task(self, widget):
        try:
            os.kill( self.id_subproc, signal.SIGKILL )
        except:
            pass


    def on_button_close_clicked(self, widget):
        self.mainWin.destroy()
            

    def run_command(self, cmd, args, reset=True):
        self.button_stop.set_sensitive(True)
        self.button_quit.set_sensitive(False)
        self.button_back.set_sensitive(False)
        if reset:
            self.vteTerminal.reset(True,True)
        self.id_subproc = self.vteTerminal.fork_command( command=cmd, argv=[cmd,] + args )


    def on_vte_child_exit(self, vte, data):
        self.button_stop.set_sensitive(False)
        self.button_quit.set_sensitive(True)
        self.button_back.set_sensitive(True)
        
        status = self.vteTerminal.get_child_exit_status()
        # 若正常退出
        if status == 0:
            if self.checkbutton_auto_shutdown.get_active():
                self.vteTerminal.feed('\r\n\n')
                self.run_command( './auto_shutdown.py', [], False )
        # 若异常退出 或 被用户中止
        else:
            self.vteTerminal.feed('\r\n\n' + _('Program stoped.'))
            self.checkbutton_auto_shutdown.set_active(False)










# 要恢复的映像文件
class RestoreImage(object):
    def __init__(self):

        self.builder = gtk.Builder()
        self.builder.add_from_file('./glade/restore_image.glade')
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)

        self.vbox = self.builder.get_object('vbox1')

        # 映像文件
        self.entry_restore_from = self.builder.get_object('entry_restore_from')
        self.button_browse = self.builder.get_object('button_browse')
        self.button_browse.connect('clicked', self.on_button_browse_clicked )


        # 底部按钮 
        self.builder2 = gtk.Builder()
        self.builder2.add_from_file("./glade/bottom.glade")

        self.bottom = self.builder2.get_object('hbox1')
        
        self.vbox.pack_start(self.bottom, False, False)

        # 底部按钮：退出
        self.button_quit = self.builder2.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)
        # 底部按钮：后退
        self.button_back = self.builder2.get_object('button_back')
        self.button_back.connect('clicked', self.on_button_back_clicked)
        # 底部按钮：前进
        self.button_forward = self.builder2.get_object('button_forward')
        self.button_forward.connect('clicked', self.on_button_forward_clicked )

        self.back_win = None
        self.forward_win = None

    def set_back_window( self, back ):
        self.back_win = back

    def set_forward_window( self, forward ):
        self.forward_win = forward

        
    # 后退
    def on_button_back_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.back_win.mainWin.move(x,y)
        self.back_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.back_win.mainWin.show_all()
        
    # 前进
    def on_button_forward_clicked(self, widget ):
        x,y = self.mainWin.get_position()
        w,h = self.mainWin.get_size()
        self.forward_win.mainWin.move(x,y)
        self.forward_win.mainWin.resize(w,h)
        
        self.mainWin.hide_all()
        self.forward_win.mainWin.show_all()

    # 指定恢复文件
    def on_button_browse_clicked(self, widget ):
        dialog = gtk.FileChooserDialog('UCloner', None, gtk.FILE_CHOOSER_ACTION_OPEN, 
                                        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OK,  gtk.RESPONSE_OK))
        res = dialog.run()
        if res == gtk.RESPONSE_OK:
            self.entry_restore_from.set_text( dialog.get_filename() )
        dialog.destroy()






class BACKUP(object):
    def __init__(self, width, height):
        self.firstWin = Excludes()
        self.secondWin = BackupPath()
        self.thirdWin = VteWindow()

        for each in [ self.firstWin, self.secondWin, self.thirdWin ]:
            #each.mainWin.set_size_request(width, height)
            each.mainWin.set_title('UCloner - ' + _('Backup'))
            each.mainWin.set_position(gtk.WIN_POS_CENTER)
            each.mainWin.set_resizable(True)
            #each.mainWin.set_icon_from_file('ucloner.png')
            each.mainWin.hide_all()


        self.firstWin.set_forward_window( self.secondWin )
        
        self.secondWin.set_back_window( self.firstWin )
        self.secondWin.set_forward_window( self.thirdWin )
        
        self.secondWin.button_forward.set_label(_(' Do Backup '))
        self.secondWin.button_forward.connect('clicked', self.do_backup )
        
        self.thirdWin.set_back_window( self.secondWin )


    def run(self, caller ):
        self.firstWin.set_back_window( caller )
        
        x,y = caller.mainWin.get_position()
        w,h = caller.mainWin.get_size()
        
        self.firstWin.mainWin.move(x,y)
        self.firstWin.mainWin.resize(w,h)
        
        caller.mainWin.hide_all()
        self.firstWin.mainWin.show_all()
        

    # 开始备份
    def do_backup(self, widget ):
        x,y = self.secondWin.mainWin.get_position()
        w,h = self.secondWin.mainWin.get_size()
        self.secondWin.forward_win.mainWin.move(x,y)
        self.secondWin.forward_win.mainWin.resize(w,h)
        
        self.secondWin.mainWin.hide_all()
        self.secondWin.forward_win.mainWin.show_all()

        # 将 要排除的目录和文件 写入文本文件
        a = self.firstWin.get_all_excludes()
        excludesWriteTo = functions.new_path('/tmp/excludesWriteTo_backup')
        f = file( excludesWriteTo, 'w' )
        f.write( '\n'.join( a ) )
        f.close()
        # 获取 备份路径 参数
        backup_to = self.secondWin.get_backup_to()
        
        args = []
        args.append( "mode=backup" )
        args.append( "backup_to=%s"%backup_to )
        args.append( 'exclude_from=%s'%excludesWriteTo )

        #print args
        #print self.thirdWin.vteTerminal.get_font()
        self.thirdWin.run_command( './ucloner_cmd.py', args )














class RESTORE(object):
    def __init__(self, width, height):
        self.firstWin = RestoreImage()
        self.secondWin = TargetParts()
        self.thirdWin = VteWindow()

        for each in [ self.firstWin, self.secondWin, self.thirdWin ]:
            #each.mainWin.set_size_request(width, height)
            each.mainWin.set_title('UCloner - ' + _('Restore'))
            each.mainWin.set_position(gtk.WIN_POS_CENTER)
            each.mainWin.set_resizable(True)
            #each.mainWin.set_icon_from_file('ucloner.png')
            each.mainWin.hide_all()


        self.firstWin.set_forward_window( self.secondWin )
        
        self.secondWin.set_back_window( self.firstWin )
        self.secondWin.set_forward_window( self.thirdWin )
        
        self.secondWin.button_forward.set_label(_(' Do Restore '))
        self.secondWin.button_forward.connect('clicked', self.do_restore )
        
        self.thirdWin.set_back_window( self.secondWin )

        self.partitionList_refreshed = False


    def run(self, caller ):
        self.firstWin.set_back_window( caller )
        
        x,y = caller.mainWin.get_position()
        w,h = caller.mainWin.get_size()
        
        self.firstWin.mainWin.move(x,y)
        self.firstWin.mainWin.resize(w,h)
        
        caller.mainWin.hide_all()
        self.firstWin.mainWin.show_all()
        
        if not self.partitionList_refreshed:
            self.secondWin.on_button_refreshPartList_clicked()
            self.partitionList_refreshed = True
        

    # 开始恢复系统
    def do_restore(self, widget ):
        x,y = self.secondWin.mainWin.get_position()
        w,h = self.secondWin.mainWin.get_size()
        self.secondWin.forward_win.mainWin.move(x,y)
        self.secondWin.forward_win.mainWin.resize(w,h)
        
        self.secondWin.mainWin.hide_all()
        self.secondWin.forward_win.mainWin.show_all()

        args = self.secondWin.get_all_args()
        args.append( "mode=restore" )
        imageFile = self.firstWin.entry_restore_from.get_text()
        args.append( "restore_from=%s"%imageFile )

        #print args
        self.thirdWin.run_command( './ucloner_cmd.py', args )











class CLONE(object):
    def __init__(self, width, height):
        self.firstWin = Excludes()
        self.secondWin = TargetParts()
        self.thirdWin = VteWindow()

        for each in [ self.firstWin, self.secondWin, self.thirdWin ]:
            #each.mainWin.set_size_request(width, height)
            each.mainWin.set_title('UCloner - ' + _('Clone'))
            each.mainWin.set_position(gtk.WIN_POS_CENTER)
            each.mainWin.set_resizable(True)
            #each.mainWin.set_icon_from_file('ucloner.png')
            each.mainWin.hide_all()


        self.firstWin.set_forward_window( self.secondWin )
        
        self.secondWin.set_back_window( self.firstWin )
        self.secondWin.set_forward_window( self.thirdWin )
        
        self.secondWin.button_forward.set_label(_('  Do Clone  '))
        self.secondWin.button_forward.connect('clicked', self.do_clone )
        
        self.thirdWin.set_back_window( self.secondWin )

        self.partitionList_refreshed = False
        

    def run(self, caller ):
        self.firstWin.set_back_window( caller )
        
        x,y = caller.mainWin.get_position()
        w,h = caller.mainWin.get_size()
        
        self.firstWin.mainWin.move(x,y)
        self.firstWin.mainWin.resize(w,h)
        
        caller.mainWin.hide_all()
        self.firstWin.mainWin.show_all()
        
        if not self.partitionList_refreshed:
            self.secondWin.on_button_refreshPartList_clicked()
            self.partitionList_refreshed = True


    # 开始克隆
    def do_clone(self, widget ):
        x,y = self.secondWin.mainWin.get_position()
        w,h = self.secondWin.mainWin.get_size()
        self.secondWin.forward_win.mainWin.move(x,y)
        self.secondWin.forward_win.mainWin.resize(w,h)
        
        self.secondWin.mainWin.hide_all()
        self.secondWin.forward_win.mainWin.show_all()

        # 目标分区
        args = self.secondWin.get_all_args()
        args.append( "mode=clone" )

        # 将 要排除的目录和文件 写入文本文件
        a = self.firstWin.get_all_excludes()
        excludesWriteTo = functions.new_path('/tmp/excludesWriteTo_clone')
        f = file( excludesWriteTo, 'w' )
        f.write( '\n'.join( a ) )
        f.close()

        args.append( 'exclude_from=%s'%excludesWriteTo )

        #print args
        self.thirdWin.run_command( './ucloner_cmd.py', args )









class UCloner(object):
    def __init__(self,width, height):
        self.gladefile = "./glade/ucloner.glade"
        self.builder = gtk.Builder()
        self.builder.add_from_file(self.gladefile)
        
        self.mainWin = self.builder.get_object('window1')
        self.mainWin.connect('destroy', gtk.main_quit)

        self.mainWin.set_default_size(width, height)
        self.mainWin.set_title('UCloner')
        self.mainWin.set_position(gtk.WIN_POS_CENTER)
        self.mainWin.set_resizable(True)
        #self.mainWin.set_icon_from_file('ucloner.png')



        self.vbox = self.builder.get_object('vbox1')
        
        self.radiobutton_backup = self.builder.get_object('radiobutton1')
        self.radiobutton_restore = self.builder.get_object('radiobutton2')
        self.radiobutton_clone = self.builder.get_object('radiobutton3')
        

        # 底部按钮：关于
        self.button_about = self.builder.get_object('button_about')
        self.button_about.connect('clicked', self.on_button_about_clicked )

        # 底部按钮：退出
        self.button_quit = self.builder.get_object('button_quit')
        self.button_quit.connect('clicked', gtk.main_quit)

        # 底部按钮：后退
        self.button_back = self.builder.get_object('button_back')
        self.button_back.set_sensitive(False)

        # 底部按钮：前进
        self.button_forward = self.builder.get_object('button_forward')
        self.button_forward.connect('clicked', self.on_button_forward_clicked )

        self.backup = BACKUP(width, height)
        self.clone = CLONE(width, height)
        self.restore = RESTORE(width, height)

        self.mainWin.show_all()



    # 前进
    def on_button_forward_clicked(self, widget ):
        if self.radiobutton_backup.get_active():
            self.backup.run( self )
        elif self.radiobutton_restore.get_active():
            self.restore.run( self )
        elif self.radiobutton_clone.get_active():
            self.clone.run( self )
        else:
            pass



    # 关于
    def on_button_about_clicked(self, widget ):
        a = gtk.AboutDialog()
        a.set_name('UCloner')
        a.set_version('10.10.2-beta1')
        a.set_copyright('GPL v2')
        a.set_comments('UCloner is a system backup/restore/clone tool designed for Ubuntu Linux.')
        a.set_website('http://code.google.com/p/ucloner/')
        a.set_website_label(_('project home ') )
        a.set_authors( ['ptptptptptpt',] )
        a.set_translator_credits('borisbsr')
        res = a.run()
        a.destroy()








    
if __name__ == '__main__':
    a = UCloner(750, 430)
    gtk.main()






