
# Speki
Flashcard app in your terminal


For manual, toggle help menu with F1 in the program.
