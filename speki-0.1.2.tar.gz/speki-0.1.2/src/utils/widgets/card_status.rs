
use crate::app::App;
use tui::{
    backend::Backend,
    layout::Rect,
    Frame,
};




pub fn card_status<B>(_f: &mut Frame<B>, _app: & App, _area: Rect, _selected: bool)
where
    B: Backend,
{

}
