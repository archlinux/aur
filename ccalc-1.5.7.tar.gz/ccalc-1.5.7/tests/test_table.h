#include "test.h"

Test get_table_test();
