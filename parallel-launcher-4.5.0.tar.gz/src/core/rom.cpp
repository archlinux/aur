#include "src/core/rom.hpp"

#include <unordered_map>
#include <utility>
#include <fstream>
#include <ios>
#include "src/polyfill/file-search.hpp"
#include "src/polyfill/sha1.hpp"
#include "src/core/file-controller.hpp"
#include "src/thirdparty/crc32.h"
#include "src/core/buffer.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/time.hpp"

static constexpr char P_GROUPS[] = "tags";
static constexpr char P_FOLDER[] = "folder_path";
static constexpr char P_RECURSIVE[] = "recursive";
static constexpr char P_IGNORE_HIDDEN[] = "ignore_hidden";
static constexpr char P_FOLLOW_SYMLINKS[] = "follow_symlinks";
static constexpr char P_MAX_DEPTH[] = "max_depth";

template<> void JsonSerializer::serialize<RomSource>( JsonWriter &jw, const RomSource &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_FOLDER, obj.folder.u8string() );
	jw.writeProperty( P_RECURSIVE, obj.recursive );
	jw.writeProperty( P_IGNORE_HIDDEN, obj.ignoreHidden && obj.recursive );
	jw.writeProperty( P_FOLLOW_SYMLINKS, obj.followSymlinks && obj.recursive );
	jw.writeProperty( P_MAX_DEPTH, obj.recursive ? obj.maxDepth : 5 );
	jw.writePropertyName( P_GROUPS );
	jw.writeArrayStart();
	for( const string &tag : obj.autoTags ) {
		jw.writeString( tag );
	}
	jw.writeArrayEnd();
	jw.writeObjectEnd();
}

template<> RomSource JsonSerializer::parse<RomSource>( const Json &json ) {
	std::set<string> tags;
	for( const Json &tag : json[P_GROUPS].array() ) {
		tags.insert( tag.get<string>() );
	}

	return RomSource{
		fs::to_path( json[P_FOLDER].get<string>() ),
		json[P_RECURSIVE].get<bool>(),
		json[P_IGNORE_HIDDEN].get<bool>(),
		json[P_FOLLOW_SYMLINKS].get<bool>(),
		json[P_MAX_DEPTH].get<ubyte>(),
		std::move( tags )
	};
}

template<> void JsonSerializer::serialize<fs::path>( JsonWriter &jw, const fs::path &obj ) {
	jw.writeString( obj.u8string() );
}

template<> fs::path JsonSerializer::parse<fs::path>( const Json &json ) {
	return fs::to_path( json.get<string>() );
}

static inline void unscrambleN64( ubyte *name ) {
	for( int i = 0; i < 20; i+= 4 ) {
		std::swap( name[i], name[i+3] );
		std::swap( name[i+1], name[i+2] );
	}
}

static inline void unscrambleV64( ubyte *name ) {
	for( int i = 0; i < 20; i+= 2 ) {
		std::swap( name[i], name[i+1] );
	}
}

static const ushort s_kanaTable[64] = {
	0x00A0, 0x8082, 0x808C, 0x808D, 0x8081, 0x83BB, 0x83B2, 0x82A1, 0x82A3, 0x82A5, 0x82A7, 0x82A9, 0x83A3, 0x83A5, 0x83A7, 0x8383,
	0x83BC, 0x82A2, 0x82A4, 0x82A6, 0x82A8, 0x82AA, 0x82AB, 0x82AD, 0x82AF, 0x82B1, 0x82B3, 0x82B5, 0x82B7, 0x82B9, 0x82BB, 0x82BD,
	0x82BF, 0x8381, 0x8384, 0x8386, 0x8388, 0x838A, 0x838B, 0x838C, 0x838D, 0x838E, 0x838F, 0x8392, 0x8395, 0x8398, 0x839B, 0x839E,
	0x839F, 0x83A0, 0x83A1, 0x83A2, 0x83A4, 0x83A6, 0x83A8, 0x83A9, 0x83AA, 0x83AB, 0x83AC, 0x83AD, 0x83AF, 0x83B3, 0x829B, 0x829C
};

string RomUtil::getInternalName( const fs::path romPath ) {
	ubyte sjsName[20];
	std::ifstream romFile( romPath.u8string(), std::ios_base::in | std::ios_base::binary );

	romFile.seekg( 0 );
	const ubyte firstByte = (ubyte)romFile.get();

	romFile.seekg( 0x20 );
	romFile.read( (char*)sjsName, 20 );
	if( !romFile.good() ) return string();
	romFile.close();

	if( firstByte == 0x40 ) {
		unscrambleN64( sjsName );
	} else if( firstByte == 0x37 ) {
		unscrambleV64( sjsName );
	}

	string name;
	for( int i = 0; i < 20; i++ ) {
		const ubyte c = sjsName[i];

		if( c == 0x5C ) {
			name += (char)0xC2;
			name += (char)0xA5;
		} else if( c == 0x7E ) {
			name += (char)0xE2;
			name += (char)0x80;
			name += (char)0xBE;
		} else if( c > 0xA0 && sjsName[i] < 0xE0 ) {
			const ushort wc = s_kanaTable[c - 0xA0];
			name += (char)0xE3;
			name += (char)(wc >> 8);
			name += (char)(wc & 0xFF);
		} else if( c == 0 ) {
			name += ' ';
		} else {
			name += (char)c;
		}
	}

	int n = (int)name.length();
	while( n > 0 && name[--n] == ' ' );

	return name.substr( 0, n + 1 );
}

int64 RomUtil::getLastModified( const fs::path romPath ) {
#ifdef __APPLE__
	return (int64)fs::last_write_time( romPath );
#else
	return Time::toUnixTime( fs::last_write_time( romPath ) );
#endif
}

uint RomUtil::getCrc32( const fs::path &romPath ) {
	const size_t fileSize = (size_t)fs::file_size( romPath );

	std::ifstream romFile( romPath.u8string(), std::ios_base::in | std::ios_base::binary );
#ifdef _WIN32
	Buffer winInternalBuffer( 8192 );
	romFile.rdbuf()->pubsetbuf( winInternalBuffer.data(), 8192 );
#endif

	Buffer romData( fileSize );
	romFile.read( romData.data(), fileSize );

#ifdef _WIN32
	romFile.rdbuf()->pubsetbuf( nullptr, 0 );
#endif

	return crc32( romData.udata(), fileSize );
}

bool RomUtil::coveredBySearchPath( const fs::path &romPath ) {
	const bool isHidden = romPath.stem().u8string()[0] == '.';

	const std::vector<RomSource> sources = FileController::loadRomSources();
	for( const RomSource &source : sources ) {
		if( isHidden && source.ignoreHidden ) continue;

		if( source.recursive ) {
			fs::path aPath = romPath.parent_path();
			for( ubyte i = 0; i < source.maxDepth && !aPath.empty(); i++ ) {
				if( aPath == source.folder ) return true;

				if( source.ignoreHidden && aPath.stem().u8string()[0] == '.' ) break;
				if( !source.followSymlinks && fs::isSymlinkSafe( aPath ) ) break;

				aPath = aPath.parent_path();
			}
		} else if( romPath.parent_path() == source.folder ) {
			return true;
		}
	}

	return false;
}
