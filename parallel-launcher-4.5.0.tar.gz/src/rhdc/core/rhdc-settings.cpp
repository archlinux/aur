#include "src/rhdc/core/rhdc-settings.hpp"

#include "src/polyfill/base-directory.hpp"

const RhdcSettings &RhdcSettings::Default() {
	static const RhdcSettings s_default = {
		/* downloadDirectory */ BaseDir::home() / "Downloads" / "rhdc-hacks",
		/* checkAllSaveSlots */ false,
		/* preferHle */ false,
		/* syncGroups */ true
	};
	return s_default;
}

static constexpr char P_DOWNLOAD_DIR[] = "download_directory";
static constexpr char P_ALL_SAVE_SLOTS[] = "check_all_save_slots";
static constexpr char P_PREFER_HLE[] = "perfer_hle";
static constexpr char P_SYNC_GROUPS[] = "sync_groups";

template<> void JsonSerializer::serialize<RhdcSettings>( JsonWriter &jw, const RhdcSettings &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_DOWNLOAD_DIR, obj.downloadDirectory.u8string() );
	jw.writeProperty( P_ALL_SAVE_SLOTS, obj.checkAllSaveSlots );
#ifdef __APPLE__
	jw.writeProperty( P_PREFER_HLE, false );
#else
	jw.writeProperty( P_PREFER_HLE, obj.preferHle );
#endif
	jw.writeProperty( P_SYNC_GROUPS, obj.syncGroups );
	jw.writeObjectEnd();
}

template<> RhdcSettings JsonSerializer::parse<RhdcSettings>( const Json &json ) {
	const string downloadDir = json[P_DOWNLOAD_DIR].getOrDefault<string>( "" );
	return RhdcSettings {
		downloadDir.empty() ? RhdcSettings::Default().downloadDirectory : fs::to_path( downloadDir ),
		json[P_ALL_SAVE_SLOTS].getOrDefault<bool>( RhdcSettings::Default().checkAllSaveSlots ),
#ifdef __APPLE__
		false,
#else
		json[P_PREFER_HLE].getOrDefault<bool>( RhdcSettings::Default().preferHle ),
#endif
		json[P_SYNC_GROUPS].getOrDefault<bool>( RhdcSettings::Default().syncGroups )
	};
}
