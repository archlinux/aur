#include "src/rhdc/core/psl.hpp"

#include "src/core/file-controller.hpp"
#include <fstream>
#include <ios>

static inline int bitcount( ubyte flags ) {
#ifdef _WIN32
	int count = 0;
	while( flags != 0 ) {
		flags &= flags - 1;
		count++;
	}
	return count;
#else
	return (int)__builtin_popcount( (uint)flags );
#endif
}

static int getSlotStarCount(
	std::ifstream &saveFile,
	const ParallelStarLayout &layout,
	uint slotIndex
) {
	const uint slotOffset = layout.slotsStart + (slotIndex * layout.slotSize);

	int starCount = 0;

	saveFile.seekg( slotOffset + layout.activeBit / 8 );

	if( !((ubyte)saveFile.get() & (1 << (7 - (layout.activeBit % 8)))) ) {
		return 0;
	}

	for( const StarBitsLocation &starBits : layout.starBits ) {
		saveFile.seekg( slotOffset + starBits.byteOffset );
		for( uint i = 0; i < starBits.numBytes; i++ ) {
			starCount += bitcount( (ubyte)saveFile.get() & starBits.bitMask );
		}
	}

	return starCount;
}

int ParallelStarLayout::getStarCount( const fs::path &saveFilePath ) const {
	std::ifstream saveFile( saveFilePath.u8string(), std::ios_base::in | std::ios_base::binary );
	if( FileController::loadRhdcSettings().checkAllSaveSlots ) {
		int starCount = 0;
		for( uint i = 0; i < numSlots; i++ ) {
			const int slotStarCount = getSlotStarCount( saveFile, *this, i );
			if( slotStarCount > starCount ) starCount = slotStarCount;
		}
		return starCount;
	} else {
		return getSlotStarCount( saveFile, *this, 0 );
	}
}

static constexpr char P_NUM_SLOTS[] = "num_save_slots";
static constexpr char P_SLOTS_START[] = "slots_start";
static constexpr char P_SLOT_SIZE[] = "slot_size";
static constexpr char P_STAR_BITS[] = "star_bits";
static constexpr char P_ACTIVE_BIT[] = "active_bit";

static constexpr char P_NAME[] = "name";
static constexpr char P_BYTE_OFFSET[] = "byte_offset";
static constexpr char P_NUM_BYTES[] = "num_bytes";
static constexpr char P_BIT_MASK[] = "bit_mask";

static constexpr char P_HACKS[] = "hacks";
static constexpr char P_LAYOUT[] = "layout";

template<> void JsonSerializer::serialize<ParallelStarLayout>( JsonWriter &jw, const ParallelStarLayout &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_NUM_SLOTS, obj.numSlots );
	jw.writeProperty( P_SLOTS_START, obj.slotsStart );
	jw.writeProperty( P_SLOT_SIZE, obj.slotSize );
	jw.writeProperty( P_ACTIVE_BIT, obj.activeBit );
	jw.writePropertyName( P_STAR_BITS );
	jw.writeArrayStart();
	for( const StarBitsLocation &starBits : obj.starBits ) {
		jw.writeObjectStart();
		jw.writeProperty( P_NAME, starBits.name );
		jw.writeProperty( P_BYTE_OFFSET, starBits.byteOffset );
		jw.writeProperty( P_NUM_BYTES, starBits.numBytes );
		jw.writeProperty( P_BIT_MASK, starBits.bitMask );
		jw.writeObjectEnd();
	}
	jw.writeArrayEnd();
	jw.writeObjectEnd();
}

template<> ParallelStarLayout JsonSerializer::parse<ParallelStarLayout>( const Json &json ) {
	ParallelStarLayout layout = {
		json[P_NUM_SLOTS].get<ubyte>(),
		json[P_SLOTS_START].get<uint>(),
		json[P_SLOT_SIZE].get<uint>(),
		json[P_ACTIVE_BIT].get<uint>(),
		std::vector<StarBitsLocation>()
	};

	if( layout.numSlots == 0 ) {
		throw JsonReaderException( "Layout must have at least one save slot" );
	}

	if( layout.slotSize == 0 ) {
		throw JsonReaderException( "Save slot size must be greater than zero" );
	}

	const JArray &jArray = json[P_STAR_BITS].array();
	layout.starBits.reserve( jArray.size() );

	if( jArray.size() == 0 ) {
		throw JsonReaderException( "Layout does not define any star bit locations" );
	}

	for( const Json &sbj : jArray ) {
		StarBitsLocation starBits = {
			sbj[P_NAME].getOrDefault<string>( "" ),
			sbj[P_BYTE_OFFSET].get<uint>(),
			sbj[P_NUM_BYTES].get<ushort>(),
			sbj[P_BIT_MASK].getOrDefault<ubyte>( 0xFF )
		};

		if( starBits.bitMask == 0 ) {
			throw JsonReaderException( "Star bitmask cannot be zero" );
		}

		layout.starBits.push_back( std::move( starBits ) );
	}

	return layout;
}

template<> void JsonSerializer::serialize<LayoutManager>( JsonWriter &jw, const LayoutManager &obj ) {
	obj.serialize( jw );
}

void LayoutManager::serialize( JsonWriter &jw ) const {
	HashMap<string,std::vector<string>> reverseMap;
	for( const auto &[hackId, name] : m_hackMap ) {
		reverseMap[name].push_back( hackId );
	}

	jw.writeArrayStart();
	for( const auto &[name, layout] : m_layoutMap ) {
		jw.writeObjectStart();
		jw.writeProperty( P_NAME, name );
		jw.writePropertyName( P_HACKS );
		jw.writeArrayStart();
		for( const string &hackId : reverseMap[name] ) {
			jw.writeString( hackId );
		}
		jw.writeArrayEnd();
		jw.writePropertyName( P_LAYOUT );
		JsonSerializer::serialize( jw, layout );
		jw.writeObjectEnd();
	}
	jw.writeArrayEnd();
}

template<> LayoutManager JsonSerializer::parse<LayoutManager>( const Json &json ) {
	HashMap<string,string> hackMap;
	HashMap<string,ParallelStarLayout> layoutMap;
	for( const Json &layoutDef : json.array() ) {
		const string &name = layoutDef[P_NAME].get<string>();
		for( const Json &hack : layoutDef[P_HACKS].array() ) {
			hackMap[hack.get<string>()] = name;
		}

		layoutMap[name] = JsonSerializer::parse<ParallelStarLayout>( layoutDef[P_LAYOUT] );
	}

	return LayoutManager( std::move( hackMap ), std::move( layoutMap ) );
}
