#!/usr/bin/env bash

# Import functions and environment variables
LIMINE_FUNCTIONS_PATH=/usr/lib/limine/limine-common-functions
# shellcheck disable=SC1090
source "${LIMINE_FUNCTIONS_PATH}" || {
	echo -e "\033[1;31m Error: Failed to source '${LIMINE_FUNCTIONS_PATH}'.\033[0m" >&2
	exit 1
}

initialize_header || exit 1

all=0
lines=()

# Read input and identify whether to process all modules or specific changes
while read -r line; do
	if [[ "${line}" != */vmlinuz ]]; then
		# Trigger for changes affecting mkinitcpio files
		all=1
		continue
	fi
	lines+=("/${line%/vmlinuz}")
done

if ((all)); then
	lines=(/usr/lib/modules/*)
fi

mutex_lock "limine-mkinitcpio-install"
reset_enroll_config

# Process each kernel directory
for line in "${lines[@]}"; do
	if ! pacman -Qqo "${line}/pkgbase" &>/dev/null; then
		# Skip kernel if pkgBase does not belong to any package
		continue
	fi

	pkgBase="$(<"${line}/pkgbase")"
	kVer="${line##*/}"

	ukiDirPath="${ESP_PATH}/EFI/Linux"
	kDirPath="${ESP_PATH}/${MACHINE_ID}/${pkgBase}"

	uki_path="${ukiDirPath}/${MACHINE_ID}_${pkgBase}.efi"
	uki_fallback_path="${ukiDirPath}/${MACHINE_ID}_${pkgBase}-fallback.efi"

	initramfs_path="${kDirPath}/initramfs-${pkgBase}"
	vmlinuz_path="${kDirPath}/vmlinuz-${pkgBase}"

	if [[ "$ENABLE_UKI" == "yes" ]] && check_uefi; then
		# Unified Kernel Image (UKI)
		install -dm700 "${ukiDirPath}"

		echo "Building UKI for ${pkgBase} (${kVer})"
		if are_snapper_and_sb_installed; then
			# Note: When Secure Boot is enabled, a signed UKI ignores external cmdline and won't boot into a Btrfs snapshot. To fix this, remove the embedded cmdline from the UKI.
			mkinitcpio --kernel "${kVer}" --no-cmdline --uki "${uki_path}"
		else
			limine-entry-tool --get-cmdline "${pkgBase}" --no-mutex >/tmp/kernel-cmdline
			mkinitcpio --kernel "${kVer}" --uki "${uki_path}" --cmdline /tmp/kernel-cmdline
			rm /tmp/kernel-cmdline
		fi
		sb_sign "${uki_path}"
		limine-entry-tool --add-uki "${pkgBase}" "${uki_path}" --comment "${kVer}" --no-mutex
		echo "UKI stored in: ${uki_path}"

		# Remove existing initramfs and vmlinuz
		if [[ -d "${kDirPath}" ]]; then
			limine-entry-tool --remove "${pkgBase}" --no-mutex
		fi

	else

		# Initramfs and vmlinuz handling
		install -dm700 "${kDirPath}"
		install -Dm600 "${line}/vmlinuz" "${vmlinuz_path}"

		echo "Building initramfs for ${pkgBase} (${kVer})"
		mkinitcpio --kernel "${kVer}" --no-cmdline --generate "${initramfs_path}"
		limine-entry-tool --add "${pkgBase}" "${initramfs_path}" "${vmlinuz_path}" --comment "${kVer}" --no-mutex
		echo "Kernel stored in: ${vmlinuz_path}"
		echo "Initramfs stored in: ${initramfs_path}"

		# Remove existing UKI files.
		if [[ -f "${uki_path}" ]]; then
			limine-entry-tool --remove-uki "${pkgBase}" --no-mutex
		fi
		if [[ -f "${uki_fallback_path}" ]]; then
			limine-entry-tool --remove-uki "${pkgBase}-fallback" --no-mutex
		fi
	fi
done

enroll_config
mutex_unlock
