#!/usr/bin/env bash

# Import functions and environment variables
LIMINE_FUNCTIONS_PATH=/usr/lib/limine/limine-common-functions
# shellcheck disable=SC1090
source "${LIMINE_FUNCTIONS_PATH}" || {
    echo -e "\033[1;31m Error: Failed to source '${LIMINE_FUNCTIONS_PATH}'.\033[0m" >&2
    exit 1
}

initialize_header || exit 1
mutex_lock "limine-dracut-remove"
reset_enroll_config

# Read a "Target" line from the pacman hook script
while read -r targetLine; do
    if [[ "${targetLine}" == */vmlinuz ]]; then
        kernel_dir="/${targetLine%/vmlinuz}"
        if [[ -f "${kernel_dir}/pkgbase" ]]; then
            pkgBase="$(<"${kernel_dir}/pkgbase")"
            limine-entry-tool --remove-all "${pkgBase}" "${pkgBase}-fallback" --quiet --no-mutex
        fi
    elif [[ "${targetLine}" == */pkgbase ]]; then
        pkgBase="$(<"${targetLine}")"
        limine-entry-tool --remove-all "${pkgBase}" "${pkgBase}-fallback" --quiet --no-mutex
    fi
done

enroll_config
mutex_unlock
