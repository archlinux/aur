#!/usr/bin/env bash

# Import functions and environment variables
LIMINE_FUNCTIONS_PATH=/usr/lib/limine/limine-common-functions
# shellcheck disable=SC1090
source "${LIMINE_FUNCTIONS_PATH}" || {
	echo -e "\033[1;31m Error: Failed to source '${LIMINE_FUNCTIONS_PATH}'.\033[0m" >&2
	exit 1
}

initialize_header || exit 1

all=0
lines=()

# Read input and identify whether to process all modules or specific changes
while read -r line; do
	if [[ "${line}" != */vmlinuz ]]; then
		# Trigger for changes affecting Dracut files
		all=1
		continue
	fi
	lines+=("/${line%/vmlinuz}")
done

if ((all)); then
	lines=(/usr/lib/modules/*)
fi

mutex_lock "limine-dracut-install"
reset_enroll_config

# Process each kernel directory
for line in "${lines[@]}"; do
	if ! pacman -Qqo "${line}/pkgbase" &>/dev/null; then
		# Skip kernel if pkgBase does not belong to any package
		continue
	fi

	pkgBase="$(<"${line}/pkgbase")"
	kVer="${line##*/}"

	ukiDirPath="${ESP_PATH}/EFI/Linux"
	kDirPath="${ESP_PATH}/${MACHINE_ID}/${pkgBase}"

	uki_path="${ukiDirPath}/${MACHINE_ID}_${pkgBase}.efi"
	uki_fallback_path="${ukiDirPath}/${MACHINE_ID}_${pkgBase}-fallback.efi"

	initramfs_path="${kDirPath}/initramfs-${pkgBase}"
	initramfs_fallback_path="${kDirPath}/initramfs-${pkgBase}-fallback"
	vmlinuz_path="${kDirPath}/vmlinuz-${pkgBase}"

	if check_uefi && { [[ "${DRACUT_UKI}" == "yes" ]] || [[ "${ENABLE_UKI}" == "yes" ]]; }; then
		# Unified Kernel Image (UKI)
		install -dm700 "${ukiDirPath}"

		echo "Building UKI for ${pkgBase} (${kVer})"
		if are_snapper_and_sb_installed; then
			# Note: When Secure Boot is enabled, a signed UKI ignores external cmdline and won't boot into a Btrfs snapshot. To fix this, remove the embedded cmdline from the UKI.
			dracut --force --uefi --hostonly --no-hostonly-cmdline --kver "${kVer}" "${uki_path}"
		else
			kernel_cmdline=$(limine-entry-tool --get-cmdline "${pkgBase}" --no-mutex)
			dracut --force --uefi --hostonly --no-hostonly-cmdline --kver "${kVer}" "${uki_path}" --kernel-cmdline "${kernel_cmdline}"
		fi
		sb_sign "${uki_path}"
		limine-entry-tool --add-uki "${pkgBase}" "${uki_path}" --comment "${kVer}" --no-mutex
		echo "UKI stored in: ${uki_path}"

		# Building UKI fallback
		if [[ "${DRACUT_FALLBACK}" == "yes" ]]; then
			echo "Building UKI fallback for ${pkgBase} (${kVer})"
			if are_snapper_and_sb_installed; then
				# Note: When Secure Boot is enabled, a signed UKI ignores external cmdline and won't boot into a Btrfs snapshot. To fix this, remove the embedded cmdline from the UKI.
				dracut --force --uefi --no-hostonly --no-hostonly-cmdline --kver "${kVer}" "${uki_fallback_path}"
			else
				kernel_cmdline=$(limine-entry-tool --get-cmdline "${pkgBase}-fallback" --no-mutex)
				dracut --force --uefi --no-hostonly --no-hostonly-cmdline --kver "${kVer}" "${uki_fallback_path}" --kernel-cmdline "${kernel_cmdline}"
			fi
			sb_sign "${uki_fallback_path}"
			limine-entry-tool --add-uki "${pkgBase}-fallback" "${uki_fallback_path}" --comment "${kVer} fallback" --no-mutex
			echo "UKI fallback stored in: ${uki_fallback_path}"
		else
			# Remove fallback if not needed
			[[ -f "${uki_fallback_path}" ]] && limine-entry-tool --remove-uki "${pkgBase}-fallback" --no-mutex
		fi

		# Remove legacy initramfs and vmlinuz
		if [[ -d "${kDirPath}" ]]; then
			limine-entry-tool --remove "${pkgBase}"
		fi

	else

		# Initramfs and vmlinuz handling
		install -dm700 "${kDirPath}"
		install -Dm600 "${line}/vmlinuz" "${vmlinuz_path}"

		echo "Building initramfs for ${pkgBase} (${kVer})"
		dracut --force --no-uefi --hostonly --no-hostonly-cmdline --kver "${kVer}" "${initramfs_path}"
		limine-entry-tool --add "${pkgBase}" "${initramfs_path}" "${vmlinuz_path}" --comment "${kVer}" --no-mutex
		echo "Kernel stored in: ${vmlinuz_path}"
		echo "Initramfs stored in: ${initramfs_path}"

		# Building initramfs fallback
		if [[ "$DRACUT_FALLBACK" == "yes" ]]; then
			echo "Building fallback initramfs for ${pkgBase} (${kVer})"
			dracut --force --no-uefi --no-hostonly --kver "${kVer}" "${initramfs_fallback_path}"
			limine-entry-tool --add "${pkgBase}" "${initramfs_fallback_path}" "${vmlinuz_path}" "-fallback" --comment "${kVer} fallback" --no-mutex
			echo "Fallback initramfs stored in: ${initramfs_fallback_path}"
		else
			# Remove fallback if not needed
			[[ -f "${initramfs_fallback_path}" ]] && {
				limine-entry-tool --remove-entry "${pkgBase}-fallback" --no-mutex
				rm -f "${initramfs_fallback_path}"
			}
		fi

		# Remove existing UKI files.
		if [[ -f "${uki_path}" ]]; then
			limine-entry-tool --remove-uki "${pkgBase}" --no-mutex
		fi
		if [[ -f "${uki_fallback_path}" ]]; then
			limine-entry-tool --remove-uki "${pkgBase}-fallback" --no-mutex
		fi
	fi
done

enroll_config
mutex_unlock
