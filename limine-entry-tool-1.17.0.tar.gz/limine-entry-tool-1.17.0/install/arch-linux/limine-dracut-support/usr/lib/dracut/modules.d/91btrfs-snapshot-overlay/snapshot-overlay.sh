#!/bin/bash
function mount_snapshot_overlay() {

    local ROOT_MNT="$NEWROOT"

    local FS_TYPE
    FS_TYPE=$(findmnt --mountpoint "$ROOT_MNT" -no FSTYPE)

    local FS_RO
    FS_RO=$(btrfs property get "${ROOT_MNT}" ro)

    if [[ "${FS_TYPE}" == "btrfs" ]] && [[ "${FS_RO}" == *"true" ]]; then
        local RAM_DIR
        RAM_DIR=$(mktemp -d -p /)
        mount -t tmpfs cowspace "${RAM_DIR}"
        mkdir -p "${RAM_DIR}"/{upper,work}
        mount -t overlay -o lowerdir="${ROOT_MNT}",upperdir="${RAM_DIR}"/upper,workdir="${RAM_DIR}"/work rootfs "${ROOT_MNT}"
    fi
}

mount_snapshot_overlay
