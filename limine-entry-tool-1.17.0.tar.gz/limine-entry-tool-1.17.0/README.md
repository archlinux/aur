# limine-entry-tool

### Contents

- [Description](#description)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Planned version 2.0.0](#donate)

## Description

This tool manages boot entries for the Limine bootloader on UEFI systems. It can create, update, or delete boot entries.

**Note:** 
Legacy BIOS, ARM, and RISC-V are also supported, but with limited functionality:

* Automatic EFI deployment is disabled.
* UKI auto-generation is disabled.
* Automatic config enrollment is disabled.
* EFI entry scanning is not supported.

### Scan for EFI Boot Entries

```shell
limine-entry-tool --scan
```
This scans all active EFI entries (e.g., dual boot) from the motherboard firmware, allowing you to select one to add to Limine.

`limine-scan` is an alias for this command. 

### Create a New Boot Entry:

```shell
limine-entry-tool --add "<kernel name>" "<path to initramfs>" "<path to vmlinuz>" "<any suffix name>" --comment "<any comment>" --quiet
```
**Note:** The `<kernel name>` must follow FAT32 naming rules (letters, digits, `_`,`.`,`-` only).
Spaces/special characters are invalid, as the name creates a FAT32 directory.

**Examples:**

```shell
# Create a boot entry for "kernel-6.10.1":
limine-entry-tool --add "kernel-6.10.1" "/tmp/initramfs" "/usr/lib/modules/6.10.1/vmlinuz"

# Create a boot entry for "kernel-6.10.1" with a "-fallback" suffix:
limine-entry-tool --add "kernel-6.10.1" "/tmp/initramfs-fallback" "/usr/lib/modules/6.10.1/vmlinuz" "-fallback"
```

These commands will create (or update) a boot entry named `kernel-6.10.1` in the boot menu and copy the files
(`initramfs`,`initramfs-fallback` and `vmlinuz`) to the directory `$ESP_PATH/${machine_id}/kernel-6.10.1/`.

### Create a New Boot Entry with a Unified Kernel Image (UKI)

```shell
limine-entry-tool --add-uki "<kernel name>" "<path to UKI>" --comment "<any comment>"  --quiet
```
**Note:** The `<kernel name>` must follow FAT32 naming rules (letters, digits, `_`,`.`,`-` only).
Spaces/special characters are invalid, as the name creates a FAT32 file.

**Example:**

Create a UKI entry for `kernel-6.12.1`:

```sh
limine-entry-tool --add-uki "kernel-6.12.1" "/tmp/uki.img"
```

This command will create (or update) a boot entry named `kernel-6.12.1` in the boot menu and copy the UKI file
to `$ESP_PATH/EFI/Linux/${machine_id}_kernel-6.12.1.efi`.

### Create a New EFI Entry

```shell
limine-entry-tool --add-efi "<EFI entry name>" "<path to EFI loader file>" --comment "<Any comment>" --priority "<Number>" --overwrite --quiet
```

Arguments:

- `--priority <Number>`: Sets the position of the EFI entry in the boot order.
  If not set, the default value is **50**, placing it in the middle of the boot order range.
- `--overwrite`: Replaces an existing entry with a new one.

**Example:**

```shell
limine-entry-tool --add-efi "Default fallback loader" "/boot/EFI/BOOT/BOOTX64.EFI" --priority 10
```

This adds a new EFI entry to `limine.conf`.
If an entry with the same name already exists, it will not be overwritten.

### Remove a Boot Entry:

```shell
limine-entry-tool --remove "<kernel name>"  --quiet
limine-entry-tool --remove-entry "<kernel name>" --quiet
limine-entry-tool --remove-uki "<kernel name>" --quiet
limine-entry-tool --remove-efi "<path to an EFI file>"
limine-entry-tool --remove-os "<OS name or machine-ID>"
```

**Examples:**

1. **Remove a kernel entry and its files:**

```shell
limine-entry-tool --remove "kernel-6.10.1"
```

This deletes:

* The boot entry from the boot menu.
* The directory `$ESP_PATH/${machine_id}/kernel-6.10.1/`, including all associated files
  (initramfs, initramfs-fallback, vmlinuz), but not UKI.

**Note:** The `<kernel name>` must match the **last part** of the directory name in its path.
If matched, all boot entries using this same path will be removed, but OS entries will remain unchanged.

2. **Remove a UKI entry:**

```sh
limine-entry-tool --remove-uki "kernel-6.10.1"
```

This removes:

* The boot entry with the UKI.
* The UKI file located at `$ESP_PATH/EFI/Linux/${machine_id}_kernel-6.10.1.efi`.

**Note:** The `<kernel name>` must match the **last part** of the UKI file name in its path.
Similar to the above, OS entries are not affected.

3. **Remove only a boot entry (keep any bootable files):**

```shell
limine-entry-tool --remove-entry "kernel-6.10.1"
```

This removes the entry named `kernel-6.10.1` from the boot menu but **does not delete its files or directory**.

4. **Remove an EFI entry**

```shell
limine-entry-tool --remove-efi "/boot/EFI/BOOT/BOOTX64.EFI"
```

This removes any EFI boot entries that match the specified EFI file path. 
*Note:* The EFI file itself will **not** be deleted.

5. **Remove an OS entry**

```shell
limine-entry-tool --remove-os "Arch Linux"
limine-entry-tool --remove-os "d647abee5e264f469d7a38b751d9d1db"
```

This removes an OS entry that matches the machine-ID or OS name.

## Requirements

* Limine version **8** or newer (due to updated configuration syntax).
* An ESP (EFI System Partition) with at least 1 GB of free space (size depends on the number of kernels).
* Java runtime version 17 or newer.
* Standard GNU `coreutils` and `util-linux`.

## Installation

### For Arch Linux

#### Easy setup

1. Install [limine-dracut-support](https://aur.archlinux.org/packages/limine-dracut-support/) for Dracut,
or [limine-mkinitcpio-hook](https://aur.archlinux.org/packages/limine-mkinitcpio-hook/) for mkinitcpio.
These packages provide hooks to automate kernel installation and removal via `limine-entry-tool`.
1. Run `bootctl --print-esp-path` to check if an ESP path is detected:
    * If detected, no further configuration is needed.
    * If not detected, edit `/etc/default/limine`
      to set `ESP_PATH=` to the correct ESP path.
1. Edit `/etc/default/limine` to set `KERNEL_CMDLINE[default]=` with your preferred kernel parameters.
1. (Optional) Edit `/etc/default/limine` to enable or disable `DRACUT_FALLBACK` for automatically generating kernel fallback.
1. (Optional) Edit `/etc/default/limine` to enable or disable `ENABLE_UKI` for creating UKI.
1. Run `limine-update` or `dracut-rebuild` (for Dracut) `limine-mkinitcpio` (for mkinitcpio) to generate an initramfs or UKI and update `$ESP_PATH/limine.conf`.
1. (Optional) `limine-scan` scans for available UEFI boot entries (dual-boot) and lets you select which ones to add to Limine.

**Note:**
When updating or reinstalling Limine, it will be automatically deployed to UEFI system with x86_64
architecture.

**or**

#### Manual setup (For advance users)

1. Install `limine-entry-tool` from [AUR](https://aur.archlinux.org/packages/limine-entry-tool/).
   This package does not include an initramfs tool.
1. Run `bootctl --print-esp-path` to check if an ESP path is detected:
    * If detected, no further configuration is needed.
    * If not detected, edit `/etc/default/limine`
      to set `ESP_PATH=` to the correct ESP path.
1. Edit `/etc/default/limine` to set `KERNEL_CMDLINE[default]=` with your preferred kernel parameters.
1. Install an initramfs tool of your choice (e.g., `mkinitcpio`, `dracut`, `booster`, or another preferred tool).
1. **Write your own script and pacman hooks** to automate the addition and removal of kernels 
   using `limine-entry-tool` with different options.
1. Run `limine-install` to deploy the Limine EFI binary to the ESP on a UEFI system (x86_64 architecture), 
   typically to `$ESP_PATH/EFI/Limine/limine_x86.efi`.
1. (Optional) `limine-scan` scans for available UEFI boot entries (dual-boot) and lets you select which ones to add to Limine.

### For Other Linux Distributions

There are no pre-built packages for various package managers.
Package maintainers are welcome to create them.

**Note:** This setup below is not suitable for NixOS and some immutable distros as they do not
follow [FHS](https://en.wikipedia.org/wiki/Filesystem_Hierarchy_Standard).

Manual installation is required:

1. Install `limine` and deploy it to ESP.
2. Make sure it is registered in your motherboard firmware.
3. Clone the repository:

```shell
git clone https://gitlab.com/Zesko/limine-entry-tool.git
cd limine-entry-tool
```

4. Build the project

```shell
mvn clean package
```

5. Install the necessary files:

```shell
cp target/limine-entry-tool.jar /usr/share/java/
cp install/arch-linux/limine-entry-tool/usr/bin/limine* /usr/local/bin/
cp -r install/arch-linux/limine-entry-tool/usr/lib/limine /usr/lib/
```
6. Edit `/etc/default/limine` to set `ESP_PATH` to the correct ESP path.
7. Edit `/etc/default/limine` to set `KERNEL_CMDLINE[default]=` with your preferred kernel parameters.
8. In `/etc/default/limine`, configure `LIMINE_BINARY_PATH=` to a Limine EFI binary path (default: `/usr/share/limine/BOOTX64.EFI` on Arch).
It will be copied to your boot partition by `limine-install`. 
9. Write your script to invoke `limine-entry-tool` to creating or removing boot entries.
10. Run `limine-install` to deploy Limine EFI binary for x86_64 architecture.

## Configuration

Copy this to `/etc/default/limine` and configure it.

```properties
### OS Entry Targeting:
### If TARGET_OS_NAME is not set, the tool will generate a new OS entry with the default distro name and machine-ID.
### Alternatively, you can add "comment: machine-id=${machine_id}" to your OS entry block in '$ESP_PATH/limine.conf'.
### The machine-ID helps the tool to automatically target the OS entry. Changing the OS name does not matter.
#TARGET_OS_NAME="Arch Linux"


### Boot Partition Path:
### Specify the mount path of your boot partition if you are running on legacy BIOS, ARM, or RISC-V.
### Note: 
### If you are using systemd with UEFI, the path is detected automatically via 'bootctl --print-esp-path'.
### If detection fails, set this path manually.
#ESP_PATH="/boot"


### Kernel Command Line Configuration:
### Set multiple kernel command lines, including parameters, for specific kernel entries.
### If not set, the tool will attempt to read the kernel parameters from '/etc/kernel/cmdline' or '/proc/cmdline'.
### [default] applies to any kernel entries without a specific configuration.
### Optionally, [fallback] applies to kernel entries that include the name *fallback*.
### Optionally, custom ["kernel name"] entries correspond to kernel entry names in the boot menu, allowing unique cmdline per kernel entry.
#KERNEL_CMDLINE[default]=""
#KERNEL_CMDLINE[fallback]=""
#KERNEL_CMDLINE["linux-lts"]=""
#KERNEL_CMDLINE["linux-zen"]=""


### Formatting Boot Entry:
### Define the number of spaces to indent each line of the boot entry in '$ESP_PATH/limine.conf'.
SPACE_NUMBER=2


### Boot Integrity Check:
### Enable BLAKE2 checksum verification for bootable files. (yes|no)
ENABLE_VERIFICATION=yes


### Automatic Config Backup:
### Create a backup of '$ESP_PATH/limine.conf' before saving, if '$ESP_PATH/limine.conf.old' is older than the specified time (in hours).
### If not set, the default threshold is 8 hours.
BACKUP_THRESHOLD=8


### Kernel Entries Order:
### Wildcard "*" matches any letter in kernel-entry name 
### If ENABLE_SORT is set to "yes", only wildcard "*" entries are sorted alphabetically.
BOOT_ORDER="*, *fallback, Snapshots"
ENABLE_SORT=no


### Custom Java Binary Path
### Set this to specify a custom Java binary path instead of using the system default.
### If left unset, the default system Java will be used.
#JAVA_BIN_PATH="/usr/lib/jvm/java-21-openjdk/bin"


### Limine UEFI Binary Path
### Set the path to the Limine UEFI binary. Default: '/usr/share/limine/BOOTX64.EFI' (from the limine package on Arch Linux)
### It will be copied to '$ESP_PATH/EFI/Limine/limine_x64.efi' when running 'limine-install'.
#LIMINE_BINARY_PATH="/usr/share/limine/BOOTX64.EFI"


### Default Boot Fallback
### Set Limine as the default boot fallback at '$ESP_PATH/EFI/BOOT/BOOTX64.EFI'. (yes|no)
ENABLE_LIMINE_FALLBACK=no


### Find Bootloaders:
### Automatically add systemd-boot, rEFInd, or the default EFI loader to Limine if they are found in the ESP. (yes|no)
FIND_BOOTLOADERS=yes


### Enroll Limine Config
### Automatically enrolls the Limine config into the Limine binary to protect it from modifications.
###
### WARNING and RISKS:
### Enabling this will PREVENT booting if limine.conf is accidentally modified and manual re-enrollment is forgotten.
### If you're unsure but want to try it, set 'ENABLE_LIMINE_FALLBACK=yes' and run 'limine-update' to enable booting into the Limine fallback without enrolling the config.
###
### IMPORTANT REMEMBER: Always run 'limine-enroll-config' after editing limine.conf, otherwise Limine will block the changes.
### Note:
### * If using limine-snapper-sync, set 'COMMANDS_BEFORE_SAVE=limine-reset-enroll' and 'COMMANDS_AFTER_SAVE=limine-enroll-config' to automate config enrollment.
### * If multiple systems modify the same limine.conf, they should handle enrollment automatically.
### * To enable, copy this option to /etc/default/limine and set it to (yes|no). This option has no effect in /etc/limine-entry-tool.conf
#ENABLE_ENROLL_LIMINE_CONFIG=no


##########  The below options apply to Arch Linux when 'limine-dracut-support' or 'limine-mkinitcpio-hook' is installed ###########

### UKI (Unified Kernel Image):
### Automatically create UKIs in '$ESP_PATH/EFI/Linux/' for UEFI. (yes|no)
###
### Advantage:
###  - UKIs are automatically loaded by bootloaders like 'systemd-boot' and 'rEFInd'.
### Disadvantage:
###  - UKIs use more ESP space compared to separate 'initramfs' and 'vmlinuz' files, especially with multiple Limine snapshots.
###
### Additional notes:
### - Duplicate 'initramfs' and 'vmlinuz' files are removed when 'limine-update' is run to generate a UKI.
### - UKI ignores booting into a snapshot when Secure Boot is enabled. To resolve this, any embedded kernel cmdline is removed from the UKI, which will then read the external kernel cmdline.
ENABLE_UKI=no


### Dracut Fallback Configuration:
### Automatically create a kernel fallback image using Dracut. (yes|no)
### If set to 'yes,' this will consume a lot of storage space, especially when taking multiple snapshots.
DRACUT_FALLBACK=no
```

______________________

### Donate

If you would like to support my work on the planned version 2.0.0,
a complete rewrite in Kotlin with some advantages and improvements over version 1, feel free to donate:

[<img src="https://gitlab.com/Zesko/resources/-/raw/main/kofiButton.png" width=110px>](https://ko-fi.com/zeskotron)
&nbsp;[<img src="https://gitlab.com/Zesko/resources/-/raw/main/PayPalButton.png" width=160px/>](https://www.paypal.com/donate/?hosted_button_id=XKP36D62AY5HY)

##### Planned version 2.0.0

- **Support for smaller ESP sizes** by storing bootable files on a separate FAT32 partition.
- **BLS support:** Automatically parses existing BLS files and generates corresponding Limine boot entries.
- **Configurable protocol options** for individual kernel entries.
- **Configurable kernel entry options:** for example,
`KERNEL_ENTRY_OPTIONS["kernel fallback"]="skip-kernel-snapshot"`, which can be read by Limine-Snapper-Sync.
- **Complete rewrite in Kotlin:** This will simplify and optimize the codebase compared to version 1.
- **Improving performance:** Optimized code using standard libraries.
- **Full compatibility** with version 1.
