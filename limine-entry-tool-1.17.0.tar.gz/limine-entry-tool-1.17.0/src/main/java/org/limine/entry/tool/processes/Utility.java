package org.limine.entry.tool.processes;

import org.limine.entry.tool.formats.limine8.LimineKey;
import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.ConsoleColor;
import org.limine.entry.tool.objects.LogLevel;
import org.limine.entry.tool.objects.Output;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Utility {

    private static final int MACHINE_ID_LENGTH = 32;
    private static final String MACHINE_ID_FILE_PATH = "/etc/machine-id";

    public static void ensureDirectoryExists(String dirPath) {
        // Construct the full directory path
        File dir = new File(dirPath);
        // Check if the directory exists
        if (!dir.exists()) {
            // If it doesn't exist, create the directory
            if (dir.mkdirs()) {
                if (Config.ENABLE_PRINT) {
                    System.out.println(ConsoleColor.GREEN_BOLD + "Directory created: " + ConsoleColor.RESET + dir.getPath());
                }
            } else {
                System.err.println(ConsoleColor.RED_BOLD + "Failed to create directory: " + ConsoleColor.RESET + dir.getPath());
                loggerSend("Failed to create directory: " + dir.getPath(), LogLevel.ERROR);
            }
        }
    }

    /**
     * Generate a machine ID in /etc/machine-id
     */
    public static String readMachineID() {
        String machineID;
        try {
            machineID = new String(Files.readAllBytes(Paths.get("/etc/machine-id"))).trim();
        } catch (IOException e) {
            machineID = generateRandomMachineID();
        }
        return machineID;
    }

    public static boolean isFilePresent(String filePath) {
        File file = new File(filePath);
        return file.exists() && file.isFile();
    }

    public static boolean isDirectoryPresent(String dirPath) {
        Path path = Paths.get(dirPath);
        try {
            // Check if the path exists and is a directory (following symbolic links)
            return Files.exists(path) && Files.isDirectory(path);
        } catch (Exception e) {
            return false;
        }
    }

    public static String generateRandomMachineID() {
        SecureRandom random = new SecureRandom();
        StringBuilder newMachineID = new StringBuilder(MACHINE_ID_LENGTH);
        for (int i = 0; i < MACHINE_ID_LENGTH; i++) {
            int nextInt = random.nextInt(16); // 0-15 for hexadecimal
            newMachineID.append(Integer.toHexString(nextInt));
        }
        try {
            Files.writeString(Paths.get(MACHINE_ID_FILE_PATH), newMachineID);
            if (Config.ENABLE_PRINT) {
                System.out.println(ConsoleColor.GREEN_BOLD + "New machine-id generated: " + ConsoleColor.RESET + newMachineID);
                System.out.println(ConsoleColor.GREEN_BOLD + "This machine-id saved: " + ConsoleColor.RESET + MACHINE_ID_FILE_PATH);
            }
            changeFilePermissions(MACHINE_ID_FILE_PATH, "r--r--r--");
        } catch (IOException e) {
            String errMessage = "New machine ID generator failed. Error: " + e.getMessage();
            System.err.println(ConsoleColor.RED_BOLD + "New machine ID generator failed. Error: " + ConsoleColor.RESET + e.getMessage());
            loggerSend(errMessage, LogLevel.ERROR);
            throw new RuntimeException(e);
        }
        return newMachineID.toString();
    }

    public static void changeFilePermissions(String filePath, String permissions) {
        Path path = Paths.get(filePath);
        // Convert the permission string to a set of PosixFilePermissions
        Set<PosixFilePermission> perms = PosixFilePermissions.fromString(permissions);
        try {
            Files.setPosixFilePermissions(path, perms);
            if (Config.ENABLE_PRINT) {
                System.out.println(ConsoleColor.GREEN + "Permissions " + permissions + " changed successfully for file: " + filePath + ConsoleColor.RESET);
            }
        } catch (IOException e) {
            String errMessage = "Failed to change permissions " + permissions + " for file: " + filePath;
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            loggerSend(errMessage, LogLevel.ERROR);
        }
    }

    private static String extractHash(String outputLine) {
        StringBuilder hash = new StringBuilder();
        outputLine = outputLine.trim();
        for (int i = 0; i < outputLine.length(); i++) {
            char c = outputLine.charAt(i);
            if (c == ' ') {
                break;
            }
            hash.append(c);
        }
        return hash.toString();
    }

    public static String blake2(String absoluteFilePath) {
        Output output = Utility.getTextFromCommand(Config.HASH_COMMAND_LINE + " " + absoluteFilePath, false, true);
        if (output.isSuccess()) {
            return Utility.extractHash(output.text().get(0));
        } else {
            return null;
        }
    }

    public static void copyFile(String sourceFilePath, String targetFilePath, boolean force, boolean showOutput, boolean showCommand) {
        if (force) {
            Utility.runCommand("cp -f '" + sourceFilePath + "' '" + targetFilePath + "'", showOutput, showCommand);
        } else {
            Utility.runCommand("cp -u '" + sourceFilePath + "' '" + targetFilePath + "'", showOutput, showCommand);
        }
    }

    public static void copyFile(String sourceFilePath, String targetFilePath, boolean force) {
        copyFile(sourceFilePath, targetFilePath, force, true, true);
    }

    public static void moveFile(String sourceFilePath, String targetFilePath, boolean force, boolean showOutput, boolean showCommand) {
        if (force) {
            Utility.runCommand("mv -f '" + sourceFilePath + "' '" + targetFilePath + "'", showOutput, showCommand);
        } else {
            Utility.runCommand("mv -u '" + sourceFilePath + "' '" + targetFilePath + "'", showOutput, showCommand);
        }
    }

    public static void deleteDirectory(String dirPath) {
        Utility.runCommand("rm -rf '" + dirPath + "'", true, true);
    }

    public static void deleteFile(String absoluteFilePath) {
        Utility.runCommand("rm -f '" + absoluteFilePath + "'", true, true);
    }

    /**
     * Get the result from a command output using ProcessBuilder.
     *
     * @param commandLine         The command to be executed.
     * @param exitIfError         If true, the application will exit in case of error.
     * @param displayErrorMessage Error message to display/log in case of error.
     * @return List of strings containing the output of the command.
     */
    public static Output getTextFromCommand(String commandLine, boolean exitIfError, boolean displayErrorMessage) {
        // Use ProcessBuilder to create and start the process
        ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", commandLine)
                .redirectErrorStream(true);// Redirect error stream to the standard output stream
        try {
            Process process = processBuilder.start();
            List<String> textOutput = new ArrayList<>();

            // Use try-with-resources to automatically close BufferedReader
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                reader.lines().forEach(textOutput::add);
            }

            // Wait for the process to finish and get the exit code
            int errorCode = process.waitFor();
            if (errorCode == 0) {
                return new Output(textOutput, null, errorCode, true);
            }
            if (displayErrorMessage) {
                System.err.println(ConsoleColor.RED_BOLD + "Command failed: " + ConsoleColor.RESET + commandLine);
                loggerSend("Command failed: " + commandLine, LogLevel.ERROR);
                if (!textOutput.isEmpty()) {
                    if (!textOutput.get(0).trim().isEmpty()) {
                        System.err.println(ConsoleColor.RED_BOLD + "Output: " + ConsoleColor.RESET + Arrays.toString(textOutput.toArray()));
                        loggerSend("Output: " + Arrays.toString(textOutput.toArray()), LogLevel.ERROR);
                    }
                }
            }
            if (exitIfError) {
                System.err.println(ConsoleColor.RED_BOLD + "Exit code: " + ConsoleColor.RESET + errorCode);
                loggerSend("Exit code: " + errorCode, LogLevel.ERROR);
                System.exit(1);
            }
            return new Output(null, textOutput, errorCode, false);
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Run multiple commands.
     */
    public static void runCommands(List<String> commands, boolean stopNextCommandOnError, boolean showOutput, boolean showCommand) {
        try {
            for (String command : commands) {
                ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", command);
                Process process = processBuilder.start();

                CompletableFuture<Void> outputFuture = null;
                CompletableFuture<Void> errorFuture = null;

                if (showOutput) {
                    // Use CompletableFuture to asynchronously read output and error streams
                    outputFuture = CompletableFuture.runAsync(() -> printStream(process.getInputStream(), System.out::println));
                    errorFuture = CompletableFuture.runAsync(() -> printStream(process.getErrorStream(), System.err::println));
                }
                // Wait for the process to complete
                int errorCode = process.waitFor();
                if (showOutput) {
                    // Wait for the output/error streams to finish processing
                    outputFuture.join();
                    errorFuture.join();
                }
                if (errorCode != 0) {
                    System.err.println(ConsoleColor.RED_BOLD + "Command failed: " + ConsoleColor.RESET + "\"" + command + "\" with exit code: " + errorCode);
                    loggerSend("Command failed: \"" + command + "\" with exit code: " + errorCode, LogLevel.ERROR);
                    if (stopNextCommandOnError) {
                        // Stop continues to the next command
                        break;
                    }
                } else {
                    if (showCommand && Config.ENABLE_PRINT) {
                        System.out.println(ConsoleColor.GREEN_BOLD + "Command succeeded: " + ConsoleColor.RESET + command);
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void printStream(InputStream inputStream, Consumer<String> consumer) {
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                consumer.accept(line);
            }
        } catch (IOException ignored) {
        }
    }


    public static void runCommand(String command, boolean showOutput, boolean showCommand) {
        runCommands(List.of(command), true, showOutput, showCommand);
    }


    public static String extractFileNameFromPath(String path) {
        int lastIndex = path.lastIndexOf('/');
        if (lastIndex != -1) {
            return path.substring(lastIndex + 1);
        } else {
            // If no '/' is found, return the entire path as a file name
            return path;
        }
    }


    /**
     * Logger
     */
    public static void loggerSend(String message, LogLevel logLevel) {
        try {
            // Bugfix: Do not use Runtime.getRuntime() that has a bug to escape some character like '-'
            // Use ProcessBuilder instead.
            ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", "logger -t limine-entry-tool -p " + logLevel.level + " \"" + message + "\"");
            processBuilder.start();
        } catch (IOException ignored) {
        }
    }


    /**
     * Read any kernel parameters from /proc/cmdline or /etc/kernel/cmdline?
     */
    public static String readKernelCmdline() {
        String[] possiblePaths = {"/etc/kernel/cmdline", "/proc/cmdline"};
        for (String pathString : possiblePaths) {
            Path path = Paths.get(pathString);
            if (Files.exists(path)) {
                try {
                    String line = new String(Files.readAllBytes(path));
                    // Use regex to remove all trailing line breaks (\r\n or \n)
                    return line.replaceAll("[\\r\\n]+$", "").trim();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return null; // Return null if neither file is found
    }


    public static String getLinuxDistroName() {
        Path osReleasePath = Paths.get("/etc/os-release");
        try {
            if (Files.exists(osReleasePath)) {
                List<String> lines = Files.readAllLines(osReleasePath);

                for (String line : lines) {
                    if (line.startsWith("PRETTY_NAME=")) {
                        return line.split("=")[1].replaceAll("\"", "");
                    }
                }
            }

            Path debianVersionPath = Paths.get("/etc/debian_version");
            Path redhatVersionPath = Paths.get("/etc/redhat-release");

            // Fallbacks if /etc/os-release is not available
            if (Files.exists(Paths.get("/etc/lsb-release"))) {
                return getLinuxDistroNameFromLsbReleaseFile();

            } else if (Files.exists(debianVersionPath)) {
                return "Debian " + Files.readString(debianVersionPath).trim();

            } else if (Files.exists(redhatVersionPath)) {
                return Files.readString(redhatVersionPath).trim();

            }
        } catch (IOException e) {
            System.err.println(ConsoleColor.RED_BOLD + "Error reading Linux Distro information: " + ConsoleColor.RESET + e.getMessage());
        }
        return null; // Return null if no information is found
    }

    private static String getLinuxDistroNameFromLsbReleaseFile() throws IOException {
        List<String> lines = Files.readAllLines(Paths.get("/etc/lsb-release"));
        for (String line : lines) {
            if (line.startsWith("DISTRIB_DESCRIPTION=")) {
                return line.split("=")[1].replaceAll("\"", "").trim();
            }
        }
        return null;
    }

    /**
     * Remove leading symbols in the name.
     */
    public static String cleanName(String name) {
        if (name == null || name.isEmpty()) {
            return name;
        }
        name = name.trim();
        int i = 0;
        boolean isColonFound = false;
        // Loop to skip all leading colons
        while (i < name.length() && name.startsWith(LimineKey.ENTRY_KEY.toString(), i)) {
            isColonFound = true;
            i++;
        }
        if (isColonFound && name.startsWith(LimineKey.EXPAND.toString(), i)) {
            i++;
        }
        return name.substring(i);
    }

    public static String buildPath(String... parts) {
        String path = Paths.get("", parts).toString();
        if (path.startsWith(File.separator)) {
            return path;
        } else {
            return File.separator + path;
        }
    }


    /**
     * Check whether the command exists.
     */
    public static boolean isCommandPresent(String command) {
        // Get the PATH environment variable
        String pathEnv = System.getenv("PATH");
        if (pathEnv == null || pathEnv.isEmpty()) {
            return false; // If the PATH is empty, the command cannot be found
        }

        // Split the PATH by the system's path separator (":" on Linux/Unix)
        String[] paths = pathEnv.split(File.pathSeparator);

        // Iterate through each directory in PATH
        for (String path : paths) {
            // Check if the command exists in the current directory
            File commandFile = new File(path, command);
            if (commandFile.isFile() && commandFile.canExecute()) {
                return true; // Command exists and is executable
            }
        }
        return false; // Command isn't found in any PATH directories
    }


    /**
     * Validates if the system is running in EFI mode.
     *
     * @return True if the system is running in EFI mode; otherwise, false.
     */
    public static boolean isSystemEfi() {
        return new File("/sys/firmware/efi").exists();
    }


    /**
     * Check if the system is x86_84 or amd84
     */
    public static boolean isSystemAmd64() {
        String arch = System.getProperty("os.arch").toLowerCase();
        return arch.equals("x86_64") || arch.equals("amd64");
    }


    /**
     * Validates if the given path is a valid boot partition using FAT32.
     *
     * @param path The path to validate (e.g., "/boot/efi").
     * @return True if the path is a valid FAT32 partition; otherwise, false.
     */
    public static boolean validateFatPartition(String path) {
        File bootPath = new File(path);

        // Check if the given path exists and is mounted
        if (!bootPath.exists() || !bootPath.isDirectory()) {
            String errMessage = "The specified ESP path '" + path + "' does not exist or is not a directory.";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            loggerSend(errMessage, LogLevel.ERROR);
            return false;
        }

        // Check if the path has a FAT32 filesystem
        try {
            String fileSystemType = Files.getFileStore(Paths.get(path)).type();
            if (!"vfat".equalsIgnoreCase(fileSystemType)) {
                String errMessage = "The ESP path '" + path + "' does not have a FAT32 (vfat) filesystem.";
                System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
                loggerSend(errMessage, LogLevel.ERROR);
                return false;
            }
        } catch (IOException e) {
            String errMessage = "Error checking filesystem type of the ESP path '" + path + "' : " + e.getMessage();
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            loggerSend(errMessage, LogLevel.ERROR);
            return false;
        }

        return true;
    }


    /**
     * Corrects the case sensitivity of a given file path by traversing the actual
     * filesystem and returning the case-sensitive path on the underlying filesystem.
     * This is particularly useful for case-insensitive filesystems like FAT32.
     *
     * @param path The input file path that needs correction.
     * @return The corrected case-sensitive path, or null if the file does not exist.
     */
    public static String correctCaseSensitivePath(String path) {
        File file = new File(path);
        if (!file.exists()) {
            return null; // File does not exist
        }

        StringBuilder correctedPath = new StringBuilder();

        File current = file;
        while (current != null) {
            File parent = current.getParentFile();
            if (parent != null) {
                File[] siblings = parent.listFiles();
                if (siblings != null) {
                    for (File sibling : siblings) {
                        if (sibling.getName().equalsIgnoreCase(current.getName())) {
                            correctedPath.insert(0, File.separator + sibling.getName());
                            break;
                        }
                    }
                }
            } else {
                correctedPath.insert(0, current.getName());
            }
            current = parent;
        }

        return correctedPath.toString();
    }


    /**
     * Validates if a given filename conforms to the rules of FAT32 filenames.
     * FAT32 filenames must adhere to specific restrictions such as length, allowed
     * characters, and cannot start or end with a dot or space.
     *
     * @param name The filename to validate.
     * @return True if the filename is valid, according to FAT32 rules; false otherwise.
     */
    public static boolean isValidFat32Name(String name) {
        // Regular expression to validate FAT32 filenames
        Pattern FAT32_VALID_NAME_PATTERN = Pattern.compile(
                "^(?![.\\-\\s])" +      // Cannot start with a dot, hyphen, or space
                        "[a-zA-Z0-9._-]+" + // Only English letters, digits, underscores, dots, and hyphens
                        "(?<![.\\-\\s])$"  // Cannot end with a dot, hyphen, or space
        );
        // FAT32 filenames are limited to 255 characters and cannot contain invalid characters.
        if (name == null || name.trim().isEmpty() || name.length() > 99) {
            return false;
        }
        return FAT32_VALID_NAME_PATTERN.matcher(name).matches();
    }


    /**
     * Verifies if the file is older than the specified number of hours.
     *
     * @param filePath Path to the file
     * @param hours    the number of hours to compare
     * @return true if the file is older than the specified hours, false otherwise.
     */
    public static boolean isFileOlderThan(String filePath, int hours) {
        File file = new File(filePath);
        long lastModified = file.lastModified();
        if (lastModified == 0L) {
            // File does not exist or the timestamp is invalid
            return false;
        }
        long now = System.currentTimeMillis();
        long diffMillis = now - lastModified;
        long thresholdMillis = hours * 3600_000L;
        return diffMillis > thresholdMillis;
    }


    /**
     * Get version.
     */
    public static String getVersion() {
        try (InputStream manifestStream = Utility.class.getResourceAsStream("/META-INF/MANIFEST.MF")) {
            if (manifestStream != null) {
                Manifest manifest = new Manifest(manifestStream);
                Attributes attributes = manifest.getMainAttributes();
                return attributes.getValue("Implementation-Version");
            }
        } catch (Exception ignored) {
        }
        return "Unknown";
    }

    public static String getMountPoint(String partUUID) {
        Output pathOutput = getTextFromCommand("findmnt -no TARGET -S PARTUUID=" + partUUID, false, false);
        if (pathOutput.isSuccess()) {
            return pathOutput.text().get(0);
        } else {
            return "";
        }
    }


    public static String getMountPointIfFat32(String filePath) {
        Path realPath = new File(filePath).getAbsoluteFile().toPath().normalize();
        File mountFile = new File("/proc/mounts");

        if (!mountFile.exists()) {
            return "";
        }

        try (Stream<String> lines = Files.lines(mountFile.toPath())) {
            for (String line : (Iterable<String>) lines::iterator) {
                String[] parts = line.split(" ");
                if (parts.length < 3) continue;

                String mountPoint = parts[1];
                String fsType = parts[2];

                if (realPath.startsWith(Paths.get(mountPoint)) && "vfat".equalsIgnoreCase(fsType)) {
                    return mountPoint;
                }
            }
        } catch (IOException ignored) {
        }
        return "";
    }


    public static String removeSurroundingSlashes(String path) {
        if (path == null || path.isEmpty()) {
            return path;
        }
        return path.replaceAll("^/+", "").replaceAll("/+$", "").trim();
    }


    /**
     * Get partition UUID of the mount point
     *
     * @param mountPoint It is the mount path.
     * @return partition UUID.
     */
    public static String getPartitionUUID(String mountPoint) {
        Output uuidOutput = getTextFromCommand("findmnt -no PARTUUID --mountpoint " + mountPoint, true, true);
        if (uuidOutput.isSuccess()) {
            return uuidOutput.text().get(0);
        } else {
            return "";
        }
    }
}
