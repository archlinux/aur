package org.limine.entry.tool;

import org.limine.entry.tool.objects.*;
import org.limine.entry.tool.processes.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Main {

    public static void main(String[] args) throws IOException {
        // First, parse flags (e.g., --quiet, --help, --version) and store them
        List<String> remainingArgs = new ArrayList<>();
        String comment = "";
        EntryOptions entryOptions = new EntryOptions();
        boolean isArgComment = false, isArgPriority = false;
        for (String arg : args) {
            if (isArgComment) {
                if (arg.startsWith("--")) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                } else {
                    comment = arg;
                    isArgComment = false; //Reset
                    continue;
                }
            }
            if (isArgPriority) {
                if (entryOptions.parseArg(arg, EntryOptions.Key.ORDER_PRIORITY)) {
                    isArgPriority = false; //Reset
                    continue;
                } else {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
            }
            switch (arg) {
                case "--quiet":
                    Config.ENABLE_PRINT = false;
                    break;
                case "--help":
                    printHelp();
                    return;
                case "--version":
                    System.out.println(ConsoleColor.GREEN + Utility.getVersion() + ConsoleColor.RED);
                    return;
                case "--comment":
                    isArgComment = true;
                    break;
                case "--priority":
                    isArgPriority = true;
                    break;
                case "--overwrite":
                    entryOptions.setEntryOverwrite(true);
                    break;
                default:
                    remainingArgs.add(arg);
                    break;
            }
        }

        // Now, process the main command (first element of remainingArgs)
        if (remainingArgs.isEmpty()) {
            System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
            printHelp();
            return;
        }

        String command = remainingArgs.get(0);
        String kernelName;

        switch (command) {
            case "--add":
                if (remainingArgs.size() < 4) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                String initramfsPath = remainingArgs.get(2);
                String vmlinuzPath = remainingArgs.get(3);
                String suffixName = remainingArgs.size() == 5 ? remainingArgs.get(4) : "";
                add(kernelName, comment, entryOptions, initramfsPath, vmlinuzPath, suffixName);
                return;

            case "--add-uki":
                if (remainingArgs.size() < 3) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                String ukiPath = remainingArgs.get(2);
                addUki(kernelName, comment, entryOptions, ukiPath);
                return;

            case "--add-efi":
                if (remainingArgs.size() < 3) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String efiName = remainingArgs.get(1);
                String efiPath = remainingArgs.get(2);
                addEfi(efiName, comment, entryOptions, efiPath);
                return;

            case "--remove":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                remove(kernelName, false);
                return;

            case "--remove-uki":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                remove(kernelName, true);
                return;

            case "--remove-entry":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                removeEntry(kernelName);
                return;

            case "--remove-efi":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String filePath = remainingArgs.get(1);
                removeEfi(filePath);
                return;

            case "--remove-os":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String osNameOrMachineID = remainingArgs.get(1);
                removeOs(osNameOrMachineID);
                return;

            case "--remove-all":
                List<String> kernelNames = remainingArgs.stream().filter(arg -> !arg.startsWith("--")).toList();
                removeAll(kernelNames);
                return;

            case "--scan":
                scanEfiEntries();
                return;
            case "--get-cmdline":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                ConfigReader configReader = new ConfigReader();
                Config config = configReader.readConfig();
                System.out.println(config.getKernelCmdline(kernelName));
                return;
            default:
                System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                printHelp();
        }
    }

    private static void printHelp() {
        System.out.println("""
                Usage: limine-entry-tool [option] [--quiet]
                Options:
                       --add [kernel entry name] [path to initramfs] [path to vmlinuz] [any suffix name] --comment [any comment]
                       --add-uki [kernel entry name] [path to UKI file] --comment [any comment]
                       --add-efi [OS entry name] [path to EFI binary] --comment [any comment] --priority [number] --overwrite
                       --get-cmdline [kernel name]
                       --remove [kernel directory name]
                       --remove-uki [kernel file name]
                       --remove-entry [kernel entry name]
                       --remove-all [kernel name 1] [kernel name 2] [kernel name 3] ...
                       --remove-efi [path] : Remove an EFI boot entry that matches a specified bootable file path.
                       --remove-os [machine-ID or name] : Remove an OS entry matching a given machine-ID or OS name.
                       --scan : Scans available EFI entries for selection.
                       --version
                """);
    }

    private static void add(String kernelName, String comment, EntryOptions kernelEntryOptions, String initramfsPath, String vmlinuzPath, String suffixName) throws IOException {
        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            String errMassage = "Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.";
            System.err.println(ConsoleColor.RED_BOLD + errMassage + ConsoleColor.RESET);
            Utility.loggerSend(errMassage, LogLevel.ERROR);
            System.exit(1);
            return;
        }
        kernelName = kernelName.trim();
        suffixName = suffixName.trim();
        comment = comment.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limineReader = new LimineReader(config);
        LimineController limineController = new LimineController(limineReader.getTargetOsNode(), config);
        limineController.add(kernelName, comment, kernelEntryOptions, initramfsPath, vmlinuzPath, suffixName);

        // Save
        if (limineController.isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    private static void addUki(String kernelName, String comment, EntryOptions kernelEntryOptions, String ukiFilePath) throws IOException {
        if (!Utility.isSystemAmd64()) {
            String errMessage = "Your system is not using x86_64 architecture";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
        }
        if (!Utility.isSystemEfi()) {
            String errMessage = "Your system is not using EFI mode";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
        }

        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            String errMessage = "Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
            return;
        }
        kernelName = kernelName.trim();
        comment = comment.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limineReader = new LimineReader(config);
        LimineController limineController = new LimineController(limineReader.getTargetOsNode(), config);
        limineController.addUki(kernelName, comment, kernelEntryOptions, ukiFilePath);

        // Save
        if (limineController.isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    private static void addEfi(String efiName, String comment, EntryOptions kernelEntryOptions, String efiFilePath) throws IOException {
        if (!Utility.isSystemAmd64()) {
            String errMessage = "Your system is not using x86_64 architecture";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
        }
        if (!Utility.isSystemEfi()) {
            String errMessage = "Your system is not using EFI mode";
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
        }

        efiName = efiName.trim();
        comment = comment.trim();
        efiFilePath = efiFilePath.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limineReader = new LimineReader(config);
        boolean isUpdateNeeded = LimineController.merge(limineReader.getRootNode(), efiName, comment, kernelEntryOptions, efiFilePath, config);

        // Save
        if (isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }


    private static void remove(String kernelName, boolean isUKI) throws IOException {
        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            String errMassage = "Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.";
            System.err.println(ConsoleColor.RED_BOLD + errMassage + ConsoleColor.RESET);
            Utility.loggerSend(errMassage, LogLevel.ERROR);
            System.exit(1);
            return;
        }

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limineReader = new LimineReader(config);
        LimineController limineController = new LimineController(limineReader.getTargetOsNode(), config);
        limineController.remove(kernelName.trim(), isUKI);

        // Save
        if (limineController.isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    /**
     * Remove only a boot entry without removing kernel files
     */
    private static void removeEntry(String kernelName) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limineReader = new LimineReader(config);
        LimineController limineController = new LimineController(limineReader.getTargetOsNode(), config);
        limineController.removeEntry(kernelName.trim());

        // Save
        if (limineController.isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    private static void removeAll(List<String> kernelNames) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        LimineReader limineReader = new LimineReader(config);
        LimineController limineController = new LimineController(limineReader.getTargetOsNode(), config);
        for (String kernelName : kernelNames) {
            limineController.remove(kernelName.trim(), true);
            limineController.remove(kernelName.trim(), false);
        }
        // Save
        if (limineController.isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    /**
     * Remove an EFI boot entry
     */
    private static void removeEfi(String efiFilePath) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limineReader = new LimineReader(config);
        boolean isUpdateNeeded = LimineController.removeEfi(limineReader.getRootNode(), efiFilePath, config);
        // Save
        if (isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    /**
     * Remove an OS entry
     */
    private static void removeOs(String osNameOrMachineID) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limineReader = new LimineReader(config);
        boolean isUpdateNeeded = LimineController.removeOs(limineReader.getRootNode(), osNameOrMachineID, config);
        // Save
        if (isUpdateNeeded) {
            LimineWriter limineWriter = new LimineWriter(config);
            limineWriter.backup();
            limineWriter.save(limineReader.getRootNode());
        }
    }

    private static void scanEfiEntries() throws IOException {
        EfiBootEntry selectedEntry = EfiScanner.showEfiEntriesAndSelect();
        if (selectedEntry != null) {
            Config.ENABLE_PRINT = false;
            System.out.println(ConsoleColor.GREEN_BOLD + "EFI entry added to Limine: " + ConsoleColor.RESET + "\"" + selectedEntry.name() + "\", guid(" + selectedEntry.gptUuid() + "):" + selectedEntry.efiPath());
            EntryOptions options = new EntryOptions().setPriority(20).setEntryOverwrite(true);
            String mountPoint = Utility.getMountPoint(selectedEntry.gptUuid());
            if (mountPoint.isEmpty()) {
                String tempMountPoint = "/run/let";
                Utility.ensureDirectoryExists(tempMountPoint);
                Utility.runCommand("mount /dev/disk/by-partuuid/" + selectedEntry.gptUuid() + " " + tempMountPoint, false, true);
                addEfi(selectedEntry.name(), selectedEntry.name(), options, tempMountPoint + selectedEntry.efiPath());
                Utility.runCommand("umount " + tempMountPoint, false, true);
            } else {
                addEfi(selectedEntry.name(), selectedEntry.name(), options, mountPoint + selectedEntry.efiPath());
            }
        }
    }
}