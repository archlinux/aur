package org.limine.entry.tool.objects;


import java.util.Map;

public record Config(String machineID, String targetOs, String espPath, Map<String, String> kernelCmdlineMap,
                     String pathResource) {

    public static final String HASH_COMMAND_LINE = "b2sum --binary";
    public static final String DEFAULT_CONFIG_FILE_PATH = "/etc/default/limine";
    public static final String[] CONFIG_FILE_PATHS = {"/etc/limine-entry-tool.conf", DEFAULT_CONFIG_FILE_PATH};
    public static final String LIMINE_CONFIG_FILE = "limine.conf";
    public static final String UKI_FILE_SUFFIX = ".efi";
    public static final String DEFAULT_UKI_DIR_PATH = "EFI/Linux";
    public static final String BACKUP_SUFFIX = ".old";
    public static final int DEFAULT_ORDER_PRIORITY_VALUE = 50;
    public static final boolean DEFAULT_CMDLINE_OVERWRITE = true;
    public static final boolean DEFAULT_ENTRY_OVERWRITE = false;
    public static boolean ENABLE_OS_GENERATION = true;
    public static int BACKUP_THRESHOLD = 8;
    public static String SPACES = "  ";
    public static boolean ENABLE_VERIFICATION = false;
    public static boolean ENABLE_PRINT = true;
    public static String[] BOOT_ORDER = {"*", "*fallback", "Snapshots"};
    public static boolean ENABLE_SORT = false;

    public String getKernelCmdline(String key) {
        String cmdline = kernelCmdlineMap.get(key);

        if ((cmdline == null || cmdline.isBlank()) && key.contains("fallback")) {
            cmdline = kernelCmdlineMap.get("fallback");
        }

        if (cmdline == null || cmdline.isBlank()) {
            cmdline = kernelCmdlineMap.get("default");
        }

        // This is compatible with KERNEL_CMDLINE without an array from the bash shell.
        if (cmdline == null || cmdline.isBlank()) {
            cmdline = kernelCmdlineMap.get("0");
        }
        return cmdline;
    }
}
