package org.limine.entry.tool.processes;

import org.limine.entry.tool.formats.limine8.LimineKey;
import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.ConsoleColor;
import org.limine.entry.tool.objects.LogLevel;
import org.limine.entry.tool.objects.Output;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class ConfigReader {

    private final Properties properties;

    public ConfigReader() {
        this.properties = loadConfigFiles();
        // Set environment variables into properties
        //System.getenv().forEach(this.properties::setProperty);
    }

    private Properties loadConfigFiles() {
        Properties properties = new Properties();
        for (String configFilePath : Config.CONFIG_FILE_PATHS) {
            if (Utility.isFilePresent(configFilePath)) {
                try (FileInputStream fileInputStream = new FileInputStream(configFilePath)) {
                    properties.load(fileInputStream);
                } catch (IOException e) {
                    System.err.println(ConsoleColor.RED_BOLD + "Failed to load config file: " + ConsoleColor.RESET + configFilePath + " due to " + e.getMessage());
                    Utility.loggerSend("Failed to load config file: " + configFilePath + " due to " + e.getMessage(), LogLevel.ERROR);
                    System.exit(1);
                    return null;
                }
            }
        }
        properties.forEach((key, value) -> {
            if (value instanceof String stringValue) {
                String trimmedValue = stringValue.replaceAll("\"", "").trim();
                properties.setProperty((String) key, trimmedValue);
            }
        });
        return properties;
    }

    private Map<String, String> parseKernelCmdline(Properties properties) {
        Map<String, String> kernelCmdlineMap = new HashMap<>();
        properties.forEach((key, value) -> {
            String keyString = key.toString();
            String valueString = value.toString();

            // Handle "KERNEL_CMDLINE" single value
            if (keyString.equals("KERNEL_CMDLINE")) {
                kernelCmdlineMap.put("0", valueString);
            }
            // Handle mapped syntax: KERNEL_CMDLINE[key]
            else if (keyString.startsWith("KERNEL_CMDLINE[") && keyString.contains("]")) {
                // Safely extract the key between [ and ]
                int startIdx = keyString.indexOf('[') + 1;
                int endIdx = keyString.indexOf(']');
                if (startIdx > 0 && endIdx > startIdx) { // Ensure valid range
                    String extractedKey = keyString.substring(startIdx, endIdx).replaceAll("\"", ""); // Remove quotes from key
                    kernelCmdlineMap.put(extractedKey, valueString);
                }
            }
        });

        String defaultValue = kernelCmdlineMap.get("default");
        if (defaultValue == null || defaultValue.isBlank()) {
            defaultValue = kernelCmdlineMap.get("0");
        }
        if (defaultValue == null || defaultValue.isBlank()) {
            kernelCmdlineMap.put("default", Utility.readKernelCmdline());
        }
        return kernelCmdlineMap;
    }

    public Config readConfig() {

        String targetOs = properties.getProperty("TARGET_OS_NAME");
        if (targetOs == null || targetOs.isBlank()) {
            targetOs = Utility.getLinuxDistroName();
        } else {
            targetOs = Utility.cleanName(targetOs);
        }

        Map<String, String> kernelCmdlineMap = this.parseKernelCmdline(properties);

        String espPath = properties.getProperty("ESP_PATH");
        if (espPath == null || espPath.isBlank()) {
            if (Utility.isSystemEfi() && Utility.isCommandPresent("bootctl")) {
                Output output = Utility.getTextFromCommand("bootctl --print-esp-path", false, false);
                if (output.isSuccess()) {
                    espPath = output.text().get(0);
                }
            }
        }
        if (espPath == null || espPath.isBlank()) {
            String errMessage = "No ESP_PATH. Please set ESP_PATH in " + Config.DEFAULT_CONFIG_FILE_PATH;
            System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
            Utility.loggerSend(errMessage, LogLevel.ERROR);
            System.exit(1);
            return null;
        } else {
            espPath = Utility.buildPath(espPath);

            // Verify boot path if it uses vfat.
            if (!Utility.validateFatPartition(espPath)) {
                String errMessage = "Incorrect config: \"" + espPath + "\" is not an ESP path. Please correct the config " + Config.DEFAULT_CONFIG_FILE_PATH + " to set your value in ESP_PATH.";
                System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
                Utility.loggerSend(errMessage, LogLevel.ERROR);
                System.exit(1);
                return null;
            }
        }

        String spaceNumber = properties.getProperty("SPACE_NUMBER");
        if (spaceNumber != null) {
            try {
                int number = Integer.parseInt(spaceNumber);
                StringBuilder spaces = new StringBuilder();
                while (number > 0) {
                    spaces.append(" ");
                    number--;
                }
                Config.SPACES = spaces.toString();
            } catch (NumberFormatException ignored) {
                String errMessage = "Value of SPACE_NUMBER should be a number and not a word!";
                System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
                Utility.loggerSend(errMessage, LogLevel.ERROR);
            }
        }

        String enableVerification = properties.getProperty("ENABLE_VERIFICATION");
        if (enableVerification != null) {
            Config.ENABLE_VERIFICATION = "yes".equalsIgnoreCase(enableVerification);
        }

        String backupThreshold = properties.getProperty("BACKUP_THRESHOLD");
        if (backupThreshold != null) {
            try {
                Config.BACKUP_THRESHOLD = Integer.parseInt(backupThreshold);
            } catch (NumberFormatException e) {
                String errMessage = "BACKUP_THRESHOLD '" + backupThreshold + "' is invalid, it should be in hours format.";
                System.err.println(ConsoleColor.RED_BOLD + errMessage + ConsoleColor.RESET);
                Utility.loggerSend(errMessage, LogLevel.ERROR);
            }
        }

        String bootOrder = properties.getProperty("BOOT_ORDER");
        if (bootOrder != null) {
            if (!bootOrder.isBlank()) {
                Config.BOOT_ORDER = Arrays.stream(bootOrder.split(",")).map(String::trim).toArray(String[]::new);
            }
        }

        String enableSort = properties.getProperty("ENABLE_SORT");
        if (enableSort != null) {
            if ("yes".equalsIgnoreCase(enableSort)) {
                Config.ENABLE_SORT = true;
            }
        }

        String pathResource = LimineKey.PATH_RESOURCE.toString();
        return new Config(Utility.readMachineID(), targetOs, espPath, kernelCmdlineMap, pathResource);
    }

}
