#!/usr/bin/env python3
from blockify.gui import main
main()
