import tkinter as tk
from tkinter import *
from tkinter import messagebox
import json
import os
import shutil
class Debag():
    def __init__(self, root):
        self.root = root
        self.root.title("Debugger")
        self.root.geometry("900x600")
        self.buttons()
    def buttons(self):
        btn_qt6 = tk.Button(root, text="Install pyqt6", command=self.installpq6)
        btn_qt6.pack()

        btn_qt6webrngine = tk.Button(root, text="Install pyqt6-webengine", command=self.installpq6_webengine)
        btn_qt6webrngine.pack()

        btn_qt6pac = tk.Button(root, text="Install pyqt6 for arch", command=self.installpq6_arch)
        btn_qt6pac.pack()

        btn_qt6webenginepac = tk.Button(root, text="Install pyqt6-webengine for arch", command=self.installpq6webengine_arch)
        btn_qt6webenginepac.pack()

        btn_qt6apt = tk.Button(root, text="Install pyqt6 for ubuntu", command=self.installpq6_ubuntu)
        btn_qt6apt.pack()

        btn_qt6webengineapt = tk.Button(root, text="Install pyqt6-webengine for ubuntu", command=self.installpq6webengine_ubuntu)
        btn_qt6webengineapt.pack()

        btn_qt6dnf = tk.Button(root, text="Install pyqt6 for fedora", command=self.installpq6_fedora)
        btn_qt6dnf.pack()

        btn_qt6webenginednf = tk.Button(root, text="Install pyqt6-webengine for fedora", command=self.installpq6webengine_fedora)
        btn_qt6webenginednf.pack()

        btn_redactsettings = tk.Button(root, text="Delete settings", command=self.delete_settings)
        btn_redactsettings.pack()
    def installpq6(self):

        os.system("pip install pyqt6")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6 was installed" 
)
    def installpq6_webengine(self):
        os.system("pip install pyqt6-webengine")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6-webengine was installed" 
)
    def installpq6_arch(self):
        os.system("sudo pacman -S python-pyqt6")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6 was installed(arch)" 
)
    def installpq6webengine_arch(self):
        os.system("sudo pacman -S python-pyqt6-webengine")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6-webengine was installed(arch)" 
)
    def installpq6_ubuntu(self):
        os.system("sudo apt install python-pyqt6")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6 was installed(ubuntu)" 
)
    def installpq6webengine_ubuntu(self):
        os.system("sudo apt install python-pyqt6-webengine")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6-webengine was installed(ubuntu)" 
)
    def installpq6_fedora(self):
        os.system("sudo dnf install python-pyqt6")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6 was installed(fedora)" 
)
    def installpq6webengine_fedora(self):
        os.system("sudo dnf install python-pyqt6-webengine")
        messagebox.showinfo(
    "info",           
    "Good, pyqt6-webengine was installed(fedora)" 
)
    def delete_settings(self):
        os.system("rm -rf ~/.config/wolfbrowser")
        messagebox.showinfo(
    "info",           
    "Succesful, Settings deleted" 
)
if __name__ == "__main__":
    root = tk.Tk()
    app = Debag(root)
    root.mainloop()