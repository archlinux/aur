import os
import sys
from PyQt6.QtWidgets import QMessageBox
from moduls.settings.settingswindow import *
def gitcheckupdate(versionbrowser, parent=None):
    try:
        
        print("^o^")
    except Exception as e:
       print(f"Error {e}")
