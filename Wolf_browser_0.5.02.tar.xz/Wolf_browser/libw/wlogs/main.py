import sys
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from datetime import *
class LogWin(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WLogs")
        self.setGeometry(300, 300, 100, 100)
        self.logs = []
        self.logslayout()
        self.hotkeys()
    def hotkeys(self):
        from PyQt6.QtGui import QShortcut, QKeySequence
        exit_set = QShortcut(QKeySequence("Ctrl+q"), self)
        exit_set.activated.connect(lambda: self.close())     
    def logslayout(self):
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        self.layout = QVBoxLayout(self.central_widget)
        
        self.loglabel = QLabel()
        self.loglabel.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.layout.addWidget(self.loglabel)
    def addlog(self, namefromlogget, log):
        logtime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.logs.append(f"/{logtime}/[{namefromlogget}]: {log}")
        self.loglabel.setText("\n".join(self.logs))
