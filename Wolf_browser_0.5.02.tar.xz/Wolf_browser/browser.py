import sys 
#import argparse
import importlib.util
import os
import json
from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtWebEngineWidgets import *
from PyQt6.QtWebEngineCore import *
from PyQt6.QtGui import *   
from moduls.settings.loader_settings import *
read_region_settings(None)
from moduls.settings.settingswindow import *
from moduls.misc.adblocker import AdBlockerInterceptor
from moduls.misc.savehistory import read_browser_settings, save_to_history
from moduls.misc.downloaddialog import *
from moduls.helpers.information import *
from moduls.misc.historywindow import *
from moduls.misc.hotkeys import *  
from moduls.misc.navigationbar import *
from moduls.helpers.settingshelp import *
from checkers.checkupdates import *
from regions.getlng import languche_change
from libw.wlogs.main import LogWin
font_on = 0
font = QFont("JetBrains Mono", 12)
#font = QFont()
__version__ = "0.5.02"
class MainBrowser(QMainWindow):
    def __init__(self):
        self.log_win = LogWin()##logs
        self.log_win.hide()##logs
        self.ver = __version__   
        gitcheckupdate(self.ver)
        super().__init__()
        self.log_win.addlog("BROWSER", "START INIT")
        self.download_folder = ""
        self.download_enabled = False
        self.load_download_settings()
        languche_change(self)
        self.setWindowTitle("Wolf browser - private surf")
        read_customize_size(self)
        sizehbreak = int(self.sizeh115)
        sizewbreak = int(self.sizew115)
        self.setGeometry(100, 100, sizewbreak, sizehbreak)
        self.setWindowIcon(QIcon("programicons/icon.png"))
        self.statusBar().showMessage("Ready", 2000)
        self.settings_window = SettingsWindow(self.log_win)
        self.importmetods()
        self.error_404_html = self.load_html_page("404.html")
        self.offline_html = self.load_html_page("offline.html")
        read_cryptohistory(self)
    def importmetods(self):
        read_main_settings(self)
        read_coloricons(self)
        read_allow_open_new_tab_tab(self)
        self.tabs = QTabWidget()
        self.url_bar = QLineEdit()
        self.tabs.setTabsClosable(True)
        #self.coloricons = "white"
        if self.coloricons == "white":
            self.tabs.setStyleSheet("""
            QTabBar::close-button {
                image: url(icons/white/x(red).svg);  
                subcontrol-position: right;
                margin-right: 5px;
                width: 16px;
                height: 16px;
            }
            QTabBar::close-button:hover {
                image: url(icons/white/x.svg);  
                background-color: #ff4444;
                border-radius: 4px;
            }
        """)#1.Standart 2.NotStandart
        elif self.coloricons == "black":
            self.tabs.setStyleSheet("""
            QTabBar::close-button {
                image: url(icons/black/x(red).svg);  
                subcontrol-position: right;
                margin-right: 5px;
                width: 16px;
                height: 16px;
            }
            QTabBar::close-button:hover {
                image: url(icons/black/x.svg);  
                background-color: #ff4444;
                border-radius: 4px;
            }
        """)#1.Standart 2.NotStandart
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.tab_changed)
        self.setCentralWidget(self.tabs)
        read_settings_privatepage_proxy(self)
        self.statusBar().showMessage("Ready", 2000)
        self.linew = "200" 
        self.lineh = "16" 
        read_settings_custompage_razmerbootline(self)  
        #
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedWidth(int(self.linew))  
        self.progress_bar.setFixedHeight(int(self.lineh)) 
        self.progress_bar.setMaximumWidth(150)
        self.progress_bar.setVisible(False)
        self.progress_bar.setFormat("%p%")
        self.progress_bar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        #self.progress_bar.setStyleSheet("""
        #    border: 1px solid #5a5a5a;
        #    border-radius: 4px;
        #    text-align: center;
        #    color: white;
        #    font-weight: bold;
        #    background-color: #2d2d2d;
        #}
        #QProgressBar::chunk {
        #    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        #                               stop:0 #7c3aed,    /* фиолетовый */
        #                               stop:0.3 #2563eb,  /* синий */
        #                               stop:0.6 #16a34a,  /* зеленый */
        #                               stop:1 #eab308);   /* желтый */
        #    border-radius: 3px;
        #}
    #""")
        read_settings_custompage_colors(self) 
        self.statusBar().addPermanentWidget(self.progress_bar)  #addPermanentWidget = справа
        #
        read_priv777_settings(self)
        self.new_tab()
        read_cui_button(self)
        read_pomogashka(self)
        nav_bar(self)
        read_settings_blockerpage_cookie(self)  
        read_settings_blockerpage_javascreept(self)
        read_settings_blockerpage_addblocker(self)
        read_browser_settings(self)
        profile = QWebEngineProfile.defaultProfile()
        profile.downloadRequested.connect(self.handle_download)
        read_hotkeys_settings(self)
        hotkey(self)
        self.log_win.addlog("BROWSER", "FINISH INIT")
    def url_line(self):
        url = self.url_bar.text().strip()
        if url:
            if url.startswith("file://"):###LOCALE
                pass###LOCALE
            elif not url.startswith("http://") and not url.startswith("https://"):
                url = "https://" + url
            web_view = self.get_current_webview()
            if web_view:
                web_view.setUrl(QUrl(url))
            else:
                print("No active web view to load URL")  
                self.log_win.addlog("NE", "NO ACTIVE WEBVIEW TO LOAD URL")
    def update_urlbar(self, qurl, web_view=None):
        url_string = qurl.toString()
        print(f"URL changed to: {url_string}")
        self.statusBar().showMessage(f"Url changed to: {url_string}", 3000)
        self.log_win.addlog("WEBENGINE", f"URL CHANGED TO: {url_string}")
        if self.url_bar.text() != url_string:
            self.url_bar.setText(url_string)
        self.url_bar.setCursorPosition(0)
    def home(self):
        web_view = self.get_current_webview()
        if web_view:
            web_view.setUrl(QUrl(f"{self.homepage}"))
    def get_current_webview(self):
        current_index = self.tabs.currentIndex()
        if current_index >= 0:
            return self.tabs.widget(current_index)
        return None

    def navigate_back(self):
        web_view = self.get_current_webview()
        if web_view:
            web_view.back()
            self.log_win.addlog("WEBENGINE", "PAGE BACK")

    def navigate_forward(self):
        web_view = self.get_current_webview()
        if web_view:
            web_view.forward()
            self.log_win.addlog("WEBENGINE", "PAGE FORWARD")

    def reload_page(self):
        web_view = self.get_current_webview()
        if web_view:
            web_view.reload()  
            self.log_win.addlog("WEBENGINE", "PAGE RELOAD")  
    def open_settings(self):
        self.settings_window.show()
        self.settings_window.raise_()
        self.settings_window.activateWindow()
        self.log_win.addlog("BROWSER", "OPEN SETTINGS WINDOW")
    def open_info(self):
        self.info_window = InfoWindowF1()  
        self.info_window.show()
        self.log_win.addlog("BROWSER", "OPEN INFO WINDOW")
    def new_tab(self, url=None):
        if url is None:
            url = self.search_system 
        web_view = QWebEngineView()
        if self.onfixsizewebviev == 1:
            web_view.setFixedSize(self.sizehwebview, self.sizewwebview)###<<<---
        else:
            pass
        self.log_win.addlog("BROWSER&WEBENGINE", "NEWTAB")

###########################
        def handle_new_window(req):
            new_url = req.requestedUrl().toString()
            self.create_new_tab_for_page(new_url)
        if self.allowcrtnewtabtab == 1:
            web_view.page().newWindowRequested.connect(handle_new_window)
        else:
            pass
###########################

        web_view.page().loadFinished.connect(
            lambda ok, wv=web_view: self.check_page_error(ok, wv))
        web_view.setUrl(QUrl(url))
        web_view.urlChanged.connect(lambda qurl, wv=web_view: self.update_urlbar(qurl, wv))
        web_view.titleChanged.connect(lambda title, wv=web_view: self.update_title(title, wv))
        web_view.loadProgress.connect(lambda progress, wv=web_view: self.show_progress(progress, wv))
        web_view.loadFinished.connect(lambda ok, wv=web_view: self.hide_progress(wv))
        index = self.tabs.addTab(web_view, "New tab")
        self.tabs.setCurrentIndex(index)
        return index
    def create_new_tab_for_page(self, url=None):
        web_view = QWebEngineView()
        if self.onfixsizewebviev == 1:
            web_view.setFixedSize(self.sizehwebview, self.sizewwebview)###<<<---
        else:
            pass
        def handle_new_window(req):
            new_url = req.requestedUrl().toString()
            self.create_new_tab_for_page(new_url)
        
        web_view.page().newWindowRequested.connect(handle_new_window)
        
        web_view.page().loadFinished.connect(
            lambda ok, wv=web_view: self.check_page_error(ok, wv))
        if url:
            web_view.setUrl(QUrl(url))
        web_view.urlChanged.connect(lambda qurl, wv=web_view: self.update_urlbar(qurl, wv))
        web_view.titleChanged.connect(lambda title, wv=web_view: self.update_title(title, wv))
        web_view.loadProgress.connect(lambda progress, wv=web_view: self.show_progress(progress, wv))
        web_view.loadFinished.connect(lambda ok, wv=web_view: self.hide_progress(wv))
        
        index = self.tabs.addTab(web_view, "New tab")
        self.tabs.setCurrentIndex(index)
        return web_view
    def close_tab(self, index):
        if self.tabs.count() > 1:
            self.tabs.removeTab(index)
            self.log_win.addlog("BROWSER&WEBENGINE", "CLOSETAB")
        else:
            self.close()
            self.log_win.addlog("BROWSER&WEBENGINE", "CLOSETAB AND EXIT")
    def tab_changed(self, index):
        if index >= 0:
            web_view = self.tabs.widget(index)
            if web_view:
                self.url_bar.setText(web_view.url().toString())
                self.log_win.addlog("BROWSER&WEBENGINE", "TAB CHANGED")
    def update_title(self, title, web_view):
        index = self.tabs.indexOf(web_view)
        if index != -1:
            short_title = title[:15] + "..." if len(title) > 15 else title
            self.tabs.setTabText(index, short_title)
            self.tabs.setTabToolTip(index, title) 
        url = web_view.url().toString()
        save_to_history(url, title)
    def close_current_tab(self):
    
        current_index = self.tabs.currentIndex()
        if current_index >= 0:
            self.close_tab(current_index)        
    
    def show_progress(self, progress, web_view):
        if web_view == self.get_current_webview():
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(progress)

    def hide_progress(self, web_view):
        if web_view == self.get_current_webview():
            self.progress_bar.setVisible(False)
            self.progress_bar.setValue(0)
    def update_progressbar_style(self):
        if self.progress_style == "gradient":
            style = """
            QProgressBar {
                border: 1px solid #5a5a5a;
                border-radius: 4px;
                text-align: center;
                color: white;
                font-weight: bold;
                background-color: #2d2d2d;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #7c3aed,
                                        stop:0.3 #2563eb,
                                        stop:0.6 #16a34a,
                                        stop:1 #eab308);
                border-radius: 3px;
            }
            """
        else:
            style = f"""
            QProgressBar {{
                border: 1px solid #5a5a5a;
                border-radius: 4px;
                text-align: center;
                color: white;
                font-weight: bold;
                background-color: #2d2d2d;
            }}
            QProgressBar::chunk {{
                background: {self.progress_color};
                border-radius: 3px;
            }}
            """
        
        self.progress_bar.setStyleSheet(style)  
    
    def open_from_history(self, item_text):
        import re
        urls = re.findall(r'https?://[^\s]+', item_text)
        if urls:
            self.new_tab(urls[0])

    def clear_history(self, dialog=None):
        try:
            filepath = Path.home() / ".config/wolfbrowser/history/history.json"
            if os.path.exists(filepath):
                os.remove(filepath)
            if dialog:
                dialog.close()
            QMessageBox.information(self, "Finished", "History clear")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error: {e}")
    def handle_download(self, download):
        if not self.download_enabled:
            download.cancel()
            self.statusBar().showMessage("You cant download", 3000)
            self.log_win.addlog("BROWSER&WEBENGINE", "CANT DOWNLOAD")
            return
        if self.download_folder:
            download.setDownloadDirectory(self.download_folder)
        dialog = SimpleDownloadDialog(download.suggestedFileName(), self)
        timer = QTimer()
        timer.timeout.connect(lambda: update_dialog())
        timer.start(500)
        def update_dialog():
            received = download.receivedBytes()
            total = download.totalBytes()
            dialog.update_progress(received, total)
            
            if download.isFinished():
                timer.stop()
                dialog.accept()
        download.accept()
        dialog.exec()
    def load_download_settings(self):
        try:
            from pathlib import Path
            filepath = Path.home() / ".config/wolfbrowser/settings/browser_settings.json"
            with open(filepath, "r") as f:
                settings = json.load(f)
                self.download_enabled = settings.get("ALLOWDOWNLOAD", False)
                self.download_folder = settings.get("FILEROADDOWNLOAD", "")
                print(f"Download: {self.download_enabled}, floader: {self.download_folder}")
        except Exception as e:
            self.download_enabled = False
            self.download_folder = ""
            print(f"Error {e}")
    def open_floader(self):
        import subprocess
        
        folder = self.download_folder if self.download_folder else os.path.expanduser("~/Downloads")
        
        if not os.path.exists(folder):
            QMessageBox.warning(self, "Error", f"Folder not found: {folder}")
            return
        
        try:
            subprocess.Popen(["xdg-open", folder])
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open folder: {e}")
    def check_page_error(self, ok, web_view):
        current_url = web_view.url().toString()
        if current_url == "about:blank" and ok:
            last_url = self.url_bar.text().strip()
            
            if last_url and last_url != "about:blank" and '.' in last_url:
                if not self.check_internet():
                    self.show_offline_page()
                    self.log_win.addlog("WEBENGINE", "SHOW OFLINE")
                else:
                    self.show_404_page()
                    self.log_win.addlog("WEBENGINE", "SHOW 404")
            return
        if not ok and not current_url.startswith("about:"):
            if not self.check_internet():
                self.show_offline_page()
                self.log_win.addlog("WEBENGINE", "SHOW OFLINE")
            else:
                if not self.download_enabled:
                    self.show_404_page()
                    self.log_win.addlog("WEBENGINE", "SHOW 404")
                elif self.download_enabled:
                    #self.show_download_page()
                    pass
    def check_internet(self):
        import socket
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
    def load_html_page(self, filename):
        try:
            page_path = os.path.join(os.path.dirname(__file__), "pages", filename)
            with open(page_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            print(f"Error loading {filename}: {e}")
            return None 
    def show_404_page(self):
        web_view = self.get_current_webview()
        if web_view and self.error_404_html:
            web_view.setHtml(self.error_404_html, QUrl("about:404"))
        else:
            print("404 page not loaded")
    def show_offline_page(self):
        web_view = self.get_current_webview()
        if web_view and self.offline_html:
            web_view.setHtml(self.offline_html, QUrl("about:000"))
        else:
            print("Offline page not loaded")
    def pomogashka_loader(self):
        text = self.pomogashka_line.text().strip()
        web_view = self.get_current_webview()
        if text == "":
            pass
        elif text == self.one_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.one_url))
        elif text == self.two_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.two_url))
        elif text == self.three_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.three_url))
        elif text == self.four_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.four_url))
        elif text == self.five_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.five_url))
        elif text == self.six_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.six_url))
        elif text == self.seven_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.seven_url))
        elif text == self.eight_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.eight_url))
        elif text == self.nine_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.nine_url))
        elif text == self.ten_cmd:
            if web_view:
                web_view.setUrl(QUrl(self.ten_url))
        else:
            pass
    def open_settingspref(self):
        self.set_window = SettingsHelperF2() 
        self.set_window.show()
    def show_download_page(self):
        web_view = self.get_current_webview()
        if web_view and self.download_html:
            web_view.setHtml(self.download_html, QUrl("about:download"))
        else:
            pass
            #print("Download page")
    def showlogwin(self):
        self.log_win.show()
        self.log_win.raise_()
if __name__ == "__main__":
    if "--version" in sys.argv:
        print(f"Wolf browser - {__version__}")
    elif "--debug" in sys.argv:
        os.system("python debug/debugger.py")
    else:
        os.system("clear")
        app = QApplication(sys.argv)
        if font_on == 1:
            app.setFont(font)
        else:
            pass
        browser = MainBrowser()
        browser.show()
        sys.exit(app.exec())        