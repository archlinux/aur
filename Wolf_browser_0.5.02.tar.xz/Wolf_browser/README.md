# Wolf Browser

**Power by int13h3**  
**Copyright (c) int13h3** 
**Version 0.4.15** 
**License: GPL 3.0**  
**Source codeberg:** https://codeberg.org/int13h3/Wolf_browser
**Source gitlab:** https://gitlab.com/int13h3/wolf_browser
