#Russian
###main
window_title = "Wolf browser - Настройки"
###main


###about layout
version_aboutlay = "Версия 0.4.15"
messgae_aboutlay = "Разработчик заботится о вашей анонимности!"
messgae1_aboutlay = "Your data is safe!"
lecense_aboutlay = "Lecence: GPL v3.0"
cbp_aboutlay = "Codeberg проект - https://codeberg.org/int13h3/Wolf_browser"
glp_aboutlay = "GitLab проект - https://gitlab.com/int13h3/wolf_browser"
tgcru_aboutlay = "Telegram канал рус - t.me/devlab404"
tgcen_aboutlay = "Telegram канал анг - t.me/devlab404eu"
###about layout


###1 layout
se_1lay = "Поисковая система"
hp_1lay = "Домашняя страница"
cusse_1lay = "Своя"
cushp_1lay = "Своя"
###1 layout


###2 layout
namepagebloc_2lay = "Блокировки"
pgb_2lay = "Блокировка страниц"
adbb_2lay = "Блокировка рекламы и трэкеров"
jsb_2lay = "Java-script блокировка"
mb_2lay = "Блокировка майнеров"
ckb_2lay = "Блокировка cookies"
###2 layout


###3 layout
namecustblock_3lay = "Кастомизация"
prgb_3lay = "Линия загрузки"
szprgb_3lay = "Размер линии загрузки"
lszprgb_3lay = "Length размер"
wszprgb_3lay = "Width размер"
colprgb_3lay = "Цвет линии загрузки"
c1g_3lay = "Зелёный"
c2r_3lay = "Красный"
c3y_3lay = "Жёлтый"
c4b_3lay = "Синий"
c5gr_3lay = "Градиент"
bws_3lay = "Размер окна браузера"
sws_3lay = "Размер окна настроек"
###3 layout


###ci layout
cstuititle_cilay = "Кастомизация интерфейса"
tbb_cilay = "Кнопки на инструмент баре"
sbb_cilay = "Отображать кнопку назад"
sfb_cilay = "Отображать кнопку вперёд"
sub_cilay = "Отображать кнопку обновить"
shb_cilay = "Отображать кнопку домой"
sdlb_cilay = "Отображать кнопку загрузочного листа"
sntb_cilay = "Отображать кнопку новой вкладки"
stb_cilay = "Отображать кнопку tor"
ssb_cilay = "Отображать кнопку настроек"
shisb_cilay = "Отображать кнопку истории"
sp_cilay = "Отображать помогашку"
ict_cilay = "Иконки"
bic_cilay = "Использовать чёрные иконки"
wic_cilay = "Использовать белые иконки"
addendum_cilay = "Дополнительно"
devmlo_cilay = "Режим разработчика(только Linux)"
###ci layout


###hotkeys layout
htitle_hlay = "Горячие клавиши"
ref_hlay = "Reference"
hsw_hlay = "Помошник настроек"
nt_hlay = "Новая вкладка"
ct_hlay = "Закрыть вкладку"
upd_hlay = "Обновить"
hp_hlay = "Домой"
e_hlay = "Выйти"
shis_hlay = "Открыть историю"
sset_hlay = "Открыть настройки"
logswin_hlay = "Открыть окно логов"
###hotkeys layout


###4 layout
byptitle_4lay = "Обход"
prox_4lay = "Прокси"
us5p_4lay = "Использовать SOCKS5 прокси"
proxadr_4lay = "Прокси адрес"
proxport_4lay = "Прокси порт"
###4 layout


###5 layout
bwes_5lay = "Настройки браузера"
up_5lay = "Пользовательские разрешения"
ahtbs_5lay = "Разрешить сохранение истории"
eh_5lay = "Шифровать историю(beta)"
ctdts_5lay = "Код для расшифровки(beta)"
aftbd_5lay = "Разрешить скачивание файлов"
over_5lay = "Обзор"
ascnt_5lay = "Разрешить вкладкам открывать новые вкладки(beta)"
l_5lay = "Язык(beta)"
###5 layout


###private777 lay
p_pr7lay = "Приватность"
chgwv_pr7lay = "Изменить размер web view(Рекомендовано - 1400x900)"
###private777 lay


###help layout
ps_helplay = "Настройка помогашки"
###help layout


###tool layout
tooltitle_tlay = "Инструменты"
osw_tlay = "Open status window"
###tool layout


###+++
sbbtn_alllay = "Сохранить"
###+++


###crt setbar
abouttextnametab = "О программе"
maintextnametab = "Основные"
blockertextnametab = "Блокировка"
castomizetextnametab = "Кастомизация"
customizeuitextnametab = "Кастомизация интерфейса"
hotkeystextnametab = "Горячие клавиши"
bypasstextnametab = "Обход"
browsersettingstextnametab = "Настройки браузера"
privatetextnametab = "Приватность"
pomogashkatextnametab = "Помогашка"
tooltextnametab = "Инструменты"
###crt setbar