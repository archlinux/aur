from moduls.settings.loader_settings import *

def languche_change(self):
    read_region_settings(self)
    if lngsetindextochangerx113 == "eu":
        print("eu")
    elif lngsetindextochangerx113 == "ru":
        print("ru")