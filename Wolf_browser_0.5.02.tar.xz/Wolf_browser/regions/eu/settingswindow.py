#English
###main
window_title = "Wolf browser - Settings"
###main


###about layout
version_aboutlay = "Version 0.4.15"
messgae_aboutlay = "The wolf browser team cares about your privacy and anonymity!"
messgae1_aboutlay = "Your data is safe!"
lecense_aboutlay = "Lecence: GPL v3.0"
cbp_aboutlay = "Codeberg project - https://codeberg.org/int13h3/Wolf_browser"
glp_aboutlay = "GitLab project - https://gitlab.com/int13h3/wolf_browser"
tgcru_aboutlay = "Telegram channal ru - t.me/devlab404"
tgcen_aboutlay = "Telegram channal en - t.me/devlab404eu"
###about layout


###1 layout
se_1lay = "Search Engine"
hp_1lay = "Home Page"
cusse_1lay = "Custom"
cushp_1lay = "Custom"
###1 layout


###2 layout
namepagebloc_2lay = "Blocker"
pgb_2lay = "Page blocker"
adbb_2lay = "Add blocker and tracker blocker"
jsb_2lay = "Java-script blocker"
mb_2lay = "Miner blocker"
ckb_2lay = "Cookies blocker"
###2 layout


###3 layout
namecustblock_3lay = "Customize"
prgb_3lay = "Progress bar"
szprgb_3lay = "Bar Progress Size"
lszprgb_3lay = "Length Size"
wszprgb_3lay = "Width Size"
colprgb_3lay = "Color Progress Bar"
c1g_3lay = "Green"
c2r_3lay = "Red"
c3y_3lay = "Yellow"
c4b_3lay = "Blue"
c5gr_3lay = "Gradient"
bws_3lay = "Browser window size"
sws_3lay = "Settings window size"
###3 layout


###ci layout
cstuititle_cilay = "Customize UI"
tbb_cilay = "Tool bar button"
sbb_cilay = "Show back button"
sfb_cilay = "Show forward button"
sub_cilay = "Show update button"
shb_cilay = "Show home button"
sdlb_cilay = "Show download list button"
sntb_cilay = "Show new tab button"
stb_cilay = "Show tor button"
ssb_cilay = "Show settings button"
shisb_cilay = "Show history button"
sp_cilay = "Show pomogashka"
ict_cilay = "Icons"
bic_cilay = "Use black icons pack"
wic_cilay = "Use white icons pack"
addendum_cilay = "Addendum"
devmlo_cilay = "Developer Mode(Linux only)"
###ci layout


###hotkeys layout
htitle_hlay = "Hotkeys"
ref_hlay = "Reference"
hsw_hlay = "Help settings window"
nt_hlay = "New tab"
ct_hlay = "Close tab"
upd_hlay = "Update"
hp_hlay = "Home page"
e_hlay = "Exit"
shis_hlay = "Show history"
sset_hlay = "Show settings"
logswin_hlay = "Open logs window"
###hotkeys layout


###4 layout
byptitle_4lay = "Bypass"
prox_4lay = "Proxy"
us5p_4lay = "Use SOCKS5 proxies"
proxadr_4lay = "Proxy address"
proxport_4lay = "Proxy Port"
###4 layout


###5 layout
bwes_5lay = "Browser web engine settings"
up_5lay = "User permissions"
ahtbs_5lay = "Allow history to be saved"
eh_5lay = "Encrypt history(beta)"
ctdts_5lay = "Code to decipher the story(beta)"
aftbd_5lay = "Allow filels to be downloaded"
over_5lay = "Overview"
ascnt_5lay = "Allow sites create new tabs(beta)"
l_5lay = "Languche(beta)"
###5 layout


###private777 lay
p_pr7lay = "Private"
chgwv_pr7lay = "Change webview size(Recomendate - 1400x900)"
###private777 lay


###help layout
ps_helplay = "Pomogashka settings"
###help layout


###tool layout
tooltitle_tlay = "Tool"
osw_tlay = "Open status window"
###tool layout


###+++
sbbtn_alllay = "Save"
###+++


###crt setbar
abouttextnametab = "About"
maintextnametab = "Main"
blockertextnametab = "Blocker"
castomizetextnametab = "Castomize"
customizeuitextnametab = "Customize UI"
hotkeystextnametab = "Hotkeys"
bypasstextnametab = "Bypass"
browsersettingstextnametab = "Browser settings"
privatetextnametab = "Private"
pomogashkatextnametab = "Pomogashka"
tooltextnametab = "Tool"
###crt setbar