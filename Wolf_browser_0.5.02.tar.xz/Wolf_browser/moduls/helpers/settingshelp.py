from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QLabel, QScrollArea, QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
import sys
from moduls.settings.loader_settings import *
class SettingsHelperF2(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Wolf browser - reference")
        self.setGeometry(300, 300, 400, 300)
        self.setWindowIcon(QIcon("programicons/icon.png"))
        self.layout()
        self.hotkeys()
    def hotkeys(self):
        from PyQt6.QtGui import QShortcut, QKeySequence
        exit_set = QShortcut(QKeySequence("Ctrl+q"), self)
        exit_set.activated.connect(lambda: self.close()) 
    def layout(self):
        self.settings_txt = """
About settings

Open settings by default Ctrl + j

Tabs:
    1.About
    2.Main
    3.Blocker
    4.Castomize
    5.Customize UI
    6.Hotkeys
    7.Private
    8.Browser settings
    9.Pomogashka
    10.Tool

Settings breakdown
    About tab
        Version information
        About developer
        License
    Main tab
        Search engine (available):
            DuckDuckGo
            Brave
            Custom
        Home page (available):
            DuckDuckGo
            Brave
            Custom
    Blocker tab
        Page blocking
        Ad and tracker blocking
        JavaScript blocker
        Miner blocking
        Cookie blocking
    Customize tab
        Progress bar size
            Width
            Height
        Progress bar color
            Green
            Red
            Yellow
            Blue
            Gradient
        Main window size
            Width
            Height
        Settings window size
            Width
            Height
    Customize UI tab
        Toolbar buttons display
            Back button
            Forward button
            Refresh button
            Home button
            Downloads button
            New tab button
            Settings button
            History button
            Help tool button
        Icons
            Black
            White
        Additional
            Developer mode (Linux only)
    Hotkeys tab
        Reference
        New tab
        Close tab
        Refresh
        Home page
        Exit program
        Open history
        Open settings
        Open logs window
    Private tab
        Proxy
            Use proxy
            Proxy address
            Proxy port
    Browser settings tab
        User permissions
            Allow saving history
            Encrypt history
            Encryption key
            Allow downloading files
            Download path
    Pomogashka tab
        Command
        Url
    Tool tab (Linux only)
        Open RAM consumption status window

If problems occur after changing settings:
    1. Close browser
    2. Open file manager
    3. Open browser folder
    4. Open settings folder
    5. Open desired section
"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.addWidget(QLabel(self.settings_txt))
        content_layout.addStretch()
        scroll_area.setWidget(content_widget)
        main_layout.addWidget(scroll_area)

