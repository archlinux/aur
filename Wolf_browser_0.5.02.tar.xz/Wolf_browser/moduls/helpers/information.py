from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QIcon
import os
from moduls.settings.loader_settings import *
class InfoWindowF1(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Wolf browser - reference")
        self.setGeometry(300, 300, 400, 300)
        self.setWindowIcon(QIcon("programicons/icon.png"))
        self.layout()
        self.hotkeys()
    def hotkeys(self):
        from PyQt6.QtGui import QShortcut, QKeySequence
        exit_set = QShortcut(QKeySequence("Ctrl+q"), self)
        exit_set.activated.connect(lambda: self.close()) 
    def layout(self):
        read_hotkeys_settings(self)
        newtab = self.newtabhotkeya113
        closetab = self.closetabhotkeya113
        update115 = self.updatetabhotkeya113
        home = self.homehotkeya113
        history_list = self.showhistoryhotkeya113
        settings = self.showsettingshotkeya113
        referaence = self.referencehotkeya113
        openhelpsettingswindow = self.opensettingswindowa113
        exithotkey115 = self.exithotkeya113
        openlogswindow115 = self.openlogwindowa113
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.addWidget(QLabel("Reference"))
        layout.addWidget(QLabel("=" * 50))
        layout.addWidget(QLabel("Hotkeys"))
        layout.addWidget(QLabel(f"{referaence} - reference"))
        layout.addWidget(QLabel(f"{newtab} - new tab"))
        layout.addWidget(QLabel(f"{closetab} - close tab"))
        layout.addWidget(QLabel(f"{update115} - update page"))
        layout.addWidget(QLabel(f"{home} - home page"))
        layout.addWidget(QLabel(f"{history_list} - history"))
        layout.addWidget(QLabel(f"{settings} - settings"))
        layout.addWidget(QLabel(f"{openhelpsettingswindow} - open help settings"))
        layout.addWidget(QLabel(f"{exithotkey115} - program exit"))
        layout.addWidget(QLabel(f"{openlogswindow115} - open log window"))
        layout.addWidget(QLabel("=" * 50))
        layout.addStretch()