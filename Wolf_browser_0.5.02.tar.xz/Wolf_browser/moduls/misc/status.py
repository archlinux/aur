import sys
import importlib.util
import os
from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtGui import *
import psutil
class StatusWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Wolf browser - status window")
        self.setGeometry(100, 100, 600, 400)
        self.setWindowIcon(QIcon("programicons/icon.png"))
        self.readram()
        self.text()
    def readram(self):
        os.system("ps aux | grep browser.py | grep -v grep > /tmp/process_info.txt")
        try:
            with open("/tmp/process_info.txt", "r") as f:
                line = f.readline()
                if line:
                    parts = line.split()
                    self.pid = parts[1]    
                    self.ram = parts[3]     
                else:
                    self.pid = "Not found"
                    self.ram = "0.0"
        except Exception as e:
            self.pid = "Error"
            self.ram = "0.0"
            print(f"Read error: {e}")
        finally:
            os.system("rm /tmp/process_info.txt")
    def text(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(10) 
        layout.setContentsMargins(20, 20, 20, 20)
        self.label = QLabel(f"RAM - {self.ram}%")
        self.label_pid = QLabel(f"PID = {self.pid}")
        update_btn = QPushButton("Update")
        update_btn.clicked.connect(self.update_info)
        layout.addWidget(self.label)
        layout.addWidget(self.label_pid)
        layout.addWidget(update_btn)
        layout.addStretch()
    def update_info(self):
        self.readram()
        self.label.setText(f"RAM - {self.ram}%")
        self.label_pid.setText(f"PID = {self.pid}")
    