from PyQt6.QtWebEngineCore import QWebEngineUrlRequestInterceptor, QWebEngineUrlRequestInfo
import requests
import re
import os
import json
import hashlib
from pathlib import Path
class AdBlockerInterceptor(QWebEngineUrlRequestInterceptor):
    def __init__(self):
        super().__init__()
        self.blocked_domains = set()
        filepath = Path.home() / ".cache/wolfbrowser/cache/adblock_cache.json"
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        self.cache_file = filepath
        self.load_cached_blocklist()
    
    def load_cached_blocklist(self):
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                import time
                cache_time = cache.get('timestamp', 0)
                current_time = time.time()
                if current_time - cache_time < 604800:
                    self.blocked_domains = set(cache.get('domains', []))
                    print(f"From cache loaded: {len(self.blocked_domains)} domens")
                    print(f"Data chache: {time.ctime(cache_time)}")
                    return
                else:
                    print("Cache is very old donwload new lists...")
                    
            except Exception as e:
                print(f"When programm read cache print error: {e}")
        self.download_and_cache_blocklist()
    
    def download_and_cache_blocklist(self):
        
        lists = [
            "https://raw.githubusercontent.com/0libote/Pi-Hole-Blocklist/main/Lists/All-in-One.txt",
            "https://raw.githubusercontent.com/blocklistproject/Lists/master/everything.txt",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        ]
        
        total_domains = set()
        
        for url in lists:
            try:
                print(f"Donwload blocklist: {url}")
                r = requests.get(url, timeout=30)
                
                for line in r.text.splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        parts = line.split()
                        if len(parts) == 2 and parts[0] in ["0.0.0.0", "127.0.0.1"]:
                            total_domains.add(parts[1].lower())
                        elif len(parts) == 1 and "." in parts[0]:
                            total_domains.add(parts[0].lower())
                            
                print(f"Donwloaded: {len(total_domains)} domens")
                
            except Exception as e:
                print(f"Donwload error {url}: {e}")
        try:
            import time
            cache_data = {
                'timestamp': time.time(),
                'domains': list(total_domains),
                'count': len(total_domains)
            }
            
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
            
            print(f"Cache was saved: {len(total_domains)} domens")
            
        except Exception as e:
            print(f"Error when programm saved chache: {e}")
        
        self.blocked_domains = total_domains
    
    def interceptRequest(self, info):
        url = info.requestUrl().host().toString().lower()
        
        # Быстрая проверка
        if url in self.blocked_domains:
            print(f"БЛОК: {url}")
            info.block(True)
            return