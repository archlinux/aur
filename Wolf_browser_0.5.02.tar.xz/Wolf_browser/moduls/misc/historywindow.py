import json
from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtWebEngineWidgets import *
from PyQt6.QtWebEngineCore import *
from PyQt6.QtGui import *
import os
from pathlib import Path
def show_history(window):
        try:
            filepath = Path.home() / ".config/wolfbrowser/history/history.json"
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    history = json.load(f)
            else:
                history = []
            if not history:
                QMessageBox.information(window, "History", "-")
                return
            dialog = QDialog(window)
            dialog.setWindowTitle("History")
            dialog.resize(600, 400)
            layout = QVBoxLayout()
            list_widget = QListWidget()
            from moduls import loader_settings 
            for item in reversed(history):
                display_url = item['url']
                if loader_settings.savehistorycrypto == 1 and not item['url'].startswith('http'):
                    try:
                        decrypted = xor_cipher(item['url'], "p1")
                        if decrypted.startswith('http'):
                            display_url = decrypted
                    except Exception as e:
                        print(f"Decryption error: {e}")
                display_title = item['title']
                if loader_settings.savehistorycrypto == 1:
                    try:
                        decrypted_title = xor_cipher(item['title'], "p1")
                        if any(c.isalpha() for c in decrypted_title): 
                            display_title = decrypted_title
                    except Exception as e:
                        print(f"Title decryption error: {e}")
                text = f"[{item['time']}] {display_title} — {display_url}"
                list_widget.addItem(text)
            list_widget.itemDoubleClicked.connect(
                lambda item: window.open_from_history(item.text()))
            layout.addWidget(list_widget)
            btn_clear = QPushButton("Clear history")
            btn_clear.clicked.connect(lambda: window.clear_history(dialog))
            layout.addWidget(btn_clear)
            dialog.setLayout(layout)
            dialog.exec()
        except Exception as e:
            QMessageBox.critical(window, "Error", f"Error: {e}")
def xor_cipher(text, password):
        result = []
        for i, char in enumerate(text):
            key_char = password[i % len(password)]
            result.append(chr(ord(char) ^ ord(key_char)))
        return ''.join(result)