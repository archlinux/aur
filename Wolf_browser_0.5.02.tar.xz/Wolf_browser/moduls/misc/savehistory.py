import json
import os
from datetime import datetime
import hashlib
from moduls.settings import loader_settings
from pathlib import Path
#Global
history_enabled = False
loader_settings.read_cryptohistory(None)
def read_browser_settings(self):
    try:
        filepath = Path.home() / ".config/wolfbrowser/settings/browser_settings.json" 
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            global history_enabled
            history_enabled = settings.get("SH", False)
            if history_enabled:
                print("History will be save")
            else:
                print("History off")
    except Exception as e:
        print(f"Error when load browser settings: {e}")
        history_enabled = False

def save_to_history(url, title): 
    global history_enabled
    if not history_enabled:
        return  
    try:
        filepath = Path.home() / ".config/wolfbrowser/history/history.json"
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        history_file = filepath
        history = []
        if os.path.exists(history_file):
            with open(history_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
        if loader_settings.savehistorycrypto == 1:
            text = url
            password = "p1"
            urlupdate = encrypted = xor_cipher(text, password)
            titleupdate = encrypted = xor_cipher(title, password)
            history.append({
                "url": urlupdate,
                "title": titleupdate,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        else:
            history.append({
                "url": url,
                "title": title,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        if len(history) > 1000:
            history = history[-1000:]
        
        #save
        print(f"{history} ---ihjfushfuehopiwujpodsioujfpuioejsiuopjf")
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
            
        print(f"Saved: {title}")
        
    except Exception as e:
        print(f"Error when program save history: {e}")
def xor_cipher(text, password):
    result = []
    for i, char in enumerate(text):
        key_char = password[i % len(password)]
        encrypted_char = chr(ord(char) ^ ord(key_char))
        result.append(encrypted_char)
    return ''.join(result)