from PyQt6.QtWidgets import *
from moduls.settings.loader_settings import *
from moduls.misc.historywindow import *
def nav_bar(self):
        bar = QToolBar("Navigation panel")
        self.addToolBar(bar)
        #back button
        #back_btn = QAction("<-", self)
        #back_btn.setStatusTip("You last page")
        #back_btn.triggered.connect(self.navigate_back) 
        #bar.addAction(back_btn)  
        if self.show_back_btn == 1:
            back_icon = QIcon(f"icons/{self.coloricons}/arrow-left.svg")
            back_btn = QAction(back_icon, "Back", self) 
            back_btn.setStatusTip("You last page")    
            back_btn.triggered.connect(self.navigate_back) 
            bar.addAction(back_btn)
        else:
            pass
        #forward button
        #forward_btn = QAction("->", self)
        #forward_btn.setStatusTip("You forward page")
        #forward_btn.triggered.connect(self.navigate_forward) 
        #bar.addAction(forward_btn) 
        if self.show_forward_btn == 1:
            forward_icon = QIcon(f"icons/{self.coloricons}/arrow-right.svg")
            forward_btn = QAction(forward_icon, "Forward", self) 
            forward_btn.setStatusTip("You forward page")    
            forward_btn.triggered.connect(self.navigate_forward) 
            bar.addAction(forward_btn)
        else:
            pass
        #update button(F5)
        #update_btn = QAction("Upd", self)
        #update_btn.setStatusTip("Update page")
        #update_btn.triggered.connect(self.reload_page) 
        #bar.addAction(update_btn) 
        if self.show_update_btn == 1:
            update_icon = QIcon(f"icons/{self.coloricons}/refresh-cw.svg")
            update_btn = QAction(update_icon, "Update", self) 
            update_btn.setStatusTip("Update page") 
            update_btn.triggered.connect(self.reload_page) 
            bar.addAction(update_btn)
        else:
            pass
        #home page new btn
        if self.show_home_btn == 1:
            home_icon = QIcon(f"icons/{self.coloricons}/home.svg")
            home_btn = QAction(home_icon, "Home", self)  
            home_btn.setStatusTip("Home page")  
            home_btn.triggered.connect(self.home) 
            bar.addAction(home_btn)
        else:
            pass
        #url bar
        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.url_line)
        bar.addWidget(self.url_bar)
        current_web_view = self.get_current_webview()
        if current_web_view:
            self.url_bar.setText(current_web_view.url().toString())


        #pomogashka
        if self.show_help_line == 1:
            self.pomogashka_line = QLineEdit()
            bar.addWidget(self.pomogashka_line)
            help_btn_icon = QIcon(f"icons/{self.coloricons}/terminal.svg")
            help_btn_btn = QAction(help_btn_icon, "Pomogashka", self)  
            help_btn_btn.setStatusTip("Pomogashka")  
            help_btn_btn.triggered.connect(self.pomogashka_loader) 
            bar.addAction(help_btn_btn)
        else:
            pass
        #home page button
        #home_btn = QAction("H", self)
        #home_btn.setStatusTip("Home page")
        #home_btn.triggered.connect(self.home) 
        #bar.addAction(home_btn) 
        
        #new tab
        #new_tab_btn = QAction("+", self)
        #new_tab_btn.setStatusTip("New tab")
        #new_tab_btn.triggered.connect(lambda: self.new_tab())
        #bar.addAction(new_tab_btn)
        if self.show_newtab_btn == 1:
            new_tab_btn_icon = QIcon(f"icons/{self.coloricons}/plus.svg")
            new_tab_btn = QAction(new_tab_btn_icon, "New tab", self)  
            new_tab_btn.setStatusTip("New tab")   
            new_tab_btn.triggered.connect(lambda: self.new_tab()) 
            bar.addAction(new_tab_btn)
        else:
            pass
        #tor
        if self.usetorproxy == 1 and self.show_tor_btn == 1:
            tor_use_btn_icon = QIcon(f"icons/{self.coloricons}/tor.svg")
            tor_use_btn = QAction(tor_use_btn_icon, "The onion route", self)
            tor_use_btn.setStatusTip("Use the onion route")
            tor_use_btn.triggered.connect(lambda: self.new_tab()) 
            bar.addAction(tor_use_btn)
        #elif self.usetorproxy == 0:
        #    pass
        else:
            pass
        #tor
        #download list
        if self.show_downloadlist_btn == 1:
            download_list_btn_icon = QIcon(f"icons/{self.coloricons}/download.svg")
            download_list_btn = QAction(download_list_btn_icon, "Open download list", self)  
            download_list_btn.setStatusTip("Download list")   
            download_list_btn.triggered.connect(lambda: self.open_floader()) 
            bar.addAction(download_list_btn)
        else:
            pass
        #history btn
        if self.show_history_btn == 1:
            history_icon = QIcon(f"icons/{self.coloricons}/archive.svg")  
            history_btn = QAction(history_icon, "History", self)
            history_btn.setStatusTip("Show history")
            history_btn.triggered.connect(lambda: show_history(self))
            bar.addAction(history_btn)
        else:
            pass
        #settings button
        #set_btn = QAction("⋮", self)
        #set_btn.setStatusTip("Settings")
        #set_btn.triggered.connect(self.open_settings) 
        #bar.addAction(set_btn)
        if self.show_settings_btn == 1:
            set_btn_icon = QIcon(f"icons/{self.coloricons}/settings.svg")
            set_btn = QAction(set_btn_icon, "Settings", self)  
            set_btn.setStatusTip("Settings")  
            set_btn.triggered.connect(self.open_settings) 
            bar.addAction(set_btn)
        else:
            pass