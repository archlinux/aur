import sys 
import importlib.util
import sys
import os
import json
from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtWebEngineWidgets import *
from PyQt6.QtWebEngineCore import *
from PyQt6.QtGui import *
from PyQt6.QtWebEngineWidgets import *
from PyQt6.QtWebEngineCore import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QProgressBar, QPushButton
from PyQt6.QtCore import QTimer
class SimpleDownloadDialog(QDialog):
    def __init__(self, filename, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Download")
        self.setFixedSize(300, 120)
        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"File: {filename}"))
        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.size_label = QLabel("Size: 0 KB / 0 KB")
        layout.addWidget(self.size_label)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        layout.addWidget(self.cancel_btn)
        self.setLayout(layout)
    def update_progress(self, received, total):
        if total > 0:
            percent = int(received * 100 / total)
            self.progress.setValue(percent)
            if total < 1024 * 1024:
                self.size_label.setText(f"Size: {received/1024:.0f} KB / {total/1024:.0f} KB")
            else:
                self.size_label.setText(f"Size: {received/1024/1024:.1f} MB / {total/1024/1024:.1f} MB")