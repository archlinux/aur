import json
import os
from PyQt6.QtWidgets import QMessageBox, QFileDialog
from pathlib import Path
from moduls.settings.standartsettingscreator import *
class LoadSettings():  
    def save_blocker_settings(self):
        settings = {
            "page_blocker": self.page_blocker.isChecked(),
            "add_blocker": self.add_blocker.isChecked(),
            "js_blocker": self.js_blocker.isChecked(),
            "miner_blocker": self.miner_blocker.isChecked(),
            "cookies_blocker": self.cookies_blocker.isChecked(),
        }
        
        try:
            
            filepath = Path.home()/".config/wolfbrowser/settings/blocker_settings.json"  
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED BLOCKER SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR BLOCKER SETTINGS FAILED TO SAVE {str(e)}")
            
    def load_blocker_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/blocker_settings.json"
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.page_blocker.setChecked(settings.get("page_blocker", False))
                self.add_blocker.setChecked(settings.get("add_blocker", False))
                self.js_blocker.setChecked(settings.get("js_blocker", False))
                self.miner_blocker.setChecked(settings.get("miner_blocker", False))
                self.cookies_blocker.setChecked(settings.get("cookies_blocker", False))
                self.log_win.addlog("SAVS", "LOADED BLOCKER SETTINGS")
            else:
                create_standart_blocker_settings()  
        except Exception as e:
            print(f"Failed to load settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR BLOCKER SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_blocker_settings_error(self)
            




    def save_private_settings(self):
        settings = {
            "proxy": self.proxy.isChecked(),
            "adresseditline": self.editlineproxy.text(),  
            "proxyeditline": self.editportproxyline.text(),
        }
        
        try:
            filepath = Path.home()/".config/wolfbrowser/settings/private_settings.json"  
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED PRIVATE SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR PRIVATE SETTINGS FAILED TO SAVE {str(e)}")



    def load_private_settings(self):
            try:
                filepath = Path.home() / ".config/wolfbrowser/settings/private_settings.json"
                
                if os.path.exists(filepath):
                    with open(filepath, 'r', encoding='utf-8') as f:
                        settings = json.load(f)
                    
                    self.proxy.setChecked(settings.get("proxy", False))
                    self.editlineproxy.setText(settings.get("adresseditline", ""))
                    self.editportproxyline.setText(settings.get("proxyeditline", ""))
                    self.log_win.addlog("SAVS", "LOADED PRIVATE SETTINGS")
                else:
                    create_standart_private_settings()    
            except Exception as e:
                print(f"Failed to load private settings: {str(e)}")
                self.log_win.addlog("SAVS", f"ERROR PRIVATE SETTINGS FAILED TO LOAD {str(e)}")
                set_standart_private_settings_error(self)
    def save_customization_settings(self):
        settings = {
            "razmerlinew": self.razmerwline.text(),
            "razmerlineh": self.razmerhline.text(),
            "colorlinegreen": self.colorbcheckG.isChecked(),
            "colorlinered": self.colorbcheckR.isChecked(),
            "colorlineyellow": self.colorbcheckY.isChecked(),
            "colorlineblue": self.colorbcheckB.isChecked(),
            "colorlinegradient": self.colorbcheckGR.isChecked(),
            "sizehmainwindow": self.sizehmain.text(),
            "sizewmainwindow": self.sizewmain.text(),
            "sizehsettingswindow": self.sizehbrowser.text(),
            "sizewsettingswindow": self.sizewbrowser.text(),
        }
        try:
            filepath = Path.home()/".config/wolfbrowser/settings/customization_settings.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED CUSTOMIZATION SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR CUSTOMIZATION SETTINGS FAILED TO SAVE {str(e)}")
    def load_customization_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/customization_settings.json"
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.razmerwline.setText(settings.get("razmerlinew", "200")),
                self.razmerhline.setText(settings.get("razmerlineh", "16")),
                self.colorbcheckG.setChecked(settings.get("colorlinegreen", False)),
                self.colorbcheckR.setChecked(settings.get("colorlinered", False)),
                self.colorbcheckY.setChecked(settings.get("colorlineyellow", False)),
                self.colorbcheckB.setChecked(settings.get("colorlineblue", False)),
                self.colorbcheckGR.setChecked(settings.get("colorlinegradient", False))
                self.sizehmain.setText(settings.get("sizehmainwindow", ""))                
                self.sizewmain.setText(settings.get("sizewmainwindow", ""))
                self.sizehbrowser.setText(settings.get("sizehsettingswindow", ""))
                self.sizewbrowser.setText(settings.get("sizewsettingswindow", ""))
                self.log_win.addlog("SAVS", "LOADED CUSTOMIZATION SETTINGS")
            else:
                create_standart_customization_settings()
        except Exception as e:
            print(f"Failed to load customization settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR CUSTOMIZATION SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_customization_settings_error(self)
    def save_main_settings(self):
        settings = {
            "DuckDuckGo": self.duckduckgosearch.isChecked(),
            "Brave": self.bravesearch.isChecked(),
            "Custom": self.customsearch.isChecked(),
            "Custom line": self.customsearch_line.text(),
            "DuckDuckGoHome": self.duckduckgohome.isChecked(),
            "BraveHome": self.bravehome.isChecked(),
            "CustomHome": self.customhome.isChecked(),
            "Customhome line": self.customhome_line.text(),
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/main_settings.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED MAIN SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR MAIN SETTINGS FAILED TO SAVE {str(e)}")
    def load_main_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/main_settings.json" 
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.duckduckgosearch.setChecked(settings.get("DuckDuckGo", False)),
                self.bravesearch.setChecked(settings.get("Brave", False))
                self.customsearch.setChecked(settings.get("Custom", False))
                self.customsearch_line.setText(settings.get("Custom line", "")),
                self.duckduckgohome.setChecked(settings.get("DuckDuckGoHome", False)),
                self.bravehome.setChecked(settings.get("BraveHome", False))
                self.customhome.setChecked(settings.get("CustomHome", False))
                self.customhome_line.setText(settings.get("Customhome line", "")),
                self.log_win.addlog("SAVS", "LOADED MAIN SETTINGS")
            else:
                create_standart_main_settings()
        except Exception as e:
            print(f"Failed to load customization settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR MAIN SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_main_settings_error(self)
    def save_browser_settings(self):
        settings = {
            "SH": self.savehistory.isChecked(),
            "CryptoHistory": self.savehistorysha256.isChecked(),
            "PasswordHistory": self.savehistorysha256password.text(),
            "ALLOWDOWNLOAD": self.downloadfiles.isChecked(),
            "FILEROADDOWNLOAD": self.fileroad,
            "LNG": self.browserlanguches.currentIndex(),
            "CRTNEWTABSITES": self.allowcreatenewtabsfromsites.isChecked()
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/browser_settings.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED BROWSER SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR BROWSER SETTINGS FAILED TO SAVE {str(e)}")
    def load_browser_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/browser_settings.json"
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.savehistory.setChecked(settings.get("SH", False)),
                self.savehistorysha256.setChecked(settings.get("CryptoHistory", False)),
                self.savehistorysha256password.setText(settings.get("PasswordHistory", ""))
                self.downloadfiles.setChecked(settings.get("ALLOWDOWNLOAD", False)),
                self.fileroad = settings.get("FILEROADDOWNLOAD", ""),
                lang_index = settings.get("LNG", 0)
                self.browserlanguches.setCurrentIndex(lang_index) 
                self.allowcreatenewtabsfromsites.setChecked(settings.get("CRTNEWTABSITES"))
                self.log_win.addlog("SAVS", "LOADED BROWSER SETTINGS")
            else:
                create_standart_browser_settings()
        except Exception as e:
            print(f"Failed to load customization settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR BROWSER SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_browser_settings_error(self)
    def owerviewdirectory(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose floder")
        if folder:
            self.fileroad = folder
            print(f"Choosed: {folder}")  #Choose
            self.save_browser_settings(self)
    def save_cui_settings(self):
        settings = {
            "showhistorybtn": self.showhistorybtn.isChecked(),
            "showbackbtn": self.showbackbtn.isChecked(),
            "showforwardbtn": self.showforwardbtn.isChecked(),
            "showupdatebtn": self.showupdatebtn.isChecked(),
            "shownewtabbtn": self.shownewtabbtn.isChecked(),
            "showtorbtn": self.showtorbtn.isChecked(),
            "showsettingsbtn": self.showsettingsbtn.isChecked(),
            "showhomebtn": self.showhomebtn.isChecked(),
            "showdownloadlistbtn": self.showdownloadlistbtn.isChecked(),
            "creatorstool": self.showcreatorstool.isChecked(),
            "icons1": self.icon1pack.isChecked(),
            "icons2": self.icon2pack.isChecked(),
            "help_line": self.showpomogashkaline.isChecked()
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/customize_ui.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED CUI SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR CUI SETTINGS FAILED TO SAVE {str(e)}")
    def load_cui_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/customize_ui.json" 
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.showhistorybtn.setChecked(settings.get("showhistorybtn", False))
                self.showbackbtn.setChecked(settings.get("showbackbtn", False))
                self.showforwardbtn.setChecked(settings.get("showforwardbtn", False))
                self.showupdatebtn.setChecked(settings.get("showupdatebtn", False))
                self.shownewtabbtn.setChecked(settings.get("shownewtabbtn", False))
                self.showtorbtn.setChecked(settings.get("showtorbtn", False))
                self.showsettingsbtn.setChecked(settings.get("showsettingsbtn", False))
                self.showhomebtn.setChecked(settings.get("showhomebtn", False))
                self.showdownloadlistbtn.setChecked(settings.get("showdownloadlistbtn", False)),
                self.showcreatorstool.setChecked(settings.get("creatorstool", False))
                self.icon1pack.setChecked(settings.get("icons1", False))
                self.icon2pack.setChecked(settings.get("icons2", False))
                self.showpomogashkaline.setChecked(settings.get("help_line", False))
                self.log_win.addlog("SAVS", "LOADED CUI SETTINGS")
            else:
                create_standart_cui_settings()
        except Exception as e:
            print(f"Failed to load customization settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR CUI SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_cui_settings_error(self)
    def save_hotkeys_settings(self):
        settings = {
            "newtabhotkey": self.newtabhotkey.text(),
            "closetabhotkey": self.closetabhotkey.text(),
            "updatehotkey": self.updatehotkey.text(),
            "homehotkey": self.homehotkey.text(),
            "exithotkey": self.exithotkey.text(),
            "showhistoryhotkey": self.showhistoryhotkey.text(),
            "showsettingshotkey": self.showsettingshotkey.text(),
            "referencehotkey": self.referencehotkey.text(),
            "opensettingswindow": self.opensettingswindow.text(),
            "openlogswindow": self.showlogwindow.text()
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/hotkeys.json"
            Path(filepath).parent.mkdir(parents=True, exist_ok=True) 
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED HOTKEYS SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR HOTKEYS SETTINGS FAILED TO SAVE {str(e)}")
    def load_hotkeys_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/hotkeys.json" 
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.newtabhotkey.setText(settings.get("newtabhotkey", ""))
                self.closetabhotkey.setText(settings.get("closetabhotkey", ""))
                self.updatehotkey.setText(settings.get("updatehotkey", ""))
                self.homehotkey.setText(settings.get("homehotkey", ""))
                self.exithotkey.setText(settings.get("exithotkey", ""))
                self.showhistoryhotkey.setText(settings.get("showhistoryhotkey", ""))
                self.showsettingshotkey.setText(settings.get("showsettingshotkey", ""))
                self.referencehotkey.setText(settings.get("referencehotkey", ""))
                self.opensettingswindow.setText(settings.get("opensettingswindow", ""))
                self.showlogwindow.setText(settings.get("openlogswindow", ""))
                self.log_win.addlog("SAVS", "LOADED HOTKEYS SETTINGS")
            else:
                create_standart_hotkeys_settings()
        except Exception as e:
            print(f"Failed to load customization settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR HOTKEYS SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_hotkeys_settings_error(self)
    def save_pom_settings(self):
        settings = {
            "one": self.ftextinput.text(),
            "two": self.stextinput.text(),
            "three": self.thtextinput.text(),
            "for": self.fortextinput.text(),
            "five": self.fivetextinput.text(),
            "six": self.sixtextinput.text(),
            "seven": self.sevtextinput.text(),
            "eght": self.eghttextinput.text(),
            "nine": self.ninetextinput.text(),
            "ten": self.tentextinput.text(),
            "_one": self.furlput.text(),
            "_two": self.surlput.text(),
            "_three": self.thurlput.text(),
            "_for": self.forurlput.text(),
            "_five": self.fiveurlput.text(),
            "_six": self.sixurlput.text(),
            "_seven": self.sevurlput.text(),
            "_eght": self.eghturlput.text(),
            "_nine": self.nineurlput.text(),
            "_ten": self.tenurlput.text(),
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/pomogashka.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED POM SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR POM SETTINGS FAILED TO SAVE {str(e)}")
    def load_pom_settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/pomogashka.json" 
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.ftextinput.setText(settings.get("one", ""))
                self.stextinput.setText(settings.get("two", ""))
                self.thtextinput.setText(settings.get("three", ""))
                self.fortextinput.setText(settings.get("for", ""))
                self.fivetextinput.setText(settings.get("five", ""))
                self.sixtextinput.setText(settings.get("six", ""))
                self.sevtextinput.setText(settings.get("seven", ""))
                self.eghttextinput.setText(settings.get("eght", ""))
                self.ninetextinput.setText(settings.get("nine", ""))
                self.tentextinput.setText(settings.get("ten", ""))
                self.furlput.setText(settings.get("_one", ""))
                self.surlput.setText(settings.get("_two", ""))
                self.thurlput.setText(settings.get("_three", ""))
                self.forurlput.setText(settings.get("_for", ""))
                self.fiveurlput.setText(settings.get("_five", ""))
                self.sixurlput.setText(settings.get("_six", ""))
                self.sevurlput.setText(settings.get("_seven", ""))
                self.eghturlput.setText(settings.get("_eght", ""))
                self.nineurlput.setText(settings.get("_nine", ""))
                self.tenurlput.setText(settings.get("_ten", ""))
                self.log_win.addlog("SAVS", "LOADED POM SETTINGS")
            else: 
                create_standart_help_settings()
        except Exception as e:
            print(f"Failed to load pomogashka settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR POM SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_help_settings_error(self)
    def save_private777settings(self):
        settings = {
            "sizewebviewonoroff": self.chengerazmerwebview.isChecked(),
            "shwv": self.linedisizeh.text(),
            "swwv": self.linedisizew.text()
        }
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/privatetor.json" 
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4, ensure_ascii=False)
            
            QMessageBox.information(self, "Success", "Please restart browser!")
            self.log_win.addlog("SAVS", "SAVED PRIVATE777 SETTINGS")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR PRIVATE777 SETTINGS FAILED TO SAVE {str(e)}")
    def load_private777settings(self):
        try:
            filepath = Path.home() / ".config/wolfbrowser/settings/privatetor.json" 
            
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                self.chengerazmerwebview.setChecked(settings.get("sizewebviewonoroff", False))
                self.linedisizeh.setText(settings.get("shwv", ""))
                self.linedisizew.setText(settings.get("swwv", ""))
                self.log_win.addlog("SAVS", "LOADED PRIVATE777 SETTINGS")
            else: 
                create_standart_pr777_settings()
        except Exception as e:
            print(f"Failed to load pomogashka settings: {str(e)}")
            self.log_win.addlog("SAVS", f"ERROR PRIVATE777 SETTINGS FAILED TO LOAD {str(e)}")
            set_standart_pr777_settings_error(self)