import json
from pathlib import Path
def create_standart_blocker_settings():
    settings = {
            "page_blocker": False,
            "add_blocker": False,
            "js_blocker": False,
            "miner_blocker": False,
            "cookies_blocker": False,
            }
    filepath = Path.home()/".config/wolfbrowser/settings/blocker_settings.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings 
def set_standart_blocker_settings_error(settings_window):
    settings_window.page_blocker.setChecked(False)
    settings_window.add_blocker.setChecked(False)
    settings_window.js_blocker.setChecked(False)
    settings_window.miner_blocker.setChecked(False)
    settings_window.cookies_blocker.setChecked(False)
def create_standart_private_settings():
    settings = {
            "proxy": False,
            "adresseditline": '',  
            "proxyeditline": '',
        }
    filepath = Path.home()/".config/wolfbrowser/settings/private_settings.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_private_settings_error(settings_window):
    settings_window.proxy.setChecked(False)       
    settings_window.editlineproxy.setText('')      
    settings_window.editportproxyline.setText('') 
def create_standart_customization_settings():
    settings = {
            "razmerlinew": '200',
            "razmerlineh": '16',
            "colorlinegreen": False,
            "colorlinered": False,
            "colorlineyellow": False,
            "colorlineblue": False,
            "colorlinegradient": True,
            "sizehmainwindow": '1920',
            "sizewmainwindow": '1080',
            "sizehsettingswindow": '1920',
            "sizewsettingswindow": '1080',
        }
    filepath = Path.home()/".config/wolfbrowser/settings/customization_settings.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_customization_settings_error(settings_window):
    settings_window.razmerwline.setText('200')
    settings_window.razmerhline.setText('16')
    settings_window.colorbcheckG.setChecked(False)
    settings_window.colorbcheckR.setChecked(False)
    settings_window.colorbcheckY.setChecked(False)
    settings_window.colorbcheckB.setChecked(False)
    settings_window.colorbcheckGR.setChecked(True)
    settings_window.sizehmain.setText('1920')
    settings_window.sizewmain.setText('1080')
    settings_window.sizehbrowser.setText('1920')
    settings_window.sizehbrowser.setText('1080')
def create_standart_main_settings():
    settings = {
            "DuckDuckGo": True,
            "Brave": False,
            "Custom": False,
            "Custom line": '',
            "DuckDuckGoHome": True,
            "BraveHome": False,
            "CustomHome": False,
            "Customhome line": '',
        }
    filepath = Path.home()/".config/wolfbrowser/settings/main_settings.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_main_settings_error(settings_window):
    settings_window.duckduckgosearch.setChecked(True)
    settings_window.bravesearch.setChecked(False)
    settings_window.customsearch.setChecked(False)
    settings_window.customsearch_line.setText('')
    settings_window.duckduckgohome.setChecked(False)
    settings_window.bravehome.setChecked(False)
    settings_window.customhome.setChecked(False)
    settings_window.customhome_line.setText('')
def create_standart_browser_settings():
    settings = {
            "SH": False,
            "CryptoHistory": False,
            "PasswordHistory": '',
            "ALLOWDOWNLOAD": False,
            "FILEROADDOWNLOAD": '',
            "LNG": 0,
            "CRTNEWTABSITES": False
        }
    filepath = Path.home()/".config/wolfbrowser/settings/browser_settings.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_browser_settings_error(settings_window):
    settings_window.savehistory.setChecked(False),
    settings_window.savehistorysha256.setChecked(False),
    settings_window.savehistorysha256password.setText(''),
    settings_window.downloadfiles.setChecked(False),
    #settings_window.fileroad = settings.get(''),
    settings_window.allowcreatenewtabsfromsites.setChecked(False)
def create_standart_cui_settings():
    settings = {
            "showhistorybtn": False,
            "showbackbtn": True,
            "showforwardbtn": True,
            "showupdatebtn": True,
            "shownewtabbtn": True,
            "showtorbtn": False,
            "showsettingsbtn": True,
            "showhomebtn": True,
            "showdownloadlistbtn": False,
            "creatorstool": False,
            "icons1": False,
            "icons2": True,
            "help_line": False
        }
    filepath = Path.home() / ".config/wolfbrowser/settings/customize_ui.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_cui_settings_error(settings_window):
    settings_window.showhistorybtn.setChecked(False)
    settings_window.showbackbtn.setChecked(True)
    settings_window.showforwardbtn.setChecked(True)
    settings_window.showupdatebtn.setChecked(True)
    settings_window.shownewtabbtn.setChecked(True)
    settings_window.showtorbtn.setChecked(False)
    settings_window.showsettingsbtn.setChecked(True)
    settings_window.showhomebtn.setChecked(True)
    settings_window.showdownloadlistbtn.setChecked(False)
    settings_window.showcreatorstool.setChecked(False)
    settings_window.icon1pack.setChecked(False)
    settings_window.icon2pack.setChecked(False)
    settings_window.showpomogashkaline.setChecked(False)
def create_standart_hotkeys_settings():
    settings = {
            "newtabhotkey": 'Ctrl+t',
            "closetabhotkey": 'Ctrl+w',
            "updatehotkey": 'F5',
            "homehotkey": 'HOME',
            "exithotkey": 'Ctrl+q',
            "showhistoryhotkey": 'Ctrl+h',
            "showsettingshotkey": 'Ctrl+j',
            "referencehotkey": 'F1',
            "opensettingswindow": 'F2',
            "openlogswindow": 'Ctrl+l'
        }
    filepath = Path.home() / ".config/wolfbrowser/settings/hotkeys.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_hotkeys_settings_error(settings_window):
    settings_window.newtabhotkey.setText("Ctrl+t")
    settings_window.closetabhotkey.setText("Ctrl+w")
    settings_window.updatehotkey.setText("F5")
    settings_window.homehotkey.setText("HOME")
    settings_window.exithotkey.setText("Ctrl+q")
    settings_window.showhistoryhotkey.setText("Ctrl+h")
    settings_window.showsettingshotkey.setText("Ctrl+j")
    settings_window.referencehotkey.setText("F1")
    settings_window.opensettingswindow.setText("F2")
    settings_window.showlogwindow.setText("Ctrl+l")
def create_standart_help_settings():
    settings = {
            "one": "",
            "two": "",
            "three": "",
            "for": "",
            "five": "",
            "six": "",
            "seven": "",
            "eght": "",
            "nine": "",
            "ten": "",
            "_one": "",
            "_two": "",
            "_three": "",
            "_for": "",
            "_five": "",
            "_six": "",
            "_seven": "",
            "_eght": "",
            "_nine": "",
            "_ten": "",
        }
    filepath = Path.home() / ".config/wolfbrowser/settings/pomogashka.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_help_settings_error(settings_window):
    settings_window.ftextinput.setText("")
    settings_window.stextinput.setText("")
    settings_window.thtextinput.setText("")
    settings_window.fortextinput.setText("")
    settings_window.fivetextinput.setText("")
    settings_window.sixtextinput.setText("")
    settings_window.sevtextinput.setText("")
    settings_window.eghttextinput.setText("")
    settings_window.ninetextinput.setText("")
    settings_window.tentextinput.setText("")
    settings_window.furlput.setText("")
    settings_window.surlput.setText("")
    settings_window.thurlput.setText("")
    settings_window.forurlput.setText("")
    settings_window.fiveurlput.setText("")
    settings_window.sixurlput.setText("")
    settings_window.sevurlput.setText("")
    settings_window.eghturlput.setText("")
    settings_window.nineurlput.setText("")
    settings_window.tenurlput.setText("")
def create_standart_pr777_settings():
    settings = {
            "sizewebviewonoroff": "",
            "shwv": "1400",
            "swwv": "900"
        }
    filepath = Path.home() / ".config/wolfbrowser/settings/privatetor.json" 
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)
    return settings
def set_standart_pr777_settings_error(settings_window):
    settings_window.chengerazmerwebview.setChecked(False)
    settings_window.linedisizeh.setText("1400")
    settings_window.linedisizew.setText("900")