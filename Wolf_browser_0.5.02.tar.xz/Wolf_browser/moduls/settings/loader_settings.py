import sys 
import os
import json
from PyQt6.QtWidgets import *
from PyQt6.QtWebEngineWidgets import QWebEngineView  
from PyQt6.QtWebEngineCore import *  
from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtNetwork import QNetworkProxy
from pathlib import Path
from moduls.misc.adblocker import AdBlockerInterceptor
def get_config_path(filename):
    return Path.home() / ".config" / "wolfbrowser" / "settings" / filename
def read_settings_blockerpage_cookie(self):
    try:
        filepath = get_config_path("blocker_settings.json")
        with open(filepath, 'r', encoding='utf-8') as f:
            settings = json.load(f)
        profile = QWebEngineProfile.defaultProfile()
        if settings.get('cookies_blocker', True):
            profile.cookieStore().setCookieFilter(lambda request: False)
            print("Cookes off")
        else:
            #profile.cookieStore().setCookieFilter(None)
            print("Cookes on")
            
    except FileNotFoundError:
        print("File blocker_settings.json not found")
        QWebEngineProfile.defaultProfile().cookieStore().setCookieFilter(None)
    except json.JSONDecodeError:
        print("Error in json file")
        QWebEngineProfile.defaultProfile().cookieStore().setCookieFilter(None)

def read_settings_privatepage_proxy(self):
    self.usetorproxy = 0
    try:
        filepath = get_config_path("private_settings.json")
        with open(filepath, 'r', encoding='utf-8') as f:
            settings = json.load(f)
                
        if settings.get('proxy', False):
            proxy_host = settings.get('adresseditline', '127.0.0.1')
            proxy_port = int(settings.get('proxyeditline', '9150'))
            proxy = QNetworkProxy()
            proxy.setType(QNetworkProxy.ProxyType.Socks5Proxy)
            proxy.setHostName(proxy_host)
            proxy.setPort(proxy_port)
            QNetworkProxy.setApplicationProxy(proxy)
                    
            print(f"Proxy on: {proxy_host}:{proxy_port}")
            if proxy_port == 9050 or proxy_port == 9150:
                self.usetorproxy = 1   
            else:
                self.usetorproxy = 0  
        else:
            QNetworkProxy.setApplicationProxy(QNetworkProxy())
            print("Proxy off")
                    
    except FileNotFoundError:
        print("File private_settings.json not found")
        QNetworkProxy.setApplicationProxy(QNetworkProxy())
    except Exception as e:
        print(f"Error in json file: {e}")
        QNetworkProxy.setApplicationProxy(QNetworkProxy())                  
        
def read_settings_blockerpage_javascreept(self):
    try:
        filepath = get_config_path("blocker_settings.json")
        with open(filepath, 'r', encoding='utf-8') as f:
            settings = json.load(f)
        
        profile = QWebEngineProfile.defaultProfile()
        settings_web = profile.settings()
        if settings.get('js_blocker', False):
            settings_web.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, False)
            print("JavaScript off")
        else:
            settings_web.setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
            print("JavaScript on")
            
    except FileNotFoundError:
        print("File blocker_settings.json not found, JavaScripts on")
        QWebEngineProfile.defaultProfile().settings().setAttribute(
            QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
    except Exception as e:
        print(f"Error from json file: {e}")

def read_settings_blockerpage_addblocker(self):
    try:
        filepath = get_config_path("blocker_settings.json")
        with open(filepath, 'r', encoding='utf-8') as f:
            settings = json.load(f)
        
        profile = QWebEngineProfile.defaultProfile()
        if settings.get('add_blocker', False):
            profile.setUrlRequestInterceptor(AdBlockerInterceptor())
            print("AddBlocker on")
        else:
            profile.setUrlRequestInterceptor(None)
            print("AddBlocker off")
            
    except Exception as e:
        print(f"Error AddBlocker: {e}")

def read_settings_custompage_razmerbootline(self):
    try:
        filepath = get_config_path("customization_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            self.linew = settings.get("razmerlinew", "200") 
            self.lineh = settings.get("razmerlineh", "16")   
            self.saved_linew = self.linew
            self.saved_lineh = self.lineh
            
    except Exception as e:
        print(f"Failed to load customization settings: {str(e)}")

def read_settings_custompage_colors(self):
    try:
        filepath = get_config_path("customization_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("colorlinegreen", False):
                self.progress_color = "#22c55e" 
                self.progress_style = "solid"
                print("Color: Green")
            elif settings.get("colorlinered", False):
                self.progress_color = "#ef4444" 
                self.progress_style = "solid"
                print("Color: Red")
            elif settings.get("colorlineyellow", False):
                self.progress_color = "#eab308" 
                self.progress_style = "solid"
                print("Color: Yellow")
            elif settings.get("colorlineblue", False):
                self.progress_color = "#3b82f6"  
                self.progress_style = "solid"
                print("Color: Blue")
            elif settings.get("colorlinegradient", False):
                self.progress_style = "gradient"
                print("Color: Gradient")
            else:
                self.progress_style = "gradient"
                print("Color: Gradient not from file")
            self.update_progressbar_style()
            
    except Exception as e:
        print(f"Error when import colors: {e}")
        self.progress_style = "gradient"

def update_progressbar_style(self):
    
    if self.progress_style == "gradient":
        style = """
        QProgressBar {
            border: 1px solid #5a5a5a;
            border-radius: 4px;
            text-align: center;
            color: white;
            font-weight: bold;
            background-color: #2d2d2d;
        }
        QProgressBar::chunk {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                    stop:0 #7c3aed,
                                    stop:0.3 #2563eb,
                                    stop:0.6 #16a34a,
                                    stop:1 #eab308);
            border-radius: 3px;
        }
        """
    else:
        style = f"""
        QProgressBar {{
            border: 1px solid #5a5a5a;
            border-radius: 4px;
            text-align: center;
            color: white;
            font-weight: bold;
            background-color: #2d2d2d;
        }}
        QProgressBar::chunk {{
            background: {self.progress_color};
            border-radius: 3px;
        }}
        """
    
    self.progress_bar.setStyleSheet(style)
def read_main_settings(self):
    try:
        filepath = get_config_path("main_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("DuckDuckGo", False):
                self.search_system = "https://duckduckgo.com/"
            elif settings.get("Brave", False):
                self.search_system = "https://search.brave.com/"
            elif settings.get("Custom", False):
                self.search_system = settings.get("Custom line", "")
            else:
                self.search_system = "https://duckduckgo.com/"
            print(f"Load search system: {self.search_system}")
            if settings.get("DuckDuckGoHome", False):
                self.homepage = "https://duckduckgo.com/"
            elif settings.get("BraveHome", False):
                self.homepage = "https://search.brave.com/"
            elif settings.get("CustomHome", False):
                self.homepage = settings.get("Customhome line", "")
    except Exception as e:
        print(f"Error when load main_settings: {e}")
        self.search_system = "https://duckduckgo.com/" 
def read_browser_settingsdownload(self):
    try:
        filepath = get_config_path("browser_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            if settings.get("ALLOWDOWNLOAD", False):
                self.download_enabled = True
                print("You can download")
            
            download_folder = settings.get("FILEROADDOWNLOAD", "")
            if download_folder:
                self.download_folder = download_folder
                print(f"Road is loading: {download_folder}")
    except Exception as e:
        print(f"Error download settings: {e}")
def read_cui_button(self):
    try:
        filepath = get_config_path("customize_ui.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            if settings.get("showhistorybtn", False):
                self.show_history_btn = 1
            else:
                self.show_history_btn = 0
            if settings.get("showbackbtn", False):
                self.show_back_btn = 1
            else:
                self.show_back_btn = 0
            if settings.get("showforwardbtn", False):
                self.show_forward_btn = 1
            else:
                self.show_forward_btn = 0
            if settings.get("showupdatebtn", False):
                self.show_update_btn = 1
            else:
                self.show_update_btn = 0
            if settings.get("shownewtabbtn", False):
                self.show_newtab_btn = 1
            else:
                self.show_newtab_btn = 0
            if settings.get("showtorbtn", False):
                self.show_tor_btn = 1
            else:
                self.show_tor_btn = 0
            if settings.get("showsettingsbtn", False):
                self.show_settings_btn = 1
            else:
                self.show_settings_btn = 0
            if settings.get("showhomebtn", False):
                self.show_home_btn = 1
            else:
                self.show_home_btn = 0
            if settings.get("showdownloadlistbtn", False):
                self.show_downloadlist_btn = 1
            else:
                self.show_downloadlist_btn = 0
            if settings.get("help_line", False):
                self.show_help_line = 1
            else:
                self.show_help_line = 0
        else:
            self.show_history_btn = 0
            self.show_back_btn = 1
            self.show_forward_btn = 1
            self.show_update_btn = 1
            self.show_newtab_btn = 1
            self.show_settings_btn = 1
            self.show_home_btn = 1
            self.show_downloadlist_btn = 0
            self.show_help_line = 0
    except Exception as e:
        print(f"Error download settings: {e}")
def read_hotkeys_settings(self):
    try:
        filepath = get_config_path("hotkeys.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            self.newtabhotkeya113 = settings.get("newtabhotkey", "")
            self.closetabhotkeya113 = settings.get("closetabhotkey", "")
            self.updatetabhotkeya113 = settings.get("updatehotkey", "")
            self.homehotkeya113 = settings.get("homehotkey", "")
            self.exithotkeya113 = settings.get("exithotkey", "")
            self.showhistoryhotkeya113 = settings.get("showhistoryhotkey", "")
            self.showsettingshotkeya113 = settings.get("showsettingshotkey", "")
            self.referencehotkeya113 = settings.get("referencehotkey", "")
            self.opensettingswindowa113 = settings.get("opensettingswindow", "")
            self.openlogwindowa113 = settings.get("openlogswindow", "")
            
    except Exception as e:
        print(f"Error download settings: {e}")
def read_customize_size(self):
    try:
        filepath = get_config_path("customization_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            self.sizeh115 = settings.get("sizehmainwindow", "")
            self.sizew115 = settings.get("sizewmainwindow", "")
            self.sizehsettings115 = settings.get("sizehsettingswindow", "")
            self.sizewsettings115 = settings.get("sizewsettingswindow", "")
        else:
            self.sizeh115 = "1920"
            self.sizew115 = "1080"
            self.sizehsettings115 = "600"
            self.sizewsettings115 = "600"
    except Exception as e:
        print(f"Error download settings: {e}")
def read_toolforcreator(self):
    try:
        filepath = get_config_path("customize_ui.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("creatorstool", False):
                self.show_toolsettings = 1
            else:
                self.show_toolsettings = 0
        else:
            self.show_toolsettings = 0
    except Exception as e:
        print(f"Error download settings: {e}")
savehistorycrypto = 0
def read_cryptohistory(self):
    global savehistorycrypto
    try:
        filepath = get_config_path("browser_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("CryptoHistory", False):
                savehistorycrypto = 1
            else:
                savehistorycrypto = 0
    except Exception as e:
        print(f"Error download settings: {e}")
def read_coloricons(self):
    try:
        filepath = get_config_path("customize_ui.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("icons1", False):
                self.coloricons = "black"
            elif settings.get("icons2", False):
                self.coloricons = "white"
        else:
            self.coloricons = "white"
    except Exception as e:
        print(f"Error download settings: {e}")
def read_pomogashka(self):
    try:
        filepath = get_config_path("pomogashka.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            self.one_cmd = settings.get("one", "")
            self.one_url = settings.get("_one", "")
            
            self.two_cmd = settings.get("two", "")
            self.two_url = settings.get("_two", "")
            
            self.three_cmd = settings.get("three", "")
            self.three_url = settings.get("_three", "")
            
            self.four_cmd = settings.get("for", "")
            self.four_url = settings.get("_for", "")
            
            self.five_cmd = settings.get("five", "")
            self.five_url = settings.get("_five", "")
            
            self.six_cmd = settings.get("six", "")
            self.six_url = settings.get("_six", "")
            
            self.seven_cmd = settings.get("seven", "")
            self.seven_url = settings.get("_seven", "")
            
            self.eight_cmd = settings.get("eght", "")
            self.eight_url = settings.get("_eght", "")
            
            self.nine_cmd = settings.get("nine", "")
            self.nine_url = settings.get("_nine", "")
            
            self.ten_cmd = settings.get("ten", "")
            self.ten_url = settings.get("_ten", "")
    except Exception as e:
        print(f"Error download pomogashka settings: {e}")
def read_region_settings(self):
    global lngsetindextochangerx113
    try:
        lngsetindextochangerx113 = "eu"
        filepath = get_config_path("browser_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("LNG") == 1:
                lngsetindextochangerx113 = "ru"
            else:
                lngsetindextochangerx113 = "eu"

    except Exception as e:
        print(f"Error lng settings: {e}")
        lngsetindextochangerx113 = "eu"
def read_allow_open_new_tab_tab(self):
    try:
        filepath = get_config_path("browser_settings.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("CRTNEWTABSITES") == True:
                self.allowcrtnewtabtab = 1
            else:
                self.allowcrtnewtabtab = 0
    except Exception as e:
        print(f"Error opennewtaballowsettings: {e}")
def read_priv777_settings(self):
    try:
        filepath = get_config_path("privatetor.json")
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            if settings.get("sizewebviewonoroff"):
                self.onfixsizewebviev = 1
            else:
                self.onfixsizewebviev = 0
            if settings.get("shwv"):
                self.sizehwebview = int(settings.get("shwv"))
            else:
                self.sizehwebview = 1400
            if settings.get("swwv"):
                self.sizewwebview = int(settings.get("swwv"))
            else:
                self.sizewwebview = 900
    except Exception as e:
        print(f"Error readpriv777: {e}")