#ifndef __RESOURCE_resource_H__
#define __RESOURCE_resource_H__

#include <gio/gio.h>

extern GResource *resource_get_resource (void);
#endif
