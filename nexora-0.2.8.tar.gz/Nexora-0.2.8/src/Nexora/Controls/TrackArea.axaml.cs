using System.Collections.ObjectModel;
using Avalonia;
using Avalonia.Controls;
using Nexora.ViewModels;

namespace Nexora.Controls;

public partial class TrackArea : UserControl
{
    public static readonly StyledProperty<ObservableCollection<TrackControlVm>> TrackVmsProperty =
        AvaloniaProperty.Register<TrackArea, ObservableCollection<TrackControlVm>>(nameof(TrackVms)
    );

    public ObservableCollection<TrackControlVm> TrackVms
    {
        get => GetValue(TrackVmsProperty);
        set => SetValue(TrackVmsProperty, value);
    }

    public TrackArea()
    {
        InitializeComponent();
    }

    private void OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if(sender is ListBox listBox)
        {
            listBox.SelectedItem = null;
        }
    }
}
