import { app, BrowserWindow } from "electron";
import path from "path";
import { isDev } from "./utils.js";

type test = string;
const t: test = "test";
console.log(t);

app.on("ready", () => {
  const mainWindow = new BrowserWindow({
    autoHideMenuBar: true,
    webPreferences: {
      webSecurity: false,
    },
  });
  if (isDev()) {
    mainWindow.loadURL("http://localhost:7838");
  } else {
    const indexPath = path.join("/usr/lib/aniparser/dist-react", "index.html");
    mainWindow.loadFile(indexPath);
    console.log("Loading:", indexPath);
  }
});
