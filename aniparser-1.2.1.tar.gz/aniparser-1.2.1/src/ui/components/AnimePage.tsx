import "./AnimePage.css";
import { Anime } from "../../api/source/Yumme_anime_ru";
import { YummyAnimeExtractor } from "../../api/source/Yumme_anime_ru";
import { playAnime, openAnimePage, setLoading } from "../body";
import { useEffect, useState } from "react";

// Интерфейс для хранения прогресса просмотра
interface WatchProgress {
  animeUrl: string;
  episodeIndex: number;
  currentTime: number;
  dubbing: string;
  lastWatched: number;
  playbackSpeed: number;
}

// Функция для загрузки прогресса просмотра
function loadWatchProgress(animeUrl: string): WatchProgress | null {
  try {
    const savedProgressList = localStorage.getItem("watchProgress");
    if (!savedProgressList) return null;

    const progressList: WatchProgress[] = JSON.parse(savedProgressList);
    const progress = progressList.find((p) => p.animeUrl === animeUrl);

    return progress || null;
  } catch (error) {
    console.error("Ошибка при загрузке прогресса:", error);
    return null;
  }
}

export default function AnimePage({
  isLoading,
  animeList,
}: {
  isLoading: boolean;
  animeList: Anime[];
}) {
  const [savedProgress, setSavedProgress] = useState<WatchProgress | null>(
    null
  );

  // Загружаем сохраненный прогресс
  useEffect(() => {
    if (animeList.length > 0) {
      const anime = animeList[animeList.length - 1];
      if (anime && anime.animeResult && anime.animeResult.anime_url) {
        const progress = loadWatchProgress(anime.animeResult.anime_url);
        setSavedProgress(progress);
      }
    }
  }, [animeList]);

  if (isLoading) return <div>Loading...</div>;
  if (animeList.length === 0) return <div></div>;
  console.log(animeList);

  const anime = animeList[animeList.length - 1];

  const rating = anime.animeResult.rating.average;
  const stars = Array(5)
    .fill(0)
    .map((_, index) => {
      const starValue = (index + 1) * 2;
      return (
        <span
          key={index}
          className={`star ${rating >= starValue ? "filled" : ""}`}
        >
          ★
        </span>
      );
    });

  const handleViewingOrderClick = async (animeId: string) => {
    setLoading(true);
    try {
      const extractor = new YummyAnimeExtractor();
      const newAnime = await extractor.getAnime(animeId);
      openAnimePage(newAnime);
    } catch (error) {
      console.error("Error opening anime:", error);
    } finally {
      setLoading(false);
    }
  };

  // Текст для кнопки в зависимости от наличия сохранения
  const getWatchButtonText = () => {
    if (savedProgress) {
      return `Продолжить просмотр с ${savedProgress.episodeIndex + 1} серии`;
    } else {
      return "Начать просмотр";
    }
  };

  return (
    <div className={"anime-page"}>
      <div className="anime-page-info">
        <div className="anime-page-poster">
          <img
            className="anime-page-thumbnail"
            src={
              anime.animeResult.poster.huge &&
              !anime.animeResult.poster.huge.startsWith("http")
                ? `https:${anime.animeResult.poster.huge}`
                : anime.animeResult.poster.huge
            }
            alt={anime.animeResult.title}
          />
        </div>
        <div className="anime-page-title-info">
          <h1 className="anime-page-title">{anime.animeResult.title}</h1>

          <div className="anime-page-meta">
            <div
              className="meta-el anime-status"
              data-status={anime.animeResult.anime_status.title}
            >
              {anime.animeResult.anime_status.title}
            </div>
            <div className="meta-el">{anime.animeResult.type.name}</div>
            <div className="meta-el">{anime.animeResult.year}</div>
          </div>
          {anime.animeResult.genres && anime.animeResult.genres.length > 0 && (
            <div className="anime-page-genres">
              {anime.animeResult.genres.map((genre, index) => (
                <span key={index} className="genre-tag">
                  {genre.title}
                </span>
              ))}
            </div>
          )}
          {rating > 0 && (
            <div className="rating-container-page">
              <div className="rating-stars">{stars}</div>
              <div className="rating-value">{rating.toFixed(1)}</div>
            </div>
          )}
          {anime.episodes && anime.episodes.length > 0 && (
            <button className="watch-button" onClick={() => playAnime(anime)}>
              {getWatchButtonText()}
            </button>
          )}
        </div>
      </div>
      <div className="anime-page-description-container">
        <p className="anime-page-description">
          {anime.animeResult.description}
        </p>
        {anime.animeResult.viewing_order &&
          anime.animeResult.viewing_order.length > 0 && (
            <div className="viewing-order-container">
              <h2 className="viewing-order-title">Порядок просмотра</h2>
              <div className="viewing-order-list">
                {anime.animeResult.viewing_order.map((item, index) => (
                  <div
                    key={index}
                    className="viewing-order-item"
                    onClick={() => handleViewingOrderClick(item.anime_url)}
                    style={{ cursor: "pointer" }}
                  >
                    <div className="viewing-order-item-poster">
                      <img
                        className="viewing-order-item-thumbnail"
                        src={
                          item.poster.huge &&
                          !item.poster.huge.startsWith("http")
                            ? `https:${item.poster.huge}`
                            : item.poster.huge
                        }
                        alt={item.title}
                      />
                    </div>
                    <div className="viewing-order-item-info">
                      <h3 className="viewing-order-item-title">{item.title}</h3>
                      <div className="viewing-order-item-meta">
                        <span className="viewing-order-item-type">
                          {item.type.name}
                        </span>
                        <span className="viewing-order-item-year">
                          {item.year}
                        </span>
                        <span
                          className="viewing-order-item-status"
                          data-status={item.anime_status.title}
                        >
                          {item.anime_status.title}
                        </span>
                      </div>
                      {item.description && (
                        <p className="viewing-order-item-description">
                          {item.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
      </div>
    </div>
  );
}
