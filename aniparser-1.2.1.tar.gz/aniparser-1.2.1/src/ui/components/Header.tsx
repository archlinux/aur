import "./header.css";
import { closeAllAnimes, closePlayer, set_body_type } from "../body";
import { BodyType } from "../types";
import { handleKeyDown, SearchAnime } from "./AnimeSearchPage";
import { FaSearch, FaHome } from "react-icons/fa";

let value: string = "";

export default function Header() {
  return (
    <div className="header">
      <div className="header-left">
        <h1>Anime Parser</h1>
      </div>

      <div className="header-center">
        <div className="search-container">
          <input
            type="text"
            placeholder="Поиск аниме..."
            onChange={(event) => (value = event.target.value)}
            onKeyDown={(event) => handleKeyDown(event, value)}
          />
          <button onClick={() => SearchAnime(value)}>
            <FaSearch />
          </button>
        </div>
      </div>

      <div className="header-right">
        <button
          onClick={() => {
            closeAllAnimes();
            set_body_type(BodyType.Search);
            closePlayer();
          }}
        >
          <FaHome />
        </button>
      </div>
    </div>
  );
}
