import "./AnimeSearchPage.css";
import { useEffect, useState } from "react";
import { Search, YummyAnimeExtractor } from "../../api/source/Yumme_anime_ru";
import { openAnimePage, setLoading } from "../body";

export async function SearchAnime(query: string) {
  const searchData = await new YummyAnimeExtractor().Search(query);
  setListf(searchData);
}

async function openAnime(search_data: Search) {
  setLoading(true);
  const anime = await search_data.getAnime();
  openAnimePage(anime);
  setLoading(false);
}

function AnimePlate(search_data: Search) {
  const rating = search_data.searchResult.rating.average;
  const stars = Array(5)
    .fill(0)
    .map((_, index) => {
      const starValue = (index + 1) * 2;
      return (
        <span
          key={index}
          className={`star ${rating >= starValue ? "filled" : ""}`}
        >
          ★
        </span>
      );
    });

  return (
    <a
      className="anime-plate"
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => openAnime(search_data)}
    >
      <div className="thumbnail">
        <img
          className="thumbnail-img"
          src={
            !search_data.searchResult.poster.huge.startsWith("http")
              ? `https:${search_data.searchResult.poster.huge}`
              : search_data.searchResult.poster.huge
          }
          alt={search_data.searchResult.title}
        />
        {rating > 0 && (
          <div className="rating-container">
            <div className="rating-stars">{stars}</div>
            <div className="rating-value">{rating.toFixed(1)}</div>
          </div>
        )}
      </div>
      <div className="anime-data">
        <h3 className="title">{search_data.searchResult.title}</h3>
        <div className="small-info">
          <div
            className="small-info-el anime-status"
            data-status={search_data.searchResult.anime_status.title}
          >
            {search_data.searchResult.anime_status.title}
          </div>
          <div className="small-info-el">
            {search_data.searchResult.type.name}
          </div>
          <div className="small-info-el">{search_data.searchResult.year}</div>
        </div>

        <p className="description">{search_data.searchResult.description}</p>
      </div>
    </a>
  );
}

function SearchDataList(array: Search[]) {
  if (!array) {
    return <div>Loading...</div>;
  }
  return (
    <div className="anime-list">
      {array.map((obj, i) => (
        <div key={i}>{AnimePlate(obj)}</div>
      ))}
    </div>
  );
}

export function handleKeyDown(
  event: React.KeyboardEvent<HTMLInputElement>,
  value: string
) {
  if (event.key === "Enter") {
    SearchAnime(value);
  }
}

let setListf: (list: Search[]) => void;

export default function SearchPage(props: { active: boolean }) {
  const [list, setList] = useState<Search[]>([]);
  useEffect(() => {
    setListf = (val: Search[]) => setList(val);
  }, []);
  return (
    <div className={props.active ? "active" : "inactive"}>
      {SearchDataList(list)}
    </div>
  );
}
