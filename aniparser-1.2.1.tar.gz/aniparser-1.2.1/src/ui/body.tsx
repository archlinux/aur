import "./body.css";
import SearchPage from "./components/AnimeSearchPage";
import { BodyType } from "./types";
import AnimePage from "./components/AnimePage";
import { useState, useEffect } from "react";
import { Anime } from "../api/source/Yumme_anime_ru";
import { Player } from "./components/player";
import Header from "./components/Header";

export let set_body_type: (type: BodyType) => void;
export let handle_esc_key: () => void;

export let openAnimePage: (anime: Anime) => void;
export let closeAnimePage: () => void;
export let closeAllAnimes: () => void;
export let setLoading: (loading: boolean) => void;
export let playAnime: (anime: Anime) => void;
export let closePlayer: () => void;
export default function BodyElement() {
  const [body_type, setBodyType] = useState<BodyType>(BodyType.Search);
  const [animeList, setAnimeList] = useState<Anime[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [nowAnime, setNowAnime] = useState<Anime | null>(null);

  useEffect(() => {
    set_body_type = (type: BodyType) => {
      setBodyType(type);
    };
    openAnimePage = (anime: Anime) => {
      console.log("openAnimePage");
      console.log(animeList);
      setAnimeList([...animeList, anime]);
      console.log("done");
    };
    closeAnimePage = () => {
      setAnimeList((prev) => prev.slice(0, -1));
    };
    setLoading = (loading: boolean) => {
      setIsLoading(loading);
    };
    closeAllAnimes = () => {
      setAnimeList([]);
    };
    playAnime = (anime: Anime) => {
      setNowAnime(anime);
    };
    closePlayer = () => {
      setNowAnime(null);
    };
    handle_esc_key = () => {
      if (nowAnime) {
        closePlayer();
      } else {
        closeAnimePage();
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        handle_esc_key();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [nowAnime, animeList]);

  return (
    <>
      <Header />
      <SearchPage
        active={
          body_type === BodyType.Search && !isLoading && animeList.length == 0
        }
      />
      <div className={nowAnime ? "inactive" : "active"}>
        <AnimePage isLoading={isLoading} animeList={animeList} />
      </div>
      {nowAnime && <Player anime={nowAnime} />}
    </>
  );
}
