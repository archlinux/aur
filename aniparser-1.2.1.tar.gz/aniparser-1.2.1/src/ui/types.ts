export enum BodyType {
  Search,
  Ongoing,
  Starred,
}
