import "./App.css";
import BodyElement from "./body";

function App() {
  return (
    <main className="container">
      <BodyElement />
    </main>
  );
}

export default App;
