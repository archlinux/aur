#!/bin/sh
#
# End-to-end test suite for pass-pqp.
#
# Uses a temporary keyring and a temporary store, and exercises every
# subcommand. No decryption passphrase is needed because the test key is
# generated with `--no-passphrase` and PASS_PQP_NO_PASSPHRASE is set.
#
# The `pqp` binary can be overridden with PASS_PQP_PQP_BIN.
# Run with a specific shell:  bash tests/run-tests.sh  |  zsh tests/run-tests.sh

set -e

PASS_PQP_PQP_BIN="${PASS_PQP_PQP_BIN:-pqp}"
export PASS_PQP_PQP_BIN PASS_PQP_NO_PASSPHRASE=1

WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/pass-pqp-test.XXXXXX")"
trap 'rm -rf "$WORKDIR"' EXIT

export KEYRING_PATH="$WORKDIR/keyring"
export PASSWORD_STORE_DIR="$WORKDIR/store"
export HOME="$WORKDIR/home"
mkdir -p "$HOME"

PP="$(cd "$(dirname "$0")/.." && pwd)/pass-pqp"

fail() {
	echo "FAIL: $*" >&2
	exit 1
}

keyid=$("$PASS_PQP_PQP_BIN" gen-key -u "test@example.com" --no-passphrase --compress none 2>/dev/null |
	sed -n 's/^Generated key pair: key-id=\(.*\)$/\1/p')
[ -n "$keyid" ] || fail "could not generate test key"

"$PP" init "$keyid" >/dev/null 2>&1 || fail "init"

# --- insert variants ---------------------------------------------------------
printf 'silent-pass\nsilent-pass\n' | "$PP" insert website/one >/dev/null 2>&1 || fail "insert (silent)"
printf 'echo-pass\n' | "$PP" insert -e website/two >/dev/null 2>&1 || fail "insert -e"
printf 'ml-1\nml-2\nml-3\n' | "$PP" insert -m notes/todo >/dev/null 2>&1 || fail "insert -m"

# --- show ---------------------------------------------------------------------
[ "$("$PP" show website/one)" = "silent-pass" ] || fail "show website/one"
[ "$("$PP" show website/two)" = "echo-pass" ] || fail "show website/two"
[ "$("$PP" show notes/todo | wc -l)" -eq 3 ] || fail "show notes/todo multiline"

# --- generate -----------------------------------------------------------------
generated=$("$PP" generate -n email/tok 20 | tail -1 | sed 's/\x1b\[[0-9;]*m//g')
[ "${#generated}" -eq 20 ] || fail "generate length"

# --- find / grep ---------------------------------------------------------------
"$PP" find one | grep -q website/one || fail "find one"
"$PP" grep ml-2 | grep -q todo || fail "grep ml-2"

# --- cp / mv / rm --------------------------------------------------------------
"$PP" cp website/one website/three >/dev/null 2>&1 || fail "cp"
[ "$("$PP" show website/three)" = "silent-pass" ] || fail "cp decrypt"
"$PP" mv website/three website/four >/dev/null 2>&1 || fail "mv"
[ "$("$PP" show website/four)" = "silent-pass" ] || fail "mv decrypt"
[ ! -e "$PASSWORD_STORE_DIR/website/three.pqp.enc" ] || fail "mv removed source"
"$PP" rm -f website/four >/dev/null 2>&1 || fail "rm"
[ ! -e "$PASSWORD_STORE_DIR/website/four.pqp.enc" ] || fail "rm removed file"

# --- edit ----------------------------------------------------------------------
fake_editor="$WORKDIR/editor"
printf '#!/bin/sh\nprintf "edited-content\\n" > "$1"\n' > "$fake_editor"
chmod +x "$fake_editor"
EDITOR="$fake_editor" "$PP" edit notes/todo >/dev/null 2>&1 || fail "edit"
[ "$("$PP" show notes/todo)" = "edited-content" ] || fail "edit decrypt"

# --- init --path with a second key -----------------------------------------------
keyid2=$("$PASS_PQP_PQP_BIN" gen-key -u "second@example.com" --no-passphrase --compress none 2>/dev/null |
	sed -n 's/^Generated key pair: key-id=\(.*\)$/\1/p')
"$PP" init -p team "$keyid2" >/dev/null 2>&1 || fail "init --path"
[ "$(cat "$PASSWORD_STORE_DIR/team/.pqp-id")" = "$keyid2" ] || fail "team gpg-id"

# re-encryption on move across folders
printf 'rootpass\nrootpass\n' | "$PP" insert root/secret >/dev/null 2>&1 || fail "insert root/secret"
"$PP" mv root/secret team/fromroot >/dev/null 2>&1 || fail "mv across folders"
[ "$("$PP" show team/fromroot)" = "rootpass" ] || fail "re-encrypt across folders"

# --- ls -------------------------------------------------------------------------
"$PP" ls | grep -q "── team" || fail "ls tree"

# --- git ------------------------------------------------------------------------
"$PP" git log --oneline | grep -q "Add given password" || fail "git log has commits"
grep -q "diff=pqp" "$PASSWORD_STORE_DIR/.gitattributes" || fail "gitattributes"

# --- ls with no subcommand --------------------------------------------------------
"$PP" | grep -q "Password Store" || fail "bare ls"

echo "ALL TESTS PASSED"
