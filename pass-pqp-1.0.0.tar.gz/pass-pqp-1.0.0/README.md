# pass-pqp 🔐🛡️

**A pass-compatible password store backed by PQP quantum-safe crypto.**

`pass-pqp` is a drop-in replacement for the classic [`pass`](https://www.passwordstore.org/)
command line, but instead of GPG it encrypts every secret with
[`pqp`](https://github.com/ajdiaz/pqp) — a quantum-resistant stack built on
**ML-KEM** (Kyber) + **ML-DSA** (Dilithium) + **XChaCha20-Poly1305**.

> 🧑‍💻 Same muscle memory you already have. 🤖 Different (quantum-safe) brain.
> Everything is still stored in a **git repository**, so history, sync and
> audit trails work exactly like you expect.

---

## ✨ Why pass-pqp?

- 🧮 **Post-quantum cryptography** — ML-KEM-768 key encapsulation and ML-DSA-65 signatures protect your secrets against harvest-now-decrypt-later attacks.
- 🔑 **No GPG agent, no key servers** — just `pqp` key pairs living in your keyring (`~/.pqp/keys` by default).
- 📦 **A real git repository** — every mutation is committed with a descriptive message. Sync over SSH/GitHub with plain `git`.
- 🐚 **Pure POSIX shell** — no bashisms, no dependencies beyond `pqp`, `git`, and a few standard tools. Runs under `sh`, `bash`, `ksh` and `zsh`.
- 🕶️ **`pass` compatible CLI** — `init`, `ls`, `show`, `insert`, `edit`, `generate`, `grep`, `find`, `cp`, `mv`, `rm`, `git` … you already know how to use it.

---

## 📦 Requirements

- [`pqp`](https://github.com/ajdiaz/pqp) binary in your `PATH` (or `PASS_PQP_PQP_BIN`)
- `git` in your `PATH` (or `PASS_PQP_GIT_BIN`)
- `base64`, `mktemp`, `find`, `sed`, `grep`, `tr` — all standard on any POSIX system
- Optional for clipboard: `wl-copy`/`wl-paste` (Wayland) or `xclip` (X11)
- Optional for QR codes: `qrencode` (+ `feh`, `gm` or ImageMagick `display`)

### 🔑 Generating your key pair

Keys are managed with `pqp` itself:

```console
$ pqp gen-key -u "alice@example.com"
Enter passphrase for new key: ********
Confirm passphrase: ********
Generated key pair: key-id=871aecd02a3e12a9
  user-id: alice@example.com
  kem: ML-KEM-768
  dsa: ML-DSA-65
  ...
```

> 🔒 The secret key material is always encrypted at rest with a passphrase
> derived through Argon2id. Nothing raw ever touches disk.

---

## 🚀 Quick start

```console
$ pass-pqp init alice@example.com
Password store initialized for alice@example.com
[master (root-commit) 29d330e] Configure git repository for pqp file diff.
[master 992a32d] Set PQP id to alice@example.com.
```

Add a password (it's confirmed twice, so nothing is mistyped):

```console
$ pass-pqp insert email/github
Enter password for email/github:
Retype password for email/github:
[master a906d1c] Add given password for email/github to store.
```

Show it back:

```console
$ pass-pqp email/github          # `show` is the default command
hunter2-was-taken-😉
```

List the store:

```console
$ pass-pqp
Password Store
├── email
│   ├── github
│   └── work
└── server
    └── raspberry-pi
```

Generate a strong one and put it on the clipboard (auto-clears after 45s):

```console
$ pass-pqp generate -c email/aws 32
Copied email/aws to clipboard. Will clear in 45 seconds.
```

---

## 🎮 Command reference

| Command | Description |
| --- | --- |
| `pass-pqp init [--path=sub,-p sub] key-id` | Initialize the store (or a subfolder) for a PQP key id. Re-encrypts existing entries. Passing an empty id de-initializes. |
| `pass-pqp [ls] [subfolder]` | List the password tree. `pass-pqp` with no arguments lists the whole store. |
| `pass-pqp [show] [-c[line]\|--clip[=line]] pass-name` | Decrypt and print an entry. `-c` copies a single line to the clipboard, `-q` renders it as a QR code. |
| `pass-pqp find pass-names...` | List entries whose names match any of the given terms. |
| `pass-pqp grep [options] string` | Decrypt every entry and grep the plaintext (supports grep options like `-i`, `-n`). |
| `pass-pqp insert [-e\|-m] [-f] pass-name` | Insert a new entry. `-e` echoes input, `-m` reads multi-line until Ctrl+D, `-f` skips the overwrite prompt. |
| `pass-pqp edit pass-name` | Edit an entry in `${EDITOR:-vi}`. Aborts if unchanged. |
| `pass-pqp generate [-n] [-c\|-q] [-i\|-f] pass-name [len]` | Generate a random password of `len` (default 25). `-n` = no symbols, `-c`/`-q` = clipboard/QR, `-i` replaces only the first line of an existing entry. |
| `pass-pqp rm [-r] [-f] pass-name` | Remove an entry (or whole folder with `-r`). |
| `pass-pqp cp [-f] old new` / `pass-pqp mv [-f] old new` | Copy or move an entry, re-encrypting it when the target folder uses a different key. |
| `pass-pqp git git-args...` | Run any git command in the store (e.g. `pass-pqp git log`, `pass-pqp git push`). |
| `pass-pqp help` / `pass-pqp version` | Show usage / version banner. |

Every mutation (`insert`, `generate`, `edit`, `rm`, `cp`, `mv`, `init`, …)
creates an automatic git commit — history is your audit log. 📜

---

## 🧪 Realistic session

```console
$ pass-pqp init alice@example.com
Password store initialized for alice@example.com

$ pass-pqp insert -m wifi/home
Enter contents of wifi/home and press Ctrl+D when finished:

ssid: MyRouter
password: 0h-n0-4-guest!
frequency: 5GHz

$ pass-pqp generate -n email/aws 40
The generated password for email/aws is:
pWk9cXq2TzLmNvB7RfGhJdY3SaZx5Cv8QeWrAs6Df

$ pass-pqp grep -i router
wifi/home:
ssid: MyRouter

$ pass-pqp cp email/aws email/aws-backup
'.../email/aws.pqp.enc' -> '.../email/aws-backup.pqp.enc'
[master d3f2a1b] Copy email/aws to email/aws-backup.

$ pass-pqp git log --oneline
d3f2a1b Copy email/aws to email/aws-backup.
9cc087c Add given password for email/aws to store.
...
```

---

## 🌳 Per-folder encryption keys

Like `pass`, each subfolder can use its own recipient key. Drop a `.pqp-id`
file in a subfolder and that subtree is encrypted to a different key:

```console
$ pass-pqp init alice@example.com                     # whole store → Alice
$ pass-pqp init -p team bob@example.com               # team/ → Bob
$ pass-pqp mv email/aws team/aws                      # re-encrypted to Bob automatically
```

> ⚠️ **One recipient per folder.** `pqp encrypt` takes a single recipient key,
> so `pass-pqp` uses the **first non-comment line** of `.pqp-id`. This is the
> main deliberate deviation from `pass`, which supports multi-recipient GPG.

---

## 🧰 Environment variables

All of `pass`'s knobs work, plus a few new ones:

| Variable | Default | Purpose |
| --- | --- | --- |
| `PASSWORD_STORE_DIR` | `~/.password-store` | Store location. |
| `PASSWORD_STORE_UMASK` | `077` | File permission mask. |
| `PASSWORD_STORE_KEY` | — | Override the recipient for every operation. |
| `PASSWORD_STORE_GENERATED_LENGTH` | `25` | Default generated password length. |
| `PASSWORD_STORE_CHARACTER_SET` | `[:punct:][:alnum:]` | Characters used by `generate`. |
| `PASSWORD_STORE_CHARACTER_SET_NO_SYMBOLS` | `[:alnum:]` | Characters used by `generate -n`. |
| `PASSWORD_STORE_CLIP_TIME` | `45` | Seconds before the clipboard is cleared. |
| `PASSWORD_STORE_X_SELECTION` | `clipboard` | X11 selection used by `xclip`. |
| `PASS_PQP_PQP_BIN` | `pqp` | Path to the `pqp` binary. |
| `PASS_PQP_GIT_BIN` | `git` | Path to the `git` binary. |
| `PASS_PQP_NO_PASSPHRASE` | `0` | Set to `1` to pass `--no-passphrase` on every decryption (CI/automation with passphrase-less keys). |
| `PASS_PQP_PASSWORD_TOOL` | — | External passphrase prompt tool (e.g. `pinentry`, `ssh-askpass`) passed as `--password-tool` on every decryption. Use this when your key has a passphrase and you run from a non-interactive session. |
| `PASS_PQP_ALLOW_EXPIRED` | `0` | Set to `1` to pass `--allow-expired` on every encryption. |

---

## 🧯 Troubleshooting

- **"You must run `pass-pqp init …`"** — the store (or the target folder) has no
  `.pqp-id`. Run `pass-pqp init your-key-id` first.
- **"decryption failed: no matching key or wrong passphrase"** — the recipient
  key isn't in your keyring, or the passphrase is wrong.
- **"Enter passphrase for secret key:" on every read** — that's PQP by design
  (no agent caching yet). Set `PASS_PQP_NO_PASSPHRASE=1` when your key has an
  empty passphrase, or `PASS_PQP_PASSWORD_TOOL=pinentry` to hand the prompt to
  an external tool.
- **Clipboard says "No X11 or Wayland display detected"** — install `wl-clipboard`
  or `xclip`, or run under a graphical session.

---

## 🚚 Migrating from `pass`

Already using the classic GPG-based `pass`? The bundled
`contrib/pass-pqp-migrate` script converts your whole store in one shot —
same secrets, same folder layout, just re-encrypted with PQP.

```console
$ pass-pqp-migrate --map "alice@example.com:871aecd02a3e12a9"
Migrating pass store:
  from: /home/alice/.password-store
  to:   /home/alice/.password-store-pqp
  wrote /home/alice/.password-store-pqp/.pqp-id = 871aecd02a3e12a9
  migrated: websites/github.gpg -> websites/github.pqp.enc
  migrated: email/gmail/primary.gpg -> email/gmail/primary.pqp.enc
Migration complete: 2 entries migrated to /home/alice/.password-store-pqp.
```

Every `.gpg` entry is decrypted with `gpg` and re-encrypted with `pqp`, and
each `.gpg-id` becomes a `.pqp-id`. Recipients are resolved automatically
when a PQP key's user id matches, or explicitly via `--map`, `--map-file`,
or `--default`:

```console
$ pass-pqp-migrate -y --map-file my-map.txt --default 871aecd02a3e12a9
```

Then point `PASSWORD_STORE_DIR` at the new store and carry on with
`pass-pqp` — the destination is already a git repository with the migration
committed. See `man pass-pqp-migrate` for the full option reference.

---

## 📚 Docs & completion

- Man page: `man/pass-pqp.1`
- Migration man page: `man/pass-pqp-migrate.1`
- Shell completion: `completions/pass-pqp.{bash,zsh,fish}`

Install everything with `make install` (defaults to `PREFIX=/usr/local`).

## 🔗 Links

- 🏠 Project: <https://github.com/ajdiaz/pass-pqp>
- 🧮 Backend: <https://github.com/ajdiaz/pqp>

## 🧑‍⚖️ License

MIT.
