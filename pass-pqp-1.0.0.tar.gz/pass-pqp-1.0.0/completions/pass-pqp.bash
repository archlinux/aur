# bash completion for pass-pqp
_pass_pqp() {
    local cur prev words commands
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    commands="init ls list find grep show insert add edit generate rm remove delete mv rename cp copy git help version"

    if [ "$COMP_CWORD" -eq 1 ]; then
        COMPREPLY=($(compgen -W "$commands" -- "$cur"))
        return 0
    fi

    case "${COMP_WORDS[1]}" in
        show|ls|list|find|grep|insert|add|edit|rm|remove|delete|mv|rename|cp|copy|generate)
            case "$prev" in
                -c|-q|--clip|--qrcode|-p|--path|-f|--force|-e|--echo|-m|--multiline|-n|--no-symbols|-i|--in-place|-r|--recursive)
                    return 0 ;;
            esac
            COMPREPLY=($(compgen -W "$(_pass_pqp_names)" -- "$cur"))
            return 0
            ;;
        init)
            COMPREPLY=($(compgen -W "-p --path" -- "$cur"))
            return 0
            ;;
        git)
            COMPREPLY=($(compgen -W "$(git -C "${PASSWORD_STORE_DIR:-$HOME/.password-store}" help -a 2>/dev/null | tr '\n' ' ')" -- "$cur"))
            return 0
            ;;
    esac
    return 0
}

_pass_pqp_names() {
    local dir="${PASSWORD_STORE_DIR:-$HOME/.password-store}"
    find "$dir" -path '*/.git' -prune -o -type f -name '*.pqp.enc' -print 2>/dev/null |
        sed -e "s#^$dir/##" -e 's#\.pqp\.enc$##'
}

complete -F _pass_pqp pass-pqp
