#compdef pass-pqp
# zsh completion for pass-pqp

_pass_pqp() {
    local -a commands
    commands=(
        'init:Initialize password storage for a PQP key id'
        'ls:List passwords'
        'list:List passwords'
        'find:List passwords that match pass-names'
        'grep:Search password files for a string'
        'show:Show an existing password'
        'insert:Insert a new password'
        'add:Insert a new password'
        'edit:Insert or edit a password'
        'generate:Generate a new password'
        'rm:Remove a password or directory'
        'remove:Remove a password or directory'
        'delete:Remove a password or directory'
        'mv:Rename or move a password'
        'rename:Rename or move a password'
        'cp:Copy a password'
        'copy:Copy a password'
        'git:Run a git command in the store'
        'help:Show usage'
        'version:Show version information'
    )

    if (( CURRENT == 2 )); then
        _describe 'command' commands
        return
    fi

    case $words[2] in
        show|ls|list|find|grep|insert|add|edit|rm|remove|delete|mv|rename|cp|copy|generate)
            _arguments -C \
                '(-c --clip)'{-c,--clip}'[copy password to clipboard]' \
                '(-q --qrcode)'{-q,--qrcode}'[show password as QR code]' \
                '(-f --force)'{-f,--force}'[do not prompt]' \
                '(-e --echo)'{-e,--echo}'[echo password while entering]' \
                '(-m --multiline)'{-m,--multiline}'[enter multiline password]' \
                '(-n --no-symbols)'{-n,--no-symbols}'[generate password without symbols]' \
                '(-i --in-place)'{-i,--in-place}'[replace only the first line]' \
                '(-r --recursive)'{-r,--recursive}'[remove directories recursively]' \
                "1:password name:_pass_pqp_names" && return
            ;;
        init)
            _arguments -C \
                '(-p --path)'{-p,--path}'[initialize a subfolder]:subfolder' \
                "1:PQP key id" && return
            ;;
        git)
            local -a git_cmds
            git_cmds=(${(f)"$(_call_program git-commands git -C "${PASSWORD_STORE_DIR:-$HOME/.password-store}" help -a 2>/dev/null | tr ' ' '\n')"})
            _describe 'git command' git_cmds && return
            ;;
    esac
    _files
}

_pass_pqp_names() {
    local dir="${PASSWORD_STORE_DIR:-$HOME/.password-store}"
    find "$dir" -path '*/.git' -prune -o -type f -name '*.pqp.enc' -print 2>/dev/null |
        sed -e "s#^$dir/##" -e 's#\.pqp\.enc$##'
}

_pass_pqp "$@"
