# fish completion for pass-pqp
function __pass_pqp_commands
    printf '%s\n' init ls list find grep show insert add edit generate rm remove delete mv rename cp copy git help version
end

function __pass_pqp_names
    set -l dir (string length "$PASSWORD_STORE_DIR" >/dev/null; echo "$PASSWORD_STORE_DIR")
    if test -z "$dir"
        set dir "$HOME/.password-store"
    end
    find "$dir" -path '*/.git' -prune -o -type f -name '*.pqp.enc' -print 2>/dev/null |
        sed -e "s#^$dir/##" -e 's#\.pqp\.enc$##'
end

function __pass_pqp_has_command
    for cmd in (__pass_pqp_commands)
        if __fish_seen_subcommand_from $cmd
            return 0
        end
    end
    return 1
end

complete -c pass-pqp -f
complete -c pass-pqp -n "not __fish_seen_subcommand_from (__pass_pqp_commands)" -a "(__pass_pqp_commands)" -d 'pass-pqp command'

complete -c pass-pqp -n "__fish_seen_subcommand_from show ls list find grep insert add edit rm remove delete mv rename cp copy generate" -a "(__pass_pqp_names)" -d 'password name'
complete -c pass-pqp -n "__fish_seen_subcommand_from show" -s c -l clip -d 'copy password to clipboard' -a 'line number'
complete -c pass-pqp -n "__fish_seen_subcommand_from show" -s q -l qrcode -d 'show password as QR code' -a 'line number'
complete -c pass-pqp -n "__fish_seen_subcommand_from insert add" -s e -l echo -d 'echo password while entering'
complete -c pass-pqp -n "__fish_seen_subcommand_from insert add" -s m -l multiline -d 'enter multiline password'
complete -c pass-pqp -n "__fish_seen_subcommand_from insert add generate edit rm remove delete cp copy mv rename" -s f -l force -d 'do not prompt'
complete -c pass-pqp -n "__fish_seen_subcommand_from generate" -s n -l no-symbols -d 'generate without symbols'
complete -c pass-pqp -n "__fish_seen_subcommand_from generate" -s i -l in-place -d 'replace only the first line'
complete -c pass-pqp -n "__fish_seen_subcommand_from rm remove delete" -s r -l recursive -d 'remove directories recursively'
complete -c pass-pqp -n "__fish_seen_subcommand_from init" -s p -l path -d 'initialize a subfolder' -a '(printf "%s\n" (__fish_complete_directories))'
