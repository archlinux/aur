module ghpkg
import json
import os

pub fn check()
{
  println("Checking binaries...")

  // Find binary location
  mut bin_location := ''
  $if linux || macos {
    bin_location = '/usr/local/bin/'
  } $else $if windows {
    // Use a local Programs folder in %LOCALAPPDATA% 
    local_appdata := os.getenv('LOCALAPPDATA')
    if local_appdata == '' {
      eprintln('Could not detect LOCALAPPDATA, using C:\\Temp')
      bin_location = 'C:\\Temp\\'
    } else {
      bin_location = "${local_appdata.replace('\\', '/')}/ghpkg/bin"
      // Ensure the folder exists
      os.mkdir_all(os.dir(bin_location)) or {
        eprintln('Failed to create target folder: $err')
        return
      }
    }
  }

  // Join db_path together
  mut db_path := ''
  $if windows {
    db_path = "${os.getenv("LOCALAPPDATA").replace('\\', '/')}/ghpkg/db.json"
  } $else {
    db_path = os.join_path("/etc", "ghpkg", "db.json")
  }
  println("DB path: $db_path")

  // Parse db as db_raw
  db_raw_in := os.read_file(db_path) or {
    eprintln("Could not open db.json: $err")
    return
  }

  // Parse db_raw as db_json
  mut db_json := json.decode([]Db, db_raw_in) or {
    eprintln("Failed to decode JSON: $err")
    return
  }

  // Iterate over db_json and remove entries with missing binaries
  mut updated_db := []Db{}  // new list to hold entries that exist

  for pkg in db_json {
    // Determine expected binary path
    mut bin_path := ''
    $if linux || macos {
      bin_path = os.join_path(bin_location, pkg.binary_name)
    } $else $if windows {
      bin_path = os.join_path(bin_location, pkg.binary_name)
    }

    // Check if binary exists
    if os.exists(bin_path) {
      updated_db << pkg  // keep this entry
      println("${pkg.name}: binary exists at $bin_path")
    } else {
      println("${pkg.name}: binary missing at $bin_path, removing from db.json")
    }
  }

  // Save updated list back to db.json
  db_raw_out := json.encode_pretty(updated_db)
  os.write_file(db_path, db_raw_out) or {
    eprintln("Failed to update db.json: $err")
    return
  }
}
