module ghpkg
import json
import os

pub fn remove_package(pkg_name_imut string)
{
  // Find binary location
  mut bin_target := ''
  $if linux || macos {
    bin_target = '/usr/local/bin/' + pkg_name_imut
  } $else $if windows {
    // Use a local Programs folder in %LOCALAPPDATA% 
    local_appdata := os.getenv('LOCALAPPDATA')
    if local_appdata == '' {
      eprintln('Could not detect LOCALAPPDATA, using C:\\Temp')
      bin_target = 'C:/Temp/' + pkg_name_imut
    } else {
      bin_target = "${local_appdata.replace('\\', '/')}/ghpkg/bin/${pkg_name_imut}.exe"
      // Ensure the folder exists
      os.mkdir_all(os.dir(bin_target)) or {
        eprintln('Failed to create target folder: $err')
        return
      }
    }
  }

  // Join db_path together
  mut db_path := ''
  $if windows {
    db_path = "${os.getenv("LOCALAPPDATA").replace('\\', '/')}/ghpkg/db.json"
  } $else {
    db_path = os.join_path("/etc", "ghpkg", "db.json")
  }
    println("DB path: $db_path")

  // Parse db.json as db_raw_in
  db_raw_in := os.read_file(db_path) or {
    eprintln("Could not open db.json: $err")
    return
  }

  // Parse db_raw_in as db_json
  mut db_json := json.decode([]Db, db_raw_in) or {
    eprintln("Failed to parse JSON: $err")
    return
  }

  // Search for pkg_name_imut in db_json
  db_json = db_json.filter(it.name != pkg_name_imut)

  // Encode db.json as db_raw_out
  db_raw_out := json.encode_pretty(db_json)

  // Save db.json
  os.write_file(db_path, db_raw_out) or {
    eprintln("Failed to save db.json: $err")
    return
  }

  println("Removed entry from db.json")

  // Remove binary
  os.rm(bin_target) or { eprintln("Failed to remove binary: $err") }
  println("Removed binary from ${bin_target}")
}
