Module {
	name: 'test'
	description: 'Indev package manager'
	version: '1.0.0'
	license: 'MIT'
	dependencies: ['git']
}
