# Examples

## autoshift example and mod remaping for laptop example
```yaml
TIMING:
  TAP_MILLISEC: 160
FEATURES:
  AUTOSHIFT: 15

MAPPINGS:
  baselayer:
    - KEY: KEY_J
      TAP: KEY_J
      DOUBLETAP: KEY_ESC
#on dvorak layout key_e is equivalant to a period
    - KEY: KEY_LEFTALT
      TAP: KEY_E
      HOLD: KEY_LEFTALT
#make caps key compose key without losing caps functionallity
#scrolllock since it does not exist on my keyboard and therefore is a free modifier compatible with xkb compose
    - KEY: KEY_CAPSLOCK
      TAP: KEY_SCROLLLOCK
    - KEY: KEY_RIGHTALT
      TAP: KEY_MENU
      HOLD: KEY_RIGHTALT
#swap so on dvorak little fingers dont have to be moved
    - KEY: KEY_W
      TAP: KEY_P
    - KEY: KEY_P
      TAP: KEY_W

    - KEY: KEY_E
      TAP: KEY_SLASH
    - KEY: KEY_SLASH
      TAP: KEY_E
```
