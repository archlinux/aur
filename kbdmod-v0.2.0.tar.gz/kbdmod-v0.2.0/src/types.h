#pragma once
#include <bits/stdint-uintn.h>

typedef uint16_t TypeOutputConf;
typedef uint8_t KeyCode;
