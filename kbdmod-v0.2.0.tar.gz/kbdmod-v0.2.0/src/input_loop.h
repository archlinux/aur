#pragma once
#include "timer.h"
#include "mapping.h"
#include <linux/input.h>
#include "io.h"
#include "layer.h"
#include "command.h"

extern void input_loop();
