#define CCALC_VERSION "1.6.5"

#ifdef DEBUG
    #define CCALC_RELEASE CCALC_VERSION " DEBUG"
#else
    #define CCALC_RELEASE CCALC_VERSION
#endif

#define COPYRIGHT_NOTICE "ccalc " CCALC_RELEASE " Copyright (C) 2018-2021 Philipp Hochmann, phil.hochmann@gmail.com\n"
