# hello-world-alpha
Prints: Hello World.

## Usage

```
autoreconf --install
./configure 
make
src/hello 
```
