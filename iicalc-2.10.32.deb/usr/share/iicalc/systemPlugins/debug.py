def out(msg,tf):
	if(tf):
		print(msg)
