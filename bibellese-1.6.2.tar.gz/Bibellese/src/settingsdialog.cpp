#include <QSettings>

#include "settingsdialog.h"
#include "ui_settingsdialog.h"

SettingsDialog::SettingsDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SettingsDialog)
{
    ui->setupUi(this);
    readSettings();
}

SettingsDialog::~SettingsDialog()
{
    delete ui;
}

void SettingsDialog::saveSettings()
{
    QSettings settings;
    settings.setValue("oeab/start_hour", ui->timeEditOeab->dateTime().time().hour());
    settings.setValue("oeab/start_minute", ui->timeEditOeab->dateTime().time().minute());
    settings.setValue("oeab/duration", ui->spinBoxOeab->value());
    settings.setValue("jahresbibel/start_hour", ui->timeEditJahr->dateTime().time().hour());
    settings.setValue("jahresbibel/start_minute", ui->timeEditJahr->dateTime().time().minute());
    settings.setValue("jahresbibel/duration", ui->spinBoxJahr->value());
    QDialog::accept();
}

void SettingsDialog::readSettings()
{
    QSettings settings;
    ui->timeEditOeab->setTime(QTime(settings.value("oeab/start_hour", 6).toInt(),
                                    settings.value("oeab/start_minute", 0).toInt(),
                                    0));
    ui->spinBoxOeab->setValue(settings.value("oeab/duration", 30).toInt());
    ui->timeEditJahr->setTime(QTime(settings.value("jahresbibel/start_hour", 21).toInt(),
                                    settings.value("jahresbibel/start_minute", 30).toInt(),
                                    0));
    ui->spinBoxJahr->setValue(settings.value("jahresbibel/duration", 45).toInt());

}
