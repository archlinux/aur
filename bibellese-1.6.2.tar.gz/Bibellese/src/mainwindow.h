#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <map>
#include <string>

#include <QMainWindow>

#include "leseplan.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void new_oeab_plan(QAction *action);
    void newJahresbibelPlan();
    void newPerikopenPlan(QAction *action);
    void showSettings();
    void showLicense();
    void exportToIcal();
    void aboutProg();
    void aboutQt();
    
private slots:
    void on_pbExport_clicked();

private:
    void updateTable();
    Ui::MainWindow *ui;
    std::map<std::string, std::string> mDateiMap;
    Leseplan *mLeseplan;
};

#endif // MAINWINDOW_H
