#include <iostream>
#include <fstream>
#include <sstream>

#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>

#include "perikopen.h"
#include <config.h>


Perikopen::Perikopen() : Perikopen(boost::gregorian::day_clock::local_day().year())
{
}

Perikopen::Perikopen(int year) : mYear(year)
{
    mTitel.push_back("Liturgischer Tag");
    mTitel.push_back("Bibelstelle(n)");

    calcKirchenjahr(year - 1);
    auslesen();
    appendBibelstellen();
    mLitDates.clear();
    calcKirchenjahr(year);
    auslesen();
    appendBibelstellen();
}

struct BibelstelleComparer
{
  bool operator()(Bibelstelle const& lhs, Bibelstelle const& rhs) const
  {
      if (lhs.getDatum() < rhs.getDatum())
              return true;
      else if (lhs.getDatum() > rhs.getDatum())
              return false;
      else
          return false;
  }
};


const std::vector<Bibelstelle> Perikopen::getBibelstellen()
{
//    std::vector<Bibelstelle> stellen;
//    for(auto item: mLitDates)
//    {
//        Bibelstelle stelle(item.second.getDate());
//        stelle.addBibelstelle(item.first);
//        stelle.addBibelstelle(item.second.getText());
//        stellen.push_back(stelle);
//    }
//    std::sort(stellen.begin(), stellen.end(), BibelstelleComparer());

//    return stellen;
    return mBibelstellen;
}

boost::gregorian::greg_year Perikopen::getJahr()
{
    return mYear;
}

void Perikopen::calcKirchenjahr(int start_year)
{
    boost::gregorian::date start(start_year, 11, 26);
    while (start.day_of_week() != 0)
    {
        start += boost::gregorian::days(1);
    }
    mLitDates["1Adv"] = LiturgischerTag(start);
    start += boost::gregorian::days(7);
    mLitDates["2Adv"] = LiturgischerTag(start);
    start += boost::gregorian::days(7);
    mLitDates["3Adv"] = LiturgischerTag(start);
    start += boost::gregorian::days(7);
    mLitDates["4Adv"] = LiturgischerTag(start);
    start = boost::gregorian::date(start_year, 12, 24);
    mLitDates["ChristV"] = LiturgischerTag(start);
    mLitDates["ChristN"] = LiturgischerTag(start);
    start += boost::gregorian::days(1);
    mLitDates["ChristF (I)"] = LiturgischerTag(start);
    start += boost::gregorian::days(1);
    mLitDates["ChristF (II)"] = LiturgischerTag(start);
    boost::gregorian::date tmpDate = mLitDates["ChristF (II)"].getDate();
    while(tmpDate.day_of_week() != 0)
    {
        tmpDate += boost::gregorian::days(1);
    }
    start = boost::gregorian::date(start_year, 12, 31);
    mLitDates["AltjA"] = LiturgischerTag(start);
    start += boost::gregorian::days(1);
    mLitDates["Neuj"] = LiturgischerTag(start);
    mLitDates["Epiph"] = LiturgischerTag(boost::gregorian::date(mLitDates["Neuj"].getDate().year(), 1, 6));

    // Calculate 1st and 2nd sunday after Christfest and before Epiphanias
    // Note that Altjahresabend and Neujahr have higher priorities than [1,2]nChristF
    {
        int i = 1;
        while(tmpDate < mLitDates["Epiph"].getDate())
        {
            if (tmpDate != mLitDates["AltjA"].getDate() && tmpDate != mLitDates["Neuj"].getDate())
            {
                mLitDates[boost::lexical_cast<std::string>(i) + "nChristF"] = tmpDate;
                ++i;
            }
            tmpDate += boost::gregorian::days(7);
        }
    }
    tmpDate = mLitDates["Epiph"].getDate();
    while(tmpDate.day_of_week() != 0)
    {
        tmpDate += boost::gregorian::days(1);
    }
    mLitDates["1nE"] = tmpDate;
    boost::gregorian::date easterDate = calcOstersonntag(start_year + 1);
    tmpDate = easterDate - boost::gregorian::days(46); // Aschermittwoch
    while(tmpDate.day_of_week() != 0)
    {
        tmpDate -= boost::gregorian::days(1);
    }
    mLitDates["Estom"] = LiturgischerTag(tmpDate);
    mLitDates["Sexa"] = LiturgischerTag(tmpDate -  boost::gregorian::days(7));
    mLitDates["Sept"] = LiturgischerTag(tmpDate -  boost::gregorian::days(14));

    // Calculate 2nd, 3rd... sundays between Epiphanias and last of Epiphanias.
    // Last of Epiphanias is the sunday before Septuagesimä
    mLitDates["LnE"] = LiturgischerTag(mLitDates["Sept"].getDate() - boost::gregorian::days(7));
    tmpDate = mLitDates["1nE"].getDate() + boost::gregorian::days(7);
    for (int i = 2; tmpDate < mLitDates["LnE"].getDate(); i++)
    {
        mLitDates[boost::lexical_cast<std::string>(i) + "nE"] = tmpDate;
        tmpDate = tmpDate + boost::gregorian::days(7);
    }
    tmpDate = easterDate - boost::gregorian::days(46); // Aschermittwoch
    while(tmpDate.day_of_week() != 0)
    {
        tmpDate += boost::gregorian::days(1);
    }
    mLitDates["Inv"] = LiturgischerTag(tmpDate);
    mLitDates["Rem"] = LiturgischerTag(tmpDate + boost::gregorian::days(7));
    mLitDates["Ok"] = LiturgischerTag(tmpDate + boost::gregorian::days(14));
    mLitDates["Lät"] = LiturgischerTag(tmpDate + boost::gregorian::days(21));
    mLitDates["Jud"] = LiturgischerTag(tmpDate + boost::gregorian::days(28));
    mLitDates["Palm"] = LiturgischerTag(easterDate - boost::gregorian::days(7));
    mLitDates["GrünD"] = LiturgischerTag(easterDate - boost::gregorian::days(3));
    mLitDates["Karfr"] = LiturgischerTag(easterDate - boost::gregorian::days(2));
    mLitDates["Karfr (II)"] = LiturgischerTag(easterDate - boost::gregorian::days(2));
    mLitDates["OsterN"] = LiturgischerTag(easterDate - boost::gregorian::days(1));
    mLitDates["OsterS"] = LiturgischerTag(easterDate);
    mLitDates["OsterM"] = LiturgischerTag(easterDate + boost::gregorian::days(1));
    mLitDates["Quas"] = LiturgischerTag(easterDate + boost::gregorian::days(7));
    mLitDates["MisDm"] = LiturgischerTag(easterDate + boost::gregorian::days(14));
    mLitDates["Jub"] = LiturgischerTag(easterDate + boost::gregorian::days(21));
    mLitDates["Kant"] = LiturgischerTag(easterDate + boost::gregorian::days(28));
    mLitDates["Rog"] = LiturgischerTag(easterDate + boost::gregorian::days(35));
    mLitDates["Himf"] = LiturgischerTag(easterDate + boost::gregorian::days(39));
    mLitDates["Ex"] = LiturgischerTag(easterDate + boost::gregorian::days(42));
    mLitDates["PfingstS"] = LiturgischerTag(easterDate + boost::gregorian::days(49));
    mLitDates["PfingstM"] = LiturgischerTag(easterDate + boost::gregorian::days(50));
    mLitDates["Trin"] = LiturgischerTag(easterDate + boost::gregorian::days(56));
    tmpDate = boost::gregorian::date(start_year + 1, 11, 26);
    while (tmpDate.day_of_week() != 0)
    {
        tmpDate += boost::gregorian::days(1);
    }
    mLitDates["DrittlS"] = LiturgischerTag(tmpDate - boost::gregorian::days(21));
    mLitDates["VorlS"] = LiturgischerTag(tmpDate - boost::gregorian::days(14));
    mLitDates["BußT"] = LiturgischerTag(tmpDate - boost::gregorian::days(11));
    mLitDates["LS"] = LiturgischerTag(tmpDate - boost::gregorian::days(7));

    // Calculate sundays after Trinitatis as long as they are earlier than "Drittletzter Sonntag im Kirchenjahr"
    for(int i = 1; i < 25; i++)
    {
        if ((mLitDates["Trin"].getDate() + boost::gregorian::days(i * 7)) < mLitDates["DrittlS"].getDate())
        {
            mLitDates[boost::lexical_cast<std::string>(i) + "nT"] = LiturgischerTag(mLitDates["Trin"].getDate() + boost::gregorian::days(i * 7));
        }
    }
    tmpDate = boost::gregorian::date(start_year + 1, 10, 1);
    while (tmpDate.day_of_week() != 0)
    {
        tmpDate += boost::gregorian::days(1);
    }
    mLitDates["Ernted"] = LiturgischerTag(tmpDate);
    mLitDates["Ref"] = boost::gregorian::date(start_year + 1, 10, 31);
}

boost::gregorian::date Perikopen::calcOstersonntag(int year)
{
    boost::gregorian::date ostersonntag(year, boost::date_time::Mar, 1);

    // Die Säkularzahl
    int k = year / 100;

    // Die säkulare Mondschaltung
    int m = 15 + (3 * k + 3) / 4 - (8 * k + 13) / 25;

    // die säkulare Sonnenschaltung
    int s = 2 - (3 * k + 3) / 4;

    // der Mondparameter
    int a = year % 19;

    // der Keim für den ersten Vollmond im FrÃ¼hling
    int d = (19 * a + m) % 30;

    // die kalendarische Korrekturgröße
    int r = d / 29 + (d / 28 - d / 29) * (a / 11);

    // die Ostergrenze
    int og = 21 + d - r;

    // der erste Sonntag im März
    int sz = 7 - (year + year / 4 + s) % 7;

    // die Entfernung des Ostersonntags von der Ostergrenze (Osterentfernung in Tagen)
    int oe = 7 - (og - sz) % 7;

    // das Datum des Ostersonntags als Märzdatum (32. März = 1. April usw.)
    int os = og + oe;

    ostersonntag = ostersonntag + boost::gregorian::days(os) - boost::gregorian::days(1);

    return ostersonntag;
}

void Perikopen::auslesen()
{
    // Predigtreihe berechnen
    int reihe = ((mLitDates["1Adv"].getDate().year() - 1996) % 6) + 1;

    // Auslesen der Predigtexte
    boost::filesystem::path pfad(std::string(INSTALL_PREFIX) + "/share/bibellese/data/perikopen.txt");
    if (!boost::filesystem::exists(pfad)) {
        pfad = boost::filesystem::current_path() /= "data/perikopen.txt";
    }
    std::ifstream datei(pfad.string());
    std::string zeile;
    std::string tmpLitTag;
    while (datei.good())
    {
        std::vector<std::string> tmpLitStellen;
        getline(datei, zeile);

        // Workaround, damit nicht fälschlicher Weise eine weitere, leere
        // Zeile eingelesen wird. Liegt das am Unicode-Format?
        if (zeile.length() <= 10)
            continue;

        std::stringstream ss(zeile);
        getline(ss, tmpLitTag, '|');
        std::string item;
        while(getline(ss, item, '|'))
        {
            tmpLitStellen.push_back(item);
        }

        if (mLitDates.count(tmpLitTag))
        {
            mLitDates[tmpLitTag].setText(tmpLitStellen[reihe - 1]);
        }
    }

}

void Perikopen::appendBibelstellen()
{
    //std::vector<Bibelstelle> stellen;
    for(auto item: mLitDates)
    {
        Bibelstelle stelle(item.second.getDate());
        stelle.addBibelstelle(item.first);
        stelle.addBibelstelle(item.second.getText());
        if (stelle.getDatum().year() == mYear)
        {
            mBibelstellen.push_back(stelle);
        }
    }
    std::sort(mBibelstellen.begin(), mBibelstellen.end(), BibelstelleComparer());
}

LiturgischerTag::LiturgischerTag()
{
}

LiturgischerTag::LiturgischerTag(const boost::gregorian::date &date, const std::string &text)
    : mLitDate(date), mLitText(text)
{
}

boost::gregorian::date LiturgischerTag::getDate()
{
    return mLitDate;
}

void LiturgischerTag::setText(const std::string &text)
{
    mLitText = text;
}

std::string LiturgischerTag::getText()
{

    return mLitText;
}
