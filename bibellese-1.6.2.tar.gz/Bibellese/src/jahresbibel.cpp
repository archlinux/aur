#include <fstream>
#include <iostream>
#include <sstream>

#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include <config.h>
#include "jahresbibel.h"

using namespace std;

Jahresbibel::Jahresbibel()
{
    mTitel.push_back("Bibelstelle AT");
    mTitel.push_back("Bibelstelle NT");
    mTitel.push_back("Psalm");
    auslesen();
}

Jahresbibel::~Jahresbibel()
{

}

const vector<Bibelstelle> Jahresbibel::getBibelstellen()
{
    vector<Bibelstelle> stellen;
    for(auto item: m_mapBibelstellen)
    {
        Bibelstelle stelle(item.first);
        std::stringstream ss(item.second);
        std::string tmpString;
        while(getline(ss, tmpString, ';'))
        {
            stelle.addBibelstelle(tmpString);
        }
        stellen.push_back(stelle);
    }
    return stellen;
}

//inline const std::map<boost::gregorian::date, std::string>& Jahresbibel::getBibelstellen()
//{

//    return m_mapBibelstellen;
//}

void Jahresbibel::auslesen()
{
    boost::filesystem::path pfad(string(INSTALL_PREFIX) + "/share/bibellese/data/jahresbibel.txt");
    if (!boost::filesystem::exists(pfad)) {
        pfad = boost::filesystem::current_path() /= "data/jahresbibel.txt";
    }
    ifstream datei(pfad.string());
    string buffer;
    string tmpString;

    map<string, int> monate = { { "JANUAR", 1 }, { "FEBRUAR", 2 }, { "MÄRZ", 3 }, { "APRIL", 4 }, { "MAI", 5 }, {
            "JUNI", 6 }, { "JULI", 7 }, { "AUGUST", 8 }, { "SEPTEMBER", 9 }, { "OKTOBER", 10 }, { "NOVEMBER", 11 }, {
            "DEZEMBER", 12 } };

    int tag, monat = -1;
    string ps, at, nt;

    while (datei.good()) {
        getline(datei, buffer);

        // Monat
        if (buffer.length() <= 10) {
            boost::trim(buffer);
            monat = monate[buffer];
        } else {
            // Tag
            tmpString = buffer.substr(0, 2);
            boost::trim(tmpString);
            tag = boost::lexical_cast<int>(tmpString);

            // Bibelstellen
            ps = buffer.substr(6, 20);
            boost::trim(ps);
            at = buffer.substr(26, 27);
            boost::trim(at);
            nt = buffer.substr(53);
            boost::trim(nt);

            boost::gregorian::date curDatum(boost::gregorian::day_clock::local_day());

            m_mapBibelstellen[boost::gregorian::date(curDatum.year(), monat, tag)] = at + string(";") + nt + string(";") + ps;
        }

    }
}
