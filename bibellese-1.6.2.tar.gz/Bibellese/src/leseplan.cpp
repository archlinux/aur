/*
 *  Bibellese
 *  Copyright (C) 2012  Martin Brodbeck
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <fstream>

#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <libical/ical.h>

#include "leseplan.h"

using namespace std;

void Leseplan::speichernAlsIcal(const string& dateiname, const int std, const int min, const int dauer)
{
    string icalString;
    icalcomponent* calendar;
    icalcomponent* event;
    icalproperty* property;
    struct icaltimetype atime;
    struct icaltimetype etime;
    struct icaldurationtype durTime;
    boost::uuids::random_generator gen;

    calendar = icalcomponent_new(ICAL_VCALENDAR_COMPONENT);
    icalcomponent_add_property(calendar, icalproperty_new_version("2.0"));
    icalcomponent_add_property(calendar, icalproperty_new_prodid("-//Brodbeck//NONSGML Bibellese//EN"));

    durTime.is_neg = 0;
    durTime.weeks = 0;
    durTime.days = 0;
    durTime.hours = 0;
    durTime.minutes = dauer;
    durTime.seconds = 0;

    for (auto item : getBibelstellen()) {
        event = icalcomponent_new(ICAL_VEVENT_COMPONENT);
        boost::uuids::uuid uuid = gen();
        stringstream ss;
        ss << uuid;
        icalcomponent_add_property(event, icalproperty_new_uid(ss.str().c_str()));
        std::string bibStellenString;
        for(auto tmpItem: item.getBibelstellen())
        {
            if(bibStellenString.size() == 0)
            {
                bibStellenString = tmpItem;
            }
            else
            {
                bibStellenString += string(" / ") + tmpItem;
            }
        }
        icalcomponent_add_property(event, icalproperty_new_summary(bibStellenString.c_str()));
        atime = icaltime_from_day_of_year(item.getDatum().day_of_year(), item.getDatum().year());
        atime.is_date = 0;
        atime.hour = std;
        atime.minute = min;
        atime.second = 0;

        // Neues iCal Property = Startzeit
        property = icalproperty_new_dtstart(atime);
        icalproperty_add_parameter(property, icalparameter_new_tzid("Europe/Berlin"));
        icalcomponent_add_property(event, property);

        // Neues iCal Property = Endzeit
        etime = icaltime_add(atime, durTime);
        property = icalproperty_new_dtend(etime);
        icalproperty_add_parameter(property, icalparameter_new_tzid("Europe/Berlin"));
        icalcomponent_add_property(event, property);

        // Neues iCal Property = Startzeit (initialer Wert = 0)
        property = icalproperty_new_sequence(0);
        icalcomponent_add_property(event, property);


        icalcomponent_add_component(calendar, event);
    }

    icalString = icalcomponent_as_ical_string(calendar);
    icalcomponent_free(calendar);

    ofstream datei_schreiben;
    datei_schreiben.open(dateiname);
    datei_schreiben << icalString;
    datei_schreiben.close();
}

boost::gregorian::greg_year Leseplan::getJahr()
{
    if (m_mapBibelstellen.size() != 0) {
        return m_mapBibelstellen.begin()->first.year();
    } else {
        return boost::gregorian::day_clock::local_day().year();
    }
}

vector<std::string> Leseplan::getTitel()
{
    return mTitel;
}

Leseplan::Leseplan()
{
    mTitel.push_back("Datum");
}

inline const vector<Bibelstelle> Leseplan::getBibelstellen()
{
    vector<Bibelstelle> stellen;
    for(auto item: m_mapBibelstellen)
    {
        Bibelstelle stelle(item.first);
        stelle.addBibelstelle(item.second);
        stellen.push_back(stelle);
    }
    return stellen;
}


void Bibelstelle::addBibelstelle(string bibelstelle)
{
    mBibelstellen.push_back(bibelstelle);
}

const boost::gregorian::date &Bibelstelle::getDatum() const
{
    return mDatum;
}

const std::vector<std::string>& Bibelstelle::getBibelstellen()
{
    return mBibelstellen;
}
