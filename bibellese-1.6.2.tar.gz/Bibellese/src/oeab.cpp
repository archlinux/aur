/*
 *  Bibellese
 *  Copyright (C) 2012  Martin Brodbeck
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <fstream>
#include <iostream>

#include "oeab.h"

using namespace std;

Oeab::Oeab(string dateiname) :
        mDateiname(dateiname)
{
    mTitel.push_back("Bibelstelle");
    auslesen();
}

Oeab::~Oeab()
{

}

//inline const map<boost::gregorian::date, std::string>& Oeab::getBibelstellen()
//{

//    return m_mapBibelstellen;
//}

void Oeab::auslesen()
{
    ifstream datei(mDateiname);
    string zeile;
    string strDatum;
    string strBibelstelle;
    stringstream ssDatum;

    boost::gregorian::date_input_facet* diFacet = new boost::gregorian::date_input_facet("%d.%m.%Y");
    ssDatum.imbue(locale(ssDatum.getloc(), diFacet));
    ssDatum.exceptions(std::ios_base::failbit);

    while (datei.good()) {
        getline(datei, zeile);

        // Workaround, damit nicht fälschlicher Weise eine weitere, leere
        // Zeile eingelesen wird. Liegt das am Unicode-Format?
        if (zeile.length() <= 10)
            continue;

        stringstream ss(zeile);
        getline(ss, strDatum, '\t');
        getline(ss, strBibelstelle);

        ssDatum.str(strDatum);
        boost::gregorian::date datum;
        try {
            if (strDatum.find('.') != string::npos)
                ssDatum >> datum;
            else
                datum = boost::gregorian::from_simple_string(strDatum);
        } catch (const exception& ex) {
            cerr << strDatum << endl;
            ex.what();
            continue;
        }

        m_mapBibelstellen[datum] = strBibelstelle;
    }

    //delete diFacet;
}
