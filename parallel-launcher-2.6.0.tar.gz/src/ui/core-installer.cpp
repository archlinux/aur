#include "src/ui/core-installer.hpp"

#include <QMessageBox>
#include <cassert>
#include "src/polyfill/base-directory.hpp"
#include "src/ui/download-dialog.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/zip.hpp"

static const char *s_installCorePrompt = "This emulator core is not installed. Would you like to install it now?";

static const char *s_parallelFailedMsg = ""
	"Failed to install the ParallelN64 emulator core. You can try installing it "
	"manually by opening RetroArch, going to Load Core, then Download a Core, "
	"and then selecting Nintendo - Nintendo 64 (ParaLLEl N64).";

static const char *s_mupenFailedMsg = ""
	"Failed to install the Mupen64Plus-Next emulator core. You can try installing it "
	"manually by opening RetroArch, going to Load Core, then Download a Core, "
	"and then selecting Nintendo - Nintendo 64 (Mupen64Plus-Next).";

static const char *s_unknownCorePathMsg = ""
	"Parallel Launcher cannot determine where to install this emulator core because "
	"the core directory is missing from your RetroArch config file, or a RetroArch "
	"configuration file cannot be found. If you have not yet run RetroArch, you may "
	"need to run it once to force this config file to be created.";

bool CoreInstaller::requireCore( EmulatorCore core ) {
	if( core == EmulatorCore::UseDefault ) {
		core = FileController::loadAppSettings().defaultEmulator;
	}

	if( RetroArch::isEmulatorCoreInstalled( core ) ) {
		return true;
	}

	assert( core == EmulatorCore::ParallelN64 || core == EmulatorCore::Mupen64plusNext );

	if( QMessageBox::question( nullptr, "Install Emulator Core?", s_installCorePrompt ) != QMessageBox::Yes ) {
		return false;
	}

	const fs::path corePath = RetroArch::getCorePath();
	if( corePath.empty() ) {
		QMessageBox::critical( nullptr, "Unknown Core Directory", s_unknownCorePathMsg );
		return false;
	}

	fs::create_directories( BaseDir::temp() );
	fs::path zipPath;
	const char *failMessage;
	bool downloaded;

	if( core == EmulatorCore::ParallelN64 ) {
		zipPath = BaseDir::temp() / "parallel_n64_libretro.zip";
		downloaded = DownloadDialog::download( "Downloading ParallelN64 core...", RetroArch::getParallelN64DownloadUrl(), zipPath );
		failMessage = s_parallelFailedMsg;
	} else {
		zipPath = BaseDir::temp() / "mupen64plus_next_libretro.zip";
		downloaded = DownloadDialog::download( "Downloading Mupen64Plus-Next core...", RetroArch::getMupenDownloadUrl(), zipPath );
		failMessage = s_mupenFailedMsg;
	}

	const bool success = downloaded && Zip::unzip( zipPath, corePath ) && RetroArch::isEmulatorCoreInstalled( core );

	std::error_code err;
	fs::remove( zipPath, err );

	if( !success ) {
		QMessageBox::critical( nullptr, "Failed to install core", failMessage );
		return false;
	}

	return true;
}
