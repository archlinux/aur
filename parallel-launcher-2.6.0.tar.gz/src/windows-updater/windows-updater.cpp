#include "src/windows-updater/windows-updater.hpp"

#include <QMessageBox>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProgressDialog>
#include <cstdlib>
#include "src/core/version.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/settings.hpp"
#include "src/core/file-controller.hpp"
#include "src/windows-updater/update-dialog.hpp"
#include "src/ui/download-dialog.hpp"
#include "src/polyfill/process.hpp"
#include "src/polyfill/base-directory.hpp"

#if QT_VERSION >= QT_VERSION_CHECK( 5, 15, 0 )
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::errorOccurred )
#else
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::error )
#endif

#ifdef _WIN64
	#define INSTALLER_URL "https://parallel-launcher.ca/latest/parallel-launcher_setup_win64.exe"
	#define INSTALLER_FILENAME "parallel-launcher_setup_win64.exe"
#else
	#define INSTALLER_URL "https://parallel-launcher.ca/latest/parallel-launcher_setup_win32.exe"
	#define INSTALLER_FILENAME "parallel-launcher_setup_win32.exe"
#endif

static inline void downloadUpdate() {
	const fs::path filePath = BaseDir::temp() / INSTALLER_FILENAME;

	if( !DownloadDialog::download( "Downloading installer...", INSTALLER_URL, filePath ) ) {
		QMessageBox::critical( nullptr, "Download Failed", "Failed to download the latest installer. Try again later." );
		return;
	}

	try {
		AsyncProcess( filePath.string(), std::vector<string>() ).detach();
		std::exit( 0 );
	} catch( ... ) {
		QMessageBox::critical( nullptr, "Unexpected Error", "Failed to launch installer." );
	}
}

static inline void downloadChangelog(
	QNetworkAccessManager *web,
	const Version &latestVersion
) {
	QNetworkReply *response = web->get(
		QNetworkRequest( QUrl( "https://parallel-launcher.ca/latest/changelog.htm" ) )
	);

	QObject::connect( response, ON_NETWORK_ERROR, [=](QNetworkReply::NetworkError error) {
		(void)error;
		response->deleteLater();
		web->deleteLater();
	});

	QObject::connect( response, &QNetworkReply::finished, [=](){
		QByteArray rawData = response->readAll();
		web->deleteLater();
		response->deleteLater();

		UpdateDialog dialog( latestVersion, rawData.toStdString().c_str() );
		const int result = dialog.exec();
		if( result == QDialog::Accepted ) {
			downloadUpdate();
		} else if( dialog.stopReminders() ) {
			AppSettings settings = FileController::loadAppSettings();
			settings.checkForUpdates = false;
			FileController::saveAppSettings( settings );
		}
	});
}

void WindowsUpdater::checkForUpdates() {
	if( !FileController::loadAppSettings().checkForUpdates ) {
		return;
	}

	QNetworkAccessManager *web = new QNetworkAccessManager();

	QNetworkReply *response = web->get(
		QNetworkRequest( QUrl( "https://parallel-launcher.ca/latest/version" ) )
	);

	QObject::connect( response, ON_NETWORK_ERROR, [=](QNetworkReply::NetworkError error) {
		(void)error;
		response->deleteLater();
		web->deleteLater();
	});

	QObject::connect( response, &QNetworkReply::finished, [=](){
		QByteArray rawData = response->readAll();
		response->deleteLater();

		Version latestVersion;
		if(
			!rawData.isNull() &&
			Version::tryParse( rawData.toStdString(), latestVersion ) &&
			CurrentVersion::Application < latestVersion
		) {
			downloadChangelog( web, latestVersion );
		}
	});
}
