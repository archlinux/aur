//! GM soundfont playback via rustysynth. Renders notes to buffers and plays as samples.

use std::path::Path;
use std::sync::Arc;

use crate::sample_loader::Sample;
use rustysynth::{SoundFont, Synthesizer, SynthesizerSettings};

/// GM program numbers (first preset in each bank is 0-127).
const GM_PROGRAM: &[(&str, u8)] = &[
    ("gm_piano", 0),
    ("gm_epiano1", 4),
    ("gm_epiano2", 5),
    ("gm_acoustic_bass", 32),
    ("gm_electric_bass", 33),
    ("gm_acoustic_guitar_nylon", 24),
    ("gm_acoustic_guitar_steel", 25),
];

fn gm_name_to_program(name: &str) -> Option<u8> {
    let name_lower = name.to_lowercase();
    GM_PROGRAM
        .iter()
        .find(|(n, _)| *n == name_lower)
        .map(|(_, p)| *p)
}

/// Load a .sf2 file. Returns None if file missing or invalid.
pub fn load_soundfont(path: &Path) -> Option<Arc<SoundFont>> {
    let data = std::fs::read(path).ok()?;
    let mut cursor = std::io::Cursor::new(data);
    let sf = SoundFont::new(&mut cursor).ok()?;
    Some(Arc::new(sf))
}

/// Render a single GM note into a stereo sample (interleaved L,R).
pub fn render_gm_note(
    soundfont: &Arc<SoundFont>,
    program: u8,
    midi_note: u8,
    velocity: u8,
    duration_secs: f32,
    sample_rate: u32,
) -> Option<Sample> {
    let settings = SynthesizerSettings::new(sample_rate as i32);
    let mut syn = Synthesizer::new(soundfont, &settings).ok()?;
    let block_size = syn.get_block_size();
    if block_size == 0 {
        return None;
    }

    // Сброс канала и выбор GM банка/пресета (для FluidR3 GS и др.).
    syn.process_midi_message(0, 0xB0, 0x79, 0); // Reset All Controllers
    syn.process_midi_message(0, 0xB0, 0, 0); // Bank Select MSB = 0
    syn.process_midi_message(0, 0xB0, 32, 0); // Bank Select LSB = 0
    syn.process_midi_message(0, 0xC0, program as i32, 0); // Program Change
    syn.note_on(0, midi_note as i32, velocity as i32);

    let total_frames = (duration_secs * sample_rate as f32).ceil() as usize;
    let total_samples = total_frames * 2; // stereo interleaved
    let mut left = vec![0f32; block_size];
    let mut right = vec![0f32; block_size];
    let mut out: Vec<f32> = Vec::with_capacity(total_samples);

    let mut rendered = 0usize;
    while rendered < total_frames {
        syn.render(&mut left, &mut right);
        let to_take = (total_frames - rendered).min(block_size);
        for i in 0..to_take {
            out.push(left[i]);
            out.push(right[i]);
        }
        rendered += to_take;
        if rendered >= total_frames {
            break;
        }
    }

    syn.note_off(0, midi_note as i32);

    Some(Sample {
        data: Arc::new(out),
        sample_rate,
        channels: 2,
    })
}

/// If `name` is a known GM sound name, return its program number.
pub fn gm_program_for_name(name: &str) -> Option<u8> {
    gm_name_to_program(name)
}
