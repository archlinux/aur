use crate::project_audio::{PitchMode, PitchParams, StretchParams};

pub trait StretchPitchBackend: Send + Sync {
    fn name(&self) -> &'static str;

    fn process_preview(
        &self,
        input: &[f32],
        channels: usize,
        stretch: &StretchParams,
        pitch: &PitchParams,
    ) -> Vec<f32>;

    fn process_offline_hq(
        &self,
        input: &[f32],
        channels: usize,
        stretch: &StretchParams,
        pitch: &PitchParams,
    ) -> Vec<f32>;
}

#[derive(Default)]
pub struct BuiltInStretchPitch;

impl StretchPitchBackend for BuiltInStretchPitch {
    fn name(&self) -> &'static str {
        "built-in-resampler"
    }

    fn process_preview(
        &self,
        input: &[f32],
        channels: usize,
        stretch: &StretchParams,
        pitch: &PitchParams,
    ) -> Vec<f32> {
        process_resample(input, channels, stretch, pitch, false)
    }

    fn process_offline_hq(
        &self,
        input: &[f32],
        channels: usize,
        stretch: &StretchParams,
        pitch: &PitchParams,
    ) -> Vec<f32> {
        process_resample(input, channels, stretch, pitch, true)
    }
}

pub fn default_backend() -> BuiltInStretchPitch {
    BuiltInStretchPitch
}

pub fn process_resample(
    input: &[f32],
    channels: usize,
    stretch: &StretchParams,
    pitch: &PitchParams,
    high_quality: bool,
) -> Vec<f32> {
    if input.is_empty() || channels == 0 {
        return Vec::new();
    }

    let pitch_ratio = pitch.ratio().max(0.01) as f64;
    let stretch_ratio = stretch.ratio.max(0.01);
    let source_step = match pitch.mode {
        PitchMode::Tape => 1.0 / (stretch_ratio * pitch_ratio),
        PitchMode::Elastic => 1.0 / stretch_ratio,
    };
    let first_pass = resample_linear(input, channels, source_step, high_quality);

    if matches!(pitch.mode, PitchMode::Elastic) && (pitch_ratio - 1.0).abs() > 0.000_1 {
        // Elastic pitch needs a proper phase-vocoder/PSOLA backend for final quality.
        // This preview path keeps duration stable by pitching via resample and stretching back.
        let pitched = resample_linear(&first_pass, channels, 1.0 / pitch_ratio, high_quality);
        let restore = first_pass.len().max(channels) as f64 / pitched.len().max(channels) as f64;
        resample_linear(&pitched, channels, restore, high_quality)
    } else {
        first_pass
    }
}

fn resample_linear(
    input: &[f32],
    channels: usize,
    source_step: f64,
    high_quality: bool,
) -> Vec<f32> {
    let frames = input.len() / channels;
    if frames == 0 {
        return Vec::new();
    }
    let out_frames = ((frames as f64) / source_step.max(0.000_001))
        .ceil()
        .max(1.0) as usize;
    let mut out = vec![0.0_f32; out_frames * channels];
    let taps = if high_quality { 4 } else { 1 };

    for out_frame in 0..out_frames {
        let source_pos = out_frame as f64 * source_step;
        let base = source_pos.floor() as isize;
        let frac = (source_pos - base as f64) as f32;
        for ch in 0..channels {
            let sample = if taps == 1 {
                sample_linear(input, channels, frames, base, frac, ch)
            } else {
                sample_cubic(input, channels, frames, base, frac, ch)
            };
            out[out_frame * channels + ch] = sample;
        }
    }

    out
}

fn sample_linear(
    input: &[f32],
    channels: usize,
    frames: usize,
    base: isize,
    frac: f32,
    ch: usize,
) -> f32 {
    let a = sample_at(input, channels, frames, base, ch);
    let b = sample_at(input, channels, frames, base + 1, ch);
    a + (b - a) * frac
}

fn sample_cubic(
    input: &[f32],
    channels: usize,
    frames: usize,
    base: isize,
    frac: f32,
    ch: usize,
) -> f32 {
    let p0 = sample_at(input, channels, frames, base - 1, ch);
    let p1 = sample_at(input, channels, frames, base, ch);
    let p2 = sample_at(input, channels, frames, base + 1, ch);
    let p3 = sample_at(input, channels, frames, base + 2, ch);
    let a = -0.5 * p0 + 1.5 * p1 - 1.5 * p2 + 0.5 * p3;
    let b = p0 - 2.5 * p1 + 2.0 * p2 - 0.5 * p3;
    let c = -0.5 * p0 + 0.5 * p2;
    let d = p1;
    (((a * frac) + b) * frac + c) * frac + d
}

fn sample_at(input: &[f32], channels: usize, frames: usize, frame: isize, ch: usize) -> f32 {
    let frame = frame.clamp(0, frames.saturating_sub(1) as isize) as usize;
    input.get(frame * channels + ch).copied().unwrap_or(0.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::project_audio::{PitchParams, StretchParams};

    #[test]
    fn stretch_ratio_changes_duration() {
        let input = vec![0.0_f32; 100];
        let stretch = StretchParams {
            ratio: 2.0,
            ..Default::default()
        };
        let out = process_resample(&input, 1, &stretch, &PitchParams::default(), false);
        assert!(out.len() > input.len());
    }
}
