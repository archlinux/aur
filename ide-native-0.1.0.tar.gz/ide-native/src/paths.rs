//! Resolve install and development paths for the Strudel runtime.

use std::path::PathBuf;

/// Packaged Strudel tree installed by the distro package.
pub const SYSTEM_STRUDEL_ROOT: &str = "/usr/share/struidel/strudel";

/// Root of the Strudel JS runtime (`scripts/`, `packages/`, `doc.json`).
pub fn strudel_root() -> PathBuf {
    if let Ok(p) = std::env::var("STRUDEL_HOME") {
        let pb = PathBuf::from(p);
        if pb.is_dir() {
            return pb;
        }
    }

    let settings = crate::settings::load_settings();
    if let Some(ref p) = settings.strudel_local_path {
        let pb = PathBuf::from(p);
        if pb.is_dir() {
            return pb;
        }
    }

    let system = PathBuf::from(SYSTEM_STRUDEL_ROOT);
    if system.is_dir() {
        return system;
    }

    if let Ok(exe) = std::env::current_exe() {
        if let Some(parent) = exe.parent() {
            for cand in [
                parent.join("../share/struidel/strudel"),
                parent.join("strudel"),
                parent.join("../strudel"),
            ] {
                if let Ok(c) = cand.canonicalize() {
                    if c.is_dir() {
                        return c;
                    }
                }
            }
        }
    }

    // Development monorepo: ide-native/../strudel
    let dev = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("..").join("strudel");
    if let Ok(c) = dev.canonicalize() {
        return c;
    }

    system
}

pub fn doc_json_path() -> Option<PathBuf> {
    let path = strudel_root().join("doc.json");
    path.is_file().then_some(path)
}

pub fn runner_mjs_path() -> PathBuf {
    strudel_root().join("scripts").join("strudel-runner.mjs")
}

pub fn package_dir(package: &str) -> PathBuf {
    strudel_root().join("packages").join(package)
}

/// Default samples / cache directory (XDG data).
pub fn default_sample_folder() -> PathBuf {
    if let Some(dirs) = directories::ProjectDirs::from("cc", "strudel", "struidel") {
        return dirs.data_local_dir().join("samples");
    }
    PathBuf::from("struidel-samples")
}

/// Cache file for the language index (XDG cache).
pub fn language_index_cache_path() -> PathBuf {
    if let Some(dirs) = directories::ProjectDirs::from("cc", "strudel", "struidel") {
        return dirs.cache_dir().join("strudel_language_index.json");
    }
    std::env::temp_dir().join("struidel_language_index.json")
}
