/*****************************************************************
** KENCFS - (c) 2010-2017 by Felice Murolo, all rigths reserved
** KENCFS-Plasma - (c) 2017 by Felice Murolo, all rigths reserved
** Author: Felice Murolo, Salerno, Italia
** eMail: linuxboy@RE-MO-VEfel.hopto.org
**
** GNU Lesser General Public License Usage
** KEncFS and it's sources may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
**/

#include "config.h"
#include <KConfig>
#include <KConfigGroup>

extern char *cfgfile;
extern bool starthide, browseaftermount,usewallet,wallet_automount;
extern int selected_icon, def_icon;

cfg::cfg()
{

}

cfg::~cfg()
{

}

QList<QStringList> cfg::load()
{
    KConfig config(cfgfile, KConfig::SimpleConfig);
    //KConfigGroup g( &config, "" );

    QList<QStringList> a;
    QStringList b;

    QStringList l=config.groupList();
    int i;
    for (i=0; i<l.size(); i++) {
        KConfigGroup f(&config, l.at(i));
        if (f.hasKey("PMount")) {
            id=f.readEntry("Id","myfs");
            pmount=f.readPathEntry("PMount",QString());
            crypt=f.readPathEntry("Crypt",QString());
            encfs_opt = f.readEntry("Encfs_Options",QString());
            fuse_opt = f.readEntry("Fuse_Options",QString());
            b.clear();
            b << id << pmount << crypt << "" << encfs_opt << fuse_opt;
            a << b;
        }
        else if (f.hasKey("BrowseAfterMount")) {
            //g.changeGroup(l.at(i));
            starthide=f.readEntry("StartHide",false);
            browseaftermount=f.readEntry("BrowseAfterMount",true);
            usewallet=f.readEntry("UseKdeWallet",false);
            wallet_automount=f.readEntry("KdeWallet_AutoMount",false);
            selected_icon = f.readEntry("SelectedIcon",def_icon);
        }
    }
    return a;
}

void cfg::save(QList<QStringList> a)
{
    int i;
    KConfig config(cfgfile);
    foreach (QString d, config.groupList()) {
        config.deleteGroup(d);
    }

    KConfigGroup g( &config, "General" );
    g.writeEntry("StartHide",starthide);
    g.writeEntry("BrowseAfterMount",browseaftermount);
    g.writeEntry("UseKdeWallet",usewallet);
    g.writeEntry("KdeWallet_AutoMount",wallet_automount);
    g.writeEntry("SelectedIcon",selected_icon);

    for (i=0; i<a.size(); i++)
        {
        id=a.at(i).at(0);
        pmount=a.at(i).at(1);
        crypt=a.at(i).at(2);
        encfs_opt = a.at(i).at(4);
        fuse_opt = a.at(i).at(5);
        KConfigGroup f( &config, id );
        f.writeEntry("Id",id);
        f.writePathEntry("PMount",pmount);
        f.writePathEntry("Crypt",crypt);
        f.writeEntry("Encfs_Options",encfs_opt);
        f.writeEntry("Fuse_Options",fuse_opt);
        }
    g.config()->sync();

}


