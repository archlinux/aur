/*****************************************************************
** KENCFS - (c) 2010-2017 by Felice Murolo, all rigths reserved
** KENCFS-Plasma - (c) 2017 by Felice Murolo, all rigths reserved
** Author: Felice Murolo, Salerno, Italia
** eMail: linuxboy@RE-MO-VEfel.hopto.org
**
** GNU Lesser General Public License Usage
** KEncFS and it's sources may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
**/

#include <stdio.h>
#include "configdialog.h"
#include "ui_configdialog.h"
#include <iostream>
#include "mainwindow.h"
#include <KStatusNotifierItem>
using namespace std;


extern bool starthide,browseaftermount,usewallet,wallet_automount;
#include <KWallet>
using KWallet::Wallet;
extern Wallet *m_wallet;
extern QString WalletFolder;
extern bool wallet_opened;
extern int selected_icon;
extern MainWindow *mainwindow;
extern QStringList icons;
extern int def_icon;
extern int selected_icon;
extern KStatusNotifierItem *tray;

configDialog::configDialog(QWidget *parent) :
        QDialog(parent),
        configui(new Ui::configDialog)
{
configui->setupUi(this);
configui->lbicon->setText(tr("Icon's Selection"));
}


configDialog::~configDialog()
{
}

void configDialog::accept()
{
    starthide=configui->cbstarthide->isChecked();
    browseaftermount=configui->cbbrowse->isChecked();
    usewallet=configui->cbusewallet->isChecked();
    wallet_automount=configui->cbwallet_automount->isChecked();
    if (!usewallet && wallet_opened) {
        cout << "NOT USEWALLET, remove wallet folder for Kencfs\n";
        m_wallet->removeFolder(WalletFolder);
    }
    selected_icon = configui->hsicon->value();
    cout << "Selected Icon: " << selected_icon << "\n";
    cout << "Changing mainwindow icon... " ;
    QIcon qi(QIcon(QString(KENCFS_ICONS) + QString("/") + icons.at(selected_icon)));
    mainwindow->setWindowIcon(qi);
    cout << "Changing tray icon... " ;
    tray->setIconByPixmap(qi);
    cout << "Done.\n";
    this->hide();
}


void configDialog::hideEvent(QHideEvent *e)
{
    (void)e;
}

void configDialog::showEvent(QShowEvent *e)
{
    (void)e;
    configui->cbstarthide->setChecked(starthide);
    configui->cbbrowse->setChecked(browseaftermount);
    configui->cbusewallet->setChecked(usewallet);
    configui->cbwallet_automount->setChecked(wallet_automount);
    configui->hsicon->setValue(selected_icon);
    configui->lbshow->setPixmap(QPixmap(QString(KENCFS_ICONS) + QString("/") + icons.at(selected_icon)));
}

void configDialog::sliderChanged(int value)
{
    if (value >=0 && value <= icons.size())
    {
        configui->lbshow->setPixmap(QPixmap(QString(KENCFS_ICONS) + QString("/") + icons.at(value)));
    }
}

void configDialog::changeEvent(QEvent *e)
{
    (void)e;
}
