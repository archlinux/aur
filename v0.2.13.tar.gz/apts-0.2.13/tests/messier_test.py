import pytest
from default import *


#def test_visiable_messier():
  #o = setup_observations()
  #o.get_visible_planets()
  #print(o.get_visible_messier())
