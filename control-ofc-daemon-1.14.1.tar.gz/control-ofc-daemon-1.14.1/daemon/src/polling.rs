//! Hardware polling loops for hwmon sensors and OpenFanController fans.
//!
//! Each subsystem gets its own async loop that runs on a configurable interval,
//! reads hardware, and pushes results into the shared `StateCache`.

use std::path::Path;
use std::sync::Arc;
use std::time::{Duration, Instant};

use tokio::sync::watch;

/// Read CLOCK_BOOTTIME (monotonic clock that includes suspend time).
/// Returns Duration::ZERO on failure.
fn boottime_now() -> Duration {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: clock_gettime is signal-safe per POSIX. `ts` is a valid
    // mutable reference to a stack-local timespec — the call writes only
    // to this struct and touches no other memory. CLOCK_BOOTTIME is
    // supported on all Linux kernels >= 2.6.39 (our minimum target).
    if unsafe { libc::clock_gettime(libc::CLOCK_BOOTTIME, &mut ts) } != 0 {
        return Duration::ZERO;
    }
    Duration::new(ts.tv_sec as u64, ts.tv_nsec as u32)
}

use crate::health::cache::StateCache;
use crate::health::state::{
    AmdGpuFanState, CachedSensorReading, DeviceLabel, HwmonFanState, OpenFanState,
};
use crate::hwmon::gpu_detect::AmdGpuInfo;
use crate::hwmon::intel_gpu_detect::IntelGpuInfo;
use crate::hwmon::types::SensorReading;
use crate::serial::protocol::Command;
use crate::serial::transport::{send_command, SerialTransport};

/// Convert hwmon `SensorReading` (with `SystemTime`) into cache `CachedSensorReading` (with `Instant`).
fn to_cached(reading: &SensorReading) -> CachedSensorReading {
    use crate::hwmon::types::SensorSource;
    let source = match reading.source {
        SensorSource::AmdGpu => DeviceLabel::AmdGpu,
        SensorSource::IntelGpu => DeviceLabel::IntelGpu,
        SensorSource::Hwmon => DeviceLabel::Hwmon,
    };
    CachedSensorReading {
        id: reading.id.clone(),
        kind: reading.kind,
        label: reading.label.clone(),
        value_c: reading.value_c,
        source,
        updated_at: Instant::now(),
        // Rate and min/max are computed by the cache on update
        rate_c_per_s: None,
        session_min_c: None,
        session_max_c: None,
        chip_name: reading.chip_name.clone(),
        temp_type: reading.temp_type,
        thresholds: reading.thresholds.clone(),
    }
}

/// Run the hwmon sensor polling loop.
///
/// Reads all hwmon temperature sensors every `interval`, and RPM/PWM for
/// all discovered PWM headers, pushing results into the cache.
///
/// Sensor descriptors are discovered once and cached (DEC-133); per-tick
/// work touches only `temp*_input` value files. Re-discovery (which
/// re-reads labels, types, and the DEC-117 threshold/alarm snapshot) runs
/// only on explicit triggers:
/// 1. `sensor_rescan` flag — set by `POST /hwmon/rescan`;
/// 2. a cached descriptor failing value-reads for
///    `SENSOR_READ_FAIL_REDISCOVER_STREAK` consecutive ticks (device
///    unbound mid-session);
/// 3. no `CpuTemp` descriptor in the cache — re-discover every tick so a
///    late-loading `k10temp`/`coretemp` is picked up immediately and the
///    no-sensor 40% fallback can release (this also covers the empty set).
///
/// Rationale: per-tick full discovery re-read ~12 threshold attributes per
/// sensor plus chip names/labels every second. Kernel drivers cache chip
/// registers (it87/nct6775 re-sweep at most every 1.5s) so most of that
/// was wasted syscalls, but on `asus_wmi_sensors` boards the kernel docs
/// warn that polling the WMI interface more frequently increases the risk
/// of fan/sensor misbehaviour — so the daemon now polls the minimum set.
#[allow(clippy::too_many_arguments)]
pub async fn hwmon_poll_loop(
    cache: Arc<StateCache>,
    history: Arc<crate::health::history::HistoryRing>,
    headers: Vec<crate::hwmon::pwm_discovery::PwmHeaderDescriptor>,
    gpu_infos: Vec<AmdGpuInfo>,
    intel_gpu_infos: Vec<IntelGpuInfo>,
    hwmon_root: &Path,
    interval: Duration,
    sensor_rescan: Arc<std::sync::atomic::AtomicBool>,
    mut shutdown: watch::Receiver<bool>,
) {
    use crate::hwmon::types::{SensorDescriptor, SensorKind};
    use std::collections::HashMap;
    use std::sync::atomic::Ordering;

    let hwmon_root = hwmon_root.to_path_buf();
    let headers = Arc::new(headers);
    let gpu_infos = Arc::new(gpu_infos);
    let intel_gpu_infos = Arc::new(intel_gpu_infos);
    let mut tick = tokio::time::interval(interval);
    tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    let mut consecutive_errors: u32 = 0;
    let mut prev_boot: Option<Duration> = None;
    let mut prev_mono: Option<Instant> = None;

    // DEC-133: cached sensor descriptor set + per-descriptor read-failure
    // streaks. `Arc` so each tick's spawn_blocking can borrow the set
    // without cloning descriptor contents.
    let mut descriptors: Arc<Vec<SensorDescriptor>> = Arc::new(Vec::new());
    let mut discovered_once = false;
    let mut read_fail_streaks: HashMap<String, u32> = HashMap::new();

    loop {
        tokio::select! {
            _ = tick.tick() => {}
            _ = shutdown.changed() => {
                log::info!("hwmon poll loop shutting down");
                return;
            }
        }

        // Detect system suspend/resume via CLOCK_BOOTTIME vs CLOCK_MONOTONIC gap.
        // CLOCK_MONOTONIC pauses during suspend; CLOCK_BOOTTIME does not.
        let now_boot = boottime_now();
        let now_mono = Instant::now();
        if let (Some(pb), Some(pm)) = (prev_boot, prev_mono) {
            let boot_delta = now_boot.saturating_sub(pb);
            let mono_delta = now_mono.duration_since(pm);
            let suspend_gap = boot_delta.saturating_sub(mono_delta);
            if suspend_gap > Duration::from_secs(3) {
                log::info!(
                    "System resume detected (suspended ~{:.0}s). \
                     Signalling hwmon manual mode reset.",
                    suspend_gap.as_secs_f64()
                );
                cache.set_resume_detected();
            }
        }
        prev_boot = Some(now_boot);
        prev_mono = Some(now_mono);

        // DEC-133: decide whether this tick re-runs sensor discovery.
        let rescan_requested = sensor_rescan.swap(false, Ordering::SeqCst);
        let streak_exceeded = read_fail_streaks
            .values()
            .any(|&n| n >= crate::constants::SENSOR_READ_FAIL_REDISCOVER_STREAK);
        let cpu_temp_missing = descriptors.iter().all(|d| d.kind != SensorKind::CpuTemp);
        let needs_discovery =
            !discovered_once || rescan_requested || streak_exceeded || cpu_temp_missing;
        if rescan_requested {
            log::info!("Sensor descriptor refresh requested via /hwmon/rescan");
        } else if streak_exceeded && discovered_once {
            let failing: Vec<&str> = read_fail_streaks
                .iter()
                .filter(|(_, &n)| n >= crate::constants::SENSOR_READ_FAIL_REDISCOVER_STREAK)
                .map(|(id, _)| id.as_str())
                .collect();
            log::warn!("Re-discovering sensors after persistent read failures on {failing:?}");
        }

        // Run blocking sysfs I/O on the blocking thread pool
        let root = hwmon_root.clone();
        let hdrs = headers.clone();
        let gpus = gpu_infos.clone();
        let intel_gpus = intel_gpu_infos.clone();
        let descs = descriptors.clone();
        let result: Result<_, tokio::task::JoinError> = tokio::task::spawn_blocking(move || {
            // Sensor leg: full discovery only when triggered; otherwise the
            // hot path reads each cached descriptor's temp*_input file only.
            let sensors: Result<(Option<Vec<SensorDescriptor>>, Vec<_>), crate::error::HwmonError> =
                if needs_discovery {
                    crate::hwmon::discovery::discover_sensors(&root).map(|fresh| {
                        let readings = crate::hwmon::read_sensor_values(&fresh);
                        (Some(fresh), readings)
                    })
                } else {
                    Ok((None, crate::hwmon::read_sensor_values(&descs)))
                };
            let fan_states: Vec<HwmonFanState> = read_hwmon_fan_states(&hdrs);
            // AMD + Intel discrete GPU fans share the cache `gpu_fans` map,
            // distinguished by their ID prefix (`amd_gpu:` / `intel_gpu:`).
            let mut gpu_fan_states: Vec<AmdGpuFanState> = read_gpu_fan_states(&gpus);
            gpu_fan_states.extend(read_intel_fan_states(&intel_gpus));
            (sensors, fan_states, gpu_fan_states)
        })
        .await;

        match result {
            Ok((Ok((fresh_descriptors, readings)), fan_states, gpu_fan_states)) => {
                consecutive_errors = 0;
                if let Some(fresh) = fresh_descriptors {
                    if !discovered_once || rescan_requested {
                        log::info!("Sensor discovery: {} sensor(s) cached", fresh.len());
                    }
                    descriptors = Arc::new(fresh);
                    discovered_once = true;
                    read_fail_streaks.clear();
                }

                // Track per-descriptor read failures: a descriptor present in
                // the cache but absent from this tick's readings failed.
                let read_ids: std::collections::HashSet<&str> =
                    readings.iter().map(|r| r.id.as_str()).collect();
                for d in descriptors.iter() {
                    if read_ids.contains(d.id.as_str()) {
                        read_fail_streaks.remove(&d.id);
                    } else {
                        *read_fail_streaks.entry(d.id.clone()).or_insert(0) += 1;
                    }
                }

                let cached: Vec<CachedSensorReading> = readings.iter().map(to_cached).collect();
                let count = cached.len();
                // Record to history ring buffer before cache update
                for r in &readings {
                    history.record(&r.id, r.value_c);
                }
                cache.update_sensors(cached);

                // Update hwmon fan state in cache
                if !fan_states.is_empty() {
                    let fan_count = fan_states.len();
                    cache.update_hwmon_fans(fan_states);
                    log::debug!("hwmon poll: {count} sensors, {fan_count} fans updated");
                } else {
                    log::debug!("hwmon poll: {count} sensors updated");
                }

                // Update GPU fan state in cache
                if !gpu_fan_states.is_empty() {
                    let gpu_count = gpu_fan_states.len();
                    cache.update_gpu_fans(gpu_fan_states);
                    log::debug!("gpu poll: {gpu_count} GPU fans updated");
                }
            }
            Ok((Err(e), _, _)) => {
                consecutive_errors += 1;
                if consecutive_errors <= 3 {
                    log::warn!("hwmon poll error: {e}");
                } else if consecutive_errors == 4 {
                    log::warn!("hwmon poll error (suppressing until periodic reminder): {e}");
                } else if consecutive_errors.is_multiple_of(60) {
                    log::warn!(
                        "hwmon poll error (persistent — {consecutive_errors} consecutive failures): {e}"
                    );
                }
            }
            Err(e) => {
                log::error!("hwmon poll task panicked: {e}");
            }
        }
    }
}

/// Read RPM and current PWM for all discovered hwmon PWM headers.
fn read_hwmon_fan_states(
    headers: &[crate::hwmon::pwm_discovery::PwmHeaderDescriptor],
) -> Vec<HwmonFanState> {
    let now = Instant::now();
    headers
        .iter()
        .filter_map(|h| {
            // Read RPM if tach is available
            let rpm = h
                .rpm_path
                .as_ref()
                .and_then(|p| match std::fs::read_to_string(p) {
                    Ok(s) => s.trim().parse::<u16>().ok(),
                    Err(e) => {
                        log::debug!(
                            "hwmon header '{}': failed to read RPM from {}: {e}",
                            h.id,
                            p
                        );
                        None
                    }
                });

            // Read current PWM raw value and convert to percent
            let pwm_pct = match std::fs::read_to_string(&h.pwm_path) {
                Ok(s) => s.trim().parse::<u8>().ok().map(crate::pwm::raw_to_percent),
                Err(e) => {
                    log::debug!(
                        "hwmon header '{}': failed to read PWM from {}: {e}",
                        h.id,
                        h.pwm_path
                    );
                    None
                }
            };

            // Only report if we got at least one meaningful reading
            if rpm.is_some() || pwm_pct.is_some() {
                Some(HwmonFanState {
                    id: h.id.clone(),
                    rpm,
                    last_commanded_pwm: pwm_pct,
                    updated_at: now,
                })
            } else {
                log::debug!("hwmon header '{}': no readable RPM or PWM — skipping", h.id);
                None
            }
        })
        .collect()
}

/// Read fan RPM for all detected AMD GPUs.
fn read_gpu_fan_states(gpus: &[AmdGpuInfo]) -> Vec<AmdGpuFanState> {
    let now = Instant::now();
    gpus.iter()
        .filter(|g| g.has_fan_rpm)
        .map(|g| {
            let fan_input = g.hwmon_path.join("fan1_input");
            let rpm = std::fs::read_to_string(&fan_input)
                .ok()
                .and_then(|s| s.trim().parse::<u16>().ok());

            AmdGpuFanState {
                id: format!("amd_gpu:{}", g.pci_bdf),
                rpm,
                last_commanded_pct: None, // Preserved from cache by the caller
                updated_at: now,
            }
        })
        .collect()
}

/// Read fan RPM for all detected Intel discrete GPUs (DEC-121).
///
/// Read-only: `last_commanded_pct` is always `None` because Intel fan control
/// is firmware-managed with no userspace write path. Only GPUs that actually
/// expose `fan1_input` produce a fan entity (a fanless/blower SKU yields none).
fn read_intel_fan_states(gpus: &[IntelGpuInfo]) -> Vec<AmdGpuFanState> {
    let now = Instant::now();
    gpus.iter()
        .filter(|g| g.has_fan_rpm)
        .map(|g| {
            let fan_input = g.hwmon_path.join("fan1_input");
            let rpm = std::fs::read_to_string(&fan_input)
                .ok()
                .and_then(|s| s.trim().parse::<u16>().ok());

            AmdGpuFanState {
                id: format!("intel_gpu:{}", g.pci_bdf),
                rpm,
                last_commanded_pct: None, // Always None — read-only.
                updated_at: now,
            }
        })
        .collect()
}

/// Run the OpenFanController RPM polling loop.
///
/// Sends `ReadAllRpm` every `interval` and pushes fan state into the cache.
/// After 5 consecutive errors, enters reconnect mode: attempts `auto_detect_port`
/// with exponential backoff (1s..30s) until the device reappears.
pub async fn openfan_poll_loop(
    cache: Arc<StateCache>,
    transport: Arc<parking_lot::Mutex<Box<dyn SerialTransport + Send>>>,
    timeout: Duration,
    interval: Duration,
    mut shutdown: watch::Receiver<bool>,
) {
    let mut tick = tokio::time::interval(interval);
    tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    let mut consecutive_errors: u32 = 0;
    let reconnect_threshold: u32 = 5;
    let mut reconnect_backoff: u32 = 1;

    loop {
        tokio::select! {
            _ = tick.tick() => {}
            _ = shutdown.changed() => {
                log::info!("openfan poll loop shutting down");
                return;
            }
        }

        // If too many consecutive errors, attempt reconnect instead of polling
        if consecutive_errors >= reconnect_threshold {
            let cycle = consecutive_errors - reconnect_threshold;
            let skip_cycles = reconnect_backoff.min(30);
            if skip_cycles == 0 || !cycle.is_multiple_of(skip_cycles) {
                consecutive_errors += 1;
                continue;
            }

            let t = timeout;
            let reconnect_result = tokio::task::spawn_blocking(move || {
                crate::serial::real_transport::auto_detect_port(t).and_then(|path| {
                    crate::serial::real_transport::RealSerialTransport::open(&path, t)
                        .ok()
                        .map(|rt| -> Box<dyn SerialTransport + Send> { Box::new(rt) })
                })
            })
            .await;

            match reconnect_result {
                Ok(Some(new_transport)) => {
                    let mut guard = transport.lock();
                    *guard = new_transport;
                    consecutive_errors = 0;
                    reconnect_backoff = 1;
                    log::info!("OpenFan Controller reconnected");
                    continue;
                }
                _ => {
                    reconnect_backoff = (reconnect_backoff * 2).min(30);
                    consecutive_errors += 1;
                    if consecutive_errors == reconnect_threshold + 1 {
                        log::warn!("OpenFan Controller disconnected — entering reconnect mode");
                    }
                    continue;
                }
            }
        }

        // Serial I/O is blocking — run on blocking pool
        let transport = transport.clone();
        let result = tokio::task::spawn_blocking(move || {
            let mut guard = transport.lock();
            send_command(&mut **guard, &Command::ReadAllRpm, timeout)
        })
        .await;

        match result {
            Ok(Ok(response)) => {
                consecutive_errors = 0;
                reconnect_backoff = 1;
                let now = Instant::now();
                match response {
                    crate::serial::protocol::Response::Rpm { readings, .. } => {
                        // Preserve last_commanded_pwm from existing cache entries
                        let snap = cache.snapshot();
                        let fans: Vec<OpenFanState> = readings
                            .iter()
                            .map(|r| {
                                let existing_pwm = snap
                                    .openfan_fans
                                    .get(&r.channel)
                                    .and_then(|f| f.last_commanded_pwm);
                                OpenFanState {
                                    channel: r.channel,
                                    rpm: r.rpm,
                                    last_commanded_pwm: existing_pwm,
                                    updated_at: now,
                                    rpm_polled: true,
                                }
                            })
                            .collect();
                        let count = fans.len();
                        cache.update_openfan_fans(fans);
                        log::debug!("openfan poll: {count} channels updated");
                    }
                }
            }
            Ok(Err(e)) => {
                consecutive_errors += 1;
                if consecutive_errors <= 3 {
                    log::warn!("openfan poll error: {e}");
                } else if consecutive_errors == 4 {
                    log::warn!("openfan poll error (suppressing until periodic reminder): {e}");
                } else if consecutive_errors.is_multiple_of(60) {
                    log::warn!(
                        "openfan poll error (persistent — {consecutive_errors} consecutive failures): {e}"
                    );
                }
            }
            Err(e) => {
                log::error!("openfan poll task panicked: {e}");
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    // ── DEC-133: sensor descriptor cache ─────────────────────────────

    /// Write a fake k10temp device (CpuTemp) into the tempdir sysfs root.
    fn write_k10temp(root: &std::path::Path, temp_c: f64) {
        let dir = root.join("hwmon0");
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("name"), "k10temp\n").unwrap();
        fs::write(
            dir.join("temp1_input"),
            format!("{}\n", (temp_c * 1000.0) as i64),
        )
        .unwrap();
        fs::write(dir.join("temp1_label"), "Tctl\n").unwrap();
    }

    /// Write a fake nvme device (non-CPU) into the tempdir sysfs root.
    fn write_nvme(root: &std::path::Path) {
        let dir = root.join("hwmon1");
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("name"), "nvme\n").unwrap();
        fs::write(dir.join("temp1_input"), "38000\n").unwrap();
        fs::write(dir.join("temp1_label"), "Composite\n").unwrap();
    }

    struct PollHarness {
        cache: Arc<StateCache>,
        rescan: Arc<std::sync::atomic::AtomicBool>,
        shutdown_tx: watch::Sender<bool>,
        handle: tokio::task::JoinHandle<()>,
    }

    fn spawn_poll_loop(root: std::path::PathBuf) -> PollHarness {
        let cache = Arc::new(StateCache::new());
        let rescan = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let (shutdown_tx, shutdown_rx) = watch::channel(false);
        let history = Arc::new(crate::health::history::HistoryRing::new(16));
        let (cache2, rescan2) = (cache.clone(), rescan.clone());
        let handle = tokio::spawn(async move {
            hwmon_poll_loop(
                cache2,
                history,
                Vec::new(),
                Vec::new(),
                Vec::new(),
                &root,
                Duration::from_secs(1),
                rescan2,
                shutdown_rx,
            )
            .await;
        });
        PollHarness {
            cache,
            rescan,
            shutdown_tx,
            handle,
        }
    }

    async fn stop(h: PollHarness) {
        let _ = h.shutdown_tx.send(true);
        let _ = tokio::time::timeout(Duration::from_secs(5), h.handle).await;
    }

    fn sensor_by_label(
        cache: &StateCache,
        label: &str,
    ) -> Option<crate::health::state::CachedSensorReading> {
        cache
            .sensors_snapshot()
            .values()
            .find(|s| s.label == label)
            .cloned()
    }

    /// Per-tick reads must use the cached descriptor set: changing a label
    /// file after discovery is invisible until a refresh trigger, while
    /// values stay fresh.
    #[tokio::test(start_paused = true)]
    async fn poll_loop_uses_cached_descriptors_between_ticks() {
        let tmp = tempfile::tempdir().unwrap();
        write_k10temp(tmp.path(), 55.0);
        let h = spawn_poll_loop(tmp.path().to_path_buf());

        // Tick 1 fires immediately (interval semantics) — wait past it.
        tokio::time::sleep(Duration::from_millis(500)).await;
        assert!(
            sensor_by_label(&h.cache, "Tctl").is_some(),
            "initial discovery"
        );

        // Mutate the label (descriptor metadata) AND the value.
        fs::write(tmp.path().join("hwmon0/temp1_label"), "Changed\n").unwrap();
        fs::write(tmp.path().join("hwmon0/temp1_input"), "65000\n").unwrap();
        tokio::time::sleep(Duration::from_millis(1000)).await; // tick 2

        let s = sensor_by_label(&h.cache, "Tctl")
            .expect("label must come from the cached descriptor, not a re-read");
        assert!(
            (s.value_c - 65.0).abs() < f64::EPSILON,
            "values must stay fresh"
        );
        assert!(
            sensor_by_label(&h.cache, "Changed").is_none(),
            "no re-discovery without a trigger (DEC-133)"
        );

        stop(h).await;
    }

    /// The /hwmon/rescan flag forces a descriptor refresh on the next tick
    /// and is consumed by the loop.
    #[tokio::test(start_paused = true)]
    async fn poll_loop_rediscovers_on_rescan_flag() {
        let tmp = tempfile::tempdir().unwrap();
        write_k10temp(tmp.path(), 55.0);
        let h = spawn_poll_loop(tmp.path().to_path_buf());

        tokio::time::sleep(Duration::from_millis(500)).await; // tick 1
        fs::write(tmp.path().join("hwmon0/temp1_label"), "Renamed\n").unwrap();
        h.rescan.store(true, std::sync::atomic::Ordering::SeqCst);
        tokio::time::sleep(Duration::from_millis(1000)).await; // tick 2

        assert!(
            sensor_by_label(&h.cache, "Renamed").is_some(),
            "rescan flag must trigger re-discovery"
        );
        assert!(
            !h.rescan.load(std::sync::atomic::Ordering::SeqCst),
            "flag must be consumed"
        );

        stop(h).await;
    }

    /// A descriptor failing value-reads for the configured streak triggers
    /// one re-discovery (device unbound mid-session).
    #[tokio::test(start_paused = true)]
    async fn poll_loop_rediscovers_after_read_failure_streak() {
        let tmp = tempfile::tempdir().unwrap();
        write_k10temp(tmp.path(), 55.0);
        let h = spawn_poll_loop(tmp.path().to_path_buf());

        tokio::time::sleep(Duration::from_millis(500)).await; // tick 1
                                                              // Device vanishes; a different chip appears (not yet discovered).
        fs::remove_file(tmp.path().join("hwmon0/temp1_input")).unwrap();
        write_nvme(tmp.path());

        // Streak builds one failed tick at a time, then the next tick
        // re-discovers: STREAK ticks + 1 + margin.
        let ticks = crate::constants::SENSOR_READ_FAIL_REDISCOVER_STREAK + 2;
        for _ in 0..ticks {
            tokio::time::sleep(Duration::from_millis(1000)).await;
        }

        assert!(
            sensor_by_label(&h.cache, "Composite").is_some(),
            "read-failure streak must trigger re-discovery and pick up the new chip"
        );

        stop(h).await;
    }

    /// While no CpuTemp descriptor is cached, the loop re-discovers every
    /// tick — a late-loading k10temp must appear without any flag, so the
    /// no-sensor 40% fallback can release (P0-R1).
    #[tokio::test(start_paused = true)]
    async fn poll_loop_rediscovers_while_no_cpu_sensor_cached() {
        let tmp = tempfile::tempdir().unwrap();
        write_nvme(tmp.path()); // non-CPU only
        let h = spawn_poll_loop(tmp.path().to_path_buf());

        tokio::time::sleep(Duration::from_millis(500)).await; // tick 1
        assert!(sensor_by_label(&h.cache, "Composite").is_some());

        // CPU sensor module loads late.
        write_k10temp(tmp.path(), 60.0);
        tokio::time::sleep(Duration::from_millis(1000)).await; // tick 2

        assert!(
            sensor_by_label(&h.cache, "Tctl").is_some(),
            "missing-CpuTemp trigger must re-discover every tick"
        );

        stop(h).await;
    }

    fn fake_intel_gpu(
        hwmon_path: std::path::PathBuf,
        bdf: &str,
        has_fan_rpm: bool,
    ) -> IntelGpuInfo {
        IntelGpuInfo {
            pci_bdf: bdf.to_string(),
            pci_device_id: 0xE20B,
            pci_revision: 0,
            pci_class: 0x030000,
            marketing_name: Some("Arc B580".into()),
            driver: "xe".into(),
            hwmon_path,
            is_discrete: true,
            has_fan_rpm,
        }
    }

    #[test]
    fn read_intel_fan_states_reads_rpm_with_intel_prefix() {
        let tmp = tempfile::tempdir().unwrap();
        let hwmon = tmp.path().join("hwmon3");
        fs::create_dir_all(&hwmon).unwrap();
        fs::write(hwmon.join("fan1_input"), "1234\n").unwrap();

        let gpus = [fake_intel_gpu(hwmon, "0000:03:00.0", true)];
        let states = read_intel_fan_states(&gpus);

        assert_eq!(states.len(), 1);
        assert_eq!(states[0].id, "intel_gpu:0000:03:00.0");
        assert_eq!(states[0].rpm, Some(1234));
        // Read-only: never a commanded percentage.
        assert_eq!(states[0].last_commanded_pct, None);
    }

    #[test]
    fn read_intel_fan_states_skips_fanless_gpu() {
        let tmp = tempfile::tempdir().unwrap();
        let hwmon = tmp.path().join("hwmon3");
        fs::create_dir_all(&hwmon).unwrap();

        let gpus = [fake_intel_gpu(hwmon, "0000:03:00.0", false)];
        assert!(read_intel_fan_states(&gpus).is_empty());
    }

    #[test]
    fn read_intel_fan_states_missing_file_yields_none_rpm() {
        // has_fan_rpm true at detection, but the file vanished by poll time.
        let tmp = tempfile::tempdir().unwrap();
        let hwmon = tmp.path().join("hwmon3");
        fs::create_dir_all(&hwmon).unwrap();

        let gpus = [fake_intel_gpu(hwmon, "0000:03:00.0", true)];
        let states = read_intel_fan_states(&gpus);
        assert_eq!(states.len(), 1);
        assert_eq!(states[0].rpm, None);
    }
}
