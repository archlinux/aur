//! Hwmon PWM and lease endpoints.
//!
//! Named `hwmon_ctl` to avoid confusion with the top-level `crate::hwmon` module.

use std::sync::Arc;

use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::Json;

use super::{error_response, json_ok, AppState};
use crate::api::responses::*;
use crate::hwmon::lease::LeaseError;
use crate::hwmon::pwm_control::HwmonControlError;

/// GET /hwmon/headers — list discovered controllable PWM headers.
pub async fn hwmon_headers_handler(
    State(state): State<Arc<AppState>>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(ref controller) = state.hwmon_controller else {
        return json_ok(
            StatusCode::OK,
            PwmHeadersResponse {
                api_version: API_VERSION,
                headers: vec![],
            },
        );
    };

    let ctrl = controller.lock();

    let headers = ctrl
        .headers()
        .iter()
        .map(|h| PwmHeaderEntry {
            id: h.id.clone(),
            label: h.label.clone(),
            chip_name: h.chip_name.clone(),
            device_id: h.device_id.clone(),
            pwm_index: h.pwm_index,
            supports_enable: h.supports_enable,
            rpm_available: h.rpm_available,
            min_pwm_percent: h.min_pwm_percent,
            max_pwm_percent: h.max_pwm_percent,
            is_writable: h.is_writable,
            pwm_mode: h.pwm_mode,
        })
        .collect();

    json_ok(
        StatusCode::OK,
        PwmHeadersResponse {
            api_version: API_VERSION,
            headers,
        },
    )
}

/// POST /hwmon/lease/take — acquire the exclusive hwmon write lease.
pub async fn hwmon_lease_take_handler(
    State(state): State<Arc<AppState>>,
    Json(body): Json<TakeLeaseRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(ref controller) = state.hwmon_controller else {
        return error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            &ErrorEnvelope::hardware_unavailable("no hwmon PWM headers available"),
        );
    };

    let mut ctrl = controller.lock();

    // GUI always preempts internal holders (profile engine, thermal safety).
    // Use force_take to evict any current holder.
    let lease = ctrl.lease_manager_mut().force_take_lease(&body.owner_hint);
    json_ok(
        StatusCode::OK,
        LeaseResponse {
            api_version: API_VERSION,
            lease_id: lease.lease_id.clone(),
            owner_hint: lease.owner_hint.clone(),
            ttl_seconds: lease.ttl_seconds(),
        },
    )
}

/// POST /hwmon/lease/release — release the hwmon write lease.
pub async fn hwmon_lease_release_handler(
    State(state): State<Arc<AppState>>,
    Json(body): Json<ReleaseLeaseRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(ref controller) = state.hwmon_controller else {
        return error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            &ErrorEnvelope::hardware_unavailable("no hwmon PWM headers available"),
        );
    };

    let mut ctrl = controller.lock();

    match ctrl.lease_manager_mut().release_lease(&body.lease_id) {
        Ok(()) => {
            ctrl.on_lease_released();
            json_ok(
                StatusCode::OK,
                LeaseReleasedResponse {
                    api_version: API_VERSION,
                    released: true,
                },
            )
        }
        Err(LeaseError::InvalidLease) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error("invalid lease id"),
        ),
        Err(LeaseError::Expired) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error("lease expired"),
        ),
        Err(LeaseError::NoLease) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error("no active lease to release"),
        ),
        Err(e) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error(e.to_string()),
        ),
    }
}

/// GET /hwmon/lease/status — lease status for UI display.
pub async fn hwmon_lease_status_handler(
    State(state): State<Arc<AppState>>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(ref controller) = state.hwmon_controller else {
        let resp = LeaseStatusResponse {
            api_version: API_VERSION,
            lease_required: true,
            held: false,
            lease_id: None,
            ttl_seconds_remaining: None,
            owner_hint: None,
        };
        return json_ok(StatusCode::OK, resp);
    };

    let ctrl = controller.lock();

    let resp = match ctrl.lease_manager().active_lease() {
        Some(lease) => LeaseStatusResponse {
            api_version: API_VERSION,
            lease_required: true,
            held: true,
            lease_id: Some(lease.lease_id.clone()),
            ttl_seconds_remaining: Some(lease.ttl_seconds()),
            owner_hint: Some(lease.owner_hint.clone()),
        },
        None => LeaseStatusResponse {
            api_version: API_VERSION,
            lease_required: true,
            held: false,
            lease_id: None,
            ttl_seconds_remaining: None,
            owner_hint: None,
        },
    };

    json_ok(StatusCode::OK, resp)
}

/// POST /hwmon/lease/renew — extend the TTL of the current lease.
pub async fn hwmon_lease_renew_handler(
    State(state): State<Arc<AppState>>,
    Json(body): Json<RenewLeaseRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(ref controller) = state.hwmon_controller else {
        return error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            &ErrorEnvelope::hardware_unavailable("no hwmon PWM headers available"),
        );
    };

    let mut ctrl = controller.lock();

    match ctrl.lease_manager_mut().renew_lease(&body.lease_id) {
        Ok(lease) => json_ok(
            StatusCode::OK,
            LeaseResponse {
                api_version: API_VERSION,
                lease_id: lease.lease_id.clone(),
                owner_hint: lease.owner_hint.clone(),
                ttl_seconds: lease.ttl_seconds(),
            },
        ),
        Err(LeaseError::InvalidLease) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error("invalid lease id"),
        ),
        Err(LeaseError::Expired) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error("lease expired"),
        ),
        Err(e) => error_response(
            StatusCode::BAD_REQUEST,
            &ErrorEnvelope::lease_error(e.to_string()),
        ),
    }
}

/// POST /hwmon/{header_id}/pwm — set PWM on an hwmon header (requires lease).
///
/// DEC-099: dispatched on `spawn_blocking` to keep tokio worker threads
/// available while the (parking_lot) controller mutex is held by another
/// task. Hwmon writes are typically sub-millisecond, but contention with
/// the verify endpoint or the thermal-emergency scan can extend the
/// critical section by seconds.
///
/// DEC-102: short-circuit with `400 feature_unavailable` when the header's
/// discovered `is_writable` flag is `false`. Without this guard the kernel
/// returns `EACCES`, which the controller surfaces as `503 hardware_unavailable`
/// with `retryable: true` — a misclassification that traps GUI clients with
/// retry policies into a 1 Hz storm. The condition (a read-only sysfs file)
/// is permanent for this header, so the correct envelope is the same one
/// DEC-094/DEC-098 chose for capability gaps. Defense-in-depth: discovery
/// already drops `chip_name == "amdgpu"` (the canonical case), so this path
/// only fires when an unforeseen chip exposes a read-only `pwmN`.
pub async fn hwmon_set_pwm_handler(
    State(state): State<Arc<AppState>>,
    Path(header_id): Path<String>,
    Json(body): Json<HwmonSetPwmRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let Some(controller) = state.hwmon_controller.clone() else {
        return error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            &ErrorEnvelope::hardware_unavailable("no hwmon PWM headers available"),
        );
    };

    // Pre-flight writability check (DEC-102). Mirrors the GPU handlers'
    // `feature_unavailable` shape from DEC-098 so a single-prefix client
    // (the GUI control loop) can treat the response as "drop this member"
    // rather than "retry next cycle".
    {
        let ctrl = controller.lock();
        match ctrl.headers().into_iter().find(|h| h.id == header_id) {
            Some(h) if !h.is_writable => {
                return error_response(
                    StatusCode::BAD_REQUEST,
                    &ErrorEnvelope::feature_unavailable(format!(
                        "hwmon header '{header_id}' is read-only \
                         (sysfs pwm file lacks write permission); \
                         this header cannot accept PWM writes"
                    )),
                );
            }
            Some(_) => {}
            None => {
                return error_response(
                    StatusCode::NOT_FOUND,
                    &ErrorEnvelope::validation(format!("unknown header: {header_id}")),
                );
            }
        }
    }

    let pwm_percent = body.pwm_percent;
    let lease_id = body.lease_id.clone();
    let header_id_clone = header_id.clone();
    let result = tokio::task::spawn_blocking(move || {
        controller
            .lock()
            .set_pwm(&header_id_clone, pwm_percent, &lease_id)
    })
    .await;

    match result {
        Ok(Ok(set_result)) => {
            state.cache.record_gui_write();
            json_ok(
                StatusCode::OK,
                HwmonSetPwmResponse {
                    api_version: API_VERSION,
                    header_id: set_result.header_id,
                    pwm_percent: set_result.pwm_percent,
                    raw_value: set_result.raw_value,
                },
            )
        }
        Ok(Err(e)) => hwmon_control_error_response(e),
        Err(e) => error_response(
            StatusCode::INTERNAL_SERVER_ERROR,
            &ErrorEnvelope::internal(format!("hwmon write task failed: {e}")),
        ),
    }
}

/// Map a `HwmonControlError` to an HTTP error response.
fn hwmon_control_error_response(err: HwmonControlError) -> (StatusCode, Json<serde_json::Value>) {
    match err {
        HwmonControlError::Lease(LeaseError::AlreadyHeld {
            owner_hint,
            ttl_seconds,
        }) => error_response(
            StatusCode::CONFLICT,
            &ErrorEnvelope::lease_already_held(format!(
                "lease held by '{owner_hint}' (expires in {ttl_seconds}s)"
            )),
        ),
        HwmonControlError::Lease(_) => error_response(
            StatusCode::FORBIDDEN,
            &ErrorEnvelope::lease_error("valid lease required for hwmon PWM writes"),
        ),
        HwmonControlError::Validation(msg) => {
            error_response(StatusCode::BAD_REQUEST, &ErrorEnvelope::validation(msg))
        }
        HwmonControlError::Hardware(_) => error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            &ErrorEnvelope::hardware_unavailable(err.to_string()),
        ),
    }
}

/// POST /hwmon/rescan — re-enumerate hwmon devices and return fresh header list.
///
/// Also flags the sensor polling loop to rebuild its cached descriptor set
/// (labels, types, DEC-117 threshold snapshot) on its next tick (DEC-133) —
/// this is how newly loaded sensor chips appear without a daemon restart.
/// Does not replace the running PWM controller — header discovery results
/// are returned for the GUI to refresh its view; a daemon restart is needed
/// to pick up truly new PWM-control hardware.
pub async fn hwmon_rescan_handler(
    State(state): State<Arc<AppState>>,
) -> (StatusCode, Json<serde_json::Value>) {
    use crate::hwmon::pwm_discovery::discover_pwm_headers;
    use crate::hwmon::HWMON_SYSFS_ROOT;

    // DEC-133: the polling loop owns the descriptor cache; it swap-checks
    // this flag each tick and re-runs sensor discovery when set.
    state
        .sensor_rescan_requested
        .store(true, std::sync::atomic::Ordering::SeqCst);

    let hwmon_root = std::path::Path::new(HWMON_SYSFS_ROOT);
    match discover_pwm_headers(hwmon_root) {
        Ok(headers) => {
            let entries: Vec<PwmHeaderEntry> = headers
                .iter()
                .map(|h| PwmHeaderEntry {
                    id: h.id.clone(),
                    label: h.label.clone(),
                    chip_name: h.chip_name.clone(),
                    device_id: h.device_id.clone(),
                    pwm_index: h.pwm_index,
                    supports_enable: h.supports_enable,
                    rpm_available: h.rpm_available,
                    min_pwm_percent: h.min_pwm_percent,
                    max_pwm_percent: h.max_pwm_percent,
                    is_writable: h.is_writable,
                    pwm_mode: h.pwm_mode,
                })
                .collect();
            log::info!("Hwmon rescan: found {} PWM header(s)", entries.len());
            let count = entries.len();
            json_ok(
                StatusCode::OK,
                serde_json::json!({
                    "api_version": API_VERSION,
                    "headers": entries,
                    "count": count,
                }),
            )
        }
        Err(e) => error_response(
            StatusCode::INTERNAL_SERVER_ERROR,
            &ErrorEnvelope::internal(format!("hwmon rescan failed: {e}")),
        ),
    }
}

/// Settle window for `hwmon_verify_handler`, aliased from the single source
/// of truth in `constants.rs` so the hwmon and GPU verify paths cannot drift
/// apart (DEC-101). See `constants::VERIFY_WAIT_SECONDS` for the rationale and
/// the cross-repo GUI coupling (`VERIFY_PAUSE_SAFETY_MS`).
const VERIFY_WAIT_SECONDS: u8 = crate::constants::VERIFY_WAIT_SECONDS;

/// POST /hwmon/{header_id}/verify — behavioural test of PWM write effectiveness.
///
/// Writes a test PWM value, waits for hardware to respond, then reads back
/// pwm_enable, PWM value, and RPM to classify the result. Requires a valid
/// hwmon lease. Takes ~6 seconds — slow-spinning fans (pumps, large 140mm
/// chassis fans) need >3s to settle, and a too-short wait produced false
/// `no_rpm_effect` verdicts. The GUI's `VERIFY_PAUSE_SAFETY_MS` and the
/// per-call HTTP timeout in `client.py::verify_hwmon_pwm` must stay above
/// this value (≥9 s and ≥12 s respectively).
pub async fn hwmon_verify_handler(
    State(state): State<Arc<AppState>>,
    axum::extract::Path(header_id): axum::extract::Path<String>,
    Json(body): Json<HwmonVerifyRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let controller = match &state.hwmon_controller {
        Some(c) => c,
        None => {
            // M12: match sibling hwmon handlers which all return 503
            // hardware_unavailable when the controller is absent. Returning
            // 404 here implied the endpoint itself was missing, which it is
            // not — the hardware is.
            return error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                &ErrorEnvelope::hardware_unavailable("no hwmon PWM headers available"),
            );
        }
    };

    // Validate lease and extract header paths
    let (pwm_path, enable_path, rpm_path) = {
        let ctrl = controller.lock();
        if let Err(e) = ctrl.lease_manager().validate_lease(&body.lease_id) {
            return error_response(
                StatusCode::FORBIDDEN,
                &ErrorEnvelope::lease_error(e.to_string()),
            );
        }
        match ctrl.headers().into_iter().find(|h| h.id == header_id) {
            Some(h) => (
                h.pwm_path.clone(),
                h.enable_path.clone(),
                h.rpm_path.clone(),
            ),
            None => {
                return error_response(
                    StatusCode::NOT_FOUND,
                    &ErrorEnvelope::validation(format!("unknown header: {header_id}")),
                )
            }
        }
    };

    let read_state = |pwm: &str, en: &Option<String>, rpm: &Option<String>| -> HwmonVerifyState {
        let pwm_raw = std::fs::read_to_string(pwm)
            .ok()
            .and_then(|s| s.trim().parse::<u8>().ok());
        let pwm_enable = en.as_ref().and_then(|p| {
            std::fs::read_to_string(p)
                .ok()
                .and_then(|s| s.trim().parse::<u8>().ok())
        });
        let rpm_val = rpm.as_ref().and_then(|p| {
            std::fs::read_to_string(p)
                .ok()
                .and_then(|s| s.trim().parse::<u16>().ok())
        });
        HwmonVerifyState {
            pwm_enable,
            pwm_raw,
            pwm_percent: pwm_raw.map(crate::pwm::raw_to_percent),
            rpm: rpm_val,
        }
    };

    // Read initial state
    let initial = read_state(&pwm_path, &enable_path, &rpm_path);

    // Calculate test PWM: ensure a significant delta from current
    let current_pct = initial.pwm_percent.unwrap_or(50);
    let test_pct: u8 = if current_pct > 50 { 20 } else { 80 };

    // Write test value via controller (sets pwm_enable=1 + PWM).
    // Route errors through the shared HwmonControlError mapper: a lease that
    // expired between the up-front validate_lease check and this write must
    // surface as 403 lease_required, not 500 internal_error.
    {
        let mut ctrl = controller.lock();
        if let Err(e) = ctrl.set_pwm(&header_id, test_pct, &body.lease_id) {
            return hwmon_control_error_response(e);
        }
    }

    // Wait for hardware to respond
    tokio::time::sleep(std::time::Duration::from_secs(VERIFY_WAIT_SECONDS as u64)).await;

    // Read back state after wait
    let final_state = read_state(&pwm_path, &enable_path, &rpm_path);

    // Restore original PWM. Failures here are surfaced via
    // ``restore_failed`` rather than overwriting the diagnostic verify
    // outcome — a successful verify with a failed restore is its own
    // condition the caller can act on (typically: re-write the desired
    // PWM). Previously the error was silently swallowed.
    let restore_failed = {
        let mut ctrl = controller.lock();
        match ctrl.set_pwm(&header_id, current_pct, &body.lease_id) {
            Ok(_) => false,
            Err(e) => {
                log::warn!(
                    "verify: restore PWM to {current_pct}% on {header_id} \
                     failed (header left at test value {test_pct}%): {e}"
                );
                true
            }
        }
    };

    // Classify result
    let (result, details) = classify_verify_result(&initial, &final_state, test_pct);

    json_ok(
        StatusCode::OK,
        HwmonVerifyResponse {
            header_id,
            result,
            initial_state: initial,
            final_state,
            test_pwm_percent: test_pct,
            wait_seconds: VERIFY_WAIT_SECONDS,
            details,
            restore_failed,
        },
    )
}

fn classify_verify_result(
    initial: &HwmonVerifyState,
    final_state: &HwmonVerifyState,
    test_pct: u8,
) -> (String, String) {
    // Check if pwm_enable was reclaimed
    if let Some(final_enable) = final_state.pwm_enable {
        if final_enable != 1 {
            return (
                "pwm_enable_reverted".into(),
                format!(
                    "pwm_enable changed from 1 to {final_enable} after write. \
                     Most likely cause: BIOS/EC firmware reasserting automatic \
                     mode (e.g. AORUS Smart Fan reclaim). Less likely: another \
                     in-process writer (lease holder, thermal-safety override) \
                     flipped pwm_enable during the {VERIFY_WAIT_SECONDS}s test \
                     window. Re-run with no profile active and no other client \
                     writing to disambiguate."
                ),
            );
        }
    }

    // Check if PWM value was clamped/overridden
    let test_raw = crate::pwm::percent_to_raw(test_pct);
    if let Some(final_raw) = final_state.pwm_raw {
        let delta = (final_raw as i16 - test_raw as i16).unsigned_abs();
        if delta > 10 {
            return (
                "pwm_value_clamped".into(),
                format!(
                    "PWM value changed from test {test_raw} to {final_raw} during \
                     the {VERIFY_WAIT_SECONDS}s verify window. Most likely cause: \
                     BIOS/EC firmware overriding the PWM register. Less likely: \
                     another writer (lease holder, thermal-safety override, or a \
                     CLI tool poking sysfs directly) wrote to the same header \
                     during the test. Re-run with no profile active and no other \
                     client writing to confirm BIOS/EC reclaim."
                ),
            );
        }
    }

    // Check RPM change (if available)
    match (initial.rpm, final_state.rpm) {
        (Some(init_rpm), Some(final_rpm)) if init_rpm > 100 => {
            let expected_decrease = test_pct < initial.pwm_percent.unwrap_or(50);
            let rpm_changed = if expected_decrease {
                final_rpm < init_rpm.saturating_sub(init_rpm / 5)
            } else {
                final_rpm > init_rpm + init_rpm / 5
            };
            if !rpm_changed {
                return (
                    "no_rpm_effect".into(),
                    format!(
                        "RPM unchanged ({init_rpm} \u{2192} {final_rpm}) despite PWM change — \
                         PWM writes may be accepted but have no hardware effect"
                    ),
                );
            }
            (
                "effective".into(),
                format!("PWM control verified: RPM changed {init_rpm} \u{2192} {final_rpm}"),
            )
        }
        _ => (
            "rpm_unavailable".into(),
            "PWM values held but RPM sensor unavailable or too low to verify".into(),
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::hwmon::lease::LeaseError;
    use crate::hwmon::pwm_control::HwmonControlError;

    /// P1-2 regression: a `HwmonControlError::Lease(_)` — which is what
    /// `set_pwm` returns when the lease expires mid-call — must map to
    /// 403 `lease_required`, never 500 `internal_error`. The verify handler
    /// previously hand-rolled a 500; it now delegates to this mapper.
    #[test]
    fn hwmon_control_error_response_maps_lease_to_403() {
        let err = HwmonControlError::Lease(LeaseError::NoLease);
        let (status, body) = hwmon_control_error_response(err);
        assert_eq!(status, StatusCode::FORBIDDEN);
        let json = body.0;
        assert_eq!(json["error"]["code"], "lease_required");
        assert_eq!(json["error"]["retryable"], false);
    }

    #[test]
    fn hwmon_control_error_response_maps_invalid_lease_to_403() {
        let err = HwmonControlError::Lease(LeaseError::InvalidLease);
        let (status, body) = hwmon_control_error_response(err);
        assert_eq!(status, StatusCode::FORBIDDEN);
        let json = body.0;
        assert_eq!(json["error"]["code"], "lease_required");
    }

    #[test]
    fn hwmon_control_error_response_maps_expired_lease_to_403() {
        // T2 (test-tests audit): Expired joined LeaseError as a distinct
        // variant. The HTTP shape must remain 403 lease_required so existing
        // GUI retry policies (re-acquire on 403) keep working.
        let err = HwmonControlError::Lease(LeaseError::Expired);
        let (status, body) = hwmon_control_error_response(err);
        assert_eq!(status, StatusCode::FORBIDDEN);
        let json = body.0;
        assert_eq!(json["error"]["code"], "lease_required");
        assert_eq!(json["error"]["retryable"], false);
    }

    /// B1: classify_verify_result `details` must acknowledge that an
    /// in-process concurrent writer is a possible cause of a register
    /// change during the verify wait. Before B1 the wording named BIOS/EC
    /// as the only cause, which produced false `pwm_value_clamped`
    /// verdicts on the X870E AORUS MASTER where the GUI's own control
    /// loop was the racer.
    #[test]
    fn pwm_value_clamped_details_acknowledges_concurrent_writers() {
        let initial = HwmonVerifyState {
            pwm_enable: Some(1),
            pwm_raw: Some(128),
            pwm_percent: Some(50),
            rpm: Some(1000),
        };
        // pwm_raw drifted significantly from the test value — should
        // produce pwm_value_clamped.
        let final_state = HwmonVerifyState {
            pwm_enable: Some(1),
            pwm_raw: Some(200),
            pwm_percent: Some(78),
            rpm: Some(1500),
        };
        let (result, details) = classify_verify_result(&initial, &final_state, 20);
        assert_eq!(result, "pwm_value_clamped");
        // Headline cause is still BIOS/EC — the most common case in the wild.
        assert!(details.contains("BIOS/EC"), "details: {details:?}");
        // But the wording must also call out the concurrent-writer alternative.
        assert!(details.contains("another writer"), "details: {details:?}");
        // The disambiguation hint must be present so users know how to confirm.
        assert!(
            details.contains("Re-run with no profile active"),
            "details: {details:?}"
        );
    }

    #[test]
    fn pwm_enable_reverted_details_acknowledges_concurrent_writers() {
        let initial = HwmonVerifyState {
            pwm_enable: Some(1),
            pwm_raw: Some(128),
            pwm_percent: Some(50),
            rpm: Some(1000),
        };
        // pwm_enable flipped back to 2 (auto/cruise) — pwm_enable_reverted.
        let final_state = HwmonVerifyState {
            pwm_enable: Some(2),
            pwm_raw: Some(128),
            pwm_percent: Some(50),
            rpm: Some(1000),
        };
        let (result, details) = classify_verify_result(&initial, &final_state, 20);
        assert_eq!(result, "pwm_enable_reverted");
        assert!(details.contains("BIOS/EC"), "details: {details:?}");
        assert!(
            details.contains("another in-process writer"),
            "details: {details:?}"
        );
        assert!(
            details.contains("Re-run with no profile active"),
            "details: {details:?}"
        );
    }

    /// B1: result enum values must remain unchanged so the GUI's
    /// `hwmon_guidance.verification_guidance` lookup still finds the right
    /// keys without coordinated GUI redeploys. The wording change is
    /// limited to the `details` field.
    #[test]
    fn b1_result_enum_values_unchanged() {
        let initial = HwmonVerifyState {
            pwm_enable: Some(1),
            pwm_raw: Some(128),
            pwm_percent: Some(50),
            rpm: None,
        };
        let reverted = HwmonVerifyState {
            pwm_enable: Some(2),
            pwm_raw: Some(128),
            pwm_percent: Some(50),
            rpm: None,
        };
        let (result, _) = classify_verify_result(&initial, &reverted, 20);
        assert_eq!(result, "pwm_enable_reverted");

        let clamped = HwmonVerifyState {
            pwm_enable: Some(1),
            pwm_raw: Some(200),
            pwm_percent: Some(78),
            rpm: None,
        };
        let (result, _) = classify_verify_result(&initial, &clamped, 20);
        assert_eq!(result, "pwm_value_clamped");
    }
}
