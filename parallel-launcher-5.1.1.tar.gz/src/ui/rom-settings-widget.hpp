#ifndef SRC_UI_ROM_SETTINGS_WIDGET_HPP_
#define SRC_UI_ROM_SETTINGS_WIDGET_HPP_

#include <QWidget>
#include "src/core/settings.hpp"

namespace Ui {
	class RomSettingsWidget;
}

class RomSettingsWidget : public QWidget {
	Q_OBJECT

	private:
	Ui::RomSettingsWidget *m_ui;
	bool m_suppressEvents;
	bool m_showAllPlugins;
	bool m_accurateDepthCompare;

	public:
	explicit RomSettingsWidget( QWidget *parent = nullptr );
	virtual ~RomSettingsWidget();

	void setSettings(
		const Uuid &inputMode,
		EmulatorCore core,
		GfxPlugin parallelPlugin,
		GfxPlugin mupenPlugin,
		bool overclockCpu,
		bool overclockVi,
		bool widescreen,
		bool upscaleTexRects,
		bool emulateFramebuffer,
		bool accurateDepthCompare
	);

	const Uuid &getInputMode() const;
	EmulatorCore getEmulatorCore() const;
	GfxPlugin getParallelPlugin() const;
	GfxPlugin getMupenPlugin() const;
	bool overclockCpu() const;
	bool overclockVi() const;
	bool widescreen() const;
	bool upscaleTexRects() const;
	bool emulateFramebuffer() const;
	inline bool accurateDepthCompare() const noexcept { return m_accurateDepthCompare; }

	private:
	void updateWarningVisibility();
	void updatePluginVisibility();
	void updatePluginSettingsVisibility();

	public:
	inline void setShowAllPlugins( bool showAll ) {
		m_showAllPlugins = showAll;
		updatePluginVisibility();
	}

	inline bool showingAllPlugins() const noexcept {
		return m_showAllPlugins;
	}

	private slots:
	void inputModeSelectionChanged();
	void overclockCpuToggled( bool checked );
	void overclockViToggled( bool checked );
	void widescreenToggled( bool checked );
	void upscaleTexRectsToggled( bool checked );
	void emulateFramebufferToggled( bool checked );
	void accurateDepthCompareToggled( bool checked );
	void emulatorChanged();
	void parallelPluginChanged( int pluginId, bool checked );
	void mupenPluginChanged( int pluginId, bool checked );
	void morePluginsToggled();

	signals:
	void inputModeChanged();
	void emulatorCoreChanged();
	void parallelPluginChanged();
	void mupenPluginChanged();
	void overclockCpuChanged( bool );
	void overclockViChanged( bool );
	void widescreenChanged( bool );
	void upscaleTexRectsChanged( bool );
	void emulateFramebufferChanged( bool );
	void accurateDepthCompareChanged( bool );
	void showMorePluginsChanged( bool );

};



#endif /* SRC_UI_ROM_SETTINGS_WIDGET_HPP_ */
