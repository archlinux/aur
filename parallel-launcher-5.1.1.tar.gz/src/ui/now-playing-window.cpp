#include "src/ui/now-playing-window.hpp"
#include "ui_now-playing-window.h"

#include <cstdio>
#include <fstream>

#include "src/rhdc/ui/star-display-widget.hpp"
#include "src/core/numeric-string.hpp"
#include "src/core/time.hpp"
#include "src/ui/icons.hpp"
#include "src/db/data-provider.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/rhdc/core/hack.hpp"
#include "src/rhdc/core/layout.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/polyfill/base-directory.hpp"

NowPlayingWindow::NowPlayingWindow(
	AsyncProcess *process,
	const fs::path &romPath,
	const string &sha1,
	int64 pastPlayTime
) :
	QMainWindow( nullptr ),
	m_ui( new Ui::NowPlayingWindow ),
	m_process( process ),
	m_timer( this ),
	m_pastPlayTime( pastPlayTime ),
	m_startTime( Time::nowMs() )
{
	m_ui->setupUi( this );

	RhdcHack hack;
	if( DataProvider::tryFetchRhdcHackByChecksum( sha1, &hack ) ) {
		m_ui->romNameLabel->setText( hack.info.name.c_str() );
		if( FileController::loadRhdcSettings().enableStarDisplay ) {
			StarLayout layout;
			if( StarLayout::tryLoadLayout( hack.info.hackId, layout ) ) {
				StarDisplayWidget *starDisplay = new StarDisplayWidget( this, RetroArch::getSaveFilePath( romPath ), std::move( layout ) );
				QBoxLayout* centralLayout = qobject_cast<QBoxLayout*>( m_ui->centralwidget->layout() );
				int centralLayoutCount = centralLayout->count();
				centralLayout->insertWidget( centralLayoutCount - 1, starDisplay );
			}
		}
	} else {
		m_ui->romNameLabel->setText( romPath.stem().u8string().c_str() );
	}

	connect( &m_timer, SIGNAL(timeout()), this, SLOT(updateTimers()) );
	m_timer.start( 1000 );

	setWindowIcon( Icon::appIcon() );
	m_ui->killButton->setIcon( Icon::pkill() );

	updateTimers();
}

NowPlayingWindow::~NowPlayingWindow() {
	delete m_ui;
}

int64 NowPlayingWindow::getSessionTime() const {
	return Time::nowMs() - m_startTime;
}

static string formatTime( int64 ms ) {
	static constexpr int64 MINUTE = 60;
	static constexpr int64 HOUR = MINUTE * 60;

	const int64 totalSeconds = (ms + 500ll) / 1000ll;

	const int64 seconds = totalSeconds % MINUTE;
	const int64 minutes = (totalSeconds % HOUR) / MINUTE;
	const int64 hours = totalSeconds / HOUR;

	if( hours > 0 ) {
		char mss[9];
		std::sprintf( mss, ":%02lld:%02lld", minutes, seconds );
		return Number::toString( hours ) + mss;
	} else {
		char mss[8];
		std::sprintf( mss, "%lld:%02lld", minutes, seconds );
		return string( mss );
	}
}

void NowPlayingWindow::killEmulator() {
	m_process->kill();
	close();
}

void NowPlayingWindow::updateTimers() {
	const int64 sessionTime = getSessionTime();
	m_ui->sessionTimeLabel->setText( formatTime( sessionTime ).c_str() );
	m_ui->totalTimeLabel->setText( formatTime( sessionTime + m_pastPlayTime ).c_str() );
}
