#ifndef _WS_URL_H_
#define _WS_URL_H_

#include <sys/types.h>
#include <regex.h>

#include <ws/http.h>
#include <ws/request.h>


typedef void (* WsUrlHandler)(WsRequest * request);

struct _WsUrl
{
    const char       * mask;
    WsUrlHandler       handler;
    void             * re;

};
typedef struct _WsUrl WsUrl;


/* Calls appropriate to request environ variable REQUEST_URI handler from urls
 * @param urls pointer to url structure
 * @param request  WsRequest  instance
 * @param response WsResponse instance
 * */
WsHttpStatus
ws_url_handler_call(WsUrl * urls, WsRequest * request);


#endif
