#ifndef _WS_STATUS_H_
#define _WS_STATUS_H_


enum _WsStatus
{
    wsSuccess,
    wsConnectionTimeout,
    wsConnectionError,
    wsConnectionClosed,
    wsAddressError,
    wsSocketError,
    wsSocketAcceptError,
    wsSocketSelectError,
    wsSocketReadError,
    wsSocketWriteError,
    wsOpenFileError,
    wsConfigSyntaxError,

    wsUnknownStatus
};

typedef enum _WsStatus WsStatus;


const char *
ws_status_get_text(WsStatus status);


#endif
