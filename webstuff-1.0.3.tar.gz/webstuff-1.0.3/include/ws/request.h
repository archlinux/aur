#ifndef __WS_REQUEST_H_
#define __WS_REQUEST_H_

#include <stdarg.h>

#include <ws/types.h>
#include <ws/http.h>
#include <ws/list.h>
#include <ws/status.h>

typedef struct _WsRequest           WsRequest;
typedef struct _WsRequestPrivate    WsRequestPrivate;
typedef enum   _WsRequestEnviron    WsRequestEnviron;

struct _WsRequest {
    WsList            * environ;   /* CGI Environment */
    WsList            * get;       /* GET VARS */
    WsList            * post;      /* POST vars */
    WsList            * cookie;    /* COOKIE vars */
    WsList            * upload;    /* uploaded FILES */
    WsString          * matches;   /* url parsing matches */
    WsRequestPrivate  * priv;      /* private */
};





enum _WsRequestEnviron
{
    wsRequestUri,
    wsRequestMethod,

    wsRemoteAddr,
    wsRemotePort,

    wsScriptName,
    wsScriptFilename,

    wsHttpHost,
    wsHttpUserAgent,
    wsHttpAccept,
    wsHttpAcceptLanguage,
    wsHttpAcceptEncoding,
    wsHttpCookie,
    wsHttpConnection,

    wsServerSoftware,
    wsServerName,
    wsServerProtocol,
    wsServerAddr,
    wsServerPort,
    wsServerAdmin,

    wsContentType,
    wsContentLength,

    wsDocumentUri,
    wsDocumentRoot,

    wsGatewayInterface,

    wsQueryString,

    wsRequestEnvironCount
};


WsString
ws_request_get_env(WsRequest * self, WsRequestEnviron var);

/* + response functions ---------------------------------------------------- */

/* low level send */
WsStatus
ws_put (const WsChar * data, WsInt size,  WsRequest * wsr);

// put string data to streamput stream
WsStatus
ws_print  (WsRequest * wsr, const WsChar * data);

// put formated string to streamput stream
WsStatus
ws_printf (WsRequest * wsr, const WsChar * format, ...);

// put formated string to streamput stream va version
WsStatus
ws_vprintf(WsRequest * wsr, const WsChar * format, va_list arg);


void
ws_set_cookie(WsRequest * wsr, const WsChar  * name,
                               const WsChar  * value,
                               WsInt           expires,
                               const WsChar  * path,
                               const WsChar  * domain,
                               WsBool          secure);

void
ws_set_header(WsRequest * wsr, const WsChar * key, const WsChar * value);


void
ws_set_response_status(WsRequest * wsr, WsHttpStatus status);


WsHttpStatus
ws_get_response_status(WsRequest * wsr);


void
ws_request_set_on_requested(WsRequest * wsr, WsCreateEvent on_request);


void
ws_request_set_on_responded(WsRequest * wsr, WsDestroyEvent on_response);


void
ws_request_set_requested(WsRequest * wsr);


void
ws_request_set_responded(WsRequest * wsr);


WsPointer
ws_request_get_data(WsRequest * wsr);


WsPointer
ws_request_get_worker_data(WsRequest * wsr);


/* + debug methods --------------------------------------------------------- */


void
ws_request_print_environ(WsRequest * wsr);



#endif
