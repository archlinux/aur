#ifndef _WS_MODULE_H_
#define _WS_MODULE_H_

#include <ws/types.h>
#include <ws/thread.h>
#include <ws/log.h>
#include <ws/url.h>


extern const WsVersion     wsVersion;
extern const WsChar        wsWebStuffServer[];



/* types
 *************************************************************************** */

typedef struct _WsModule        WsModule;
typedef struct _WsModulePrivate WsModulePrivate;

struct _WsModule
{
    WsThread             thread;          /* thread */
    WsCreateEvent        on_worker_start;
    WsDestroyEvent       on_worker_stop;
    WsCreateEvent        on_request_ready;
    WsDestroyEvent       on_request_response;
    WsModulePrivate    * priv;
};

/* methods
 *************************************************************************** */

/* Constructor
 * @param name null terminated string with your module name
 * @return new instance of WsModule
 * */
WsModule *
ws_module_new(const WsChar * module_name, const WsVersion * module_version);


/* Destructor
 * @param self instance of WsModule
 * */
void
ws_module_free(WsModule * self);


/* + control methods ------------------------------------------------------- */

/* start module thread
 * @param self instance of WsModule
 * */
void
ws_module_start(WsModule * self);


/* stop module thread
 * @param self instance of WsModule
 * */
void
ws_module_stop(WsModule * self);


/* get termination state
 * @param self instance of WsModule
 * @retrun true if thread is terminated, otherwhise false
 * */
WsBool
ws_module_is_terminated(WsModule * self);


/* + configuration methods ------------------------------------------------- */

/* set up logging component
 * @param self instance of WsModule
 * @param logfile null-terminated string with log file name
 * @param level   bit-mast with log level
 * @return true on success, false on file access error 
 * */
WsBool
ws_module_set_log(WsModule * self, WsChar * logfile, WsInt level);


/* set up listening socket
 * @param self instance of WsModule
 * @param host null terminated string with IP or hostanme
 * @param port number of port
 * */
void
ws_module_set_socket(WsModule * self, const WsChar * host, const WsInt port);


/* set up module urls and their handlers
 * @param self instance of WsModule
 * @param urls array of WsUrl structures, terminated with NULL-mask element
 * */
void
ws_module_set_urls(WsModule * self, WsUrl * urls);


/* set up internal number of threads
 * @param self instance of WsModule
 * @param threads number of threads
 * */
void
ws_module_set_threads(WsModule * self, int threads);



#endif
