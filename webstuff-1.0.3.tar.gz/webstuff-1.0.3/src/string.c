#include <stdio.h> 
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ws/string.h>

#include "macro.h"


const WsChar cEtx = 0x03;


void
ws_string_set_length(WsString * target, WsSize size)
{
    if (!target) return;

    WsString s = *target;;
    /* check if we have some memory and is it enough for us */
    if (!s || ws_string_get_size(s) < size)
    {
        s = calloc(size+2, sizeof(WsChar));
        s[size+1] = cEtx;

        if (*target)
        {
            strncpy(s, *target, MIN(size, strlen(*target)));
            free(*target);
        }
        *target = s;
    }

    /* null-terminate */
    s[size] = 0;
}


void
ws_string_free(WsString str)
{
    if (str)
    {
        free(str);
        *((void**)&str) = NULL;
    }
}


void
ws_string_set(WsString * target, const WsChar * source)
{
    ws_string_copy(target, source, strlen(source));
}


void
ws_string_copy(WsString * target, const WsChar * source, WsSize size)
{
    if (!size && source) size = strlen(source);

    ws_string_set_length(target, size);

    if (source) strncpy(*target, source, size);
}


WsSize
ws_string_get_length(const WsString str)
{
    return strlen(str);
}


WsSize
ws_string_get_size(WsString str)
{
    if (!str) return 0;

    WsChar * s = str;
    while(*s != cEtx) s++;

    return (WsSize)(s-str)-1;
}


void
ws_string_set_from_hex(WsString * target, const WsChar * source, WsSize size)
{
    ws_string_set_length(target, size*3-1);
    char * bp = *target;
    *bp = 0;
    while(size--)
    {
        sprintf(bp, "%.2X%c", *source & 0xff, (size) ? ' ' : 0);
        bp+=3;
        source++;
    }
}


void
ws_string_append(WsString * base, const WsChar * appendix, WsSize size)
{
    WsSize total;

    if (!size) size = strlen(appendix);
    total = size;
    if (*base) total += strlen(*base);

    ws_string_set_length(base, total);

    strncat(*base, appendix, size);
}


void
ws_string_join(WsString * target, const WsChar * pattern,  ...)
{
    WsSize      size = 0;
    WsSize      argc = 0;
    WsChar   *  arg;

    va_list     vl;
    va_start (vl, pattern);

    /* count length */
    while ((arg = va_arg(vl, WsChar*))!=NULL)
    {
        argc++;
        size += strlen(arg);
    }

    va_end(vl);

    va_start (vl, pattern);
    if (argc)
    {
        if (pattern)
            size += (argc-1)*strlen(pattern);
        ws_string_set_length(target, size);
        (*target)[0]=0;
        while (argc--)
        {
            arg = va_arg(vl, WsChar*);
            strcat(*target, arg);
            if (pattern && argc) strcat(*target, pattern);
        }
    }
    va_end(vl);
}


WsString
ws_string_replace( const WsChar      * haystack,
                   const WsChar      * pattern,
                   const WsChar      * needle,
                   WsReplaceOptions    options)
{
    WsSize           size = 0; /* replacements */
    WsSize           plen = strlen(pattern);
    const WsChar   * b    = haystack;
    const WsChar   * e;
    WsString         str;

    while ( (b = strstr(b, pattern)) != NULL) size++;


    size = strlen(haystack) - plen + size*strlen(needle);
    ws_string_set_length(&str, size);
    b    = haystack;

    while ( (e = strstr(b, pattern)) != NULL)
    {
        strncat(str, b, (WsInt) (e-b));
        strcat(str, needle);
        b = &e[plen];
    }
    strcat(str, b);

    return str;
}


WsSize
ws_string_chop(WsString str)
{
    WsChar * p = str;
    WsSize   s = 0;
    WsSize   r;

    /* remove prepending spaces */
    while (*p == ' ') s++;
    strcpy(str, &str[s]);
    r = s;

    /* remove ending spaces */
    s = strlen(str);
    while (--s)
    {
        if (str[s] != ' ') break;
        str[s] = 0;
        r++;
    }

    return r;
}
