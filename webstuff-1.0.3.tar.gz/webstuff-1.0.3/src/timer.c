#include <sys/select.h>
#include <stdlib.h>
#include <stdio.h>  /* debug */

#include <ws/timer.h>



void
ws_stopwatch_start(WsStopwatch * sw)
{
    time(&sw->begin);
    sw->end   = 0;
}


void
ws_stopwatch_stop(WsStopwatch * sw)
{
    time(&sw->end);
}


WsSize
ws_stopwatch_get_elapsed(WsStopwatch * sw)
{
    return difftime( (sw->end==0) ? time(NULL) : sw->end, sw->begin );
}




void
ws_sleep(WsSize usec)
{
    #ifdef WIN32
    sleep(usec);
    #else
    struct timeval tv;

    tv.tv_sec = 0;
    tv.tv_usec = usec*1000;
    select(0, NULL, NULL, NULL, &tv);
    #endif
}
