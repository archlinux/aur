#include <ws/status.h>

const char *
ws_status_get_text(WsStatus code)
{
    switch (code)
    {
        /* common */
        case wsSuccess:          return "Success";

        /* non-error statuses */
        case wsConnectionTimeout: return "Connection timeout";
        case wsConnectionError:   return "Connection Error";
        case wsConnectionClosed:  return "Connection Closed";
        case wsAddressError:      return "Address error";
        case wsSocketError:       return "Socket Error";
        case wsSocketAcceptError: return "accept() error";
        case wsSocketSelectError: return "select() error";
        case wsSocketReadError:   return "Socket Read Error";
        case wsSocketWriteError:  return "Socket Write Error";
        case wsOpenFileError:     return "Open File Error";
        case wsConfigSyntaxError: return "Config Syntax Error";


        case wsUnknownStatus:    break;
    }

    return "UnknownStatus";
}


