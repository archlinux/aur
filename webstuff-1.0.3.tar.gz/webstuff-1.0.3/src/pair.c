#include <stdlib.h>
/* #include <stdio.h> */ /*debug */
#include <string.h>

#include <ws/pair.h>


WsPair *
ws_pair_new( const WsChar * key, const WsChar * value )
{
    return ws_pair_new_from_length( key,   (key)   ? strlen(key)   : 0,
                                    value, (value) ? strlen(value) : 0 );
}


WsPair *
ws_pair_new_from_length( const WsChar * key,
                         WsSize         k_len,
                         const WsChar * value,
                         WsSize         v_len )
{
    WsPair * self = calloc(1, sizeof(WsPair));
    if (k_len) ws_string_copy(&self->key, key, k_len);
    if (v_len) ws_string_copy(&self->value, value, v_len);
    return self;
}


void
ws_pair_free ( WsPair * self )
{
    if (!self) return;
    ws_string_free(self->key);
    ws_string_free(self->value);
    free(self);
}
