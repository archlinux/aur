#include <string.h>
#include <stdlib.h>
/* #include <stdio.h> */ /* debug */

#include <ws/timestamp.h>
#include <ws/string.h>

static int
get_digit(char * p, int size)
{
    char buf[size+1];
    buf[size]=0;
    strncpy(buf, p, size);

    return atoi(buf);
}


void
ws_now(WsTimestamp * ts)
{
    time_t rawtime;
    time ( &rawtime );

    memcpy(ts, localtime ( &rawtime ), sizeof(WsTimestamp));
}



void
ws_timestamp_set_from_string(WsTimestamp * ts, WsChar * string)
{
    char * e;

    e = strchr(string, '-');

    /* get current timeinfo and modify it according to string */
    ts->tm_year = get_digit(string, (int)(e-string)) - 1900;
    ts->tm_mon  = get_digit(e+1, 2)- 1;
    ts->tm_mday = get_digit(e+4, 2);
    ts->tm_hour = get_digit(e+7, 2);
    ts->tm_min  = get_digit(e+10, 2);
    ts->tm_sec  = get_digit(e+13, 2);

    mktime ( ts );
}


void
ws_timestamp_set_string(WsTimestamp * ts, WsString * string)
{
    /* Length(YYYY-MM-DD HH:MM:SS)=19, for strftime we have to pass 20 because
     * of NULL-termination, that is added automatically 
     * by ws_string_set_length
     * */
    ws_string_set_length(string, 19); 
    strftime (*string, 20, "%F %T", ts);
}

void
ws_timestamp_add_seconds(WsTimestamp * ts, WsInt seconds)
{
    time_t tm = mktime(ts) + seconds;
    memcpy(ts, localtime (&tm), sizeof(WsTimestamp));
}
