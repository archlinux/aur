#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>

#include <ws/socket.h>

#define SOCKET_ERROR -1

/* CONSTANTS
 *************************************************************************** */

static const int cWaitOnSocket=500000;


/* TYPES
 *************************************************************************** */

struct _WsSocketPriv
{
    int                   fd;          // Server socket descriptor
    struct sockaddr_in    address;       // local inet address
    char                  host[15+1];  // buffer for ip address
};


/* STATIC PROTOTYPES
 *************************************************************************** */

static void
ws_socket_init(WsSocket * self);

static struct sockaddr *
ws_socket_get_address(WsSocket * self);


static void
set_last_error_message(const char * ptr);


static WsStatus
set_addres_from_host_and_port( struct sockaddr_in * sa,
                               const char         * host,
                               int                  port);


/* GLOBALS
 *************************************************************************** */

static const char * last_error_message = NULL;



/* IMPLEMENTATION
 *************************************************************************** */

WsSocket *
ws_socket_new()
{
    WsSocket * self = calloc(1, sizeof(WsSocket));
    ws_socket_init(self);

    self->priv->fd = SOCKET_ERROR;
    //ws_socket_open(self);

    return self;
}


void
ws_socket_free(WsSocket * self)
{
    set_last_error_message(NULL);

    if (self)
    {
        ws_socket_close(self, true);
        free(self->priv);
        free(self);
        *((void**)&self) = NULL;
    }
}


WsStatus
ws_socket_open(WsSocket * self)
{
    WsStatus res = wsSuccess;

    set_last_error_message(NULL);

    self->priv->fd = socket(AF_INET, SOCK_STREAM, 0);
    if ( self->priv->fd == SOCKET_ERROR ||
            setsockopt( self->priv->fd,
                        SOL_SOCKET,
                        SO_REUSEADDR,
                        &self->priv->fd, sizeof(int) ) < 0
    )
    {
        set_last_error_message(strerror(errno));
        res = wsSocketError;
    }
    return res;

}


bool
ws_socket_is_open(WsSocket * self)
{
    return (self->priv->fd == SOCKET_ERROR) ? false : true;
}

WsStatus
ws_socket_close(WsSocket * self, bool do_shutdown)
{
    if (self->priv->fd == -1) /* already closed */
        return wsSuccess;

    *self->priv->host = 0;

    if (do_shutdown) shutdown(self->priv->fd, SHUT_RDWR);

    if (close(self->priv->fd) != 0)
    {
        set_last_error_message(strerror(errno));
        return wsSocketError;
    }
    self->priv->fd = -1;

    return wsSuccess;
}


char *
ws_socket_get_host(WsSocket * self)
{
    if (!(*self->priv->host))
    {
        strcpy(self->priv->host, inet_ntoa( self->priv->address.sin_addr ));
    }
    return self->priv->host;

}


uint32_t
ws_socket_get_in_addr(WsSocket * self)
{
    return self->priv->address.sin_addr.s_addr;
}


int
ws_socket_get_port(WsSocket * self)
{
    return (int) ntohs( self->priv->address.sin_port );
}


WsStatus
ws_socket_set_address(WsSocket * self, const char * host, int port)
{
    return set_addres_from_host_and_port(&self->priv->address, host, port);
}


WsStatus
ws_socket_bind(WsSocket * self)
{
    WsStatus res = wsSuccess;

    /* check if socket is opened */
    if (self->priv->fd == SOCKET_ERROR) 
        res = ws_socket_open(self);


    if (res == wsSuccess)
    {
        /* try bind */
        if ( bind( self->priv->fd,
                   ws_socket_get_address(self),
                   sizeof(struct sockaddr_in) ) != 0)

        {
            set_last_error_message(strerror(errno));
            res = wsSocketError;
        }
    }
    else
        ws_socket_close(self, false);
    return res;
}


#ifdef CLIENT
WsStatus
ws_socket_connect(WsSocket * self, const char * host, int port)
{
    int                   ssize;
    struct sockaddr_in    sa;
    WsStatus             res = wsSuccess;

    res = set_addres_from_host_and_port(&sa, host, port);

    /* check if socket is opened */
    if (res == wsSuccess)
    {
        if (self->priv->fd == SOCKET_ERROR) 
            res = ws_socket_open(self);

        if (res == wsSuccess)
        {
            ssize = sizeof(struct sockaddr_in);
            set_last_error_message(NULL);

            if (connect( self->priv->fd, (struct sockaddr *)&sa, ssize)!=0)
            {
                set_last_error_message(strerror(errno));
                res = wsConnectionError;
            }
        }
    }
    return res;
}
#endif


#ifdef SERVER
WsStatus
ws_socket_accept(WsSocket * self, WsSocket ** client)
{
    struct timeval    tv;
    fd_set            set;
    int               i;
    WsStatus         s = wsSuccess;

    FD_ZERO(&set);
    FD_SET(self->priv->fd, &set);

    tv.tv_sec  = 0;
    tv.tv_usec = cWaitOnSocket;

    *client = NULL;

    i = select(self->priv->fd+1, &set, NULL, NULL, &tv);
    if (i==1)
    {
        *client = ws_socket_new();

        i = sizeof(struct sockaddr_in);
        (*client)->priv->fd = accept( self->priv->fd, 
                                    ws_socket_get_address(*client),
                                    (socklen_t *)&i );
        if ((*client)->priv->fd == -1)
        {
            set_last_error_message(strerror(errno));
            ws_socket_free(*client);
            ws_socket_close(self, true);
            s = wsSocketAcceptError;
        }

    }
    else if (i < 0) /* select error, close socket */
    {
        ws_socket_close(self, true);
        s = wsSocketSelectError;
    }

    return s;
}


WsStatus
ws_socket_listen(WsSocket * self)
{
    WsStatus res = wsSuccess;
    if (self->priv->fd == SOCKET_ERROR) 
        res = ws_socket_bind(self);


    if (res == wsSuccess && listen(self->priv->fd, 128) == SOCKET_ERROR)
    {
        set_last_error_message(strerror(errno));
        ws_socket_close(self, false);
        return wsSocketError;
    }

    return res;
}
#endif




int
ws_socket_read(WsSocket * self, char * buffer, int length)
{
    struct timeval  tv;
    fd_set          rset;
    int             s;

    tv.tv_sec  = 0;
    tv.tv_usec = cWaitOnSocket;
    FD_ZERO(&rset);
    FD_SET(self->priv->fd, &rset);

    s = select(self->priv->fd+1, &rset, NULL, NULL, &tv);

    if (s > 0)/* && FD_ISSET(self->priv->fd, &rset)) // ready to read*/
    {
        s = recv(self->priv->fd, buffer, length, MSG_DONTWAIT);
        if (s==0) s = -1;

        // length < 0 is error, so we have to disconnect
        // but if length is 0 it means that client was disconnected as long 
        // as we are behind select()

    }
    
    if (s == -1) ws_socket_close(self, true);

    return s;
}

int
ws_socket_send(WsSocket * self, const char * buffer, int length)
{
    struct timeval  tv;
    fd_set          wset;
    int             s;

    tv.tv_sec  = 0;
    tv.tv_usec = cWaitOnSocket;
    FD_ZERO(&wset);
    FD_SET (self->priv->fd, &wset);

    s = select(self->priv->fd+1, NULL, &wset, NULL, &tv);

    if (s > 0)
    {
        //FD_ISSET(sock->fd, &wset))
        s = send(self->priv->fd, buffer, length, MSG_DONTWAIT);

        if (!(s>0)) s = -1;
    }


    if (s == -1) ws_socket_close(self, true);

    return s;
}


const char *
ws_socket_get_last_error()
{
    return last_error_message;
}


/* STATIC IMPLEMENTATION
 *************************************************************************** */
static void
ws_socket_init(WsSocket * self)
{
    self->priv       = calloc(1, sizeof(WsSocketPriv));

    self->priv->address.sin_family = AF_INET;
}

static struct sockaddr *
ws_socket_get_address(WsSocket * self)
{
    return (struct sockaddr *) &self->priv->address;
}


static WsStatus
set_addres_from_host_and_port( struct sockaddr_in * sa,
                               const char         * host,
                               int                  port)
{
    int               rs;
    struct addrinfo * ai;

    memset(sa, 0, sizeof( struct sockaddr_in ));
    sa->sin_family = AF_INET;

    set_last_error_message(NULL);

    rs = getaddrinfo(host, NULL, NULL, &ai);

    if(rs != 0)
    {
        set_last_error_message(gai_strerror(rs));
        return wsAddressError;
    }

    sa->sin_addr.s_addr=((struct sockaddr_in*)(ai->ai_addr))->sin_addr.s_addr;
    sa->sin_port       =htons(port);

    freeaddrinfo(ai);

    return wsSuccess;
}

static void
set_last_error_message(const char * ptr)
{
    last_error_message = ptr;
}
