#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#include <ws/templight.h>

#define TPL_BUFFER_SIZE 256


struct _WsTemplightAtom
{
    int    type; /* Atom type */
    int    size;     /* Atom data size */
    void * data;     /* Pointer to data */
};

typedef struct _WsTemplightAtom WsTemplightAtom;


struct _WsTemplight
{
    char               * name;     /* Templight name */
    char               * root;     /* Template root folder */
    int                  size;     /* quantity of atoms in content */
    WsTemplightAtom   ** content;  /* Array of atoms */
};


static int
_ws_templight_parse_line(WsList * stack, char * b, int line);


static int
_ws_templight_error(char * error, int line);


static void
_ws_templight_add_label(WsTemplight * block, char * begin, int length);


static void
_ws_templight_add_plain(WsTemplight * block, char * begin, int length);


static void
_ws_templight_atom_append(WsTemplight* self, int type, int size, void * data);


static void
_ws_templight_block_insert(WsTemplight * self, WsTemplight * b, int shift, int size);




WsTemplight *
ws_templight_new(char * template_name, char * root)
{
    WsTemplight   * self;
    WsList        * stack;
    FILE          * fd;
    char            b[TPL_BUFFER_SIZE];   /* buffer */
    char          * fp;                   /* file path */
    int             l;


    l = strlen(template_name);
    
    fp = calloc((strlen(root)+l+11), sizeof(char));

    sprintf(fp, "%s/%s.tpl.html", root, template_name);

    fd = fopen(fp, "r");

    if (!fd)
    {
        fprintf(stderr, "[templight] Could not open template file (%s): %s\n", 
                fp, strerror(errno));
        free (fp);
        return NULL;
    }

    self = calloc(1, sizeof(WsTemplight));
    self->name = calloc(l+1, sizeof(char));
    self->root = root;
    strcpy(self->name, template_name);
    self->content=NULL;

    stack = ws_list_new(4);
    ws_list_push(stack, self);

    l=1; // line number

    while(fgets(b,TPL_BUFFER_SIZE-1,fd))
    {
        b[TPL_BUFFER_SIZE-1] = 0;
        if (_ws_templight_parse_line(stack, b, l))
        {
            /* exit on parse error */
            self = ws_templight_free(self);
            break;
        }
        l++;
    }
    if (ws_list_get_count(stack) > 1)
    {
        fprintf(stderr, "[templight] unclosed block %s\n", 
                ((WsTemplight *)ws_list_pop(stack))->name);
        self = ws_templight_free(self);
    }

    ws_list_free(stack);

    fclose(fd);
    free (fp);

    return self;
}


WsTemplight *
ws_templight_new_as_block(char * block_name, int length)
{
    WsTemplight * self;
    char * p=&block_name[length-1];

    while(p>block_name)
    {
        if (*p==' ')
        {
            p--;
            length--;
        }
        else
            break;
    }

    self = calloc(1, sizeof(WsTemplight));
    self->name = calloc(length+1, sizeof(char));
    strncpy(self->name, block_name, length);
    self->content=NULL;

    return self;
}

static WsPair *
_clone_label(WsPair * label)
{
    WsPair * new = calloc(1, sizeof(WsPair));
    new->key = calloc(strlen(label->key)+1, sizeof(char));
    new->value = calloc(strlen(label->value)+1, sizeof(char));

    strcpy(new->key, label->key);
    strcpy(new->value, label->value);

    return new;
}

WsTemplight *
ws_templight_clone(WsTemplight * self)
{
    int           i   = 0;
    WsTemplight * tpl = calloc(1, sizeof(WsTemplight));
    /* WsTemplight * tmp; */

    tpl->name = calloc(strlen(self->name)+1, sizeof(char));
    strcpy(tpl->name, self->name);
    tpl->size = self->size;

    tpl->content = calloc(tpl->size, sizeof(WsTemplightAtom*));

    while (i<tpl->size)
    {
        tpl->content[i]=malloc(sizeof(WsTemplightAtom));
        tpl->content[i]->type =  self->content[i]->type;
        tpl->content[i]->size = self->content[i]->size;
        switch (self->content[i]->type)
        {
            case aPlain:
                tpl->content[i]->type=aLink;
                tpl->content[i]->data=self->content[i]->data;
                break;
            case aBlock:
                printf("block:%s", ((WsTemplight *)self->content[i]->data)->name);
                tpl->content[i]->data=ws_templight_clone(
                        (WsTemplight *) self->content[i]->data);
                /* tmp = tpl->content[i]->data; */
                break;
            case aLabel:
                tpl->content[i]->data=_clone_label((WsPair*)self->content[i]->data);
                break;
            case aLink:
                tpl->content[i]->data=self->content[i]->data;
                break;
        }
        i++;
    }

    return tpl;


}




void *
ws_templight_free(WsTemplight * self)
{
    int i = 0;
    if (self)
    {
        if (self->name) free(self->name);
        
        if (self->content)
        {
            while (i < self->size)
            {
                switch (self->content[i]->type)
                {
                    case aBlock:
                        ws_templight_free(
                            (WsTemplight *) self->content[i]->data );
                        break;
                    case aLabel:
                        if ( ((WsPair *)self->content[i]->data)->key)
                            free(((WsPair *)self->content[i]->data)->key);
                        if ( ((WsPair *)self->content[i]->data)->value)
                            free(((WsPair *)self->content[i]->data)->value);
                        free((WsPair *)self->content[i]->data);
                        break;
                    case aPlain:
                        free((char *)self->content[i]->data);
                        break;
                }
                free (self->content[i]);
                i++;
            }
            free(self->content);
        }
        free(self);
    }
    return NULL;
}


static int
_ws_templight_parse_line(WsList * stack, char * b, int line)
{
    WsTemplight * block;
    char * begin;
    char * end;
    int    length;



    /* Parse block end */
    begin = strstr(b, "<!--ws:}-->");
    if (begin)
    {
        if (ws_list_get_count(stack) == 1)
            return _ws_templight_error("closing of non-opened block", line);
        
        ws_list_pop(stack);
        return 0;
    }


    begin = strstr(b, "<!--ws:");
    /* Parse block begin  */
    if (begin) 
    {
        begin += 7;
        end = strstr(begin, "{-->");
        if (end && end > begin)
        {
            block = ws_templight_new_as_block(begin, (int) (end-begin));
            _ws_templight_atom_append(
                /* (WsTemplight *)stack->stack[0] , */
                ws_list_get_item(stack, ws_list_get_count(stack)-1),
                aBlock,
                0,
                (void *) block);
            ws_list_push(stack, (void*) block);
            return 0;
        }
        else
            return _ws_templight_error("wrong block name", line);
    }
        
    /* Parse labels and plain text */
    /* block = (WsTemplight *)stack->stack[0]; */
    block = ws_list_get_item(stack, ws_list_get_count(stack)-1);
    end = b;
    while ( (begin = strstr(end, "{ws:")) )
    {
        /* some text before label */
        if (begin > end) _ws_templight_add_plain(block, end, (int)(begin-end));

        /* saving label */
        begin+=4;
        end = strstr(begin, "}");
        if(end)
        {
            _ws_templight_add_label(block, begin, (int)(end-begin));
            end++;
        }
        else
            return _ws_templight_error("wrong label name", line);
    }
    /* plain text, even after label */
    length = strlen(end);
    if (length>0) _ws_templight_add_plain(block, end, length);

    return 0; // SUCCESS
}


static void
_ws_templight_add_label(WsTemplight * block, char * begin, int length)
{
    WsPair * label = malloc(sizeof(WsPair));
    label->key = calloc(length+1, sizeof(char));
    label->value = calloc(1, sizeof(char));


    strncpy(label->key, begin, length);
    printf("[debug] adding label (%s)\n", label->key);
}


static void
_ws_templight_add_plain(WsTemplight * block, char * begin, int length)
{
    char * plain = calloc(length+1, sizeof(char));
    strncpy(plain, begin, length);


    _ws_templight_atom_append(block, aPlain, 0, (void*)plain);
}

static void
_ws_templight_atom_append(WsTemplight * self, int type, int size, void * data)
{
    int                  i = 0;
    WsTemplightAtom  * atom = malloc(sizeof(WsTemplightAtom));
    WsTemplightAtom ** content;
    atom->type = type;
    atom->size = size;
    atom->data = data;

    self->size++;
    content = calloc(self->size, sizeof(WsTemplightAtom*));
    while (i < self->size - 1)
    {
        content[i]=self->content[i];
        i++;
    }

    content[i] = atom;
    if (self->content)
        free(self->content);

    self->content=content;

}


static int
_ws_templight_error(char * error, int line)
{
    fprintf(stderr, "[templight] Parse Error on line #%d: %s\n", line, error);
    return line;
}


WsTemplight *
ws_templight_block_new(WsTemplight * self, char * block)
{
    int i;
    WsTemplight * b;
    for(i=0; i<self->size; i++)
    {
        if (self->content[i]->type != aBlock) continue;

        b = (WsTemplight *) self->content[i]->data;
        printf("[debug] found block (%s)\n", b->name);
        if (strcmp(b->name, block)) continue;


        b = ws_templight_clone( (WsTemplight *) self->content[i]->data );
        self->content[i]->size++;

        /* atom->size for first block contains number of repeats 
         * all we need is to insert block in appropriate block */

        _ws_templight_block_insert(self, b, i+self->content[i]->size, -1);

        return b;
    }

    return NULL;
}

static void
_ws_templight_block_insert(WsTemplight * self, WsTemplight * b, int shift, int size)
{
    int i=0;
    WsTemplightAtom ** content;
    WsTemplightAtom  * atom;

    self->size++;
    content = calloc(self->size, sizeof(WsTemplightAtom *));
    atom    = malloc(sizeof(WsTemplightAtom));
    atom->size = size;
    atom->type=aBlock;
    atom->data = (void*)b;

    while (i<shift)
    {
        content[i]=self->content[i];
        i++;
    }
    content[i]=atom;
    i++;
    while (i<self->size)
    {
        content[i]=self->content[i-1];
        i++;
    }

    if (self->content) free(self->content);

    self->content=content;
}

int
ws_templight_set_string(WsTemplight * self, char * label, char * value)
{
    int i, r=0;
    WsPair * l;

    
    for(i=0; i<self->size; i++)
    {
        if (self->content[i]->type != aLabel) continue;

        l = (WsPair*) self->content[i]->data;
        if (strcmp(l->key, label)) continue;

        if(l->value) free(l->value);

        l->value = calloc(strlen(value)+1, sizeof(char));
        strcpy(l->value, value);
        self->content[i]->size=1;
        r++;
    }
    return r;
}


int
ws_templight_set_int(WsTemplight * self, char * label, int value)
{
    char data[64];
    sprintf(data, "%d", value);

    return ws_templight_set_string(self, label, data);
}


int
ws_templight_set_float(WsTemplight * self, char * label, float value)
{
    char data[64];
    sprintf(data, "%f", value);

    return ws_templight_set_string(self, label, data);
}

int
ws_templight_set_block(WsTemplight * self, char * label, char * value)
{
    WsTemplight * t;
    WsPair     * l;
    int i, r=0;



    for(i=0; i<self->size; i++)
    {
        if (self->content[i]->type != aLabel) continue;

        l = (WsPair*) self->content[i]->data;
        if (strcmp(l->key, label)) continue;

        if(l->value) free(l->value);

        t = ws_templight_new(value, self->root);
        //if (t->name) free(t->name);
        //t->name = l->key;
        free(l->key);
        free(l);
        self->content[i]->data = (void*)t;
        self->content[i]->type = aBlock;
        self->content[i]->size = 1;

        r++;
    }
    return r;
}


/* Composes count of labels inside block
 * Result: amount of composes */
int
ws_templight_compose(WsTemplight * self, WsPair * label, int count)
{
    int r=0;
    while (count > 0)
    {
        r+=ws_templight_set_string(
                self, label[count-1].key, label[count-1].value);
        count--;
    }

    return r;
}


void
ws_templight_out(WsTemplight * self, WsRequest * wsr)
{
    int i =0;

    //ws_header_end(request);
    while (i<self->size)
    {
        switch (self->content[i]->type)
        {
            case aPlain:
            case aLink:
                ws_print(wsr, (char*) self->content[i]->data);
                break;
            case aLabel:
                //if (self->content[i]->size > 0)
                    ws_print(wsr, ((WsPair*) self->content[i]->data)->value);
                break;
            case aBlock:
                if (self->content[i]->size == -1)
                {
                    ws_templight_out( 
                        ((WsTemplight *) self->content[i]->data),
                        wsr
                    );
                }
        }
        i++;
    }
}
