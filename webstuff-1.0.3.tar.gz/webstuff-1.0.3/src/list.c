#include <stdlib.h>
#include <string.h>
#include <ws/types.h>
#include <ws/list.h>

struct _WsListPrivate
{
    void     ** list;
    /* void     ** iterator; */
    uint32_t    size;
    uint32_t    count;
};




/* implementation
 * ************************************************************************ */



WsList *
ws_list_new(uint32_t  size)
{
    WsList * self = calloc(1, sizeof(WsList));
    self->priv = calloc(1, sizeof(WsListPrivate));
    ws_list_set_size(self, size);

    return self;
}


void
ws_list_free(WsList * self)
{
    if (self)
    {
        if (self->free_item)
            ws_list_empty(self);
        free(self->priv->list);
//        arc_mutex_destroy(&self->priv->lock);
        free(self->priv);
        free(self);
        *((void**)&self)=NULL;
    }
}


void
ws_list_empty(WsList * self)
{
    int i;
    if (self)
    {
        for (i = 0; i<self->priv->count; i++)
        {
            if (self->priv->list[i])
            {
                if (self->free_item)
                    self->free_item(self->priv->list[i]);
                self->priv->list[i] = NULL;
            }
        }

    }
}


void
ws_list_clean(WsList * self)
{
    uint32_t    i, c=0;
    void     ** p = NULL;
    if (self)
    {
        for (i = 0; i<self->priv->count; i++)
        {
            if (p && self->priv->list[i])
            {
                *p = self->priv->list[i];
                self->priv->list[i] = NULL;
                i = (uint32_t)(p - self->priv->list)+1;
                p = &self->priv->list[i];
                c++;
                continue;
            }

            if (!self->priv->list[i]) p = &self->priv->list[i];

        }
        self->priv->count-=c;

    }
}


void
ws_list_set_item_destructor(WsList * self, WsListItemDestructor free_item)
{
    self->free_item = free_item;
}


void
ws_list_set_size(WsList * self, uint32_t size)
{
    if (size == self->priv->size) return;
    
    void ** list;
    list = (size) ? calloc(size, sizeof(void*)) : NULL;

    if(self->priv->list)
    {
        memcpy(list, self->priv->list, self->priv->count);
        free(self->priv->list);
    }

    self->priv->size = size;
    self->priv->list = list;
}




uint32_t
ws_list_get_size(WsList * self)
{
    return self->priv->size;
}



uint32_t
ws_list_get_count(WsList * self)
{
return self->priv->count;
}


void
ws_list_set_item(WsList * self, uint32_t index, void * item)
{
    if (index < self->priv->size)
    {
        if (index >= self->priv->count) self->priv->count = index + 1;
        self->priv->list[index] = item;
    }
}


void *
ws_list_get_item(WsList * self, uint32_t index)
{
    void * res = NULL;

    if (index < self->priv->count)
    {
        res = self->priv->list[index];
    }

    return res;
}



void *
ws_list_find(   WsList              * self,
                 WsListCompare         comparer,
                 void                 * argument,
                 uint32_t             * position )
{
    uint32_t    i;
    void      * res  = NULL;
    bool        stop = false;

    for (i=(position)? *position : 0; i<self->priv->count; i++)
    {
        if (position) *position = i;
        if (comparer(self->priv->list[i], argument, &stop))
        {
            res = self->priv->list[i];
            break;
        }

        if (stop) break;
    }

    return res;

}



void
ws_list_walk(   WsList              * self,
                 WsListDirection       direction,
                 WsListCompare        walker,
                 void                 * argument )
{
    uint32_t    i, end;

    /* get proper direction */
    if (direction == WsListFirstToLast)
    {
        i   = 0;
        end = self->priv->count-1;
    }
    else
    {
        i   = self->priv->count-1;
        end = 0;
    }

    while (1)
    {
        walker(self->priv->list[i], argument, NULL);

        if (i == end) break;

        (direction == WsListFirstToLast) ? i++ : i--;
    }

}



void
ws_list_insert( WsList              * self,
                 void                 * item,
                 uint32_t               position )
{
    uint32_t    i;
    void     ** l = self->priv->list;

    if (self->priv->count == self->priv->size)
    {
        /* enlarge */
        self->priv->size++;
        l = calloc(self->priv->size, sizeof(void*));
        if (position > 0)
            memcpy(l, self->priv->list, position*sizeof(void*));
    }
    if (position > self->priv->count) position = self->priv->count;

    if (position < self->priv->count)
    {
        /* move items after position */
        for (i = self->priv->count; i>position; i--)
        {
            l[i]=self->priv->list[i-1];
        }
    }

    l[position] = item;
    self->priv->count++;

    if (l != self->priv->list)
    {
        free(self->priv->list);
        self->priv->list = l;
    }


}



void
ws_list_remove( WsList              * self,
                 uint32_t               position )
{
    if (position < self->priv->count)
    {
        while (position < self->priv->count-1)
        {
            self->priv->list[position] = self->priv->list[position+1];

            position++;
        }

        self->priv->count--;
    }

}


#ifdef STACK


void
ws_list_push(WsList *self, void * item)
{
    ws_list_insert(self, item, self->priv->count);
}


void *
ws_list_pop(WsList *self)
{
    void * item;
    if (self->priv->count)
    {
        item = ws_list_get_item(self, self->priv->count-1);
        ws_list_remove(self, self->priv->count-1);
    }
    else
        item = NULL;
    return item;
}

#endif

#ifdef QUEUE


void *
ws_list_shift(WsList *self)
{
    void * item;
    if (self->priv->count)
    {
        item = ws_list_get_item(self, 0);
        ws_list_remove(self, 0);
    }
    else
        item = NULL;
    return item;
}

void
ws_list_append(WsList * self, void * item)
{
     ws_list_insert(self, item, self->priv->count);

}


#endif









