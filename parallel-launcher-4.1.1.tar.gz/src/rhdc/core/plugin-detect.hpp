#ifndef SRC_RHDC_CORE_PLUGIN_DETECT_HPP_
#define SRC_RHDC_CORE_PLUGIN_DETECT_HPP_

#include "src/core/settings.hpp"

struct AutoPlugin {
	EmulatorCore emulator;
	GfxPlugin parallelPlugin;
	GfxPlugin mupenPlugin;

	static AutoPlugin guess( const fs::path &romPath, bool preferHle );
};

#endif /* SRC_RHDC_CORE_PLUGIN_DETECT_HPP_ */
