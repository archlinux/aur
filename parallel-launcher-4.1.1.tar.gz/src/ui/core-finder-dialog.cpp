#include "src/ui/core-finder-dialog.hpp"

#include <QMessageBox>
#include "src/core/file-controller.hpp"

CoreFinderDialog::CoreFinderDialog( EmulatorCore core ) :
	QProgressDialog( nullptr ),
	m_core( core ),
	m_dialogOpen( new bool( false ) )
{
	setLabelText( "Searching for latest core version..." );
	setMinimum( 0 );
	setMaximum( 0 );
}

static const string s_fallbackDownloadUrlBase = ""
	"http://buildbot.libretro.com/nightly/"
#ifdef _WIN32
	#ifdef _WIN64
		"windows/x86_64"
	#else
		"windows/x86"
	#endif
#else
	#ifdef _LP64
		"linux/x86_64"
	#else
		"linux/x86"
	#endif
#endif
	"/latest/";

#ifdef _WIN32
	#define LIBRARY_EXT ".dll"
#else
	#define LIBRARY_EXT ".so"
#endif

static inline CoreBuild getFallbackBuild( EmulatorCore core ) {
	string downloadLink;
	if( core == EmulatorCore::ParallelN64 ) {
		downloadLink = s_fallbackDownloadUrlBase + ("parallel_n64_libretro" LIBRARY_EXT ".zip");
	} else {
		downloadLink = s_fallbackDownloadUrlBase + ("mupen64plus_next_libretro" LIBRARY_EXT ".zip");
	}

	return CoreBuild {
		CommitInfo{ "", "", "" },
		std::move( downloadLink )
	};
}

void CoreFinderDialog::showEvent( QShowEvent *event ) {
	std::shared_ptr<bool> dialogOpen = m_dialogOpen;
	*dialogOpen = true;

	string branch = "master";
	if( m_core == EmulatorCore::Mupen64plusNext && FileController::loadAppSettings().mupenDevBranch ) {
		branch = "develop";
	}

	m_build.reset();
	CoreBuilds::getLastKnownGood(
		m_core,
		branch,
		"",
		[this,dialogOpen](const CoreBuild &build) {
			// Don't need locks here because queued connections are used
			if( *dialogOpen ) {
				this->m_build = build;
				this->close();
			}
		},
		[this,dialogOpen](){
			if( *dialogOpen ) {
				this->m_build = getFallbackBuild( m_core );
				this->close();
			}
		}
	);

	QProgressDialog::showEvent( event );
}

void CoreFinderDialog::closeEvent( QCloseEvent *event ) {
	*m_dialogOpen = false;
	QProgressDialog::closeEvent( event );
}
