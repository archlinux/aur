# Amiga OS Themes for XFCE (XFWM4)

I created these for fun, but they worked so
good for me that I use the OS3.x theme for daily work now. :)

There are two themes included, one for 1.3 and one for 3.* Window decorations, both include a larger high DPI version.

I am combining the theme with the Amiga3.x gtk2 theme from untouchable89:
http://xfce-look.org/content/show.php/Amiga3.x?content=127251

These mousepointers from xBreeze are great with the theme, too:
http://xfce-look.org/content/show.php/Amiga+Classic+Red?content=128152

Use it with the one and only Topaz font here:
https://github.com/rewtnull/amigafonts

Just copy the content of the Archive into your ~/.themes Folder and
select the theme of your choice in the XFCE4 Windowmanager Configuration. 
