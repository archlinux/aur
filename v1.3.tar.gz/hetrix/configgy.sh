#!/usr/bin/env bash
# configgy.sh -- interactive index.json manager for hetrix
# Usage:
#   ./configgy.sh [command] [args]   (standalone)
#   hetrix configgy [command] [args] (via hetrix)
#
# Commands: add, remove, edit, list, show, search, validate, format, help
# No args: open interactive menu

set -uo pipefail

# ---------------------------------------------------------------------------
# Colours + icons
# ---------------------------------------------------------------------------
RED='\033[0;31m';    BRED='\033[1;31m'
GREEN='\033[0;32m';  BGREEN='\033[1;32m'
YELLOW='\033[1;33m'; CYAN='\033[1;36m'
BLUE='\033[1;34m';   MAGENTA='\033[1;35m'
BOLD='\033[1m';      DIM='\033[2m'; NC='\033[0m'

NF_OK=$'\xef\x80\x8c'       # nf-fa-check
NF_ERR=$'\xef\x80\x8d'      # nf-fa-times
NF_WARN=$'\xef\x81\xb1'     # nf-fa-warning
NF_ARROW=$'\xef\x81\xa1'    # nf-fa-angle-right
NF_TRASH=$'\xef\x87\xb8'    # nf-fa-trash

ok()     { echo -e "${BGREEN}  ${NF_OK}  ${NC}${GREEN}$*${NC}"; }
err()    { echo -e "${BRED}  ${NF_ERR}  ${NC}${RED}$*${NC}" >&2; }
warn()   { echo -e "${YELLOW}  ${NF_WARN}  ${NC}${YELLOW}$*${NC}"; }
info()   { echo -e "${CYAN}  ${NF_ARROW} ${NC}$*"; }
step()   { echo -e "${MAGENTA}  >> ${NC}${BOLD}$*${NC}"; }
blank()  { echo ""; }
divider(){ echo -e "${DIM}  $(printf '%0.s-' {1..54})${NC}"; }

banner() {
    local msg="$1"
    local w=$(( ${#msg} + 4 ))
    local line; line=$(printf '%0.s=' $(seq 1 "$w"))
    blank
    echo -e "${BLUE}  +${line}+${NC}"
    echo -e "${BLUE}  |  ${BOLD}${msg}${NC}${BLUE}  |${NC}"
    echo -e "${BLUE}  +${line}+${NC}"
    blank
}

# ---------------------------------------------------------------------------
# Paths  (mirrors hetrix Utils:: resolution order)
# ---------------------------------------------------------------------------
HETRIX_DIR="${HETRIX_DIR:-$HOME/hetrix}"
INDEX="${HETRIX_INDEX:-${HETRIX_DIR}/index.json}"
BIN_DIR="${HETRIX_BIN:-${HETRIX_DIR}/bin}"
CFG="${HETRIX_DIR}/cfg.toml"

# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------
_require_python() {
    if ! command -v python3 &>/dev/null; then
        err "python3 is required for configgy's JSON handling."
        err "Install python3 and retry."
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------
check_index() {
    if [[ ! -f "$INDEX" ]]; then
        err "index.json not found at: $INDEX"
        info "Run: hetrix init"
        exit 1
    fi
}

validate_json() {
    _require_python
    if ! python3 -m json.tool "$INDEX" >/dev/null 2>&1; then
        err "index.json has a JSON syntax error!"
        info "Run: python3 -m json.tool $INDEX"
        return 1
    fi
    return 0
}

# ---------------------------------------------------------------------------
# Pretty-print one package entry
# ---------------------------------------------------------------------------
show_package() {
    local name="$1"
    _require_python
    python3 - "$INDEX" "$name" "$BIN_DIR" <<'PY'
import sys, json, os
try:
    idx = json.load(open(sys.argv[1]))
except Exception as e:
    print(f"  error reading index: {e}")
    sys.exit(1)
name    = sys.argv[2]
bin_dir = sys.argv[3]
if name not in idx:
    print(f"  package '{name}' not found in index.json")
    sys.exit(0)
p = idx[name]

NC   = "\033[0m"; DIM = "\033[2m"; BOLD = "\033[1m"
GREEN = "\033[1;32m"; CYAN = "\033[36m"; YELLOW = "\033[1;33m"

output   = p.get("output", name)
installed = os.path.exists(os.path.join(bin_dir, output))
tick = f"  {GREEN}[installed]{NC}" if installed else ""

print(f"\n  {BOLD}{GREEN}{name}{NC}{tick}")
field_order = ["url","pull_type","build","args","main","sub_dir","build_dir",
               "output","version","auto_add_cmds","install_cmd","no_extra_args","description"]
for k in field_order:
    v = p.get(k, "")
    if v:
        print(f"    {DIM}{k:<16}{NC} {v}")
# any extra fields not in the standard list
for k, v in p.items():
    if k not in field_order and v:
        print(f"    {DIM}{k:<16}{NC} {v}")
print()
PY
}

# ---------------------------------------------------------------------------
# Prompt helper: read with a coloured prompt
# ---------------------------------------------------------------------------
_prompt() {
    local label="$1" default="$2"
    local hint=""
    [[ -n "$default" ]] && hint=" ${DIM}(${default})${NC}"
    local reply
    read -rp "$(echo -e "  ${CYAN}${label}${hint}${NC}: ")" reply
    if [[ -z "$reply" && -n "$default" ]]; then
        echo "$default"
    else
        echo "$reply"
    fi
}

# ---------------------------------------------------------------------------
# cmd_add
# ---------------------------------------------------------------------------
cmd_add() {
    check_index
    _require_python
    banner "add package"

    local PKG_NAME
    PKG_NAME=$(_prompt "package name" "")
    [[ -z "$PKG_NAME" ]] && { err "Name cannot be empty."; exit 1; }

    # Check for existing entry
    local EXISTS
    EXISTS=$(python3 -c "
import json, sys
try:
    idx = json.load(open('$INDEX'))
    print('yes' if '$PKG_NAME' in idx else 'no')
except:
    print('no')
" 2>/dev/null)
    if [[ "$EXISTS" == "yes" ]]; then
        warn "Package '$PKG_NAME' already exists in index.json."
        local OVR
        OVR=$(_prompt "overwrite? [y/N]" "N")
        [[ "${OVR,,}" != "y" ]] && { info "Aborted."; exit 0; }
    fi

    local PKG_URL PKG_PULL PKG_BUILD PKG_OUTPUT PKG_ARGS PKG_MAIN
    local PKG_SUBDIR PKG_VERSION PKG_AUTO PKG_DESC PKG_INSTALL_CMD

    PKG_URL=$(_prompt "url" "")
    [[ -z "$PKG_URL" ]] && { err "URL cannot be empty."; exit 1; }

    echo -e "  ${DIM}pull_type: git | curl | auto${NC}"
    PKG_PULL=$(_prompt "pull_type" "auto")

    echo -e "  ${DIM}build: cmake|make|gcc|g++|autoconf|meson|cargo|go|zig|python|node|ruby|dune|auto${NC}"
    PKG_BUILD=$(_prompt "build" "auto")

    PKG_OUTPUT=$(_prompt "output binary name" "$PKG_NAME")
    PKG_ARGS=$(_prompt "compiler/build flags" "")
    PKG_MAIN=$(_prompt "main file (single-file gcc/g++)" "")
    PKG_SUBDIR=$(_prompt "sub_dir (build subdirectory)" "")
    PKG_VERSION=$(_prompt "version/tag (blank = latest)" "")

    echo -e "  ${DIM}auto_add_cmds: 1 = prompt to move to bin, 0 = keep in workspace${NC}"
    PKG_AUTO=$(_prompt "auto_add_cmds" "1")
    PKG_INSTALL_CMD=$(_prompt "install_cmd (custom shell command, optional)" "")
    PKG_NO_EXTRA_ARGS=$(_prompt "no_extra_args (true = pass ONLY args, no injected defaults) [true/false]" "false")
    echo -e "  ${DIM}sha256/sha512: optional hex digest for verification (curl: download hash; git: tree hash). Leave blank to skip.${NC}"
    PKG_SHA256=$(_prompt "sha256 (optional)" "")
    PKG_SHA512=$(_prompt "sha512 (optional)" "")
    PKG_DESC=$(_prompt "description" "")

    blank
    step "writing to $INDEX ..."

    # Use python to write -- safe against shell quoting issues in values
    python3 - \
        "$INDEX" "$PKG_NAME" "$PKG_URL" "$PKG_PULL" "$PKG_BUILD" \
        "$PKG_OUTPUT" "$PKG_ARGS" "$PKG_MAIN" "$PKG_SUBDIR" \
        "$PKG_VERSION" "$PKG_AUTO" "$PKG_INSTALL_CMD" \
        "$PKG_NO_EXTRA_ARGS" "$PKG_SHA256" "$PKG_SHA512" "$PKG_DESC" <<'PY'
import json, sys

path, name, url, pull, build, output, args, main_, sub, ver, auto_, inst, no_extra_args, sha256, sha512, desc = sys.argv[1:17]

with open(path) as f:
    idx = json.load(f)

entry = {}
if url:            entry["url"]           = url
if pull and pull != "auto": entry["pull_type"] = pull
if build:          entry["build"]         = build
if args:           entry["args"]          = args
if main_:          entry["main"]          = main_
if sub:            entry["sub_dir"]       = sub
if output and output != name: entry["output"] = output
if ver:            entry["version"]       = ver
if auto_ and auto_ != "1":  entry["auto_add_cmds"] = auto_
if inst:           entry["install_cmd"]   = inst
if no_extra_args and no_extra_args.lower() == "true":
    entry["no_extra_args"] = True
if sha256:         entry["sha256"]         = sha256
if sha512:         entry["sha512"]         = sha512
if desc:           entry["description"]   = desc

# Always keep url and build even if "auto"
if "url" not in entry and url:  entry["url"]   = url
if "build" not in entry:        entry["build"] = build or "auto"

idx[name] = entry

with open(path, "w") as f:
    json.dump(idx, f, indent=2)
    f.write("\n")

print(f"  written: {name}")
PY

    ok "Package '$PKG_NAME' added."
    show_package "$PKG_NAME"
}

# ---------------------------------------------------------------------------
# cmd_remove
# ---------------------------------------------------------------------------
cmd_remove() {
    check_index
    _require_python
    local name="${1:-}"
    [[ -z "$name" ]] && name=$(_prompt "package to remove" "")
    [[ -z "$name" ]] && { err "No name given."; exit 1; }

    banner "remove: $name"
    show_package "$name"

    echo -e "  ${BOLD}  1)${NC} remove from index.json only"
    echo -e "  ${BOLD}  2)${NC} remove from index.json + delete binary from bin/"
    echo -e "  ${BOLD}  q)${NC} cancel"
    blank

    local CHOICE
    CHOICE=$(_prompt "choice" "q")

    _remove_from_index() {
        python3 - "$INDEX" "$name" <<'PY'
import json, sys
path, name = sys.argv[1], sys.argv[2]
with open(path) as f: idx = json.load(f)
if name in idx:
    del idx[name]
with open(path, "w") as f:
    json.dump(idx, f, indent=2); f.write("\n")
PY
    }

    case "$CHOICE" in
        1)
            _remove_from_index
            ok "Removed '$name' from index.json."
            ;;
        2)
            local BIN_NAME
            BIN_NAME=$(python3 -c "
import json, sys
idx = json.load(open('$INDEX'))
print(idx.get('$name', {}).get('output', '$name'))
" 2>/dev/null)
            _remove_from_index
            ok "Removed '$name' from index.json."
            local BIN_PATH="$BIN_DIR/$BIN_NAME"
            if [[ -f "$BIN_PATH" ]]; then
                rm -f "$BIN_PATH"
                ok "Deleted binary: $BIN_PATH"
            else
                warn "Binary not found at: $BIN_PATH (may not have been installed)"
            fi
            ;;
        q|Q|"")
            info "Cancelled."
            ;;
        *)
            warn "Unknown choice -- cancelled."
            ;;
    esac
}

# ---------------------------------------------------------------------------
# cmd_edit  -- edit a single field of a package
# ---------------------------------------------------------------------------
cmd_edit() {
    check_index
    _require_python
    local name="${1:-}"
    [[ -z "$name" ]] && name=$(_prompt "package to edit" "")
    [[ -z "$name" ]] && { err "No name given."; exit 1; }

    banner "edit: $name"
    show_package "$name"

    echo -e "  ${DIM}fields: url pull_type build args no_extra_args main sub_dir build_dir output version auto_add_cmds install_cmd sha256 sha512 description${NC}"
    local FIELD
    FIELD=$(_prompt "field to edit" "")
    [[ -z "$FIELD" ]] && { err "No field given."; exit 1; }

    local CURRENT
    CURRENT=$(python3 -c "
import json
idx = json.load(open('$INDEX'))
print(idx.get('$name', {}).get('$FIELD', ''))
" 2>/dev/null)

    echo -e "  current: ${DIM}${CURRENT:-<empty>}${NC}"
    local NEW_VAL
    NEW_VAL=$(_prompt "new value (blank to clear)" "$CURRENT")

    python3 - "$INDEX" "$name" "$FIELD" "$NEW_VAL" <<'PY'
import json, sys
path, name, field, val = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
with open(path) as f: idx = json.load(f)
if name not in idx:
    print(f"  package '{name}' not found"); sys.exit(1)
if val:
    idx[name][field] = val
elif field in idx[name]:
    del idx[name][field]
with open(path, "w") as f:
    json.dump(idx, f, indent=2); f.write("\n")
PY

    ok "Updated $name.$FIELD"
    show_package "$name"
}

# ---------------------------------------------------------------------------
# cmd_list
# ---------------------------------------------------------------------------
cmd_list() {
    check_index
    _require_python
    banner "packages in index.json"

    python3 - "$INDEX" "$BIN_DIR" <<'PY'
import json, os, sys

idx     = json.load(open(sys.argv[1]))
bin_dir = sys.argv[2]
pkgs    = {k: v for k, v in idx.items() if not k.startswith("_")}

NC    = "\033[0m"; DIM = "\033[2m"; BOLD = "\033[1m"
GREEN = "\033[1;32m"; BLUE = "\033[1;34m"

build_order = ["gcc","g++","cmake","make","autoconf","meson",
               "cargo","go","zig","python","node","ruby","dune","auto","bash"]

groups = {}
for name, entry in pkgs.items():
    b = entry.get("build", "auto")
    groups.setdefault(b, []).append((name, entry))

total = 0
for b in build_order:
    if b not in groups: continue
    print(f"\n  {BLUE}[ {b} ]{NC}")
    print(f"  {DIM}  {'--' * 27}{NC}")
    for name, entry in sorted(groups[b]):
        binname   = entry.get("output", name)
        installed = os.path.exists(os.path.join(bin_dir, binname))
        tick  = f"{GREEN}*{NC}" if installed else " "
        desc  = entry.get("description", "")
        pull  = entry.get("pull_type", "")
        pull_str = f"  {DIM}[{pull}]{NC}" if pull and pull != "auto" else ""
        ver   = entry.get("version", "")
        ver_str = f"  {DIM}@{ver}{NC}" if ver else ""
        print(f"  {tick} {BOLD}{name:<24}{NC}{DIM}{desc}{NC}{pull_str}{ver_str}")
        print(f"      {DIM}{entry.get('url','(no url)')}{NC}")
        total += 1

print(f"\n  {DIM}total: {total} packages{NC}\n")
PY
}

# ---------------------------------------------------------------------------
# cmd_show
# ---------------------------------------------------------------------------
cmd_show() {
    check_index
    local name="${1:-}"
    [[ -z "$name" ]] && name=$(_prompt "package name" "")
    [[ -z "$name" ]] && { err "No name given."; exit 1; }
    banner "package: $name"
    show_package "$name"
    blank
}

# ---------------------------------------------------------------------------
# cmd_uninstall  -- delete binary from bin/
# ---------------------------------------------------------------------------
cmd_uninstall() {
    _require_python
    local name="${1:-}"
    [[ -z "$name" ]] && name=$(_prompt "package name" "")
    [[ -z "$name" ]] && { err "No name given."; exit 1; }

    banner "uninstall binary: $name"

    local BIN_NAME
    BIN_NAME=$(python3 -c "
import json, sys
try:
    idx = json.load(open('$INDEX'))
    print(idx.get('$name', {}).get('output', '$name'))
except:
    print('$name')
" 2>/dev/null)
    local BIN_PATH="$BIN_DIR/$BIN_NAME"

    if [[ -f "$BIN_PATH" ]]; then
        local CONFIRM
        CONFIRM=$(_prompt "delete $BIN_PATH? [y/N]" "N")
        [[ "${CONFIRM,,}" != "y" ]] && { info "Cancelled."; return; }
        rm -f "$BIN_PATH"
        ok "Deleted: $BIN_PATH"
    else
        warn "Binary not found: $BIN_PATH"
    fi
}

# ---------------------------------------------------------------------------
# cmd_search
# ---------------------------------------------------------------------------
cmd_search() {
    check_index
    _require_python
    local query="${1:-}"
    [[ -z "$query" ]] && query=$(_prompt "search query" "")
    [[ -z "$query" ]] && { err "No query."; exit 1; }
    banner "search: $query"

    python3 - "$INDEX" "$query" <<'PY'
import json, sys
idx   = json.load(open(sys.argv[1]))
q     = sys.argv[2].lower()
NC    = "\033[0m"; BOLD = "\033[1m"
GREEN = "\033[1;32m"; DIM = "\033[2m"
found = 0
for name, entry in idx.items():
    if name.startswith("_"): continue
    hay = (name + entry.get("url","") + entry.get("description","")).lower()
    if q in hay:
        print(f"  {BOLD}{GREEN}{name}{NC}  {DIM}{entry.get('build','?')}{NC}")
        print(f"    {DIM}{entry.get('url','')}{NC}")
        if entry.get("description"):
            print(f"    {entry['description']}")
        print()
        found += 1
if found == 0:
    print(f"  no packages matching '{q}'")
PY
}

# ---------------------------------------------------------------------------
# cmd_validate
# ---------------------------------------------------------------------------
cmd_validate() {
    check_index
    _require_python
    banner "validating index.json"
    info "path: $INDEX"
    blank
    if python3 -m json.tool "$INDEX" >/dev/null 2>&1; then
        ok "index.json is valid JSON!"
        local COUNT
        COUNT=$(python3 -c "import json; d=json.load(open('$INDEX')); print(len([k for k in d if not k.startswith('_')]))")
        info "$COUNT packages found."
    else
        err "index.json has a syntax error!"
        blank
        python3 -m json.tool "$INDEX" 2>&1 | head -20 || true
        exit 1
    fi
}

# ---------------------------------------------------------------------------
# cmd_format
# ---------------------------------------------------------------------------
cmd_format() {
    check_index
    _require_python
    banner "formatting index.json"
    if ! validate_json; then exit 1; fi
    python3 - "$INDEX" <<'PY'
import json, sys
path = sys.argv[1]
with open(path) as f: idx = json.load(f)
with open(path, "w") as f:
    json.dump(idx, f, indent=2); f.write("\n")
print("  formatted.")
PY
    ok "index.json formatted cleanly."
}

# ---------------------------------------------------------------------------
# cmd_rename  -- rename a package key in index.json
# ---------------------------------------------------------------------------
cmd_rename() {
    check_index
    _require_python
    local old="${1:-}" new="${2:-}"
    [[ -z "$old" ]] && old=$(_prompt "current package name" "")
    [[ -z "$new" ]] && new=$(_prompt "new package name" "")
    [[ -z "$old" || -z "$new" ]] && { err "Both names required."; exit 1; }
    banner "rename: $old -> $new"

    python3 - "$INDEX" "$old" "$new" <<'PY'
import json, sys
path, old, new = sys.argv[1], sys.argv[2], sys.argv[3]
with open(path) as f: idx = json.load(f)
if old not in idx:
    print(f"  '{old}' not found in index.json"); sys.exit(1)
if new in idx:
    print(f"  '{new}' already exists -- aborting"); sys.exit(1)
idx[new] = idx.pop(old)
if "output" not in idx[new]:
    idx[new]["output"] = new
with open(path, "w") as f:
    json.dump(idx, f, indent=2); f.write("\n")
PY
    ok "Renamed '$old' to '$new'."
}

# ---------------------------------------------------------------------------
# cmd_cfg  -- show resolved config
# ---------------------------------------------------------------------------
cmd_cfg() {
    blank
    echo -e "  ${BOLD}hetrix paths${NC}"
    divider
    echo -e "  ${CYAN}HETRIX_DIR  ${NC}= ${DIM}${HETRIX_DIR}${NC}"
    echo -e "  ${CYAN}INDEX       ${NC}= ${DIM}${INDEX}${NC}"
    echo -e "  ${CYAN}BIN_DIR     ${NC}= ${DIM}${BIN_DIR}${NC}"
    [[ -f "$CFG" ]] && echo -e "  ${CYAN}CFG         ${NC}= ${DIM}${CFG}${NC}"
    blank
}

# ---------------------------------------------------------------------------
# cmd_menu  -- interactive TUI menu
# ---------------------------------------------------------------------------
cmd_menu() {
    while true; do
        clear
        echo -e "${CYAN}"
        cat <<'ASCII'
      ::::::::   ::::::::  ::::    ::: :::::::::: ::::::::::: ::::::::   ::::::::  :::   ::: 
    :+:    :+: :+:    :+: :+:+:   :+: :+:            :+:    :+:    :+: :+:    :+: :+:   :+: 
   +:+        +:+    +:+ :+:+:+  +:+ +:+            +:+    +:+        +:+         +:+ +:+   
  +#+        +#+    +:+ +#+ +:+ +#+ :#::+::#       +#+    :#:        :#:          +#++:     
 +#+        +#+    +#+ +#+  +#+#+# +#+            +#+    +#+   +#+# +#+   +#+#    +#+       
#+#    #+# #+#    #+# #+#   #+#+# #+#            #+#    #+#    #+# #+#    #+#    #+#        
########   ########  ###    #### ###        ########### ########   ########     ###         
ASCII
        echo -e "${NC}"
        echo -e "  ${BLUE}index:${NC} ${DIM}${INDEX}${NC}"
        echo -e "  ${BLUE}bin:  ${NC} ${DIM}${BIN_DIR}${NC}"
        blank
        echo -e "  ${BOLD}  1)${NC} add package"
        echo -e "  ${BOLD}  2)${NC} remove package"
        echo -e "  ${BOLD}  3)${NC} edit package field"
        echo -e "  ${BOLD}  4)${NC} list all packages"
        echo -e "  ${BOLD}  5)${NC} show package details"
        echo -e "  ${BOLD}  6)${NC} search"
        echo -e "  ${BOLD}  7)${NC} uninstall binary from bin/"
        echo -e "  ${BOLD}  8)${NC} validate JSON"
        echo -e "  ${BOLD}  9)${NC} format / pretty-print"
        echo -e "  ${BOLD}  r)${NC} rename package"
        echo -e "  ${BOLD}  c)${NC} show paths / config"
        echo -e "  ${BOLD}  q)${NC} quit"
        blank
        local CHOICE
        CHOICE=$(_prompt "choice" "")
        blank
        case "$CHOICE" in
            1) cmd_add       ;;
            2) cmd_remove    ;;
            3) cmd_edit      ;;
            4) cmd_list      ;;
            5) cmd_show      ;;
            6) cmd_search    ;;
            7) cmd_uninstall ;;
            8) cmd_validate  ;;
            9) cmd_format    ;;
            r|R) cmd_rename  ;;
            c|C) cmd_cfg     ;;
            q|Q) info "bye!"; exit 0 ;;
            *) warn "unknown option '$CHOICE'" ;;
        esac
        blank
        read -rp "$(echo -e "  ${DIM}press enter to continue...${NC}")" _
    done
}

# ---------------------------------------------------------------------------
# cmd_help
# ---------------------------------------------------------------------------
cmd_help() {
    echo -e "${BLUE}  COMMANDS${NC}"
    _row() { printf "  ${BOLD}%-26s${NC} %s\n" "$1" "$2"; }
    _row "add"                    "add a new package interactively"
    _row "remove [name]"          "remove from index and optionally from bin/"
    _row "uninstall [name]"       "delete the installed binary from bin/"
    _row "edit [name]"            "edit a single field of a package"
    _row "rename [old] [new]"     "rename a package key"
    _row "list"                   "list packages grouped by build system"
    _row "show [name]"            "show all fields of one package"
    _row "search [query]"         "search by name, URL, or description"
    _row "validate"               "check index.json for syntax errors"
    _row "format"                 "pretty-print index.json in place"
    _row "cfg"                    "show resolved paths and config"
    _row "(no args)"              "open the interactive menu"
    _row "help"                   "show this help"
    blank
    echo -e "${BLUE}  ENVIRONMENT${NC}"
    printf "  ${CYAN}HETRIX_INDEX${NC}  = %s\n" "$INDEX"
    printf "  ${CYAN}HETRIX_BIN${NC}    = %s\n" "$BIN_DIR"
    printf "  ${CYAN}HETRIX_DIR${NC}    = %s\n" "$HETRIX_DIR"
    blank
}

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
case "${1:-}" in
    add)               cmd_add       "${@:2}"    ;;
    remove|rm)         cmd_remove    "${2:-}"    ;;
    uninstall)         cmd_uninstall "${2:-}"    ;;
    edit)              cmd_edit      "${2:-}"    ;;
    rename)            cmd_rename    "${2:-}" "${3:-}" ;;
    list|ls)           cmd_list                  ;;
    show)              cmd_show      "${2:-}"    ;;
    search)            cmd_search    "${2:-}"    ;;
    validate)          cmd_validate              ;;
    format|fmt)        cmd_format               ;;
    cfg|paths)         cmd_cfg                  ;;
    help|--help|-h)    cmd_help                 ;;
    "")                cmd_menu                 ;;
    *)
        err "unknown command: $1"
        info "run: hetrix configgy help"
        exit 1
        ;;
esac
