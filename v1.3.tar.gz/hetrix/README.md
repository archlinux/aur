  hetrix  --  source-based package manager  *  v1.3
  fetches source code, builds it, installs the binary.

--------------------------------------------------------------------------------
  quick start
--------------------------------------------------------------------------------

  1.  build and install hetrix:

        chmod +x hetrix.sh
        ./hetrix.sh

  2.  browse available packages:

        hetrix list

  3.  install something:

        hetrix fetch ripgrep
        hetrix fetch lazygit
        hetrix fetch bat

  4.  install everything in index.json at once (parallel):

        hetrix fetch --all
        hetrix fetch --all --jobs 4     # override concurrency

  5.  remove a binary:

        hetrix remove ripgrep

  6.  add your own packages with configgy:

        chmod +x configgy.sh
        ./configgy.sh

--------------------------------------------------------------------------------
  install methods
--------------------------------------------------------------------------------

    ./hetrix.sh                       build + install to /usr/local/bin
    ./hetrix.sh --prefix ~/.local     install without root
    ./hetrix.sh --no-install          build only  (output: ./hetrix)
    ./hetrix.sh --no-seed             skip copying index.json

--------------------------------------------------------------------------------
  requirements
--------------------------------------------------------------------------------

  to build hetrix itself:

    g++ >= 8  (c++17 filesystem support required)
    make

  to use hetrix (install packages):

    git     -- for cloning repos
    curl    -- for downloading archives and binaries
    + the build tools for each package (see build systems below)

  distro install commands:

    debian / ubuntu   sudo apt install g++ make git curl cmake
    fedora / rhel     sudo dnf install gcc-c++ make git curl cmake
    arch / endeavouros  sudo pacman -s gcc make git curl cmake
    alpine linux      sudo apk add g++ make git curl cmake
    void linux        sudo xbps-install -s gcc make git curl cmake

--------------------------------------------------------------------------------
  workspace layout
--------------------------------------------------------------------------------

    ~/hetrix/
    |-- index.json          package registry          <-- edit this
    |-- installed.json      lock file (installed pkgs)
    |-- cfg.toml            configuration
    |-- bin/                installed binaries         <-- add to path
    |-- workspace/          temporary build dirs       (auto-cleaned)
    |-- repos/              local source overrides     (optional)
    |-- src/                hetrix c++ source code
    |-- configgy.sh         interactive index manager
    |-- hetrix.sh           build + install script
    |-- makefile
    `-- readme.md

  all paths are overridable via environment variables:

    hetrix_dir          base directory          (default: ~/hetrix)
    hetrix_bin          installed binaries       (default: ~/hetrix/bin)
    hetrix_workspace    build workspace          (default: ~/hetrix/workspace)
    hetrix_index        package index file       (default: ~/hetrix/index.json)

  when run as root, binaries install to /usr/local/bin/ instead of ~/hetrix/bin.

--------------------------------------------------------------------------------
  commands
--------------------------------------------------------------------------------

  install / manage
    hetrix fetch <package>        fetch, build, and install a package
    hetrix fetch <user/repo>      github shorthand  (auto-detect build)
    hetrix fetch <url>            full url  (auto-detect build)
    hetrix fetch --all            fetch every package in index.json (parallel)
    hetrix upgrade <package>      check remote for a newer version and rebuild
    hetrix upgrade --all          upgrade all installed packages (parallel)
    hetrix rebuild <package>      force re-fetch and rebuild a package
    hetrix rebuild --all          rebuild all installed packages (parallel)
    hetrix remove <package>       remove an installed binary from bin/

  information
    hetrix status                 health check -- show ok/missing/broken for all
    hetrix info <package>         show all index + install details for one package
    hetrix list                   list all packages in index.json
    hetrix search <query>         search by name, url, or description
    hetrix installed              list packages tracked in installed.json
    hetrix which <package>        show installed binary path

  portability
    hetrix export [output.json]   dump installed packages as index.json fragment
                                  (use to reproduce your setup on another machine)
    hetrix sync                   merge remote index.json (see cfg.toml)
    hetrix sync --url <url>       sync from a specific url

  workspace
    hetrix clean                  wipe entire workspace
    hetrix clean <package>        wipe one package from workspace
    hetrix init                   initialise ~/hetrix/ workspace

  index
    hetrix index                  print path to index.json
    hetrix index --edit           open index.json in your $editor
    hetrix configgy [subcommand]  interactive index manager (add/remove/edit...)

  config
    hetrix config                 show all cfg.toml values
    hetrix config --edit          open cfg.toml in your $editor

  archives (requires zpaq from your package manager)
    hetrix zpaq compress <f> [o]  compress file or directory to .zpaq
    hetrix zpaq extract <arc> [d] extract .zpaq archive
    hetrix zpaq list <arc>        list archive contents
    hetrix repos list             list ~/hetrix/repos/
    hetrix repos compress [name]  compress repo dir(s) to .zpaq
    hetrix repos extract [name]   extract .zpaq repo(s)

  flags
    --all           operate on all packages (parallel)
    --jobs n        override parallel_pkg_jobs for this run
    --move          skip prompt -- always move binary to bin/
    --keep          skip prompt -- always keep binary in workspace
    --no-clean      keep workspace after install
    --index <path>  use a custom index.json path
    --force         overwrite existing index.json on init
    --url <url>     url to sync from (overrides cfg.toml)
    --overwrite     remote entries win on conflict (sync)

--------------------------------------------------------------------------------
  build systems
--------------------------------------------------------------------------------

  set "build" in index.json to one of these values:

  c / c++
    gcc           compile .c files with gcc
    g++           compile .cpp files with g++
    cmake         cmakelists.txt  (calls make internally)
    make          makefile  (plain make -j)
    autoconf      configure.ac / configure script -> make
    meson         meson.build  (calls ninja, installs to local prefix)

  compiled languages
    cargo         rust   (cargo.toml)     binaries -> target/release/
    go            go     (go.mod)         binary   -> project root
    zig           zig    (build.zig)      binaries -> zig-out/bin/
    dune          ocaml  (dune-project)   binaries -> _build/default/

  scripted / bytecode
    python        pip install --user  (pyproject.toml / setup.py / setup.cfg)
    node          npm install + npm run build
    ruby          gem build/install or rake install
    bash          install.sh / build.sh / setup.sh, or set "main" to point to script

  special
    auto          hetrix inspects the repo and picks the right system

  auto-detection order:
    cmakelists.txt -> meson.build -> configure[.ac] -> makefile ->
    cargo.toml -> go.mod -> build.zig -> dune-project ->
    pyproject.toml / setup.py -> package.json -> *.gemspec ->
    *.cpp files -> *.c files

--------------------------------------------------------------------------------
  cfg.toml
--------------------------------------------------------------------------------

  location: ~/hetrix/cfg.toml

  [general]
    editor             = "nvim"        # editor for --edit commands
    clean_after_build  = true          # remove workspace after install
    parallel_jobs      = 0             # make -j n inside builds (0 = nproc)
    parallel_pkg_jobs  = 2             # how many packages to build at once
                                       # e.g. 4 on an i7-14700f is very fast

  [install]
    auto_move          = false         # always move binary to bin/
    auto_keep          = false         # always keep binary in workspace

  [sync]
    remote_index       = ""            # url to pull remote index.json from

  [paths]
    dir                = ""            # override ~/hetrix base dir
    bin                = ""            # override ~/hetrix/bin
    workspace          = ""            # override ~/hetrix/workspace

  [build]
    strip_binaries       = false       # run strip on installed elf binaries

  [default_args]
  # default arguments for each build tool. used when a package has no 'args'
  # set in index.json and 'no_extra_args' is not true.
  #
  # great place to set: -march=native -o3, cpu tuning, sanitisers, lto, etc.
  # setting any key overrides hetrix's built-in safe default for that tool.
  # empty = hetrix uses the built-in default shown in the comment.
  #
  # gcc_def_args     = "-o2 -wall"                   # c compiler
  # gpp_def_args     = "-std=c++17 -o2 -wall"        # c++ compiler
  # cmake_def_args   = "-dcmake_build_type=release"  # cmake configure
  # cargo_def_args   = "--release"                   # rust/cargo
  # zig_def_args     = "-doptimize=releasesafe"      # zig build
  # go_def_args      = ""                            # go build flags
  # meson_def_args   = ""                            # meson setup extra args
  # make_def_args    = ""                            # make extra vars/targets
  # autoconf_def_args = ""                           # ./configure extra args
  # node_def_args    = ""                            # npm install extra args
  # python_def_args  = ""                            # pip install extra args
  # ruby_def_args    = ""                            # gem/rake extra args
  # dune_def_args    = ""                            # dune build extra args
  # bash_def_args    = ""                            # bash script args
  #
  # example -- native optimised c/c++ builds:
  #   gcc_def_args   = "-o3 -march=native -pipe"
  #   gpp_def_args   = "-std=c++23 -o3 -march=native -pipe"
  #
  # per-package 'args' in index.json always wins over these defaults.
  # set 'no_extra_args: true' on a package to ignore defaults entirely.

  [fetch]
    git_depth          = 1             # clone depth (0 = full history)
    git_submodules     = true

  [verify]
    require_sha_for_curl = false       # reject curl packages without sha
    warn_missing_sha     = false

  [repos]
    auto_compress      = false         # compress local repos to .zpaq after use
    compression_level  = 5            # zpaq level 1 (fastest) to 5 (best)

--------------------------------------------------------------------------------
  index.json format
--------------------------------------------------------------------------------

  location: ~/hetrix/index.json
  edit with: hetrix index --edit   or   ./configgy.sh

  full example entry (all fields):

    "myapp": {
      "url":           "https://github.com/user/myapp",
      "pull_type":     "git",
      "build":         "cmake",
      "args":          "-dcmake_build_type=release -dwith_feature=on",
      "main":          "",
      "sub_dir":       "cli",
      "build_dir":     "",
      "output":        "myapp",
      "version":       "v2.1.0",
      "auto_add_cmds": "1",
      "no_extra_args": false,
      "description":   "my cool app",
      "install_cmd":   "",
      "sha256":        "",
      "sha512":        ""
    }

  fields:

    url             git repo, tarball url, or direct binary url  (required)
    pull_type       "git" | "curl" | "auto"  (default: auto)
    build           build system (see build systems above)
    args            extra flags passed to the compiler or build tool
    main            entry source file for single-file gcc/g++ or bash builds
    sub_dir         cd into this subdirectory before building
    build_dir       override the directory to scan for built binaries
    output          name of the binary to produce  (default: package name)
    version         git tag or branch to pin  (default: latest tag)
    auto_add_cmds   "1" = prompt to move binary to bin/ (default)
                    "0" = skip prompt, keep binary in workspace
    no_extra_args   true = pass only args to build tool, no injected defaults
    description     short description shown in hetrix list / hetrix info
    install_cmd     custom shell command run in the source directory
    sha256          expected sha-256 of download / git tree (optional)
    sha512          expected sha-512 of download / git tree (optional)

  go args example  (the tricky case):

    "build": "go",
    "args":  "-o validator ./cmd/validator",
    "output": ""    <-- leave empty so hetrix doesn't add a second -o

--------------------------------------------------------------------------------
  parallel builds
--------------------------------------------------------------------------------

  upgrade --all, rebuild --all, and fetch --all all build packages in parallel.

  how it works:
    - phase 1  (upgrade --all only): remote version tags are fetched in parallel
      (pure network, up to 2x parallel_pkg_jobs workers)
    - phase 2: each package's fetch + build + install runs in its own thread
    - subprocess output is captured to a per-package temp log file so it
      doesn't interleave; the log is dumped to stdout when the job finishes
    - progress is shown in real-time on stderr: [n/total] icon  package
    - lockmanager writes (installed.json) are mutex-protected

  tuning:
    parallel_pkg_jobs = 4    # in cfg.toml -- good starting point for 8+ cores
    hetrix upgrade --all --jobs 6   # one-off override

  note: parallel_jobs (make -j inside each build) and parallel_pkg_jobs
  (packages building simultaneously) are independent. with parallel_pkg_jobs=4
  and parallel_jobs=0 (nproc), you get 4 concurrent builds each using all cores.
  tune parallel_jobs downward if you want to limit total cpu load.

--------------------------------------------------------------------------------
  portability / export
--------------------------------------------------------------------------------

  to recreate your exact set of packages on another machine:

    hetrix export ~/hetrix/export.json        # on the source machine
    scp ~/hetrix/export.json newmachine:~/hetrix/index.json
    hetrix fetch --all                        # on the new machine

  export includes: url, build, args, version, sha, output, sub_dir, and all
  other index.json fields for installed packages. auto_add_cmds is always
  set to "1" in the export so binaries land in bin/ on reinstall.

--------------------------------------------------------------------------------
  status and info
--------------------------------------------------------------------------------

  hetrix status
    checks every entry in installed.json and reports:
      green  -- binary present and accounted for
      yellow -- binary was kept in workspace and workspace has been cleaned
                (run: hetrix rebuild <package>)
      red    -- binary missing from bin/ (run: hetrix rebuild <package>)

  hetrix info <package>
    shows all index.json fields + installed version, install date, binary
    path, binary present/missing, and workspace path.

--------------------------------------------------------------------------------
  configgy -- index manager
--------------------------------------------------------------------------------

  configgy.sh is an interactive tool for managing index.json
  without hand-editing json.

    ./configgy.sh                  open interactive menu
    ./configgy.sh add              add a package (interactive prompts)
    ./configgy.sh remove <name>    remove from index and/or delete from bin/
    ./configgy.sh uninstall <name> delete the installed binary from bin/
    ./configgy.sh edit <name>      edit a single field
    ./configgy.sh list             list all packages grouped by build system
    ./configgy.sh show <name>      show all fields of a package
    ./configgy.sh search <query>   search by name, url, or description
    ./configgy.sh validate         check index.json for json syntax errors
    ./configgy.sh format           pretty-print index.json in place

--------------------------------------------------------------------------------
  local repo override
--------------------------------------------------------------------------------

  drop source into ~/hetrix/repos/<name>/ and hetrix uses that instead
  of downloading from the url -- useful for offline use or local projects:

    mkdir -p ~/hetrix/repos/myapp
    cp -r /path/to/source/* ~/hetrix/repos/myapp/
    hetrix fetch myapp

  repos can also be zpaq-compressed for storage:

    hetrix repos compress myapp    # creates repos/myapp.zpaq, removes dir
    hetrix repos extract myapp     # decompresses before next use
    hetrix repos list              # show all local repos

--------------------------------------------------------------------------------
  path setup
--------------------------------------------------------------------------------

  add ~/hetrix/bin to your path so installed binaries are accessible:

    echo 'export path="$path:$home/hetrix/bin"' >> ~/.bashrc
    source ~/.bashrc

  for fish shell:

    fish_add_path ~/hetrix/bin

  hetrix will print a warning if the bin directory is not on your path
  after a successful install.

--------------------------------------------------------------------------------
  source code
--------------------------------------------------------------------------------

  src/
    main.cpp            entry point + all commands + cli parser
    builder.hpp         build system detection + all build strategies
    fetcher.hpp         git clone / curl download / local repo copy
    installer.hpp       binary detection + interactive install prompt
    updater.hpp         upgrade / rebuild / parallel --all logic
    config_manager.hpp  json parser + index.json load/save
    config.hpp          packageentry struct + packageindex type
    lock.hpp            installed.json read/write (thread-safe)
    logger.hpp          coloured output + nerd font icons + write mutex
    utils.hpp           filesystem, shell, path, string helpers
    cfg.hpp             cfg.toml parser + hetrixconfig struct ([default_args] + [build])
    thread_pool.hpp     fixed-size worker pool for parallel builds
    progress.hpp        thread-safe [n/total] progress ticker
    zpaq.hpp            zpaq archive wrapper

  to recompile after modifying source:

    cd ~/hetrix
    ./hetrix.sh --no-seed          (rebuild only, don't touch index.json)
    # or
    make
