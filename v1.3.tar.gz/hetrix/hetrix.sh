#!/usr/bin/env bash
# hetrix.sh -- compile and install hetrix
# Usage: ./hetrix.sh [--prefix DIR] [--no-install] [--no-seed]
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[1;36m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

info()   { echo -e "${CYAN}  >> ${NC}$*"; }
ok()     { echo -e "${GREEN}  ✔  ${NC}$*"; }
warn()   { echo -e "${YELLOW}  ⚠  ${NC}$*"; }
err()    { echo -e "${RED}  ✖  ${NC}$*" >&2; }
step()   { echo -e "${BOLD}  >> ${NC}$*"; }
banner() { echo -e "\n${CYAN}  +== ${BOLD}$* ${NC}${CYAN}==+${NC}\n"; }

echo -e "${CYAN}"
cat <<'ASCII'
  ██╗  ██╗███████╗████████╗██████╗ ██╗██╗  ██╗
  ██║  ██║██╔════╝╚══██╔══╝██╔══██╗██║╚██╗██╔╝
  ███████║█████╗     ██║   ██████╔╝██║ ╚███╔╝ 
  ██╔══██║██╔══╝     ██║   ██╔══██╗██║ ██╔██╗ 
  ██║  ██║███████╗   ██║   ██║  ██║██║██╔╝ ██╗
  ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝
ASCII
echo -e "${NC}${DIM}  hetrix build script  *  v1.2${NC}\n"

# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
PREFIX="/usr/local"
NO_INSTALL=0
NO_SEED=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --prefix)     PREFIX="$2"; shift 2 ;;
        --prefix=*)   PREFIX="${1#*=}"; shift ;;
        --no-install) NO_INSTALL=1; shift ;;
        --no-seed)    NO_SEED=1; shift ;;
        --help|-h)
            echo "Usage: $0 [--prefix DIR] [--no-install] [--no-seed]"
            echo "  --prefix DIR   install to DIR/bin  (default: /usr/local)"
            echo "  --no-install   build only, don't install"
            echo "  --no-seed      don't copy index.json or configgy.sh"
            exit 0 ;;
        *) warn "Unknown argument: $1"; shift ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HETRIX_HOME="${HETRIX_DIR:-$HOME/hetrix}"

# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------
banner "checking build dependencies"
MISSING=()
for tool in g++ make; do
    if command -v "$tool" &>/dev/null; then
        ok "found: $tool"
    else
        warn "missing: $tool"
        MISSING+=("$tool")
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    err "Missing tools: ${MISSING[*]}"
    echo ""
    echo "  Install with your package manager:"
    echo "    Arch / EndeavourOS  ->  sudo pacman -S gcc make"
    echo "    Debian / Ubuntu     ->  sudo apt install g++ make"
    echo "    Fedora              ->  sudo dnf install gcc-c++ make"
    echo "    Alpine              ->  sudo apk add g++ make"
    exit 1
fi

# ---------------------------------------------------------------------------
# C++17 filesystem probe
# ---------------------------------------------------------------------------
banner "checking C++17 support"
TMP=$(mktemp /tmp/hetrix_probe_XXXXXX.cpp)
cat >"$TMP" <<'EOF'
#include <filesystem>
int main(){ return std::filesystem::exists("/") ? 0 : 1; }
EOF

EXTRA_LD=""
if g++ -std=c++17 -o /tmp/hetrix_probe "$TMP" -lstdc++fs 2>/dev/null; then
    EXTRA_LD="-lstdc++fs"
    ok "C++17 filesystem OK (with -lstdc++fs)"
elif g++ -std=c++17 -o /tmp/hetrix_probe "$TMP" 2>/dev/null; then
    ok "C++17 filesystem OK"
else
    err "g++ does not support C++17 filesystem. Upgrade to g++ >= 8."
    rm -f "$TMP" /tmp/hetrix_probe
    exit 1
fi
rm -f "$TMP" /tmp/hetrix_probe

# ---------------------------------------------------------------------------
# Compile
# ---------------------------------------------------------------------------
banner "compiling hetrix"
cd "$SCRIPT_DIR"

CXXFLAGS="-std=c++17 -O2 -Wall -Wextra -Isrc"
LDFLAGS="-lpthread $EXTRA_LD"
CMD="g++ $CXXFLAGS src/main.cpp -o hetrix $LDFLAGS"
step "$CMD"
if eval "$CMD"; then
    ok "compiled: $SCRIPT_DIR/hetrix"
else
    err "compilation failed!"
    exit 1
fi

# ---------------------------------------------------------------------------
# Skip install?
# ---------------------------------------------------------------------------
if [[ "$NO_INSTALL" -eq 1 ]]; then
    warn "--no-install: skipping install."
    echo ""
    ok "binary at: $SCRIPT_DIR/hetrix"
    echo "  run:  ./hetrix help"
    exit 0
fi

# ---------------------------------------------------------------------------
# Install binary
# ---------------------------------------------------------------------------
banner "installing hetrix"
mkdir -p "$PREFIX/bin"
if [[ ! -w "$PREFIX/bin" ]]; then
    warn "No write permission to $PREFIX/bin -- trying sudo..."
    sudo install -Dm755 hetrix "$PREFIX/bin/hetrix"
else
    install -Dm755 hetrix "$PREFIX/bin/hetrix"
fi
ok "installed: $PREFIX/bin/hetrix"

# ---------------------------------------------------------------------------
# Install configgy.sh alongside the binary so 'hetrix configgy' can find it
# ---------------------------------------------------------------------------
if [[ "$NO_SEED" -ne 1 ]]; then
    if [[ -f "$SCRIPT_DIR/configgy.sh" ]]; then
        if [[ ! -w "$PREFIX/bin" ]]; then
            sudo install -Dm755 "$SCRIPT_DIR/configgy.sh" "$PREFIX/bin/configgy.sh"
        else
            install -Dm755 "$SCRIPT_DIR/configgy.sh" "$PREFIX/bin/configgy.sh"
        fi
        ok "installed: $PREFIX/bin/configgy.sh"
    else
        warn "configgy.sh not found next to hetrix.sh -- skipping."
    fi
fi

# ---------------------------------------------------------------------------
# Seed workspace
# ---------------------------------------------------------------------------
banner "seeding workspace"
mkdir -p "$HETRIX_HOME/bin" "$HETRIX_HOME/workspace" "$HETRIX_HOME/repos"

if [[ "$NO_SEED" -eq 1 ]]; then
    warn "--no-seed: skipping index.json and cfg.toml seeding."
else
    # index.json
    if [[ -f "$HETRIX_HOME/index.json" ]]; then
        info "index.json already exists -- left untouched."
    elif [[ -f "$SCRIPT_DIR/index.json" ]]; then
        cp "$SCRIPT_DIR/index.json" "$HETRIX_HOME/index.json"
        ok "seeded: $HETRIX_HOME/index.json"
    else
        warn "No index.json found -- hetrix will write a template on first init."
    fi

    # cfg.toml  (write template only if it doesn't exist)
    if [[ ! -f "$HETRIX_HOME/cfg.toml" ]]; then
        hetrix_bin="$PREFIX/bin/hetrix"
        if [[ -x "$hetrix_bin" ]]; then
            # Run 'hetrix init' to write the template properly
            "$hetrix_bin" init --force 2>/dev/null || true
        fi
        # If still missing (hetrix init not found yet), write a minimal one
        if [[ ! -f "$HETRIX_HOME/cfg.toml" ]]; then
            cat >"$HETRIX_HOME/cfg.toml" <<'TOML'
# hetrix configuration file -- see 'hetrix config' for docs
[general]
clean_after_build = true
parallel_jobs     = 0

[install]
auto_move = false
auto_keep = false

[sync]
remote_index = ""

[paths]
# dir       = "~/hetrix"
# bin       = "~/hetrix/bin"
# workspace = "~/hetrix/workspace"
TOML
            ok "created: $HETRIX_HOME/cfg.toml"
        fi
    else
        info "cfg.toml already exists -- left untouched."
    fi
fi

ok "workspace ready: $HETRIX_HOME/"

# ---------------------------------------------------------------------------
# PATH hints
# ---------------------------------------------------------------------------
echo ""
if [[ ":$PATH:" != *":$PREFIX/bin:"* ]]; then
    warn "$PREFIX/bin not in PATH. Add to ~/.bashrc / ~/.profile:"
    echo "    export PATH=\"\$PATH:$PREFIX/bin\""
fi
if [[ ":$PATH:" != *":$HETRIX_HOME/bin:"* ]]; then
    warn "$HETRIX_HOME/bin not in PATH. Add to ~/.bashrc / ~/.profile:"
    echo "    export PATH=\"\$PATH:$HETRIX_HOME/bin\""
fi

echo ""
echo -e "${GREEN}${BOLD}  ✔ hetrix installed!${NC}"
echo ""
echo "  hetrix help               show all commands"
echo "  hetrix list               list packages"
echo "  hetrix configgy           manage index.json interactively"
echo "  hetrix index --edit       open index.json in your editor"
echo "  hetrix fetch <package>    install a package"
echo "  hetrix upgrade --all      upgrade everything"
echo ""
