#include <iostream>
#include <string>
#include <vector>
#include <optional>
#include <filesystem>
#include <algorithm>
#include <future>

#include "logger.hpp"
#include "utils.hpp"
#include "cfg.hpp"
#include "config.hpp"
#include "config_manager.hpp"
#include "lock.hpp"
#include "fetcher.hpp"
#include "builder.hpp"
#include "installer.hpp"
#include "updater.hpp"
#include "zpaq.hpp"
#include "thread_pool.hpp"
#include "progress.hpp"

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Global config (loaded once at startup)
// ---------------------------------------------------------------------------

static HetrixConfig gCfg;

// ---------------------------------------------------------------------------
// Workspace bootstrap
// ---------------------------------------------------------------------------

static void initWorkspace() {
    Utils::mkdirp(Utils::hetrixDir());
    Utils::mkdirp(Utils::binDir());
    Utils::mkdirp(Utils::workspaceDir());
    Utils::mkdirp(Utils::reposDir());
}

// ---------------------------------------------------------------------------
// Option bag
// ---------------------------------------------------------------------------

struct Opts {
    std::string              command;
    std::string              arg;           // first positional after command
    std::vector<std::string> extra;         // remaining positionals / pass-through args

    bool forceMove  = false;   // --move
    bool forceKeep  = false;   // --keep
    bool noClean    = false;   // --no-clean
    bool editIndex  = false;   // --edit
    bool forceInit  = false;   // --force
    bool overwrite  = false;   // --overwrite  (sync)
    bool all        = false;   // --all        (upgrade / fetch / rebuild)

    std::string customIndex;   // --index <path>
    std::string remoteUrl;     // --url <url>   (sync)
    int         jobs        = 0; // --jobs N  (override parallel_pkg_jobs)
};

static Opts parseArgs(int argc, char* argv[]) {
    Opts o;
    for (int i = 1; i < argc; ++i) {
        std::string a(argv[i]);
        if      (a == "--move")       { o.forceMove = true; }
        else if (a == "--keep")       { o.forceKeep = true; }
        else if (a == "--no-clean")   { o.noClean   = true; }
        else if (a == "--edit")       { o.editIndex = true; }
        else if (a == "--force")      { o.forceInit = true; }
        else if (a == "--overwrite")  { o.overwrite = true; }
        else if (a == "--all")        { o.all       = true; }
        else if ((a == "--index" || a == "-i") && i + 1 < argc) {
            o.customIndex = argv[++i];
        } else if (a == "--url" && i + 1 < argc) {
            o.remoteUrl = argv[++i];
        } else if ((a == "--jobs" || a == "-j") && i + 1 < argc) {
            try { o.jobs = std::stoi(argv[++i]); } catch (...) { o.jobs = 0; }
        } else if (o.command.empty()) {
            o.command = a;
        } else if (o.arg.empty()) {
            o.arg = a;
        } else {
            o.extra.push_back(a);
        }
    }
    return o;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static ConfigManager makeCM(const Opts& opts) {
    ConfigManager cm;
    if (!opts.customIndex.empty()) cm.setIndexPath(opts.customIndex);
    return cm;
}

static LockManager makeLM() {
    return LockManager();
}

// Apply cfg.toml path overrides to env (set env so Utils:: picks them up)
static void applyCfgPaths(const HetrixConfig& cfg) {
    if (!cfg.dir.empty())       setenv("HETRIX_DIR",       Utils::expandHome(cfg.dir).c_str(),       1);
    if (!cfg.bin.empty())       setenv("HETRIX_BIN",       Utils::expandHome(cfg.bin).c_str(),       1);
    if (!cfg.workspace.empty()) setenv("HETRIX_WORKSPACE", Utils::expandHome(cfg.workspace).c_str(), 1);
}

// ---------------------------------------------------------------------------
// help
// ---------------------------------------------------------------------------

static void printHelp(const std::string& /*prog*/) {
    auto section = [](const std::string& title) {
        std::cout << "\n" CLR_BBLUE "  " << title << "\n" CLR_RESET;
    };
    auto row = [](const std::string& cmd, const std::string& desc) {
        std::cout << "  " CLR_BOLD << cmd << CLR_RESET;
        int pad = 36 - (int)cmd.size();
        if (pad > 0) std::cout << std::string(pad, ' ');
        std::cout << desc << "\n";
    };
    auto frow = [](const std::string& f, const std::string& d) {
        std::cout << "  " CLR_GREEN << f << CLR_RESET;
        int pad = 18 - (int)f.size();
        if (pad > 0) std::cout << std::string(pad, ' ');
        std::cout << d << "\n";
    };
    auto pathRow = [](const std::string& label, const std::string& val,
                      const std::string& desc) {
        std::cout << "  " CLR_CYAN << label << CLR_RESET " = "
                  << CLR_DIM << val << CLR_RESET "\n"
                  << "  " << std::string(label.size() + 3, ' ')
                  << CLR_DIM << desc << CLR_RESET "\n";
    };

    section("COMMANDS");
    row("fetch <package>",            "fetch, build, and install a package");
    row("fetch <user/repo>",          "GitHub shorthand (auto-detect build)");
    row("fetch <https://...>",        "full URL (auto-detect build)");
    row("fetch --all",                "fetch and install every package in index.json");
    row("upgrade <package>",          "check for update and rebuild if newer");
    row("upgrade --all",              "upgrade all installed packages (parallel)");
    row("rebuild <package>",          "force re-fetch and rebuild a package");
    row("rebuild --all",              "rebuild all installed packages (parallel)");
    row("status",                     "check health of every installed package");
    row("info <package>",             "show all known info about a package");
    row("export [output.json]",       "dump installed packages as index.json fragment");
    row("sync",                       "merge remote index.json (see cfg.toml)");
    row("sync --url <url>",           "sync from a specific URL");
    row("remove <package>",           "remove an installed binary from bin/");
    row("list",                       "list all packages in index.json");
    row("search <query>",             "search by name, URL, or description");
    row("which <package>",            "show installed binary path");
    row("init",                       "initialise ~/hetrix/ workspace");
    row("index",                      "print path to index.json");
    row("index --edit",               "open index.json in your $EDITOR");
    row("clean",                      "remove all workspace build dirs");
    row("clean <package>",            "remove workspace dir for one package");
    row("configgy [subcommand]",      "index.json manager (add/remove/edit/list...)");
    row("zpaq <compress|extract|list>", "zpaq archive tool for general files");
    row("repos <list|compress|extract>","manage ~/hetrix/repos/ local repo overrides");
    row("config",                     "show current cfg.toml path and values");
    row("config --edit",              "open cfg.toml in your $EDITOR");
    row("installed",                  "list packages tracked in installed.json");
    row("help",                       "show this help");

    section("FETCH / UPGRADE / REBUILD FLAGS");
    row("  --all",                    "operate on all packages (parallel)");
    row("  --jobs N",                 "override parallel_pkg_jobs for this run");
    row("  --move",                   "skip prompt -- always move to bin");
    row("  --keep",                   "skip prompt -- always keep in place");
    row("  --no-clean",               "keep workspace after install");

    section("SYNC FLAGS");
    row("  --url <url>",              "URL to sync from (overrides cfg.toml)");
    row("  --overwrite",              "remote entries win on conflict");

    section("GLOBAL FLAGS");
    row("  --index <path>",           "use a custom index.json path");
    row("  --force",                  "overwrite index.json on init");

    section("PATHS  " CLR_DIM "(overridable via env vars or cfg.toml)");
    pathRow("HETRIX_DIR",       Utils::hetrixDir(),    "base workspace  (default: ~/hetrix)");
    pathRow("HETRIX_BIN",       Utils::binDir(),       "installed binaries");
    pathRow("HETRIX_WORKSPACE", Utils::workspaceDir(), "temporary build dirs");
    pathRow("HETRIX_INDEX",     Utils::indexPath(),    "package index file");

    section("BUILD SYSTEMS  " CLR_DIM "(set \"build\": \"...\" in index.json)");
    std::cout << "\n  " CLR_DIM "C / C++\n" CLR_RESET;
    row("  gcc",                      "compile .c files with gcc");
    row("  g++",                      "compile .cpp files with g++");
    row("  cmake",                    "CMakeLists.txt -> make");
    row("  make",                     "Makefile (plain make -j)");
    row("  autoconf",                 "configure.ac / configure -> make");
    row("  meson",                    "meson.build -> ninja");
    std::cout << "\n  " CLR_DIM "Compiled languages\n" CLR_RESET;
    row("  cargo",                    "Rust (Cargo.toml) -> target/release/");
    row("  go",                       "Go (go.mod) -> project root");
    row("  zig",                      "Zig (build.zig) -> zig-out/bin/");
    row("  dune",                     "OCaml (dune-project) -> _build/default/");
    std::cout << "\n  " CLR_DIM "Scripted\n" CLR_RESET;
    row("  python",                   "pip install (pyproject.toml / setup.py)");
    row("  node",                     "npm install + npm run build");
    row("  ruby",                     "gem build/install or rake install");
    row("  bash",                     "install.sh / build.sh / setup.sh (or set \"main\")");
    std::cout << "\n  " CLR_DIM "Special\n" CLR_RESET;
    row("  auto",                     "hetrix sniffs the repo and picks for you");

    section("INDEX.JSON FIELDS");
    frow("url",            "git repo, tarball URL, or direct binary URL");
    frow("pull_type",      "\"git\" | \"curl\" | \"auto\"  (default: auto)");
    frow("build",          "build system value from the list above");
    frow("args",           "extra compiler / cmake / cargo flags");
    frow("main",           "entry source file (single-file gcc/g++ builds)");
    frow("sub_dir",        "cd into this subdir before building");
    frow("build_dir",      "override where to search for built binaries");
    frow("output",         "binary name to produce  (default: package name)");
    frow("version",        "git tag or branch to pin  (default: latest tag)");
    frow("auto_add_cmds",  "\"1\" prompt to move to bin (default), \"0\" keep in workspace");
    frow("description",    "shown in hetrix list");
    frow("install_cmd",    "custom shell command (runs in src dir)");
    frow("sha256",         "SHA-256 digest for verification (curl: of download; git: of tree)");
    frow("sha512",         "SHA-512 digest (same as above)");
    frow("no_extra_args",  "true = pass ONLY args to build tool, no injected defaults");

    section("CFG.TOML KEYS");
    frow("[general]",           "");
    frow("  editor",            "preferred editor for --edit commands");
    frow("  clean_after_build", "remove workspace after install (default: true)");
    frow("  parallel_jobs",     "make -j N inside each build (0 = auto nproc)");
    frow("  parallel_pkg_jobs", "how many packages to build in parallel (default: 2)");
    frow("[install]",           "");
    frow("  auto_move",         "always move binary to bin (default: false)");
    frow("  auto_keep",         "always keep in workspace (default: false)");
    frow("[sync]",              "");
    frow("  remote_index",      "URL to pull remote index from");
    frow("[paths]",             "dir / bin / workspace  (override env vars)");
    frow("[build]",             "");
    frow("  strip_binaries",    "run 'strip' on installed ELF binaries (default: false)");
    frow("[default_args]",      "per-build-system default flags (used when pkg has no 'args')");
    frow("  gcc_def_args",      "default: -O2 -Wall");
    frow("  gpp_def_args",      "default: -std=c++17 -O2 -Wall");
    frow("  cmake_def_args",    "default: -DCMAKE_BUILD_TYPE=Release");
    frow("  cargo_def_args",    "default: --release");
    frow("  zig_def_args",      "default: -Doptimize=ReleaseSafe");
    frow("  go_def_args",       "default: (none)");
    frow("  meson_def_args",    "default: (none)  -- extra meson setup args");
    frow("  make_def_args",     "default: (none)  -- extra make variables/targets");
    frow("  autoconf_def_args", "default: (none)  -- extra ./configure args");
    frow("  node_def_args",     "default: (none)  -- extra npm install args");
    frow("  python_def_args",   "default: (none)  -- extra pip install args");
    frow("  ruby_def_args",     "default: (none)  -- extra gem/rake args");
    frow("  dune_def_args",     "default: (none)  -- extra dune build args");
    frow("  bash_def_args",     "default: (none)  -- args passed to bash scripts");
    frow("[fetch]",             "");
    frow("  git_depth",         "clone depth (1=shallow, 0=full history)");
    frow("  git_submodules",    "recurse submodules (default: true)");
    frow("[verify]",            "");
    frow("  require_sha_for_curl","reject curl packages without sha (default: false)");
    frow("  warn_missing_sha",  "warn when any package has no sha (default: false)");
    frow("[repos]",             "");
    frow("  auto_compress",     "compress local repos to .zpaq after use (default: false)");
    frow("  compression_level", "zpaq level 1-5 (default: 5)");
    std::cout << "\n  " CLR_DIM
              << "zpaq is optional -- install from your system package manager\n"
              << "  (package is usually named 'zpaq': apt/dnf/pacman/apk/xbps)\n"
              << CLR_RESET;

    std::cout << "\n";
}

// ---------------------------------------------------------------------------
// init
// ---------------------------------------------------------------------------

static int cmdInit(const Opts& opts) {
    Logger::banner("initialising hetrix workspace");
    initWorkspace();
    Logger::ok("workspace: " + Utils::hetrixDir());
    Logger::blank();

    ConfigManager cm = makeCM(opts);
    if (opts.forceInit && Utils::exists(cm.getIndexPath())) {
        Logger::warn("--force set -- removing existing index.json.");
        Utils::rmrf(cm.getIndexPath());
    }
    if (!cm.initIndex()) { Logger::err("failed to set up index.json."); return 1; }

    // Create cfg.toml if it doesn't exist
    std::string cfgFile = configPath();
    if (!Utils::exists(cfgFile)) {
        if (saveConfigTemplate(cfgFile))
            Logger::ok("created: " + cfgFile);
        else
            Logger::warn("could not write " + cfgFile);
    } else {
        Logger::info("cfg.toml already exists -- left untouched.");
    }

    Logger::blank();
    Logger::info("index:     " + cm.getIndexPath());
    Logger::info("config:    " + cfgFile);
    Logger::info("bin:       " + Utils::binDir());
    Logger::info("workspace: " + Utils::workspaceDir());
    Logger::info("repos:     " + Utils::reposDir());
    Logger::blank();
    Logger::ok("done. edit your packages:");
    Logger::info("  hetrix index --edit");
    Logger::info("  hetrix configgy");
    return 0;
}

// ---------------------------------------------------------------------------
// list
// ---------------------------------------------------------------------------

static int cmdList(const Opts& opts) {
    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();
    auto idx = cm.load();
    if (idx.empty()) { Logger::warn("No packages. Edit: " + cm.getIndexPath()); return 0; }

    Logger::blank();
    std::cout << CLR_BOLD "  packages in index.json  (" << idx.size() << ")\n" CLR_RESET;
    Logger::divider();

    for (auto& [name, e] : idx) {
        auto installed = lm.find(name);
        std::cout << "  " CLR_BGREEN << name << CLR_RESET;
        if (installed) std::cout << "  " CLR_BGREEN NF_OK CLR_RESET;
        if (!e.description.empty())
            std::cout << CLR_DIM "  -- " << e.description << CLR_RESET;
        std::cout << "\n";
        std::cout << "    " CLR_DIM "url   " CLR_RESET
                  << (e.url.empty() ? "(local repo)" : e.url) << "\n";
        std::cout << "    " CLR_DIM "build " CLR_RESET << e.build;
        if (!e.pull_type.empty() && e.pull_type != "auto")
            std::cout << "  " CLR_DIM "pull=" CLR_RESET << e.pull_type;
        if (!e.version.empty())
            std::cout << "  " CLR_DIM "ver=" CLR_RESET << e.version;
        if (!e.args.empty())
            std::cout << "  " CLR_DIM "args=" CLR_RESET << e.args;
        if (installed)
            std::cout << "  " CLR_DIM "installed=" CLR_RESET << installed->version;
        std::cout << "\n\n";
    }
    return 0;
}

// ---------------------------------------------------------------------------
// installed  -- list entries in the lock file
// ---------------------------------------------------------------------------

static int cmdInstalled(const Opts& /*opts*/) {
    LockManager lm = makeLM();
    auto idx = lm.load();
    Logger::blank();
    std::cout << CLR_BOLD "  installed packages  (" << idx.size() << ")\n" CLR_RESET;
    Logger::divider();
    if (idx.empty()) {
        Logger::warn("No packages recorded yet. Install some with 'hetrix fetch'.");
        return 0;
    }
    for (auto& [name, e] : idx) {
        std::cout << "  " CLR_BGREEN << name << CLR_RESET
                  << "  " CLR_DIM "ver=" CLR_RESET << e.version
                  << "\n";
        std::cout << "    " CLR_DIM "binary     " CLR_RESET << e.binaryPath << "\n";
        std::cout << "    " CLR_DIM "installed  " CLR_RESET << e.installedAt << "\n\n";
    }
    return 0;
}

// ---------------------------------------------------------------------------
// search
// ---------------------------------------------------------------------------

static int cmdSearch(const Opts& opts) {
    if (opts.arg.empty()) { Logger::err("Usage: hetrix search <query>"); return 1; }
    ConfigManager cm = makeCM(opts);
    auto idx = cm.load();
    int found = 0;
    Logger::blank();
    std::cout << CLR_BOLD "  search results for '" << opts.arg << "':\n" CLR_RESET;
    Logger::divider();
    std::string q = opts.arg;
    // Case-insensitive search
    auto lower = [](std::string s) { for (auto& c : s) c = tolower(c); return s; };
    std::string ql = lower(q);
    for (auto& [name, e] : idx) {
        bool hit = lower(name).find(ql)        != std::string::npos
                || lower(e.url).find(ql)        != std::string::npos
                || lower(e.description).find(ql)!= std::string::npos;
        if (hit) {
            std::cout << "  " CLR_BGREEN << name << CLR_RESET
                      << "  " CLR_DIM << e.url << CLR_RESET "\n";
            if (!e.description.empty())
                std::cout << "    " << e.description << "\n";
            ++found;
        }
    }
    if (found == 0) Logger::warn("No matches for '" + q + "'.");
    std::cout << "\n";
    return 0;
}

// ---------------------------------------------------------------------------
// which
// ---------------------------------------------------------------------------

static int cmdWhich(const Opts& opts) {
    if (opts.arg.empty()) { Logger::err("Usage: hetrix which <package>"); return 1; }
    std::string target = Utils::installDir() + "/" + opts.arg;
    if (Utils::exists(target)) { std::cout << target << "\n"; return 0; }
    Logger::warn(opts.arg + " not found in " + Utils::installDir());
    return 1;
}

// ---------------------------------------------------------------------------
// remove
// ---------------------------------------------------------------------------

static int cmdRemove(const Opts& opts) {
    if (opts.arg.empty()) { Logger::err("Usage: hetrix remove <package>"); return 1; }
    Logger::banner("removing: " + opts.arg);

    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();

    std::string binDir = Utils::installDir();
    auto found = cm.find(opts.arg);
    std::string binName = (found && !found->output.empty()) ? found->output : opts.arg;
    std::string target  = binDir + "/" + binName;

    if (!Utils::exists(target)) target = binDir + "/" + opts.arg;

    if (!Utils::exists(target)) {
        Logger::warn("'" + opts.arg + "' not found in " + binDir);
        Logger::info("Use: hetrix which " + opts.arg + "  to check where it's installed.");
        return 1;
    }

    Logger::cleaning("removing " + target + " ...");
    try {
        fs::remove(target);
        Logger::ok("removed: " + target);
        lm.remove(opts.arg);  // purge lock entry
    } catch (const std::exception& ex) {
        Logger::err("failed to remove " + target + ": " + ex.what());
        return 1;
    }

    Logger::blank();
    Logger::info("To also clean workspace: hetrix clean " + opts.arg);
    return 0;
}

// ---------------------------------------------------------------------------
// index
// ---------------------------------------------------------------------------

static int cmdIndex(const Opts& opts) {
    ConfigManager cm = makeCM(opts);
    std::string path = cm.getIndexPath();
    std::cout << path << "\n";
    if (!opts.editIndex) return 0;

    // Determine editor: cfg.toml > $VISUAL > $EDITOR > well-known binaries
    std::string editor = gCfg.editor;
    if (editor.empty()) {
        const char* vis = std::getenv("VISUAL");
        const char* ed  = std::getenv("EDITOR");
        if (vis && vis[0]) editor = vis;
        else if (ed && ed[0]) editor = ed;
    }
    if (editor.empty()) {
        for (auto& e : {"micro", "hx", "helix", "nvim", "vim", "nano", "vi"})
            if (Utils::commandExists(e)) { editor = e; break; }
    }
    if (editor.empty()) {
        Logger::err("No editor found. Set 'editor' in cfg.toml or $EDITOR.");
        Logger::info("Edit manually: " + path);
        return 1;
    }
    Logger::info("opening with: " + editor);
    return std::system((editor + " " + path).c_str());
}

// ---------------------------------------------------------------------------
// config  -- show or edit cfg.toml
// ---------------------------------------------------------------------------

static int cmdConfig(const Opts& opts) {
    std::string path = configPath();

    if (!Utils::exists(path)) {
        Logger::warn("cfg.toml not found -- creating template at: " + path);
        if (!saveConfigTemplate(path)) {
            Logger::err("Failed to write cfg.toml.");
            return 1;
        }
        Logger::ok("created: " + path);
    }

    std::cout << CLR_BOLD "  cfg.toml: " CLR_RESET << path << "\n\n";

    auto printVal = [](const std::string& key, const std::string& val) {
        std::cout << "  " CLR_CYAN << key << CLR_RESET " = " CLR_DIM << val << CLR_RESET "\n";
    };
    auto printBool = [](const std::string& key, bool val) {
        std::cout << "  " CLR_CYAN << key << CLR_RESET " = "
                  << (val ? CLR_BGREEN "true" : CLR_DIM "false") << CLR_RESET "\n";
    };

    printVal ("editor",           gCfg.editor.empty() ? "(not set -- using $EDITOR)" : gCfg.editor);
    printBool("clean_after_build", gCfg.cleanAfterBuild);
    printVal ("parallel_jobs",    gCfg.parallelJobs == 0 ? "auto" : std::to_string(gCfg.parallelJobs));
    printBool("auto_move",        gCfg.autoMove);
    printBool("auto_keep",        gCfg.autoKeep);
    printVal ("remote_index",     gCfg.remoteIndex.empty() ? "(not set)" : gCfg.remoteIndex);
    if (!gCfg.dir.empty())       printVal("paths.dir",        gCfg.dir);
    if (!gCfg.bin.empty())       printVal("paths.bin",        gCfg.bin);
    if (!gCfg.workspace.empty()) printVal("paths.workspace",  gCfg.workspace);
    // [build]
    printBool("build.strip_binaries", gCfg.stripBinaries);
    // [default_args]
    auto defVal = [](const std::string& v, const std::string& builtin) {
        return v.empty() ? "(default: " + builtin + ")" : v;
    };
    printVal("default_args.gcc_def_args",      defVal(gCfg.defaultGccFlags,    "-O2 -Wall"));
    printVal("default_args.gpp_def_args",      defVal(gCfg.defaultGppFlags,    "-std=c++17 -O2 -Wall"));
    printVal("default_args.cmake_def_args",    defVal(gCfg.defaultCmakeArgs,   "-DCMAKE_BUILD_TYPE=Release"));
    printVal("default_args.cargo_def_args",    defVal(gCfg.defaultCargoFlags,  "--release"));
    printVal("default_args.zig_def_args",      defVal(gCfg.defaultZigOptimize, "-Doptimize=ReleaseSafe"));
    printVal("default_args.go_def_args",       defVal(gCfg.defaultGoFlags,     "(none)"));
    printVal("default_args.meson_def_args",    defVal(gCfg.defaultMesonArgs,   "(none)"));
    printVal("default_args.make_def_args",     defVal(gCfg.defaultMakeArgs,    "(none)"));
    printVal("default_args.autoconf_def_args", defVal(gCfg.defaultAutoconfArgs,"(none)"));
    printVal("default_args.node_def_args",     defVal(gCfg.defaultNodeFlags,   "(none)"));
    printVal("default_args.python_def_args",   defVal(gCfg.defaultPythonFlags, "(none)"));
    printVal("default_args.ruby_def_args",     defVal(gCfg.defaultRubyFlags,   "(none)"));
    printVal("default_args.dune_def_args",     defVal(gCfg.defaultDuneFlags,   "(none)"));
    printVal("default_args.bash_def_args",     defVal(gCfg.defaultBashArgs,    "(none)"));
    // [fetch]
    printVal ("fetch.git_depth",     gCfg.gitDepth == 0 ? "0 (full history)" : std::to_string(gCfg.gitDepth));
    printBool("fetch.git_submodules", gCfg.gitSubmodules);
    // [verify]
    printBool("verify.require_sha_for_curl", gCfg.requireShaForCurl);
    printBool("verify.warn_missing_sha",     gCfg.warnMissingSha);
    // [repos]
    printBool("repos.auto_compress",    gCfg.autoCompress);
    printVal ("repos.compression_level", std::to_string(gCfg.compressionLevel));

    if (!opts.editIndex) return 0;

    std::string editor = gCfg.editor;
    if (editor.empty()) {
        const char* vis = std::getenv("VISUAL");
        const char* ed  = std::getenv("EDITOR");
        if (vis && vis[0]) editor = vis;
        else if (ed && ed[0]) editor = ed;
    }
    if (editor.empty())
        for (auto& e : {"micro", "hx", "helix", "nvim", "vim", "nano", "vi"})
            if (Utils::commandExists(e)) { editor = e; break; }
    if (editor.empty()) {
        Logger::err("No editor found. Edit manually: " + path);
        return 1;
    }
    Logger::blank();
    Logger::info("opening with: " + editor);
    return std::system((editor + " " + path).c_str());
}

// ---------------------------------------------------------------------------
// clean
// ---------------------------------------------------------------------------

static int cmdClean(const Opts& opts) {
    std::string ws = Utils::workspaceDir();
    LockManager lm = makeLM();

    // helper: if a package's recorded binary lives inside wsDir, its install
    // was keep-in-place and the binary is now gone -- purge the lock entry.
    auto purgeStaleWsEntries = [&](const std::string& wsDir) {
        auto idx = lm.load();
        for (auto& [name, e] : idx) {
            // binaryPath starts with wsDir means it was kept in workspace
            if (e.binaryPath.rfind(wsDir, 0) == 0) {
                Logger::info("purging stale lock entry: " + name
                             + " (binary was in removed workspace)");
                lm.remove(name);
            }
        }
    };

    if (!opts.arg.empty()) {
        std::string target = ws + "/" + opts.arg;
        Logger::banner("cleaning workspace: " + opts.arg);
        if (!Utils::exists(target)) {
            Logger::info("Nothing to clean for '" + opts.arg + "'.");
            // still purge the lock entry if it references this workspace dir --
            // could be left over from a previous partial clean
            purgeStaleWsEntries(target);
            return 0;
        }
        Logger::cleaning("removing " + target + " ...");
        if (!Utils::rmrf(target)) {
            Logger::err("failed to remove " + target);
            return 1;
        }
        Logger::ok("cleaned!");
        purgeStaleWsEntries(target);
        return 0;
    }

    Logger::banner("cleaning entire workspace");
    if (!Utils::exists(ws)) { Logger::info("Workspace already clean: " + ws); return 0; }

    int count = 0;
    try {
        for (auto& entry : fs::directory_iterator(ws)) {
            Logger::cleaning("removing " + entry.path().string() + " ...");
            Utils::rmrf(entry.path().string());
            ++count;
        }
    } catch (const std::exception& ex) {
        Logger::err("clean failed: " + std::string(ex.what())); return 1;
    }

    Logger::blank();
    if (count == 0) {
        Logger::info("workspace was already empty.");
    } else {
        Logger::ok("workspace cleaned!");
        // purge all lock entries whose binary lives anywhere in the workspace
        purgeStaleWsEntries(ws);
    }
    return 0;
}

// ---------------------------------------------------------------------------
// status  -- check health of all installed packages
// ---------------------------------------------------------------------------

static int cmdStatus(const Opts& /*opts*/) {
    LockManager lm = makeLM();
    auto idx = lm.load();
    if (idx.empty()) {
        Logger::info("No packages in installed.json.");
        return 0;
    }

    Logger::banner("hetrix status");
    int ok = 0, missing = 0, gone = 0;
    std::string ws  = Utils::workspaceDir();
    std::string bin = Utils::installDir();

    for (auto& [name, e] : idx) {
        bool binExists = Utils::exists(e.binaryPath);
        bool inBin     = e.binaryPath.rfind(bin, 0) == 0;
        bool inWs      = e.binaryPath.rfind(ws,  0) == 0;

        if (binExists) {
            std::cout << CLR_BGREEN "  " NF_OK "  " CLR_RESET
                      << CLR_BOLD << name << CLR_RESET
                      << "  " CLR_DIM << e.version << CLR_RESET
                      << "\n";
            std::cout << CLR_DIM "       " << e.binaryPath << CLR_RESET "\n";
            ++ok;
        } else if (inWs) {
            // binary was kept in workspace and workspace has been cleaned
            std::cout << CLR_BYELLOW "  " NF_WARN "  " CLR_RESET
                      << CLR_BOLD << name << CLR_RESET
                      << CLR_YELLOW "  (workspace binary missing -- run: hetrix rebuild " << name << ")" CLR_RESET
                      << "\n";
            std::cout << CLR_DIM "       was: " << e.binaryPath << CLR_RESET "\n";
            ++missing;
        } else if (inBin) {
            std::cout << CLR_BRED "  " NF_ERR "  " CLR_RESET
                      << CLR_BOLD << name << CLR_RESET
                      << CLR_RED "  (binary missing from bin/ -- run: hetrix rebuild " << name << ")" CLR_RESET
                      << "\n";
            std::cout << CLR_DIM "       was: " << e.binaryPath << CLR_RESET "\n";
            ++gone;
        } else {
            // path is neither ws nor bin -- unusual, just check exists
            std::cout << CLR_BRED "  " NF_ERR "  " CLR_RESET
                      << CLR_BOLD << name << CLR_RESET
                      << CLR_RED "  (binary not found at recorded path)" CLR_RESET "\n";
            std::cout << CLR_DIM "       was: " << e.binaryPath << CLR_RESET "\n";
            ++gone;
        }
    }

    Logger::blank();
    Logger::info("ok: " + std::to_string(ok)
                 + "  missing: " + std::to_string(missing)
                 + "  broken: " + std::to_string(gone));
    return (missing + gone > 0) ? 1 : 0;
}

// ---------------------------------------------------------------------------
// info  -- show everything known about one package
// ---------------------------------------------------------------------------

static int cmdInfo(const Opts& opts) {
    if (opts.arg.empty()) {
        Logger::err("Usage: hetrix info <package>");
        return 1;
    }
    std::string name = opts.arg;
    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();

    auto entry    = cm.find(name);
    auto installed = lm.find(name);

    if (!entry && !installed) {
        Logger::err("'" + name + "' not found in index.json or installed.json.");
        return 1;
    }

    Logger::banner("info: " + name);

    auto field = [](const std::string& k, const std::string& v) {
        if (v.empty()) return;
        std::cout << "  " CLR_CYAN << std::left;
        int pad = 18 - (int)k.size();
        std::cout << k << CLR_RESET << std::string(pad > 0 ? pad : 1, ' ') << v << "\n";
    };
    auto bfield = [](const std::string& k, bool v) {
        std::cout << "  " CLR_CYAN << k << CLR_RESET "  "
                  << (v ? CLR_BGREEN "true" : CLR_DIM "false") << CLR_RESET "\n";
    };

    if (entry) {
        std::cout << CLR_BBLUE "  index.json\n" CLR_RESET;
        field("name",         entry->name);
        field("description",  entry->description);
        field("url",          entry->url);
        field("pull_type",    entry->pull_type);
        field("build",        entry->build);
        field("version",      entry->version);
        field("output",       entry->output);
        field("args",         entry->args);
        field("main",         entry->main_file);
        field("sub_dir",      entry->sub_dir);
        field("build_dir",    entry->build_dir);
        field("install_cmd",  entry->install_cmd);
        field("auto_add_cmds",entry->auto_add_cmds);
        field("sha256",       entry->sha256);
        field("sha512",       entry->sha512);
        if (entry->noExtraArgs) bfield("no_extra_args", true);
    }

    if (installed) {
        Logger::blank();
        std::cout << CLR_BBLUE "  installed.json\n" CLR_RESET;
        field("version",      installed->version);
        field("installed_at", installed->installedAt);
        field("binary",       installed->binaryPath);

        bool binOk = Utils::exists(installed->binaryPath);
        std::cout << "  " CLR_CYAN "binary status" CLR_RESET "  "
                  << (binOk ? CLR_BGREEN NF_OK " present" : CLR_BRED NF_ERR " missing")
                  << CLR_RESET "\n";

        std::string wsDir = Utils::workspaceDir() + "/" + name;
        bool wsOk = Utils::exists(wsDir);
        std::cout << "  " CLR_CYAN "workspace" CLR_RESET "     "
                  << (wsOk ? CLR_GREEN + wsDir : CLR_DIM "(cleaned)")
                  << CLR_RESET "\n";
    } else {
        Logger::blank();
        Logger::info(name + " is not installed.");
    }

    Logger::blank();
    return 0;
}

// ---------------------------------------------------------------------------
// export  -- dump installed packages as a minimal index.json fragment
// ---------------------------------------------------------------------------

static int cmdExport(const Opts& opts) {
    LockManager   lm = makeLM();
    ConfigManager cm = makeCM(opts);
    auto lockIdx = lm.load();
    if (lockIdx.empty()) {
        Logger::info("Nothing installed -- exported index is empty.");
    }

    Logger::banner("exporting installed packages");

    // build a JSON fragment containing only installed packages' index entries
    std::ostringstream ss;
    ss << "{\n";
    bool first = true;
    int count = 0;
    for (auto& [name, le] : lockIdx) {
        auto entry = cm.find(name);

        auto escStr = [](const std::string& s) {
            std::string r;
            for (char c : s) {
                if      (c == '"')  r += "\\\"";
                else if (c == '\\') r += "\\\\";
                else if (c == '\n') r += "\\n";
                else                r += c;
            }
            return r;
        };

        if (!first) ss << ",\n";
        first = false;
        ss << "  \"" << escStr(name) << "\": {\n";
        ss << "    \"version\": \""     << escStr(le.version) << "\",\n";
        if (entry) {
            if (!entry->url.empty())         ss << "    \"url\": \""          << escStr(entry->url)          << "\",\n";
            if (!entry->pull_type.empty())   ss << "    \"pull_type\": \""    << escStr(entry->pull_type)    << "\",\n";
            if (!entry->build.empty())       ss << "    \"build\": \""        << escStr(entry->build)        << "\",\n";
            if (!entry->args.empty())        ss << "    \"args\": \""         << escStr(entry->args)         << "\",\n";
            if (!entry->output.empty())      ss << "    \"output\": \""       << escStr(entry->output)       << "\",\n";
            if (!entry->sub_dir.empty())     ss << "    \"sub_dir\": \""      << escStr(entry->sub_dir)      << "\",\n";
            if (!entry->build_dir.empty())   ss << "    \"build_dir\": \""    << escStr(entry->build_dir)    << "\",\n";
            if (!entry->main_file.empty())   ss << "    \"main\": \""         << escStr(entry->main_file)    << "\",\n";
            if (!entry->install_cmd.empty()) ss << "    \"install_cmd\": \""  << escStr(entry->install_cmd)  << "\",\n";
            if (!entry->sha256.empty())      ss << "    \"sha256\": \""       << escStr(entry->sha256)       << "\",\n";
            if (!entry->sha512.empty())      ss << "    \"sha512\": \""       << escStr(entry->sha512)       << "\",\n";
            if (!entry->description.empty()) ss << "    \"description\": \""  << escStr(entry->description)  << "\",\n";
        }
        // auto_add_cmds = "1" so the binary gets moved to bin on reinstall
        ss << "    \"auto_add_cmds\": \"1\"\n";
        ss << "  }";
        ++count;
    }
    ss << "\n}\n";

    // decide output path
    std::string outPath;
    if (!opts.arg.empty()) {
        outPath = opts.arg;
    } else {
        outPath = Utils::hetrixDir() + "/export.json";
    }

    if (!Utils::writeFile(outPath, ss.str())) {
        Logger::err("Failed to write export file: " + outPath);
        return 1;
    }
    Logger::ok("exported " + std::to_string(count) + " package(s) to: " + outPath);
    Logger::info("To import on another machine:");
    Logger::info("  cp " + outPath + " ~/hetrix/index.json");
    Logger::info("  hetrix fetch --all");
    Logger::blank();
    return 0;
}

// ---------------------------------------------------------------------------
// fetch
// ---------------------------------------------------------------------------

static int cmdFetch(const Opts& opts) {
    // apply --jobs override to config
    if (opts.jobs > 0) gCfg.parallelPkgJobs = opts.jobs;

    // --all: fetch every package in index.json in parallel
    if (opts.all) {
        initWorkspace();
        ConfigManager cm = makeCM(opts);
        LockManager   lm = makeLM();
        auto idx = cm.load();
        if (idx.empty()) { Logger::warn("No packages in index.json."); return 0; }

        std::vector<PackageEntry> targets;
        for (auto& [name, entry] : idx)
            if (!entry.url.empty()) targets.push_back(entry);

        Logger::banner("fetching all " + std::to_string(targets.size()) + " packages");
        int total = (int)targets.size();
        Progress prog(total);
        int pkgJobs = std::max(1, gCfg.parallelPkgJobs);
        ThreadPool pool(std::min(pkgJobs, total));
        std::vector<std::future<Updater::JobResult>> futs;

        // reuse Updater's parallel job runner
        Updater up(cm, lm, Utils::workspaceDir(), Utils::installDir(), gCfg);
        bool forceMove = opts.forceMove || gCfg.autoMove;
        bool forceKeep = opts.forceKeep || gCfg.autoKeep;
        bool noClean   = opts.noClean   || !gCfg.cleanAfterBuild;

        int i = 1;
        for (auto& entry : targets) {
            prog.start(entry.name);
            int idx2 = i++;
            futs.push_back(pool.submit(
                [&up, entry, forceMove, forceKeep, noClean, idx2, total]() mutable {
                    return up.runParallelJob(entry, forceMove, forceKeep, noClean, idx2, total);
                }));
        }
        int ok = 0, failed = 0;
        for (auto& f : futs) {
            auto res = f.get();
            if (res.result == InstallResult::FAILED) { ++failed; prog.fail(res.name); }
            else                                     { ++ok;     prog.ok(res.name); }
        }
        Logger::blank();
        Logger::banner("fetch summary");
        Logger::info("fetched : " + std::to_string(ok));
        Logger::info("failed  : " + std::to_string(failed));
        return failed > 0 ? 1 : 0;
    }

    if (opts.arg.empty()) {
        Logger::err("Usage: hetrix fetch <package | user/repo | https://...>");
        Logger::info("       hetrix fetch --all   (fetch every package in index.json)");
        return 1;
    }
    initWorkspace();

    const std::string& pkgArg = opts.arg;
    std::string ws  = Utils::workspaceDir();
    std::string bin = Utils::installDir();

    PackageEntry entry;
    entry.name          = pkgArg;
    entry.build         = "auto";
    entry.output        = pkgArg;
    entry.pull_type     = "auto";
    entry.auto_add_cmds = "1";

    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();

    Logger::blank();
    std::cout << CLR_DIM "  searching index.json...\n" CLR_RESET;

    auto found = cm.find(pkgArg);
    if (found) {
        entry = *found;
        Logger::ok("found " CLR_BGREEN + entry.name + CLR_RESET " in index.json");
        if (!entry.description.empty()) Logger::detail(entry.description);
    } else {
        Logger::warn("'" + pkgArg + "' not in index.json -- treating as URL.");
        if (pkgArg.find('/') != std::string::npos
                && pkgArg.find("://") == std::string::npos) {
            entry.url    = "https://github.com/" + pkgArg;
            entry.name   = fs::path(pkgArg).filename().string();
            entry.output = entry.name;
            Logger::info("GitHub shorthand -> " + entry.url);
        } else if (pkgArg.find("://") != std::string::npos) {
            entry.url    = pkgArg;
            entry.name   = fs::path(pkgArg).stem().string();
            entry.output = entry.name;
        } else {
            Logger::err("Cannot resolve '" + pkgArg + "'. Add to index.json or supply a URL.");
            return 1;
        }
    }

    // Apply cfg.toml overrides for this session
    bool forceMove = opts.forceMove || gCfg.autoMove;
    bool forceKeep = opts.forceKeep || gCfg.autoKeep;
    bool noClean   = opts.noClean   || !gCfg.cleanAfterBuild;

    Logger::blank();

    // Step 1: Fetch
    Logger::banner("fetching source");
    Fetcher fetcher(entry, ws, gCfg);
    std::string srcDir = fetcher.fetch();
    if (srcDir.empty()) { Logger::err("fetch failed. aborting."); return 1; }
    Logger::ok("source ready: " + srcDir);
    Logger::blank();

    // Step 2: Build
    Logger::banner("building");
    Logger::info("running...");
    Logger::blank();

    Builder builder(srcDir, entry, gCfg);
    if (!builder.build()) {
        Logger::blank();
        Logger::err("build failed. source left at: " + srcDir);
        Logger::info("inspect and build manually if needed.");
        return 1;
    }

    // Step 3: Install
    Logger::banner("install");
    std::string ver = entry.version.empty() ? "(unknown)" : entry.version;
    bool installedSomewhere = false;

    if (!entry.install_cmd.empty()) {
        Installer inst(entry, bin, gCfg);
        inst.runCustomInstall(entry.install_cmd, srcDir);
        std::string binPath = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
        lm.record(entry.name, ver, binPath);
        installedSomewhere = true;
    } else {
        auto bins = builder.findBuiltBinaries();
        Logger::info("found " + std::to_string(bins.size()) + " executable(s).");
        Installer inst(entry, bin, gCfg);
        bool moved = inst.promptAndInstall(bins, srcDir, forceMove, forceKeep);

        if (moved) {
            // Copied to bin/ -- record and optionally clean workspace
            inst.printPathHint();
            std::string binPath = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
            lm.record(entry.name, ver, binPath);
            installedSomewhere = true;
            if (!noClean) {
                Logger::blank();
                Logger::banner("cleaning up");
                Logger::cleaning("removing workspace: " + srcDir + " ...");
                if (Utils::rmrf(srcDir)) Logger::ok("workspace cleaned!");
                else Logger::warn("could not fully clean workspace: " + srcDir);
            } else {
                Logger::blank();
                Logger::info("--no-clean: workspace kept at " + srcDir);
            }
        } else {
            // Kept in workspace -- still record so upgrade knows the version
            if (!bins.empty()) {
                lm.record(entry.name, ver, bins[0]);
                Logger::info("recorded in installed.json (kept in workspace).");
            }
            installedSomewhere = true;
            Logger::blank();
            Logger::info("workspace kept at " + srcDir);
        }
    }

    Logger::blank();
    std::cout << CLR_BGREEN "  " NF_OK " done!\n" CLR_RESET;
    Logger::blank();
    (void)installedSomewhere;
    return 0;
}

// ---------------------------------------------------------------------------
// upgrade
// ---------------------------------------------------------------------------

static int cmdUpgrade(const Opts& opts) {
    if (opts.jobs > 0) gCfg.parallelPkgJobs = opts.jobs;

    bool forceMove = opts.forceMove || gCfg.autoMove;
    bool forceKeep = opts.forceKeep || gCfg.autoKeep;
    bool noClean   = opts.noClean   || !gCfg.cleanAfterBuild;

    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();
    Updater up(cm, lm, Utils::workspaceDir(), Utils::installDir(), gCfg);

    initWorkspace();

    if (opts.all || opts.arg.empty()) {
        return up.upgradeAll(forceMove, forceKeep, noClean);
    }
    return up.upgrade(opts.arg, forceMove, forceKeep, noClean);
}

// ---------------------------------------------------------------------------
// rebuild
// ---------------------------------------------------------------------------

static int cmdRebuild(const Opts& opts) {
    if (opts.jobs > 0) gCfg.parallelPkgJobs = opts.jobs;

    bool forceMove = opts.forceMove || gCfg.autoMove;
    bool forceKeep = opts.forceKeep || gCfg.autoKeep;
    bool noClean   = opts.noClean   || !gCfg.cleanAfterBuild;

    initWorkspace();

    ConfigManager cm = makeCM(opts);
    LockManager   lm = makeLM();
    Updater up(cm, lm, Utils::workspaceDir(), Utils::installDir(), gCfg);

    if (opts.all) {
        return up.rebuildAll(forceMove, forceKeep, noClean);
    }
    if (opts.arg.empty()) {
        Logger::err("Usage: hetrix rebuild <package>  OR  hetrix rebuild --all");
        return 1;
    }
    return up.rebuild(opts.arg, forceMove, forceKeep, noClean);
}

// ---------------------------------------------------------------------------
// sync
// ---------------------------------------------------------------------------

static int cmdSync(const Opts& opts) {
    ConfigManager cm = makeCM(opts);
    std::string url = opts.remoteUrl.empty() ? gCfg.remoteIndex : opts.remoteUrl;
    Logger::banner("syncing index.json");
    return cm.syncRemote(url, opts.overwrite);
}

// ---------------------------------------------------------------------------
// configgy  -- find and exec configgy.sh, or open the interactive menu
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// zpaq  -- general-purpose zpaq compression/decompression
// ---------------------------------------------------------------------------

static int cmdZpaq(const Opts& opts) {
    const std::string& sub = opts.arg;

    if (sub == "compress" || sub == "c") {
        if (opts.extra.empty()) {
            Logger::err("Usage: hetrix zpaq compress <file|dir> [output.zpaq]");
            Logger::info("  If output path is omitted, <source>.zpaq is used.");
            return 1;
        }
        std::string source  = fs::absolute(opts.extra[0]).string();
        std::string archive = opts.extra.size() > 1
            ? opts.extra[1]
            : source + ".zpaq";
        return ZpaqManager::compress(source, archive, gCfg.compressionLevel) ? 0 : 1;

    } else if (sub == "extract" || sub == "x") {
        if (opts.extra.empty()) {
            Logger::err("Usage: hetrix zpaq extract <archive.zpaq> [dest-dir]");
            return 1;
        }
        std::string archive = fs::absolute(opts.extra[0]).string();
        std::string dest    = opts.extra.size() > 1
            ? opts.extra[1]
            : fs::path(archive).parent_path().string();
        return ZpaqManager::extract(archive, dest) ? 0 : 1;

    } else if (sub == "list" || sub == "l") {
        if (opts.extra.empty()) {
            Logger::err("Usage: hetrix zpaq list <archive.zpaq>");
            return 1;
        }
        return ZpaqManager::list(fs::absolute(opts.extra[0]).string()) ? 0 : 1;

    } else {
        Logger::banner("hetrix zpaq -- zpaq wrapper");
        Logger::info("subcommands:");
        Logger::info("  hetrix zpaq compress <file|dir> [out.zpaq]  -- compress a file or directory");
        Logger::info("  hetrix zpaq extract <archive.zpaq> [dir]    -- extract an archive");
        Logger::info("  hetrix zpaq list <archive.zpaq>             -- list archive contents");
        Logger::blank();
        Logger::info("compression level is set via [repos] compression_level in cfg.toml (1-5).");
        Logger::info("current level: " + std::to_string(gCfg.compressionLevel));
        if (!ZpaqManager::isAvailable())
            Logger::warn("zpaq is not installed. Install it with your system package manager (package name: zpaq)");
        return 0;
    }
}

// ---------------------------------------------------------------------------
// repos  -- manage ~/hetrix/repos/ local repo overrides
// ---------------------------------------------------------------------------

static int cmdRepos(const Opts& opts) {
    std::string reposDir = Utils::reposDir();
    const std::string& sub = opts.arg;

    if (sub.empty() || sub == "list") {
        // list all repos (both directories and .zpaq archives)
        Logger::banner("local repos: " + reposDir);
        if (!Utils::exists(reposDir)) {
            Logger::info("repos directory does not exist yet.");
            Logger::info("Create it with: mkdir -p " + reposDir);
            return 0;
        }
        int count = 0;
        for (auto& e : fs::directory_iterator(reposDir)) {
            std::string name = e.path().filename().string();
            if (e.is_directory()) {
                Logger::info("  [dir ] " + name);
                ++count;
            } else if (e.path().extension() == ".zpaq") {
                Logger::info("  [zpaq] " + name);
                ++count;
            }
        }
        if (count == 0) Logger::info("  (none)");
        Logger::blank();
        Logger::info("Local repos override remote URLs for matching package names.");
        Logger::info("Place source at: " + reposDir + "/<package-name>/");
        Logger::info("Or a zpaq archive: " + reposDir + "/<package-name>.zpaq");
        return 0;

    } else if (sub == "compress") {
        // compress one or all repos
        if (!ZpaqManager::require()) return 1;
        Utils::mkdirp(reposDir);
        bool all = opts.extra.empty();
        int ok = 0, fail = 0;

        for (auto& e : fs::directory_iterator(reposDir)) {
            if (!e.is_directory()) continue;
            std::string name    = e.path().filename().string();
            std::string repoDir = e.path().string();
            if (!all && name != opts.extra[0]) continue;

            Logger::blank();
            Logger::banner("compressing repo: " + name);
            bool r = ZpaqManager::compressRepo(repoDir, gCfg.compressionLevel,
                                               /*removeSource=*/true);
            if (r) ++ok; else ++fail;
        }
        if (ok + fail == 0) {
            if (all)
                Logger::info("No uncompressed repos found in " + reposDir);
            else
                Logger::err("Repo '" + opts.extra[0] + "' not found (uncompressed directory).");
        }
        Logger::blank();
        Logger::info("compressed: " + std::to_string(ok) + "  failed: " + std::to_string(fail));
        return fail > 0 ? 1 : 0;

    } else if (sub == "extract") {
        // extract one or all .zpaq repos
        if (!ZpaqManager::require()) return 1;
        Utils::mkdirp(reposDir);
        bool all = opts.extra.empty();
        int ok = 0, fail = 0;

        for (auto& e : fs::directory_iterator(reposDir)) {
            if (e.path().extension() != ".zpaq") continue;
            // stem = "myrepo"
            std::string name    = e.path().stem().string();
            std::string archive = e.path().string();
            if (!all && name != opts.extra[0]) continue;

            Logger::blank();
            Logger::banner("extracting repo: " + name);
            bool r = ZpaqManager::extractRepo(archive);
            if (r) ++ok; else ++fail;
        }
        if (ok + fail == 0) {
            if (all)
                Logger::info("No .zpaq archives found in " + reposDir);
            else
                Logger::err("Archive '" + opts.extra[0] + ".zpaq' not found.");
        }
        Logger::blank();
        Logger::info("extracted: " + std::to_string(ok) + "  failed: " + std::to_string(fail));
        return fail > 0 ? 1 : 0;

    } else {
        Logger::banner("hetrix repos -- local repo management");
        Logger::info("subcommands:");
        Logger::info("  hetrix repos list              -- list all local repos");
        Logger::info("  hetrix repos compress [name]   -- compress repo(s) to .zpaq");
        Logger::info("  hetrix repos extract  [name]   -- extract .zpaq repo(s)");
        Logger::blank();
        Logger::info("Repos live in: " + reposDir);
        Logger::info("A directory or .zpaq archive matching a package name overrides");
        Logger::info("that package's URL when running 'hetrix fetch'.");
        return 0;
    }
}


static int cmdConfiggy(const Opts& opts) {
    // Build the argument string for configgy.sh
    std::string subArgs;
    if (!opts.arg.empty()) subArgs += " " + opts.arg;
    for (auto& a : opts.extra) subArgs += " " + a;

    // Find configgy.sh: next to binary, then in hetrix dir, then in PATH
    std::string script;
    for (auto& dir : {Utils::selfDir(), Utils::hetrixDir()}) {
        if (dir.empty()) continue;
        std::string p = dir + "/configgy.sh";
        if (Utils::exists(p)) { script = p; break; }
    }
    // Fallback: look for it on PATH
    if (script.empty() && Utils::commandExists("hetrix-configgy"))
        script = "hetrix-configgy";

    if (script.empty()) {
        Logger::err("configgy.sh not found.");
        Logger::info("Expected next to hetrix binary or in ~/hetrix/.");
        Logger::info("Re-run hetrix.sh to reinstall.");
        return 1;
    }

    // Pass HETRIX_* env vars through so configgy.sh uses the same paths
    std::string cmd = "bash " + script + subArgs;
    return std::system(cmd.c_str());
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

int main(int argc, char* argv[]) {
    Logger::printMainBanner();

    // Load config early so path overrides apply before any Utils:: call
    gCfg = loadConfig(configPath());
    applyCfgPaths(gCfg);

    Opts opts = parseArgs(argc, argv);

    if (opts.command.empty() || opts.command == "help"
            || opts.command == "--help" || opts.command == "-h") {
        printHelp(argv[0]);
        return 0;
    }

    if (opts.command == "init")      return cmdInit(opts);
    if (opts.command == "list")      return cmdList(opts);
    if (opts.command == "installed") return cmdInstalled(opts);
    if (opts.command == "search")    return cmdSearch(opts);
    if (opts.command == "which")     return cmdWhich(opts);
    if (opts.command == "remove")    return cmdRemove(opts);
    if (opts.command == "index")     return cmdIndex(opts);
    if (opts.command == "config")    return cmdConfig(opts);
    if (opts.command == "clean")     return cmdClean(opts);
    if (opts.command == "status")    return cmdStatus(opts);
    if (opts.command == "info")      return cmdInfo(opts);
    if (opts.command == "export")    return cmdExport(opts);
    if (opts.command == "fetch")     return cmdFetch(opts);
    if (opts.command == "upgrade")   return cmdUpgrade(opts);
    if (opts.command == "rebuild")   return cmdRebuild(opts);
    if (opts.command == "sync")      return cmdSync(opts);
    if (opts.command == "configgy")  return cmdConfiggy(opts);
    if (opts.command == "zpaq")      return cmdZpaq(opts);
    if (opts.command == "repos")     return cmdRepos(opts);

    Logger::err("Unknown command: " + opts.command);
    Logger::info("Run: hetrix help");
    return 1;
}
