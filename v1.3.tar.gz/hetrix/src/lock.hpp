#pragma once
#include "utils.hpp"
#include "logger.hpp"
#include <string>
#include <map>
#include <optional>
#include <sstream>
#include <ctime>
#include <mutex>

// ---------------------------------------------------------------------------
// InstalledEntry  -- one row in the lock file
// ---------------------------------------------------------------------------

struct InstalledEntry {
    std::string version;        // git tag / commit that was installed
    std::string installedAt;    // ISO-8601 timestamp
    std::string binaryPath;     // absolute path to the installed binary
};

using LockIndex = std::map<std::string, InstalledEntry>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

namespace LockDetail {

inline std::string nowIso() {
    std::time_t t = std::time(nullptr);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", std::localtime(&t));
    return buf;
}

inline std::string escape(const std::string& s) {
    std::string r;
    for (char c : s) {
        if      (c == '"')  r += "\\\"";
        else if (c == '\\') r += "\\\\";
        else if (c == '\n') r += "\\n";
        else                r += c;
    }
    return r;
}

} // namespace LockDetail

// ---------------------------------------------------------------------------
// LockManager
// ---------------------------------------------------------------------------

class LockManager {
    std::string lockPath;

    static std::string defaultPath() {
        return Utils::hetrixDir() + "/installed.json";
    }

    // Minimal JSON parse -- same flat-object-of-objects approach as ConfigManager.
    LockIndex parse(const std::string& raw) const {
        LockIndex idx;
        // Simple state machine: find "pkgname": { ... }
        size_t pos = 0;
        auto skip = [&]() {
            while (pos < raw.size() && (std::isspace((unsigned char)raw[pos]) || raw[pos] == ','))
                ++pos;
        };
        auto readStr = [&]() -> std::string {
            if (pos >= raw.size() || raw[pos] != '"') return "";
            ++pos;
            std::string r;
            while (pos < raw.size() && raw[pos] != '"') {
                if (raw[pos] == '\\' && pos + 1 < raw.size()) { ++pos; }
                r += raw[pos++];
            }
            if (pos < raw.size()) ++pos; // closing "
            return r;
        };
        auto skipObj = [&]() {
            if (pos < raw.size() && raw[pos] == '{') ++pos;
            int depth = 1;
            while (pos < raw.size() && depth > 0) {
                if      (raw[pos] == '{') ++depth;
                else if (raw[pos] == '}') --depth;
                else if (raw[pos] == '"') { ++pos; while (pos < raw.size() && raw[pos] != '"') { if (raw[pos] == '\\') ++pos; ++pos; } }
                ++pos;
            }
        };

        skip();
        if (pos >= raw.size() || raw[pos] != '{') return idx;
        ++pos; // outer {

        while (true) {
            skip();
            if (pos >= raw.size() || raw[pos] == '}') break;
            if (raw[pos] != '"') { ++pos; continue; }

            std::string name = readStr();
            skip();
            if (pos < raw.size() && raw[pos] == ':') ++pos;
            skip();
            if (pos >= raw.size() || raw[pos] != '{') { skipObj(); continue; }
            ++pos; // inner {

            InstalledEntry e;
            while (true) {
                skip();
                if (pos >= raw.size() || raw[pos] == '}') { ++pos; break; }
                if (raw[pos] != '"') { ++pos; continue; }
                std::string key = readStr();
                skip();
                if (pos < raw.size() && raw[pos] == ':') ++pos;
                skip();
                std::string val = readStr();
                if      (key == "version")     e.version     = val;
                else if (key == "installed_at")e.installedAt = val;
                else if (key == "binary")      e.binaryPath  = val;
            }
            if (!name.empty()) idx[name] = e;
        }
        return idx;
    }

    std::string serialise(const LockIndex& idx) const {
        std::ostringstream ss;
        ss << "{\n";
        bool first = true;
        for (auto& [name, e] : idx) {
            if (!first) ss << ",\n";
            first = false;
            ss << "  \"" << LockDetail::escape(name) << "\": {\n";
            ss << "    \"version\":      \"" << LockDetail::escape(e.version)     << "\",\n";
            ss << "    \"installed_at\": \"" << LockDetail::escape(e.installedAt) << "\",\n";
            ss << "    \"binary\":       \"" << LockDetail::escape(e.binaryPath)  << "\"\n";
            ss << "  }";
        }
        ss << "\n}\n";
        return ss.str();
    }

public:
    explicit LockManager(const std::string& path = defaultPath())
        : lockPath(path) {}

    LockIndex load() const {
        if (!Utils::exists(lockPath)) return {};
        std::string raw = Utils::readFile(lockPath);
        if (raw.empty()) return {};
        try { return parse(raw); }
        catch (...) { return {}; }
    }

    bool save(const LockIndex& idx) const {
        return Utils::writeFile(lockPath, serialise(idx));
    }

    // Record a successful install.
    // Thread-safe: load→modify→save under a static mutex so parallel builds
    // don't clobber each other's entries.
    bool record(const std::string& name, const std::string& version,
                const std::string& binaryPath) {
        static std::mutex mtx;
        std::lock_guard<std::mutex> lk(mtx);
        auto idx = load();
        InstalledEntry e;
        e.version     = version;
        e.installedAt = LockDetail::nowIso();
        e.binaryPath  = binaryPath;
        idx[name] = e;
        return save(idx);
    }

    // Remove a package record (thread-safe).
    bool remove(const std::string& name) {
        static std::mutex mtx;
        std::lock_guard<std::mutex> lk(mtx);
        auto idx = load();
        idx.erase(name);
        return save(idx);
    }

    std::optional<InstalledEntry> find(const std::string& name) const {
        auto idx = load();
        auto it = idx.find(name);
        if (it == idx.end()) return std::nullopt;
        return it->second;
    }

    const std::string& getPath() const { return lockPath; }
};
