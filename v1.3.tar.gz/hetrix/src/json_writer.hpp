#pragma once
#include "config.hpp"
#include "utils.hpp"
#include <string>
#include <sstream>
#include <map>

// ---------------------------------------------------------------------------
// JsonWriter  -- serialize PackageIndex to well-formed JSON
// ---------------------------------------------------------------------------

namespace JsonWriter {

inline std::string escape(const std::string& s) {
    std::string r;
    r.reserve(s.size());
    for (unsigned char c : s) {
        switch (c) {
            case '"':  r += "\\\""; break;
            case '\\': r += "\\\\"; break;
            case '\n': r += "\\n";  break;
            case '\r': r += "\\r";  break;
            case '\t': r += "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    r += buf;
                } else {
                    r += (char)c;
                }
        }
    }
    return r;
}

// Emit a JSON string field if value is non-empty (or if force is true)
inline void field(std::ostringstream& ss, const std::string& indent,
                  const std::string& key, const std::string& val,
                  bool force = false, bool last = false) {
    if (!force && val.empty()) return;
    ss << indent << "\"" << escape(key) << "\": \"" << escape(val) << "\"";
    if (!last) ss << ",";
    ss << "\n";
}

// Serialise the full PackageIndex to a JSON string
inline std::string serialise(const PackageIndex& idx) {
    std::ostringstream ss;
    ss << "{\n";

    bool firstPkg = true;
    for (auto& [name, e] : idx) {
        if (!firstPkg) ss << ",\n";
        firstPkg = false;

        ss << "  \"" << escape(name) << "\": {\n";

        // Collect non-empty fields in canonical order
        std::vector<std::pair<std::string,std::string>> fields;
        auto maybe = [&](const std::string& k, const std::string& v) {
            if (!v.empty()) fields.push_back({k, v});
        };

        if (!e.url.empty())          fields.push_back({"url",           e.url});
        if (e.pull_type != "auto" && !e.pull_type.empty())
                                     fields.push_back({"pull_type",     e.pull_type});
        if (!e.version.empty())      fields.push_back({"version",       e.version});
        if (e.build != "auto" && !e.build.empty())
                                     fields.push_back({"build",         e.build});
        else if (e.build == "auto")  fields.push_back({"build",         "auto"});
        maybe("args",          e.args);
        maybe("main",          e.main_file);
        maybe("sub_dir",       e.sub_dir);
        maybe("build_dir",     e.build_dir);
        // output only if different from name
        if (!e.output.empty() && e.output != name)
                                     fields.push_back({"output",        e.output});
        maybe("install_cmd",   e.install_cmd);
        if (e.auto_add_cmds != "1" && !e.auto_add_cmds.empty())
                                     fields.push_back({"auto_add_cmds", e.auto_add_cmds});
        maybe("sha256",        e.sha256);
        maybe("sha512",        e.sha512);
        if (e.noExtraArgs) fields.push_back({"no_extra_args", "true"});
        maybe("description",   e.description);

        for (size_t i = 0; i < fields.size(); ++i) {
            bool last = (i == fields.size() - 1);
            ss << "    \"" << escape(fields[i].first) << "\": \""
               << escape(fields[i].second) << "\"";
            if (!last) ss << ",";
            ss << "\n";
        }

        ss << "  }";
    }

    ss << "\n}\n";
    return ss.str();
}

// Write PackageIndex to file atomically (write to tmp, then rename)
inline bool writeIndex(const std::string& path, const PackageIndex& idx) {
    std::string tmp = path + ".tmp";
    if (!Utils::writeFile(tmp, serialise(idx))) return false;
    try {
        std::filesystem::rename(tmp, path);
        return true;
    } catch (...) {
        std::filesystem::remove(tmp);
        return false;
    }
}

} // namespace JsonWriter
