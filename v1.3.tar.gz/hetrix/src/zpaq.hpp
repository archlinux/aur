#pragma once
#include "logger.hpp"
#include "utils.hpp"
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// ZpaqManager
// Wraps the 'zpaq' CLI tool. All compression/extraction runs from the
// directory containing the archive so stored paths are always relative --
// no absolute-path surprises on extraction.
// ---------------------------------------------------------------------------

class ZpaqManager {
public:
    static bool isAvailable() {
        return Utils::commandExists("zpaq");
    }

    static bool require() {
        if (!isAvailable()) {
            Logger::err("'zpaq' is not installed.");
            Logger::info("Install it with your system package manager (e.g. apt, dnf, pacman, apk, xbps-install).");
            Logger::info("Package name is usually: zpaq");
            return false;
        }
        return true;
    }

    // -----------------------------------------------------------------------
    // compress  -- compress a file or directory into a .zpaq archive.
    //
    //   source  : absolute path to a file or directory
    //   archive : absolute path to the output .zpaq (created or appended)
    //   level   : 1 (fast) to 5 (best)
    //   runDir  : working directory for the zpaq process
    //             defaults to the parent of source so stored paths are relative
    // -----------------------------------------------------------------------
    static bool compress(const std::string& source,
                         const std::string& archive,
                         int level = 5,
                         const std::string& runDir = "") {
        if (!require()) return false;
        if (!fs::exists(source)) {
            Logger::err("source not found: " + source);
            return false;
        }

        int lvl = std::min(5, std::max(1, level));

        // Compute relative paths from the run dir so the archive stores
        // portable relative paths rather than absolute ones.
        std::string wd = runDir.empty()
            ? fs::path(source).parent_path().string()
            : runDir;

        // Make archive path absolute so we can cd into wd safely.
        fs::path archiveAbs = fs::absolute(archive);
        fs::path sourceRel  = fs::relative(source, wd);

        Logger::info("compressing: " + source + " -> " + archiveAbs.string()
                     + "  [level " + std::to_string(lvl) + "]");
        Logger::info("please wait...");

        std::string cmd = "zpaq add " + archiveAbs.string()
                        + " " + sourceRel.string()
                        + " -m" + std::to_string(lvl);

        if (Utils::runCommand(cmd, wd) != 0) {
            Logger::err("zpaq compression failed.");
            return false;
        }
        Logger::ok("compressed: " + archiveAbs.string());
        return true;
    }

    // -----------------------------------------------------------------------
    // extract  -- extract a .zpaq archive.
    //
    //   archive : absolute path to the .zpaq file
    //   destDir : where to extract (the archive is always extracted here)
    //             defaults to the directory containing the archive
    // -----------------------------------------------------------------------
    static bool extract(const std::string& archive,
                        const std::string& destDir = "") {
        if (!require()) return false;
        if (!fs::exists(archive)) {
            Logger::err("archive not found: " + archive);
            return false;
        }

        std::string wd = destDir.empty()
            ? fs::path(archive).parent_path().string()
            : destDir;

        Utils::mkdirp(wd);

        fs::path archiveAbs = fs::absolute(archive);

        Logger::info("extracting: " + archiveAbs.string() + " -> " + wd);
        Logger::info("please wait...");

        std::string cmd = "zpaq extract " + archiveAbs.string();
        if (Utils::runCommand(cmd, wd) != 0) {
            Logger::err("zpaq extraction failed.");
            return false;
        }
        Logger::ok("extracted to: " + wd);
        return true;
    }

    // -----------------------------------------------------------------------
    // compressRepo  -- compress ~/hetrix/repos/<name>/ to <name>.zpaq
    //
    //   repoDir      : absolute path to the repo directory
    //   level        : 1-5
    //   removeSource : if true, delete the directory after successful compress
    // -----------------------------------------------------------------------
    static bool compressRepo(const std::string& repoDir,
                             int level = 5,
                             bool removeSource = false) {
        if (!require()) return false;
        if (!fs::exists(repoDir)) {
            Logger::err("repo not found: " + repoDir);
            return false;
        }

        // Archive lives alongside the directory: repos/myrepo.zpaq
        std::string archivePath = repoDir + ".zpaq";
        // Run from repos/ so stored paths are just "myrepo/..."
        std::string reposDir = fs::path(repoDir).parent_path().string();

        if (!compress(repoDir, archivePath, level, reposDir)) return false;

        if (removeSource) {
            Logger::cleaning("removing source directory: " + repoDir + " ...");
            Utils::rmrf(repoDir);
            Logger::ok("removed: " + repoDir);
        }
        return true;
    }

    // -----------------------------------------------------------------------
    // extractRepo  -- extract repos/<name>.zpaq back to repos/<name>/
    //
    //   archivePath : absolute path to <name>.zpaq in ~/hetrix/repos/
    // -----------------------------------------------------------------------
    static bool extractRepo(const std::string& archivePath) {
        if (!require()) return false;
        if (!fs::exists(archivePath)) {
            Logger::err("archive not found: " + archivePath);
            return false;
        }
        // Extract into the repos/ directory so relative paths restore correctly.
        std::string reposDir = fs::path(archivePath).parent_path().string();
        return extract(archivePath, reposDir);
    }

    // -----------------------------------------------------------------------
    // list  -- show files stored in a .zpaq archive
    // -----------------------------------------------------------------------
    static bool list(const std::string& archive) {
        if (!require()) return false;
        if (!fs::exists(archive)) {
            Logger::err("archive not found: " + archive);
            return false;
        }
        Logger::banner("archive: " + fs::path(archive).filename().string());
        return Utils::runCommand("zpaq list " + archive) == 0;
    }
};
