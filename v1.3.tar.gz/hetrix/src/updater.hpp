#pragma once
#include "cfg.hpp"
#include "config.hpp"
#include "config_manager.hpp"
#include "lock.hpp"
#include "logger.hpp"
#include "utils.hpp"
#include "fetcher.hpp"
#include "builder.hpp"
#include "installer.hpp"
#include "thread_pool.hpp"
#include "progress.hpp"
#include <string>
#include <optional>
#include <filesystem>
#include <future>
#include <vector>
#include <mutex>

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// Tri-state result of a fetch→build→install run.
// ---------------------------------------------------------------------------
enum class InstallResult { FAILED, MOVED_TO_BIN, KEPT_IN_PLACE };

// ---------------------------------------------------------------------------
// Updater  -- upgrade / rebuild packages (single and parallel --all)
// ---------------------------------------------------------------------------
class Updater {
    ConfigManager&      cm;
    LockManager&        lm;
    std::string         ws;
    std::string         bin;
    const HetrixConfig& cfg;

    // Fetch latest release tag from a git remote without cloning.
    std::string latestRemoteTag(const std::string& url) const {
        if (!Utils::commandExists("git")) return "";
        std::string out = Utils::captureCommand(
            "git ls-remote --tags --refs " + url + " 2>/dev/null"
            " | awk -F'/' '{print $NF}'"
            " | grep -E '^v?[0-9]+\\.[0-9]'"
            " | sort -V | tail -1");
        return Utils::trim(out);
    }

    // -----------------------------------------------------------------------
    // Core pipeline: fetch → build → install one package.
    //
    // logFile:  if non-empty, all subprocess output goes there instead of the
    //           terminal (used in parallel mode so outputs don't interleave).
    // -----------------------------------------------------------------------
    InstallResult doFetchBuildInstall(const PackageEntry& entry,
                                      bool forceMove, bool forceKeep, bool noClean,
                                      const std::string& logFile = "") {
        Logger::banner("fetching source: " + entry.name);
        Fetcher fetcher(entry, ws, cfg);
        if (!logFile.empty()) fetcher.setLogFile(logFile);

        std::string srcDir = fetcher.fetch();
        if (srcDir.empty()) { Logger::err("fetch failed."); return InstallResult::FAILED; }
        Logger::ok("source ready: " + srcDir);
        Logger::blank();

        Logger::banner("building: " + entry.name);
        Builder builder(srcDir, entry, cfg);
        if (!logFile.empty()) builder.setLogFile(logFile);
        if (!builder.build()) {
            Logger::err("build failed. source at: " + srcDir);
            return InstallResult::FAILED;
        }

        Logger::banner("installing: " + entry.name);
        std::string ver = entry.version.empty() ? "(unknown)" : entry.version;

        if (!entry.install_cmd.empty()) {
            Installer inst(entry, bin, cfg);
            inst.runCustomInstall(entry.install_cmd, srcDir);
            std::string binPath = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
            lm.record(entry.name, ver, binPath);
            return InstallResult::MOVED_TO_BIN;
        }

        auto bins = builder.findBuiltBinaries();
        Installer inst(entry, bin, cfg);
        bool moved = inst.promptAndInstall(bins, srcDir, forceMove, forceKeep);

        if (moved) {
            inst.printPathHint();
            std::string binPath = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
            lm.record(entry.name, ver, binPath);
            if (!noClean) {
                Logger::blank();
                Logger::cleaning("removing workspace: " + srcDir + " ...");
                Utils::rmrf(srcDir);
                Logger::ok("workspace cleaned.");
            }
            return InstallResult::MOVED_TO_BIN;
        } else {
            // kept in workspace -- still record so upgrade knows the version
            if (!bins.empty()) {
                lm.record(entry.name, ver, bins[0]);
                Logger::info("recorded in installed.json (kept in workspace).");
            }
            return InstallResult::KEPT_IN_PLACE;
        }
    }

    // -----------------------------------------------------------------------
    // Parallel worker: runs doFetchBuildInstall, captures all output to a
    // temp log file, and dumps it to stdout when done so builds from
    // different packages don't interleave.
    // -----------------------------------------------------------------------

public:
    // JobResult is also used by cmdFetch --all
    struct JobResult {
        std::string    name;
        InstallResult  result;
        std::string    logPath;
        std::string    version;
    };

    // Exposed so cmdFetch --all can drive it directly
    JobResult runParallelJob(const PackageEntry& entry,
                             bool forceMove, bool forceKeep, bool noClean,
                             int jobIdx, int total) {
        std::string logPath = ws + "/_hetrix_log_" + entry.name + ".txt";
        Utils::rmrf(logPath);

        auto result = doFetchBuildInstall(entry, forceMove, forceKeep, noClean, logPath);

        Logger::jobHeader(entry.name, jobIdx, total);
        std::string logContent = Utils::readFile(logPath);
        if (!logContent.empty()) {
            std::lock_guard<std::mutex> lk(Logger::_mtx());
            std::cout << logContent;
            std::cout.flush();
        }
        Utils::rmrf(logPath);

        return { entry.name, result, logPath, entry.version };
    }

    Updater(ConfigManager& cm_, LockManager& lm_,
            const std::string& wsDir, const std::string& binDir,
            const HetrixConfig& config)
        : cm(cm_), lm(lm_), ws(wsDir), bin(binDir), cfg(config) {}

    // -----------------------------------------------------------------------
    // upgrade  -- check remote for a newer version and rebuild if found.
    // -----------------------------------------------------------------------
    int upgrade(const std::string& pkgName,
                bool forceMove, bool forceKeep, bool noClean) {
        auto found = cm.find(pkgName);
        if (!found) {
            Logger::err("'" + pkgName + "' not found in index.json.");
            return 1;
        }
        PackageEntry entry = *found;
        Logger::banner("upgrade: " + pkgName);

        auto installed = lm.find(pkgName);
        if (!installed) {
            Logger::info(pkgName + ": not installed -- skipping. "
                         "(use 'hetrix fetch " + pkgName + "' to install)");
            return 0;
        }
        std::string installedVer = installed->version;
        Logger::info("installed version : " + (installedVer.empty() ? "(unknown)" : installedVer));

        std::string latestVer;
        if (!entry.url.empty() && entry.url.find("://") != std::string::npos) {
            Logger::info("querying remote for latest tag...");
            latestVer = latestRemoteTag(entry.url);
        }
        Logger::blank();

        if (latestVer.empty()) {
            Logger::warn("could not determine remote version for '" + pkgName + "'.");
            Logger::info("Skipping. Use 'hetrix rebuild " + pkgName + "' to force.");
            return 0;
        }
        Logger::info("latest remote tag : " + latestVer);

        if (!installedVer.empty() && installedVer != "(unknown)"
                && installedVer == latestVer) {
            Logger::ok(pkgName + " is already up to date (" + latestVer + ").");
            return 0;
        }
        if (!installedVer.empty() && installedVer != "(unknown)")
            Logger::ok("update available: " + installedVer + " -> " + latestVer);
        else
            Logger::ok("version was untracked -- upgrading to: " + latestVer);

        entry.version = latestVer;

        std::string oldBin = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
        if (Utils::exists(oldBin)) {
            Logger::cleaning("removing old binary: " + oldBin + " ...");
            Utils::rmrf(oldBin);
        }
        std::string oldWs = ws + "/" + entry.name;
        if (Utils::exists(oldWs)) {
            Logger::cleaning("removing stale workspace: " + oldWs + " ...");
            Utils::rmrf(oldWs);
        }

        auto result = doFetchBuildInstall(entry, forceMove, forceKeep, noClean);
        if (result != InstallResult::FAILED)
            Logger::ok("upgrade complete: " + pkgName + " @ " + latestVer);
        return (result == InstallResult::FAILED) ? 1 : 0;
    }

    // -----------------------------------------------------------------------
    // upgradeAll  -- parallel upgrade of all installed packages with a URL.
    // -----------------------------------------------------------------------
    int upgradeAll(bool forceMove, bool forceKeep, bool noClean) {
        auto idx = cm.load();
        if (idx.empty()) { Logger::warn("No packages in index.json."); return 0; }

        // pre-flight: which packages are installed and have a URL?
        auto lockIdx = lm.load();
        std::vector<std::pair<std::string, PackageEntry>> candidates;
        int noUrl = 0, notInstalled = 0;
        for (auto& [name, entry] : idx) {
            if (entry.url.empty())          { ++noUrl;          continue; }
            if (!lockIdx.count(name))       { ++notInstalled;   continue; }
            candidates.push_back({name, entry});
        }

        // phase 1: fetch latest tags in parallel (cheap network queries)
        Logger::banner("checking remote versions (" + std::to_string(candidates.size()) + " packages)");
        struct UpgradeCandidate {
            PackageEntry entry;
            std::string  installedVer;
            std::string  latestVer;
        };
        std::vector<UpgradeCandidate> toUpgrade;
        {
            int total = (int)candidates.size();
            Progress tagProg(total);
            int pkgJobCount = std::max(1, cfg.parallelPkgJobs);
            ThreadPool tagPool(std::min(pkgJobCount * 2, total > 0 ? total : 1));
            std::vector<std::future<UpgradeCandidate>> futs;
            int i = 0;
            for (auto& [name, entry] : candidates) {
                std::string installedVer = lockIdx.at(name).version;
                tagProg.start(name);
                futs.push_back(tagPool.submit([this, entry, installedVer, &tagProg]() mutable {
                    std::string latest;
                    if (entry.url.find("://") != std::string::npos)
                        latest = latestRemoteTag(entry.url);
                    if (latest.empty())
                        tagProg.skip(entry.name, "remote tag unknown");
                    else if (!installedVer.empty() && installedVer != "(unknown)"
                             && installedVer == latest)
                        tagProg.skip(entry.name, "already up to date @ " + latest);
                    else
                        tagProg.ok(entry.name, latest.empty() ? "" : installedVer + " -> " + latest);
                    return UpgradeCandidate{entry, installedVer, latest};
                }));
                ++i;
            }
            for (auto& f : futs) {
                auto uc = f.get();
                bool needsUpgrade = !uc.latestVer.empty()
                    && (uc.installedVer.empty() || uc.installedVer == "(unknown)"
                        || uc.installedVer != uc.latestVer);
                if (needsUpgrade) {
                    uc.entry.version = uc.latestVer;
                    toUpgrade.push_back(uc);
                }
            }
        }

        if (toUpgrade.empty()) {
            Logger::blank();
            Logger::ok("All packages are up to date.");
            Logger::blank();
            Logger::banner("upgrade summary");
            Logger::info("checked       : " + std::to_string(candidates.size()));
            Logger::info("not installed : " + std::to_string(notInstalled) + " (skipped)");
            Logger::info("no URL        : " + std::to_string(noUrl)          + " (skipped)");
            Logger::info("up to date    : " + std::to_string(candidates.size() - (int)toUpgrade.size()));
            return 0;
        }

        // phase 2: rebuild packages that need updating, in parallel
        Logger::banner("upgrading " + std::to_string(toUpgrade.size()) + " package(s)");
        int total = (int)toUpgrade.size();
        Progress buildProg(total);
        int pkgJobs = std::max(1, cfg.parallelPkgJobs);
        ThreadPool buildPool(std::min(pkgJobs, total));
        std::vector<std::future<JobResult>> futs;
        int i = 1;
        for (auto& uc : toUpgrade) {
            // clean up stale artifacts before queuing
            std::string oldBin = bin + "/" + (uc.entry.output.empty() ? uc.entry.name : uc.entry.output);
            if (Utils::exists(oldBin)) Utils::rmrf(oldBin);
            std::string oldWs  = ws  + "/" + uc.entry.name;
            if (Utils::exists(oldWs))  Utils::rmrf(oldWs);

            int idx2 = i++;
            buildProg.start(uc.entry.name);
            futs.push_back(buildPool.submit(
                [this, uc, forceMove, forceKeep, noClean, idx2, total]() mutable {
                    return runParallelJob(uc.entry, forceMove, forceKeep, noClean, idx2, total);
                }));
        }

        int upgraded = 0, failed = 0;
        for (auto& f : futs) {
            auto res = f.get();
            if (res.result == InstallResult::FAILED) {
                ++failed;
                buildProg.fail(res.name, "build failed");
            } else {
                ++upgraded;
                buildProg.ok(res.name, res.version);
            }
        }

        Logger::blank();
        Logger::banner("upgrade summary");
        Logger::info("checked       : " + std::to_string(idx.size()));
        Logger::info("not installed : " + std::to_string(notInstalled) + " (skipped)");
        Logger::info("no URL        : " + std::to_string(noUrl)          + " (skipped)");
        Logger::info("upgraded      : " + std::to_string(upgraded));
        Logger::info("failed        : " + std::to_string(failed));
        return failed > 0 ? 1 : 0;
    }

    // -----------------------------------------------------------------------
    // rebuild  -- unconditionally re-fetch, rebuild, and reinstall one pkg.
    // -----------------------------------------------------------------------
    int rebuild(const std::string& pkgName,
                bool forceMove, bool forceKeep, bool noClean) {
        auto found = cm.find(pkgName);
        if (!found) {
            Logger::err("'" + pkgName + "' not found in index.json.");
            return 1;
        }
        PackageEntry entry = *found;
        Logger::banner("rebuild: " + pkgName);

        std::string oldBin = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
        if (Utils::exists(oldBin)) {
            Logger::cleaning("removing old binary: " + oldBin + " ...");
            Utils::rmrf(oldBin);
        }
        std::string oldWs = ws + "/" + entry.name;
        if (Utils::exists(oldWs)) {
            Logger::cleaning("removing stale workspace: " + oldWs + " ...");
            Utils::rmrf(oldWs);
        }

        auto result = doFetchBuildInstall(entry, forceMove, forceKeep, noClean);
        if (result != InstallResult::FAILED) {
            Logger::blank();
            std::string suffix = (result == InstallResult::KEPT_IN_PLACE)
                ? " (kept in workspace)" : "";
            Logger::ok("rebuild complete: " + pkgName + suffix);
        }
        return (result == InstallResult::FAILED) ? 1 : 0;
    }

    // -----------------------------------------------------------------------
    // rebuildAll  -- parallel unconditional rebuild of all installed pkgs.
    // -----------------------------------------------------------------------
    int rebuildAll(bool forceMove, bool forceKeep, bool noClean) {
        auto lockIdx = lm.load();
        if (lockIdx.empty()) {
            Logger::warn("No packages installed (installed.json is empty).");
            return 0;
        }

        std::vector<PackageEntry> targets;
        int noIndex = 0;
        for (auto& [name, _] : lockIdx) {
            auto found = cm.find(name);
            if (!found) { ++noIndex; continue; }
            targets.push_back(*found);
        }

        Logger::banner("rebuilding " + std::to_string(targets.size()) + " package(s)");
        int total = (int)targets.size();
        Progress prog(total);
        int pkgJobs = std::max(1, cfg.parallelPkgJobs);
        ThreadPool pool(std::min(pkgJobs, total));
        std::vector<std::future<JobResult>> futs;
        int i = 1;
        for (auto& entry : targets) {
            std::string oldBin = bin + "/" + (entry.output.empty() ? entry.name : entry.output);
            if (Utils::exists(oldBin)) Utils::rmrf(oldBin);
            std::string oldWs  = ws  + "/" + entry.name;
            if (Utils::exists(oldWs))  Utils::rmrf(oldWs);

            int idx2 = i++;
            prog.start(entry.name);
            futs.push_back(pool.submit(
                [this, entry, forceMove, forceKeep, noClean, idx2, total]() mutable {
                    return runParallelJob(entry, forceMove, forceKeep, noClean, idx2, total);
                }));
        }

        int ok = 0, failed = 0;
        for (auto& f : futs) {
            auto res = f.get();
            if (res.result == InstallResult::FAILED) {
                ++failed;
                prog.fail(res.name, "build failed");
            } else {
                ++ok;
                prog.ok(res.name);
            }
        }

        Logger::blank();
        Logger::banner("rebuild summary");
        Logger::info("rebuilt  : " + std::to_string(ok));
        Logger::info("failed   : " + std::to_string(failed));
        if (noIndex > 0)
            Logger::warn(std::to_string(noIndex) + " installed package(s) not found in index.json (skipped)");
        return failed > 0 ? 1 : 0;
    }
};
