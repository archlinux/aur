#pragma once
#include "config.hpp"
#include "json_writer.hpp"
#include "logger.hpp"
#include "utils.hpp"
#include <string>
#include <map>
#include <optional>
#include <stdexcept>
#include <sstream>
#include <filesystem>
#include <unistd.h>

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// JsonParser  -- load index.json (hand-rolled, no external deps)
// Supports the flat string-value object subset plus bare true/false/numbers.
// ---------------------------------------------------------------------------

namespace JsonParser {

struct Token {
    enum Type { LBRACE, RBRACE, LBRACKET, RBRACKET, COLON, COMMA, STRING, END } type;
    std::string value;
};

class Lexer {
    const std::string& src;
    size_t pos = 0;
public:
    explicit Lexer(const std::string& s) : src(s) {}

    void skipWS() {
        while (pos < src.size() && std::isspace((unsigned char)src[pos])) ++pos;
        // skip // and # line comments
        if (pos + 1 < src.size() &&
            ((src[pos] == '/' && src[pos+1] == '/') || src[pos] == '#')) {
            while (pos < src.size() && src[pos] != '\n') ++pos;
            skipWS();
        }
    }

    std::string parseString() {
        ++pos; // skip opening "
        std::string r;
        while (pos < src.size() && src[pos] != '"') {
            if (src[pos] == '\\' && pos + 1 < src.size()) {
                ++pos;
                switch (src[pos]) {
                    case '"':  r += '"';  break;
                    case '\\': r += '\\'; break;
                    case '/':  r += '/';  break;
                    case 'n':  r += '\n'; break;
                    case 't':  r += '\t'; break;
                    case 'r':  r += '\r'; break;
                    default:   r += src[pos]; break;
                }
            } else {
                r += src[pos];
            }
            ++pos;
        }
        if (pos < src.size()) ++pos; // skip closing "
        return r;
    }

    Token next() {
        skipWS();
        if (pos >= src.size()) return {Token::END, ""};
        char c = src[pos];
        if (c == '{') { ++pos; return {Token::LBRACE,   ""}; }
        if (c == '}') { ++pos; return {Token::RBRACE,   ""}; }
        if (c == '[') { ++pos; return {Token::LBRACKET, ""}; }
        if (c == ']') { ++pos; return {Token::RBRACKET, ""}; }
        if (c == ':') { ++pos; return {Token::COLON,    ""}; }
        if (c == ',') { ++pos; return {Token::COMMA,    ""}; }
        if (c == '"') return {Token::STRING, parseString()};
        // bare value (null / true / false / number)
        std::string bare;
        while (pos < src.size() && src[pos] != ',' && src[pos] != '}'
               && src[pos] != ']' && src[pos] != '\n'
               && !std::isspace((unsigned char)src[pos]))
            bare += src[pos++];
        if (!bare.empty()) return {Token::STRING, bare};
        throw std::runtime_error(std::string("Unexpected char '") + c
                                 + "' at pos " + std::to_string(pos));
    }

    Token peek() { size_t s = pos; Token t = next(); pos = s; return t; }

    // Skip over an entire JSON value (object, array, or scalar).
    void skipValue() {
        skipWS();
        if (pos >= src.size()) return;
        if (src[pos] == '{') {
            next(); // {
            int depth = 1;
            while (depth > 0 && pos < src.size()) {
                auto t = next();
                if (t.type == Token::LBRACE)   ++depth;
                else if (t.type == Token::RBRACE) --depth;
                else if (t.type == Token::END) break;
            }
        } else if (src[pos] == '[') {
            next(); // [
            int depth = 1;
            while (depth > 0 && pos < src.size()) {
                auto t = next();
                if (t.type == Token::LBRACKET) ++depth;
                else if (t.type == Token::RBRACKET) --depth;
                else if (t.type == Token::END) break;
            }
        } else {
            next(); // scalar
        }
    }
};

inline std::map<std::string, std::string> parseObject(Lexer& lex) {
    std::map<std::string, std::string> obj;
    if (lex.next().type != Token::LBRACE)
        throw std::runtime_error("Expected '{'");
    while (true) {
        auto t = lex.peek();
        if (t.type == Token::RBRACE) { lex.next(); break; }
        if (t.type == Token::COMMA)  { lex.next(); continue; }
        auto key = lex.next();
        if (key.type != Token::STRING)
            throw std::runtime_error("Expected key string");
        if (lex.next().type != Token::COLON)
            throw std::runtime_error("Expected ':'");
        // Value might be a nested object/array -- skip gracefully
        auto vt = lex.peek();
        if (vt.type == Token::LBRACE || vt.type == Token::LBRACKET) {
            lex.skipValue();
            continue;
        }
        auto val = lex.next();
        if (val.type != Token::STRING)
            throw std::runtime_error("Expected value for key: " + key.value);
        obj[key.value] = val.value;
    }
    return obj;
}

inline PackageIndex parse(const std::string& json) {
    PackageIndex idx;
    Lexer lex(json);
    if (lex.next().type != Token::LBRACE)
        throw std::runtime_error("Expected top-level '{}'");

    while (true) {
        auto t = lex.peek();
        if (t.type == Token::RBRACE) { lex.next(); break; }
        if (t.type == Token::COMMA)  { lex.next(); continue; }
        if (t.type == Token::END)    break;
        auto name = lex.next();
        if (name.type != Token::STRING)
            throw std::runtime_error("Expected package name");
        if (lex.next().type != Token::COLON)
            throw std::runtime_error("Expected ':'");

        // Skip comment / section sentinel keys (start with _)
        if (name.value.empty() || name.value[0] == '_') {
            lex.skipValue();
            continue;
        }

        auto f = parseObject(lex);

        PackageEntry e;
        e.name          = name.value;
        e.url           = f.count("url")           ? f["url"]           : "";
        e.pull_type     = f.count("pull_type")     ? f["pull_type"]     : "auto";
        e.version       = f.count("version")       ? f["version"]       : "";
        e.build         = f.count("build")         ? f["build"]         : "auto";
        e.args          = f.count("args")          ? f["args"]          : "";
        e.main_file     = f.count("main")          ? f["main"]          : "";
        e.sub_dir       = f.count("sub_dir")       ? f["sub_dir"]       : "";
        e.build_dir     = f.count("build_dir")     ? f["build_dir"]     : "";
        e.output        = f.count("output")        ? f["output"]        : name.value;
        e.install_cmd   = f.count("install_cmd")   ? f["install_cmd"]   : "";
        e.auto_add_cmds = f.count("auto_add_cmds") ? f["auto_add_cmds"] : "1";
        e.sha256        = f.count("sha256")        ? f["sha256"]        : "";
        e.sha512        = f.count("sha512")        ? f["sha512"]        : "";
        e.noExtraArgs   = f.count("no_extra_args") ? (f["no_extra_args"] == "true" || f["no_extra_args"] == "1") : false;
        e.description   = f.count("description")  ? f["description"]   : "";

        idx[name.value] = e;
    }
    return idx;
}

} // namespace JsonParser

// ---------------------------------------------------------------------------
// ConfigManager  -- load, save, and sync index.json
// ---------------------------------------------------------------------------

class ConfigManager {
    std::string idxPath;

    std::string findSeedIndex() const {
        for (auto& dir : {Utils::selfDir(), fs::current_path().string()}) {
            if (dir.empty()) continue;
            std::string p = dir + "/index.json";
            if (Utils::exists(p) && p != idxPath) return p;
        }
        return "";
    }

    static std::string blankTemplate() {
        return R"({
  "_doc": "hetrix index.json  --  see README.md for all fields.",
  "_example": {
    "url":           "https://github.com/user/repo",
    "pull_type":     "auto",
    "build":         "auto",
    "args":          "",
    "sub_dir":       "",
    "output":        "binary-name",
    "version":       "",
    "auto_add_cmds": "1",
    "description":   "short description"
  }
}
)";
    }

public:
    explicit ConfigManager() : idxPath(Utils::indexPath()) {}

    // -----------------------------------------------------------------------
    // Load
    // -----------------------------------------------------------------------

    PackageIndex load() const {
        if (!Utils::exists(idxPath)) {
            Logger::warn("No index.json at " + idxPath + "  --  run: hetrix init");
            return {};
        }
        std::string raw = Utils::readFile(idxPath);
        if (raw.empty()) { Logger::warn("index.json is empty."); return {}; }
        try {
            return JsonParser::parse(raw);
        } catch (const std::exception& ex) {
            Logger::err("JSON parse error in " + idxPath);
            Logger::err("  " + std::string(ex.what()));
            Logger::info("Validate: python3 -m json.tool " + idxPath);
            return {};
        }
    }

    std::optional<PackageEntry> find(const std::string& name) const {
        auto idx = load();
        auto it  = idx.find(name);
        if (it == idx.end()) return std::nullopt;
        return it->second;
    }

    // -----------------------------------------------------------------------
    // Save  -- write PackageIndex back to index.json atomically
    // -----------------------------------------------------------------------

    bool save(const PackageIndex& idx) const {
        return JsonWriter::writeIndex(idxPath, idx);
    }

    // -----------------------------------------------------------------------
    // Init  -- create index.json if it doesn't exist
    // -----------------------------------------------------------------------

    bool initIndex() {
        if (Utils::exists(idxPath)) {
            Logger::info("index.json already exists -- left untouched.");
            Logger::info("Path: " + idxPath);
            return true;
        }
        std::string seed = findSeedIndex();
        if (!seed.empty()) {
            Logger::step("Seeding index.json from: " + seed);
            try {
                fs::copy_file(seed, idxPath, fs::copy_options::overwrite_existing);
                Logger::ok("Copied -> " + idxPath);
                return true;
            } catch (const std::exception& ex) {
                Logger::warn("Copy failed: " + std::string(ex.what()) + " -- writing template.");
            }
        }
        Logger::warn("No seed index.json found -- writing blank template.");
        bool ok = Utils::writeFile(idxPath, blankTemplate());
        if (ok) Logger::ok("Template written: " + idxPath);
        return ok;
    }

    // -----------------------------------------------------------------------
    // Sync  -- merge a remote index URL into the local index
    // overwrite=false: local entries win on conflict
    // overwrite=true : remote entries win on conflict
    // -----------------------------------------------------------------------

    int syncRemote(const std::string& url, bool overwrite) {
        if (url.empty()) {
            Logger::err("No remote_index URL configured.");
            Logger::info("Set 'remote_index' in ~/hetrix/cfg.toml  or pass --url <url>.");
            return 1;
        }

        if (!Utils::commandExists("curl")) {
            Logger::err("'curl' is required for sync.");
            return 1;
        }

        Logger::syncing("fetching remote index from: " + url);

        std::string tmpFile = Utils::hetrixDir() + "/.remote_index_tmp.json";
        int rc = Utils::runCommand("curl -fsSL --max-time 30 -o " + tmpFile + " " + url);
        if (rc != 0 || !Utils::exists(tmpFile)) {
            Logger::err("Failed to download remote index.");
            Utils::rmrf(tmpFile);
            return 1;
        }

        // Parse remote
        std::string remoteRaw = Utils::readFile(tmpFile);
        Utils::rmrf(tmpFile);

        PackageIndex remote;
        try {
            remote = JsonParser::parse(remoteRaw);
        } catch (const std::exception& ex) {
            Logger::err("Remote index JSON parse error: " + std::string(ex.what()));
            return 1;
        }

        Logger::ok("remote index: " + std::to_string(remote.size()) + " packages.");

        // Load local
        PackageIndex local = load();
        int added = 0, updated = 0, skipped = 0;

        for (auto& [name, re] : remote) {
            if (local.count(name)) {
                if (overwrite) {
                    local[name] = re;
                    ++updated;
                } else {
                    ++skipped;
                }
            } else {
                local[name] = re;
                ++added;
            }
        }

        if (!save(local)) {
            Logger::err("Failed to write merged index.json.");
            return 1;
        }

        Logger::blank();
        Logger::ok("sync complete.");
        Logger::info("added   : " + std::to_string(added));
        Logger::info("updated : " + std::to_string(updated));
        Logger::info("skipped : " + std::to_string(skipped)
                     + (overwrite ? "" : " (local wins -- use --overwrite to replace)"));
        return 0;
    }

    // -----------------------------------------------------------------------
    // Programmatic add / remove (used by 'hetrix configgy' C++ dispatch)
    // -----------------------------------------------------------------------

    bool addEntry(const PackageEntry& e) {
        auto idx = load();
        idx[e.name] = e;
        return save(idx);
    }

    bool removeEntry(const std::string& name) {
        auto idx = load();
        if (!idx.count(name)) {
            Logger::warn("'" + name + "' not in index.json.");
            return false;
        }
        idx.erase(name);
        return save(idx);
    }

    void setIndexPath(const std::string& p) { idxPath = p; }
    const std::string& getIndexPath() const  { return idxPath; }
};
