#pragma once
#include <string>
#include <map>

// ---------------------------------------------------------------------------
// PackageEntry  -- one package from index.json
// ---------------------------------------------------------------------------

struct PackageEntry {
    std::string name;

    // source
    std::string url;            // git URL, tarball URL, or direct binary URL
    std::string pull_type;      // "git" | "curl" | "auto"
    std::string version;        // git tag / branch to pin

    // build
    std::string build;          // cmake|make|gcc|g++|autoconf|meson|
                                // cargo|go|zig|dune|python|node|ruby|auto
    std::string args;           // extra flags for the compiler / build tool
    bool        noExtraArgs = false; // if true: pass ONLY args, no injected defaults ever
    std::string main_file;      // single-file gcc/g++ entry point ("main" key)
    std::string sub_dir;        // cd into this subdir before building
    std::string build_dir;      // override where to look for built binaries

    // output / install
    std::string output;         // binary name to produce  (default: package name)
    std::string install_cmd;    // shell command run instead of normal install flow
    std::string auto_add_cmds;  // "1" = prompt to move to bin (default)
                                // "0" = keep in workspace, skip prompt

    // verification
    std::string sha256;         // expected SHA-256 hex digest
                                //   curl: of downloaded archive/binary
                                //   git:  of 'git archive HEAD | sha256sum'
    std::string sha512;         // expected SHA-512 hex digest (same as above)

    // metadata
    std::string description;
};

// Full index: package-name -> entry
using PackageIndex = std::map<std::string, PackageEntry>;
