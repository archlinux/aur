#pragma once
#include <atomic>
#include <string>
#include <iostream>
#include <mutex>
#include <iomanip>

// ---------------------------------------------------------------------------
// Progress  -- thread-safe progress tracker for parallel --all operations
//
// Prints to stderr so it doesn't mix with stdout build output.
// Lines are colour-coded to match Logger style.
// ---------------------------------------------------------------------------

class Progress {
    std::atomic<int> done{0};
    int              total;
    std::mutex       mtx;

    // ansi codes
    static constexpr const char* RST  = "\033[0m";
    static constexpr const char* DIM  = "\033[2m";
    static constexpr const char* GRN  = "\033[1;32m";
    static constexpr const char* RED  = "\033[1;31m";
    static constexpr const char* YEL  = "\033[1;33m";
    static constexpr const char* CYN  = "\033[36m";

    // nerd font icons (nf-fa subset)
    static constexpr const char* ICON_OK  = "\xef\x80\x8c"; // 
    static constexpr const char* ICON_ERR = "\xef\x80\x8d"; // 
    static constexpr const char* ICON_COG = "\xef\x80\x93"; // 
    static constexpr const char* ICON_DOT = "\xef\x81\x94"; // 

    std::string bracket(int n) const {
        return std::string("[") + std::to_string(n) + "/" + std::to_string(total) + "]";
    }

public:
    explicit Progress(int n) : total(n) {}

    // call when a job starts -- shows a dim "pending" line
    void start(const std::string& pkg) {
        std::lock_guard<std::mutex> lk(mtx);
        std::cerr << DIM << "  [../" << total << "] " << ICON_COG << "  "
                  << pkg << "  (starting)" << RST << "\n";
    }

    // call when a job completes successfully
    void ok(const std::string& pkg, const std::string& note = "") {
        int n = ++done;
        std::lock_guard<std::mutex> lk(mtx);
        std::cerr << GRN << "  " << bracket(n) << " " << ICON_OK << "  "
                  << pkg;
        if (!note.empty()) std::cerr << "  " << RST << DIM << note;
        std::cerr << RST << "\n";
    }

    // call when a job fails
    void fail(const std::string& pkg, const std::string& reason = "") {
        int n = ++done;
        std::lock_guard<std::mutex> lk(mtx);
        std::cerr << RED << "  " << bracket(n) << " " << ICON_ERR << "  "
                  << pkg;
        if (!reason.empty()) std::cerr << "  " << RST << YEL << reason;
        std::cerr << RST << "\n";
    }

    // call when a job is skipped (not installed, no URL, etc.)
    void skip(const std::string& pkg, const std::string& reason = "") {
        int n = ++done;
        std::lock_guard<std::mutex> lk(mtx);
        std::cerr << CYN << "  " << bracket(n) << " " << ICON_DOT << "  "
                  << pkg;
        if (!reason.empty()) std::cerr << "  " << RST << DIM << reason;
        std::cerr << RST << "\n";
    }

    int getTotal() const { return total; }
};
