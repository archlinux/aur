#pragma once
#include "utils.hpp"
#include <fstream>
#include <sstream>
#include <string>

// ---------------------------------------------------------------------------
// HetrixConfig  -- loaded from ~/hetrix/cfg.toml
// Minimal TOML subset: [section], key = "value", key = true/false, key = N
// ---------------------------------------------------------------------------

struct HetrixConfig {
    // [general]
    std::string editor;
    bool        cleanAfterBuild = true;
    int         parallelJobs    = 0;       // 0 = nproc auto (make -j)
    int         parallelPkgJobs = 2;       // how many packages to build simultaneously

    // [install]
    bool autoMove = false;
    bool autoKeep = false;

    // [sync]
    std::string remoteIndex;

    // [paths]
    std::string dir;
    std::string bin;
    std::string workspace;

    // [build]  (legacy keys -- still parsed for backward compat)
    // [default_args]  (preferred section going forward)
    // empty string = use hetrix built-in defaults per build system
    std::string defaultCmakeArgs;          // cmake_def_args   default: "-DCMAKE_BUILD_TYPE=Release"
    std::string defaultCargoFlags;         // cargo_def_args   default: "--release"
    std::string defaultZigOptimize;        // zig_def_args     default: "-Doptimize=ReleaseSafe"
    std::string defaultGppFlags;           // gpp_def_args     default: "-std=c++17 -O2 -Wall"
    std::string defaultGccFlags;           // gcc_def_args     default: "-O2 -Wall"
    std::string defaultGoFlags;            // go_def_args      default: ""
    std::string defaultMesonArgs;          // meson_def_args   default: ""
    std::string defaultMakeArgs;           // make_def_args    default: ""
    std::string defaultAutoconfArgs;       // autoconf_def_args default: ""
    std::string defaultNodeFlags;          // node_def_args    default: ""
    std::string defaultPythonFlags;        // python_def_args  default: ""
    std::string defaultRubyFlags;          // ruby_def_args    default: ""
    std::string defaultDuneFlags;          // dune_def_args    default: ""
    std::string defaultBashArgs;           // bash_def_args    default: ""
    bool        stripBinaries = false;     // run 'strip' on installed ELF binaries

    // [fetch]
    int  gitDepth      = 1;                // --depth N for git clone; 0 = full history
    bool gitSubmodules = true;             // --recurse-submodules

    // [verify]
    bool requireShaForCurl = false;        // reject curl downloads without sha256/sha512
    bool warnMissingSha    = false;        // warn when any package has no sha set

    // [repos]
    bool autoCompress    = false;          // auto-compress local repos to .zpaq after use
    int  compressionLevel = 5;             // zpaq level 1 (fastest) to 5 (best)
};

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

namespace CfgDetail {

inline bool parseBool(const std::string& v) {
    return v == "true" || v == "1" || v == "yes";
}

inline std::string stripQuotes(const std::string& v) {
    if (v.size() >= 2 && v.front() == '"' && v.back() == '"')
        return v.substr(1, v.size() - 2);
    return v;
}

} // namespace CfgDetail

// ---------------------------------------------------------------------------
// Load
// ---------------------------------------------------------------------------

inline HetrixConfig loadConfig(const std::string& path) {
    HetrixConfig cfg;
    if (!Utils::exists(path)) return cfg;

    std::ifstream f(path);
    if (!f.is_open()) return cfg;

    std::string section, line;
    while (std::getline(f, line)) {
        std::string t = Utils::trim(line);
        if (t.empty() || t[0] == '#') continue;

        if (t[0] == '[') {
            auto end = t.find(']');
            if (end != std::string::npos)
                section = Utils::trim(t.substr(1, end - 1));
            continue;
        }

        auto eq = t.find('=');
        if (eq == std::string::npos) continue;

        std::string key = Utils::trim(t.substr(0, eq));
        std::string val = CfgDetail::stripQuotes(Utils::trim(t.substr(eq + 1)));
        // strip inline comment
        auto hash = val.find(" #");
        if (hash != std::string::npos) val = Utils::trim(val.substr(0, hash));

        if (section == "general") {
            if      (key == "editor")            cfg.editor          = val;
            else if (key == "clean_after_build") cfg.cleanAfterBuild = CfgDetail::parseBool(val);
            else if (key == "parallel_jobs")     cfg.parallelJobs    = val.empty() ? 0 : std::stoi(val);
            else if (key == "parallel_pkg_jobs") cfg.parallelPkgJobs = val.empty() ? 2 : std::stoi(val);
        } else if (section == "install") {
            if      (key == "auto_move")         cfg.autoMove = CfgDetail::parseBool(val);
            else if (key == "auto_keep")         cfg.autoKeep = CfgDetail::parseBool(val);
        } else if (section == "sync") {
            if      (key == "remote_index")      cfg.remoteIndex = val;
        } else if (section == "paths") {
            if      (key == "dir")               cfg.dir       = val;
            else if (key == "bin")               cfg.bin       = val;
            else if (key == "workspace")         cfg.workspace = val;
        } else if (section == "build") {
            // legacy [build] keys -- still parsed for backward compat
            if      (key == "default_cmake_args")   cfg.defaultCmakeArgs   = val;
            else if (key == "default_cargo_flags")  cfg.defaultCargoFlags  = val;
            else if (key == "default_zig_optimize") cfg.defaultZigOptimize = val;
            else if (key == "default_gpp_flags")    cfg.defaultGppFlags    = val;
            else if (key == "default_gcc_flags")    cfg.defaultGccFlags    = val;
            else if (key == "strip_binaries")       cfg.stripBinaries      = CfgDetail::parseBool(val);
        } else if (section == "default_args") {
            // preferred -- short intuitive names, one key per build system
            if      (key == "gcc_def_args")       cfg.defaultGccFlags    = val;
            else if (key == "gpp_def_args")       cfg.defaultGppFlags    = val;
            else if (key == "cmake_def_args")     cfg.defaultCmakeArgs   = val;
            else if (key == "cargo_def_args")     cfg.defaultCargoFlags  = val;
            else if (key == "zig_def_args")       cfg.defaultZigOptimize = val;
            else if (key == "go_def_args")        cfg.defaultGoFlags     = val;
            else if (key == "meson_def_args")     cfg.defaultMesonArgs   = val;
            else if (key == "make_def_args")      cfg.defaultMakeArgs    = val;
            else if (key == "autoconf_def_args")  cfg.defaultAutoconfArgs= val;
            else if (key == "node_def_args")      cfg.defaultNodeFlags   = val;
            else if (key == "python_def_args")    cfg.defaultPythonFlags = val;
            else if (key == "ruby_def_args")      cfg.defaultRubyFlags   = val;
            else if (key == "dune_def_args")      cfg.defaultDuneFlags   = val;
            else if (key == "bash_def_args")      cfg.defaultBashArgs    = val;
        } else if (section == "fetch") {
            if      (key == "git_depth")         cfg.gitDepth      = val.empty() ? 1 : std::stoi(val);
            else if (key == "git_submodules")    cfg.gitSubmodules = CfgDetail::parseBool(val);
        } else if (section == "verify") {
            if      (key == "require_sha_for_curl") cfg.requireShaForCurl = CfgDetail::parseBool(val);
            else if (key == "warn_missing_sha")     cfg.warnMissingSha    = CfgDetail::parseBool(val);
        } else if (section == "repos") {
            if      (key == "auto_compress")     cfg.autoCompress     = CfgDetail::parseBool(val);
            else if (key == "compression_level") cfg.compressionLevel = val.empty() ? 5 : std::stoi(val);
        }
    }
    return cfg;
}

// ---------------------------------------------------------------------------
// Save (write default template)
// ---------------------------------------------------------------------------

inline bool saveConfigTemplate(const std::string& path) {
    static constexpr const char* tmpl = R"(# hetrix configuration file
# Edit freely -- all fields are optional.
# ~/.hetrix/cfg.toml

[general]
# Preferred editor for 'hetrix index --edit'. Falls back to $EDITOR / $VISUAL.
# editor            = "micro"

# Remove build workspace after a successful install.
clean_after_build   = true

# Parallel jobs for make/cmake/ninja. 0 = auto (nproc).
parallel_jobs       = 0

# How many packages to build simultaneously with --all commands.
# e.g. 4 is a good starting point on a many-core CPU.
parallel_pkg_jobs   = 2


[install]
# Skip the "move to bin / keep in place" prompt.
# Only one of these should be true at a time.
auto_move           = false
auto_keep           = false


[sync]
# URL of a remote index.json to merge on 'hetrix sync'.
# remote_index      = "https://raw.githubusercontent.com/you/repo/main/index.json"
remote_index        = ""


[paths]
# Override default paths. Paths here take precedence over environment variables.
# dir               = "~/hetrix"
# bin               = "~/hetrix/bin"
# workspace         = "~/hetrix/workspace"


[build]
# Run 'strip' on installed ELF binaries to remove debug symbols / shrink size.
strip_binaries      = false


[default_args]
# Default arguments passed to each build tool when a package has no 'args'
# set in index.json, and 'no_extra_args' is not true.
#
# Great place to put:  -march=native -O3  for native-optimised builds,
# CPU tuning flags, sanitiser flags for dev builds, extra cmake defines, etc.
#
# Empty = hetrix uses its built-in safe defaults (shown in comments).
# Setting a key overrides the built-in default entirely for that tool.

# C / C++
# gcc_def_args     = "-O2 -Wall"
# gpp_def_args     = "-std=c++17 -O2 -Wall"

# Example: native optimised C/C++ (uncomment to enable):
# gcc_def_args     = "-O3 -march=native -pipe"
# gpp_def_args     = "-std=c++23 -O3 -march=native -pipe"

# CMake
# cmake_def_args   = "-DCMAKE_BUILD_TYPE=Release"

# Rust / Cargo
# cargo_def_args   = "--release"

# Zig
# zig_def_args     = "-Doptimize=ReleaseSafe"

# Go
# go_def_args      = ""

# Meson  (extra setup args, e.g. -Db_lto=true)
# meson_def_args   = ""

# Make  (extra variables, e.g. PREFIX=/usr/local)
# make_def_args    = ""

# Autoconf  (./configure extra args, e.g. --disable-nls)
# autoconf_def_args = ""

# Node.js
# node_def_args    = ""

# Python / pip
# python_def_args  = ""

# Ruby / gem
# ruby_def_args    = ""

# OCaml / Dune
# dune_def_args    = ""

# Bash install scripts
# bash_def_args    = ""


[fetch]
# Git clone depth. 1 = shallow clone (fastest). 0 = full history.
git_depth           = 1

# Clone submodules recursively (--recurse-submodules).
git_submodules      = true


[verify]
# Fail curl downloads that have no sha256 or sha512 set in index.json.
require_sha_for_curl = false

# Print a warning for any package that has no sha256/sha512 set.
warn_missing_sha    = false


[repos]
# Automatically compress local repos (~/hetrix/repos/<name>/) to .zpaq after
# a successful build. The directory is removed; .zpaq archive remains.
auto_compress       = false

# Zpaq compression level: 1 (fastest/largest) to 5 (slowest/smallest).
compression_level   = 5
)";
    return Utils::writeFile(path, tmpl);
}

inline std::string configPath() {
    return Utils::hetrixDir() + "/cfg.toml";
}
