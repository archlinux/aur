#pragma once
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <pwd.h>
#include <filesystem>
#include <sstream>
#include <fstream>
#include <iostream>

// NOTE: logger.hpp is NOT included here to avoid a circular dependency.
// Log calls inside utils fall back to stderr directly where needed.

namespace fs = std::filesystem;

namespace Utils {

// ---------------------------------------------------------------------------
// Path helpers
// ---------------------------------------------------------------------------

inline std::string homeDir() {
    const char* home = std::getenv("HOME");
    if (home && home[0] != '\0') return home;
    struct passwd* pw = getpwuid(getuid());
    return pw ? pw->pw_dir : "/tmp";
}

// Expand a leading ~/ to the real home directory.
inline std::string expandHome(const std::string& path) {
    if (path.size() >= 2 && path[0] == '~' && path[1] == '/')
        return homeDir() + path.substr(1);
    if (path == "~") return homeDir();
    return path;
}

inline std::string hetrixDir() {
    const char* env = std::getenv("HETRIX_DIR");
    if (env && env[0] != '\0') return expandHome(env);
    return homeDir() + "/hetrix";
}

inline std::string binDir() {
    const char* env = std::getenv("HETRIX_BIN");
    if (env && env[0] != '\0') return expandHome(env);
    return hetrixDir() + "/bin";
}

inline std::string workspaceDir() {
    const char* env = std::getenv("HETRIX_WORKSPACE");
    if (env && env[0] != '\0') return expandHome(env);
    return hetrixDir() + "/workspace";
}

inline std::string reposDir() {
    return hetrixDir() + "/repos";
}

inline std::string indexPath() {
    const char* env = std::getenv("HETRIX_INDEX");
    if (env && env[0] != '\0') return expandHome(env);
    return hetrixDir() + "/index.json";
}

// ---------------------------------------------------------------------------
// Identity
// ---------------------------------------------------------------------------

inline bool isRoot() {
    return getuid() == 0;
}

inline std::string installDir() {
    return isRoot() ? "/usr/local/bin" : binDir();
}

// ---------------------------------------------------------------------------
// Command availability check
// ---------------------------------------------------------------------------

inline bool commandExists(const std::string& cmd) {
    return std::system(("command -v " + cmd + " >/dev/null 2>&1").c_str()) == 0;
}

// ---------------------------------------------------------------------------
// Command execution
// ---------------------------------------------------------------------------

// Wrap a path in single quotes for safe shell interpolation.
inline std::string shellQuote(const std::string& s) {
    std::string r = "'";
    for (char c : s) {
        if (c == '\'') r += "'\\''";
        else            r += c;
    }
    r += "'";
    return r;
}

// Run with full output streaming (verbose).
inline int runCommand(const std::string& cmd, const std::string& workdir = "") {
    std::string full = workdir.empty() ? cmd : "cd " + shellQuote(workdir) + " && " + cmd;
    std::cerr << CLR_DIM "      $ " << cmd << CLR_RESET "\n";
    return std::system(full.c_str());
}

// Run and redirect all output (stdout+stderr) to a log file (appended).
// Also writes the "$ cmd" header to the log so the log is self-documenting.
inline int runCommandLogged(const std::string& cmd,
                             const std::string& workdir,
                             const std::string& logfile) {
    std::string full = workdir.empty() ? cmd : "cd " + shellQuote(workdir) + " && " + cmd;
    std::ofstream lf(logfile, std::ios::app);
    if (lf.is_open()) { lf << "$ " << full << "\n"; lf.close(); }
    std::string logged = full + " >>" + shellQuote(logfile) + " 2>&1";
    return std::system(logged.c_str());
}

// Run silently and capture stdout+stderr.
inline std::string captureCommand(const std::string& cmd) {
    std::string result;
    FILE* pipe = popen((cmd + " 2>&1").c_str(), "r");
    if (!pipe) return "";
    char buf[256];
    while (fgets(buf, sizeof(buf), pipe)) result += buf;
    pclose(pipe);
    return result;
}

// ---------------------------------------------------------------------------
// Filesystem helpers
// ---------------------------------------------------------------------------

inline bool mkdirp(const std::string& path) {
    try {
        fs::create_directories(path);
        return true;
    } catch (const std::exception& e) {
        std::cerr << "  mkdir failed: " << path << " — " << e.what() << "\n";
        return false;
    }
}

inline bool rmrf(const std::string& path) {
    try {
        if (fs::exists(path)) fs::remove_all(path);
        return true;
    } catch (const std::exception& e) {
        std::cerr << "  rmrf failed: " << path << " — " << e.what() << "\n";
        return false;
    }
}

inline bool exists(const std::string& path) {
    return fs::exists(path);
}

inline std::string readFile(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return "";
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

inline bool writeFile(const std::string& path, const std::string& content) {
    std::ofstream f(path);
    if (!f.is_open()) return false;
    f << content;
    return f.good();
}

// ---------------------------------------------------------------------------
// File search
// ---------------------------------------------------------------------------

inline std::vector<std::string> findFiles(const std::string& dir,
                                          const std::string& ext) {
    std::vector<std::string> result;
    if (!fs::exists(dir)) return result;
    for (auto& e : fs::recursive_directory_iterator(
             dir, fs::directory_options::skip_permission_denied)) {
        if (e.is_regular_file() && e.path().extension() == ext)
            result.push_back(e.path().string());
    }
    return result;
}

inline std::vector<std::string> findExecutables(const std::string& dir) {
    std::vector<std::string> result;
    if (!fs::exists(dir)) return result;
    for (auto& e : fs::recursive_directory_iterator(
             dir, fs::directory_options::skip_permission_denied)) {
        if (!e.is_regular_file()) continue;
        auto perms = e.status().permissions();
        if ((perms & fs::perms::owner_exec) == fs::perms::none) continue;
        std::string ext = e.path().extension();
        if (ext == ".sh" || ext == ".py" || ext == ".so" ||
            ext == ".a"  || ext == ".o"  || ext == ".la" ||
            ext == ".pc" || ext == ".cmake") continue;
        if (e.path().filename().string()[0] == '.') continue;
        result.push_back(e.path().string());
    }
    return result;
}

// ---------------------------------------------------------------------------
// String helpers
// ---------------------------------------------------------------------------

inline std::string trim(const std::string& s) {
    auto a = s.find_first_not_of(" \t\n\r");
    if (a == std::string::npos) return "";
    auto b = s.find_last_not_of(" \t\n\r");
    return s.substr(a, b - a + 1);
}

inline bool isOnPath(const std::string& dir) {
    const char* pathEnv = std::getenv("PATH");
    if (!pathEnv) return false;
    std::istringstream ss(pathEnv);
    std::string token;
    while (std::getline(ss, token, ':')) {
        if (token == dir) return true;
    }
    return false;
}

// Path of the running hetrix binary (via /proc/self/exe).
inline std::string selfDir() {
    char buf[4096] = {};
    if (::readlink("/proc/self/exe", buf, sizeof(buf) - 1) > 0)
        return fs::path(buf).parent_path().string();
    return "";
}

} // namespace Utils

// Bring colour macros into scope for utils.hpp users that don't include logger.hpp
#ifndef CLR_RESET
#  define CLR_RESET  "\033[0m"
#  define CLR_DIM    "\033[2m"
#endif
