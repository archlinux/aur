#pragma once
#include "cfg.hpp"
#include "config.hpp"
#include "logger.hpp"
#include "utils.hpp"
#include "zpaq.hpp"
#include <string>
#include <vector>
#include <filesystem>

namespace fs = std::filesystem;

// fetcher -- downloads source via git, curl, or local repo

class Fetcher {
    PackageEntry        pkg;
    std::string         workDir;
    const HetrixConfig& cfg;
    std::string         logFile; // empty = stream to terminal

    // run a command, routing output to logFile when set
    int run(const std::string& cmd, const std::string& wd = "") const {
        const std::string& workdir = wd.empty() ? workDir : wd;
        if (!logFile.empty())
            return Utils::runCommandLogged(cmd, workdir, logFile);
        return Utils::runCommand(cmd, workdir);
    }

    // -----------------------------------------------------------------------
    // SHA verification helpers
    // -----------------------------------------------------------------------

    // Verify a file against an expected hex digest.
    // algo: "sha256" or "sha512".
    bool verifySha(const std::string& filePath,
                   const std::string& algo,
                   const std::string& expected) const {
        if (expected.empty()) return true;

        std::string tool = algo + "sum";
        if (!Utils::commandExists(tool)) {
            Logger::warn(tool + " not found -- skipping checksum verification.");
            return true;
        }

        Logger::info("verifying " + algo + " checksum...");
        std::string captured = Utils::captureCommand(
            tool + " " + filePath + " 2>/dev/null");
        std::string actual = Utils::trim(captured.substr(0, captured.find(' ')));

        if (actual.empty()) {
            Logger::err("checksum tool returned empty output.");
            return false;
        }

        auto lower = [](std::string s){ for(auto& c:s) c=std::tolower((unsigned char)c); return s; };
        if (lower(actual) != lower(expected)) {
            Logger::err(algo + " mismatch!");
            Logger::err("  expected : " + expected);
            Logger::err("  actual   : " + actual);
            Logger::err("Download may be corrupt or tampered. Aborting.");
            return false;
        }
        Logger::ok(algo + " OK.");
        return true;
    }

    // Verify a git clone by hashing the tree via 'git archive HEAD | <algo>sum'.
    // This is deterministic -- git archive strips metadata, same tree = same hash.
    bool verifyGitSha(const std::string& cloneDir) const {
        if (pkg.sha256.empty() && pkg.sha512.empty()) return true;

        if (!Utils::commandExists("git")) {
            Logger::warn("git not available -- skipping git tree verification.");
            return true;
        }

        auto runGitHash = [&](const std::string& algo, const std::string& expected) -> bool {
            std::string tool = algo + "sum";
            if (!Utils::commandExists(tool)) {
                Logger::warn(tool + " not found -- skipping git tree " + algo + " check.");
                return true;
            }

            Logger::info("verifying git tree " + algo + "...");
            // pipe git archive HEAD through the hash tool; read only the hash token
            std::string actual = Utils::trim(Utils::captureCommand(
                "git -C " + cloneDir + " archive HEAD 2>/dev/null"
                " | " + tool + " 2>/dev/null"
                " | awk '{print $1}'"));

            if (actual.empty()) {
                Logger::err("git archive | " + tool + " produced empty output.");
                return false;
            }

            auto lower = [](std::string s){ for(auto& c:s) c=std::tolower((unsigned char)c); return s; };
            if (lower(actual) != lower(expected)) {
                Logger::err(algo + " mismatch on git tree!");
                Logger::err("  expected : " + expected);
                Logger::err("  actual   : " + actual);
                Logger::err("Clone may be corrupted or the wrong commit. Aborting.");
                return false;
            }
            Logger::ok(algo + " OK. (git tree)");
            return true;
        };

        if (!pkg.sha256.empty() && !runGitHash("sha256", pkg.sha256)) return false;
        if (!pkg.sha512.empty() && !runGitHash("sha512", pkg.sha512)) return false;
        return true;
    }

    // Warn or fail when SHA is missing, depending on cfg
    void checkShaMissing(bool isCurl) const {
        if (pkg.sha256.empty() && pkg.sha512.empty()) {
            if (isCurl && cfg.requireShaForCurl) {
                // caller must handle the false return
            }
            if (cfg.warnMissingSha) {
                Logger::warn("no sha256/sha512 set for '" + pkg.name + "' -- skipping verification.");
            }
        }
    }

    // -----------------------------------------------------------------------
    // URL classification
    // -----------------------------------------------------------------------

    bool looksLikeGit(const std::string& url) const {
        return url.find("github.com")    != std::string::npos
            || url.find("gitlab.com")    != std::string::npos
            || url.find("bitbucket.org") != std::string::npos
            || url.find("codeberg.org")  != std::string::npos
            || url.find("sr.ht")         != std::string::npos
            || url.find(".git")          != std::string::npos;
    }

    bool looksLikeArchive(const std::string& url) const {
        return url.find(".tar.gz")  != std::string::npos
            || url.find(".tgz")     != std::string::npos
            || url.find(".tar.bz2") != std::string::npos
            || url.find(".tar.xz")  != std::string::npos
            || url.find(".zip")     != std::string::npos;
    }

    // -----------------------------------------------------------------------
    // Version detection
    // -----------------------------------------------------------------------

    std::string detectLatestVersion(const std::string& url) const {
        if (!Utils::commandExists("git")) return "";
        std::string out = Utils::captureCommand(
            "git ls-remote --tags --refs " + url + " 2>/dev/null"
            " | awk -F'/' '{print $NF}'"
            " | grep -E '^v?[0-9]+\\.[0-9]'"
            " | sort -V | tail -1");
        return Utils::trim(out);
    }

    // -----------------------------------------------------------------------
    // Git clone
    // -----------------------------------------------------------------------

    bool fetchGit(const std::string& dest) {
        if (!Utils::commandExists("git")) {
            Logger::err("'git' is not installed. Install it and retry.");
            return false;
        }

        // Warn about missing sha if configured to do so
        checkShaMissing(false);

        std::string tag = pkg.version.empty() ? detectLatestVersion(pkg.url) : pkg.version;
        if (!tag.empty())
            Logger::info("version detected: " + tag);
        else
            Logger::info("no version tag found -- cloning default branch (HEAD).");

        Logger::fetching("cloning " + pkg.url + " ...");
        Logger::info("please wait...");
        Logger::blank();

        std::string cmd = "git clone";

        // submodules
        if (cfg.gitSubmodules)
            cmd += " --recurse-submodules";

        // --progress clutters log files with carriage-return progress bars
        if (logFile.empty())
            cmd += " --progress";

        // depth
        if (!tag.empty()) {
            cmd += " --branch " + tag;
            if (cfg.gitDepth > 0)
                cmd += " --depth " + std::to_string(cfg.gitDepth);
        } else {
            if (cfg.gitDepth > 0)
                cmd += " --depth " + std::to_string(cfg.gitDepth);
        }

        cmd += " " + pkg.url + " " + dest;

        if (run(cmd) != 0) {
            Logger::blank();
            Logger::err("git clone failed.");
            return false;
        }
        Logger::blank();
        Logger::ok("clone complete  ->  " + dest);

        // SHA verification against the cloned tree
        if (!verifyGitSha(dest)) {
            Logger::err("git tree verification failed -- removing clone.");
            Utils::rmrf(dest);
            return false;
        }

        return true;
    }

    // -----------------------------------------------------------------------
    // Curl download (archive or direct binary)
    // -----------------------------------------------------------------------

    bool fetchCurl(const std::string& dest) {
        if (!Utils::commandExists("curl")) {
            Logger::err("'curl' is not installed. Install it and retry.");
            return false;
        }

        // Enforce require_sha_for_curl before downloading anything
        if (cfg.requireShaForCurl && pkg.sha256.empty() && pkg.sha512.empty()) {
            Logger::err("require_sha_for_curl is set but '" + pkg.name
                        + "' has no sha256 or sha512 in index.json.");
            Logger::info("Add a sha256/sha512 field or disable require_sha_for_curl in cfg.toml.");
            return false;
        }

        checkShaMissing(true);

        const std::string& url = pkg.url;

        // direct binary (not an archive)
        if (!looksLikeArchive(url)) {
            Utils::mkdirp(dest);
            std::string outBin = dest + "/" + (pkg.output.empty() ? pkg.name : pkg.output);
            Logger::fetching("downloading binary: " + url);
            Logger::info("please wait...");
            Logger::blank();
            if (run("curl -L --progress-bar -o " + outBin + " " + url) != 0) {
                Logger::err("curl download failed."); return false;
            }
            Logger::blank();
            run("chmod +x " + outBin);
            Logger::ok("binary downloaded: " + outBin);
            if (!pkg.sha256.empty() && !verifySha(outBin, "sha256", pkg.sha256)) return false;
            if (!pkg.sha512.empty() && !verifySha(outBin, "sha512", pkg.sha512)) return false;
            return true;
        }

        // archive download
        Utils::mkdirp(dest);
        std::string archivePath = workDir + "/" + pkg.name + "_src";
        if      (url.find(".zip")     != std::string::npos) archivePath += ".zip";
        else if (url.find(".tar.gz")  != std::string::npos) archivePath += ".tar.gz";
        else if (url.find(".tgz")     != std::string::npos) archivePath += ".tgz";
        else if (url.find(".tar.bz2") != std::string::npos) archivePath += ".tar.bz2";
        else if (url.find(".tar.xz")  != std::string::npos) archivePath += ".tar.xz";
        else                                                  archivePath += ".tar.gz";

        Logger::fetching("downloading archive: " + url);
        Logger::info("please wait...");
        Logger::blank();

        if (run("curl -L --progress-bar -o " + archivePath + " " + url) != 0) {
            Logger::err("curl download failed."); return false;
        }
        Logger::blank();
        Logger::ok("download complete: " + archivePath);

        // Verify before extracting
        if (!pkg.sha256.empty() && !verifySha(archivePath, "sha256", pkg.sha256)) {
            Utils::rmrf(archivePath); return false;
        }
        if (!pkg.sha512.empty() && !verifySha(archivePath, "sha512", pkg.sha512)) {
            Utils::rmrf(archivePath); return false;
        }

        Logger::step("extracting...");
        std::string extractCmd;
        if (archivePath.find(".zip") != std::string::npos) {
            if (!Utils::commandExists("unzip")) {
                Logger::err("'unzip' not found."); return false;
            }
            extractCmd = "unzip -q " + archivePath + " -d " + dest + "_unzip"
                         " && mv " + dest + "_unzip/*/* " + dest + " 2>/dev/null"
                         " || mv " + dest + "_unzip/* "   + dest + " 2>/dev/null"
                         " ; rm -rf " + dest + "_unzip";
        } else {
            extractCmd = "tar -xf " + archivePath + " -C " + dest + " --strip-components=1";
        }
        if (run(extractCmd) != 0) {
            Logger::err("extraction failed."); return false;
        }
        Utils::rmrf(archivePath);
        Logger::ok("extraction complete.");
        return true;
    }

    // -----------------------------------------------------------------------
    // Local repo
    // Checks for plain directory first, then .zpaq archive.
    // If cfg.autoCompress is true, compresses the directory to .zpaq after use.
    // -----------------------------------------------------------------------

    bool fetchLocal(const std::string& src, const std::string& dest) {
        // check for an uncompressed directory
        bool hasDirSrc  = fs::exists(src);
        // check for a zpaq archive alongside it
        std::string zpaqPath = src + ".zpaq";
        bool hasZpaqSrc = fs::exists(zpaqPath);

        if (!hasDirSrc && !hasZpaqSrc) {
            Logger::err("Local repo not found: " + src);
            Logger::err("Tried: " + src + "  and  " + zpaqPath);
            return false;
        }

        // if only the zpaq exists, extract it first
        if (!hasDirSrc && hasZpaqSrc) {
            Logger::info("found local repo as .zpaq: " + zpaqPath);
            Logger::info("decompressing...");
            if (!ZpaqManager::extractRepo(zpaqPath)) {
                Logger::err("failed to extract local repo archive.");
                return false;
            }
            // the extraction should have restored the src directory
            if (!fs::exists(src)) {
                Logger::err("extraction succeeded but directory not found: " + src);
                return false;
            }
            hasDirSrc = true;
        } else if (hasDirSrc) {
            Logger::info("found local repo: " + src);
        }

        Logger::fetching("copying local source: " + src + " -> " + dest);
        try {
            fs::copy(src, dest, fs::copy_options::recursive);
            Logger::ok("local copy complete.");
        } catch (const std::exception& ex) {
            Logger::err("copy failed: " + std::string(ex.what()));
            return false;
        }

        // auto-compress: if directory exists and cfg says to, compress it now
        if (cfg.autoCompress && hasDirSrc && !hasZpaqSrc) {
            if (!ZpaqManager::isAvailable()) {
                Logger::warn("auto_compress is enabled but 'zpaq' is not installed -- skipping.");
            } else {
                Logger::info("auto_compress: compressing local repo to .zpaq...");
                bool ok = ZpaqManager::compressRepo(src, cfg.compressionLevel,
                                                    /*removeSource=*/true);
                if (ok)
                    Logger::ok("local repo compressed and original removed.");
                else
                    Logger::warn("auto_compress failed -- leaving directory as-is.");
            }
        }

        return true;
    }

public:
    Fetcher(const PackageEntry& entry,
            const std::string& wdir,
            const HetrixConfig& config)
        : pkg(entry), workDir(wdir), cfg(config) {}

    // when set, subprocess output goes to this file instead of the terminal
    void setLogFile(const std::string& path) { logFile = path; }

    // Returns destination directory path, or "" on failure.
    std::string fetch() {
        std::string dest = workDir + "/" + pkg.name;

        if (fs::exists(dest)) {
            Logger::warn("stale workspace dir found -- removing: " + dest);
            Utils::rmrf(dest);
        }

        // local repo override takes priority over any URL
        std::string localRepo     = Utils::reposDir() + "/" + pkg.name;
        std::string localRepoZpaq = localRepo + ".zpaq";

        if (fs::exists(localRepo) || fs::exists(localRepoZpaq)) {
            Logger::info("local repo override detected: " + localRepo);
            Utils::mkdirp(dest);
            return fetchLocal(localRepo, dest) ? dest : "";
        }

        if (pkg.url.empty()) {
            Logger::err("No URL for '" + pkg.name + "' and no local repo override.");
            return "";
        }

        // resolve pull_type
        std::string pt = pkg.pull_type;
        if (pt.empty() || pt == "auto")
            pt = looksLikeGit(pkg.url) ? "git" : "curl";

        Logger::info("pull_type: " + pt);

        if (pt == "git") {
            Logger::info("found " + pkg.name + " powered by git!");
            return fetchGit(dest) ? dest : "";
        }

        if (pt == "curl") {
            Logger::info("found " + pkg.name + " for curl download.");
            return fetchCurl(dest) ? dest : "";
        }

        Logger::err("Unknown pull_type '" + pt + "'.  Use: git | curl | auto");
        return "";
    }
};
