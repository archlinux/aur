#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include "colorlist.h"

#define ABS(x) ( ( (x) > 0  ) ? (x) : -(x))
#define NIJOU(x) ( (x) * (x) )
#define SGN(x) ((x < 0) ? -1 : ((x > 0) ? 1 : 0))
#define CHAR_NUM 7
#define XSIZE 480
#define YSIZE 576
#define SHOT_NUM 7
#define ENEMY_MAX 32
#define ENEMY_MISSILE 256
#define CSIZE 32
#define PRIVATE static
#define XMAP 15
#define YMAP 220
#define STPF 2
#define bzero(x,y) memset(x,0,y)
#define YARARETA 1
#define CLEAR_AREA 2
#define QUIT 4
#define GAMEOVER 8
#define TO_NEXT_AREA 16


#ifdef _MAIN
#define EXTERN
#else
#define EXTERN extern
#endif

enum {
      Up,
      Down,
      Left,
      Right,
      Ks,
      Kx,
      Kz,
      Kq,
      Kc,
      Exp,
      Kt,
      Ky,
      Ku
};

enum {
      JIKI,
      JIKI_L,
      JIKI_R,
      JIKITAMA
};

typedef union {
      short sht[2];
      int dummy;
} ZAHYOU;

typedef struct {
      short x,y;
      int size_x  , size_y;
      Pixmap pixmap;
      GC gc;
} CHAR_SET;

typedef struct {
      ZAHYOU x,y;
      int flag;
} SHOT;

typedef struct {
      ZAHYOU x,y;
      int z;
      int flag;
} SHOT_CHI;

typedef struct {
      ZAHYOU x,y;
      int vx,vy;
      int enemy_no;
      int tmp1;
      int tmp2;
      int tmp3;
} ENEMY;


EXTERN Display *d;
EXTERN Window w,sc_w;
EXTERN GC font_gc,back_gc,font_sgc;
EXTERN Visual *vis;
EXTERN int scr;/* screen no*/
EXTERN XEvent e;
EXTERN Colormap cmap;
EXTERN int depth;
EXTERN unsigned long pixel[COLORNUM];
EXTERN Font fnt;
EXTERN char mask[CHAR_NUM][128];
EXTERN ZAHYOU jx,jy;
EXTERN int char_set_no;
EXTERN SHOT shot[SHOT_NUM];
EXTERN SHOT_CHI shot_chi;
EXTERN CHAR_SET char_set[256];
EXTERN ENEMY enemy[ENEMY_MAX],enemy_chijou[ENEMY_MAX];
EXTERN int shojun_flag ,  scrl_cntr1 , scrl_ptr , score , nokori;
EXTERN unsigned char map[YMAP][XMAP];
EXTERN char tpath[256];
EXTERN int andoa_flag ,DRAWSTEP;
EXTERN int level , game_level;
EXTERN unsigned char rensha;
EXTERN int rev_key , ch_color;
EXTERN long cr_pixel;
EXTERN int domo_no , wait_tbl[11] , wait_val;




