#include "xev.h"
#include "enemy.h"

PRIVATE Pixmap pixmap,pixmap_mask;
PRIVATE GC gc;
PRIVATE char *fn = "spflag.img";

void SPFlagSetChar()
{
      char img[CSIZE*CSIZE] , mask[128];
      int x,y;
      XGCValues gcv;
      
      gcv.graphics_exposures = False;

      sprintf(tpath , "%s/%s",IMAGE_DIR,fn);
      LoadChar(tpath,img , sizeof(img));

      pixmap = XCreatePixmap(d,w,CSIZE,CSIZE,depth);
      gc = XCreateGC(d,w,GCGraphicsExposures,&gcv);
      bzero(mask , sizeof(mask));
      
      DrawChar32(img , mask , gc,pixmap);
      pixmap_mask 
	= XCreateBitmapFromData(d,w,mask,CSIZE,CSIZE);
      XSetClipMask(d,gc,pixmap_mask);
}


void SPFlagFree()
{
      XFreePixmap(d,pixmap);
      XFreePixmap(d,pixmap_mask);
      XFreeGC(d,gc);
}


int SPFlag(enemy_no)
     int enemy_no;
{
      int sx,sy;
      sx = enemy_chijou[enemy_no].x.sht[UNION];
      sy = enemy_chijou[enemy_no].y.sht[UNION];

      enemy_chijou[enemy_no].y.dummy += enemy_chijou[enemy_no].vy;

      if(enemy_chijou[enemy_no].tmp1) {
	    SetSprite(sx,sy,pixmap,gc,CSIZE,CSIZE);
      
	    if( (jx.sht[UNION] - sx) > -23 &&
	       (jx.sht[UNION] - sx) < 23 &&
	       (jy.sht[UNION] - sy) > -23 &&
	       (jy.sht[UNION] - sy) < 23) {
		  nokori++;
		  Score(nokori);
		  enemy_chijou[enemy_no].tmp1 = 0;
		  enemy_chijou[enemy_no].tmp2 = 1;
	    }
	    
      }
      
      if(!enemy_chijou[enemy_no].tmp2 && 
	 (shot_chi.x.sht[UNION] - sx) > -10 &&
         (shot_chi.x.sht[UNION] - sx) < 30 &&
         (shot_chi.y.sht[UNION] - sy) > -10 &&
         (shot_chi.y.sht[UNION] - sy) < 35 &&
	 shot_chi.z == 1) {
	    enemy_chijou[enemy_no].tmp1 = 1;
	    return 1;
      }
      return 0;
}

void SPFlagInit(enemy_no , x,char_no)
     int enemy_no , x,char_no;
{
      enemy_chijou[enemy_no].tmp1 = 0;
      enemy_chijou[enemy_no].tmp2 = 0;
      enemy_chijou[enemy_no].enemy_no  = char_no;
      enemy_chijou[enemy_no].x.dummy =  (rand() % (15*CSIZE))*65536;

      enemy_chijou[enemy_no].y.dummy = -32*65536 + (rand() % 20)*65536;
      enemy_chijou[enemy_no].vx = 0;
      enemy_chijou[enemy_no].vy = STPF*65536;
      
}



