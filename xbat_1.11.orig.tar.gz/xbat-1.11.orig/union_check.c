#include <stdio.h>

main()
{
      union {
	    int i;
	    short s[2];
      } uni;

      uni.i = 10;
      
      if(uni.s[0] == 10) { 
	    fprintf(stderr,"Set UNION 1.\n");
      }else{
	    fprintf(stderr,"Set UNION 0.\n");
      }
}
	
      
