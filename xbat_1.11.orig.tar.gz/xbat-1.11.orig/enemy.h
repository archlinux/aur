#define UMINO 6
#define BARA 17

enum {
      BOMB = 1,
      TOLOIDO,
      TALKEN,
      ZAKART,
      ZOSY = 5,
      BACURA,
      KAPI,
      TERAJI,
      ANDOA,
      CORE = 10,
      GIDO,
      GZAKART,
      GBZAKART,
      GEMINI,
      JARA = 15,
      SIO,
      BRAG,
      ZOSYB
};

enum {
      ROGRAM = 2,
      BARRA,
      ZORBAK,
      ATO,
      SOL = 6,
      GROBDD,
      GROBDS,
      SPFLAG,
      DOMOGRAM = 10,
      MIM,
      DELOTA,
      GDELOTA,
      BOZAROG,
      BONODORI = 15,
      GROBDU,
      GROBDDS,
      MSG
};

