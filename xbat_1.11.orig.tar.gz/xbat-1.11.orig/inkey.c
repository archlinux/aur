#include "xev.h"

PRIVATE int inkey = 0;

void KEClear()
{
      XEvent ev;

      while(XPending(d) > 0)
	XNextEvent(d,&ev);

      inkey = 0;
}

int CheckEvent()
{
      int i, k;
      KeySym ks;
      int oc_exp = 0,push_c = 0,push_s = 0 , push_q = 0, mask;
      
      while (XPending(d) > 0){
	    mask = 0;
	    XNextEvent(d, &e);
	    switch (e.type){
		case Expose:
		  oc_exp = (1<<Exp);
		  break;
		  
		case KeyRelease:
		  switch (XKeycodeToKeysym(d, e.xkey.keycode, 0)){
		      case XK_Up: 
		      case XK_KP_8:
		      case XK_i:
			mask = (1<<Up); break;
		      case XK_Down: 
		      case XK_KP_2:
		      case XK_KP_5:
		      case XK_k:
		      case XK_m:
			mask = (1<<Down); break;
		      case XK_Left: 
		      case XK_KP_4:
		      case XK_j:
			mask = (1<<Left); break;
		      case XK_Right: 
		      case XK_KP_6:
		      case XK_l:
			mask = (1<<Right); break;
		      case XK_x: mask = (rev_key)?(1<<Kx):(1<<Kz); break;
		      case XK_z: mask = (rev_key)?(1<<Kz):(1<<Kx); break;
		      case XK_s: push_s = (1<<Ks); break;
		    case XK_q: push_q = (1<<Kq); break;
		      case XK_c: push_c = (1<<Kc); break;
		  }
		  inkey &= ~mask;
		  break;
		case KeyPress:
		  switch (XKeycodeToKeysym(d, e.xkey.keycode, 0)){
		      case XK_Up: 
		      case XK_KP_8:
		      case XK_i:
			mask = (1<<Up); break;
		      case XK_Down: 
		      case XK_KP_2:
		      case XK_KP_5:
		      case XK_k:
		      case XK_m:
			mask = (1<<Down); break;
		      case XK_Left: 
		      case XK_KP_4:
		      case XK_j:
			mask = (1<<Left); break;
		      case XK_Right: 
		      case XK_KP_6:
		      case XK_l:
			mask = (1<<Right); break;
		      case XK_x: mask = (rev_key)?(1<<Kx):(1<<Kz); break;
		      case XK_z: mask = (rev_key)?(1<<Kz):(1<<Kx); break;
		  }
		  inkey |= mask;
		  break;
	    }
      }
      return inkey | push_s | push_q | push_c | oc_exp;
}



            


