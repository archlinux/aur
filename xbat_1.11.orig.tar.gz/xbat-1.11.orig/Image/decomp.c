#include <stdio.h>
#include <sys/stat.h>
#include <errno.h>

unsigned char *deimg;
unsigned char *dat;
struct stat buf; 

void SetChar(fn,size_x,size_y)
     char *fn;
     int *size_x,*size_y;
{
      int x, y, size_xy[2], size;
      FILE *fp;
      unsigned char s[2][4];
      
      if(stat(fn , &buf)) {
            perror("LoadChar");
            exit(1);
      }
      fprintf(stderr,"%s size %d\n",fn,(int)buf.st_size);
      if((dat = (unsigned char *)malloc((int)buf.st_size)) == NULL) {
            perror("LoadChar");
            exit(1);
      }
      
      if((fp = fopen(fn,"rb")) == NULL) {
            fprintf(stderr,"Open Error %s\n",fn);
	    exit(1);
      }
      /*
      if(fread(s , sizeof(s) , 1 ,fp) != 1) {
            fprintf(stderr,"Read Error");
            fclose(fp);
      }
      */
      *size_x = 32;/*(int)(s[0][2]*256+s[0][3]);*/
      *size_y = 32;/*(int)(s[1][2]*256+s[1][3]);*/
      size = *size_x * *size_y;

      if( (deimg = (unsigned char *)malloc(size)) == NULL) {
            fprintf(stderr,"malloc in Load ");
	    exit(1);
      }
      
      if(fread(dat , (int)buf.st_size , 1 ,fp)!=1) {
	    fprintf(stderr,"fread in Load");
	    free(dat);
	    fclose(fp);
	    exit(1);
      }
      fclose(fp);
      
}

void DRl(sx,sy)
     int sx,sy;
{
      unsigned char now_p;
      int x,i,length,c;
      int size = (int)buf.st_size;
      int j;
      c = 0;j=0;
      
      for(;size > 0; size-=2) {
            now_p = dat[c++];
            length = (int)dat[c++];
	    for(;length > 0 ; length--) {
                  deimg[j++] = now_p;
            }
      }
      free(dat);
}


void Out(fn,sx,sy)
     char *fn;
     int sx,sy;
{
      FILE *fp;
      unsigned char sc[2][4];
      
      memset(sc,0,sizeof(sc));
      
      fp = fopen(fn,"wb");
      sc[0][3] = sx&255;
      sc[0][2] = (sx>>8)&255;
      sc[1][3] = sy&255;
      sc[1][2] = (sy>>8)&255;
      
      /*fwrite(sc,sizeof(sc),1,fp);*/
      fwrite(deimg,sx*sy,1,fp);
      fclose(fp);
}

main(argc ,argv)
     int argc;
     char *argv[];

{
      int sx,sy,size;

      SetChar(argv[1],&sx,&sy);
      fprintf(stderr,"%d %d\n",sx,sy);
      DRl(sx,sy);
      fprintf(stderr,"out\n");
      Out(argv[2],sx,sy);
}
