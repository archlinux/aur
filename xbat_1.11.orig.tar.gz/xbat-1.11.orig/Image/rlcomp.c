#include <stdio.h>
#include <sys/stat.h>

unsigned char out[512*512];
unsigned char *dat;

void SetChar(fn,size_x,size_y)
     char *fn;
     int *size_x,*size_y;
{
      int x, y, size_xy[2], size;
      FILE *fp;
      unsigned char s[2][4];
      
      if((fp = fopen(fn,"rb")) == NULL) {
            fprintf(stderr,"Open Error %s\n",fn);
	    exit(1);
      }
      
      /*if(fread(s , sizeof(s) , 1 ,fp) != 1) {
            fprintf(stderr,"Read Error");
            fclose(fp);
      }*/
      
      *size_x = 32;
      *size_y = 32;
      size = *size_x * *size_y;
      
      if( (dat = (unsigned char *)malloc(size)) == NULL) {
            fprintf(stderr,"malloc in Load ");
	    exit(1);
      }
      
      if(fread(dat , size , 1 ,fp)!=1) {
	    fprintf(stderr,"fread in Load");
	    free(dat);
	    fclose(fp);
	    exit(1);
      }
      fclose(fp);
      
}

int Rl(sx,sy)
     int sx,sy;
{
      unsigned char now_p,cntr;
      int x,i;

      now_p = dat[0];
      cntr = 0;
      i = 0;

      for(x = 0 ; x < sx*sy ; x++) {
	    if(dat[x] != now_p || cntr == 255) {
		  out[i++] = now_p;
		  out[i++] = cntr;
		  now_p = dat[x];
		  cntr = 1;
	    } else {
		  cntr++;
	    }
      }
      out[i++] = now_p;
      out[i++] = cntr;

      return i;
}

void Out(fn,s,sx,sy)
     char *fn;
     int s,sx,sy;
{
      FILE *fp;
      unsigned char sc[2][4];

      fp = fopen(fn,"wb");
      memset(sc,0,sizeof(sc));
      
      sc[0][3] = sx&0xff;
      sc[0][2] = (sx>>8)&0xff;
      sc[1][3] = sy&0xff;
      sc[1][2] = (sy>>8)&0xff;
      
      /*fwrite(sc,sizeof(sc),1,fp);*/
      fwrite(out,s,1,fp);
      fclose(fp);
}

main(argc ,argv)
     int argc;
     char *argv[];

{
      int sx,sy,size;

      SetChar(argv[1],&sx,&sy);
      fprintf(stderr,"%d %d %d ",sx,sy,sx*sy);
      size = Rl(sx,sy);
      fprintf(stderr,"out %d\n",size);
      Out(argv[2],size,sx,sy);
}
