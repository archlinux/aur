#define _MAIN

#include "xev.h"
#include "back.h"

int map_y = 0;
int c_no = 0;

PRIVATE Pixmap pixmap[CHIJOU];
PRIVATE GC gc[CHIJOU];
PRIVATE char inkey = 0;

void MSetChar()
{
      int c_no;
      char img[CSIZE*CSIZE],mask[128];
      XGCValues gcv;

      gcv.graphics_exposures = True;

      for(c_no = 0 ; c_no < CHIJOU ; c_no++) {
            int x,y;



	    sprintf(tpath , "./Image/%s",fn[c_no]);

	    fprintf(stderr,"%d %s",c_no,tpath);

            LoadChar(tpath,img , sizeof(img));
	    fprintf(stderr,"lll");
	    
            pixmap[c_no] = XCreatePixmap(d,w,CSIZE,CSIZE,depth);
	    fprintf(stderr,"ppp");

            gc[c_no] = XCreateGC(d,w,GCGraphicsExposures,&gcv);
	    fprintf(stderr,"ggggg");

            DrawChar32(img , mask , gc[c_no],pixmap[c_no]);
	    fprintf(stderr,"mmmm\n");
      }
}

void Init()
{

      InitWin(1);
      MSetChar();
      fprintf(stderr,"mpa");
      memset(map , 1 , sizeof(map));
      map_y = YMAP - 18;
      XSetForeground(d,back_gc,pixel[41]);
      XDrawLine(d,w,back_gc,XSIZE+99,50,XSIZE+99,270);
}
      
void Inkey()
{
      int i, k;
      KeySym ks;
      char mask;
      
      
      while (XPending(d) > 0){
            mask = 0;
            XNextEvent(d, &e);
            switch (e.type){
		case KeyPress:
		case KeyRelease:
		  switch (XKeycodeToKeysym(d, e.xkey.keycode, 0)){
		      case XK_Up: 
		      case XK_KP_8:
		      case XK_i:
			mask = (1<<Up); break;
		      case XK_Down: 
		      case XK_KP_2:
		      case XK_KP_5:
		      case XK_k:
		      case XK_m:
			mask = (1<<Down); break;
		      case XK_Left: 
		      case XK_KP_4:
		      case XK_j:
			mask = (1<<Left); break;
		      case XK_Right: 
		      case XK_KP_6:
			mask = (1<<Right); break;
		      case XK_x: mask = (rev_key)?(1<<Kx):(1<<Kz); break;
		      case XK_z: mask = (rev_key)?(1<<Kz):(1<<Kx); break;
		      case XK_s: mask = (1<<Ks); break;
		      case XK_l: mask = (1<<Kq); break;
		  }
		  if (e.type == KeyPress) inkey |= mask;
		  else inkey &= ~mask;
		  break;
	    }
      }
}

void Save()
{
      char fn[256];
      FILE *fp;

      fprintf(stderr,"Input Save Filename ? ");
      fscanf(stdin,"%s",fn);
      
      if((fp = fopen(fn,"wb")) != NULL) {
	    if(fwrite(map ,sizeof(map),1,fp) != 1)
	      {
		    fprintf(stderr,"Write Error !!\n");
		    fclose(fp);
		    return;
	      }
	    fclose(fp);
      } else {
	    fprintf(stderr,"Error!\n");
      }
}

void Load()
{
      char fn[256];
      FILE *fp;
      
      fprintf(stderr,"Input Load Filename ? ");
      fscanf(stdin,"%s",fn);
      
      if((fp = fopen(fn,"rb")) != NULL) {
	    if(fread(map ,sizeof(map),1,fp) != 1)
	      {
		    fprintf(stderr,"Write Error !!\n");
		    fclose(fp);
		    return;
	      }
	    fclose(fp);
      }else{
	    fprintf(stderr,"Error!\n");
      }
}

void PutChar(x,y,s)
     int x,y,s;
{
      int px,py,wx,wy;

      wx = (x/32)*32;
      wy = (y/32)*32;

      for(py = wy ; py < wy+s*32 ; py+=32)
	for(px = wx ; px < wx+s*32 ; px+=32) {
	      if(px <  XSIZE && py < YSIZE) {
		    map[py/32+map_y][px/32] = c_no;
      
		    XCopyArea(d,pixmap[c_no],w,back_gc,0,0,CSIZE,CSIZE,px,py);
	      }
	}
      XFlush(d);
      u_sleep(30000);
}

void MPutChar(x,y)
     int x,y;
{
      int wx,wy;

      wx = (x/32)*32;
      wy = (y/32)*32;

      XCopyArea(d,pixmap[c_no],w,back_gc,0,0,CSIZE,CSIZE,wx,wy);
      XFlush(d);
      u_sleep(30000);
}


void DrawMap()
{
      int x,y;
      char msg[10];
      for(y = 0 ; y < 19 ; y++) 
	for(x = 0 ; x < XMAP ; x++) 
	  XCopyArea(d,pixmap[map[map_y+y][x]],w,back_gc,0,0,CSIZE,CSIZE,x*32,y*32);
      XSetForeground(d,back_gc,pixel[0]);
      XFillRectangle(d,w,back_gc,XSIZE+100,50,20,220);
      XFillRectangle(d,w,back_gc,XSIZE+20,450,200,50);
      
      XSetForeground(d,back_gc,pixel[41]);
      XDrawLine(d,w,back_gc,XSIZE+100,50+map_y,XSIZE+115,50+map_y);
      XSetForeground(d,font_gc,pixel[20]);
      sprintf(msg,"%d",map_y+1);
      XDrawString(d,w,font_gc,XSIZE+20,500,msg,10);
      for(x = 1 ; x < 15 ; x++)
	XDrawLine(d,w,font_gc,x*CSIZE,0,x*CSIZE,YSIZE);
      
      for(x = 0 ; x < 30 ; x++) {
	    char c[3];

	    sprintf(c,"%d",x);
	    XDrawString(d,w,font_gc,x*CSIZE/2,20,c , 2);
      }

      XFlush(d);
}

	  
main()
{
      Window r,child;
      int rx,ry;
      unsigned int mask;
      int mx,my;

      Init();
      fprintf(stderr,"jkjj");
      while(1)
        {
              u_sleep(30000);

              XQueryPointer(d,w,&r,&child,&rx,&ry,&mx,&my,&mask);
	      

	      Inkey();

	      switch(inkey&15) {
		  case 1:
		    if(map_y > 0) {
			  map_y--;
			  DrawMap();
			  u_sleep(10000);
		    }
		    break;
		  case 2:
		    if(map_y < YMAP - 18) {
			  map_y++;
			  DrawMap();
			  u_sleep(10000);
                    }
		    break;
	      }
	      
	      if(inkey & (1<<Right)) {
		    if(c_no < CHIJOU-1)
		      c_no++;
		    MPutChar(XSIZE,0);
		    fprintf(stderr,"%s ",fn[c_no]);
		    u_sleep(30000);
	      }
	      
	      if(inkey & (1<<Left)) {
                    if(c_no > 0)
		      c_no--;
		    fprintf(stderr,"%s ",fn[c_no]);

		    MPutChar(XSIZE,0);
		    u_sleep(30000);
              }

	      if(inkey & (1<<Kx)) {
                    if(c_no > 10)
		      c_no-=10;
		    fprintf(stderr,"%s ",fn[c_no]);

		    MPutChar(XSIZE,0);
		    u_sleep(30000);
	      }
	      
	      if(inkey & (1<<Kz)) {
                    if(c_no < CHIJOU-10)
                      c_no+=10;
                    fprintf(stderr,"%s ",fn[c_no]);

                    MPutChar(XSIZE,0);
                    u_sleep(30000);
              }


	      if(inkey & (1<<Ks)) {
		    Save();
              }
	      
	      if(inkey & (1<<Kq)) {
		    Load();
              }

	      if(mask == Button1Mask && mx < XSIZE && my < YSIZE)
		PutChar(mx,my,1);

	      /*if(inkey & (1<< Kx) && mx < XSIZE && my < YSIZE)
                PutChar(mx,my,1);*/

	      if(mask == Button2Mask && mx < XSIZE && my < YSIZE)
                PutChar(mx,my,2);

	      if(mask == Button3Mask && mx < XSIZE && my < YSIZE)
                PutChar(mx,my,4);

	}
}
	      
