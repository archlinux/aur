#include <stdio.h>


main(argc , argv)
     int argc;
     char *argv[];
{
      FILE *fp;
      int i;
      int f[100];
      char b[100];
      char fn[128];
      
      sprintf(fn,"domoX%s.txt",argv[1]);

      if( (fp = fopen(fn , "r")) == NULL){
	    fprintf(stderr,"open Error %s\n",fn);
	    exit(1);
      }
      
      for(i = 0 ; i < 100; i++) {
	    fscanf(fp , "%d",&f[i]);
	    b[i] = (char)f[i];
      }
      
      fclose(fp);

      sprintf(fn,"domoX%s.dat",argv[1]);

      if((fp = fopen(fn , "wb")) == NULL) {
	    fprintf(stderr,"open Error %s\n",fn);
            exit(1);
      }

      fwrite(b , sizeof(b) , 1 , fp);
      fclose(fp);
      
      sprintf(fn,"domoY%s.txt",argv[1]);

      if( (fp = fopen(fn , "r")) == NULL){
	    fprintf(stderr,"open Error %s\n",fn);
	    exit(1);
      }
      
      for(i = 0 ; i < 100; i++) {
	    fscanf(fp , "%d",&f[i]);
	    b[i] = (char)(f[i]+2);
      }
      
      fclose(fp);

      sprintf(fn,"domoY%s.dat",argv[1]);

      if((fp = fopen(fn , "wb")) == NULL) {
	    fprintf(stderr,"open Error %s\n",fn);
            exit(1);
      }

      fwrite(b , sizeof(b) , 1 , fp);
      fclose(fp);
}



