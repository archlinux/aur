#include "xev.h"
#include "enemy.h"

PRIVATE Pixmap pixmap,pixmap_mask;
PRIVATE GC gc;
PRIVATE int shot_p[5][3] = {
      {3,4,5},
      {4,6,8},
      {6,8,10},
      {8,12,16},
      {20,30,40}
};

PRIVATE int Gshot_p[5][3] = {
      {10,15,20},
      {25,35,50},
      {35,45,60},
      {55,65,80},
      {70,90,110}
};

PRIVATE char fn[] = "delota.img";

void DelotaSetChar()
{
      char img[CSIZE*CSIZE] , mask[128];
      XGCValues gcv;
      int x,y;
      
      gcv.graphics_exposures = False;
      sprintf(tpath , "%s/%s",IMAGE_DIR,fn);
      LoadChar(tpath,img , sizeof(img));
      pixmap = XCreatePixmap(d,w,CSIZE,CSIZE,depth);
      gc = XCreateGC(d,w,GCGraphicsExposures,&gcv);
      bzero(mask , sizeof(mask));
            
      DrawChar32(img , mask , gc,pixmap);
      pixmap_mask 
	= XCreateBitmapFromData(d,w,mask,CSIZE,CSIZE);
      XSetClipMask(d,gc,pixmap_mask);
}

void DelotaFree()
{
      XFreePixmap(d,pixmap);
      XFreePixmap(d,pixmap_mask);
      XFreeGC(d,gc);
}


int Delota(enemy_no)
     int enemy_no;
{
      int sx,sy;
      sx = enemy_chijou[enemy_no].x.sht[UNION];
      sy = enemy_chijou[enemy_no].y.sht[UNION];
      
      enemy_chijou[enemy_no].y.dummy += enemy_chijou[enemy_no].vy;
      if (!enemy_chijou[enemy_no].tmp1 && (rand() & 255) < 
	  shot_p[game_level][level]) 
	EShut(enemy_no,enemy_chijou[enemy_no].x.dummy+16*65536
              ,enemy_chijou[enemy_no].y.dummy+16*65536);

      SetSprite(sx,sy+2,pixmap,gc,CSIZE,CSIZE);
      
      if(sy > YSIZE) {
            enemy_chijou[enemy_no].enemy_no = 0;
      }
      if((jx.sht[UNION] - sx) > -20 &&
         (jx.sht[UNION] - sx) < 20 &&
         (jy.sht[UNION] - sy) > 192 &&
         (jy.sht[UNION] - sy) < 224)
        shojun_flag = 1;

      if(shot_chi.z == 1) {
	    if((shot_chi.x.sht[UNION] - sx) > -10 &&
	       (shot_chi.x.sht[UNION] - sx) < 32 &&
	       (shot_chi.y.sht[UNION] - sy) > -10 &&
	       (shot_chi.y.sht[UNION] - sy) < 42 ) {
		  BombCInit(enemy_no);
		  score += 1000;
		  return 1;
	    }
      }else
        return 0;
}

int GDelota(enemy_no)
     int enemy_no;
{
      int sx,sy;
      sx = enemy_chijou[enemy_no].x.sht[UNION];
      sy = enemy_chijou[enemy_no].y.sht[UNION];
      enemy_chijou[enemy_no].tmp3 = 0;
      
      enemy_chijou[enemy_no].y.dummy += enemy_chijou[enemy_no].vy;
      if (!enemy_chijou[enemy_no].tmp1 && (rand() & 255) 
	  < Gshot_p[game_level][level]) 
	EShut(enemy_no,enemy_chijou[enemy_no].x.dummy+16*65536
              ,enemy_chijou[enemy_no].y.dummy+16*65536);

      SetSprite(sx,sy+2,pixmap,gc,CSIZE,CSIZE);
      
      if(sy > YSIZE) {
            enemy_chijou[enemy_no].enemy_no = 0;
      }
      if((jx.sht[UNION] - sx) > -20 &&
         (jx.sht[UNION] - sx) < 20 &&
         (jy.sht[UNION] - sy) > 192 &&
         (jy.sht[UNION] - sy) < 224)
        shojun_flag = 1;
 
      if(shot_chi.z == 1) {
	    if((shot_chi.x.sht[UNION] - sx) > -10 &&
	       (shot_chi.x.sht[UNION] - sx) < 32 &&
	       (shot_chi.y.sht[UNION] - sy) > -10 &&
	       (shot_chi.y.sht[UNION] - sy) < 42) {
		  BombCInit(enemy_no);
		  score += 2000;
		  return 1;
	    }
      }else
        return 0;
}

