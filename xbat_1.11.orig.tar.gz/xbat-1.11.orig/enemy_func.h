int Bomb(int),Toloido(int),Zakart(int),Zosy(int),Bacura(int);
int Talken(int),Kapi(int),Teraji(int),Ando(int),Core(int),Gido(int);
int GZakart(int),GBZakart(int) , Gemini(int),Jara(int),Sio(int),Brag(int);

void BombInit(int),ToloidoInit(int),ZakartInit(int),ZosyInit(int);
void TalkenInit(int),KapiInit(int),TerajiInit(int),AndoInit(int);
void BacuInit(int) , GidoInit(int) , GZakartInit(int) , GBZakartInit(int);
void JaraInit(int),SioInit(int),BragInit(int) , ZosyInitB(int);

int ChijouD(int),Grobd(int),Sol(int),Rogram(int),Ato(int),CBomb(int);
int SPFlag(int),Mim(int),Delota(int),GDelota(int),BozaRogram(int),Bonodo(int);
int Msg(int) , Domogram(int);

void ChijouInit2(int,int,int),SPFlagInit(int,int,int),MimInit(int,int,int);
void BozaRogInit(int , int , int) , BonodoInit(int,int,int) , DomoInit(int,int,int);
