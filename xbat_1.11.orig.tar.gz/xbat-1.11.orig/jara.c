#include "xev.h"
#include "enemy.h"

PRIVATE char *fn[] = {
      "jara1.img",
      "jara2.img",
      "jara3.img",
      "jara4.img",
      "jara5.img",
      "jara6.img",
      "jara7.img"
};

PRIVATE Pixmap pixmap[7];
PRIVATE Pixmap pixmap_mask[7];
PRIVATE GC gc[7];
PRIVATE int shot_p[5][3] = {
      {10,13,17},
      {15,20,23},
      {20,25,28},
      {30,35,40},
      {40,50,70}
};

void JaraSetChar()
{
      int c_no;
      char img[CSIZE*CSIZE] , mask[128];
      XGCValues gcv;

      gcv.graphics_exposures = False;

      for(c_no = 0 ; c_no < 7 ; c_no++) {
            int x,y;

            sprintf(tpath , "%s/%s",IMAGE_DIR,fn[c_no]);
            LoadChar(tpath,img , sizeof(img));
            pixmap[c_no] = XCreatePixmap(d,w,CSIZE,CSIZE,depth);
            bzero(mask , sizeof(mask));
	    gc[c_no] = XCreateGC(d,w,GCGraphicsExposures,&gcv);

	    DrawChar32(img , mask , gc[c_no],pixmap[c_no]);
            pixmap_mask[c_no] 
              = XCreateBitmapFromData(d,w,mask,CSIZE,CSIZE);
            XSetClipMask(d,gc[c_no],pixmap_mask[c_no]);
      }
}

void JaraFree()
{
      int i;

      for(i = 0 ; i < 7 ; i++) {
	    XFreePixmap(d,pixmap[i]);
	    XFreePixmap(d,pixmap_mask[i]);
	    XFreeGC(d,gc[i]);
      }
}

void JaraInit(enemy_no)
     int enemy_no;
{
      enemy[enemy_no].enemy_no = TOLOIDO;
      enemy[enemy_no].tmp1 = 0;
      enemy[enemy_no].tmp2 = 0;
      
      if(jx.sht[UNION] < XSIZE/2) {
	    enemy[enemy_no].x.dummy = (XSIZE - rand() % (XSIZE/2))*65536;
	    enemy[enemy_no].y.dummy = -(rand() & 31+32)*65536;
	    enemy[enemy_no].vx = -38536*(rand() % 2 + 2)*STPF;
	    enemy[enemy_no].vy = (rand() % 3+7 )*48536*STPF;
      }
      else
        {
              enemy[enemy_no].vx = (rand() % 2+2)*38536*STPF;
              enemy[enemy_no].vy = (rand() % 3+7)*48536*STPF;
              enemy[enemy_no].x.dummy = 65536*(rand() % (XSIZE/2));
              enemy[enemy_no].y.dummy = -(rand() & 31+32)*65536;
        }
}

int Jara(enemy_no)
     int enemy_no;
{
      int i;
      int yararetaTL = 0;
      register int dx,dy;
      int sx,sy;
      
      enemy[enemy_no].x.dummy += enemy[enemy_no].vx;
      enemy[enemy_no].y.dummy += enemy[enemy_no].vy;
      sx = enemy[enemy_no].x.sht[UNION];
      sy = enemy[enemy_no].y.sht[UNION];
      enemy[enemy_no].tmp1 ++;
      enemy[enemy_no].tmp1 %= 7;
      dx = jx.sht[UNION] - sx; dy = jy.sht[UNION] - sy; 
      
      if(dx > -20 && dx < 20 && dy > -20 && dy < 20)
        yararetaTL = 1;
      
      for(i = 0 ; i < SHOT_NUM ; i++)
        {
              if(!shot[i].flag)
                continue;
	      
	      if((shot[i].x.sht[UNION] - sx) > -20 && 
		 (shot[i].x.sht[UNION] - sx) < 20
		 && (shot[i].y.sht[UNION] - sy) > -24 && 
		 (shot[i].y.sht[UNION] - sy) < 2)
		{
		      score += 150;
		      shot[i].flag = 0;
                      BombInit(enemy_no);
		      return 0;
                }
        }
      
      if(sx < 0 ||sx > XSIZE
         || sy > YSIZE)
	{
              enemy[enemy_no].enemy_no = 0;
        }
      else
        {
              if(!enemy[enemy_no].tmp2 && ABS(dx) < (26+rand()%10))
		{
		      enemy[enemy_no].tmp2 = 1;
                      enemy[enemy_no].vx = -5*enemy[enemy_no].vx/3;
		      if( (rand() & 127) < shot_p[game_level][level])
			EShut(enemy_no,enemy[enemy_no].x.dummy,
			      enemy[enemy_no].y.dummy);
		      
                }

	      SetSprite(enemy[enemy_no].x.sht[UNION],
			enemy[enemy_no].y.sht[UNION],
			pixmap[enemy[enemy_no].tmp1],
			gc[enemy[enemy_no].tmp1],
			CSIZE,CSIZE);	      
        }
      
      return yararetaTL;
}



