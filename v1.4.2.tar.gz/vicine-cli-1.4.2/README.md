# vicine

[![npm version](https://img.shields.io/npm/v/vicine?logo=npm)](https://www.npmjs.com/package/vicine)
[![npm downloads](https://img.shields.io/npm/dt/vicine)](https://www.npmjs.com/package/vicine)
[![License](https://img.shields.io/npm/l/vicine)](https://github.com/spaciousejar/vicine-cli/blob/master/LICENSE)

A POSIX shell script to search, stream, and download movies, series and anime from the terminal.

See the [CHANGELOG](CHANGELOG.md) for release history.

## Features

- **Search** movies, series and anime by title
- **Browse** trending, recently added, and custom collections
- **Stream** directly in mpv, IINA, or VLC
- **Download** with yt-dlp, ffmpeg, or curl
- **Series support** — season/episode navigation with next/previous/replay controls
- **Anime support** — dub/sub audio via hianime.at

> Anime streams are pulled from the ZokoAnime server. Some titles only offer
> MegaPlay-based servers, which can't be resolved by the script — those show
> "No sources found".

## Installation

### npm

Published automatically to npmjs on every new `v*` tag (see [Releasing](#releasing)).

```sh
npm install -g vicine
```

### AUR (Arch Linux)

```sh
yay -S vicine
```

### One-liner installer

```sh
curl -fsSL https://raw.githubusercontent.com/spaciousejar/vicine-cli/master/install.sh | sh
```

System-wide (requires root):

```sh
curl -fsSL https://raw.githubusercontent.com/spaciousejar/vicine-cli/master/install.sh | sudo sh -s /usr/local/bin
```

### Manual (git)

```sh
git clone https://github.com/spaciousejar/vicine-cli.git
cd vicine-cli
chmod +x vicine
```

Optionally, add it to your `$PATH`:

```sh
sudo cp vicine /usr/local/bin/vicine
```

### Updating

- Installed via npm: `npm update -g vicine`
- Installed via script/git: `vicine -U` (self-update from GitHub, upgrade-only)

### Uninstalling

- Installed via npm: `npm uninstall -g vicine`
- Installed via AUR: `sudo pacman -R vicine`
- Installed via script/git — the script removes itself:

  ```sh
  vicine --uninstall
  ```

- Watch history under `~/.local/share/vicine` is kept; delete it manually if you want it gone.

## Releasing

Releases are fully automated — one tag push is enough:

```sh
# bump the version in `vicine` (version_number) and `package.json`, commit, then:
git tag -a v1.3.0 -m "v1.3.0"
git push origin v1.3.0
```

`.github/workflows/publish.yml` then:

1. publishes `vicine@<version>` to npmjs
2. creates a GitHub Release with notes generated from the commits since the previous tag (skipped if the release already exists)

## Dependencies

| Required | Optional |
|----------|----------|
| `curl` | `yt-dlp` or `ffmpeg` (for downloads) |
| `jq` | `vlc` |
| `sed`, `grep`, `awk` | `iina` (macOS) |
| `base64`, `od` (anime provider) | |
| `fzf` (or `rofi`/`dmenu`) | |
| `mpv` (or `iina` on macOS) | |

## Usage

```
vicine [options] [query]
```

### Examples

```sh
vicine batman                  # Search and play "batman"
vicine -s "death of robin hood" # Explicit search
vicine -t movies               # Browse trending movies
vicine -r                      # Recently added
vicine -d euphoria             # Download instead of play
vicine -b bollywood_movies --page 2 --limit 50   # Browse a collection page
vicine -S                      # Show catalogue stats
vicine -q 720p -e 3 stranger things   # Play ep 3 in 720p
vicine -q 1080p -e 5-8 stranger things # Play eps 5-8 in 1080p
vicine -c                      # Continue from watch history
vicine -n 1 batman             # Play 2nd search result (non-interactive)
vicine "jujutsu kaisen"        # Search movies/series via hicine; falls back to hianime.at
vicine -A one piece            # Search anime directly on hianime.at
vicine anime "one piece"       # Bare `anime` keyword — same as -A
vicine -A --dub -e 3 "jujutsu kaisen"  # Anime ep 3, dubbed
vicine -D -A "one piece"       # Download every episode of an anime
vicine -i batman               # Show info only (no play)
```

### Options

| Flag | Description |
|------|-------------|
| `anime` | Bare keyword alias for `-A` (search anime via hianime.at) |
| `-s`, `--search` | Search movies/series/anime |
| `-A`, `--anime` | Search anime via hianime.at |
| `--dub` / `--sub` | Dub/sub audio for anime (default sub) |
| `-t`, `--trending` | Show trending content |
| `-r`, `--recent` | Show recently added |
| `-b`, `--browse` | Browse a collection |
| `-S`, `--stats` | Show catalogue stats |
| `-q`, `--quality` | Select quality (`best`, `480p`, `720p`, `1080p`, `2160p`; `4K` accepted as an alias) |
| `-e`, `--episode` | Play episode `N`, range `N-M`, or `-1` (latest) |
| `-c`, `--continue` | Continue from watch history |
| `-C`, `--clear-history` | Clear watch history |
| `-n`, `--select-nth` | Select result by index N (non-interactive) |
| `-U`, `--update` | Self-update from GitHub (upgrade-only, refuses downgrades) |
| `--uninstall` | Remove the script from disk (history is kept) |
| `--exit-after-play` | Play then exit, return player exit code |
| `-i`, `--info` | Show info only (no play) |
| `-d`, `--download` | Download instead of playing |
| `-D`, `--download-all` | Download a movie, whole series, or anime — interactive quality/season pickers, parallel downloads (`VICINE_DL_JOBS`) |
| `-p`, `--player` | Specify player (mpv, iina, vlc) |
| `-V`, `-v`, `--version`, `--v` | Show version |
| `-h`, `--help` | Show help |
| `--rofi` | Use rofi instead of fzf |
| `--dmenu` | Use dmenu instead of fzf |
| `--no-detach` | Don't detach player |
| `--download-dir` | Set download directory |
| `--page N` | Browse page number (default 1) |
| `--limit N` | Items per browse page (default 1000) |

## License

[GPL-3.0](LICENSE)