#pragma once
#include <stdbool.h>

int cmd_help_check(const char *input);
bool cmd_help_exec(char *input, int code);
