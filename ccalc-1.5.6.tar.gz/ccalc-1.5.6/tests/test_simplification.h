#include "test.h"

Test get_simplification_test();
