#pragma once
#include <stdbool.h>

int cmd_playground_check(const char *input);
bool cmd_playground_exec(char *input, int code);
