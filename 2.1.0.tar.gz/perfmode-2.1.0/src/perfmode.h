/* keyboard backlighting functions */
void led_off(void);
void led_min(void);
void led_med(void);
void led_max(void);

/* fan control */
void fan_silent(void);
void fan_balanced(void);
void fan_turbo(void);