#include <gtk/gtk.h>

void activate(GtkApplication* app, gpointer user_data);