#pragma once

void *input_portaudio(void *audiodata);
