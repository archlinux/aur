#!/bin/sh

# Launch pyfa
python2 /usr/share/pyfa/pyfa.py
