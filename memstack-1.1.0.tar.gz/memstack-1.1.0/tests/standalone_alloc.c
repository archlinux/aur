#include <memstack.h>

int main(){


    
    return 0;
}