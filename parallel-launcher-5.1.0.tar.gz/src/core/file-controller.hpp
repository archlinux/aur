#ifndef SRC_CORE_FILE_CONTROLLER_HPP_
#define SRC_CORE_FILE_CONTROLLER_HPP_

#include <unordered_map>
#include <vector>
#include <set>
#include <map>
#include "src/core/controller.hpp"
#include "src/core/settings.hpp"
#include "src/core/updates.hpp"
#include "src/core/rom.hpp"
#include "src/ui/ui-state.hpp"
#include "src/rhdc/core/rhdc-settings.hpp"
#include "src/input/keyboard.hpp"

namespace FileController {

	extern const AppSettings &loadAppSettings();
	extern void saveAppSettings( const AppSettings &settings );

	extern const std::vector<RomSource> &loadRomSources();
	extern void saveRomSources( const std::vector<RomSource> &sources );

	extern const std::map<string, ControllerProfile> &loadControllerProfiles();
	extern void saveControllerProfiles( const std::map<string, ControllerProfile> &profiles );

	extern const HashMap<Uuid,string> &loadControllerMappings();
	extern void saveControllerMappings( const HashMap<Uuid,string> &mappings );

	extern const UiState &loadUiState();
	extern void saveUiState( const UiState &state );

	extern const std::vector<KeyId> &loadHotkeys();
	extern void saveHotkeys( const std::vector<KeyId> &hotkeys );

	extern const std::map<Uuid,InputMode> &loadInputModes();
	extern void saveInputModes( const std::map<Uuid,InputMode> &modes );

	extern const InstalledVersionsInfo &loadInstalledVersions();
	extern void saveInstalledVersions( const InstalledVersionsInfo &versions );

	extern const RhdcSettings &loadRhdcSettings();
	extern void saveRhdcSettings( const RhdcSettings &settings );

	extern const ControllerProfile &loadLastControllerProfile();
	extern void saveLastControllerProfile( const string &name );

}



#endif /* SRC_CORE_FILE_CONTROLLER_HPP_ */
