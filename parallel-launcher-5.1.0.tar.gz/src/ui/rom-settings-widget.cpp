#include "src/ui/rom-settings-widget.hpp"
#include "ui_rom-settings-widget.h"

#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/ui/flow-layout.hpp"

RomSettingsWidget::RomSettingsWidget( QWidget *parent ) :
	QWidget( parent ),
	m_ui( new Ui::RomSettingsWidget ),
	m_suppressEvents( true ),
	m_showAllPlugins( FileController::loadUiState().showAllPlugins ),
	m_accurateDepthCompare( true )
{
	m_ui->setupUi( this );

#ifdef __APPLE__
	m_ui->emulatorTabs->setStyleSheet( QString() );
#endif

	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginParallelRadio, (int)GfxPlugin::ParaLLEl );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlideRadio, (int)GfxPlugin::Glide64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginAngrylionRadio, (int)GfxPlugin::Angrylion );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlidenRadio, (int)GfxPlugin::GlideN64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginRiceRadio, (int)GfxPlugin::Rice );

	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginParallelRadio2, (int)GfxPlugin::ParaLLEl );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginAngrylionRadio2, (int)GfxPlugin::Angrylion );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginGlidenRadio2, (int)GfxPlugin::GlideN64 );

	connect( m_ui->parallelPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(parallelPluginChanged(int,bool)) );
	connect( m_ui->mupenPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(mupenPluginChanged(int,bool)) );

	FlowLayout *checkboxLayout = new FlowLayout( m_ui->checkboxContainer, QSize( 16, 6 ) );
	m_ui->checkboxContainer->setLayout( checkboxLayout );
	checkboxLayout->addWidget( m_ui->overclockCpuCheckbox );
	checkboxLayout->addWidget( m_ui->overclockViCheckbox );
	checkboxLayout->addWidget( m_ui->widescreenCheckbox );
	checkboxLayout->addWidget( m_ui->upscaleTexRectsCheckbox );
	checkboxLayout->addWidget( m_ui->emulateFramebufferCheckbox );
	checkboxLayout->addWidget( m_ui->accurateDepthCompareCheckbox );
	checkboxLayout->setContentsMargins( 6, 0, 6, 0 );

#ifdef __APPLE__
	QMargins margins = checkboxLayout->contentsMargins();
	margins.setBottom( margins.bottom() + 4 );
	checkboxLayout->setContentsMargins( margins );
#endif

	const AppSettings &settings = FileController::loadAppSettings();
	setSettings(
		DefaultInputModes::Normal.id,
		settings.defaultEmulator,
		settings.defaultParallelPlugin,
		settings.defaultMupenPlugin,
		true,
		false,
		false,
		settings.parallelTexRectUpscaling,
		settings.glidenFramebufferEmulation,
		settings.glidenCorrectDepthCompare
	);

	updateWarningVisibility();
	updatePluginVisibility();
	updatePluginSettingsVisibility();
	m_suppressEvents = false;
}

RomSettingsWidget::~RomSettingsWidget() {
	delete m_ui;
}

void RomSettingsWidget::setSettings(
	const Uuid &inputMode,
	EmulatorCore core,
	GfxPlugin parallelPlugin,
	GfxPlugin mupenPlugin,
	bool overclockCpu,
	bool overclockVi,
	bool widescreen,
	bool upscaleTexRects,
	bool emulateFramebuffer,
	bool accurateDepthCompare
) {
	m_accurateDepthCompare = accurateDepthCompare;

	if( core == EmulatorCore::UseDefault ) {
		core = FileController::loadAppSettings().defaultEmulator;
	}

	if( parallelPlugin == GfxPlugin::UseDefault ) {
		parallelPlugin = FileController::loadAppSettings().defaultParallelPlugin;
	}

	if( mupenPlugin == GfxPlugin::UseDefault ) {
		mupenPlugin = FileController::loadAppSettings().defaultMupenPlugin;
	}

	if( m_ui->parallelPluginRadioGroup->button( (int)parallelPlugin ) == nullptr ) {
		parallelPlugin = GfxPlugin::Glide64;
	}

	if( m_ui->mupenPluginRadioGroup->button( (int)mupenPlugin ) == nullptr ) {
		mupenPlugin = GfxPlugin::GlideN64;
	}

	m_suppressEvents = true;
	m_ui->inputModeSelect->setSelected( inputMode );
	m_ui->emulatorTabs->setCurrentIndex( (core == EmulatorCore::ParallelN64) ? 0 : 1 );
	m_ui->parallelPluginRadioGroup->button( (int)parallelPlugin )->setChecked( true );
	m_ui->mupenPluginRadioGroup->button( (int)mupenPlugin )->setChecked( true );
	m_ui->overclockCpuCheckbox->setChecked( overclockCpu );
	m_ui->overclockViCheckbox->setChecked( overclockVi );
	m_ui->widescreenCheckbox->setChecked( widescreen );
	m_ui->upscaleTexRectsCheckbox->setChecked( upscaleTexRects );
	m_ui->emulateFramebufferCheckbox->setChecked( emulateFramebuffer );
	m_ui->accurateDepthCompareCheckbox->setChecked( emulateFramebuffer && accurateDepthCompare );
	m_ui->accurateDepthCompareCheckbox->setEnabled( emulateFramebuffer );
	m_suppressEvents = false;

	updateWarningVisibility();
	updatePluginSettingsVisibility();
}


const Uuid &RomSettingsWidget::getInputMode() const {
	return m_ui->inputModeSelect->getSelected().id;
}

EmulatorCore RomSettingsWidget::getEmulatorCore() const {
	return (EmulatorCore)(m_ui->emulatorTabs->currentIndex() + 1);
}

GfxPlugin RomSettingsWidget::getParallelPlugin() const {
	return (GfxPlugin)m_ui->parallelPluginRadioGroup->checkedId();
}

GfxPlugin RomSettingsWidget::getMupenPlugin() const {
	return (GfxPlugin)m_ui->mupenPluginRadioGroup->checkedId();
}

bool RomSettingsWidget::overclockCpu() const {
	return m_ui->overclockCpuCheckbox->isChecked();
}

bool RomSettingsWidget::overclockVi() const {
	return m_ui->overclockViCheckbox->isChecked();
}

bool RomSettingsWidget::widescreen() const {
	return m_ui->widescreenCheckbox->isChecked();
}

bool RomSettingsWidget::upscaleTexRects() const {
	return m_ui->upscaleTexRectsCheckbox->isChecked();
}

bool RomSettingsWidget::emulateFramebuffer() const {
	return m_ui->emulateFramebufferCheckbox->isChecked();
}

void RomSettingsWidget::updateWarningVisibility() {
	m_ui->performanceWarningLabel->setVisible( !m_ui->overclockCpuCheckbox->isChecked() );
	m_ui->pluginWarningLabel->setVisible(
		m_ui->emulatorTabs->currentIndex() == 0 &&
		m_ui->pluginGlidenRadio->isChecked()
	);
}

void RomSettingsWidget::updatePluginVisibility() {
	m_ui->pluginAngrylionRadio->setVisible( m_showAllPlugins );
	m_ui->pluginGlidenRadio->setVisible( m_showAllPlugins );
	m_ui->pluginRiceRadio->setVisible( m_showAllPlugins );

	m_ui->showMorePluginsLinks->setText(
		QString( "<a href=\"#\">" ) +
		(m_showAllPlugins ? tr( "Show Fewer Plugins" ) : tr( "Show More Plugins" )) +
		QString( "</a>" )
	);
}

void RomSettingsWidget::updatePluginSettingsVisibility() {
	m_ui->upscaleTexRectsCheckbox->setVisible(
		( m_ui->emulatorTabs->currentIndex() == 0 && m_ui->pluginParallelRadio->isChecked() ) ||
		( m_ui->emulatorTabs->currentIndex() == 1 && m_ui->pluginParallelRadio2->isChecked() )
	);

	const bool gliden64 = (
		m_ui->emulatorTabs->currentIndex() == 1 &&
		m_ui->pluginGlidenRadio2->isChecked()
	);

	m_ui->emulateFramebufferCheckbox->setVisible( gliden64 );
	m_ui->accurateDepthCompareCheckbox->setVisible( gliden64 );
}

void RomSettingsWidget::inputModeSelectionChanged() {
	if( m_suppressEvents ) return;
	emit inputModeChanged();
}

void RomSettingsWidget::overclockCpuToggled( bool checked ) {
	m_ui->performanceWarningLabel->setVisible( !checked );
	if( m_suppressEvents ) return;
	emit overclockCpuChanged( checked );
}

void RomSettingsWidget::overclockViToggled( bool checked ) {
	if( m_suppressEvents ) return;
	emit overclockViChanged( checked );
}

void RomSettingsWidget::widescreenToggled( bool checked ) {
	if( m_suppressEvents ) return;
	emit widescreenChanged( checked );
}

void RomSettingsWidget::upscaleTexRectsToggled( bool checked ) {
	if( m_suppressEvents ) return;
	emit upscaleTexRectsChanged( checked );
}

void RomSettingsWidget::emulateFramebufferToggled( bool checked ) {
	m_ui->accurateDepthCompareCheckbox->setEnabled( checked );
	if( m_suppressEvents ) {
		m_ui->accurateDepthCompareCheckbox->setChecked( checked && m_accurateDepthCompare );
	} else {
		m_suppressEvents = true;
		m_ui->accurateDepthCompareCheckbox->setChecked( checked && m_accurateDepthCompare );
		m_suppressEvents = false;
		emit emulateFramebufferChanged( checked );
	}
}

void RomSettingsWidget::accurateDepthCompareToggled( bool checked ) {
	m_accurateDepthCompare = checked;
	if( m_suppressEvents ) return;
	emit accurateDepthCompareChanged( checked );
}

void RomSettingsWidget::emulatorChanged() {
	updateWarningVisibility();
	updatePluginSettingsVisibility();
	emit emulatorCoreChanged();
}

void RomSettingsWidget::parallelPluginChanged( int, bool checked ) {
	if( !checked ) return;
	updateWarningVisibility();
	updatePluginSettingsVisibility();
	emit parallelPluginChanged();
}

void RomSettingsWidget::mupenPluginChanged( int, bool checked ) {
	if( !checked ) return;
	updatePluginSettingsVisibility();
	emit mupenPluginChanged();
}

void RomSettingsWidget::morePluginsToggled() {
	m_showAllPlugins = !m_showAllPlugins;
	updatePluginVisibility();
	if( m_suppressEvents ) return;
	emit showMorePluginsChanged( m_showAllPlugins );
}
