#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"
#include "src/rhdc/web/require-login.hpp"

#include "src/core/logging.hpp"

struct RatingUpdate {
	ubyte quality;
	ubyte difficulty;
};

struct StarsUpdate {
	ushort stars;
};

struct CompletionUpdate {
	bool isComplete;
};

struct PlayTimeUpdate {
	int64 playTime;
};

template<> void JsonSerializer::serialize<RatingUpdate>( JsonWriter &jw, const RatingUpdate &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( "rating", obj.quality );
	jw.writeProperty( "difficulty", obj.difficulty );
	jw.writeObjectEnd();
}

template<> void JsonSerializer::serialize<StarsUpdate>( JsonWriter &jw, const StarsUpdate &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( "starPoints", obj.stars );
	jw.writeObjectEnd();
}

template<> void JsonSerializer::serialize<CompletionUpdate>( JsonWriter &jw, const CompletionUpdate &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( "hackComplete", obj.isComplete );
	jw.writeObjectEnd();
}

template<> void JsonSerializer::serialize<PlayTimeUpdate>( JsonWriter &jw, const PlayTimeUpdate &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( "playTime", obj.playTime );
	jw.writeObjectEnd();
}

void RhdcApi::getStarpowerAsync(
	const string &hackId,
	const std::function<void(Starpower&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getStarpowerAsync( hackId, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/starpowersubmissions/gameusersubmission/"s + ApiUtil::identity().userId + '/' + hackId );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( json.isObject() ) {
			Starpower starpower = {
				RhdcHackProgress {
					json["rating"].getOrDefault<ubyte>( 0 ),
					json["difficulty"].getOrDefault<ubyte>( 0 ),
					json["starPoints"].getOrDefault<ushort>( 0 ),
					json["hackComplete"].getOrDefault<bool>( false )
				},
				json["playTime"].getOrDefault<int64>( 0 )
			};
			onSuccess( starpower );
		} else {
			logError( "Unexpected JSON format in response from RHDC gameusersubmission query" );
			onFailure( ApiErrorType::JsonError );
		}
	}, [=](ApiErrorType error) {
		if( error == ApiErrorType::NotFound ) {
			Starpower starpower = {
				RhdcHackProgress{ 0, 0, 0, false },
				0
			};
			onSuccess( starpower );
		} else {
			onFailure( error );
		}
	});
}

void RhdcApi::getStarpowerAsync(
	const std::function<void(HashMap<string,Starpower>&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getStarpowerAsync( onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/starpowersubmissions/user/"s + ApiUtil::identity().userId );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( !json.isArray() ) {
			logError( "Unexpected JSON format in response from RHDC starpowersubmissions query" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		HashMap<string,Starpower> starpower;
		for( const Json &progress : json.array() ) {
			const string gameId = progress["gameId"].getOrDefault<string>( "" );
			if( gameId.empty() ) continue;
			starpower[gameId] = {
				RhdcHackProgress {
					progress["rating"].getOrDefault<ubyte>( 0 ),
					progress["difficulty"].getOrDefault<ubyte>( 0 ),
					progress["starPoints"].getOrDefault<ushort>( 0 ),
					progress["hackComplete"].getOrDefault<bool>( false )
				},
				progress["playTime"].getOrDefault<int64>( 0 )
			};
		}

		onSuccess( starpower );
	}, onFailure );
}

void RhdcApi::submitRatingsAsync(
	const string &hackId,
	ubyte qualityRating,
	ubyte difficultyRating,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ submitRatingsAsync( hackId, qualityRating, difficultyRating, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send<RatingUpdate>( HttpMethod::Post, "https://api.romhacking.com/starpowersubmissions/"s + hackId, { qualityRating, difficultyRating } );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::submitStarProgressAsync(
	const string &hackId,
	ushort starsCollected,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ submitStarProgressAsync( hackId, starsCollected, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send<StarsUpdate>( HttpMethod::Post, "https://api.romhacking.com/starpowersubmissions/"s + hackId, { starsCollected } );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::submitCompletionAsync(
	const string &hackId,
	bool isComplete,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ submitCompletionAsync( hackId, isComplete, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send<CompletionUpdate>( HttpMethod::Post, "https://api.romhacking.com/starpowersubmissions/"s + hackId, { isComplete } );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::submitPlayTimeAsync(
	const string &hackId,
	int64 playTime,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ submitPlayTimeAsync( hackId, playTime, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send<PlayTimeUpdate>( HttpMethod::Post, "https://api.romhacking.com/starpowersubmissions/"s + hackId, { playTime } );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}
