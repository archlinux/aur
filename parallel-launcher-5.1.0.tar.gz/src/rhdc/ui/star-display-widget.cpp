#include "src/rhdc/ui/star-display-widget.hpp"

#include <fstream>
#include <ios>
#include <QHBoxLayout>
#include <QByteArray>
#include <QImage>
#include <QLabel>
#include <QFile>
#include <QIcon>
#include "src/core/numeric-string.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/buffer.hpp"
#include "src/ui/util.hpp"

static QPixmap pixmapFromData( const std::vector<ubyte> &data ) {
	if( data.empty() ) return QPixmap();
	const QByteArray imageData = QByteArray::fromRawData( (char*)data.data(), data.size() );
	return QPixmap::fromImage( QImage::fromData( imageData ) );
}

StarDisplayWidget::StarDisplayWidget(
	QWidget *parent,
	const fs::path &saveFilePath,
	StarLayout &&layout
) :
	QTabWidget( parent ),
	m_saveFilePath( saveFilePath ),
	m_layout( layout )
{
	setTabBarAutoHide( true );

	m_collectedStarImage = pixmapFromData( m_layout.collectedStarIcon );
	if( m_collectedStarImage.isNull() ) {
		m_collectedStarImage = QIcon( ":/symbol/star.png" ).pixmap( 24, 24 );
	}

	m_missingStarImage = pixmapFromData( m_layout.missingStarIcon );
	if( m_missingStarImage.isNull() ) {
		QImage shadow = m_collectedStarImage.toImage().convertToFormat( QImage::Format_ARGB32 );
		uint *pixels = (uint*)shadow.bits();
		for( qsizetype i = 0; i < shadow.sizeInBytes() / 4; i++ ) {
			pixels[i] = (pixels[i] & 0xFF000000u) | 0x00666666u;
		}
		m_missingStarImage = QPixmap::fromImage( shadow );
	}

	if( !fs::existsSafe( saveFilePath ) ) {
		QFile saveFile( saveFilePath.u8string().c_str() );
		saveFile.open( QFile::WriteOnly | QFile::Truncate );

		QByteArray zeroBuffer;
		zeroBuffer.fill( '\0', 296960 );

		saveFile.write( zeroBuffer );
		saveFile.flush();
	}

	m_tabs.reserve( m_layout.numSlots );
	for( int i = 0; i < (int)m_layout.numSlots; i++ ) {
		QWidget *tab = new QWidget();
		QHBoxLayout *columns = new QHBoxLayout( tab );
		QVBoxLayout *leftCol = new QVBoxLayout();
		QVBoxLayout *rightCol = new QVBoxLayout();
		tab->setLayout( columns );
		columns->addLayout( leftCol );
		columns->addStretch();
		columns->addLayout( rightCol );
		if( m_layout.numSlots <= 26 ) {
			addTab( tab, ("MARIO "s + (char)('A' + i)).c_str() );
		} else {
			addTab( tab, ("MARIO "s + Number::toString( i )).c_str() );
		}
		m_tabs.push_back({ leftCol, rightCol });
	}

	connect( &m_fileWatcher, &QFileSystemWatcher::fileChanged, this, &StarDisplayWidget::saveFileChanged );
	m_fileWatcher.addPath( saveFilePath.u8string().c_str() );
	saveFileChanged();
}

StarDisplayWidget::~StarDisplayWidget() {
	for( const SlotTab &tab : m_tabs ) {
		tab.leftSide->deleteLater();
		tab.rightSide->deleteLater();
	}
}

void StarDisplayWidget::saveFileChanged() {

	std::ifstream saveFile( m_saveFilePath.u8string(), std::ios_base::binary | std::ios_base::in );
	Buffer saveData = m_layout.getUsedSaveData( saveFile );

	for( uint i = 0; i < m_layout.numSlots; i++ ) {
		UiUtil::clearLayout( m_tabs[i].leftSide );
		UiUtil::clearLayout( m_tabs[i].rightSide );

		m_tabs[i].rightSide->addStretch();

		const uint slotStart = m_layout.slotsStart + (i * m_layout.slotSize);
		const bool slotActive = (saveData.data()[slotStart + (m_layout.activeBit / 8)] >> (7 - (m_layout.activeBit % 8))) & 0x1;

		for( const StarLayout::Group &group : m_layout.groups ) {
			QVBoxLayout *uiColumn = group.leftSide ? m_tabs[i].leftSide : m_tabs[i].rightSide;

			QHBoxLayout* titleLayout = new QHBoxLayout();
			titleLayout->addStretch();
			titleLayout->addWidget( new QLabel( group.name.c_str() ) );
			titleLayout->addStretch();

			uiColumn->addLayout( titleLayout );

			QGridLayout *uiGrid = new QGridLayout();
			int row = 0;
			for( const StarLayout::Course &course : group.courses ) {
				uiGrid->addWidget( new QLabel( course.name.c_str() ), row, 0 );

				QHBoxLayout* uiStars = new QHBoxLayout();
				for( const StarLayout::StarData &starData : course.stars ) {
					const ubyte stars = saveData.data()[slotStart + starData.offset];
					ubyte mask = starData.mask;
					while( mask != 0 ) {
						QLabel *starIcon = new QLabel( "" );
						const ubyte testBit = mask - (mask & (mask - 1));
						if( slotActive && (stars & testBit) ) {
							starIcon->setPixmap( m_collectedStarImage );
						} else {
							starIcon->setPixmap( m_missingStarImage );
						}

						uiStars->addWidget( starIcon );
						mask -= testBit;
					}
				}

				uiStars->addStretch();
				uiGrid->addLayout( uiStars, row++, 1 );
			}

			uiColumn->addLayout( uiGrid );
		}

		m_tabs[i].leftSide->addStretch();
		m_tabs[i].rightSide->addStretch();
	}
}
