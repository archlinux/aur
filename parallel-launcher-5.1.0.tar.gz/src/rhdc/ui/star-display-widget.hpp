#ifndef STARDISPLAYWIDGET_HPP
#define STARDISPLAYWIDGET_HPP

#include <vector>
#include <QFileSystemWatcher>
#include <QVBoxLayout>
#include <QTabWidget>
#include <QPixmap>
#include "src/rhdc/core/layout.hpp"
#include "src/core/filesystem.hpp"

class StarDisplayWidget : public QTabWidget {
	Q_OBJECT

	private:
	struct SlotTab {
		QVBoxLayout *leftSide;
		QVBoxLayout *rightSide;
	};

	QFileSystemWatcher m_fileWatcher;
	const fs::path m_saveFilePath;
	const StarLayout m_layout;
	QPixmap m_collectedStarImage;
	QPixmap m_missingStarImage;
	std::vector<SlotTab> m_tabs;

	public:
	explicit StarDisplayWidget( QWidget *parent, const fs::path &saveFilePath, StarLayout &&layout );
	~StarDisplayWidget();

	private slots:
	void saveFileChanged();
};

#endif // STARDISPLAYWIDGET_HPP
