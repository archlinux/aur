#include "src/db/sqlite.hpp"

#include <cassert>
#include <cstdlib>
#include <iostream>
#include "src/polyfill/base-directory.hpp"

#if defined(DEBUG) && !defined(_WIN32)
#include <execinfo.h>
#endif

inline static void assertStatusGood( sqlite3 *connection, int status ) {
	if( status == SQLITE_DONE || status == SQLITE_ROW || status == SQLITE_OK ) return;
	std::cerr << "Assertion Failed: SQL Error (Status = " << status << ')' << std::endl;
	std::cerr << sqlite3_errmsg( connection ) << std::endl << std::flush;
#if defined(DEBUG) && !defined(_WIN32)
	void *stacktrace[32];
	int size = backtrace( stacktrace, 32 );
	backtrace_symbols_fd( stacktrace, size, 2 );
	std::cerr << std::endl << std::flush;
#endif
	std::exit( 1 );
}

static const char s_initSql[] = R"#(
PRAGMA encoding = "UTF-8";

CREATE TABLE IF NOT EXISTS ROMS(
	sha1 TEXT NOT NULL PRIMARY KEY,
	name TEXT NOT NULL,
	internal_name TEXT NOT NULL,
	emulator INTEGER NOT NULL,
	parallel_plugin INTEGER NOT NULL,
	mupen_plugin INTEGER NOT NULL,
	upscale_texrects INTEGER NOT NULL,
	emulate_framebuffer INTEGER NOT NULL,
	n64_depth_compare INTEGER NOT NULL,
	overclock_cpu INTEGER NOT NULL,
	overclock_vi INTEGER NOT NULL,
	widescreen INTEGER NOT NULL,
	input_mode_id BLOB NOT NULL,
	last_played INTEGER NOT NULL,
	play_time INTEGER NOT NULL,
	crc32 INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_rom_by_crc ON ROMS( crc32 );

CREATE TABLE IF NOT EXISTS ROM_PATHS(
	path TEXT NOT NULL PRIMARY KEY,
	last_modified INTEGER NOT NULL,
	sha1 TEXT NOT NULL,
	local INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_paths_by_sha1 ON ROM_PATHS( sha1 );

CREATE TABLE IF NOT EXISTS ROM_GROUPS(
	sha1 TEXT NOT NULL,
	group_name TEXT NOT NULL,
	PRIMARY KEY( sha1, group_name )
);
CREATE INDEX IF NOT EXISTS ix_groups_by_name ON ROM_GROUPS( group_name );

CREATE VIEW IF NOT EXISTS TAGGED_ROMS AS
SELECT ROMS.*, group_concat( group_name, x'0A' ) AS groups
FROM ROMS LEFT JOIN ROM_GROUPS USING( sha1 )
GROUP BY sha1;

CREATE TABLE IF NOT EXISTS PERSISTENT_GROUPS(
	name TEXT NOT NULL PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS MANUAL_ROM_PATHS(
	path TEXT NOT NULL PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS RHDC_HACKS(
	id TEXT NOT NULL PRIMARY KEY,
	name TEXT NOT NULL,
	slug TEXT NOT NULL,
	description TEXT NOT NULL,
	star_count INTEGER NOT NULL,
	downloads INTEGER NOT NULL,
	avg_rating REAL NOT NULL,
	avg_difficulty REAL NOT NULL,
	category TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS RHDC_HACK_PROGRESS(
	id TEXT NOT NULL PRIMARY KEY,
	my_rating INTEGER NOT NULL,
	my_difficulty INTEGER NOT NULL,
	stars_collected INTEGER NOT NULL,
	completed INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS RHDC_HACK_VERSIONS(
	sha1 TEXT NOT NULL PRIMARY KEY,
	id TEXT NOT NULL,
	version_name TEXT NOT NULL,
	sort_order INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_hack_versions_by_id ON RHDC_HACK_VERSIONS( id );

CREATE TABLE IF NOT EXISTS RHDC_HACK_AUTHORS(
	id TEXT NOT NULL,
	author TEXT NOT NULL,
	PRIMARY KEY( id, author )
);
CREATE INDEX IF NOT EXISTS ix_hack_authors ON RHDC_HACK_AUTHORS( author );

CREATE TABLE IF NOT EXISTS RHDC_LAST_PLAYED_VERSIONS(
	id TEXT NOT NULL PRIMARY KEY,
	sha1 TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS LOGS(
	level INTEGER NOT NULL,
	timestamp INTEGER NOT NULL,
	message TEXT NOT NULL
);

)#";

class DbConnection final {

	private:
	sqlite3 *m_connection;

	inline DbConnection( sqlite3 *connection ) noexcept : m_connection( connection ) {}
	inline DbConnection( DbConnection &&other ) noexcept : m_connection( other.m_connection ) { other.m_connection = nullptr; }
	DbConnection( const DbConnection &other ) = delete;
	~DbConnection() noexcept {
		if( m_connection != nullptr ) sqlite3_close( m_connection );
	}

	static DbConnection create() noexcept {
		const fs::path dbFile = BaseDir::data() / "roms.sqlite";

		sqlite3 *db = nullptr;
		int status = sqlite3_open( dbFile.u8string().c_str(), &db );
		if( status != SQLITE_OK ) {
			std::cerr << "Failed to open or create sqlite database" << std::endl << std::flush;
			std::exit( status );
		}

		status = sqlite3_exec( db, s_initSql, nullptr, nullptr, nullptr );
		assert( status == SQLITE_OK || status == SQLITE_DONE || status == SQLITE_ROW );

		return DbConnection( db );
	}

	public:
	static sqlite3 *instance() noexcept {
		static DbConnection s_db = DbConnection::create();
		return s_db.m_connection;
	}

};

SqlCommand::SqlCommand( const char *sql ) noexcept : m_bindingIndex( 0 ) {
	const int status = sqlite3_prepare_v3(
		DbConnection::instance(),
		sql,
		-1,
		SQLITE_PREPARE_PERSISTENT,
		&m_statement,
		nullptr
	);
	assertStatusGood( DbConnection::instance(), status );
}

SqlCommand::SqlCommand( SqlCommand &&other ) noexcept :
	m_statement( other.m_statement ),
	m_bindingIndex( other.m_bindingIndex )
{
	other.m_statement = nullptr;
}

SqlCommand::~SqlCommand() noexcept {
	sqlite3_finalize( m_statement );
}

void SqlCommand::execNonQuery( int *status ) noexcept {
	m_bindingIndex = 0;
	const int sqlStatus = sqlite3_step( m_statement );
	sqlite3_reset( m_statement );
	sqlite3_clear_bindings( m_statement );
	if( status != nullptr ) {
		*status = sqlStatus;
	} else {
		assertStatusGood( DbConnection::instance(), sqlStatus );
	}
}

DataRecordIterator::DataRecordIterator( sqlite3_stmt *statement ) noexcept :
	m_statement( statement ),
	m_status( SQLITE_OK )
{}

DataRecordIterator::DataRecordIterator( DataRecordIterator &&other ) noexcept :
	m_statement( other.m_statement ),
	m_status( other.m_status )
{
	other.m_statement = nullptr;
	other.m_status = SQLITE_MISUSE;
}

DataRecordIterator::~DataRecordIterator() noexcept {
	if( m_statement == nullptr ) return;
	sqlite3_reset( m_statement );
	sqlite3_clear_bindings( m_statement );
	assertStatusGood( DbConnection::instance(), status() );
}

bool DataRecordIterator::moveNext() noexcept {
	m_status = sqlite3_step( m_statement );
	return m_status == SQLITE_ROW;
}

void DataRecordIterator::close() noexcept {
	sqlite3_reset( m_statement );
	sqlite3_clear_bindings( m_statement );
	m_statement = nullptr;
	m_status = SQLITE_MISUSE;
}

SqlBatch::SqlBatch( const char *sql ) : m_bindingIndex( 0 ) {
	while( sql[0] != '\0' ) {
		if( sql[0] == ' ' || sql[0] == '\t' || sql[0] == '\n' ) {
			sql++;
			continue;
		}

		const char *next = nullptr;
		sqlite3_stmt *statement = nullptr;
		const int status = sqlite3_prepare_v3(
			DbConnection::instance(),
			sql,
			-1,
			SQLITE_PREPARE_PERSISTENT,
			&statement,
			&next
		);
		assertStatusGood( DbConnection::instance(), status );
		sql = next;
		m_statements.push_back( statement );
	}
	assert( m_statements.size() > 1 );
}

SqlBatch::SqlBatch( SqlBatch &&other ) noexcept :
	m_statements( std::move( other.m_statements ) ),
	m_bindingIndex( other.m_bindingIndex ) {}

SqlBatch::~SqlBatch() {
	for( sqlite3_stmt *statement : m_statements ) {
		sqlite3_finalize( statement );
	}
}

void SqlBatch::execNonQuery() noexcept {
	static SqlCommand s_start( "SAVEPOINT batch" );
	static SqlCommand s_end( "RELEASE batch" );

	m_bindingIndex = 0;
	s_start.execNonQuery();
	for( sqlite3_stmt *statement : m_statements ) {
		const int sqlStatus = sqlite3_step( statement );
		sqlite3_reset( statement );
		sqlite3_clear_bindings( statement );
		assertStatusGood( DbConnection::instance(), sqlStatus );
	}
	s_end.execNonQuery();
}


