#!/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'

echo -e "configuring skywire visor"

#here we detect the file which is provided by the hypervisorkey package
if [[ ! -f /opt/skywire/hypervisorkey.txt ]] ; then
  echo -e "${_red}  >>> FATAL: hypervisor key not found!${_nc}"
  echo "hypervisorkey package is corrupt - key is missing"
  exit
fi

echo "stopping any running instance of skywire"
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear as a subdirectory of install dir
cd /opt/skywire

if [[ -f /opt/skywire/skywire-visor.json ]] ; then #try to reuse any existing visor config
cp -b /opt/skywire/skywire-visor.json /opt/skywire/skywire-visor.json.gen
else
if [[ -f /opt/skywire/skywire.json ]] ; then #use hypervisor config
cp -b /opt/skywire/skywire.json /opt/skywire/skywire-visor.json.gen
else  #error here
echo -e "${_red}  >>> FATAL: expected visor or hypervisor configuration file not found!${_nc}"
echo "there is a problem with the expected skywire configuration which requires manual intervenion."
exit
fi
fi

#generate hypervisor configuration
_hvk=$(cat /opt/skywire/hypervisorkey.txt)
echo
echo -e "Setting hypervisors:
${_purple}${_hvk}${_nc}"
skywire-cli visor gen-config --hypervisor-pks $_hvk -p -r -o /opt/skywire/skywire-visor.json.gen
mv /opt/skywire/skywire-visor.json.gen /opt/skywire/skywire-visor.json
systemctl enable --now skywire-visor.service
echo
echo -e "Starting ${_blue}skywire${_nc} in visor-only mode"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
echo
echo -e "Visor Public Key:
${_green}${_pubkey}${_nc}"
echo
#if apt list skywire-save > /dev/null ; then
#echo -e "persisted configuration detected"
#else
#echo -e "run ${_cyan}skywire-save${_nc} to back up the current configuration!"
#fi
#echo
