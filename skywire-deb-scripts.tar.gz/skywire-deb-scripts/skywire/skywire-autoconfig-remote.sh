#!/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_remoteip=""
if [[ -z $1 ]]; then
_remoteip="$(ip route show | grep -i 'default via'| awk '{print $3 }' | sed 's/\.[^.]*$//').2:3435"
[[ "${_remoteip}" == ".2:3435" ]] && echo "gateway not found" && exit 1
else
  _remoteip="${1}:3435"
#debug
# [[ "192.168.0.1" == *.*.*.* ]] && echo "no"
[[ "${_remoteip}" != *.*.*.* ]] && echo "bad ip address format" && exit 1
fi
_remotepk=$(skywire-cli --rpc ${_remoteip} visor pk)
skywire-autoconfig ${_remotepk}
