#!/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan} ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_msg3() {
(( QUIET )) && return
local mesg=$1; shift
printf "${_blue} -->${ALL_OFF}${BOLD} ${mesg}${ALL_OFF}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_warnmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Warning:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}
_welcome(){
  _msg2 "Visit ${_blue}https://whitelist.skycoin.com/${_nc} to register your public key."
  _msg2 "View the uptime tracker: ${_blue}http://ut.skywire.skycoin.com/uptimes${_nc}"
  _msg2 "join our community on telegram: ${_blue}https://t.me/skywire https://t.me/Skycoin${_nc}"
}

_config_hypervisor() {
  #try to reuse existing configuration
  if [[ ! -f /opt/skywire/skywire.json ]]; then
    if [[ -f /etc/skywire-config.json ]]; then
      _warnmsg1 "Importing existing skybian configuration from /etc/skywire-config.json"
      cp -b  /etc/skywire-config.json /opt/skywire/skywire.json
    fi
  else
    mv /opt/skywire/skywire.json /opt/skywire/skywire-config.json
  fi

  ##generate hypervisor configuration##
  _msg3 "Generating skywire config with commands:"
  echo "  cd /opt/skywire
  cp -b skywire.json skywire-config.json
  skywire-cli config gen -ipro skywire-config.json
  mv skywire-config.json skywire.json"

  if [[ $(skywire-cli config gen -ipro skywire-config.json && mv skywire-config.json skywire.json) ]]; then
    _msg2 "${_blue}Skywire${_nc} configuration updated!"
    if [[ -f /opt/skywire/skywire.json ]]; then
      echo "config path: /opt/skywire/skywire.json"
    else
      _errmsg2 "expected config file not found at /opt/skywire/skywire.json"
      exit 100
    fi
  else
    _errmsg2 "Skywire is not installed or installation not detected! Could not generate configuration file!"
    echo "this should never happen."
    exit 100
  fi
}

_config_visor() {
  _msg2 "Creating visor configutation with specified hypervisor public key:
  ${1}"
  cp -b skywire.json skywire-visor.json
  skywire-cli config gen --hypervisor-pks ${1} -pro skywire-config.json
  mv skywire-config.json skywire-visor.json
  sudo systemctl enable --now skywire-visor.service
  _msg3 "Enabling skywire-visor systemd service:
  systemctl enable --now skywire-visor.service"
  systemctl enable --now skywire-visor.service 2> /dev/null
  _msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
  _pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
  _pubkey=${_pubkey#*: }
  _pubkey=${_pubkey//,/}
  _pubkey=${_pubkey//\"/}
  _msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
  _welcome
}

_config_tips() {
  _msg2 "execute the following command on OTHER NODES to set this one as their hypervisor:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}${_pubkey}${_nc}"
  _msg2 "(PR#1052) you can also allow RPC requests from local network:"
  echo -e "${_yellow}sed -i 's/\"cli_addr\": \"localhost:3435\",/\"cli_addr\": \":3435\",/g' /opt/skywire/skywire.json${_nc}"
  _msg2 "and configure to a hypervisor running on an ip adress, example:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}\$(skywire-cli --rpc ${_lanip}:3435 visor pk)${_nc}"
  _msg2 "to see this text again run: ${_cyan}skywire-autoconfig${_nc}"

}
#config generation writes in the current dir;
#so we want to make anything spawned by the process appear in a subdirectory of install dir
cd /opt/skywire/  || _errmsg2 "the path /opt/skywire was not found"

_msg2 "Configuring skywire"
#halt any running instance
[[ -f /etc/systemd/system/skywire.service ]] && systemctl disable --now skywire.service 2> /dev/null
[[ -f /etc/systemd/system/skywire-visor.service ]] && systemctl disable --now skywire-visor.service 2> /dev/null
[[ -f /etc/systemd/system/skywire-firstboot.service ]] && systemctl disable --now skywire-firstboot.service 2> /dev/null
[[ -f /etc/systemd/system/skywire-visor-firstboot.service ]] && systemctl disable --now skywire-visor-firstboot.service 2> /dev/null
[[ -f /etc/lib/systemd/system/skywire-hypervisor.service ]] && systemctl disable --now skywire-hypervisor.service 2> /dev/null

#Detect if this script is run in chroot - NOT WORKING ROBUSTLY
awk 'BEGIN{exit_code=1} $2 == "/" {exit_code=0} END{exit exit_code}' /proc/mounts
_1=$?
#allow explicitly setting hypervisor pk and config generation in chroot
[[ ${_1} == "1" ]] && echo ${?} && [[ ! -z $1 ]] && _config_hypervisor && _config_visor && exit
#otherwise enable the boot config service
[[ ${_1} == "1" ]] && echo ${?} && [[ -z $1 ]] && systemctl enable --now skywire-firstboot.service && exit
_config_hypervisor

#generate tls keys >>deprecated<<
#skywire-tls-gen

if [[ -z $1 ]] ; then
  if [[ ! -f /opt/skywire/skywire-visor.json ]]; then #>>start hypervisor if visor config does not exist<<
  _msg3 "Enabling skywire systemd service.."
  systemctl enable --now skywire.service 2> /dev/null
  #getting the public key with `skywire-cli visor pk` will fail because it takes the visor a little time to start
  #Need functionality so that skywire-cli can read the puclic key (or other info) from a specified visor config file
  # https://github.com/skycoin/skywire/issues/1047
  _pubkey=$(cat /opt/skywire/skywire.json | grep pk\")
  _pubkey=${_pubkey#*: }
  _pubkey=${_pubkey//,/}
  _pubkey=${_pubkey//\"/}
  #_pubkey=$(skywire-cli visor pk)
  _msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
  _msg2 "Starting now on:
  ${_red}http://127.0.0.1:8000${_nc}"
_msg2 "Use the vpn:
${_red}http://127.0.0.1:8000/#/vpn/02e145e5da1c66d73c45d741cfe0a09bf863f19ac2f53865481a44141ca072883f/${_nc}"
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
_msg2 "Access hypervisor UI from local network here:
  ${_yellow}http://${_lanip}:8000${_nc}"
_welcome
_config_tips
else
  #The visor config exists
  _msg3 "Enabling skywire-visor systemd service:
  systemctl enable --now skywire-visor.service"
systemctl enable --now skywire-visor.service 2> /dev/null
_msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
_pubkey=${_pubkey//,/}
_pubkey=${_pubkey//\"/}
_msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
_welcome
fi
else #[[ ! -z $1 ]]
_config_visor
fi
