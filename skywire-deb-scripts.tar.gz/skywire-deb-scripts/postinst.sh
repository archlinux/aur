#!/usr/bin/bash
#skywire debian postinstall script
#https://aur.archlinux.org/cgit/aur.git/tree/skywire.install?h=skywire-git
#this script hs no architecture specific elements
#kill any instance that was running
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service
#config generation writes in the current dir;
#so we want to make anything spawned by the process appear as a subdirectory of /root
cd ~/
#try to reuse old config
[[ -f /opt/skywire/skywire.json ]] && cp -b /opt/skywire/skywire.json ~/skywire.json
#generate hypervisor configuration
skywire-cli visor gen-config --is-hypervisor -p -r -o skywire.json
mv skywire.json /opt/skywire/skywire.json
skywire-tls-gen
echo "Skywire has been configured, starting now on https://127.0.0.1:8000"
systemctl enable --now skywire.service
echo "run keypkg-gen to generate the distributable public key package"
