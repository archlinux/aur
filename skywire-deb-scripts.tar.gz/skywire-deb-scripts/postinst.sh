#!/bin/bash
skywire-autoconfig
