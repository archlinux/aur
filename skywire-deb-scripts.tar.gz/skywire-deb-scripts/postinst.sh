#!/usr/bin/bash
#skywire debian postinst script
#script is executed as root by default
#architecture: any
#kill any instance that was running
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear as a subdirectory of the install dir
cd /opt/skywire

#try to reuse old config
[[ -f /opt/skywire/skywire.json ]] && cp -b /opt/skywire/skywire.json /opt/skywire/skywire.json.gen

#generate hypervisor configuration
skywire-cli visor gen-config --is-hypervisor -p -r -o /opt/skywire/skywire.json.gen
mv /opt/skywire/skywire.json.gen /opt/skywire/skywire.json

#generate the tls keys - this is just generate.sh
skywire-tls-gen

echo "Skywire has been configured, starting now on https://127.0.0.1:8000"
_lanip=$(sudo ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo "Access from local network at: https://${_lanip}:8000"
_pubkey=$(cat /opt/skywire/skywire.json | grep pk\")
_pubkey=${_pubkey#*: }
echo "Visor Public Key: ${_pubkey}"
systemctl enable --now skywire.service
echo "run keypkg-gen to generate the distributable public key package"
