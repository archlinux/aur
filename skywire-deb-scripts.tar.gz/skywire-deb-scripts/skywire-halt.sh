#!/bin/bash
sudo killall setup-node skywire-cli skywire-visor skychat skysocks skysocks-client vpn-client vpn-server
