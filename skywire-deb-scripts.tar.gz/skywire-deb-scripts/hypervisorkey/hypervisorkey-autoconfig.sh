#!/bin/bash
#root portion of the configuration
set -e
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi

_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}

_msg2 "hypervisorkey-autoconfig"

#detect the file which is provided by the hypervisorkey package
if [[ ! -f /opt/skywire/hypervisorkey.txt ]] ; then
  _errmsg2 "hypervisor key not found!"
  echo "hypervisorkey package is corrupt - key is missing"
  exit
fi

_msg2 "stopping any running instance of skywire"
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear as a subdirectory of install dir
cd /opt/skywire

if [[ -f /opt/skywire/skywire-visor.json ]] ; then #try to reuse any existing visor config
cp -b /opt/skywire/skywire-visor.json /opt/skywire/skywire-visor.json.gen
else
if [[ -f /opt/skywire/skywire.json ]] ; then #use hypervisor config
cp -b /opt/skywire/skywire.json /opt/skywire/skywire-visor.json.gen
else  #error here
_errmsg2 "expected visor or hypervisor configuration file not found!"
echo "there is a problem with the expected skywire configuration which requires manual intervenion."
exit 100
fi
fi

#generate visor configuration
_hvk=$(cat /opt/skywire/hypervisorkey.txt)
_msg2 "Setting hypervisors:"
_msg2 "${_purple}${_hvk}${_nc}"
if [[ $(skywire-cli visor gen-config --hypervisor-pks $_hvk -p -r -o /opt/skywire/skywire-visor.json.gen) ]]; then
  _msg2 "Generated ${_blue}skywire${_nc} visor configuration!"
else
  _errmsg2 "${_red}  >>> FATAL: skywire not installed or installation not detected! Could not generate configuration file!${_nc}"
  echo "this should never happen"
  exit 100
fi
mv /opt/skywire/skywire-visor.json.gen /opt/skywire/skywire-visor.json
systemctl enable --now skywire-visor.service
echo
_msg2 "Starting ${_blue}skywire${_nc} in visor-only mode"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
echo
_msg2 "Hypervisor Key:
${_purple}${_hvk}${_nc}"
_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"

if [[ -f /opt/skywire/skywire-save.txt ]]; then
_msg2 "persisted configuration detected"
else
_msg2 "run ${_cyan}skywire-save${_nc} to back up the current configuration!"
fi
echo
