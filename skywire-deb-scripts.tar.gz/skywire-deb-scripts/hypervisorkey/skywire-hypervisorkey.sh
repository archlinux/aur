#!/bin/bash
#root portion of the configuration
set -e
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi

_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_msg3() {
(( QUIET )) && return
local mesg=$1; shift
printf "${BLUE}  -->${ALL_OFF}${BOLD} ${mesg}${ALL_OFF}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}

[[ -z $1 ]] && _errmsg2 "please specify the hypervior key as argument" && exit || _hvk=$1

_msg2 "stopping any running instance of skywire"
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service
systemctl disable --now skywire-hypervisor.service

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear as a subdirectory of install dir
cd /opt/skywire

if [[ -f /opt/skywire/skywire-visor.json ]] ; then #try to reuse any existing visor config
cp -b /opt/skywire/skywire-visor.json /opt/skywire/skywire-visor.json.gen
else
if [[ -f /opt/skywire/skywire.json ]] ; then #use hypervisor config
cp -b /opt/skywire/skywire.json /opt/skywire/skywire-visor.json.gen
else  #error here
echo "expected visor or hypervisor configuration file not found!"
echo "there is a problem with the expected skywire configuration which requires manual intervenion."
exit 100
fi
fi

#generate visor configuration
_msg2 "Setting hypervisors:"
_msg2 "${_hvk}"
_msg3 "skywire-cli visor gen-config --hypervisor-pks $_hvk -p -r -o /opt/skywire/skywire-visor.json"
if [[ $(skywire-cli visor gen-config --hypervisor-pks $_hvk -p -r -o /opt/skywire/skywire-visor.json.gen) ]]; then
  _msg2 "Generated skywire visor configuration!"
else
  _errmsg2 ">>> FATAL: skywire not installed or installation not detected! Could not generate configuration file!"
  echo "this should never happen"
  exit 100
fi
mv /opt/skywire/skywire-visor.json.gen /opt/skywire/skywire-visor.json
_msg3 "systemctl enable --now skywire-visor.service"
systemctl enable --now skywire-visor.service
echo
_msg2 "Starting ${_blue}skywire${_nc} in visor-only mode"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
echo
_msg2 "Hypervisor Key:
${_purple}${_hvk}${_nc}"
_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
echo
_msg2 "Visit ${_blue}https://whitelist.skycoin.com/${_nc} to register your public key."
