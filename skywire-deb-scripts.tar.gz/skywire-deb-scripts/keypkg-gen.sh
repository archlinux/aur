#!/usr/bin/bash
#SCRIPT FOR DEBIAN
#architecture: any
if [[ $EUID -ne 0 ]]; then
   echo "must do this as root" 1>&2
   exit 100
fi

#check if the hypervisorkey pckage is installed
#refuse to create hypervisor key package when this local installation is not running as HV
#TO DO: rewrite this check for debian
#pacman -Qi hypervisorconfig > /dev/null && echo "hypervisorkey package is installed, the node has been configured as a visor. Please uninstall it to do this." 1>&2 && exit 100

_skydir="/opt/skywire"
_cachedir="${_skydir}/pkgcache"
#create build dir path
mkdir -p $_cachedir
[[ -d $_cachedir/hypervisorkey-1 ]] && rm -rf $_cachedir/hypervisorkey-1

#TO DO: automatically increment version
#copy build dir from its installed location - this dir only in the debian package for now
cp -rb $_skydir/hypervisorkey $_cachedir/hypervisorkey-1

#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat $_skydir/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
echo ${_hvisorkey} > $_cachedir/hypervisorkey-1/opt/skywire/hypervisorkey.txt

#OPTIONALLY prompt the user here to add more keys; skipped for automation

#create the hypervisorkey package
cd $_cachedir
dpkg-deb --build hypervisorkey-1

#add the skywire package from apt cache to the cache dir
#this is tricky because of versions. also it must be in APTs cache or this to work ;
#..not installed by dpkg after being downloaded directly

#the package cache was not as expected on armbian buster
#skip mirroring the skywire package
#rm -rf $_cachedir/skywire
#mkdir -p $_cachedir/skywire
#cp -b /var/cache/apt/archives/skywire* $_cachedir/skywire/

#set up repo
apt-repo-create

#instruct user on configuration
_lanip=$(sudo ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo "#On the remote system, run the fllowing command or manually add to /etc/apt/sources.list:

add-apt-repository 'deb [trusted=yes] http://${_lanip}:8079 sid main'

"
#serve repo locally
echo "enabling readonly-cache systemd service and serving package repo now on http://${_lanip}:8079"
sudo systemctl enable --now readonly-cache
