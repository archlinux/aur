#!/bin/bash
#make a .deb package repo of all created packages and offer to serve it on the LAN
#script defaults to creating an apt repo of multiple architectures
#depends:  reprepro

#require root
if [[ $EUID -ne 0 ]]; then
   echo "must do this as root" 1>&2
   exit 100
fi

_skydir="/opt/skywire"
_cachedir="${_skydir}/pkgcache"
_repodir="${_skydir}/apt/repo"
#specify a path to the built .deb packages
_pkgspath=${_cachedir}

_default_codename=(sid) #e.g. jessie, stretch, buster, sid

#determine system architecture
#_repoarchitectures=$(dpkg --print-architecture)

#just make the repo for most architectures
_repoarchitectures="amd64 arm64 armhf armel i386 mips mipsel mips64el ppc64el riscv64 s390x"

#get debian version codename
if [ -f  /etc/os-release ]; then
_remove="VERSION_CODENAME="
if [[ "$(cat /etc/os-release | grep $_remove)" == $_remove ]]; then
_codename=$(cat /etc/os-release | grep $_remove)
_codename=${_codename#"$_remove"}
else
_codename=$_default_codename
fi
fi

#need to error if this is empty
if [ -z $_codename ]; then
  _codename=$_default_codename
fi

echo -e "making repo for debian $_codename. Architectures: $_repoarchitectures"
[ ! -d $_repodir ] && mkdir -p $_repodir
[ ! -d "$_repodir/conf" ] && mkdir -p $_repodir/conf

#https://serverfault.com/questions/279153/why-does-reprepro-complain-about-the-all-architecture
#If you specify your .deb (control file) as Architecture: all, then don't put anything into the reprepro distributions file
#other than the arch's that you want it to get put into.
#Architectures: amd64 arm64 armhf armel i386 mips mipsel mips64el ppc64el riscv64 s390x
#The all packages are then available in all the architectures defined in conf/distributions
if [ ! -f "$_repodir/conf/distributions" ]; then
echo "Creating repo configuration file at $_repodir/conf/distributions"
echo "Origin: localhost" > $_repodir/conf/distributions
echo "Label: localhost" >> $_repodir/conf/distributions
echo "Codename: $_codename" >> $_repodir/conf/distributions
echo "Architectures: $_repoarchitectures" >> $_repodir/conf/distributions
echo "Components: main" >> $_repodir/conf/distributions
echo "Description: A local package repository" >> $_repodir/conf/distributions
else
echo "Using existing repo configuration file $_repodir/conf/distributions"
fi

echo "Creating debian package repo"
set -e pipefail
sudo reprepro --basedir $_repodir includedeb $_codename $_pkgspath/*.deb
