#!/bin/bash
#SCRIPT FOR DEBIAN
#architecture: any
if [[ $EUID -ne 0 ]]; then
   echo "must do this as root" 1>&2
   exit 100
fi

_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}

#check if the hypervisorkey pckage is installed
#refuse to create hypervisor key package when this local installation is not running as HV
#TO DO: rewrite this check for debian
#pacman -Qi hypervisorconfig > /dev/null && echo "hypervisorkey package is installed, the node has been configured as a visor. Please uninstall it to do this." 1>&2 && exit 100
#add some color to output for readability.

_skydir="/opt/skywire"
_cachedir="${_skydir}/skycache"
#create build dir path
mkdir -p $_cachedir
[[ -d $_cachedir/hypervisorkey-1 ]] && rm -rf $_cachedir/hypervisorkey-1

#TO DO: automatically increment version
#copy build dir from its installed location - this dir only in the debian package for now
cp -rb $_skydir/hypervisorkey $_cachedir/hypervisorkey-1

#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat $_skydir/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
echo ${_hvisorkey} > $_cachedir/hypervisorkey-1/opt/skywire/hypervisorkey.txt

#OPTIONALLY prompt the user here to add more keys; skipped for automation

#create the hypervisorkey package
cd $_cachedir
dpkg-deb --build hypervisorkey-1
rm -rf $_cachedir/hypervisorkey-1

#set up repo
apt-repo-create

#instruct user on configuration
_lanip=$(sudo ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
_msg2 "#On the remote system, please manually add the following to /etc/apt/sources.list:"
echo -e "
deb [trusted=yes] http://${_lanip}:8079 sid main

"
#serve repo locally
_msg2 "enabling skycache systemd service and serving package repo now on http://${_lanip}:8079"
sudo systemctl enable --now skycache
