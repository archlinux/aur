#!/bin/bash
#disallow root as it can't create packages
if [[ $EUID -ne 0 ]]; then
   echo -e "must do this as root" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_package="skywire-save"
_config="skywire.json"
_config2="skywire-visor.json"
_configpath="/opt/skywire"
_yaycache="/opt/skywire"
_errmsg="${_red}a saved configuration is installed, why do you want to make the same thing again?${_nc}"
#check that the hypervisorkey package was not installed - avoid unintended misconfiguration
apt list ${_package} > /dev/null 2>&1 && echo -e $_errmsg 1>&2 && exit 100
#ensure build dir path
[[ -d ${_yaycache}/${_package}-1 ]] && rm -rf ${_yaycache}/${_package}-1
#copy build dir from its installed location
cp -rb ${_configpath}/${_package} ${_yaycache}/${_package}-1

sudo systemctl stop skywire.service
sudo systemctl stop skywire-visor.service

#back up configuration files
if [[ ! -f ${_configpath}/${_config} ]] ; then #no primary config file found
#check for backup config and use that or error
[[ -f ${_configpath}/${_config}.bak ]] && install -Dm644 ${_configpath}/${_config}.bak "${_yaycache}/${_package}-1/opt/skywire/${_config}" || echo "Error ${_configpath}/${_config} not found! Please run skywire-autoconfig as root to create the configs first!" && exit
else #config file exists
install -Dm644 ${_configpath}/${_config} "${_yaycache}/${_package}-1/opt/skywire/${_config}" && sudo mv ${_configpath}/${_config} ${_configpath}/${_config}.bak
fi
if [[ ! -f ${_configpath}/${_config2} ]] ; then #no secondary config found
[[ -f ${_configpath}/${_config2}.bak ]] && install -Dm644 ${_configpath}/${_config2}.bak "${_yaycache}/${_package}-1/opt/skywire/${_config2}" || echo #echo so script doesn't error
else #secondary config exists
install -Dm644 ${_configpath}/${_config2} "${_yaycache}/${_package}-1/opt/skywire/${_config2}" && sudo mv ${_configpath}/${_config2} ${_configpath}/${_config2}.bak
fi

if [[ -f ${_configpath}/users.db ]] ; then #check for users.db - that is the password file for the hypervisor UI
install -Dm600 ${_configpath}/users.db "${_yaycache}/${_package}-1/opt/skywire/users.db"
sudo mv ${_configpath}/users.db ${_configpath}/users.db.bak
else #check for backup of this file
if [[ -f ${_configpath}/users.db.bak ]] ; then
install -Dm600 ${_configpath}/users.db.bak ${_yaycache}/${_package}/opt/skywire/users.db
fi
fi
#create the skywire-save package and install it to complete the configuration process
cd ${_yaycache}
dpkg-deb --build ${_package}
dpkg -i *.deb
