#!/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
echo "Are you sure you want to reset the skywire configuration?"
read -p "This will delete the current keys and generate new ones [y/n]" -n 1 -r
[[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
echo
#remove skywire-save if it is installed
if pacman -Qs skywire-save > /dev/null ; then
  sudo pacman -R skywire-save || exit
fi
#make sure it's off first
echo "Halting Skywire."
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service
#remove old configs and backups
echo "Removing previous configuration files.."
[[ -f /opt/skywire/skywire.json ]] && rm /opt/skywire/skywire.json
[[ -f /opt/skywire/skywire.json.bak ]] && rm /opt/skywire/skywire.json.bak
[[ -f /opt/skywire/skywire-visor.json ]] && rm /opt/skywire/skywire-visor.json
[[ -f /opt/skywire/skywire-visor.json.bak ]] && rm /opt/skywire/skywire-visor.json.bak
echo "Reconfiguring Skywire"
skywire-autoconfig
