#!/usr/bin/bash
#skywire debian postrm script
#script is executed as root by default

rm -rf /opt/skywire
