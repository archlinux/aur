#!/bin/bash
rm -rf /opt/skywire
