#!/usr/bin/bash
#skywire debian postrm script
#script is executed as root by default
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service
systemctl disable --now readonly-cache.service
rm -rf /opt/skywire
