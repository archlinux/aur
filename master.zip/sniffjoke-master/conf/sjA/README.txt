sniffjoke-autotest support two "semi-secret" options, -s and -a

-s http://yourserver.tld/pe.php

    Your HTTP connection where reach pe.php, in this directory included

-a xx.yy.nn.kk

    Yout HTTP server IP ADDRESS

doing this, you will be able to autotest your location without use
the delirandom.net single point of failure.
