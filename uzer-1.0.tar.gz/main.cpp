#include <iostream>

using namespace std;

int main() {
    cout << "Uzer loh!" << endl;
    return 0;
}

