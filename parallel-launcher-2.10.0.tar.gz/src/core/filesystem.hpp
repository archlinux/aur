#ifndef SRC_CORE_FILESYSTEM_HPP_
#define SRC_CORE_FILESYSTEM_HPP_

#include <filesystem>
#include <functional>

#ifdef _WIN32
#include "src/polyfill/windows/unicode.hpp"
#endif

namespace fs = std::filesystem;

template<> struct std::hash<fs::path> {
	inline size_t operator()(const fs::path &path) const noexcept {
		return hash_value( path );
	}
};

namespace std::filesystem {
#ifdef _WIN32
	inline path to_path( const std::string &u8string ) {
		return path( Unicode::toUtf16( u8string ) );
	}
#else
	inline path to_path( const std::string &u8string ) {
		return path( u8string );
	}
#endif
}

#endif /* SRC_CORE_FILESYSTEM_HPP_ */
