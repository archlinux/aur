#ifndef SRC_CORE_CORES_HPP_
#define SRC_CORE_CORES_HPP_

#include "src/core/settings.hpp"
#include "src/core/json.hpp"
#include <functional>

struct CoreVersion {
	string commit;
	bool lock;
};

struct CoreVersions {
	CoreVersion parallel;
	CoreVersion mupen;
	int64 lastUpdateCheck;

	static const CoreVersions Default;
};

struct CommitInfo {
	string hash;
	string message;
	string date;
};

struct CoreBuild {
	CommitInfo commit;
	string downloadLink;
};

namespace JsonSerializer {
	template<> void serialize<CoreVersion>( JsonWriter &jw, const CoreVersion &obj );
	template<> CoreVersion parse<CoreVersion>( const Json &json );

	template<> void serialize<CoreVersions>( JsonWriter &jw, const CoreVersions &obj );
	template<> CoreVersions parse<CoreVersions>( const Json &json );
}

namespace CoreBuilds {

	void getLastKnownGood(
		EmulatorCore core,
		const string &branch,
		const string &laterThan,
		const std::function<void(const CoreBuild&)> &onSuccess,
		const std::function<void(void)> &onFailure
	);

	/*
	void getCommits(
		EmulatorCore,
		const string &maxDate,
		const std::function<void(const std::vector<CommitInfo>&)> &onSuccess,
		const std::function<void(void)> &onFailure
	);
	*/

}

#endif /* SRC_CORE_CORES_HPP_ */
