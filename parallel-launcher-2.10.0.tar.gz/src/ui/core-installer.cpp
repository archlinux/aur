#include "src/ui/core-installer.hpp"

#include <QMessageBox>
#include <QDateTime>
#include <cassert>
#include "src/polyfill/base-directory.hpp"
#include "src/ui/download-dialog.hpp"
#include "src/ui/core-finder-dialog.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/cores.hpp"
#include "src/core/time.hpp"
#include "src/core/zip.hpp"

static const char *s_unknownCorePathMsg = ""
	"Parallel Launcher cannot determine where to install this emulator core because "
	"the core directory is missing from your RetroArch config file, or a RetroArch "
	"configuration file cannot be found. If you have not yet run RetroArch, you may "
	"need to run it once to force this config file to be created.";


static bool installCoreSync( EmulatorCore core, const CoreBuild &coreBuild ) {
	const fs::path tempPath = BaseDir::temp() / "core.zip";
	fs::create_directories( BaseDir::temp() );

	if( !DownloadDialog::download( "Downloading core...", coreBuild.downloadLink, tempPath ) ) {
		QMessageBox::critical( nullptr, "Download Failed", "Failed to download emulator core" );
		return false;
	}

	if( !Zip::unzip( tempPath, RetroArch::getCorePath() ) ) {
		QMessageBox::critical( nullptr, "Download Failed", "Failed to install emulator core" );
		return false;
	}

	std::error_code err;
	fs::remove( tempPath, err );

	CoreVersions coreVersions = FileController::loadCoreVersions();
	coreVersions.lastUpdateCheck = Time::now();
	if( core == EmulatorCore::ParallelN64 ) {
		coreVersions.parallel.commit = coreBuild.commit.hash;
	} else {
		coreVersions.mupen.commit = coreBuild.commit.hash;
	}
	FileController::saveCoreVersions( coreVersions );

	QMessageBox::information( nullptr, "Installation Successful", "Core installed successfully." );
	return true;
}

bool CoreInstaller::requireCore( EmulatorCore core ) {
	if( core == EmulatorCore::UseDefault ) {
		core = FileController::loadAppSettings().defaultEmulator;
	}

	if( RetroArch::isEmulatorCoreInstalled( core ) ) {
		return true;
	}

	assert( core == EmulatorCore::ParallelN64 || core == EmulatorCore::Mupen64plusNext );

	if( QMessageBox::question( nullptr, "Install Emulator Core?", "This emulator core is not installed. Would you like to install it now?" ) != QMessageBox::Yes ) {
		return false;
	}

	const fs::path corePath = RetroArch::getCorePath();
	if( corePath.empty() ) {
		QMessageBox::critical( nullptr, "Unknown Core Directory", s_unknownCorePathMsg );
		return false;
	}

	CoreFinderDialog coreFinder( core );
	coreFinder.exec();

	const std::optional<CoreBuild> &coreBuild = coreFinder.coreBuild();
	if( coreBuild.has_value() ) {
		return installCoreSync( core, coreBuild.value() );
	}

	return false;
}

static void checkForUpdates(
	EmulatorCore core,
	std::function<void(void)> then
) {
	const CoreVersions &coreVerions = FileController::loadCoreVersions();
	if( !RetroArch::isEmulatorCoreInstalled( core ) ) {
		then();
		return;
	}

	const char *updateMessage;
	string currentCommit;
	string branch;
	if( core == EmulatorCore::ParallelN64 ) {
		if( coreVerions.parallel.lock ) {
			then();
			return;
		}
		updateMessage = "An update is available for ParallelN64. Would you like to install it now?";
		currentCommit = coreVerions.parallel.commit;
		branch = "master";
	} else {
		if( coreVerions.mupen.lock ) {
			then();
			return;
		}
		updateMessage = "An update is available for Mupen64Plus-Next. Would you like to install it now?";
		currentCommit = coreVerions.mupen.commit;
		branch = FileController::loadAppSettings().mupenDevBranch ? "develop" : "master";
	}

	CoreBuilds::getLastKnownGood(
		core,
		branch,
		currentCommit,
		[=](const CoreBuild &build) {
			if( QMessageBox::question( nullptr, "Core Update Available", updateMessage ) == QMessageBox::Yes ) {
				installCoreSync( core, build );
			}
			then();
		},
		then
	);
}

static inline bool checkSchedule() {
	const QDate now = QDateTime::currentDateTime().date();
	const QDate lastUpdate = QDateTime::fromSecsSinceEpoch( FileController::loadCoreVersions().lastUpdateCheck ).date();

	if( now.year() != lastUpdate.year() ) {
		return true;
	}

	switch( FileController::loadAppSettings().coreUpdateInterval ) {
		case CoreUpdateInterval::EveryLaunch:
			return true;
		case CoreUpdateInterval::Daily:
			return now.dayOfYear() != lastUpdate.dayOfYear();
		case CoreUpdateInterval::Weekly:
			return now.weekNumber() != lastUpdate.weekNumber();
		case CoreUpdateInterval::Monthly:
			return now.month() != lastUpdate.month();
		default:
			return false;
	}
}

void CoreInstaller::checkForUpdatesAsync( bool force ) {
	if( !force && !checkSchedule() ) {
		return;
	}

	checkForUpdates(
		EmulatorCore::ParallelN64,
		[=]() {
			checkForUpdates(
				EmulatorCore::Mupen64plusNext,
				[](){
					CoreVersions coreVersions = FileController::loadCoreVersions();
					coreVersions.lastUpdateCheck = Time::now();
					FileController::saveCoreVersions( coreVersions );
				}
			);
		}
	);
}
