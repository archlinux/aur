#ifndef SRC_UI_CORE_INSTALLER_HPP_
#define SRC_UI_CORE_INSTALLER_HPP_

#include "src/core/settings.hpp"

namespace CoreInstaller {

	extern bool requireCore( EmulatorCore core );
	extern void checkForUpdatesAsync( bool force );

}



#endif /* SRC_UI_CORE_INSTALLER_HPP_ */
