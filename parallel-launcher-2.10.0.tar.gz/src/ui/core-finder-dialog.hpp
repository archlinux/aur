#ifndef SRC_UI_CORE_FINDER_DIALOG_HPP_
#define SRC_UI_CORE_FINDER_DIALOG_HPP_

#include <QProgressDialog>
#include <optional>
#include <memory>
#include "src/core/settings.hpp"
#include "src/core/cores.hpp"

class CoreFinderDialog : public QProgressDialog {

	private:
	const EmulatorCore m_core;
	std::optional<CoreBuild> m_build;
	std::shared_ptr<bool> m_dialogOpen;

	public:
	CoreFinderDialog( EmulatorCore core );
	~CoreFinderDialog() {}

	inline const std::optional<CoreBuild> &coreBuild() const noexcept {
		return m_build;
	}

	protected:
	void showEvent( QShowEvent *event ) override;
	void closeEvent( QCloseEvent *event ) override;

};



#endif /* SRC_UI_CORE_FINDER_DIALOG_HPP_ */
