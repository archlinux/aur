#include "src/ui/direct-play-window.hpp"
#include "ui_direct-play-window.h"

#include "src/core/file-controller.hpp"
#include "src/ui/icons.hpp"

DirectPlayWindow::DirectPlayWindow( const fs::path &romPath ) :
	QMainWindow( nullptr ),
	m_romPath( romPath ),
	m_ui( new Ui::DirectPlayWindow )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );

	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginParallelRadio, (int)GfxPlugin::ParaLLEl );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlideRadio, (int)GfxPlugin::Glide64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginAngrylionRadio, (int)GfxPlugin::Angrylion );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlidenRadio, (int)GfxPlugin::GlideN64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginRiceRadio, (int)GfxPlugin::Rice );

	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginParallelRadio2, (int)GfxPlugin::ParaLLEl );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginAngrylionRadio2, (int)GfxPlugin::Angrylion );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginGlidenRadio2, (int)GfxPlugin::GlideN64 );

	const AppSettings &settings = FileController::loadAppSettings();
	m_ui->emulatorTabs->setCurrentIndex( (int)settings.defaultEmulator - 1 );
	m_ui->parallelPluginRadioGroup->button( (int)settings.defaultParallelPlugin )->setChecked( true );
	m_ui->mupenPluginRadioGroup->button( (int)settings.defaultMupenPlugin )->setChecked( true );
	m_ui->performanceWarningLabel->setVisible( false );
	refreshGlidenWarning();
}

DirectPlayWindow::~DirectPlayWindow() {
	delete m_ui;
}

ROM DirectPlayWindow::getRomInfo() const {
	return ROM{
		/* name */ m_romPath.stem().u8string(),
		/* internalName */ RomUtil::getInternalName( m_romPath ),
		/* path */ m_romPath,
		/* emulator */ (EmulatorCore)(m_ui->emulatorTabs->currentIndex() + 1),
		/* parallelPlugin */ (GfxPlugin)m_ui->parallelPluginRadioGroup->checkedId(),
		/* mupenPlugin */ (GfxPlugin)m_ui->mupenPluginRadioGroup->checkedId(),
		/* lastPlayed */ 0,
		/* playTime */ 0,
		/* tags */ { "Automatically Added" },
		/* notes */ "",
		/* overclockCPU */ m_ui->overclockCpuCheckbox->isChecked(),
		/* overclockVI */ m_ui->overclockViCheckbox->isChecked(),
		/* fileVersion */ RomUtil::getLastModified( m_romPath ),
		/* crc32 */ RomUtil::getCrc32( m_romPath ),
		/* inputModeId */ m_ui->inputModeSelect->getSelected().id,
		/* widescreen */ m_ui->widescreenCheckbox->isChecked()
	};
}

void DirectPlayWindow::refreshGlidenWarning() {
	m_ui->pluginWarningLabel->setVisible(
		m_ui->emulatorTabs->currentIndex() == 0 &&
		m_ui->pluginGlidenRadio->isChecked()
	);
}

void DirectPlayWindow::accept() {
	hide();
	emit play();
}
