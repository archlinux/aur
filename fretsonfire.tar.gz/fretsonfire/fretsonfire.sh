#!/bin/bash
cd /usr/share/fretsonfire/bin
python2 FretsOnFire.py
