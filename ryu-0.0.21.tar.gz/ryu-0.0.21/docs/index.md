# Ryu

> *"Nothing ever works on the first compile. That's what makes the second one feel like a power-up arc."*

Ryu is a set of C++/QML components for Qt 6, built because the existing ones were either ugly or didn't exist. Material 3 styling, springy animations, and widgets that have seen things.

It is a personal project. It works on my machine. Your machine is a side quest.

## What's inside

| Module | What it does | Docs |
|---|---|---|
| **Extraa** | Material 3 widgets: `WavyProgress`, `MaterialSlider`, `MaterialIconButton`, `MaterialButtonGroup` | Partly |
| **Shapes** | `MaterialShape`, with 35 shapes that morph into each other using springs | Yes |
| **Cleave** | Audio visualizer. PipeWire in, FFT out, bars go brrr | Soon™ |
| **Clipsh** | Clipboard history on top of `cliphist` and `wl-copy` | Soon™ |
| **Sqliter** | SQLite-backed events storage | Soon™ |
| **Warsa** | Nepali (BS) calendar logic | Soon™ |

"Soon™" means the code exists and the documentation is still in its training arc.

## Installation

### Arch Linux (AUR)

Ryu is on the AUR in two flavors. Pick one, because they conflict with each other.

=== "ryu-bin (prebuilt)"

    Installs the release binaries. Fast, no compiler needed.

    ```bash
    paru -S ryu-bin
    ```

=== "ryu (from source)"

    Builds from the tagged release with CMake and Ninja. Slower, but compiled against your own Qt.

    ```bash
    paru -S ryu
    ```

Any AUR helper works (`yay -S ryu-bin`). To install by hand:

```bash
git clone https://aur.archlinux.org/ryu-bin.git
cd ryu-bin
makepkg -si
```

Dependencies (`qt6-base`, `qt6-declarative`, `cliphist`, `wl-clipboard`, `pipewire`) are pulled in automatically. The modules are installed to `/usr/lib/qt6/qml/Ryu/`, so they work with any Qt 6 QML app or Quickshell config, no extra import paths needed:

```qml
import Ryu.Extraa
import Ryu.Shapes
```

!!! note "Module not installed?"
    If you see `module "Ryu.Extraa" is not installed`, the package isn't installed yet. `makepkg` only builds it, so run `makepkg -si` (or `sudo pacman -U` on the built package) and try again.

### Other distros

No packages yet. [Build from source](#build-from-source) and install with `ninja -C build install`.

## Build from source

```bash
git clone https://github.com/Happilli/ryu
cd ryu
./build.sh            # configure + build with CMake and Ninja
./build.sh --clean    # burn the build directory and start over
```

Then, in QML:

```qml
import Ryu.Extraa

MaterialSlider {
    width: 240
    value: 0.5
    onMoved: console.log(value)
}
```

To try a file without an app around it, point the `qml` tool at the build directory:

```bash
qml -I build test.qml
```

## Requirements

You'll need:

- **Qt 6** with Quick and Sql
- **CMake** and **Ninja**
- A font with the icons you want (a Nerd Font or Material Symbols), because icon glyphs without one are just tofu and regret

And, depending on what you use:

- **PipeWire** for Cleave
- **cliphist** and **wl-clipboard** for Clipsh (Wayland only)
- **Python** with `requests` and `beautifulsoup4` for the Warsa month-length scraper

On Arch, the AUR packages handle all of this for you.

## A note on colors

Every Extraa component defaults to the classic M3 purple. Set your own colors, or enjoy purple forever:

```qml
MaterialSlider {
    color: "#a0ec4c"
    handleColor: "#a0ec4c"
    trackColor: "#32362b"
}
```

## Known quirks

!!! warning "Things that will bite you"
    - `WavyProgress` animates by default (`indeterminate: true`). A bare one spins forever, like a deadline.
    - Changing `MaterialSlider.orientation` swaps width and height. Set the size in `Component.onCompleted` if they start fighting.
    - Icon glyphs need `iconFont` set, or you get empty boxes.

## Contributing

Found a bug? Open an issue. Fixed one? Open a PR. Both are welcome, and neither will be judged harshly, only silently.

## License

BSD 2-Clause. Do what you want, keep the notice, and don't blame me when it breaks.
