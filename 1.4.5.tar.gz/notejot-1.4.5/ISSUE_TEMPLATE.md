## Hello! If you found an error in this app, follow this template:

* Use a descriptive title
* Describe the issue
* State what version you're using
* Take a screenshot of the problem, then use the Markdown property for it:  
   `![any_name_here](url_here)`
* If the problem needs it, show me a video of the problem with Screenkey running in the background.


Thanks!
