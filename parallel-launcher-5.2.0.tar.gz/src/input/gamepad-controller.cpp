#ifdef __APPLE__
	#include "src/input/hid-controller.cpp.inc"
#else
	#include "src/input/sdl-controller.cpp.inc"
#endif
