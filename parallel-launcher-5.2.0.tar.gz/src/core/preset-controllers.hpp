#ifndef SRC_CORE_PRESET_CONTROLLERS_HPP_
#define SRC_CORE_PRESET_CONTROLLERS_HPP_

#include "src/core/controller.hpp"

enum class ControllerType {
	Gamecube,
	XBox360,
	Nintendo64,
	Other
};

ControllerType getControllerType( const ControllerId &controllerId );

namespace DefaultProfile {
	extern const ControllerProfile XBox360;
#ifndef __APPLE__
	extern const ControllerProfile Gamecube;
	extern const ControllerProfile Nintendo64;
#endif

	extern bool exists( const string &name );
}

namespace DefaultInputModes {
	extern const InputMode Normal;
	extern const InputMode DualAnalog;
	extern const InputMode GoldenEye;
	extern const InputMode Clone;

	extern bool exists( const Uuid &uuid );
}


#endif /* SRC_CORE_PRESET_CONTROLLERS_HPP_ */
