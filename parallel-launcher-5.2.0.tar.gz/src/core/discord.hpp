#ifndef SRC_CORE_DISCORD_HPP_
#define SRC_CORE_DISCORD_HPP_

#include "src/types.hpp"

namespace Discord {

	bool pluginInstalled();
	void setNowPlaying( const string &gameName );
	inline void clearNowPlaying() { setNowPlaying( "" ); }

}



#endif /* SRC_CORE_DISCORD_HPP_ */
