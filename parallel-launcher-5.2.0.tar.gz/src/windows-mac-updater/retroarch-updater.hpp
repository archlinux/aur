#ifndef SRC_WINDOWS_MAC_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_
#define SRC_WINDOWS_MAC_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_

namespace RetroArchUpdater {

	extern bool install();
	extern void update();

}

#endif /* SRC_WINDOWS_MAC_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_ */
