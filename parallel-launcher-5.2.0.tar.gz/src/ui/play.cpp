#include "src/ui/play.hpp"

#include <fstream>
#include <ios>
#include <QCoreApplication>
#include <QMessageBox>
#include "src/ui/singleplayer-controller-select-dialog.hpp"
#include "src/ui/multiplayer-controller-select-dialog.hpp"
#include "src/ui/now-playing-window.hpp"
#include "src/ui/process-awaiter.hpp"
#include "src/ui/core-installer.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/special-groups.hpp"
#include "src/core/controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/discord.hpp"
#include "src/core/time.hpp"
#include "src/core/sm64.hpp"
#include "src/db/data-provider.hpp"
#include "src/rhdc/core/layout.hpp"
#include "src/rhdc/web/api.hpp"

static const char *s_crashMessageParallel = QT_TRANSLATE_NOOP( "Game", ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. Alternatively, if you have a very old onboard graphics card, it is possible that Vulkan is not "
	"supported on your system. In either case, using another graphics plugin might resolve the issue." );

static const char *s_crashMessageAngrylion = QT_TRANSLATE_NOOP( "Game", ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. If this is the case, try running the ROM with another graphics plugin instead." );

static const char *s_crashMessageDefault = QT_TRANSLATE_NOOP( "Game", ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM is most likely corrupt." );

static ControllerProfile getControllerProfile( const ConnectedGamepad &controller ) {
	if( controller.id < 0 ) {
		return FileController::loadLastControllerProfile();
	}

	const HashMap<Uuid,string> mappings = FileController::loadControllerMappings();
	if( mappings.count( controller.info.uuid ) > 0 ) {
		const string &activeProfile = mappings.at( controller.info.uuid );

		const std::map<string, ControllerProfile> profiles = FileController::loadControllerProfiles();
		if( profiles.count( activeProfile ) > 0 ) {
			return profiles.at( activeProfile );
		}
	}

	switch( getControllerType( controller.info.controllerId ) ) {
#ifndef __APPLE__
		case ControllerType::Gamecube:
			return DefaultProfile::Gamecube;
		case ControllerType::Nintendo64:
			return DefaultProfile::Nintendo64;
#endif
		default:
			return DefaultProfile::XBox360;
	}
}

static inline ushort getStarCount( const RomFile &romFile, const string &hackId ) {
	const fs::path saveFilePath = RetroArch::getSaveFilePath( romFile.path );
	if( !fs::existsSafe( saveFilePath ) ) return 0;

	if( StarLayout::hasLayout( hackId ) ) {
		StarLayout layout;
		if( StarLayout::tryLoadLayout( hackId, layout ) ) {
			return layout.countStars( saveFilePath );
		}
	}

	std::ifstream saveFile( saveFilePath.u8string(), std::ios_base::in | std::ios_base::binary );
	SM64::SaveFile saveData = SM64::SaveFile::read( saveFile );
	if( FileController::loadRhdcSettings().checkAllSaveSlots ) {
		ushort starCount = 0;
		for( int i = 0; i < 4; i++ ) {
			const ushort slotStars = (ushort)saveData.slot( i ).countStars();
			starCount = slotStars > starCount ? slotStars : starCount;
		}
		return starCount;
	} else {
		return (ushort)saveData.slot( 0 ).countStars();
	}
}

static inline string getRomName(
	const RomFile &romFile,
	const RomInfo &romInfo
) {
	RhdcHack hack;
	if( DataProvider::tryFetchRhdcHackByChecksum( romInfo.sha1, &hack ) ) {
		return hack.info.name;
	} else if( !romInfo.name.empty() ) {
		return romInfo.name;
	} else {
		return romFile.path.stem().u8string();
	}
}

static inline bool playGame(
	const RomFile &romFile,
	const RomInfo &romInfo,
	const std::vector<PlayerController> &players,
	bool bindSavestate,
	const std::function<void(int64)> &callback
) {
	const AppSettings &settings = FileController::loadAppSettings();
	const EmulatorCore emulatorCore = (romInfo.emulator == EmulatorCore::UseDefault) ? settings.defaultEmulator : romInfo.emulator;
	if( !CoreInstaller::requireCore( emulatorCore ) ) return false;

	GfxPlugin gfxPlugin;
	AsyncProcess *emulator = new AsyncProcess();
	try {
		*emulator = RetroArch::launchRom(
			romFile.path,
			settings,
			players,
			romInfo,
			bindSavestate,
			&gfxPlugin
		);
	} catch( ... ) {
		QMessageBox::critical(
			nullptr,
			QCoreApplication::translate( "Game", "Emulator Missing" ),
			QCoreApplication::translate( "Game", "Failed to launch emulator. It does not appear to be installed." )
		);
		return false;
	}

	NowPlayingWindow *nowPlayingWindow = nullptr;
	if( !settings.hideWhenPlaying ) {
		nowPlayingWindow = new NowPlayingWindow( emulator, romFile.path, romInfo.sha1, romInfo.playTime );
		nowPlayingWindow->show();
	}

	const bool setDiscordStatus = settings.discordIntegration;
	if( setDiscordStatus ) Discord::setNowPlaying( getRomName( romFile, romInfo ) );
	ProcessAwaiter::QtSafeAwait(
		emulator,
		[=]( [[maybe_unused]] int64 exitCode, int64 runtimeMs ) {
			if( setDiscordStatus ) Discord::clearNowPlaying();

			delete emulator;
			if( nowPlayingWindow != nullptr ) {
				nowPlayingWindow->close();
				nowPlayingWindow->deleteLater();
			}

			const int64 newPlayTime = romInfo.playTime + runtimeMs;
			if( runtimeMs > 0 ) {
				const int64 lastPlayed = Time::nowMs();
				DataProvider::updatePlayTime(
					romInfo.sha1,
					lastPlayed,
					newPlayTime
				);

				RhdcHack hack;
				if( DataProvider::tryFetchRhdcHackByChecksum( romInfo.sha1, &hack ) ) {
					const string hackId = hack.info.hackId;
					ushort starProgress = hack.progress.stars;

					const bool hackHasStars = hack.info.starCount > 0;
					if( hackHasStars ) {
						starProgress = getStarCount( romFile, hack.info.hackId );
						starProgress = starProgress > hack.info.starCount ? hack.info.starCount : starProgress;
						DataProvider::updateRhdcStarProgress( hackId, starProgress, starProgress == hack.info.starCount );

						if( newPlayTime >= 300000 || starProgress > 0 ) {
							DataProvider::removeFromGroup( romInfo.sha1, SpecialGroups::WantToPlay );
							if( starProgress == hack.info.starCount ) {
								DataProvider::removeFromGroup( romInfo.sha1, SpecialGroups::InProgress );
								DataProvider::addToGroup( romInfo.sha1, SpecialGroups::InProgress );
							} else {
								DataProvider::addToGroup( romInfo.sha1, SpecialGroups::InProgress );
							}
						}
					}

					const string sha1 = romInfo.sha1;
					RhdcApi::getStarpowerAsync( hackId, [=](Starpower &starpower){
						if( starpower.playTime > newPlayTime ) {
							DataProvider::updatePlayTime( sha1, lastPlayed, starpower.playTime );
						} else if( starpower.playTime < newPlayTime ) {
							RhdcApi::submitPlayTimeAsync( hackId, newPlayTime, [](){}, [](ApiErrorType){} );
						}

						if( hackHasStars ) {
							if( starpower.progress.stars > starProgress ) {
								DataProvider::updateRhdcStarProgress( hackId, starpower.progress.stars, starpower.progress.completed );
							} else if( starpower.progress.stars < starProgress ) {
								RhdcApi::submitStarProgressAsync( hackId, starProgress, [](){}, RhdcApi::logApiError( "Failed to submit hack progress" ) );
							}
						}
					}, RhdcApi::logApiError( "Failed to fetch hack progress" ) );

				}
			}

			if( runtimeMs < 2000 ) {
				const char *errorMessage;
				switch( gfxPlugin ) {
					case GfxPlugin::ParaLLEl:
						errorMessage = s_crashMessageParallel;
						break;
					case GfxPlugin::Angrylion:
						errorMessage = s_crashMessageAngrylion;
						break;
					default:
						errorMessage = s_crashMessageDefault;
						break;
				}
				QMessageBox::critical(
					nullptr,
					QCoreApplication::translate( "Game", "Possible ROM Error" ),
					QCoreApplication::translate( "Game", errorMessage )
				);
			}

			callback( runtimeMs );
		}
	);

	return true;
}

static inline ConnectedGamepad getActiveController() {
	std::vector<ConnectedGamepad> connectedControllers = GamepadController::instance().getConnected();
	if( connectedControllers.empty() ) {
		return ConnectedGamepad{ -1, ControllerInfo() };
	} else if( connectedControllers.size() == 1 ) {
		return connectedControllers[0];
	}

	const AppSettings settings = FileController::loadAppSettings();
	if( settings.preferredController.has_value() ) {
		for( const ConnectedGamepad &controller : connectedControllers ) {
			if( controller.info.uuid == settings.preferredController.value() ) {
				return controller;
			}
		}
	}

	SingleplayerControllerSelectDialog dialog( connectedControllers );
	dialog.exec();
	return dialog.getSelectedController();
}

static inline bool usesTwoPorts( const Uuid &inputModeId ) {
	const std::map<Uuid,InputMode> inputModes = FileController::loadInputModes();
	if( inputModes.count( inputModeId ) > 0 ) {
		return inputModes.at( inputModeId ).usesTwoPorts();
	}

	return false;
}

bool Game::play(
	const RomFile &romFile,
	const RomInfo &romInfo,
	bool multiplayer,
	const std::function<void(int64)> &callback
) {
	std::vector<PlayerController> players;
	players.reserve( multiplayer ? 4 : 1 );

	bool bindSavestate;
	if( multiplayer ) {
		MultiplayerControllerSelectDialog dialog( usesTwoPorts( romInfo.inputModeId ) );
		if( dialog.exec() != QDialog::Accepted ) {
			return false;
		}

		const std::array<ConnectedGamepad,4> controllers = dialog.getControllers();
		for( size_t i = 0; i < 4; i++ ) {
			if( controllers[i].id < 0 ) continue;

			while( i > players.size() ) players.push_back({ DefaultProfile::XBox360, Uuid() });
			players.push_back({ getControllerProfile( controllers[i] ), controllers[i].info.uuid });
		}

		if( players.empty() ) {
			players.push_back({ FileController::loadLastControllerProfile(), Uuid() });
		}

		bindSavestate = dialog.canBindSavestates();
	} else {
		const ConnectedGamepad activeController = getActiveController();
		ControllerProfile profile = getControllerProfile( activeController );
		if( activeController.id >= 0 ) {
			FileController::saveLastControllerProfile( profile.name );
		}
		players.push_back({ std::move( profile ), activeController.info.uuid });
		bindSavestate = true;
	}

	return playGame( romFile, romInfo, players, bindSavestate, callback );
}
