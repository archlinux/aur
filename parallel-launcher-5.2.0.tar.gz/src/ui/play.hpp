#ifndef SRC_UI_PLAY_HPP_
#define SRC_UI_PLAY_HPP_

#include <functional>
#include "src/core/rom.hpp"

namespace Game {

	extern bool play(
		const RomFile &romFile,
		const RomInfo &romInfo,
		bool multiplayer,
		const std::function<void(int64)> &callback
	);

}



#endif /* SRC_UI_PLAY_HPP_ */
