#include "src/rhdc/core/sync.hpp"

#include <algorithm>
#include <QCoreApplication>
#include <QFile>
#include "src/polyfill/base-directory.hpp"
#include "src/rhdc/core/layout.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/special-groups.hpp"
#include "src/core/logging.hpp"
#include "src/core/uuid.hpp"
#include "src/core/sm64.hpp"
#include "src/db/data-provider.hpp"
#include "src/db/transaction.hpp"
#include "src/ui/toast.hpp"

static void addHackVersion(
	const FollowedHack &hack,
	const RhdcHackVersionExt &version
) {
	EmulatorCore emulator = EmulatorCore::UseDefault;
	GfxPlugin parallelPlugin = GfxPlugin::UseDefault;
	GfxPlugin mupenPlugin = GfxPlugin::UseDefault;

	if( version.plugin.has_value() ) {
		const GfxPlugin recommendedPlugin = version.plugin.value();
		switch( recommendedPlugin ) {
			case GfxPlugin::Angrylion:
			case GfxPlugin::ParaLLEl:
				parallelPlugin = mupenPlugin = recommendedPlugin;
				break;
			case GfxPlugin::GlideN64:
				#ifndef __APPLE__
				emulator = EmulatorCore::Mupen64plusNext;
				#endif
				parallelPlugin = GfxPlugin::Glide64;
				mupenPlugin = GfxPlugin::GlideN64;
				break;
			default:
				emulator = EmulatorCore::ParallelN64;
				parallelPlugin = recommendedPlugin;
				mupenPlugin = GfxPlugin::GlideN64;
				break;
		}
	}

	DataProvider::addRomInfo({
		version.sha1,
		"",
		"",
		emulator,
		parallelPlugin,
		mupenPlugin,
		Flags::has( version.pluginFlags, PluginFlags::UpscaleTexrects ),
		Flags::has( version.pluginFlags, PluginFlags::EmulateFramebuffer ),
		Flags::has( version.pluginFlags, PluginFlags::AcccurateDepthCompare ),
		0,
		0,
		std::set<string>( hack.groups.begin(), hack.groups.end() ),
		true,
		false,
		0,
		DefaultInputModes::Normal.id,
		false
	});
}

void RHDC::sync( const std::function<void(bool)> &callback ) {
	using namespace RHDC;

	RhdcApi::getFollowedHacksAsync(
		[callback](HashMap<string,FollowedHack> &hacks) {
			SqlTransaction transaction;

			DataProvider::clearRhdcHacks();
			const HashSet<string> knownHashes = DataProvider::fetchAllKnownChecksums();
			std::vector<string> undownloadedHacks;

			foreach_cvalue( hack, hacks ) {
				DataProvider::addOrUpdateRhdcHack( hack.info );
				bool knownHack = false;

				int i = 0;
				for( const RhdcHackVersionExt &version : hack.versions ) {
					DataProvider::addRhdcHackVersion( hack.info.hackId, version.sha1, version.name, i++ );
					if( knownHashes.count( version.sha1 ) > 0 ) {
						knownHack = true;
					} else {
						addHackVersion( hack, version );
					}
				}

				for( const string &author : hack.authors ) {
					DataProvider::addRhdcHackAuthor( hack.info.hackId, author );
				}

				if( !knownHack ) {
					undownloadedHacks.push_back( hack.info.hackId );
				} else {
					std::set<string> localGroups = DataProvider::fetchGroupsForRhdcHack( hack.info.hackId );
					for( const string &group : hack.groups ) {
						if( localGroups.count( group ) > 0 ) {
							localGroups.erase( group );
						} else {
							DataProvider::addRhdcHackToGroup( hack.info.hackId, group );
						}
					}

					for( const string &group : localGroups ) {
						if( group == SpecialGroups::Favourites ) {
							RhdcApi::addHackToListAsync( hack.info.hackId, "Favorites", [](){}, RhdcApi::logApiError( "Failed to add hack to list" ) );
						} else if( !group.empty() && group[0] != (char)1 ) {
							RhdcApi::addHackToListAsync( hack.info.hackId, group, [](){}, RhdcApi::logApiError( "Failed to add hack to list" ) );
						}
					}

					if( !hack.layoutUrl.empty() && !StarLayout::hasLayout( hack.info.hackId ) ) {
						QFile *layoutFile = new QFile( (BaseDir::temp() / Uuid::Random().toString()).u8string().c_str() );
						layoutFile->open( QIODevice::WriteOnly | QIODevice::Truncate );
						const string hackId = hack.info.hackId;
						RhdcApi::downloadFile( hack.layoutUrl, layoutFile, [](int64,int64){}, [hackId,layoutFile](){
							layoutFile->flush();
							layoutFile->close();
							layoutFile->rename( StarLayout::layoutPath( hackId ).u8string().c_str() );
							layoutFile->deleteLater();
						}, RhdcApi::logApiError( "Failed to download star layout" ) );
					} else if( !hack.jsmlUrl.empty() && !StarLayout::hasLayout( hack.info.hackId ) ) {
						QFile *layoutFile = new QFile( (BaseDir::temp() / Uuid::Random().toString()).u8string().c_str() );
						layoutFile->open( QIODevice::WriteOnly | QIODevice::Truncate );
						const string hackId = hack.info.hackId;
						RhdcApi::downloadFile( hack.jsmlUrl, layoutFile, [](int64,int64){}, [hackId,layoutFile](){
							layoutFile->flush();
							layoutFile->close();
							layoutFile->rename( StarLayout::jsmlPath( hackId ).u8string().c_str() );
							layoutFile->deleteLater();
						}, RhdcApi::logApiError( "Failed to download star layout" ) );
					}
				}
			}
			transaction.commit();

			for( const string &hackId : undownloadedHacks ) {
				const FollowedHack &hack = hacks.at( hackId );
				const RhdcHackVersionExt &latestVersion = hack.versions.at( 0 );
				if( hack.versions.empty() ) continue;

				DataProvider::addRomFile({
					RhdcApi::getDownloadUrl( hack.info.slug, latestVersion.name ),
					0,
					latestVersion.sha1,
					false
				});
			}

			RhdcApi::getStarpowerAsync(
				[callback](HashMap<string,Starpower> &serverStarpower) {
					const HashMap<string,StarpowerExt> clientStarpower = DataProvider::fetchAllStarpower();
					SqlTransaction transaction;

					for( const auto &[hackId, starpower] : serverStarpower ) {
						if( clientStarpower.count( hackId ) <= 0 ) {
							DataProvider::updateRhdcProgress( hackId, starpower.progress );
							DataProvider::suggestRhdcHackPlayTime( hackId, starpower.playTime );
							continue;
						}

						const StarpowerExt &localStarpower = clientStarpower.at( hackId );
						const RhdcHackProgress &clientProgress = localStarpower.progress;
						const RhdcHackProgress &serverProgress = starpower.progress;

						const RhdcHackProgress newProgress = {
							serverProgress.rating,
							serverProgress.difficulty,
							std::max( clientProgress.stars, serverProgress.stars ),
							clientProgress.completed || serverProgress.completed
						};

						if( clientProgress != newProgress ) {
							DataProvider::updateRhdcProgress( hackId, newProgress );
						}

						if( serverProgress != newProgress ) {
							if( localStarpower.starCount > 0 ) {
								RhdcApi::submitStarProgressAsync( hackId, newProgress.stars, [](){}, RhdcApi::logApiError( "Failed to submit hack progress" ) );
							} else {
								RhdcApi::submitCompletionAsync( hackId, newProgress.completed, [](){}, RhdcApi::logApiError( "Failed to submit hack progress" ) );
							}
						}

						if( starpower.playTime < localStarpower.playTime ) {
							RhdcApi::submitPlayTimeAsync( hackId, localStarpower.playTime, [](){}, [](ApiErrorType){} );
						} else if( starpower.playTime > localStarpower.playTime ) {
							DataProvider::suggestRhdcHackPlayTime( hackId, starpower.playTime );
						}
					}
					transaction.commit();

					callback( true );
				},
				[callback](ApiErrorType) {
					logError( "Failed to sync progress with romhacking.com" );
					ToastMessageManager::display( ToastType::Error, QCoreApplication::translate( "RhdcSync", "Failed to sync progress with romhacking.com" ) );
					callback( true );
				}
			);
		},
		[callback](ApiErrorType err) {
			if( err != ApiErrorType::NotAuthorized && err != ApiErrorType::RegistrationRequired ) {
				ToastMessageManager::display( ToastType::Error, QCoreApplication::translate( "RhdcSync", "Failed to connect to romhacking.com" ) );
			}
			callback( false );
		}
	);
}

void RHDC::moveRhdcFolder( const fs::path &oldDir, const fs::path &newDir ) {
	fs::error_code err;
	fs::create_directories( newDir, err );
	for( const auto &p : fs::directory_iterator( oldDir ) ) {
		if( !fs::isRegularFileSafe( p.path() ) ) continue;
		if( p.path().extension() != ".z64" ) continue;
		fs::rename( p.path(), newDir / p.path().filename(), err );
	}
}
