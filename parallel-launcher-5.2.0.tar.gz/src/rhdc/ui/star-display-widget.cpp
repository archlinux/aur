#include "src/rhdc/ui/star-display-widget.hpp"

#include <fstream>
#include <ios>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QByteArray>
#include <QImage>
#include <QLabel>
#include <QFile>
#include <QIcon>
#include "src/core/numeric-string.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/buffer.hpp"

static QPixmap pixmapFromData( const std::vector<ubyte> &data ) {
	if( data.empty() ) return QPixmap();
	const QByteArray imageData = QByteArray::fromRawData( (char*)data.data(), (int)data.size() );
	return QPixmap::fromImage( QImage::fromData( imageData ) );
}

StarDisplayWidget::StarDisplayWidget(
	QWidget *parent,
	StarLayout &&layout,
	bool editable
) :
	QTabWidget( parent ),
	m_layout( layout )
{
	setTabBarAutoHide( true );

	QPixmap collectedStarImage = pixmapFromData( m_layout.collectedStarIcon );
	if( collectedStarImage.isNull() ) {
		collectedStarImage = QIcon( ":/symbol/star.png" ).pixmap( 24, 24 );
	}

	QPixmap missingStarImage = pixmapFromData( m_layout.missingStarIcon );
	if( missingStarImage.isNull() ) {
		QImage shadow = missingStarImage.toImage().convertToFormat( QImage::Format_ARGB32 );
		uint *pixels = (uint*)shadow.bits();
		for( qsizetype i = 0; i < shadow.sizeInBytes() / 4; i++ ) {
			pixels[i] = (pixels[i] & 0xFF000000u) | 0x00666666u;
		}
		missingStarImage = QPixmap::fromImage( shadow );
	}

	for( int i = 0; i < (int)m_layout.numSlots; i++ ) {
		QWidget *tab = new QWidget();
		QHBoxLayout *columns = new QHBoxLayout( tab );
		QVBoxLayout *leftCol = new QVBoxLayout();
		QVBoxLayout *rightCol = new QVBoxLayout();
		tab->setLayout( columns );
		columns->addLayout( leftCol );
		columns->addStretch();
		columns->addLayout( rightCol );
		if( m_layout.numSlots <= 26 ) {
			addTab( tab, ("MARIO "s + (char)('A' + i)).c_str() );
		} else {
			addTab( tab, ("MARIO "s + Number::toString( i )).c_str() );
		}

		const uint slotStart = m_layout.slotsStart + (i * m_layout.slotSize);
		const uint activeBit = m_layout.activeBit + (8 * slotStart);
		for( const StarLayout::Group &group : m_layout.groups ) {
			QVBoxLayout *uiColumn = group.leftSide ? leftCol : rightCol;

			QHBoxLayout* titleLayout = new QHBoxLayout();
			titleLayout->addStretch();
			titleLayout->addWidget( new QLabel( group.name.c_str() ) );
			titleLayout->addStretch();

			uiColumn->addLayout( titleLayout );

			QGridLayout *uiGrid = new QGridLayout();
			int row = 0;
			for( const StarLayout::Course &course : group.courses ) {
				QLabel *label = new QLabel( course.name.c_str() );
				label->setAlignment( Qt::AlignRight );
				uiGrid->addWidget( label, row, 0 );

				QHBoxLayout* uiStars = new QHBoxLayout();
				uiStars->setDirection( QBoxLayout::LeftToRight );
				for( const StarLayout::StarData &starData : course.stars ) {
					StarSetUi *starSet = new StarSetUi(
						nullptr,
						collectedStarImage,
						missingStarImage,
						editable,
						slotStart + starData.offset,
						activeBit,
						starData.mask
					);

					uiStars->addLayout( starSet );
					m_starSets.push_back( starSet );
				}

				uiStars->addStretch();
				uiGrid->addLayout( uiStars, row++, 1 );
			}

			uiColumn->addLayout( uiGrid );

			leftCol->addStretch();
			rightCol->addStretch();
		}
	}
}

LiveStarDisplayWidget::LiveStarDisplayWidget(
	QWidget *parent,
	const fs::path &saveFilePath,
	StarLayout &&layout
) :
	StarDisplayWidget( parent, std::move( layout ), false ),
	m_saveFilePath( saveFilePath )
{
	if( !fs::existsSafe( saveFilePath ) ) {
		QFile saveFile( saveFilePath.u8string().c_str() );
		saveFile.open( QFile::WriteOnly | QFile::Truncate );

		QByteArray zeroBuffer;
		zeroBuffer.fill( '\0', 296960 );

		saveFile.write( zeroBuffer );
		saveFile.flush();
	}

	connect( &m_fileWatcher, &QFileSystemWatcher::fileChanged, this, &LiveStarDisplayWidget::saveFileChanged );
	m_fileWatcher.addPath( saveFilePath.u8string().c_str() );
	saveFileChanged();
}

void LiveStarDisplayWidget::saveFileChanged() {
	std::ifstream saveFile( m_saveFilePath.u8string(), std::ios_base::binary | std::ios_base::in );
	Buffer saveData = m_layout.getUsedSaveData( saveFile );
	for( StarSetUi *starSet: m_starSets ) starSet->load( saveData );
}
