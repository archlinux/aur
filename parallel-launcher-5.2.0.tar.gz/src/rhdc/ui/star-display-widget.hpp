#ifndef STARDISPLAYWIDGET_HPP
#define STARDISPLAYWIDGET_HPP

#include <vector>
#include <QFileSystemWatcher>
#include <QTabWidget>
#include "src/rhdc/core/layout.hpp"
#include "src/rhdc/ui/star-set.hpp"
#include "src/core/filesystem.hpp"

class StarDisplayWidget : public QTabWidget {
	Q_OBJECT

	protected:
	const StarLayout m_layout;
	std::vector<StarSetUi*> m_starSets;

	public:
	StarDisplayWidget( QWidget *parent, StarLayout &&layout, bool editable );
	virtual ~StarDisplayWidget() {}

	inline const StarLayout &starLayout() const noexcept { return m_layout; }

};

class LiveStarDisplayWidget : public StarDisplayWidget {
	Q_OBJECT

	private:
	QFileSystemWatcher m_fileWatcher;
	const fs::path m_saveFilePath;

	public:
	LiveStarDisplayWidget( QWidget *parent, const fs::path &saveFilePath, StarLayout &&layout );
	virtual ~LiveStarDisplayWidget() {}

	private slots:
	void saveFileChanged();

};

#endif // STARDISPLAYWIDGET_HPP
