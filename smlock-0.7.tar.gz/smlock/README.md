# smlock
Smlock is a minimal screen locker, for Xorg, optimized for mobile.  
Fork of Benruijl sflock - github.com/benruijl/sflock  
It shows a clock, that will update at key press.  
## Install
REQUIRES xlib. The Dejavu font is the default.  
On Arch:  
`sudo pacman -S base-devel xlib11`  
On Debian, Ubuntu:  
`sudo apt install build-essential libxtst-dev`  
Build and install:  
`sudo make clean install`  
## Options
\-c   modify the characters displayed when the user enters his password. This can be a sequence of characters to create a fake password  
\-f   The font  
\-g   The (clock) font  
\-b   Display a custom message instead of the user name  
\-i   A command to be executed at start  
\-e   A command to be executed at the end  
\-h   Hide user name or messagge  
\-d   Clock format string, see strftime  
\-?   Help  

Example:  
`smlock -i onboard -h`  
