// smlock 0.7
#define _XOPEN_SOURCE 500
#if HAVE_SHADOW_H
#include <shadow.h>
#endif
#include <ctype.h>
#include <pwd.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <crypt.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/vt.h>
#include <fcntl.h> 
#include <errno.h> 
#include <termios.h>
#include <X11/keysym.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/dpms.h>
#include <time.h>
#if HAVE_BSD_AUTH
#include <login_cap.h>
#include <bsd_auth.h>
#endif


static void end(const char *errstr, ...) {
    va_list ap;
    va_start(ap, errstr);
    vfprintf(stderr, errstr, ap);
    va_end(ap);
    exit(EXIT_FAILURE);
}

#ifndef HAVE_BSD_AUTH
static const char * get_password() { /* only run as root */
    const char *rval;
    struct passwd *pw;
    if(geteuid() != 0) end("cannot retrieve password entry (make sure to suid smlock)\n");
    pw = getpwuid(getuid());
    endpwent();
    rval = pw->pw_passwd;

#if HAVE_SHADOW_H
    {
        struct spwd *sp;
        sp = getspnam(getenv("USER"));
        endspent();
        rval = sp->sp_pwdp;
    }
#endif
    /* drop privileges temporarily */
    if (setreuid(0, pw->pw_uid) == -1) end("cannot drop privileges\n");
    return rval;
}
#endif

int main(int argc, char **argv) {

#ifndef HAVE_BSD_AUTH
    const char *pws;
#endif
    bool running = True;
    Cursor invisible;
    Display *dpy;
    KeySym ksym;
    Pixmap pmap;
    Window root, w;
    XColor black, red, dummy, fgcolor;
    unsigned long blackp, whitep;
    XEvent ev;
    XSetWindowAttributes wa;
    XFontStruct *font, *fontt, *fontd;
    GC gc; 
    XGCValues values;
    XCharStruct overall;
    char curs[] = {0, 0, 0, 0, 0, 0, 0, 0};
    char buf[32], passwd[256], passdisp[256];
    int num, len, screen, term, pid, x, dir, ascent, descent;
	unsigned int ypost, yposs, xposs, blen = 0, cs = 0, width = 0, height = 0;
	short depth;
	bool custombanner = 0, show = 1, sldate = 0, icmc = 0, ecmc = 0, fgc = 0;
	char dfc = 0;
	char *tfor = "%R", *passchar = "*", *banner = "", *tfors = NULL, *fgcstr = NULL, *icmd = NULL, *ecmd = NULL;
    char* fontname = "-*-dejavu sans light-*-r-*-*-*-400-*-*-*-*-*-*";
    char* fontnamet = "-*-dejavu sans light-*-r-*-*-*-1050-*-*-*-*-*-*";
    char* fontnamed = fontname;
    char* username = NULL;
    char erf[20] = "font string error!\n";
    char erd[20] = "date format error!\n";
    char erc[21] = "color format error!\n";
    char nnt[16], snt[16];


    for (int i = 0; i < argc; ++i) {
        if (!strcmp(argv[i], "-c")) {
            if (i + 1 < argc) {
			if ( strlen(argv[++i]) < 20 ) {
                passchar = argv[i]; } }
            else end("password character error.\n");
        }
        else if (!strcmp(argv[i], "-d")) {
                if (i + 1 < argc) {
					if ( strlen(argv[++i]) < 17 ) {
                    tfor = argv[i]; } }
                else end(erd);
        }
        else if (!strcmp(argv[i], "-D")) {
                if (i + 1 < argc) {
					sldate = 1;
					if ( strlen(argv[++i]) < 17 ) {
                    tfors = argv[i]; } }
                else end(erd);
        }
        else if (!strcmp(argv[i], "-f")) {
                if (i + 1 < argc) {
					if ( strlen(argv[++i]) < 99 ) {
						fontname = argv[i]; } }
                else end("font 1 string error.\n");
        }
        else if (!strcmp(argv[i], "-g")) {
                if (i + 1 < argc) {
					if ( strlen(argv[++i]) < 99 ) {
                    fontnamet = argv[i]; } }
                else end("font 2 string error.\n");
        }
        else if (!strcmp(argv[i], "-t")) { 
                if (i + 1 < argc) {
					if ( (cs = strlen(argv[++i])) < 99 ) {
					if ( cs == 1 ) {
						if ( argv[i][0] == '1' ) { dfc = 1; } // font
						else if ( argv[i][0] == '2' ) { dfc = 2; } } // fontt
					    else { dfc = 3; // fontd
                        fontnamed = argv[i]; } } }
                else end("font 3 string error.\n");
        }
        else if (!strcmp(argv[i], "-b")) {
				if (i + 1 < argc) {
					if ( (blen = strlen(argv[++i])) < 99 ) {
					custombanner = 1;
					banner = argv[i]; } }
                else end("text string error.\n");
        }
        else if (!strcmp(argv[i], "-i")) {
                if (i + 1 < argc) {
                    if ( (cs = strlen(argv[++i])) < 55 ) {
					icmd = malloc(cs+3);
					icmc = 1;
                    strcpy( icmd, argv[i] );
                    strcat( icmd, " &" ); } }
                else end("initial command string error.\n");
        }
        else if (!strcmp(argv[i], "-e")) {
                if (i + 1 < argc) {
                    if ( (cs = strlen(argv[++i])) < 55 ) {
					ecmd = malloc(cs+3);
					ecmc = 1;
                    strcpy( ecmd, argv[i] );
                    strcat( ecmd, " &"); } }
                else end("final command string error.\n");
        }
        else if (!strcmp(argv[i], "-o")) {
                if (i + 1 < argc) {
                    if ( strlen(argv[++i]) < 33 ) {
					fgc = 1;
                    fgcstr = argv[i]; } }
                else end(erc);
        }
        else if (!strcmp(argv[i], "-h")) show = 0;
        else if (!strcmp(argv[i], "-?")) {
            end("\nsmlock 0.7\n\nOPTIONS:\n-c	Password mask char/s\n-f	Name/msg/pass font\n-g	Clock font\n-t	Date font: 1, 2 or string\n-b	Message to replace the name\n-i	Command at startup\n-e	Command on exit\n-h	Hide name/msg\n-d	Clock format, see strftime\n-D	Date format, see strftime\n-o	text color:'rgb:ff/ff/ff'\n\nbackground image: a picture at /opt/smlockbg will be used.\n\n");
            exit(0);
        }
    }

    // fill with password characters
    for (int i = 0; i < sizeof passdisp; i+= strlen(passchar)) 
        for (int j = 0; j < strlen(passchar) && i + j < sizeof passdisp; ++j)
            passdisp[i + j] = passchar[j];

    /* disable tty switching */
    if ((term = open("/dev/console", O_RDWR)) == -1) {
        perror("error opening console");
    }

    if ((ioctl(term, VT_LOCKSWITCH)) == -1) {
        perror("error locking console"); 
    }
    /* initial command */
    if (icmc) {
       system(icmd);
       free(icmd);
    }
    /* deamonize */
    pid = fork();
    if (pid < 0) 
        end("Could not fork smlock.");
    if (pid > 0) 
        exit(0); // exit parent 
#ifndef HAVE_BSD_AUTH
    pws = get_password();
    username = getpwuid(geteuid())->pw_name;
#else
    username = getlogin();
#endif
    if (!custombanner) {
        banner = username;
        blen = strlen(banner); }

    if(!(dpy = XOpenDisplay(0))) end("cannot open dpy\n");

    screen = DefaultScreen(dpy);
    root = RootWindow(dpy, screen);
    width = DisplayWidth(dpy, screen);
    height = DisplayHeight(dpy, screen);
    Colormap cm = DefaultColormap(dpy, screen);
    depth = DefaultDepth(dpy, screen);
    Visual *vi = DefaultVisual(dpy, screen);
    
    wa.override_redirect = 1;
    blackp = BlackPixel(dpy, screen);	/* get color black */
	whitep = WhitePixel(dpy, screen);  /* get color white */
    wa.background_pixel = blackp;
    w = XCreateWindow(dpy, root, 0, 0, width, height, 0, depth, CopyFromParent, vi, CWOverrideRedirect | CWBackPixel, &wa);
    gc = XCreateGC(dpy, w, (unsigned long)0, &values);

    XAllocNamedColor(dpy, cm, "orange red", &red, &dummy);
    XAllocNamedColor(dpy, cm, "black", &black, &dummy);
    if (fgc) {
	cs = XParseColor(dpy, cm, fgcstr, &fgcolor); //"rgb:50/ff/80"
	if (!cs) end(erc);
	XAllocColor(dpy, cm, &fgcolor); }
    
    pmap = XCreateBitmapFromData(dpy, w, curs, 8, 8);
    invisible = XCreatePixmapCursor(dpy, pmap, pmap, &black, &black, 0, 0);
    XDefineCursor(dpy, w, invisible);
    XMapRaised(dpy, w);

    font = XLoadQueryFont(dpy, fontname);
    fontt = XLoadQueryFont(dpy, fontnamet);
    if (font == 0 || fontt == 0 ) { end(erf); }
    bool lsb = 1, sid = 0, lfa = 0; // font
    fontd = font;
    if ( sldate && dfc ) {
		switch(dfc) {
            case 2: fontd = fontt; lsb = 0; lfa = 1; break; // fontt
            case 3: // fontd
            if ( (fontd = XLoadQueryFont(dpy, fontnamed)) == 0 ) { end(erf); }
            else { sid = 1; lfa = 1; }
            break; } } // font

    time_t nd = time(0);
    cs = strftime(nnt, 16, tfor, localtime(&nd));
    if (!cs) end(erd);
    short tlens = 0, tlen = strlen(nnt);
    if ( sldate ) {
	cs = strftime(snt, 16, tfors, localtime(&nd));
	if (!cs) end(erd);
	tlens = strlen(snt); }
    short vsp = (height / 100) * 2; // space between lines
    unsigned int linexs = width * 3 / 8; // line size and pos
    unsigned int linexe = width * 5 / 8;
    unsigned int liney = height / 2;
    XSetFont(dpy, gc, font->fid); // text size and pos
    XTextExtents(font, banner, blen, &dir, &ascent, &descent, &overall);
	unsigned int xposb = (width - XTextWidth(font, banner, blen)) / 2;
    unsigned int yposb = liney - vsp;
    unsigned int yposp = liney + vsp + ascent; // password y pos
    if ( sldate )  { // date size and pos
	if ( dfc > 1 ) XTextExtents(fontd, banner, blen, &dir, &ascent, &descent, &overall);
	yposs = ( height / 4 ) + ( vsp / 2 ) + ascent;
	xposs = ( width - XTextWidth(fontd, snt, tlens) ) / 2; }
    XSetFont(dpy, gc, fontt->fid); // clock size and pos
    XTextExtents(fontt, nnt, 1, &dir, &ascent, &descent, &overall);
    unsigned int xpost = (width - XTextWidth(fontt, nnt, tlen)) / 2;
    if ( sldate )  ypost = ( height / 4 ) - ( vsp / 2 );
    else ypost = ( height / 4 ) + ( ascent / 2 );
    if ( fgc ) XSetForeground(dpy, gc, fgcolor.pixel);
    else XSetForeground(dpy, gc, whitep);

    if ((running = running)) {
        for (len = 1000; len; --len) {
            if (XGrabKeyboard(dpy, root, True, GrabModeAsync, GrabModeAsync, CurrentTime) == GrabSuccess) break;
            usleep(1000);
        }
        running = (len > 0); }

    len = 0;
    XSync(dpy, False);
    bool update = 1;
    bool sleepmode = 0;

    /* main event loop */
    while(running && !XNextEvent(dpy, &ev)) {
        if (sleepmode) {
            DPMSEnable(dpy);
            DPMSForceLevel(dpy, DPMSModeOff);
            XFlush(dpy); }
           
        if (update) {
            nd = time(0);
            strftime(nnt, 16, tfor, localtime(&nd));
            XTextExtents(font, passdisp, len, &dir, &ascent, &descent, &overall);
            x = (width - overall.width) / 2;
            XSetFont(dpy, gc, fontt->fid);
            XClearWindow(dpy, w);
            XDrawString(dpy,w,gc, xpost, ypost, nnt, tlen); // clock            
            if (sldate) {
			if ( lsb ) { if ( sid ) { XSetFont(dpy, gc, fontd->fid); }
			else { XSetFont(dpy, gc, font->fid); } }
			XDrawString(dpy,w,gc, xposs, yposs, snt, tlens); // date
			if ( lfa ) { XSetFont(dpy, gc, font->fid); } }
			else XSetFont(dpy, gc, font->fid);
            if (show) {
            XDrawString(dpy,w,gc, xposb, yposb, banner, blen); // text
            XDrawLine(dpy, w, gc, linexs, liney, linexe, liney); }
            XDrawString(dpy,w,gc, x, yposp, passdisp, len); // password
            update = False;
        }
        if (ev.type == KeyPress) {
            sleepmode = False;
            buf[0] = 0;
            num = XLookupString(&ev.xkey, buf, sizeof buf, &ksym, 0);
            if (IsKeypadKey(ksym)) {
                if (ksym == XK_KP_Enter) ksym = XK_Return;
                else if (ksym >= XK_KP_0 && ksym <= XK_KP_9) ksym = (ksym - XK_KP_0) + XK_0;
            }
            if (IsFunctionKey(ksym) || IsKeypadKey(ksym) || IsMiscFunctionKey(ksym) || IsPFKey(ksym) || IsPrivateKeypadKey(ksym))
				continue;

            switch(ksym) {
                case XK_Return:
                    passwd[len] = 0;
#ifdef HAVE_BSD_AUTH
                    running = !auth_userokay(getlogin(), NULL, "auth-xlock", passwd);
#else
                    running = strcmp(crypt(passwd, pws), pws);
#endif
                    if (running != 0)
                        // change background on wrong password
                        XSetWindowBackground(dpy, w, red.pixel);
                    len = 0;
                    break;
                case XK_Escape:
                    len = 0;
                    if (DPMSCapable(dpy)) {
                        sleepmode = True;
                    }
                    break;
                case XK_BackSpace:
                    if(len)
                        --len;
                    break;
                default:
                    if(num && !iscntrl((int) buf[0]) && (len + num < sizeof passwd)) { 
                        memcpy(passwd + len, buf, num);
                        len += num;
                    }
                    break;
            }
            update = True; // show changes
        }
    }

    /* free and unlock */
    setreuid(geteuid(), 0);
    if ((ioctl(term, VT_UNLOCKSWITCH)) == -1) {
        perror("error unlocking console"); 
    }
    close(term);
    setuid(getuid()); // drop rights permanently
	/* final command */
    if (ecmc) {       
    system(ecmd);
    free(ecmd);
    }
    XFreePixmap(dpy, pmap);
    XFreeFont(dpy, font);
    XFreeFont(dpy, fontt);
    XFreeGC(dpy, gc);
    XDestroyWindow(dpy, w);
    XCloseDisplay(dpy);
    return 0;
}
