class Snap7Exception(Exception):
    """
    A Snap7 specific exception.
    """
    pass
