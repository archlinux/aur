
ICON THEME FOR SYLPHEED 3.0

Version 2
December 2009

___________________________________

  Copyright (C) 2007 Johan Spee

       www.coonsden.com

 [email through the website please]
___________________________________


Sylpheed is probably the best GTK-based e-mail client for the
Linux platform - it just doesn't look it.

The author is considering to make the program themeable, but
this feature has not been implemented yet.

However, by simply replacing the original Sylpheed artwork, and
the derived header files, a customized binary can be compiled.

1. Replace ./src/icons in your Sylpheed 2.4.0 source directory
   with the one included in this archive.

2. Compile Sylpheed, as usual.
   The binary will include all the custom graphics.

Note that some icons are not compiled into the binary, but
loaded at runtime from your GNOME icon theme. These icons will,
consequently, not be changed. 
(e.g. main window: 'search', compose: 'draft' and 'editor')

________________________________________________

  Tested with Sylpheed versions: 3.0 beta 4
________________________________________________


Updates:     http://www.coonsden.com (menu: design)
Sylpheed:    http://sylpheed.sraoss.jp/en/

____________________________________________


This is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your 
option) any later version.

This code is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this code; if not, write to the Free Software Foundation, Inc., 
59 Temple Place Suite 330, Boston, MA  02111-1307, USA.

_____________________________________

How the GNU General Public License applies to graphics and graphic design is
discussed and explained at:
http://gnuhttp://gnuart.org/english/gnugpl.html#TOC5 
