Was this really too much to ask for?
