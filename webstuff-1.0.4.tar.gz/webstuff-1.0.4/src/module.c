#include <stdio.h>
#include <stdlib.h>
#include <regex.h>

#include <ws/timer.h>
#include <ws/list.h>

#include "module.h"
#include "receiver.h"
#include "worker.h"

#define XSTR(s) STR(s)
#define STR(s) #s
#define GET_WEBSERVER(project, maj, min, rel, bld) project "/" maj "." min "." rel " build " bld

/* const
 *************************************************************************** */

const WsChar    cDefaultHost[]     = "0.0.0.0";
const WsInt     cDefaultPort       = 8080;
const WsInt     cDefaultThreads    = 4;

const WsVersion wsVersion          = {MAJOR, MINOR, RELEASE, BUILD};
#ifndef WITH_WEBSERVER_NAME
const WsChar    wsWebStuffServer[] = GET_WEBSERVER(PROJECT, STR(MAJOR), STR(MINOR), STR(RELEASE), STR(BUILD));
#else
const WsChar    wsWebStuffServer[] = WITH_WEBSERVER_NAME;
#endif
               /* see Makefile for MAJOR, MINOR, RELEASE, BUILD */

/* types
 *************************************************************************** */

struct _WsModulePrivate
{
    WsMutex        lock;            /* request queue log */
    WsInt          threads;         /* number of threads */
    /*    WsString       name;    */    /* module or executable name */
    /*    WsVersion    * version; */    /* module version */
    WsUrl        * urls;            /* list of urls */
    WsList       * requests;        /* request queue */
    WsConnector  * connector;       /* connector instance */
};


/* private methods
 *************************************************************************** */

static void
_ws_module_thread (WsModule * self);


/* implementation
 *************************************************************************** */


WsModule *
ws_module_new(const WsChar * m_name, const WsVersion * m_version)
{
    WsModule * self  = calloc(1, sizeof(WsModule));
    self->priv       = calloc(1, sizeof(WsModulePrivate));

    /* set up thread */
    ws_thread_init(WS_THREAD(self));
    ws_thread_set_name(WS_THREAD(self), m_name);
    WS_THREAD(self)->execute = (WsThreadFunction) _ws_module_thread;

    /* set up log */
    /* ws_thread_set_log(WS_THREAD(self),ws_log_new(m_name, m_version)); */

    if (!stdlog)
        stdlog = ws_log_new(ws_thread_get_pname(WS_THREAD(self)), m_version);
    /* set up connector */
    self->priv->connector = ws_connector_new();
    ws_module_set_socket(self,  cDefaultHost, cDefaultPort);

    ws_module_set_threads(self, cDefaultThreads);

    ws_mutex_init(&self->priv->lock);

    self->priv->requests = ws_list_new(cDefaultThreads);
    self->priv->requests->free_item = (WsListItemDestructor) ws_request_free;

    return self;
}


/* ------------------------------------------------------------------------- */

void
ws_module_free(WsModule * self)
{
    if (!self) return;

    if(self->priv->urls)
    {
        while (self->priv->urls->mask != NULL)
        {
            if (self->priv->urls->re) regfree(self->priv->urls->re);
            self->priv->urls++;
        }
    }

    ws_connector_free(self->priv->connector);
    ws_list_free(self->priv->requests);
    ws_mutex_destroy(&self->priv->lock);
    free(self->priv);
    ws_thread_free(WS_THREAD(self));
}


/* + control methods ------------------------------------------------------- */


void
ws_module_start(WsModule * self)
{
    ws_thread_start(WS_THREAD(self));
    ws_thread_wait(WS_THREAD(self));
}


/* ------------------------------------------------------------------------- */


void
ws_module_stop(WsModule * self)
{
    ws_thread_stop(WS_THREAD(self));
}


/* ------------------------------------------------------------------------- */


WsBool
ws_module_is_terminated(WsModule * self)
{
    return ws_thread_is_terminated(WS_THREAD(self));
}


/* + configuration methods ------------------------------------------------- */


WsBool
ws_module_set_log(WsModule * self, char * logfile, int level)
{
    ws_log_set_level(stdlog, level);
    return ! ws_log_set_file(stdlog, logfile);
}


/* ------------------------------------------------------------------------- */


void
ws_module_set_socket(WsModule * self, const WsChar * host, const WsInt port)
{
    ws_connector_set_socket(self->priv->connector, host, port);
}


/* ------------------------------------------------------------------------- */


void
ws_module_set_urls(WsModule * self, WsUrl * urls)
{
    int status;
    char buffer[256];
    self->priv->urls = urls;
    while (urls->mask != NULL)
    {
        if (!urls->re)
        {
            urls->re = calloc(1, sizeof(regex_t));
            status = regcomp(urls->re, urls->mask, REG_EXTENDED);
            if (status != 0)
            {
                regerror(status, urls->re, buffer, 256);
                stdlog->alert( WS_THREAD(self),
                                     "bad regular expression '%s'",
                                     buffer,
                                     urls->mask );
                urls->handler = NULL;
            }
        }
        urls++;
    }
}


/* ------------------------------------------------------------------------- */


void
ws_module_set_threads(WsModule * self, int threads)
{
    self->priv->threads = (threads > 0 && threads < 32) ?  threads :
                                                           cDefaultThreads;
}



/* methods for internal webstuff usage ------------------------------------- */


void
ws_module_add_request(WsModule * self, WsRequest * request)
{
    ws_mutex_lock(&self->priv->lock);

    ws_list_append(self->priv->requests, request);

    ws_mutex_unlock(&self->priv->lock);
}


WsRequest *
ws_module_get_request(WsModule * self)
{
    WsRequest * wsr=NULL;
    ws_mutex_lock(&self->priv->lock);

    wsr = ws_list_get_item(self->priv->requests, 0);
    if (wsr) ws_list_remove(self->priv->requests, 0);

    ws_mutex_unlock(&self->priv->lock);

    return wsr;
}


WsConnector *
ws_module_get_connector(WsModule * self)
{
    return self->priv->connector;
}


WsUrl *
ws_module_get_urls(WsModule * self)
{
    return self->priv->urls;
}



/* static
 *************************************************************************** */


static void
_ws_module_thread (WsModule * self)
{
    WsReceiver   ** receiver;          /* connection handler+http receiver */
    WsWorker     ** worker;          /* request handler+http replier */
    WsStopwatch     sw;
    int            i;

    receiver = malloc(self->priv->threads * sizeof(WsReceiver*));
    worker = malloc(self->priv->threads * sizeof(WsWorker*));

    ws_thread_start(WS_THREAD(self->priv->connector));

    for (i=0; i<self->priv->threads; i++) 
    {
        /* create & start receiver */
        receiver[i] = ws_receiver_new(i+1, self);
        receiver[i]->on_request_ready    = self->on_request_ready;
        receiver[i]->on_request_response = self->on_request_response;
        ws_thread_start(WS_THREAD(receiver[i]));

        /* create & start worker */
        worker[i] = ws_worker_new(i+1, self);
        worker[i]->on_start          = self->on_worker_start;
        worker[i]->on_stop           = self->on_worker_stop;
        ws_thread_start(WS_THREAD(worker[i]));
    }
    ws_stopwatch_start(&sw);
    while (!ws_thread_is_stopped(WS_THREAD(self)))
    {
        if (ws_stopwatch_get_elapsed(&sw) >= 1)
        {
/*            stdlog->debug(WS_THREAD(self), "cleanup"); */
            ws_connector_cleanup(self->priv->connector);
            ws_stopwatch_start(&sw);
        }

        ws_sleep(100);
    }

    /* stop workers & receivers */
    for (i=0; i<self->priv->threads; i++) 
    {
        ws_thread_stop(WS_THREAD(receiver[i]));
        ws_thread_stop(WS_THREAD(worker[i]));
    }

    /* wait workers and receivers */
    for (i=0; i<self->priv->threads; i++) 
    {
        ws_thread_wait(WS_THREAD(receiver[i]));
        ws_thread_wait(WS_THREAD(worker[i]));
        ws_receiver_free(receiver[i]);
        ws_worker_free(worker[i]);
    }

    /* stop and wait connector */
    ws_thread_stop(WS_THREAD(self->priv->connector));
    ws_thread_wait(WS_THREAD(self->priv->connector));

    if (receiver) free(receiver);
    if (worker) free(worker);
}

