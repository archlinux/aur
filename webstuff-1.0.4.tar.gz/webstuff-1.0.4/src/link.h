#ifndef __WS_LINK_H_
#define __WS_LINK_H_

/* +-----------------------------------------------------------------------+
   | CLASS ws_client
   +-----------------------------------------------------------------------+ */

#include <time.h>
#include <stdbool.h>

#include <ws/request.h>
#include <ws/socket.h>
#include <ws/status.h>



typedef struct {
    int                  flag : 4;
    time_t               ts;
    WsStatus             status;
    WsSocket           * socket;        // client socket
} WsLink;


// Constructor
// Creates client from server socket
// Result: client or null if accept()==0
WsLink *
ws_link_new (WsSocket * socket);


// Destructor
// Waits for thread termination and frees memory
void
ws_link_free (WsLink * client);

bool
ws_link_get_hold(WsLink * self);

void
ws_link_set_hold(WsLink * self, bool hold);


void // updates ts - online timestamp
ws_link_touch(WsLink * self);

bool // checks ts and return true if PING_TIMEOUT is not corrupted
ws_link_is_up(WsLink * self);

void
ws_link_set_down(WsLink * self, WsStatus status);


WsStatus
ws_link_get_status(WsLink * self);

#endif
