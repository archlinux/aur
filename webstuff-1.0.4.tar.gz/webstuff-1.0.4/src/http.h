#ifndef _WS_HTTP_FULL_H_
#define _WS_HTTP_FULL_H_

#include <ws/types.h>
#include <ws/request.h>

#include <ws/http.h>
#include "link.h"


enum _WsHttpConection
{
    wsHttpClose,
    wsHttpPersistent
};

typedef enum _WsHttpConection WsHttpConnection;

extern WsChar wsHttpKeepAlive[];



#endif
