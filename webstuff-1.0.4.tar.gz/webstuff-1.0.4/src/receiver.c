#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

#include <ws/types.h>
#include <ws/pair.h>
#include <ws/list.h>
#include <ws/timer.h>
#include <ws/request.h>
#include <ws/string.h>

#include "receiver.h"
#include "link.h"
#include "connector.h"
#include "module.h"
#include "http.h"



/* constants
 *************************************************************************** */

enum
{
    psRequest = 0,
    psHeader,    /* if not, read request, else headers */
    psData,     /* if set, read data */
    psDone
};


static const WsInt cBufferSize = WS_RECEIVER_BUFFER_SIZE-1;


/* static
 *************************************************************************** */

static void
ws_receiver_thread         ( WsReceiver * self );

/* reset parser data to defaults */
static void
ws_receiver_reset_parser   ( WsReceiver * self );

/* try to get data from socket, parse it and create new WsRequest instance */
static WsRequest *
ws_receiver_get_request    ( WsReceiver * self, WsLink * link );

/* read HTTP request (first line) from WsReceiver buffer */
static void
ws_receiver_read_request   ( WsReceiver * self, WsRequest * request );

/* read HTTP headers from WsReceiver buffer */
static void
ws_receiver_read_headers   ( WsReceiver * self, WsRequest * request );

/* read HTTP data from WsReceiver buffer */
static void
ws_receiver_read_data      ( WsReceiver * self, WsRequest * request );

/* finilize request */
static void
ws_receiver_finish_request ( WsReceiver    * self,
                             WsRequest     * request,
                             WsHttpStatus    status);

/* read query of view key=value<spe>key=value<...> */
static WsChar *
read_query   (WsChar * in, WsList * out, WsChar * sep);


/* find char in buffer between buffer and stop */
static WsChar *
sch(WsChar * buffer, WsChar c, WsChar * stop);


static WsInt
strcasecmpascii(WsChar * source, WsChar * target);



/* implementation
 *************************************************************************** */


WsReceiver *
ws_receiver_new(WsInt index, WsModule * module)
{
    WsReceiver * self = calloc(1, sizeof(WsReceiver));

    ws_thread_init(WS_THREAD(self));
    WS_THREAD(self)->execute = (WsThreadFunction) ws_receiver_thread;
    ws_thread_set_name_and_index(WS_THREAD(self), "Receiver", index);

    self->module = module;
    return self;
}


void
ws_receiver_free(WsReceiver * self)
{
    if(self)
    {
        ws_thread_free(WS_THREAD(self));
        *((void**)&self)=NULL;
    }
}


/* ststic
 *************************************************************************** */

static void
ws_receiver_thread(WsReceiver * self)
{
    WsRequest     * request;
    WsConnector   * connector = ws_module_get_connector(self->module);
    WsLink        * link;

    while (! ws_thread_is_stopped(WS_THREAD(self)))
    {
        /* take link */
        link = ws_connector_hold_link(connector);

        if (!link) /* no ready link, sleep and try again */
        {
            ws_sleep(100);
            continue;
        }

        /* link is up, reset parser */
        ws_receiver_reset_parser(self);

        /* try to read request */
        request = ws_receiver_get_request(self, link);

        /* if request was parsed, link should stay hold until response */
        if (request)
            ws_module_add_request(self->module, request);
        else /* release to try later */
            ws_connector_release_link(connector, link);

        /* if request is NULL there is ^no need to wait, because there already
         * was some timeout while select() */
    }
}



/* reset parser data to defaults */
static void
ws_receiver_reset_parser (WsReceiver * self)
{
    self->step    = psRequest;
    self->size    = 0;
    self->clength = 0;
    self->it      = self->buffer;

    if (self->bound)
        ws_string_set_length(&self->bound, 0);
}


/* try to get data from socket, parse it and create new WsRequest instance */
static WsRequest *
ws_receiver_get_request  (WsReceiver * self, WsLink * link)
{
    WsRequest    * request = NULL;
    WsStopwatch    sw;
    WsInt          length;
    WsStatus       s = wsSuccess;

    ws_stopwatch_start(&sw);
    
    while (! ws_thread_is_stopped(WS_THREAD(self)))
    {
        /* if there is some unparsed data in buffer, it is better to move it 
         * to begining of buffer */

        if (self->size > 0) /* check if it is necessary to change self->it */
            memcpy(self->buffer, self->it, self->size);
        else
            self->it=self->buffer;

        length = ws_socket_read( link->socket,
                                &self->buffer[self->size],
                                 cBufferSize - self->size );

        if (length == 0)
        {
            if (!request) break; /* try to read later */


            if (ws_stopwatch_get_elapsed(&sw) > 29 )
            {
                s = wsConnectionTimeout;
            }
            else
            {
                ws_sleep(100);
                continue;
            }
        }
        else if (length<0) /* error during reading */
        {
            s = wsSocketReadError;
        }

        if (s != wsSuccess) /* disconnect on error */
        {
            ws_link_set_down(link, wsSocketReadError);
            if (request)
                ws_request_free(request);
            request = NULL;
            break;
        }

        ws_link_touch(link);

        /* we have some data, time to start request */
        if (!request)
        {
            request = ws_request_new(link);
            ws_request_set_on_requested(request,  self->on_request_ready);
            ws_request_set_on_responded(request, self->on_request_response);
        }

        /* begin debug */
        self->buffer[self->size+length] = 0;

        stdlog->debug( WS_THREAD(self), "<<< %s:%d - %dbytes (%s) ", 
                             ws_socket_get_host(link->socket),
                             ws_socket_get_port(link->socket),
                             length,
                             &self->buffer[self->size] );

        /* end debug */
        self->size += length;


        /* if HTTP request was not read */
        if (self->step == psRequest)
            ws_receiver_read_request(self, request);
        else if (self->step == psHeader)
            ws_receiver_read_headers(self, request);
        else if (self->step == psData)
            ws_receiver_read_data(self, request);

        if (self->step == psDone) break;
    }

    return request;
}

static void
ws_receiver_read_request (WsReceiver * self, WsRequest * request)
{
    WsInt      l;
    WsChar * end;
    WsChar * chr;
    WsInt    version;
    WsPair * pair;
    WsLink * link = ws_request_get_link(request);

    if (!self->size) return; /* wait if no data */

    /* check if we have request line */
    end = sch(self->buffer, '\n', &self->it[self->size]);
    if (!end)
    {
        if (self->size == WS_RECEIVER_BUFFER_SIZE)
            ws_receiver_finish_request(
                self, request, wsHttpRequestEntityTooLarge);
        return; /* wait for rest or finish */
    }
    *end = 0; /* make strchr safe */

    stdlog->state(WS_THREAD(self), "<<< R[%s] (%s:%d)",
                        self->buffer,
                        ws_socket_get_host(link->socket),
                        ws_socket_get_port(link->socket) );

    /* PARSE HTTP METHOD */
    chr = strchr(self->buffer, ' ');
    l = (chr) ? (WsInt)(chr - self->buffer) : 0;

    if (l == 3) /* GET, PUT,  */
    {
        if (strncmp(self->buffer, "PUT", l)==0) l=-1;
        else if (strncmp(self->buffer, "GET", l)!=0) l=0;
    }
    else if (l == 4) /* POST, HEAD */
    {
        if (strncmp(self->buffer, "POST", l)!=0 && 
            strncmp(self->buffer, "HEAD", l)!=0 ) l=0;
    }
    else if (l>0 && l<8) /* REST */
    {
        l = ( strncmp(self->buffer, "OPTIONS", l) ==0 ||
              strncmp(self->buffer, "DELETE",  l) ==0 ||
              strncmp(self->buffer, "TRACE",   l) ==0 ||
              strncmp(self->buffer, "CONNECT", l) ==0 ) ? -1 : 0;
    }

    if (l == 0)
        return ws_receiver_finish_request(self, request, wsHttpBadRequest);
    else if (l < 0)
        return ws_receiver_finish_request(self, request, wsHttpNotImplemented);

    *chr = 0;

    pair = ws_list_get_item(request->environ, wsRequestMethod);
    ws_string_set(&pair->value, self->buffer);

    /* PARSE URI */
    chr++; /* skip all spaces if there are any. loop won't be endless cause we
            * know there is \n at least */
    while (*chr == ' ') chr++;
    l = (WsInt)(chr-self->buffer);
    if (strncmp(chr, "http://", 7) == 0) // parse host name
    {
        l +=7;
        chr = strchr(&self->buffer[l], '/');
        if (!chr) ws_receiver_finish_request(self, request, wsHttpBadRequest);
        *chr=0;

        pair = ws_list_get_item(request->environ, wsHttpHost);
        ws_string_set(&pair->value, &self->buffer[l]);

        *chr='/';
        l=(WsInt)(chr-self->buffer);
    }
    /* parse url */
    chr = strchr(&self->buffer[l], ' ');
    if (!chr) ws_receiver_finish_request(self, request, wsHttpBadRequest);
    *chr = 0;
    pair = ws_list_get_item(request->environ, wsRequestUri);
    ws_string_set(&pair->value, &self->buffer[l]);
    /*_decode_uri(p->client->request->env->first[REQUEST_URI]->value); */
    chr++;
    while (*chr == ' ') chr++;
    l = (WsInt)(chr-self->buffer);

    /* PARSE VERSION */
    if (strncmp(&self->buffer[l], "HTTP/", 5))
        ws_receiver_finish_request(self, request, wsHttpBadRequest);
    chr = strchr(&self->buffer[l], '.');
    if (!chr) ws_receiver_finish_request(self, request, wsHttpBadRequest);
    *chr=0;
    version = atoi(&self->buffer[l+5]);
    l = (WsInt)(chr-self->buffer)+1;
    if (version != 1) ws_receiver_finish_request(
            self, request, wsHttpVersionNotSupported);
    while(chr < end)
    {
        if (*chr == ' ' || *chr == '\r') break;
        chr++;
    }
    *chr=0;
    version = atoi(&self->buffer[l]);
    if (version > 1) ws_receiver_finish_request(
            self, request, wsHttpVersionNotSupported);

    end++;
    self->size -= (WsInt)(end-self->buffer);
    self->it = end;
    /* done */
    self->step = psHeader;
    /* forward control to next phase */
    if (self->size > 0) ws_receiver_read_headers(self, request);
}


static void
ws_receiver_read_headers (WsReceiver * self, WsRequest * request)
{
    if (!self->size) return;
    if(ws_get_response_status(request) != wsHttpOk)
        return ws_receiver_finish_request(self, request, 0);
    /* parse headers */
    WsChar * end;
    WsChar * chr;
    WsPair * pair;
    WsInt    var;
    WsLink * link = ws_request_get_link(request);
    

    while ((end = sch(self->it, '\n', &self->it[self->size]))!=NULL)
    {
        *end = 0; /* make string functions safe */
        chr = end-1;
        if (*chr == '\r') *chr = 0; /* ignore \r */

        stdlog->debug( WS_THREAD(self), "<<< H[%s] (%s:%d)",
                             self->it,
                             ws_socket_get_host(link->socket),
                             ws_socket_get_port(link->socket) );


        if (self->it == chr || self->it == end) /* end of HTTP headers */
        {
            self->step = psData;
            break;
        }
        else
        {
            chr = strchr(self->it, ':');
            if (!chr)
            {
                ws_receiver_finish_request(self, request,  wsHttpBadRequest);
                return;
            }
            *chr = 0;
            if      (strcmp(self->it, "Host"           )==0) var=wsHttpHost;
            else if (strcmp(self->it, "User-Agent"     )==0) var=wsHttpUserAgent;
            else if (strcmp(self->it, "Accept"         )==0) var=wsHttpAccept;
            else if (strcmp(self->it, "Accept-Language")==0) var=wsHttpAcceptLanguage;
            else if (strcmp(self->it, "Accept-Encoding")==0) var=wsHttpAcceptEncoding;
            else if (strcmp(self->it, "Connection"     )==0) var=wsHttpConnection;
            else if (strcmp(self->it, "Cookie"         )==0) var=wsHttpCookie;
            else if (strcmp(self->it, "Content-Type"   )==0) var=wsContentType;
            else if (strcmp(self->it, "Content-Length" )==0) var=wsContentLength;
            else var = 0;


            if (var)
            {
                pair = ws_list_get_item(request->environ, var);
                ws_string_set(&pair->value, &chr[2]);
            }
        }
        end++;
        self->size -= (WsInt)(end - self->it);
        self->it = end;
    }
    
    /* too long header */
    if (self->size == WS_RECEIVER_BUFFER_SIZE && !end) 
        return ws_receiver_finish_request(self, request, wsHttpBadRequest);

    if(self->step == psData)
    {
        pair = ws_list_get_item(request->environ, wsContentLength);
        chr = pair->value;
        self->clength = (chr) ? strtol(chr, NULL, 10) : 0;
        if (self->clength > 0) 
        {
            pair = ws_list_get_item(request->environ, wsContentType);
            chr = pair->value;
            if (strncmp(chr, "multipart/form-data; boundary=", 30)==0)
            {
                self->bound = &chr[30];
            }
            else 
            //if (strcmp(chr, "application/x-www-form-urlencoded")==0)
            {
                self->bound = NULL;
            }
            //else p->clen = 0; // ignore unknown types
            // NOTICE: condition changed because of some times AJAX send data
            // as text/plain
        }
        if (self->clength==0) 
            return ws_receiver_finish_request(self, request, 0);
        else if (self->size > 0) return ws_receiver_read_data(self, request);
    }
}


static void
ws_receiver_read_data    (WsReceiver * self, WsRequest * request)
{
    /* if len is zero, we've read all. it is finish time
     * if status is not OK, there is no need to parse anything */
    if (ws_get_response_status(request) != wsHttpOk) 
        return ws_receiver_finish_request(self, request, 0);

    WsChar * chr;
    WsLink * link = ws_request_get_link(request);

    if (self->bound)
    {
        self->clength = 0;
    }
    else
    {
        /* always add null termination */
        /* self->it[self->size] = 0; - already set after reading buffer */
        stdlog->debug( WS_THREAD(self), "<<< D[%s] (%s:%d)",
                             self->it,
                             ws_socket_get_host(link->socket),
                             ws_socket_get_port(link->socket) );

        chr = read_query(self->it, request->post,  "&");
        self->size    -= (WsInt)(chr-self->it);
        self->clength -= (WsInt)(chr-self->it);
        self->it = chr;
    }

    if (self->clength == 0)
        return ws_receiver_finish_request(self, request, 0);
}

static void
ws_receiver_finish_request( WsReceiver    * self,
                            WsRequest     * request,
                            WsHttpStatus    status )
{
    stdlog->state( WS_THREAD(self), "request finished: %d", status);

    WsPair * pair;
    WsChar * query;
    WsChar * c;

    pair  = ws_list_get_item(request->environ, wsRequestUri);
    query = pair->value;
    

    /* SET SCRIPT_NAME */
    c = strchr(query, '?');
    if (c) *c = 0;
    pair  =  ws_list_get_item(request->environ, wsScriptName);
    ws_string_set(&pair->value, query);
    pair  =  ws_list_get_item(request->environ, wsDocumentUri);
    ws_string_set(&pair->value, query);

    /* SET QUERY_STRING */
    if (c)
    {
        *c = '?';
        pair = ws_list_get_item(request->environ, wsQueryString);
        ws_string_set(&pair->value, &c[1]);

        read_query(&c[1], request->get,  "&");
    }
    /* Set Cookies */
    pair  = ws_list_get_item(request->environ, wsHttpCookie);
    query = pair->value;
    if (query && strlen(query)>0)
    {
        read_query(query, request->cookie, "; ");
    }

    /* Set Connection */
    c = ws_request_get_env(request, wsHttpConnection);
    ws_request_set_keep_alive(request, strcasecmpascii(c, wsHttpKeepAlive) ? false : true);
    printf("test: %s, %d\n", c, strcasecmpascii(c, wsHttpKeepAlive));

    printf("keep alive: [%s] %d Result: %d\n", 
            c, strcmp(c, wsHttpKeepAlive) ? false : true,
            ws_request_get_keep_alive(request)
            );

    if (status > 0) ws_set_response_status(request, status);
    self->step = psDone;

    ws_request_set_requested(request);
}



static WsChar *
read_query(WsChar * in, WsList * out, WsChar * sep)
{
    WsPair    * p = NULL;
    WsChar       * c = in;
    WsInt          l = 0;
    const WsInt   sl = strlen(sep);


    while (1)
    {
        if (*c == '=')
        {
            p = ws_pair_new_from_length(in, l, NULL, 0);
            ws_list_append(out, p);
            in = ++c;
            l=0;
        }
        else if (strncmp(c, sep, sl) == 0 || *c == 0)
        {
            /* if p == NULL it means we are continuing pair from last socket
             * read session or client requested abnormal uri, like
             * http://host/?something
             * so we check how many pairs there are in output list */
            if (!p && (ws_list_get_count(out) > 0))
                p=ws_list_get_item(out, ws_list_get_count(out)-1);


            if (p) /* ok, we just append value */
            {
                ws_string_append(&p->value, in, l);

            }
            else /* abnormal url, appending it */
            {
                p = ws_pair_new_from_length("", 0,in,l);
                ws_list_append(out, p);
            }

            ws_decode_uri(p->value);
            l = 0;

            if (*c != 0) c+=sl;
            in = c;
            if (*c == 0) break;
        }
        else
        {
            l++;
            c++;
        }
    }
    return in;
}


static WsChar *
sch(WsChar * buffer, WsChar c, WsChar * stop)
{
    while(buffer < stop)
    {
        if (*buffer == c) return buffer;
        buffer++;
    }
    return NULL;
}


static WsInt
strcasecmpascii(WsChar * source, WsChar * target)
{
    WsChar r;
    while ( *source != 0 && *target != 0 )
    {
        r = tolower(*source) - tolower(*target);
        if ( r != 0 ) return r;

        source++;
        target++;
    }

    return ( *source == 0 && *target == 0 ) ? 0: -1;
}
