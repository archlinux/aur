#ifndef _WS_WORKER_H_
#define _WS_WORKER_H_

#include <ws/thread.h>
#include <ws/log.h>
#include <ws/request.h>
#include <ws/url.h>
#include "module.h"


struct _WsWorker
{
    WsThread             thread;
    WsModule          *  module;
    WsUrlHandler         h_fault;
    WsCreateEvent        on_start;
    WsDestroyEvent       on_stop;
    WsPointer            data;
};

typedef struct _WsWorker WsWorker;


WsWorker *
ws_worker_new(int index, WsModule * module);

void
ws_worker_free(WsWorker * self);


#endif
