#ifndef _WS_REQUEST_FULL_H_
#define _WS_REQUEST_FULL_H_

#include <ws/request.h>
#include "link.h"
#include "worker.h"


/* methods for internal webstuff usage ------------------------------------- */

WsRequest  *
ws_request_new(WsLink * link);

void
ws_request_free(WsRequest * self);


WsStatus
ws_request_finish(WsRequest * self);


WsLink *
ws_request_get_link(WsRequest * self);


void
ws_request_set_worker(WsRequest * self, WsWorker * worker);


WsBool
ws_request_get_keep_alive(WsRequest * self);

void
ws_request_set_keep_alive(WsRequest * self, WsBool keep);

#endif
