#include <stdlib.h>
#include <stdio.h>
#include <assert.h>


#include "http.h"


WsChar wsHttpKeepAlive[]="keep-alive";

void
ws_decode_uri(WsChar  *st)
{
    WsChar  * p = st;
    WsChar    hex[3];
    WsInt     code;
    do
    {
        if(*st =='%') 
        {
            hex[0]=*(++st);
            hex[1]=*(++st);
            hex[2]=0;
            sscanf(hex,"%X",&code);
            *p++=(char)code;
        }
        else if(*st=='+') 
            *p++=' ';
        else 
            *p++=*st; 
    } while(*st++!=0);
}


const WsChar *
ws_get_http_status_text(WsHttpStatus status)
{
    switch (status)
    {
        /* most common for faster behavior */
        case wsHttpOk: return "OK";
        case wsHttpMovedPermanently: return "Moved Permanently";

        /* informational */
        case wsHttpContinue: return "Continue";
        case wsHttpSwitchingProtocols: return "Switching Protocols";
        /* Successful */
        case wsHttpCreated: return "Created";
        case wsHttpAccepted: return "Accepted";
        case wsHttpNonAuthoritativeInformation: return "Non-Authoritative Information";
        case wsHttpNoContent: return "No Content";
        case wsHttpResetContent: return "Reset Content";
        case wsHttpPartialContent: return "Partial Content";
        /* redirection */
        case wsHttpMultipleChoices: return "Multiple Choices";
        case wsHttpFound: return "Found";
        case wsHttpSeeOther: return "See other";
        case wsHttpNotModified: return "Not Modified";
        case wsHttpUseProxy: return "Use Proxy";
        case wsHttpUnused: return "(unused)";
        case wsHttpTemporaryRedirect: return "Temporary Redirect";
        /* client error */
        case wsHttpBadRequest: return "Bad Request";
        case wsHttpUnauthorized: return "Unauthorized";
        case wsHttpPaymentRequired: return "Payment Required";
        case wsHttpForbidden: return "Forbidden";
        case wsHttpNotFound: return "Not Found";
        case wsHttpMethodNotAllowed: return "Method Not Allowed";
        case wsHttpNotAcceptable: return "Not Acceptable";
        case wsHttpProxyAuthenticationRequired: return "Proxy Authentication Required";
        case wsHttpRequestTimeout: return "Request Timeout";
        case wsHttpConflict: return "Conflict";
        case wsHttpGone: return "Gone";
        case wsHttpLengthRequired: return "Length Required";
        case wsHttpPreconditionFailed: return "Precondition Failed";
        case wsHttpRequestEntityTooLarge: return "Request Entity Too Large";
        case wsHttpRequestUriTooLong: return "Request-URI Too Long";
        case wsHttpUnsupportedMediaType: return "Unsupported Media Type";
        case wsHttpRequestedRangeNotSatisfiable: return "Requested Range Not Satisfiable";
        case wsHttpExpectationFailed: return "Expectation Failed";
        /* server error */
        case wsHttpInternalServerError: return "Internal Server Error";
        case wsHttpNotImplemented: return "Not Implemented";
        case wsHttpBadGateway: return "Bad Gateway";
        case wsHttpServiceUnavailable: return "Service Unavailable";
        case wsHttpGatewayTimeout: return "Gateway Timeout";
        case wsHttpVersionNotSupported: return "HTTP Version Not Supported";

    }
    return "unknown";
}

