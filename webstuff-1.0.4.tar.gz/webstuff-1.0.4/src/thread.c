#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include <ws/thread.h>
#include <ws/string.h>

/* constants
 *************************************************************************** */

enum WsThreadFlag {tfTerminated, tfStop, tfError};

enum WsThreadStatus {tsSuccess=0, tsNoResources, tsNullExecute };

static const char errNoResources[] =
    "Insufficient resources to create another thread";

static const char errNullExecute[] =
    "Null execute function pointer";


/* types
 *************************************************************************** */

struct _WsThreadPriv
{
    int                 flag : 4;
    int                 index;
    pthread_t           id;
    WsString           name;
/*    WsLog            * log;*/
};


/* static definitions
 *************************************************************************** */

static void
ws_thread_set_flag(WsThread * self, int flag);

static void
ws_thread_unset_flag(WsThread * self, int flag);

static bool
ws_thread_get_flag(WsThread * self, int flag);

static void *
ws_thread_execute(void * arg);

static const char *
status_message(int status);

/*

static WsString *
ws_thread_get_log_format( WsThread * self,
                           const char * msg,
                           const char * details );

*/
/* globals
 *************************************************************************** */


/* protected
 *************************************************************************** */
void
ws_thread_set_error(WsThread * self);

void
ws_thread_destroy(WsThread * self);


/* implementation
 *************************************************************************** */


void
ws_thread_init(WsThread * self)
{
    self->priv = calloc(1, sizeof(WsThreadPriv));
    ws_thread_set_flag(self, tfTerminated);
}


/* protected function, that is used to free resources of global threads */
void
ws_thread_destroy(WsThread * self)
{
    if (self)
    {
        ws_string_free(self->priv->name);
        free(self->priv);
    }
}


void
ws_thread_free(WsThread * self)
{
    if (self)
    {
        ws_thread_destroy(self);

        free(self);
        *((void**)&self) = NULL;
    }
}



void
ws_thread_set_name_and_index(WsThread * self, const char * name, int index)
{
    char tmp[2+3+1];


    if (index)
    {
        self->priv->index = index;
        sprintf(tmp, " #%d", index & 0xFF);
    }
    else
        tmp[0] = 0;
    
    ws_string_join(&self->priv->name, "", name, tmp, NULL);
}


void
ws_thread_set_name(WsThread * self, const char * name)
{
    ws_thread_set_name_and_index(self, name, 0);
}


char *
ws_thread_get_name(WsThread * self)
{
    if (!self->priv->name)
        ws_string_set_length(&self->priv->name, 0);
    return self->priv->name;
}


int
ws_thread_start(WsThread * self)
{
    int result;
    self->priv->flag = 0;

    if (self->execute)
    {
        result = pthread_create( &self->priv->id,
                                 NULL,
                                 ws_thread_execute,
                                 (void*) self );
        if (result) result = tsNoResources;
    }
    else
        result = tsNullExecute;

    if (result)
    {
        stdlog->error( self, 
                          "could not start thread (%s)", 
                          status_message(result) );
        ws_thread_set_flag( self, tfError );
    }
    else
        stdlog->state( self, "started" );

    return result;
}


void
ws_thread_stop(WsThread * self)
{
    ws_thread_set_flag(self, tfStop);
}


void
ws_thread_wait(WsThread * self)
{
    if (!ws_thread_is_terminated(self))
        pthread_join(self->priv->id, NULL);
}


bool
ws_thread_is_terminated(WsThread * self)
{
    return ws_thread_get_flag(self, tfTerminated);
}


bool
ws_thread_is_stopped(WsThread * self)
{
    return (ws_thread_get_flag(self, tfStop));
}


bool
ws_thread_checkout(WsThread * self)
{
    bool   res = ws_thread_is_terminated(self);
    if (res)
    {
        if (ws_thread_get_flag(self, tfError))
            stdlog->alert( self, "has error state", NULL );
    }
    return res;
}

/*
void
ws_thread_set_log(WsThread * self, WsLog * log)
{
    self->priv->log = log;
}


WsLog *
ws_thread_get_log(WsThread * self)
{
    return self->priv->log;
}
*/

/*
void
ws_thread_log( WsThread  * self,
                WsLogLevel  level,
                const char * message, ...)
{
    if (!self->priv || !self->priv->log) return;

    va_list     args;
    WsString * m = ws_thread_get_log_format(self, message, NULL);


    va_start (args, message);
    ws_log_save (self->priv->log, level, ws_string_get(m), args);
    va_end (args);

    ws_string_free(m);
}


void
stdlog->error( WsThread * self,
                      const char * message,
                      const char* details, ...)
{
    if (!self->priv || !self->priv->log) return;

    va_list     args;
    WsString * m = ws_thread_get_log_format(self, message, details);

    va_start (args, details);
    ws_log_save (self->priv->log, llError, ws_string_get(m), args);
    va_end (args);

    ws_string_free(m);
}


void
stdlog->alert( WsThread * self,
                      const char * message,
                      const char* details, ...)
{
    if (!self->priv || !self->priv->log) return;

    va_list     args;
    WsString * m = ws_thread_get_log_format(self, message, details);

    va_start (args, details);
    ws_log_save (self->priv->log, llAlert, ws_string_get(m), args);
    va_end (args);
    ws_string_free(m);
}


void
stdlog->state(WsThread * self, const char * message, ...)
{
    if (!self->priv || !self->priv->log) return;

    va_list     args;
    WsString * m = ws_thread_get_log_format(self, message, NULL);

    va_start (args, message);
    ws_log_save (self->priv->log, llState, ws_string_get(m), args);
    va_end (args);
    ws_string_free(m);
}


void
stdlog->debug(WsThread * self, const char * message, ...)
{
    if (!self->priv || !self->priv->log) return;

    va_list     args;
    WsString * m = ws_thread_get_log_format(self, message, NULL);

    va_start (args, message);
    ws_log_save (self->priv->log, llDebug, ws_string_get(m), args);
    va_end (args);
    ws_string_free(m);
}

*/
WsChar **
ws_thread_get_pname(WsThread * self)
{
    return &self->priv->name;
}

/* protected
 * ************************************************************************* */

void
ws_thread_set_error(WsThread * self)
{
    ws_thread_set_flag(self, tfError);
}


/* static implementation
 *************************************************************************** */


static void
ws_thread_set_flag(WsThread * self, int flag)
{
    self->priv->flag |= 1<<flag;
}


static void
ws_thread_unset_flag(WsThread * self, int flag)
{
    if (self->priv->flag & 1<<flag) self->priv->flag ^= 1<<flag;
}


static bool
ws_thread_get_flag(WsThread * self, int flag)
{
    return (self->priv->flag & 1<<flag) ? true : false;
}


static void *
ws_thread_execute(void * arg)
{
    WsThread * self = arg;

    if (self->on_start) self->on_start(self, NULL);
    self->execute(self);
    if (self->on_stop) self->on_stop(self, NULL);

    ws_thread_set_flag(self, tfTerminated);
    ws_thread_unset_flag(self, tfStop);
    stdlog->state(self, "terminated");
    pthread_exit(NULL);
}
/*

static WsString *
ws_thread_get_log_format( WsThread * self,
                           const char * msg,
                           const char * details )
{
    WsString * m;
    uint32_t    s;
    s = ws_string_get_length(self->priv->name)+2+strlen(msg);

    if (details) s+=1+2+strlen(details);

    m = ws_string_new_with_size( ws_string_get(self->priv->name), s );

    ws_string_append(m, ": ");
    ws_string_append(m, msg);
    if (details)
    {
        ws_string_append(m, " (");
        ws_string_append(m, details);
        ws_string_append(m, ")");
    }
    return m;
}

*/
static const char *
status_message(int status)
{
    switch (status)
    {
        case tsNoResources : return errNoResources;
        case tsNullExecute : return errNullExecute;
    }

    return "";
}


/* MUTEX
 * ************************************************************************* */

int
ws_mutex_init(WsMutex * mutex)
{
    #ifdef WIN32
    return InitializeCriticalSection(mutex);
    #else
    return pthread_mutex_init(mutex, NULL);
    #endif
}


int
ws_mutex_destroy(WsMutex * mutex)
{
    #ifdef WIN32
    return DeleteCriticalSection(mutex);
    #else
    return pthread_mutex_destroy(mutex);
    #endif
}


int
ws_mutex_lock(WsMutex * mutex)
{
    #ifdef WIN32
    return EnterCriticalSection(mutex);
    #else
    return pthread_mutex_lock(mutex);
    #endif
}


int
ws_mutex_unlock(WsMutex * mutex)
{
    #ifdef WIN32
    return LeaveCriticalSection(mutex);
    #else
    return  pthread_mutex_unlock(mutex);
    #endif
}


