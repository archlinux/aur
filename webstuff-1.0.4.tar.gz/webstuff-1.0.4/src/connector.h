#ifndef _WS_CONNECTOR_H_
#define _WS_CONNECTOR_H_

#include <pthread.h>
#include <stdbool.h>

#include <ws/types.h>
#include <ws/socket.h>
#include <ws/thread.h>
#include <ws/list.h>

#include "link.h"


typedef struct
{
    WsThread    thread;
    WsMutex     lock;
    WsList    * links;
    WsSocket  * socket;
    uint32_t    it;        /* iterator */

} WsConnector;



WsConnector *
ws_connector_new();

void
ws_connector_free(WsConnector * self);

WsStatus
ws_connector_set_socket( WsConnector  * self,
                         const WsChar * host,
                         const WsInt    port );

void
ws_connector_cleanup(WsConnector * self);


WsLink *
ws_connector_hold_link(WsConnector * self);

void
ws_connector_release_link(WsConnector * self, WsLink * link);


#endif
