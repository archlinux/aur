#ifndef __WS_PAIR_H_
#define __WS_PAIR_H_

/* +-----------------------------------------------------------------------+
   | CLASS ws_pair
   +-----------------------------------------------------------------------+ */


#include <ws/string.h>


WsPair *
ws_pair_new( const WsChar * key, const WsChar * value );


WsPair *
ws_pair_new_from_length( const WsChar * key,
                         WsSize         k_len,
                         const WsChar * value,
                         WsSize         v_len );


void
ws_pair_free ( WsPair * self );

#endif
