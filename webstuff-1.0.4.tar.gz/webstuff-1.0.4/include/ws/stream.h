#ifndef __WS_STREAM_H_
#define __WS_STREAM_H_

#include <ws/types.h>
#include <ws/socket.h>
#include <ws/status.h>

/* +-----------------------------------------------------------------------+
   | CLASS ws_stream
   +-----------------------------------------------------------------------+ */

typedef struct {
    WsSize                size;
    WsSize                allocated;
    WsChar              * buffer;
} WsStream;


WsStream *
ws_stream_new(WsInt size);

void
ws_stream_free(WsStream * self);

WsInt
ws_stream_write(WsStream * self, const WsChar * buffer, WsSize size);

WsInt
ws_stream_read(WsStream * self, WsChar * buffer, WsSize size);


WsBool
ws_stream_is_closed(WsStream * self);


WsSize
ws_stream_get_size(WsStream * self);


WsStatus
ws_stream_send_to_socket(WsStream * self, WsSocket * sock);


#endif
