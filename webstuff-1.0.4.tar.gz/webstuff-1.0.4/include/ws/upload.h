#ifndef __WS_UPLOAD_H_
#define __WS_UPLOAD_H_

#ifndef WS_UPLOAD_DIR
    #define WS_UPLOAD_DIR "/tmp/"
#endif

#ifndef WS_UPLOAD_LENGTH
    #define WS_UPLOAD_LENGTH 10
#endif


#include <ws/pair.h>
/* +-----------------------------------------------------------------------+
   | CLASS ws_upload
   +-----------------------------------------------------------------------+ */


typedef struct
{
    WsString    key;
    WsString    name;
    WsString    path;
    WsString    type;
    WsSize      size;
    WsBool      moved;
} WsUpload;


WsUpload *
ws_upload_new ();


WsBool
ws_upload_move(WsUpload * self, WsChar * new_path);

void
ws_upload_free ( WsUpload * self );

#endif
