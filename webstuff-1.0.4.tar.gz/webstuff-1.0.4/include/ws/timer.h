#ifndef _WS_TIMEOUT_H_
#define _WS_TIMEOUT_H_

#include <time.h>
#include <ws/types.h>

struct _WsStopwatch
{
    time_t    begin;
    time_t    end;
};

typedef struct _WsStopwatch WsStopwatch;
typedef enum   _WsTimeUnit  WsTimeUnit;


void
ws_stopwatch_start(WsStopwatch * sw);


void
ws_stopwatch_stop(WsStopwatch * sw);


WsSize
ws_stopwatch_get_elapsed(WsStopwatch * sw);


void
ws_sleep(WsSize usec);


#endif
