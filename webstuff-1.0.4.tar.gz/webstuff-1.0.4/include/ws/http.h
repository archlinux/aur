#ifndef _WS_wsHttpH_
#define _WS_wsHttpH_

#include <ws/types.h>


#define WS_HTTP_TIMESTAMP    "%a, %d-%b-%Y %H:%M:%S GMT"
#define WS_HTTP_VERSION      "HTTP/1.1"
#define WS_HTTP_VERSION_SIZE (4+1+2+1+2)
#define WS_HTTP_STATUS_SIZE  (HTTP_VERSION_SIZE+1+3+1+32+2)

typedef enum _WsHttpStatus WsHttpStatus;

enum _WsHttpStatus
{
    /* informational */
    wsHttpContinue                     = 100,
    wsHttpSwitchingProtocols,
    /* Successful */
    wsHttpOk                           = 200,
    wsHttpCreated,
    wsHttpAccepted,
    wsHttpNonAuthoritativeInformation,
    wsHttpNoContent,
    wsHttpResetContent,
    wsHttpPartialContent,
    /* redirection */
    wsHttpMultipleChoices              = 300,
    wsHttpMovedPermanently,
    wsHttpFound,
    wsHttpSeeOther,
    wsHttpNotModified,
    wsHttpUseProxy,
    wsHttpUnused,
    wsHttpTemporaryRedirect,
    /* client error */
    wsHttpBadRequest                   = 400,
    wsHttpUnauthorized,
    wsHttpPaymentRequired,
    wsHttpForbidden,
    wsHttpNotFound,
    wsHttpMethodNotAllowed,
    wsHttpNotAcceptable,
    wsHttpProxyAuthenticationRequired,
    wsHttpRequestTimeout,
    wsHttpConflict,
    wsHttpGone,
    wsHttpLengthRequired,
    wsHttpPreconditionFailed,
    wsHttpRequestEntityTooLarge,
    wsHttpRequestUriTooLong,
    wsHttpUnsupportedMediaType,
    wsHttpRequestedRangeNotSatisfiable,
    wsHttpExpectationFailed,
    /* server error */
    wsHttpInternalServerError          = 500,
    wsHttpNotImplemented,
    wsHttpBadGateway,
    wsHttpServiceUnavailable,
    wsHttpGatewayTimeout,
    wsHttpVersionNotSupported
};


void
ws_decode_uri (WsChar  * uri);

const WsChar *
ws_get_http_status_text(WsHttpStatus status);


#endif
