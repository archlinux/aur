#ifndef _WS_TYPES_H_
#define _WS_TYPES_H_

#include <stdint.h>
#include <stdbool.h>

typedef char        WsChar;
typedef int32_t     WsInt;
typedef char      * WsString;

typedef uint32_t    WsUint;
typedef uint32_t    WsSize;
typedef uint16_t    WsWord;
typedef uint8_t     WsByte;

typedef bool        WsBool;
typedef float       WsFloat;
typedef double      WsDouble;

typedef void *      WsPointer;




struct _WsVersion
{
    const WsWord  major;
    const WsWord  minor;
    const WsWord  release;
    const WsWord  build;
};

typedef struct _WsVersion WsVersion;


struct _WsPair
{
    WsString key;
    WsString value;
};

typedef struct _WsPair WsPair;


typedef void * (*WsCreateEvent) (WsPointer pointer);
typedef void   (*WsDestroyEvent) (WsPointer pointer);


#endif
