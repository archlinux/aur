# Build Electron app

```bash
# git clone repo

cd hhd-ui
npm install

npm run electron-build

cd ./electron
npm install

npm run build

# output will be in the electron/dist/hhd-ui.AppImage
```
