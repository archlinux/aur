# MXSet

MXSet is a GNU C89 library that provides an optimized hashset.

---

## Usage

### 1) Initializing

Before using any functions, you must first initialize the library:

```c
#include <mxset/init.h>

int main(void)
{
        /* alloc() function, free() function, hashing function, string
         * duplication function. */
        mxset.init(allocator, free, hash, strdup);
        ...
}
```

For more information on initalizing the library, please consult the
[init.h](./include/mxset/init.h) header file, which provides documentation on
how to use every function in the `mxset` struct.

### 2) Creating a hashset

The hashset datatype is provided as `MxSet`, it can be used like so:

```c
#include <mxset.h>

int main(void)
{
        mxset.init(...);
        ...
        /* 'reserve' is the amount of memory (slots) you wish to initially
         * reserve for the created hashset. */
        MxSet set = mxset.set.init(reserve);

        /* Insert a key, ignoring its position. */
        mxset.set.insert(set, "key1");

        /* Insert a key and get its position. */
        size_t pos_key2;
        mxset.set.insert_get_pos(set, "key2", &pos_key2);

        /* Find the position of a previously inserted key. */
        _Bool found;
        size_t pos_key1 = mxset.set.find(set, "key1", &found);

        if (!found)
                puts("key1 not found");
        else
                printf("key1 found at %zu\n", pos_key1);
        ...
}
```

Although, `MxSet` is a pointer. If you wish to hardcode a hashset, you may use
`struct _mxset`, which provides the literal struct itself.

For more information, consult the [init.h](./include/mxset/init.h) header file,
which provides comprehensible documentation on all of these functions.

### 3) Discarding a hashset

After you're done with your hashset, if you wish to discard (to avoid memory
leaks and all), you may use the `destroy` function:

```c
#include <mxset.h>

int main(void)
{
        mxset.init(...);
        ...
        MxSet set = mxset.set.new(...);
        ...
        mxset.set.destroy(set);
        /* Now 'set' is unusable. Any further use of it will result in a
         * segmentation fault. */
        ...
}
```

---

## Installation

MXSet is a library that currently only works on **POSIX systems**, meaning
Windows is not supported yet.  
You may install the library with the provided `install` target in the
`Makefile`:

```bash
sudo make install PREFIX=/usr/local
```

Where `PREFIX` is, by default, `/use/local`, and is the location at which the
header files and library files will be installed. E.g.,
`/usr/local/lib/libmxset.a`, `/usr/local/include/mxset.h`.

## Contributing

Before any contributions, please read the `CONTRIBUTING.md` provided.

## License

MXSet is licensed under an LGPL-3.0 license **or later**.
