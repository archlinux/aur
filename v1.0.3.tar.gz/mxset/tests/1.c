#include "mxset/hashset.h"
#include <mxset/init.h>
#include <stdlib.h>
#include <string.h>

#define _MXSET_INTERNAL
#include <mxset/common.h>

int main(void)
{
	debug("init() = %p", mxset.init);
	mxset.init(malloc, free, MXSET_FUNCTION_NONE, strdup);

	MxSet set = mxset.set.init(0);
	debug("set = %p", set);

	mxset.set.insert(set, "hello");
	mxset.set.insert(set, "world");

	size_t pos = mxset.set.find(set, "hello", NULL);
	debug("\"%s\" is at %zu", set->_keys[pos], pos);
	pos = mxset.set.find(set, "world", NULL);
	debug("\"%s\" is at %zu", set->_keys[pos], pos);

	return 0;
}
