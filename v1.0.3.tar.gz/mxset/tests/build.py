import subprocess
import sys

cmd: list[str] = ["cc", "-std=gnu89", "-Wall", "-Iinclude",
                  "-fomit-frame-pointer", "-flto", "-O3", "-march=native",
                  "-mtune=native", "-fno-common", "-ffunction-sections",
                  "-fdata-sections", "-ffast-math", "-fno-signed-zeros",
                  "-fno-trapping-math", "-fno-plt", "-fstrict-aliasing",
                  "-fno-math-errno", "-fPIC", "-ggdb3", "-DDEBUG", "-c"]

cmd.append(f"tests/{sys.argv[1]}.c");
cmd.append("-o")
cmd.append(f"obj/test/{sys.argv[1]}.o")

subprocess.run(["mkdir", "-p", "obj/test"])

print(*cmd)
subprocess.run(cmd)

cmd.pop() # obj/test/...
cmd.pop() # -o
cmd.pop() # tests/...
cmd.pop() # -c

ld: str = subprocess.run(["make", "linker"], capture_output=True, text=True).stdout

cmd.append(f"-fuse-ld={ld}")
cmd.append("-Wl,--gc-sections")
cmd.append("-Wl,--icf=all")
cmd.append("-o")
cmd.append("bin/test")
cmd.append("-Lbin")
cmd.append("-lmxset")
cmd.append(f"obj/test/{sys.argv[1]}.o")

print(*cmd)
subprocess.run(cmd)
