/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <stddef.h>
#include <mxset/init.h>
#include <mxset/hashset.h>
#include <mxset/alloc.h>

#define _MXSET_INTERNAL
#include <mxset/common.h>

static uintptr_t empty_hash(const char *const s)
{
	return (uintptr_t)s;
}
static char *empty_strdup(const char *const s)
{
	return (char *)s;
}
static void empty_free(void *p)
{
}

static void init(void *(*alloc)(size_t size), void (*free)(void *ptr),
		 uintptr_t (*hash)(const char *s),
		 char *(*strdup)(const char *s));

struct _mxset_lib_ctx mxset = { ._alloc = NULL,
				._free = NULL,
				._hash = NULL,
				._strdup = NULL,
				.init = init,
				.hash_seed = 0,
				.set = { .init = _mxset_init,
					 .destroy = _mxset_destroy,
					 .find = _mxset_find,
					 .insert = _mxset_insert } };

static void init(void *(*alloc)(size_t size), void (*free)(void *ptr),
		 uintptr_t (*hash)(const char *s),
		 char *(*strdup)(const char *s))
{
	if (likely(alloc == NULL))
		alloc = _mxset_alloc;

	if (likely(free == NULL) || unlikely(free == MXSET_FUNCTION_NONE))
		free = empty_free;

	if (likely(hash == NULL))
		hash = _mxset_wyhash;
	else if (unlikely(hash == MXSET_FUNCTION_NONE))
		hash = empty_hash;

	if (likely(strdup == NULL) || unlikely(strdup == MXSET_FUNCTION_NONE))
		strdup = empty_strdup;

	mxset._alloc = alloc;
	mxset._free = free;
	mxset._hash = hash;
	mxset._strdup = strdup;

	debug("alloc = %p, free = %p, hash = %p, strdup = %p", alloc, free,
	      hash, strdup);
}
