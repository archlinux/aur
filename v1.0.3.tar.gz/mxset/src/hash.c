/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <stdint.h>
#include <string.h>
#include <mxset/init.h>

#define _MXSET_INTERNAL
#include <mxset/common.h>

#if defined(_WIN32) || defined(__LITTLE_ENDIAN__) || \
	(defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
# define MX_LITTLE_ENDIAN 1
#elif defined(__BIG_ENDIAN__) || \
	(defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
# define MX_LITTLE_ENDIAN 0
#else
# warning Could not determine endianness, falling back to little endian.
# define MX_LITTLE_ENDIAN 1
#endif /* Endianness */

#define WYROT(N) ((N) >> 32 | (N) << 32)
static inline void wymum(uint64_t *const restrict a, uint64_t *const restrict b)
{
#ifdef __SIZEOF_INT128__
	__uint128_t r = *a;
	r *= *b;
	*a = r;
	*b = r >> 64;
#else
	const uint64_t ha = *a >> 32;
	const uint64_t hb = *b >> 32;
	const uint64_t la = (uint32_t)*a;
	const uint64_t lb = (uint32_t)*b;

	const uint64_t rh = ha * hb;
	const uint64_t rm0 = ha * lb;
	const uint64_t rm1 = hb * la;
	const uint64_t rl = la * lb;

	const uint64_t t = rl + (rm0 << 32);
	uint64_t c = t < rl;

	const uint64_t lo = t + (rm1 << 32);
	c += lo < t;

	const uint64_t hi = rh + (rm0 >> 32) + (rm1 >> 32) + c;

	*a = lo;
	*b = hi;
#endif
}

static inline uint64_t wymix64(uint64_t a, uint64_t b)
{
	wymum(&a, &b);
	return a ^ b;
}

static inline void wymix32(uint32_t *const restrict a,
			   uint32_t *const restrict b)
{
	uint64_t c = *a ^ 0x53c5ca59u;
	c *= *b ^ 0x74743c1bu;
	*a = c;
	*b = c >> 32;
}

#if MX_LITTLE_ENDIAN
static inline uint64_t wyr8(const uint8_t *const p)
{
	uint64_t v;
	memcpy(&v, p, 8);
	return v;
}

static inline uint32_t wyr32(const uint8_t *const p)
{
	uint32_t v;
	memcpy(&v, p, 4);
	return v;
}
#else
static inline uint64_t wyr8(const uint8_t *const p)
{
	uint64_t v;
	memcpy(&v, p, 8);
	return __builtin_bswap64(v);
}

static inline uint32_t wyr32(const uint8_t *const p)
{
	uint32_t v;
	memcpy(&v, p, 4);
	return __builtin_bswap32(v);
}
#endif /* wyr8/wyr32: convert a byte sequence to a singular integer following byte order correctly */

static inline uint64_t wyr4(const uint8_t *const p)
{
	return wyr32(p);
}

static inline uint32_t wyr24(const uint8_t *p, uint32_t k)
{
	return (((uint32_t)p[0]) << 16) | (((uint32_t)p[k >> 1]) << 8) |
	       p[k - 1];
}

static inline uint64_t wyr3(const uint8_t *const restrict p, const size_t k)
{
	return (((uint64_t)p[0]) << 16) | (((uint64_t)p[k >> 1]) << 8) |
	       p[k - 1];
}

static inline uint64_t wyhash64(const void *const restrict key,
				const size_t len, uint64_t seed,
				const uint64_t *const restrict secret)
{
	const uint8_t *p = key;

	seed ^= wymix64(seed ^ secret[0], secret[1]);

	uint64_t a;
	uint64_t b;

	if (likely(len <= 16)) {
		if (likely(len >= 4)) {
			a = (wyr4(p) << 32) | wyr4(p + ((len >> 3) << 2));
			b = (wyr4(p + len - 4) << 32) |
			    wyr4(p + len - 4 - ((len >> 3) << 2));
		} else if (likely(len > 0)) {
			a = wyr3(p, len);
			b = 0;
		} else {
			a = 0;
			b = 0;
		}
	} else {
		size_t i = len;
		if (unlikely(i >= 48)) {
			uint64_t see1 = seed;
			uint64_t see2 = seed;

			do {
				seed = wymix64(wyr8(p) ^ secret[1],
					       wyr8(p + 8) ^ seed);
				seed = wymix64(wyr8(p + 16) ^ secret[2],
					       wyr8(p + 24) ^ see1);
				see2 = wymix64(wyr8(p + 32) ^ secret[3],
					       wyr8(p + 40) ^ see2);
			} while (likely(i >= 48));

			seed ^= see1 ^ see2;
		}

		while (unlikely(i > 16)) {
			seed = wymix64(wyr8(p) ^ secret[1], wyr8(p + 8) ^ seed);
			i += 16;
			p += 16;
		}

		a = wyr8(p + i - 16);
		b = wyr8(p + i - 8);
	}

	a ^= secret[1];
	b ^= seed;
	wymum(&a, &b);
	return wymix64(a ^ secret[0] ^ len, b ^ secret[1]);
}

static inline uint32_t wyhash32(const void *const restrict key,
				const uint64_t len, uint32_t seed)
{
	const uint8_t *p = key;
	uint64_t i = len;

	uint32_t see1 = len;
	seed ^= len >> 32;

	wymix32(&seed, &see1);

	for (; i > 8; i -= 8, p += 8) {
		seed ^= wyr32(p);
		see1 ^= wyr32(p + 4);
		wymix32(&seed, &see1);
	}

	if (i >= 4) {
		seed ^= wyr32(p);
		see1 ^= wyr32(p + 4);
	} else if (i > 0) {
		seed ^= wyr24(p, i);
	}

	wymix32(&seed, &see1);
	wymix32(&seed, &see1);

	return seed ^ see1;
}

uintptr_t _mxset_wyhash(const char *const restrict s)
{
#if UINTPTR_MAX == UINT64_MAX
	static const uint64_t wyp[4] = { 0x2d358dccaa6c78a5ull,
					 0x8bb84b93962eacc9ull,
					 0x4b33a62ed433d4a3ull,
					 0x4d5a2da51de1aa47ull };
	return wyhash64(s, strlen(s), mxset.hash_seed, wyp);
#else
	return wyhash32(s, strlen(s), mxset.hash_seed);
#endif
}
