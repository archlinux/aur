/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <sys/mman.h>
#include <stdint.h>
#include <stddef.h>
#include <mxset/alloc.h>

#define _MXSET_INTERNAL
#include <mxset/common.h>

/* 8KiB */
#define INITIAL_ARENA_SIZE (1024 * 8)

static void *arena = NULL;
static size_t offset;
static size_t cap;

static void init(void)
{
	arena = mmap(NULL, INITIAL_ARENA_SIZE, PROT_READ | PROT_WRITE,
		     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

	cap = INITIAL_ARENA_SIZE;
}

static _Bool extend(void)
{
	arena = mremap(arena, cap, cap << 1, MREMAP_MAYMOVE);
	cap <<= 1;

	return arena != NULL;
}

void *_mxset_alloc(size_t sz)
{
	if (unlikely(arena == NULL))
		init();

	if (unlikely(sz == 0))
		return NULL;

	const size_t curr = (offset + 7) & ~0x7u;

	if (unlikely(sz > cap + curr)) {
		if (unlikely(!extend()))
			return NULL;
	}

	void *p = arena + curr;
	offset = curr + sz;

	return p;
}
