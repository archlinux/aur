/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <stddef.h>
#include <stdint.h>
#include <mxset/hashset.h>
#include <mxset/init.h>
#include <string.h>

#ifdef __x86_64__
# include <immintrin.h>
# ifdef __AVX512F__
#  define GROUP_SIZE 64
#  define vec_set1(p) _mm512_set1_epi8(p)
#  define vec_load(p) _mm512_loadu_si512(p)
#  define vec_movemask(p) _mm512_movemask_epi8(p)
#  define vec_eq(p1, p2) _mm512_cmpeq_epi8(p1, p2)
typedef __m512i vec_t;
# elif defined(__AVX2__)
#  define GROUP_SIZE 32
#  define vec_set1(i) _mm256_set1_epi8(i)
#  define vec_load(p) _mm256_loadu_si256(p)
#  define vec_movemask(p) _mm256_movemask_epi8(p)
#  define vec_eq(p1, p2) _mm256_cmpeq_epi8(p1, p2)
typedef __m256i vec_t;
# elif defined(__SSE4_2__)
#  define GROUP_SIZE 16
#  define vec_set1(p) _mm_set1_epi8(p)
#  define vec_load(p) _mm_loadu_si128(p)
#  define vec_movemask(p) _mm_movemask_epi8(p)
#  define vec_eq(p1, p2) _mm_cmpeq_epi8(p1, p2)
typedef __m128i vec_t;
# else
#  error Your CPU does not have the necessary vectorization capabilities that Emerald requires.
# endif /* x86 vector ops */
#elif defined(__aarch64__)
# include <arm_neon.h>
# define GROUP_SIZE 16
# define vec_set1(i) vdupq_n_u8(i)
# define vec_load(p) vld1q_u8(p)
# define vec_eq(p1, p2) vceqq_u8(p1, p2)
static inline uint32_t _vec_movemask(const uint8x16_t v)
{
	uint8x16_t masked = vshrq_n_u8(v, 7);
	static const uint8_t weights[16] = { 1, 2, 4, 8, 16, 32, 64, 128,
					     1, 2, 4, 8, 16, 32, 64, 128 };
	uint8x16_t vw = vld1q_u8(weights);
	uint8x16_t p = vmulq_u8(masked, vw);

	uint8x8_t low = vget_low_u8(p);
	uint8x8_t high = vget_high_u8(p);
	return (uint32_t)(vaddv_u8(low) | (vaddv_u8(high) << 8));
}
typedef uint8x16_t vec_t;
#else
# error MXSet currently does not support your hardware.
#endif /* x86 vs. ARM NEON */

#define _MXSET_INTERNAL
#include <mxset/common.h>

#if UINTPTR_MAX == UINT64_MAX
# define GET_H2(H) (((H) >> 57) & 0x7fu)
#else
# define GET_H2(H) (((H) >> 25) & 0x7fu)
#endif

static inline uintptr_t next_pow2(uintptr_t n)
{
	if (n == 0)
		return GROUP_SIZE;

	n--;

	n |= n >> 1;
	n |= n >> 2;
	n |= n >> 4;
	n |= n >> 8;
	n |= n >> 16;
#if UINTPTR_MAX == UINT64_MAX
	n |= n >> 32;
#endif

	n++;

	if (n < GROUP_SIZE)
		n = GROUP_SIZE;

	return n;
}

MxSet _mxset_init(size_t reserve)
{
	reserve = next_pow2(reserve);

	MxSet set = mxset._alloc(sizeof *set);
	if (unlikely(set == NULL))
		return NULL;

	set->_controls = mxset._alloc(reserve);
	if (unlikely(set->_controls == NULL)) {
		mxset._free(set);
		return NULL;
	}

	set->_keys = mxset._alloc(reserve * sizeof *set->_keys);
	if (unlikely(set->_keys == NULL)) {
		mxset._free(set->_controls);
		mxset._free(set);
		return NULL;
	}

	set->_capacity = reserve;
	set->_size = 0;
	set->_deleted = 0;
	memset(set->_controls, _MXSET_EMPTY, reserve);
	memset(set->_keys, 0, reserve * sizeof *set->_keys);

	return set;
}

static inline size_t find_pos(const MxSet set, const char *const key,
			      uintptr_t hash, _Bool *found, size_t *del)
{
	_Bool found_dummy;
	size_t delete_dummy;

	if (found == NULL)
		found = &found_dummy;

	if (del == NULL)
		del = &delete_dummy;

	*found = 0;
	*del = ~0;

	uint8_t h2 = GET_H2(hash);
	size_t mask = set->_capacity - 1;
	size_t idx = hash & mask;
	size_t start = idx;

	do {
		size_t grp = idx & ~(GROUP_SIZE - 1);

		vec_t ctrl = vec_load((const vec_t *)(set->_controls + grp));
		vec_t h2v = vec_set1(h2);

		vec_t match = vec_eq(ctrl, h2v);
		uint32_t match_mask = vec_movemask(match);

		uint32_t probe = ~0;

		const size_t offset = idx - grp;
		if (offset > 0)
			probe = ~((1u << offset) - 1);

		match_mask &= probe;

		while (match_mask != 0) {
			const size_t slot = grp + __builtin_ctz(match_mask);

			if (likely(strcmp(set->_keys[slot], key) == 0)) {
				*found = 1;
				return slot;
			}

			match_mask &= match_mask - 1;
		}

		match = vec_eq(ctrl, vec_set1(_MXSET_DELETED));
		match_mask = vec_movemask(match) & probe;

		if (match_mask != 0 && *del == ~0)
			*del = grp + __builtin_ctz(match_mask);

		match = vec_eq(ctrl, vec_set1(_MXSET_EMPTY));
		match_mask = vec_movemask(match) & probe;

		if (match_mask != 0)
			return grp + __builtin_ctz(match_mask);

		idx = (grp + GROUP_SIZE) & mask;
	} while (idx != start);

	return ~0;
}

static inline _Bool resize(const MxSet set)
{
	size_t cap = next_pow2(set->_capacity << 1);
	if (unlikely(cap <= set->_capacity))
		return 0;

	uint8_t *const ctrl = mxset._alloc(cap);
	if (unlikely(ctrl == NULL))
		return 0;

	const char **const keys = mxset._alloc(cap * sizeof *keys);
	if (unlikely(keys == NULL)) {
		mxset._free(ctrl);
		return 0;
	}

	memset(ctrl, _MXSET_EMPTY, cap);
	memset(keys, 0, cap * sizeof *keys);

	struct _mxset new = { ._controls = ctrl,
			      ._keys = keys,
			      ._capacity = cap };

	size_t i;
	for (i = 0; i < set->_capacity; i++) {
		if (set->_controls[i] < _MXSET_EMPTY) {
			const uintptr_t hash = mxset._hash(set->_keys[i]);
			const size_t pos =
				find_pos(&new, set->_keys[i], hash, NULL, NULL);

			new._controls[pos] = GET_H2(hash);
			new._keys[pos] = set->_keys[i];
			new._size++;
		}
	}

	mxset._free(set->_controls);
	mxset._free(set->_keys);

	*set = new;

	return 1;
}

_Bool _mxset_insert_get_pos(const MxSet set, const char *const key,
			    size_t *const pos)
{
	if (unlikely(set->_size + set->_deleted >=
		     set->_capacity * _MXSET_LOAD_FACTOR)) {
		if (unlikely(!resize(set)))
			return 0;
	}

	uint64_t hash = mxset._hash(key);
	_Bool found;
	size_t del;
	size_t slot = find_pos(set, key, hash, &found, &del);

	if (unlikely(found || slot == ~0))
		return 0;

	if (del != ~0) {
		slot = del;
		set->_deleted--;
	}

	set->_controls[slot] = GET_H2(hash);
	set->_keys[slot] = mxset._strdup(key);
	set->_size++;

	if (pos != NULL)
		*pos = slot;

	return 1;
}

_Bool _mxset_insert(const MxSet set, const char *const key)
{
	return _mxset_insert_get_pos(set, key, NULL);
}

size_t _mxset_find(const MxSet set, const char *const key, _Bool *const found)
{
	return find_pos(set, key, mxset._hash(key), found, NULL);
}

void _mxset_destroy(const MxSet set)
{
	if (set != NULL) {
		if (set->_controls != NULL)
			mxset._free(set->_controls);

		if (set->_keys != NULL) {
			size_t i;
			for (i = 0; i < set->_capacity; i++) {
				if (set->_keys[i] != NULL)
					mxset._free((char *)set->_keys[i]);
			}

			mxset._free(set->_keys);
		}

		mxset._free(set);
	}
}
