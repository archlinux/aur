/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef _MXSET_COMMON_H
#define _MXSET_COMMON_H

#ifdef _MXSET_INTERNAL
# define likely(c) __builtin_expect(!!(c), 1)
# define unlikely(c) __builtin_expect(!!(c), 0)
# define restrict __restrict__
# define inline __inline__
# include <stdio.h>
# ifdef DEBUG
#  define debug(msg, ...)                                  \
	  printf("\x1b[35;1m[  DEBUG  ]\x1b[0m " msg       \
		 " \x1b[1mMESSAGE FROM %s:%s:%u\x1b[0m\n", \
		 ##__VA_ARGS__, __FILE__, __func__, __LINE__)
# else
#  define debug(...)
# endif /* debug() */
#endif /* internal macros */

#endif /* mxset/common.h */
