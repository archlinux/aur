/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef _MXSET_ALLOC_H
#define _MXSET_ALLOC_H

#include <stddef.h>

void *_mxset_alloc(size_t size);

#endif /* mxset/alloc.h */
