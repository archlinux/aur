/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef _MXSET_INIT_H
#define _MXSET_INIT_H

#include <stddef.h>
#include <stdint.h>
#include "mxset/hashset.h"

#define MXSET_FUNCTION_NONE ((void *)-1)

extern struct _mxset_lib_ctx {
	/* Allocates 'size' bytes and returns a pointer to the start of that
	 * byte sequence. 'size' must be aligned to 8 bytes internally, and
	 * the function must return a NULL on failure. */
	void *(*_alloc)(size_t size);

	/* Deallocates 'ptr', meaning 'ptr' must be pointing to memory that is
	 * not owned by anyone after this call. */
	void (*_free)(void *ptr);

	/* Hashes 's' and produces a 64- or 32-bit hash. */
	uintptr_t (*_hash)(const char *s);

	/* Duplicates 's' into a new chunk in memory and returns its start. */
	char *(*_strdup)(const char *s);

	/* Initializes '_alloc', '_free', '_hash', '_strdup' with 'alloc',
	 * 'free', 'hash', 'strdup' respectively. In the event a function is
	 * NULL, the library will use its own internal functions. If a function
	 * is 'MXSET_FUNCTION_NONE', the library will never call the function,
	 * as in, the function called will be empty.
	 *
	 * NOTE: 'MXSET_FUNCTION_NONE' is ignored when passed to 'alloc'. If you
	 *       do pass it to that argument for any reason, the program will
	 *       segfault. */
	void (*init)(void *(*alloc)(size_t size), void (*free)(void *ptr),
		     uintptr_t (*hash)(const char *s),
		     char *(*strdup)(const char *s));

	/* The seed at which the hashing function will operate. This can only be
	 * used with custom hashing functions designed specifically for
	 * integration with this library, and the library's own WyHash default
	 * hash function. It may be ignored otherwise. By default, it is 0.*/
	uintptr_t hash_seed;

	struct _mxset_set_ctx {
		/* Initlizes a hashset. */
		MxSet (*init)(size_t reserve);

		/* Inserts 'key' into 'dest'. It returns 1 if successful, 0
		 * otherwise. */
		_Bool (*insert)(MxSet dest, const char *key);

		/* Inserts 'key' indo 'dest'. It returns 1 if successful and
		 * modifies the value pointed to by 'pos_out' to contain the
		 * position at which 'key' resides in 'dest', otherwise returns
		 * 0 and 'pos_out' is not modified. */
		_Bool (*insert_get_pos)(MxSet dest, const char *key,
					size_t *const pos_out);

		/* Returns the position at which 'key' resides in 'set'. The
		 * theoretical position it could enter will be returned
		 * regardless of whether it was found. Pass a point to 'found'
		 * to check whether 'key' exists in 'set', or 'NULL' if you do
		 * not care whether it does. */
		size_t (*find)(MxSet set, const char *key, _Bool *const found);

		/* Uses the '_free' function to free all allocated objects in
		 * 'set'. */
		void (*destroy)(MxSet set);
	} set;
} mxset;

#endif /* mxset/init.h */
