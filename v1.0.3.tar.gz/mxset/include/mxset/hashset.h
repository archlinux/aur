/* SPDX-License-Identifier: LGPL-3.0-or-later */
/*
 * mxset
 * Copyright (C) 2026  Muhamix
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef _MXSET_HASHSET_H
#define _MXSET_HASHSET_H

#include <stdint.h>
#include <stddef.h>

#define _MXSET_EMPTY 0x80u
#define _MXSET_DELETED 0xffu
#define _MXSET_LOAD_FACTOR 0.875f

typedef struct _mxset {
	/* Specifies whether it is empty or deleted. If neither, stores the h2
	 * (the highest 7 bits of the hash) */
	uint8_t *_controls;

	/* Stores a pointer to an array of strings; the keys. */
	const char **_keys;

	/* The current maximum capacity of the set: the maximum number of keys
	 * it can store. This is not exactly followed, it is always multiplied
	 * by the load factor. Meaning the actual capacity is
	 * MxSet._capacity * _MXSET_LOAD_FACTOR */
	size_t _capacity;

	/* The number of currently occupied slots. */
	size_t _size;

	/* The number of previously deleted slots. It is incremented when a key
	 * is removed, and decremented when a key is added in a previously
	 * deleted slot. */
	size_t _deleted;
} *MxSet;

/* The reserved amount is internally aligned to the next power of 2 (if it is
 * not already one). It is then set to the width of the largest supported vector
 * register if it is any less, e.g., 16 for XMM, 32 for YMM, 64 for ZMM, 16 for
 * ARM NEON. */
MxSet _mxset_init(size_t reserve);
void _mxset_destroy(const MxSet set);

size_t _mxset_find(const MxSet set, const char *const key, _Bool *const found);
_Bool _mxset_insert(const MxSet set, const char *const key);
_Bool _mxset_insert_get_pos(const MxSet set, const char *const key,
			    size_t *const pos);

uintptr_t _mxset_wyhash(const char *const s);

#endif /* mxset/hashset.h */
