# Guidelines

This file will document how to format your code for this repo.

## 1) Legal info

Before we start talking about actual code, there are 3 things you need to make sure you never forget to do:

1. Put a license header on top of a file if it doesn't have one. It can be found
   at the bottom of the `LICENSE` file, or in any other C source or header file.
   This does not apply to tests. Above the license header must be an SPDX
   License identifier.
2. Sign off all your commits, this can be done with the `-s` flag in `git`. If
   you used AI, add an `Assisted-by:` tag followed by the LLM used.
3. Put your name and e-mail in `CONTRIBUTORS.md`, **NOT THE LICENSE HEADER**.

## 2) Comments

1. All must be in the multi-line comment format `/* ... */` to comply with C89.
2. The column limit for each comment is **80 characters**, if your comment is
   longer just write a newline.
3. Don't add empty lines at the top/bottom of the comment. E.g.,
```c
/*
 * No!
 */
```

> rule 3 does not apply to the license header.

## 3) Coding style

MXSet uses a coding style VERY similar to linux kernel's. Most of your code will
be formatted by `clang-format`. The rest can be reviewed by any maintainer.

1. Tabs must be literal tab characters, not spaces.
2. Code must never go over the 80-column limit. If it does, break it down into
   multiple lines. This does not apply to strings. Strings must never be broken
   into multiple lines.
3. If your function has so many arguments they go over the column limit, align
   them. E.g.,

```c
int function(int a, int b, int c, int d, int e, int f, int g, int h, int i,
             int j, int k)
{
        ...
}
```

4. Make sure no lines have any trailing whitespace in them.
5. Do not add spaces around function calls. E.g.,

```c
/* No! */
size_t sz = sizeof( struct my_struct );
```

6. In a `switch` statement, its subordinate `case` labels must have the same
   indentation levels. E.g.,

```c
switch (c) {
case 'T':
case 't':
        mem <<= 10;
case 'G':
case 'g':
        mem <<= 10;
case 'M':
case 'm':
        mem <<= 10;
case 'K':
case 'k':
        mem <<= 10;
default:
        break;
}
```

7. Follow the Linux Kernel/K&R style for braces.
8. When declaring a pointer, the star `*` should be adjacent to the symbol's
   name, not the type it points to's name. E.g.,

```c
char *s;
unsigned long long int memop(char *p, char **rp);
char *_itos(int x);
```

9. When naming functions and variables, use `snake_case` and try to abbreviate
   each "word" in the name to 3-4 characters. If you successfully do that,
   avoid underscores `_` unless there is more than 3 words. If you could not
   abbreviate **all** of the words, use standard `snake_case` with full words.
   Use your own judgement of abbreviations, the maintainer reviewing your code
   will look at them and decide whether you should change them.
8. 17. When defining types, avoid using `typedef` **unless** it is an
   intentionally user-visible type that must be exposed in the API. If you use
   `typedef`, you must use `PascalCase` for the type name. If not, you must use
   the same convention as variables/functions.
9. When naming enum members and non-function-like macros, use
   `SCREAMING_SNAKE_CASE`. Function-like macros should be named the same as
   actual functions.
10. If something can be `const`, make it `const`.
11. All `#endif` directives must have a comment next to them mentioning what the
    block was created to define.
12. Macros must be indented with 1 space per level **after the hash** `#`. This
    does not apply to macros residing in **only** header guards.

For more information, see the K&R coding style, the [linux kernel coding
style](https://github.com/torvalds/linux/blob/master/Documentation/process/coding-style.rst),
and this project's source tree.

## 4) How to submit

You **never** want to commit to `main`. Instead, you should either create a
**fork of the repo**, or, if you're a maintainer, create a branch with the
following naming style:

1. If you're adding a feature, `feat/`
2. If you're doing a bug fix, `bug/`
3. If you're editing docs, `docs/`
4. If you're refactoring, `refact/`
5. If you're optimizing, `perf/`
6. If you're editing a script, `script/`
7. If you're creating unit tests, `test/`
8. If you're doing an emergency bug fix, `hot/`

> The difference between `bug/` and `hot/` is mainly that `bug/` will be a
> bug fixed in the next version of the interpreter, whilst a `hot/` will be a
> bug fixed in the current version of the interpreter. Hotfixes should only be
> emergency bug fixes that are crashing the interpreter for everyone.

After the `/`, you should put a short description of whatever you are doing.
Examples:

- `feat/add-hashmap`
- `bug/incorrect-probing`
- `docs/edit-readme`
- `refact/make-vectorops-more-portable`
- `perf/optimize-probing`
- `script/automate-testing`
- `test/overflow-tests`
- `hot/incorrect-initialization-of-api`
