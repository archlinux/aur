using Avalonia.Controls;

namespace Nexora.Controls;

public partial class AudioTrackView : UserControl
{
    public AudioTrackView()
    {
        InitializeComponent();
    }
}
