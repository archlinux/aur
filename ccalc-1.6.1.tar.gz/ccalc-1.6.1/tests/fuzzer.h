#include <stdlib.h>
#include "../../engine/tree/node.h"

void get_random_tree(size_t max_inner_nodes, Node **out);
