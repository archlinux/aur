#include "test.h"

Test get_randomized_test();
