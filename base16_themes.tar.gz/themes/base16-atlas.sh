#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atlas scheme by Alex Lende (https://ajlende.com)
export BASE16_TTY_THEME=atlas

color00="002635" # Base 00 - Black
color01="ff5a67" # Base 08 - Red
color02="7fc06e" # Base 0B - Green
color03="ffcc1b" # Base 0A - Yellow
color04="5dd7b9" # Base 0D - Blue
color05="9a70a4" # Base 0E - Magenta
color06="14747e" # Base 0C - Cyan
color07="a1a19a" # Base 05 - White
color08="6C8B91" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="fafaf8" # Base 07 - Bright White
color16="f08e48" # Base 09
color17="c43060" # Base 0F
color18="00384d" # Base 01
color19="517F8D" # Base 02
color20="869696" # Base 04
color21="e6e6dc" # Base 06
color_foreground="a1a19a" # Base 05
color_background="002635" # Base 00

