#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Helios scheme by Alex Meyer (https://github.com/reyemxela)
export BASE16_TTY_THEME=helios

color00="1d2021" # Base 00 - Black
color01="d72638" # Base 08 - Red
color02="88b92d" # Base 0B - Green
color03="f19d1a" # Base 0A - Yellow
color04="1e8bac" # Base 0D - Blue
color05="be4264" # Base 0E - Magenta
color06="1ba595" # Base 0C - Cyan
color07="d5d5d5" # Base 05 - White
color08="6f7579" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="e5e5e5" # Base 07 - Bright White
color16="eb8413" # Base 09
color17="c85e0d" # Base 0F
color18="383c3e" # Base 01
color19="53585b" # Base 02
color20="cdcdcd" # Base 04
color21="dddddd" # Base 06
color_foreground="d5d5d5" # Base 05
color_background="1d2021" # Base 00

