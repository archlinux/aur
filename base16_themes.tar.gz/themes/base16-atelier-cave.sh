#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Cave scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-cave

color00="19171c" # Base 00 - Black
color01="be4678" # Base 08 - Red
color02="2a9292" # Base 0B - Green
color03="a06e3b" # Base 0A - Yellow
color04="576ddb" # Base 0D - Blue
color05="955ae7" # Base 0E - Magenta
color06="398bc6" # Base 0C - Cyan
color07="8b8792" # Base 05 - White
color08="655f6d" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="efecf4" # Base 07 - Bright White
color16="aa573c" # Base 09
color17="bf40bf" # Base 0F
color18="26232a" # Base 01
color19="585260" # Base 02
color20="7e7887" # Base 04
color21="e2dfe7" # Base 06
color_foreground="8b8792" # Base 05
color_background="19171c" # Base 00

