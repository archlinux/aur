#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Spacemacs scheme by Nasser Alshammari (https://github.com/nashamri/spacemacs-theme)
export BASE16_TTY_THEME=spacemacs

color00="1f2022" # Base 00 - Black
color01="f2241f" # Base 08 - Red
color02="67b11d" # Base 0B - Green
color03="b1951d" # Base 0A - Yellow
color04="4f97d7" # Base 0D - Blue
color05="a31db1" # Base 0E - Magenta
color06="2d9574" # Base 0C - Cyan
color07="a3a3a3" # Base 05 - White
color08="585858" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f8f8f8" # Base 07 - Bright White
color16="ffa500" # Base 09
color17="b03060" # Base 0F
color18="282828" # Base 01
color19="444155" # Base 02
color20="b8b8b8" # Base 04
color21="e8e8e8" # Base 06
color_foreground="a3a3a3" # Base 05
color_background="1f2022" # Base 00

