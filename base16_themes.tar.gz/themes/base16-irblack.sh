#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# IR Black scheme by Timothée Poisot (http://timotheepoisot.fr)
export BASE16_TTY_THEME=irblack

color00="000000" # Base 00 - Black
color01="ff6c60" # Base 08 - Red
color02="a8ff60" # Base 0B - Green
color03="ffffb6" # Base 0A - Yellow
color04="96cbfe" # Base 0D - Blue
color05="ff73fd" # Base 0E - Magenta
color06="c6c5fe" # Base 0C - Cyan
color07="b5b3aa" # Base 05 - White
color08="6c6c66" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="fdfbee" # Base 07 - Bright White
color16="e9c062" # Base 09
color17="b18a3d" # Base 0F
color18="242422" # Base 01
color19="484844" # Base 02
color20="918f88" # Base 04
color21="d9d7cc" # Base 06
color_foreground="b5b3aa" # Base 05
color_background="000000" # Base 00

