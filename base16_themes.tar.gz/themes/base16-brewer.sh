#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Brewer scheme by Timothée Poisot (http://github.com/tpoisot)
export BASE16_TTY_THEME=brewer

color00="0c0d0e" # Base 00 - Black
color01="e31a1c" # Base 08 - Red
color02="31a354" # Base 0B - Green
color03="dca060" # Base 0A - Yellow
color04="3182bd" # Base 0D - Blue
color05="756bb1" # Base 0E - Magenta
color06="80b1d3" # Base 0C - Cyan
color07="b7b8b9" # Base 05 - White
color08="737475" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="fcfdfe" # Base 07 - Bright White
color16="e6550d" # Base 09
color17="b15928" # Base 0F
color18="2e2f30" # Base 01
color19="515253" # Base 02
color20="959697" # Base 04
color21="dadbdc" # Base 06
color_foreground="b7b8b9" # Base 05
color_background="0c0d0e" # Base 00

