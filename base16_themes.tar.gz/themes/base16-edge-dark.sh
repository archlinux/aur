#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Edge Dark scheme by cjayross (https://github.com/cjayross)
export BASE16_TTY_THEME=edge-dark

color00="262729" # Base 00 - Black
color01="e77171" # Base 08 - Red
color02="a1bf78" # Base 0B - Green
color03="dbb774" # Base 0A - Yellow
color04="73b3e7" # Base 0D - Blue
color05="d390e7" # Base 0E - Magenta
color06="5ebaa5" # Base 0C - Cyan
color07="b7bec9" # Base 05 - White
color08="3e4249" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="3e4249" # Base 07 - Bright White
color16="e77171" # Base 09
color17="5ebaa5" # Base 0F
color18="88909f" # Base 01
color19="b7bec9" # Base 02
color20="73b3e7" # Base 04
color21="d390e7" # Base 06
color_foreground="b7bec9" # Base 05
color_background="262729" # Base 00

