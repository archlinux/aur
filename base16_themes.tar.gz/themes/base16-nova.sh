#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Nova scheme by George Essig (https://github.com/gessig), Trevor D. Miller (https://trevordmiller.com)
export BASE16_TTY_THEME=nova

color00="3C4C55" # Base 00 - Black
color01="83AFE5" # Base 08 - Red
color02="7FC1CA" # Base 0B - Green
color03="A8CE93" # Base 0A - Yellow
color04="83AFE5" # Base 0D - Blue
color05="9A93E1" # Base 0E - Magenta
color06="F2C38F" # Base 0C - Cyan
color07="C5D4DD" # Base 05 - White
color08="899BA6" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="556873" # Base 07 - Bright White
color16="7FC1CA" # Base 09
color17="F2C38F" # Base 0F
color18="556873" # Base 01
color19="6A7D89" # Base 02
color20="899BA6" # Base 04
color21="899BA6" # Base 06
color_foreground="C5D4DD" # Base 05
color_background="3C4C55" # Base 00

