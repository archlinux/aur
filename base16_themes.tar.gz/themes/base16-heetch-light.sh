#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Heetch Light scheme by Geoffrey Teale (tealeg@gmail.com)
export BASE16_TTY_THEME=heetch-light

color00="feffff" # Base 00 - Black
color01="27d9d5" # Base 08 - Red
color02="f80059" # Base 0B - Green
color03="5ba2b6" # Base 0A - Yellow
color04="47f9f5" # Base 0D - Blue
color05="bd0152" # Base 0E - Magenta
color06="c33678" # Base 0C - Cyan
color07="5a496e" # Base 05 - White
color08="9c92a8" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="190134" # Base 07 - Bright White
color16="bdb6c5" # Base 09
color17="dedae2" # Base 0F
color18="392551" # Base 01
color19="7b6d8b" # Base 02
color20="ddd6e5" # Base 04
color21="470546" # Base 06
color_foreground="5a496e" # Base 05
color_background="feffff" # Base 00

