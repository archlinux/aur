#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Railscasts scheme by Ryan Bates (http://railscasts.com)
export BASE16_TTY_THEME=railscasts

color00="2b2b2b" # Base 00 - Black
color01="da4939" # Base 08 - Red
color02="a5c261" # Base 0B - Green
color03="ffc66d" # Base 0A - Yellow
color04="6d9cbe" # Base 0D - Blue
color05="b6b3eb" # Base 0E - Magenta
color06="519f50" # Base 0C - Cyan
color07="e6e1dc" # Base 05 - White
color08="5a647e" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f9f7f3" # Base 07 - Bright White
color16="cc7833" # Base 09
color17="bc9458" # Base 0F
color18="272935" # Base 01
color19="3a4055" # Base 02
color20="d4cfc9" # Base 04
color21="f4f1ed" # Base 06
color_foreground="e6e1dc" # Base 05
color_background="2b2b2b" # Base 00

