#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Outrun Dark scheme by Hugo Delahousse (http://github.com/hugodelahousse/)
export BASE16_TTY_THEME=outrun-dark

color00="00002A" # Base 00 - Black
color01="FF4242" # Base 08 - Red
color02="59F176" # Base 0B - Green
color03="F3E877" # Base 0A - Yellow
color04="66B0FF" # Base 0D - Blue
color05="F10596" # Base 0E - Magenta
color06="0EF0F0" # Base 0C - Cyan
color07="D0D0FA" # Base 05 - White
color08="50507A" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="F5F5FF" # Base 07 - Bright White
color16="FC8D28" # Base 09
color17="F003EF" # Base 0F
color18="20204A" # Base 01
color19="30305A" # Base 02
color20="B0B0DA" # Base 04
color21="E0E0FF" # Base 06
color_foreground="D0D0FA" # Base 05
color_background="00002A" # Base 00

