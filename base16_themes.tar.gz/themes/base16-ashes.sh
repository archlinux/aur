#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Ashes scheme by Jannik Siebert (https://github.com/janniks)
export BASE16_TTY_THEME=ashes

color00="1C2023" # Base 00 - Black
color01="C7AE95" # Base 08 - Red
color02="95C7AE" # Base 0B - Green
color03="AEC795" # Base 0A - Yellow
color04="AE95C7" # Base 0D - Blue
color05="C795AE" # Base 0E - Magenta
color06="95AEC7" # Base 0C - Cyan
color07="C7CCD1" # Base 05 - White
color08="747C84" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="F3F4F5" # Base 07 - Bright White
color16="C7C795" # Base 09
color17="C79595" # Base 0F
color18="393F45" # Base 01
color19="565E65" # Base 02
color20="ADB3BA" # Base 04
color21="DFE2E5" # Base 06
color_foreground="C7CCD1" # Base 05
color_background="1C2023" # Base 00

