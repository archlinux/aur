#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Github scheme by Defman21
export BASE16_TTY_THEME=github

color00="ffffff" # Base 00 - Black
color01="ed6a43" # Base 08 - Red
color02="183691" # Base 0B - Green
color03="795da3" # Base 0A - Yellow
color04="795da3" # Base 0D - Blue
color05="a71d5d" # Base 0E - Magenta
color06="183691" # Base 0C - Cyan
color07="333333" # Base 05 - White
color08="969896" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="0086b3" # Base 09
color17="333333" # Base 0F
color18="f5f5f5" # Base 01
color19="c8c8fa" # Base 02
color20="e8e8e8" # Base 04
color21="ffffff" # Base 06
color_foreground="333333" # Base 05
color_background="ffffff" # Base 00

