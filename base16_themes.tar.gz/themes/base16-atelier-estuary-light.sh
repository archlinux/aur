#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Estuary Light scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-estuary-light

color00="f4f3ec" # Base 00 - Black
color01="ba6236" # Base 08 - Red
color02="7d9726" # Base 0B - Green
color03="a5980d" # Base 0A - Yellow
color04="36a166" # Base 0D - Blue
color05="5f9182" # Base 0E - Magenta
color06="5b9d48" # Base 0C - Cyan
color07="5f5e4e" # Base 05 - White
color08="878573" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="22221b" # Base 07 - Bright White
color16="ae7313" # Base 09
color17="9d6c7c" # Base 0F
color18="e7e6df" # Base 01
color19="929181" # Base 02
color20="6c6b5a" # Base 04
color21="302f27" # Base 06
color_foreground="5f5e4e" # Base 05
color_background="f4f3ec" # Base 00

