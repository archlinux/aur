#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Unikitty Light scheme by Josh W Lewis (@joshwlewis)
export BASE16_TTY_THEME=unikitty-light

color00="ffffff" # Base 00 - Black
color01="d8137f" # Base 08 - Red
color02="17ad98" # Base 0B - Green
color03="dc8a0e" # Base 0A - Yellow
color04="775dff" # Base 0D - Blue
color05="aa17e6" # Base 0E - Magenta
color06="149bda" # Base 0C - Cyan
color07="6c696e" # Base 05 - White
color08="a7a5a8" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="322d34" # Base 07 - Bright White
color16="d65407" # Base 09
color17="e013d0" # Base 0F
color18="e1e1e2" # Base 01
color19="c4c3c5" # Base 02
color20="89878b" # Base 04
color21="4f4b51" # Base 06
color_foreground="6c696e" # Base 05
color_background="ffffff" # Base 00

