#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Darktooth scheme by Jason Milkins (https://github.com/jasonm23)
export BASE16_TTY_THEME=darktooth

color00="1D2021" # Base 00 - Black
color01="FB543F" # Base 08 - Red
color02="95C085" # Base 0B - Green
color03="FAC03B" # Base 0A - Yellow
color04="0D6678" # Base 0D - Blue
color05="8F4673" # Base 0E - Magenta
color06="8BA59B" # Base 0C - Cyan
color07="A89984" # Base 05 - White
color08="665C54" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FDF4C1" # Base 07 - Bright White
color16="FE8625" # Base 09
color17="A87322" # Base 0F
color18="32302F" # Base 01
color19="504945" # Base 02
color20="928374" # Base 04
color21="D5C4A1" # Base 06
color_foreground="A89984" # Base 05
color_background="1D2021" # Base 00

