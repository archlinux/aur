#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Mocha scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=mocha

color00="3B3228" # Base 00 - Black
color01="cb6077" # Base 08 - Red
color02="beb55b" # Base 0B - Green
color03="f4bc87" # Base 0A - Yellow
color04="8ab3b5" # Base 0D - Blue
color05="a89bb9" # Base 0E - Magenta
color06="7bbda4" # Base 0C - Cyan
color07="d0c8c6" # Base 05 - White
color08="7e705a" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f5eeeb" # Base 07 - Bright White
color16="d28b71" # Base 09
color17="bb9584" # Base 0F
color18="534636" # Base 01
color19="645240" # Base 02
color20="b8afad" # Base 04
color21="e9e1dd" # Base 06
color_foreground="d0c8c6" # Base 05
color_background="3B3228" # Base 00

