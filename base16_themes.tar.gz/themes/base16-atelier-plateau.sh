#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Plateau scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-plateau

color00="1b1818" # Base 00 - Black
color01="ca4949" # Base 08 - Red
color02="4b8b8b" # Base 0B - Green
color03="a06e3b" # Base 0A - Yellow
color04="7272ca" # Base 0D - Blue
color05="8464c4" # Base 0E - Magenta
color06="5485b6" # Base 0C - Cyan
color07="8a8585" # Base 05 - White
color08="655d5d" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f4ecec" # Base 07 - Bright White
color16="b45a3c" # Base 09
color17="bd5187" # Base 0F
color18="292424" # Base 01
color19="585050" # Base 02
color20="7e7777" # Base 04
color21="e7dfdf" # Base 06
color_foreground="8a8585" # Base 05
color_background="1b1818" # Base 00

