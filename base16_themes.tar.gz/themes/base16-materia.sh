#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Materia scheme by Defman21
export BASE16_TTY_THEME=materia

color00="263238" # Base 00 - Black
color01="EC5F67" # Base 08 - Red
color02="8BD649" # Base 0B - Green
color03="FFCC00" # Base 0A - Yellow
color04="89DDFF" # Base 0D - Blue
color05="82AAFF" # Base 0E - Magenta
color06="80CBC4" # Base 0C - Cyan
color07="CDD3DE" # Base 05 - White
color08="707880" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FFFFFF" # Base 07 - Bright White
color16="EA9560" # Base 09
color17="EC5F67" # Base 0F
color18="2C393F" # Base 01
color19="37474F" # Base 02
color20="C9CCD3" # Base 04
color21="D5DBE5" # Base 06
color_foreground="CDD3DE" # Base 05
color_background="263238" # Base 00

