#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Cupertino scheme by Defman21
export BASE16_TTY_THEME=cupertino

color00="ffffff" # Base 00 - Black
color01="c41a15" # Base 08 - Red
color02="007400" # Base 0B - Green
color03="826b28" # Base 0A - Yellow
color04="0000ff" # Base 0D - Blue
color05="a90d91" # Base 0E - Magenta
color06="318495" # Base 0C - Cyan
color07="404040" # Base 05 - White
color08="808080" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="5e5e5e" # Base 07 - Bright White
color16="eb8500" # Base 09
color17="826b28" # Base 0F
color18="c0c0c0" # Base 01
color19="c0c0c0" # Base 02
color20="808080" # Base 04
color21="404040" # Base 06
color_foreground="404040" # Base 05
color_background="ffffff" # Base 00

