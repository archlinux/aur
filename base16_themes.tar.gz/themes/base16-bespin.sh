#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Bespin scheme by Jan T. Sott
export BASE16_TTY_THEME=bespin

color00="28211c" # Base 00 - Black
color01="cf6a4c" # Base 08 - Red
color02="54be0d" # Base 0B - Green
color03="f9ee98" # Base 0A - Yellow
color04="5ea6ea" # Base 0D - Blue
color05="9b859d" # Base 0E - Magenta
color06="afc4db" # Base 0C - Cyan
color07="8a8986" # Base 05 - White
color08="666666" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="baae9e" # Base 07 - Bright White
color16="cf7d34" # Base 09
color17="937121" # Base 0F
color18="36312e" # Base 01
color19="5e5d5c" # Base 02
color20="797977" # Base 04
color21="9d9b97" # Base 06
color_foreground="8a8986" # Base 05
color_background="28211c" # Base 00

