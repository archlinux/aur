#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# One Light scheme by Daniel Pfeifer (http://github.com/purpleKarrot)
export BASE16_TTY_THEME=one-light

color00="fafafa" # Base 00 - Black
color01="ca1243" # Base 08 - Red
color02="50a14f" # Base 0B - Green
color03="c18401" # Base 0A - Yellow
color04="4078f2" # Base 0D - Blue
color05="a626a4" # Base 0E - Magenta
color06="0184bc" # Base 0C - Cyan
color07="383a42" # Base 05 - White
color08="a0a1a7" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="090a0b" # Base 07 - Bright White
color16="d75f00" # Base 09
color17="986801" # Base 0F
color18="f0f0f1" # Base 01
color19="e5e5e6" # Base 02
color20="696c77" # Base 04
color21="202227" # Base 06
color_foreground="383a42" # Base 05
color_background="fafafa" # Base 00

