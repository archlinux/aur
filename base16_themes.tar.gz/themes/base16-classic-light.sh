#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Classic Light scheme by Jason Heeris (http://heeris.id.au)
export BASE16_TTY_THEME=classic-light

color00="F5F5F5" # Base 00 - Black
color01="AC4142" # Base 08 - Red
color02="90A959" # Base 0B - Green
color03="F4BF75" # Base 0A - Yellow
color04="6A9FB5" # Base 0D - Blue
color05="AA759F" # Base 0E - Magenta
color06="75B5AA" # Base 0C - Cyan
color07="303030" # Base 05 - White
color08="B0B0B0" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="151515" # Base 07 - Bright White
color16="D28445" # Base 09
color17="8F5536" # Base 0F
color18="E0E0E0" # Base 01
color19="D0D0D0" # Base 02
color20="505050" # Base 04
color21="202020" # Base 06
color_foreground="303030" # Base 05
color_background="F5F5F5" # Base 00

