#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# iA Light scheme by iA Inc. (modified by aramisgithub)
export BASE16_TTY_THEME=ia-light

color00="f6f6f6" # Base 00 - Black
color01="9c5a02" # Base 08 - Red
color02="38781c" # Base 0B - Green
color03="c48218" # Base 0A - Yellow
color04="48bac2" # Base 0D - Blue
color05="a94598" # Base 0E - Magenta
color06="2d6bb1" # Base 0C - Cyan
color07="181818" # Base 05 - White
color08="898989" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f8f8f8" # Base 07 - Bright White
color16="c43e18" # Base 09
color17="8b6c37" # Base 0F
color18="dedede" # Base 01
color19="bde5f2" # Base 02
color20="767676" # Base 04
color21="e8e8e8" # Base 06
color_foreground="181818" # Base 05
color_background="f6f6f6" # Base 00

