#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Edge Light scheme by cjayross (https://github.com/cjayross)
export BASE16_TTY_THEME=edge-light

color00="fafafa" # Base 00 - Black
color01="db7070" # Base 08 - Red
color02="7c9f4b" # Base 0B - Green
color03="d69822" # Base 0A - Yellow
color04="6587bf" # Base 0D - Blue
color05="b870ce" # Base 0E - Magenta
color06="509c93" # Base 0C - Cyan
color07="5e646f" # Base 05 - White
color08="5e646f" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="5e646f" # Base 07 - Bright White
color16="db7070" # Base 09
color17="509c93" # Base 0F
color18="7c9f4b" # Base 01
color19="d69822" # Base 02
color20="6587bf" # Base 04
color21="b870ce" # Base 06
color_foreground="5e646f" # Base 05
color_background="fafafa" # Base 00

