#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Bright scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=bright

color00="000000" # Base 00 - Black
color01="fb0120" # Base 08 - Red
color02="a1c659" # Base 0B - Green
color03="fda331" # Base 0A - Yellow
color04="6fb3d2" # Base 0D - Blue
color05="d381c3" # Base 0E - Magenta
color06="76c7b7" # Base 0C - Cyan
color07="e0e0e0" # Base 05 - White
color08="b0b0b0" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="fc6d24" # Base 09
color17="be643c" # Base 0F
color18="303030" # Base 01
color19="505050" # Base 02
color20="d0d0d0" # Base 04
color21="f5f5f5" # Base 06
color_foreground="e0e0e0" # Base 05
color_background="000000" # Base 00

