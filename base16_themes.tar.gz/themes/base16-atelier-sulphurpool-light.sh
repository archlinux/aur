#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Sulphurpool Light scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-sulphurpool-light

color00="f5f7ff" # Base 00 - Black
color01="c94922" # Base 08 - Red
color02="ac9739" # Base 0B - Green
color03="c08b30" # Base 0A - Yellow
color04="3d8fd1" # Base 0D - Blue
color05="6679cc" # Base 0E - Magenta
color06="22a2c9" # Base 0C - Cyan
color07="5e6687" # Base 05 - White
color08="898ea4" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="202746" # Base 07 - Bright White
color16="c76b29" # Base 09
color17="9c637a" # Base 0F
color18="dfe2f1" # Base 01
color19="979db4" # Base 02
color20="6b7394" # Base 04
color21="293256" # Base 06
color_foreground="5e6687" # Base 05
color_background="f5f7ff" # Base 00

