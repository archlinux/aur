#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Porple scheme by Niek den Breeje (https://github.com/AuditeMarlow)
export BASE16_TTY_THEME=porple

color00="292c36" # Base 00 - Black
color01="f84547" # Base 08 - Red
color02="95c76f" # Base 0B - Green
color03="efa16b" # Base 0A - Yellow
color04="8485ce" # Base 0D - Blue
color05="b74989" # Base 0E - Magenta
color06="64878f" # Base 0C - Cyan
color07="d8d8d8" # Base 05 - White
color08="65568a" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f8f8f8" # Base 07 - Bright White
color16="d28e5d" # Base 09
color17="986841" # Base 0F
color18="333344" # Base 01
color19="474160" # Base 02
color20="b8b8b8" # Base 04
color21="e8e8e8" # Base 06
color_foreground="d8d8d8" # Base 05
color_background="292c36" # Base 00

