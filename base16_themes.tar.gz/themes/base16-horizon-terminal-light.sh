#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Horizon Light scheme by Michaël Ball (http://github.com/michael-ball/)
export BASE16_TTY_THEME=horizon-terminal-light

color00="FDF0ED" # Base 00 - Black
color01="E95678" # Base 08 - Red
color02="29D398" # Base 0B - Green
color03="FADAD1" # Base 0A - Yellow
color04="26BBD9" # Base 0D - Blue
color05="EE64AC" # Base 0E - Magenta
color06="59E1E3" # Base 0C - Cyan
color07="403C3D" # Base 05 - White
color08="BDB3B1" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="201C1D" # Base 07 - Bright White
color16="F9CEC3" # Base 09
color17="F9CBBE" # Base 0F
color18="FADAD1" # Base 01
color19="F9CBBE" # Base 02
color20="948C8A" # Base 04
color21="302C2D" # Base 06
color_foreground="403C3D" # Base 05
color_background="FDF0ED" # Base 00

