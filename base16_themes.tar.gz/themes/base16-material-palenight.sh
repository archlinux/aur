#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Material Palenight scheme by Nate Peterson
export BASE16_TTY_THEME=material-palenight

color00="292D3E" # Base 00 - Black
color01="F07178" # Base 08 - Red
color02="C3E88D" # Base 0B - Green
color03="FFCB6B" # Base 0A - Yellow
color04="82AAFF" # Base 0D - Blue
color05="C792EA" # Base 0E - Magenta
color06="89DDFF" # Base 0C - Cyan
color07="959DCB" # Base 05 - White
color08="676E95" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FFFFFF" # Base 07 - Bright White
color16="F78C6C" # Base 09
color17="FF5370" # Base 0F
color18="444267" # Base 01
color19="32374D" # Base 02
color20="8796B0" # Base 04
color21="959DCB" # Base 06
color_foreground="959DCB" # Base 05
color_background="292D3E" # Base 00

