#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Solar Flare scheme by Chuck Harmston (https://chuck.harmston.ch)
export BASE16_TTY_THEME=solarflare

color00="18262F" # Base 00 - Black
color01="EF5253" # Base 08 - Red
color02="7CC844" # Base 0B - Green
color03="E4B51C" # Base 0A - Yellow
color04="33B5E1" # Base 0D - Blue
color05="A363D5" # Base 0E - Magenta
color06="52CBB0" # Base 0C - Cyan
color07="A6AFB8" # Base 05 - White
color08="667581" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="F5F7FA" # Base 07 - Bright White
color16="E66B2B" # Base 09
color17="D73C9A" # Base 0F
color18="222E38" # Base 01
color19="586875" # Base 02
color20="85939E" # Base 04
color21="E8E9ED" # Base 06
color_foreground="A6AFB8" # Base 05
color_background="18262F" # Base 00

