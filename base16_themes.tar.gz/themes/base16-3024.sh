#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# 3024 scheme by Jan T. Sott (http://github.com/idleberg)
export BASE16_TTY_THEME=3024

color00="090300" # Base 00 - Black
color01="db2d20" # Base 08 - Red
color02="01a252" # Base 0B - Green
color03="fded02" # Base 0A - Yellow
color04="01a0e4" # Base 0D - Blue
color05="a16a94" # Base 0E - Magenta
color06="b5e4f4" # Base 0C - Cyan
color07="a5a2a2" # Base 05 - White
color08="5c5855" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f7f7f7" # Base 07 - Bright White
color16="e8bbd0" # Base 09
color17="cdab53" # Base 0F
color18="3a3432" # Base 01
color19="4a4543" # Base 02
color20="807d7c" # Base 04
color21="d6d5d4" # Base 06
color_foreground="a5a2a2" # Base 05
color_background="090300" # Base 00

