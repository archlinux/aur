#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Chalk scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=chalk

color00="151515" # Base 00 - Black
color01="fb9fb1" # Base 08 - Red
color02="acc267" # Base 0B - Green
color03="ddb26f" # Base 0A - Yellow
color04="6fc2ef" # Base 0D - Blue
color05="e1a3ee" # Base 0E - Magenta
color06="12cfc0" # Base 0C - Cyan
color07="d0d0d0" # Base 05 - White
color08="505050" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f5f5f5" # Base 07 - Bright White
color16="eda987" # Base 09
color17="deaf8f" # Base 0F
color18="202020" # Base 01
color19="303030" # Base 02
color20="b0b0b0" # Base 04
color21="e0e0e0" # Base 06
color_foreground="d0d0d0" # Base 05
color_background="151515" # Base 00

