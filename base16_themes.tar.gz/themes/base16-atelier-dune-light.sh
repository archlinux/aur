#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Dune Light scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-dune-light

color00="fefbec" # Base 00 - Black
color01="d73737" # Base 08 - Red
color02="60ac39" # Base 0B - Green
color03="ae9513" # Base 0A - Yellow
color04="6684e1" # Base 0D - Blue
color05="b854d4" # Base 0E - Magenta
color06="1fad83" # Base 0C - Cyan
color07="6e6b5e" # Base 05 - White
color08="999580" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="20201d" # Base 07 - Bright White
color16="b65611" # Base 09
color17="d43552" # Base 0F
color18="e8e4cf" # Base 01
color19="a6a28c" # Base 02
color20="7d7a68" # Base 04
color21="292824" # Base 06
color_foreground="6e6b5e" # Base 05
color_background="fefbec" # Base 00

