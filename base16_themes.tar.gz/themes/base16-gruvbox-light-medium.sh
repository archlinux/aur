#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Gruvbox light, medium scheme by Dawid Kurek (dawikur@gmail.com), morhetz (https://github.com/morhetz/gruvbox)
export BASE16_TTY_THEME=gruvbox-light-medium

color00="fbf1c7" # Base 00 - Black
color01="9d0006" # Base 08 - Red
color02="79740e" # Base 0B - Green
color03="b57614" # Base 0A - Yellow
color04="076678" # Base 0D - Blue
color05="8f3f71" # Base 0E - Magenta
color06="427b58" # Base 0C - Cyan
color07="504945" # Base 05 - White
color08="bdae93" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="282828" # Base 07 - Bright White
color16="af3a03" # Base 09
color17="d65d0e" # Base 0F
color18="ebdbb2" # Base 01
color19="d5c4a1" # Base 02
color20="665c54" # Base 04
color21="3c3836" # Base 06
color_foreground="504945" # Base 05
color_background="fbf1c7" # Base 00

