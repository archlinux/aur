#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Gruvbox dark, medium scheme by Dawid Kurek (dawikur@gmail.com), morhetz (https://github.com/morhetz/gruvbox)
export BASE16_TTY_THEME=gruvbox-dark-medium

color00="282828" # Base 00 - Black
color01="fb4934" # Base 08 - Red
color02="b8bb26" # Base 0B - Green
color03="fabd2f" # Base 0A - Yellow
color04="83a598" # Base 0D - Blue
color05="d3869b" # Base 0E - Magenta
color06="8ec07c" # Base 0C - Cyan
color07="d5c4a1" # Base 05 - White
color08="665c54" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="fbf1c7" # Base 07 - Bright White
color16="fe8019" # Base 09
color17="d65d0e" # Base 0F
color18="3c3836" # Base 01
color19="504945" # Base 02
color20="bdae93" # Base 04
color21="ebdbb2" # Base 06
color_foreground="d5c4a1" # Base 05
color_background="282828" # Base 00

