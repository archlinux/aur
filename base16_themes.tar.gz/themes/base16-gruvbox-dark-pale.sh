#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Gruvbox dark, pale scheme by Dawid Kurek (dawikur@gmail.com), morhetz (https://github.com/morhetz/gruvbox)
export BASE16_TTY_THEME=gruvbox-dark-pale

color00="262626" # Base 00 - Black
color01="d75f5f" # Base 08 - Red
color02="afaf00" # Base 0B - Green
color03="ffaf00" # Base 0A - Yellow
color04="83adad" # Base 0D - Blue
color05="d485ad" # Base 0E - Magenta
color06="85ad85" # Base 0C - Cyan
color07="dab997" # Base 05 - White
color08="8a8a8a" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ebdbb2" # Base 07 - Bright White
color16="ff8700" # Base 09
color17="d65d0e" # Base 0F
color18="3a3a3a" # Base 01
color19="4e4e4e" # Base 02
color20="949494" # Base 04
color21="d5c4a1" # Base 06
color_foreground="dab997" # Base 05
color_background="262626" # Base 00

