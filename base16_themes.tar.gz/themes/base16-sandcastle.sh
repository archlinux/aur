#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Sandcastle scheme by George Essig (https://github.com/gessig)
export BASE16_TTY_THEME=sandcastle

color00="282c34" # Base 00 - Black
color01="83a598" # Base 08 - Red
color02="528b8b" # Base 0B - Green
color03="a07e3b" # Base 0A - Yellow
color04="83a598" # Base 0D - Blue
color05="d75f5f" # Base 0E - Magenta
color06="83a598" # Base 0C - Cyan
color07="a89984" # Base 05 - White
color08="665c54" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="fdf4c1" # Base 07 - Bright White
color16="a07e3b" # Base 09
color17="a87322" # Base 0F
color18="2c323b" # Base 01
color19="3e4451" # Base 02
color20="928374" # Base 04
color21="d5c4a1" # Base 06
color_foreground="a89984" # Base 05
color_background="282c34" # Base 00

