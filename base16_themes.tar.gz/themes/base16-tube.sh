#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# London Tube scheme by Jan T. Sott
export BASE16_TTY_THEME=tube

color00="231f20" # Base 00 - Black
color01="ee2e24" # Base 08 - Red
color02="00853e" # Base 0B - Green
color03="ffd204" # Base 0A - Yellow
color04="009ddc" # Base 0D - Blue
color05="98005d" # Base 0E - Magenta
color06="85cebc" # Base 0C - Cyan
color07="d9d8d8" # Base 05 - White
color08="737171" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="f386a1" # Base 09
color17="b06110" # Base 0F
color18="1c3f95" # Base 01
color19="5a5758" # Base 02
color20="959ca1" # Base 04
color21="e7e7e8" # Base 06
color_foreground="d9d8d8" # Base 05
color_background="231f20" # Base 00

