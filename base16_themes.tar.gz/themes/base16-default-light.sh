#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Default Light scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=default-light

color00="f8f8f8" # Base 00 - Black
color01="ab4642" # Base 08 - Red
color02="a1b56c" # Base 0B - Green
color03="f7ca88" # Base 0A - Yellow
color04="7cafc2" # Base 0D - Blue
color05="ba8baf" # Base 0E - Magenta
color06="86c1b9" # Base 0C - Cyan
color07="383838" # Base 05 - White
color08="b8b8b8" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="181818" # Base 07 - Bright White
color16="dc9656" # Base 09
color17="a16946" # Base 0F
color18="e8e8e8" # Base 01
color19="d8d8d8" # Base 02
color20="585858" # Base 04
color21="282828" # Base 06
color_foreground="383838" # Base 05
color_background="f8f8f8" # Base 00

