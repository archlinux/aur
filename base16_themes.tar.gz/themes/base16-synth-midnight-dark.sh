#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Synth Midnight Dark scheme by Michaël Ball (http://github.com/michael-ball/)
export BASE16_TTY_THEME=synth-midnight-dark

color00="040404" # Base 00 - Black
color01="B53B50" # Base 08 - Red
color02="06EA61" # Base 0B - Green
color03="DAE84D" # Base 0A - Yellow
color04="03AEFF" # Base 0D - Blue
color05="EA5CE2" # Base 0E - Magenta
color06="7CEDE9" # Base 0C - Cyan
color07="DFDBDF" # Base 05 - White
color08="61507A" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FFFBFF" # Base 07 - Bright White
color16="E4600E" # Base 09
color17="9D4D0E" # Base 0F
color18="141414" # Base 01
color19="242424" # Base 02
color20="BFBBBF" # Base 04
color21="EFEBEF" # Base 06
color_foreground="DFDBDF" # Base 05
color_background="040404" # Base 00

