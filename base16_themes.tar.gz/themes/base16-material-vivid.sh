#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Material Vivid scheme by joshyrobot
export BASE16_TTY_THEME=material-vivid

color00="202124" # Base 00 - Black
color01="f44336" # Base 08 - Red
color02="00e676" # Base 0B - Green
color03="ffeb3b" # Base 0A - Yellow
color04="2196f3" # Base 0D - Blue
color05="673ab7" # Base 0E - Magenta
color06="00bcd4" # Base 0C - Cyan
color07="80868b" # Base 05 - White
color08="44464d" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="ff9800" # Base 09
color17="8d6e63" # Base 0F
color18="27292c" # Base 01
color19="323639" # Base 02
color20="676c71" # Base 04
color21="9e9e9e" # Base 06
color_foreground="80868b" # Base 05
color_background="202124" # Base 00

