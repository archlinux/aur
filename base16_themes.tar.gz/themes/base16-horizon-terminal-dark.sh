#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Horizon Dark scheme by Michaël Ball (http://github.com/michael-ball/)
export BASE16_TTY_THEME=horizon-terminal-dark

color00="1C1E26" # Base 00 - Black
color01="E95678" # Base 08 - Red
color02="29D398" # Base 0B - Green
color03="FAC29A" # Base 0A - Yellow
color04="26BBD9" # Base 0D - Blue
color05="EE64AC" # Base 0E - Magenta
color06="59E1E3" # Base 0C - Cyan
color07="CBCED0" # Base 05 - White
color08="6F6F70" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="E3E6EE" # Base 07 - Bright White
color16="FAB795" # Base 09
color17="F09383" # Base 0F
color18="232530" # Base 01
color19="2E303E" # Base 02
color20="9DA0A2" # Base 04
color21="DCDFE4" # Base 06
color_foreground="CBCED0" # Base 05
color_background="1C1E26" # Base 00

