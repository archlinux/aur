#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Summerfruit Dark scheme by Christopher Corley (http://christop.club/)
export BASE16_TTY_THEME=summerfruit-dark

color00="151515" # Base 00 - Black
color01="FF0086" # Base 08 - Red
color02="00C918" # Base 0B - Green
color03="ABA800" # Base 0A - Yellow
color04="3777E6" # Base 0D - Blue
color05="AD00A1" # Base 0E - Magenta
color06="1FAAAA" # Base 0C - Cyan
color07="D0D0D0" # Base 05 - White
color08="505050" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FFFFFF" # Base 07 - Bright White
color16="FD8900" # Base 09
color17="CC6633" # Base 0F
color18="202020" # Base 01
color19="303030" # Base 02
color20="B0B0B0" # Base 04
color21="E0E0E0" # Base 06
color_foreground="D0D0D0" # Base 05
color_background="151515" # Base 00

