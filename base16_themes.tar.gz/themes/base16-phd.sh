#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# PhD scheme by Hennig Hasemann (http://leetless.de/vim.html)
export BASE16_TTY_THEME=phd

color00="061229" # Base 00 - Black
color01="d07346" # Base 08 - Red
color02="99bf52" # Base 0B - Green
color03="fbd461" # Base 0A - Yellow
color04="5299bf" # Base 0D - Blue
color05="9989cc" # Base 0E - Magenta
color06="72b9bf" # Base 0C - Cyan
color07="b8bbc2" # Base 05 - White
color08="717885" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="f0a000" # Base 09
color17="b08060" # Base 0F
color18="2a3448" # Base 01
color19="4d5666" # Base 02
color20="9a99a3" # Base 04
color21="dbdde0" # Base 06
color_foreground="b8bbc2" # Base 05
color_background="061229" # Base 00

