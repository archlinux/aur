#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Seaside Light scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-seaside-light

color00="f4fbf4" # Base 00 - Black
color01="e6193c" # Base 08 - Red
color02="29a329" # Base 0B - Green
color03="98981b" # Base 0A - Yellow
color04="3d62f5" # Base 0D - Blue
color05="ad2bee" # Base 0E - Magenta
color06="1999b3" # Base 0C - Cyan
color07="5e6e5e" # Base 05 - White
color08="809980" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="131513" # Base 07 - Bright White
color16="87711d" # Base 09
color17="e619c3" # Base 0F
color18="cfe8cf" # Base 01
color19="8ca68c" # Base 02
color20="687d68" # Base 04
color21="242924" # Base 06
color_foreground="5e6e5e" # Base 05
color_background="f4fbf4" # Base 00

