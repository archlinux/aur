#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Dracula scheme by Mike Barkmin (http://github.com/mikebarkmin) based on Dracula Theme (http://github.com/dracula)
export BASE16_TTY_THEME=dracula

color00="282936" # Base 00 - Black
color01="ea51b2" # Base 08 - Red
color02="ebff87" # Base 0B - Green
color03="00f769" # Base 0A - Yellow
color04="62d6e8" # Base 0D - Blue
color05="b45bcf" # Base 0E - Magenta
color06="a1efe4" # Base 0C - Cyan
color07="e9e9f4" # Base 05 - White
color08="626483" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f7f7fb" # Base 07 - Bright White
color16="b45bcf" # Base 09
color17="00f769" # Base 0F
color18="3a3c4e" # Base 01
color19="4d4f68" # Base 02
color20="62d6e8" # Base 04
color21="f1f2f8" # Base 06
color_foreground="e9e9f4" # Base 05
color_background="282936" # Base 00

