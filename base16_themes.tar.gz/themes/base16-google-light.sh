#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Google Light scheme by Seth Wright (http://sethawright.com)
export BASE16_TTY_THEME=google-light

color00="ffffff" # Base 00 - Black
color01="CC342B" # Base 08 - Red
color02="198844" # Base 0B - Green
color03="FBA922" # Base 0A - Yellow
color04="3971ED" # Base 0D - Blue
color05="A36AC7" # Base 0E - Magenta
color06="3971ED" # Base 0C - Cyan
color07="373b41" # Base 05 - White
color08="b4b7b4" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="1d1f21" # Base 07 - Bright White
color16="F96A38" # Base 09
color17="3971ED" # Base 0F
color18="e0e0e0" # Base 01
color19="c5c8c6" # Base 02
color20="969896" # Base 04
color21="282a2e" # Base 06
color_foreground="373b41" # Base 05
color_background="ffffff" # Base 00

