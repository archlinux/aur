#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Unikitty Dark scheme by Josh W Lewis (@joshwlewis)
export BASE16_TTY_THEME=unikitty-dark

color00="2e2a31" # Base 00 - Black
color01="d8137f" # Base 08 - Red
color02="17ad98" # Base 0B - Green
color03="dc8a0e" # Base 0A - Yellow
color04="796af5" # Base 0D - Blue
color05="bb60ea" # Base 0E - Magenta
color06="149bda" # Base 0C - Cyan
color07="bcbabe" # Base 05 - White
color08="838085" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f5f4f7" # Base 07 - Bright White
color16="d65407" # Base 09
color17="c720ca" # Base 0F
color18="4a464d" # Base 01
color19="666369" # Base 02
color20="9f9da2" # Base 04
color21="d8d7da" # Base 06
color_foreground="bcbabe" # Base 05
color_background="2e2a31" # Base 00

