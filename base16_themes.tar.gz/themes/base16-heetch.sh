#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Heetch Dark scheme by Geoffrey Teale (tealeg@gmail.com)
export BASE16_TTY_THEME=heetch

color00="190134" # Base 00 - Black
color01="27D9D5" # Base 08 - Red
color02="C33678" # Base 0B - Green
color03="8F6C97" # Base 0A - Yellow
color04="BD0152" # Base 0D - Blue
color05="82034C" # Base 0E - Magenta
color06="F80059" # Base 0C - Cyan
color07="BDB6C5" # Base 05 - White
color08="7B6D8B" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="FEFFFF" # Base 07 - Bright White
color16="5BA2B6" # Base 09
color17="470546" # Base 0F
color18="392551" # Base 01
color19="5A496E" # Base 02
color20="9C92A8" # Base 04
color21="DEDAE2" # Base 06
color_foreground="BDB6C5" # Base 05
color_background="190134" # Base 00

