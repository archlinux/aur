#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Heath scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-heath

color00="1b181b" # Base 00 - Black
color01="ca402b" # Base 08 - Red
color02="918b3b" # Base 0B - Green
color03="bb8a35" # Base 0A - Yellow
color04="516aec" # Base 0D - Blue
color05="7b59c0" # Base 0E - Magenta
color06="159393" # Base 0C - Cyan
color07="ab9bab" # Base 05 - White
color08="776977" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f7f3f7" # Base 07 - Bright White
color16="a65926" # Base 09
color17="cc33cc" # Base 0F
color18="292329" # Base 01
color19="695d69" # Base 02
color20="9e8f9e" # Base 04
color21="d8cad8" # Base 06
color_foreground="ab9bab" # Base 05
color_background="1b181b" # Base 00

