#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Marrakesh scheme by Alexandre Gavioli (http://github.com/Alexx2/)
export BASE16_TTY_THEME=marrakesh

color00="201602" # Base 00 - Black
color01="c35359" # Base 08 - Red
color02="18974e" # Base 0B - Green
color03="a88339" # Base 0A - Yellow
color04="477ca1" # Base 0D - Blue
color05="8868b3" # Base 0E - Magenta
color06="75a738" # Base 0C - Cyan
color07="948e48" # Base 05 - White
color08="6c6823" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="faf0a5" # Base 07 - Bright White
color16="b36144" # Base 09
color17="b3588e" # Base 0F
color18="302e00" # Base 01
color19="5f5b17" # Base 02
color20="86813b" # Base 04
color21="ccc37a" # Base 06
color_foreground="948e48" # Base 05
color_background="201602" # Base 00

