#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Black Metal (Gorgoroth) scheme by metalelf0 (https://github.com/metalelf0)
export BASE16_TTY_THEME=black-metal-gorgoroth

color00="000000" # Base 00 - Black
color01="5f8787" # Base 08 - Red
color02="9b8d7f" # Base 0B - Green
color03="8c7f70" # Base 0A - Yellow
color04="888888" # Base 0D - Blue
color05="999999" # Base 0E - Magenta
color06="aaaaaa" # Base 0C - Cyan
color07="c1c1c1" # Base 05 - White
color08="333333" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="c1c1c1" # Base 07 - Bright White
color16="aaaaaa" # Base 09
color17="444444" # Base 0F
color18="121212" # Base 01
color19="222222" # Base 02
color20="999999" # Base 04
color21="999999" # Base 06
color_foreground="c1c1c1" # Base 05
color_background="000000" # Base 00

