#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Woodland scheme by Jay Cornwall (https://jcornwall.com)
export BASE16_TTY_THEME=woodland

color00="231e18" # Base 00 - Black
color01="d35c5c" # Base 08 - Red
color02="b7ba53" # Base 0B - Green
color03="e0ac16" # Base 0A - Yellow
color04="88a4d3" # Base 0D - Blue
color05="bb90e2" # Base 0E - Magenta
color06="6eb958" # Base 0C - Cyan
color07="cabcb1" # Base 05 - White
color08="9d8b70" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="e4d4c8" # Base 07 - Bright White
color16="ca7f32" # Base 09
color17="b49368" # Base 0F
color18="302b25" # Base 01
color19="48413a" # Base 02
color20="b4a490" # Base 04
color21="d7c8bc" # Base 06
color_foreground="cabcb1" # Base 05
color_background="231e18" # Base 00

