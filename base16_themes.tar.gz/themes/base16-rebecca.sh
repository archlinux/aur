#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Rebecca scheme by Victor Borja (http://github.com/vic) based on Rebecca Theme (http://github.com/vic/rebecca-theme)
export BASE16_TTY_THEME=rebecca

color00="292a44" # Base 00 - Black
color01="a0a0c5" # Base 08 - Red
color02="6dfedf" # Base 0B - Green
color03="ae81ff" # Base 0A - Yellow
color04="2de0a7" # Base 0D - Blue
color05="7aa5ff" # Base 0E - Magenta
color06="8eaee0" # Base 0C - Cyan
color07="f1eff8" # Base 05 - White
color08="666699" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="53495d" # Base 07 - Bright White
color16="efe4a1" # Base 09
color17="ff79c6" # Base 0F
color18="663399" # Base 01
color19="383a62" # Base 02
color20="a0a0c5" # Base 04
color21="ccccff" # Base 06
color_foreground="f1eff8" # Base 05
color_background="292a44" # Base 00

