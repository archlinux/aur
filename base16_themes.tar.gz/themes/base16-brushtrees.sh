#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Brush Trees scheme by Abraham White &lt;abelincoln.white@gmail.com&gt;
export BASE16_TTY_THEME=brushtrees

color00="E3EFEF" # Base 00 - Black
color01="b38686" # Base 08 - Red
color02="87b386" # Base 0B - Green
color03="aab386" # Base 0A - Yellow
color04="868cb3" # Base 0D - Blue
color05="b386b2" # Base 0E - Magenta
color06="86b3b3" # Base 0C - Cyan
color07="6D828E" # Base 05 - White
color08="98AFB5" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="485867" # Base 07 - Bright White
color16="d8bba2" # Base 09
color17="b39f9f" # Base 0F
color18="C9DBDC" # Base 01
color19="B0C5C8" # Base 02
color20="8299A1" # Base 04
color21="5A6D7A" # Base 06
color_foreground="6D828E" # Base 05
color_background="E3EFEF" # Base 00

