#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# PaperColor Light scheme by Jon Leopard (http://github.com/jonleopard) based on PaperColor Theme (https://github.com/NLKNguyen/papercolor-theme)
export BASE16_TTY_THEME=papercolor-light

color00="eeeeee" # Base 00 - Black
color01="bcbcbc" # Base 08 - Red
color02="8700af" # Base 0B - Green
color03="d70087" # Base 0A - Yellow
color04="d75f00" # Base 0D - Blue
color05="005faf" # Base 0E - Magenta
color06="d75f00" # Base 0C - Cyan
color07="878787" # Base 05 - White
color08="5f8700" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="444444" # Base 07 - Bright White
color16="d70000" # Base 09
color17="005f87" # Base 0F
color18="af0000" # Base 01
color19="008700" # Base 02
color20="0087af" # Base 04
color21="005f87" # Base 06
color_foreground="878787" # Base 05
color_background="eeeeee" # Base 00

