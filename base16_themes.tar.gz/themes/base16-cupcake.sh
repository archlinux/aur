#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Cupcake scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=cupcake

color00="fbf1f2" # Base 00 - Black
color01="D57E85" # Base 08 - Red
color02="A3B367" # Base 0B - Green
color03="DCB16C" # Base 0A - Yellow
color04="7297B9" # Base 0D - Blue
color05="BB99B4" # Base 0E - Magenta
color06="69A9A7" # Base 0C - Cyan
color07="8b8198" # Base 05 - White
color08="bfb9c6" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="585062" # Base 07 - Bright White
color16="EBB790" # Base 09
color17="BAA58C" # Base 0F
color18="f2f1f4" # Base 01
color19="d8d5dd" # Base 02
color20="a59daf" # Base 04
color21="72677E" # Base 06
color_foreground="8b8198" # Base 05
color_background="fbf1f2" # Base 00

