#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Snazzy scheme by Chawye Hsu (https://github.com/h404bi) based on Hyper Snazzy Theme (https://github.com/sindresorhus/hyper-snazzy)
export BASE16_TTY_THEME=snazzy

color00="282a36" # Base 00 - Black
color01="ff5c57" # Base 08 - Red
color02="5af78e" # Base 0B - Green
color03="f3f99d" # Base 0A - Yellow
color04="57c7ff" # Base 0D - Blue
color05="ff6ac1" # Base 0E - Magenta
color06="9aedfe" # Base 0C - Cyan
color07="e2e4e5" # Base 05 - White
color08="78787e" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f1f1f0" # Base 07 - Bright White
color16="ff9f43" # Base 09
color17="b2643c" # Base 0F
color18="34353e" # Base 01
color19="43454f" # Base 02
color20="a5a5a9" # Base 04
color21="eff0eb" # Base 06
color_foreground="e2e4e5" # Base 05
color_background="282a36" # Base 00

