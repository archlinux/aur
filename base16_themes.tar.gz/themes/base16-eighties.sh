#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Eighties scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=eighties

color00="2d2d2d" # Base 00 - Black
color01="f2777a" # Base 08 - Red
color02="99cc99" # Base 0B - Green
color03="ffcc66" # Base 0A - Yellow
color04="6699cc" # Base 0D - Blue
color05="cc99cc" # Base 0E - Magenta
color06="66cccc" # Base 0C - Cyan
color07="d3d0c8" # Base 05 - White
color08="747369" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f2f0ec" # Base 07 - Bright White
color16="f99157" # Base 09
color17="d27b53" # Base 0F
color18="393939" # Base 01
color19="515151" # Base 02
color20="a09f93" # Base 04
color21="e8e6df" # Base 06
color_foreground="d3d0c8" # Base 05
color_background="2d2d2d" # Base 00

