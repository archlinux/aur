#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# OneDark scheme by Lalit Magant (http://github.com/tilal6991)
export BASE16_TTY_THEME=onedark

color00="282c34" # Base 00 - Black
color01="e06c75" # Base 08 - Red
color02="98c379" # Base 0B - Green
color03="e5c07b" # Base 0A - Yellow
color04="61afef" # Base 0D - Blue
color05="c678dd" # Base 0E - Magenta
color06="56b6c2" # Base 0C - Cyan
color07="abb2bf" # Base 05 - White
color08="545862" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="c8ccd4" # Base 07 - Bright White
color16="d19a66" # Base 09
color17="be5046" # Base 0F
color18="353b45" # Base 01
color19="3e4451" # Base 02
color20="565c64" # Base 04
color21="b6bdca" # Base 06
color_foreground="abb2bf" # Base 05
color_background="282c34" # Base 00

