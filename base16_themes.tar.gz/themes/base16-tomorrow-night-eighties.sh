#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Tomorrow Night scheme by Chris Kempson (http://chriskempson.com)
export BASE16_TTY_THEME=tomorrow-night-eighties

color00="2d2d2d" # Base 00 - Black
color01="f2777a" # Base 08 - Red
color02="99cc99" # Base 0B - Green
color03="ffcc66" # Base 0A - Yellow
color04="6699cc" # Base 0D - Blue
color05="cc99cc" # Base 0E - Magenta
color06="66cccc" # Base 0C - Cyan
color07="cccccc" # Base 05 - White
color08="999999" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="f99157" # Base 09
color17="a3685a" # Base 0F
color18="393939" # Base 01
color19="515151" # Base 02
color20="b4b7b4" # Base 04
color21="e0e0e0" # Base 06
color_foreground="cccccc" # Base 05
color_background="2d2d2d" # Base 00

