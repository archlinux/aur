#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Codeschool scheme by blockloop
export BASE16_TTY_THEME=codeschool

color00="232c31" # Base 00 - Black
color01="2a5491" # Base 08 - Red
color02="237986" # Base 0B - Green
color03="a03b1e" # Base 0A - Yellow
color04="484d79" # Base 0D - Blue
color05="c59820" # Base 0E - Magenta
color06="b02f30" # Base 0C - Cyan
color07="9ea7a6" # Base 05 - White
color08="3f4944" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="b5d8f6" # Base 07 - Bright White
color16="43820d" # Base 09
color17="c98344" # Base 0F
color18="1c3657" # Base 01
color19="2a343a" # Base 02
color20="84898c" # Base 04
color21="a7cfa3" # Base 06
color_foreground="9ea7a6" # Base 05
color_background="232c31" # Base 00

