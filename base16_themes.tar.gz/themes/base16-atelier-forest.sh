#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Atelier Forest scheme by Bram de Haan (http://atelierbramdehaan.nl)
export BASE16_TTY_THEME=atelier-forest

color00="1b1918" # Base 00 - Black
color01="f22c40" # Base 08 - Red
color02="7b9726" # Base 0B - Green
color03="c38418" # Base 0A - Yellow
color04="407ee7" # Base 0D - Blue
color05="6666ea" # Base 0E - Magenta
color06="3d97b8" # Base 0C - Cyan
color07="a8a19f" # Base 05 - White
color08="766e6b" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="f1efee" # Base 07 - Bright White
color16="df5320" # Base 09
color17="c33ff3" # Base 0F
color18="2c2421" # Base 01
color19="68615e" # Base 02
color20="9c9491" # Base 04
color21="e6e2e0" # Base 06
color_foreground="a8a19f" # Base 05
color_background="1b1918" # Base 00

