#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Circus scheme by Stephan Boyer (https://github.com/stepchowfun) and Esther Wang (https://github.com/ewang12)
export BASE16_TTY_THEME=circus

color00="191919" # Base 00 - Black
color01="dc657d" # Base 08 - Red
color02="84b97c" # Base 0B - Green
color03="c3ba63" # Base 0A - Yellow
color04="639ee4" # Base 0D - Blue
color05="b888e2" # Base 0E - Magenta
color06="4bb1a7" # Base 0C - Cyan
color07="a7a7a7" # Base 05 - White
color08="5f5a60" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="ffffff" # Base 07 - Bright White
color16="4bb1a7" # Base 09
color17="b888e2" # Base 0F
color18="202020" # Base 01
color19="303030" # Base 02
color20="505050" # Base 04
color21="808080" # Base 06
color_foreground="a7a7a7" # Base 05
color_background="191919" # Base 00

