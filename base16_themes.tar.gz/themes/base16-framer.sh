#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Framer scheme by Framer (Maintained by Jesse Hoyos)
export BASE16_TTY_THEME=framer

color00="181818" # Base 00 - Black
color01="FD886B" # Base 08 - Red
color02="32CCDC" # Base 0B - Green
color03="FECB6E" # Base 0A - Yellow
color04="20BCFC" # Base 0D - Blue
color05="BA8CFC" # Base 0E - Magenta
color06="ACDDFD" # Base 0C - Cyan
color07="D0D0D0" # Base 05 - White
color08="747474" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="EEEEEE" # Base 07 - Bright White
color16="FC4769" # Base 09
color17="B15F4A" # Base 0F
color18="151515" # Base 01
color19="464646" # Base 02
color20="B9B9B9" # Base 04
color21="E8E8E8" # Base 06
color_foreground="D0D0D0" # Base 05
color_background="181818" # Base 00

