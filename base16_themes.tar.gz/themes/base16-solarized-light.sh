#!/bin/sh
# base16-shell (https://github.com/chriskempson/base16-shell)
# Base16 Shell template by Chris Kempson (http://chriskempson.com)
# Solarized Light scheme by Ethan Schoonover (modified by aramisgithub)
export BASE16_TTY_THEME=solarized-light

color00="fdf6e3" # Base 00 - Black
color01="dc322f" # Base 08 - Red
color02="859900" # Base 0B - Green
color03="b58900" # Base 0A - Yellow
color04="268bd2" # Base 0D - Blue
color05="6c71c4" # Base 0E - Magenta
color06="2aa198" # Base 0C - Cyan
color07="586e75" # Base 05 - White
color08="839496" # Base 03 - Bright Black
color09=$color01 # Base 08 - Bright Red
color10=$color02 # Base 0B - Bright Green
color11=$color03 # Base 0A - Bright Yellow
color12=$color04 # Base 0D - Bright Blue
color13=$color05 # Base 0E - Bright Magenta
color14=$color06 # Base 0C - Bright Cyan
color15="002b36" # Base 07 - Bright White
color16="cb4b16" # Base 09
color17="d33682" # Base 0F
color18="eee8d5" # Base 01
color19="93a1a1" # Base 02
color20="657b83" # Base 04
color21="073642" # Base 06
color_foreground="586e75" # Base 05
color_background="fdf6e3" # Base 00

