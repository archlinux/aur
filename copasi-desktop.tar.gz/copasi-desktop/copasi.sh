export COPASIDIR=/usr
