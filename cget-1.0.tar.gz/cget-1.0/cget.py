import os
import sys
file = sys.argv[2]
filedir = sys.argv[1]
print("Downloading "+filedir+"...")
os.system("curl "+filedir+" -o "+file)
