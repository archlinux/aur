import os
import sys
arg = 0
for args in sys.argv:
    arg = arg+1
print(args)

if arg == 1:
    print("//ERROR// you didn't put arguments")
    print("Usage: cget <url> <file>")
elif arg == 2:
    print("//ERROR// You have the url argument but not the file argument")
    file = input("Where can I save the file?: ")
    filedir = sys.argv[1]
    print("Downloading "+filedir+"...")
    os.system("curl "+filedir+" -o -"+file)
elif arg == 3:
    file = sys.argv[2]
    filedir = sys.argv[1]
    print("Downloading "+filedir+"...")
    os.system("curl "+filedir+" -o "+file)
else:
    print("//ERROR// There are more than 2 arguments, please put only two arguments")
    print("Usage: cget <url> <file>")
    print("<> Required arguments")

