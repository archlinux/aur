# sentinel-helper UI chrome — 简体中文.

dialog-title-default     = 需要身份验证
dialog-message-default   = 应用程序“{$process}”正在请求提升的权限。
dialog-secondary-default = 单击“允许”继续，或单击“拒绝”取消。

button-allow = 允许
button-deny  = 拒绝

toggle-show-details = ▸ 显示详情
toggle-hide-details = ▾ 隐藏详情

auto-deny-in = {$seconds} 秒后自动拒绝

detail-command      = 命令
detail-pid          = PID
detail-cwd          = 工作目录
detail-requested-by = 请求者
detail-action       = 操作

truncated-suffix = … [已截断]
