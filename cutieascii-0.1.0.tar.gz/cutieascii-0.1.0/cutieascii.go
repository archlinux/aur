package main

import (
	"flag"
	"fmt"
	"math/rand"
	"os"
	"strings"
	"time"
)

const (
	version = "0.1.0"
	Reset   = "\033[0m"
	Bold    = "\033[1m"
	Red     = "\033[31m"
	Green   = "\033[32m"
	Yellow  = "\033[33m"
	Blue    = "\033[34m"
	Magenta = "\033[35m"
	Cyan    = "\033[36m"
)

func main() {

	showVersion := flag.Bool("v", false, "Show Version")

	flag.Parse()

	if *showVersion {
		fmt.Println("Cutieascii version:", version)
		os.Exit(0)
	}

	// Try multiple possible locations for the emojis file
	possiblePaths := []string{
		"kaoscii/allmojis",                             // Local development
		"/usr/share/cutieascii/kaoscii/allmojis",       // System-wide installation
		"/usr/local/share/cutieascii/kaoscii/allmojis", // Local installation
		"./usr/share/cutieascii/kaoscii/allmojis",      // Build local
	}

	// Determine which file to use
	var content []byte
	var err error

	// Try each possible path until one works
	for _, path := range possiblePaths {
		content, err = os.ReadFile(path)
		if err == nil {
			break
		}
	}

	displayRandomEmoji(string(content))
}

func displayRandomEmoji(content string) {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	// divide content into separate emojis by double newlines
	emojis := strings.Split(content, "\n\n")

	var validEmojis []string
	for _, emoji := range emojis {
		cleanedEmoji := strings.TrimSpace(emoji)
		if cleanedEmoji != "" {
			validEmojis = append(validEmojis, cleanedEmoji)
		}
	}

	if len(validEmojis) == 0 {
		fmt.Println("No valid emojis found.")
		return
	}

	// select a random emoji
	randomIndex := r.Intn(len(validEmojis))

	colors := []string{Yellow, Red, Green, Blue, Magenta, Cyan}
	color := colors[r.Intn(len(colors))]

	fmt.Println(Bold + color + validEmojis[randomIndex])
}
