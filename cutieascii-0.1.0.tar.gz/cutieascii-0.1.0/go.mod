module cutieascii

go 1.25.4
