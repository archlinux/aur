<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it" sourcelanguage="en_CA">
<context>
    <name>BindInputDialog</name>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="14"/>
        <source>Bind Input</source>
        <translation>Associa Input</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="38"/>
        <source>To map a button or axis to this input, either press a button on your controller or hold a control stick or trigger in a different position for a half second.</source>
        <translation>Per associare un pulsante od un asse a quest&apos;input, premi un pulsante sul tuo controller oppure sposta la levetta analogica in un&apos;altra direzione o tieni premuto uno dei pulsanti d&apos;innesco per circa un secondo.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="76"/>
        <source>Skip</source>
        <translation>Salta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="87"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>ControllerConfigDialog</name>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="14"/>
        <source>Configure Controller</source>
        <translation>Configura Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="25"/>
        <source>Configuring Controller:</source>
        <translation>Configurando Controller:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="62"/>
        <source>Quick Configure</source>
        <translation>Configurazione Rapida</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="86"/>
        <source>Enable Rumble</source>
        <translation>Abilita Vibrazione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="99"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="18"/>
        <source>Analog Up</source>
        <translation>Analogico Su</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="122"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="19"/>
        <source>Analog Down</source>
        <translation>Analogico Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="145"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="20"/>
        <source>Analog Left</source>
        <translation>Analogico Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="168"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="21"/>
        <source>Analog Right</source>
        <translation>Analogico Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="191"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="30"/>
        <source>A Button</source>
        <translation>Pulsante A</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="214"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="31"/>
        <source>B Button</source>
        <translation>Pulsante B</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="248"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="22"/>
        <source>C Up</source>
        <translation>C Su</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="271"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="23"/>
        <source>C Down</source>
        <translation>C Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="294"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="24"/>
        <source>C Left</source>
        <translation>C Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="317"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="25"/>
        <source>C Right</source>
        <translation>C Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="340"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="33"/>
        <source>Z Trigger</source>
        <translation>Innesco Z</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="363"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="34"/>
        <source>R Trigger</source>
        <translation>Innesco R</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="397"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="26"/>
        <source>D-Pad Up</source>
        <translation>Freccia Direzionale Su</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="420"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="27"/>
        <source>D-Pad Down</source>
        <translation>Freccia Direzionale Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="443"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="28"/>
        <source>D-Pad Left</source>
        <translation>Freccia Direzionale Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="466"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="29"/>
        <source>D-Pad Right</source>
        <translation>Freccia Direzionale Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="489"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="35"/>
        <source>Start Button</source>
        <translation>Tasto D&apos;Invio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="512"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="32"/>
        <source>L Trigger</source>
        <translation>Innesco L</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="550"/>
        <source>Sensitivity</source>
        <translation>Sensibilità</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="576"/>
        <source>Deadzone</source>
        <translation>Zona Morta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="635"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="36"/>
        <source>Save State</source>
        <translation>Salvataggio Rapido</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="664"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="37"/>
        <source>Load State</source>
        <translation>Carica Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="712"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="39"/>
        <source>Toggle Slow Motion</source>
        <translation>Attiva/Disattiva Rallentatore</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="722"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="38"/>
        <source>Toggle Fast Forward</source>
        <translation>Attiva/Disattiva &apos;Avanti Veloce&apos;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="787"/>
        <source>Save As</source>
        <translation>Salva Come</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="807"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="821"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="69"/>
        <source>Not Bound</source>
        <translation>Non Collegato</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="72"/>
        <source>Button %1</source>
        <translation>Tasto %1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="75"/>
        <source>Axis -%1</source>
        <translation>Asse -%1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="78"/>
        <source>Axis +%1</source>
        <translation>Asse +%1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="81"/>
        <source>Hat %1 Up</source>
        <translation>Hat %1 Su</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="84"/>
        <source>Hat %1 Down</source>
        <translation>Hat %1 Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="87"/>
        <source>Hat %1 Left</source>
        <translation>Hat %1 Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="90"/>
        <source>Hat %1 Right</source>
        <translation>Hat %1 Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="132"/>
        <source>Enter Profile Name</source>
        <translation>Inserisci Nome Del Profilo</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="132"/>
        <source>Enter a name for your new controller profile.</source>
        <translation>Inserisci un nome per il tuo nuovo profilo del controller.</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="138"/>
        <source>Failed to Save Profile</source>
        <translation>Salvataggio non riuscito</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="138"/>
        <source>A default controller profile with that name already exists.</source>
        <translation>Un profilo del controller predefinito con quel nome già esiste.</translation>
    </message>
</context>
<context>
    <name>ControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="14"/>
        <source>Select Controller</source>
        <translation>Seleziona Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="23"/>
        <source>Connected Controllers</source>
        <translation>Controller Connessi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="52"/>
        <source>Controller Profiles</source>
        <translation>Profili del Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="67"/>
        <source>Edit Profile</source>
        <translation>Modifica Profilo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="78"/>
        <source>Delete Profile</source>
        <translation>Elimina Profilo</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-select-dialog.cpp" line="169"/>
        <source>Confirm Delete</source>
        <translation>Conferma Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-select-dialog.cpp" line="169"/>
        <source>Are you sure you want to delete controller profile &apos;%1&apos;?</source>
        <translation>Sei sicuro di voler eliminare il profilo del controller &apos;%1&apos;?</translation>
    </message>
</context>
<context>
    <name>CoreFinderDialog</name>
    <message>
        <location filename="../src/ui/core-finder-dialog.cpp" line="11"/>
        <source>Searching for latest core version...</source>
        <translation>Ricerca della versione più recente del core...</translation>
    </message>
</context>
<context>
    <name>CoreInstaller</name>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="24"/>
        <source>Download Failed</source>
        <translation>Scaricamento non riuscito</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="25"/>
        <source>Failed to download emulator core</source>
        <translation>Scaricamento del core non riuscito</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="33"/>
        <source>Installation Failed</source>
        <translation>Installazione non riuscita</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="34"/>
        <source>Failed to install emulator core</source>
        <translation>Installazione del core dell&apos;emulatore non riuscita</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="44"/>
        <source>Installation Successful</source>
        <translation>Installazione avvenuta con successo</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="45"/>
        <source>Core installed successfully.</source>
        <translation>Il core è stato installato con successo.</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="65"/>
        <source>Core Unavailable</source>
        <translation>Core non disponibile</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="66"/>
        <source>Sorry! The Mupen64plus-Next emulator core is not available on MacOS. Try using ParallelN64 instead.</source>
        <translation>Spiacente! Il core di emulazione Mupen64plus-Next non è disponibile per MacOS. Prova invece ad utilizzare ParallelN64.</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="74"/>
        <source>Install Emulator Core?</source>
        <translation>Installare il core dell&apos;emulatore?</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="75"/>
        <source>This emulator core is not installed. Would you like to install it now?</source>
        <translation>Il core di quest&apos;emulatore non è installato. Vuoi installarlo ora?</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="135"/>
        <source>Core Update Available</source>
        <translation>Aggiornamento del core disponibile</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="136"/>
        <source>An update is available for %1. Would you like to install it now?</source>
        <translation>Un aggiornamento è disponibile per %1. Vuoi installarlo ora?</translation>
    </message>
</context>
<context>
    <name>DirectPlay</name>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="55"/>
        <location filename="../src/ui/direct-play.cpp" line="62"/>
        <location filename="../src/ui/direct-play.cpp" line="69"/>
        <location filename="../src/ui/direct-play.cpp" line="76"/>
        <source>Patch Failed</source>
        <translation>Patch non riuscita</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="56"/>
        <source>Failed to patch ROM. The .bps patch appears to be invalid.</source>
        <translation>Patch della ROM non riuscita. La patch del file .bps non sembra essere valida.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="63"/>
        <source>Failed to patch ROM. The base ROM does not match what the patch expects..</source>
        <translation>Patch della ROM non riuscita. La ROM di riferimento non coincide con ciò che la patch richiede.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="70"/>
        <source>Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher.</source>
        <translation>Patch della ROM non riuscita. La ROM di base da patchare non è riconosciuta da Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="77"/>
        <source>Failed to patch ROM. An error occurred while writing the patched ROM to disk.</source>
        <translation>Patch della ROM non riuscita. Si è verificato un errore durante la trascrizione della ROM patchata sul disco.</translation>
    </message>
</context>
<context>
    <name>DirectPlayWindow</name>
    <message>
        <location filename="../src/ui/designer/direct-play-window.ui" line="14"/>
        <source>ROM Settings</source>
        <translation>Impostazioni ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/direct-play-window.ui" line="27"/>
        <source>This is your first time running this ROM. Please select any ROM specific settings. You can always change these settings later.</source>
        <translation>Questa è la prima volta che si esegue questa ROM. Si prega di selezionare le impostazioni specifiche per questa ROM. Sarà possibile sempre cambiarle in seguito.</translation>
    </message>
</context>
<context>
    <name>DownloadDialog</name>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="20"/>
        <source>Downloading core...</source>
        <translation>Scaricando core...</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="229"/>
        <source>Downloading RetroArch</source>
        <translation>Scaricando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="48"/>
        <source>Downloading installer...</source>
        <translation>Scaricando programma d&apos;installazione...</translation>
    </message>
</context>
<context>
    <name>ErrorNotifier</name>
    <message>
        <location filename="../src/ui/error-notifier.cpp" line="5"/>
        <source>The application encountered an unexpected error:</source>
        <translation>L&apos;applicazione ha riscontrato un errore inaspettato:</translation>
    </message>
    <message>
        <location filename="../src/ui/error-notifier.cpp" line="12"/>
        <source>Unhandled Error</source>
        <translation>Errore non gestito</translation>
    </message>
</context>
<context>
    <name>FlatpakProgressDialog</name>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.ui" line="14"/>
        <source>Flatpak Operation</source>
        <translation>Operazioni Flatpak</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="425"/>
        <source>Updating RetroArch</source>
        <translation>Aggiornando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="426"/>
        <source>Checking for RetroArch updates</source>
        <translation>Verifica aggiornamenti per RetroArch</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="427"/>
        <source>RetroArch updated successfully.</source>
        <translation>RetroArch è stato aggiornato con successo.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="428"/>
        <source>Failed to update RetroArch.</source>
        <translation>Aggiornamento di RetroArch non riuscito.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="429"/>
        <source>An update for RetroArch is available. Would you like to install it now?</source>
        <translation>Un nuovo aggiornamento per RetroArch è disponibile. Vuoi installarlo ora?</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="442"/>
        <source>Updating Runtimes</source>
        <translation>Aggiornando file di esecuzione</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="443"/>
        <source>Checking for runtime updates</source>
        <translation>Verifica aggiornamenti del file di esecuzione</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="444"/>
        <source>Flatpak runtimes updated successfully.</source>
        <translation>I file di esecuzione del Flatpak sono stati aggiornati con successo.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="445"/>
        <source>Failed to update Flatpak runtimes.</source>
        <translation>Aggiornamento dei file di esecuzione del Flatpak non riuscito.</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="25"/>
        <source>Installing</source>
        <translation>Installazione</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="27"/>
        <source>Updating</source>
        <translation>Aggiornamento</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="29"/>
        <source>Removing</source>
        <translation>Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="31"/>
        <source>Configuring</source>
        <translation>Configurazione</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="58"/>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="60"/>
        <source>Initializing...</source>
        <translation>Avviando...</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="126"/>
        <source>Finalizing...</source>
        <translation>Terminando...</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="154"/>
        <source>Confirm</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="167"/>
        <source>Operation Succeeded</source>
        <translation>Operazione Riuscita</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="171"/>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="173"/>
        <source>Operation Failed</source>
        <translation>Operazione non riuscita</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="248"/>
        <source>Installing RetroArch</source>
        <translation>Installando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="249"/>
        <source>Preparing to install RetroArch...</source>
        <translation>Preparando i file per l&apos;installazione di RetroArch...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="250"/>
        <source>RetroArch installed successfully.</source>
        <translation>RetroArch è stato installato con successo.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="251"/>
        <source>Failed to install RetroArch.</source>
        <translation>Installazione di RetroArch non riuscita.</translation>
    </message>
</context>
<context>
    <name>Game</name>
    <message>
        <location filename="../src/ui/play.cpp" line="22"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics plugins. Alternatively, if you have a very old onboard graphics card, it is possible that Vulkan is not supported on your system. In either case, using another graphics plugin might resolve the issue.</source>
        <translation>L&apos;emulatore si è arrestato per breve tempo dopo l&apos;avvio. Se riesci ad avviare altre ROM senza problemi, allora questa ROM potrebbe contenere un microcodice RSP non valido o non sicuro, il quale non può essere avviato su plugin video riproducenti in maniera accurata la grafica della console. In alternativa, se hai con te una scheda grafica molto vecchia, è probabile che Vulkan non sia supportato per il tuo sistema operativo. In ogni caso, con l&apos;utilizzo di un altro plugin video, il problema dovrebbe risolversi.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="28"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics plugins. If this is the case, try running the ROM with another graphics plugin instead.</source>
        <translation>L&apos;emulatore si è arrestato per breve tempo dopo l&apos;avvio. Se riesci ad avviare altre ROM senza problemi, allora questa ROM potrebbe contenere un microcodice RSP non valido o non sicuro, il quale non può essere avviato su plugin video riproducenti in maniera accurata la grafica della console. Se questo è il caso, prova, quindi, ad avviare la ROM con un altro plugin video.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="33"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM is most likely corrupt.</source>
        <translation>L&apos;emulatore si è arrestato per breve tempo dopo l&apos;avvio. Se non riesci ad avviare altre ROM senza problemi, allora questa ROM molto probabilmente è danneggiata.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="110"/>
        <source>Emulator Missing</source>
        <translation>Emulatore Mancante</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="111"/>
        <source>Failed to launch emulator. It does not appear to be installed.</source>
        <translation>Avvio dell&apos;emulatore non riuscito. Non sembra essere installato.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="197"/>
        <source>Possible ROM Error</source>
        <translation>Possibile errore della ROM</translation>
    </message>
</context>
<context>
    <name>GetControllerPortDialog</name>
    <message>
        <location filename="../src/ui/get-controller-port-dialog.cpp" line="8"/>
        <source>Choose Controller</source>
        <translation>Scegli Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/get-controller-port-dialog.cpp" line="9"/>
        <source>Press any button on the controller to bind to this port.</source>
        <translation>Premi un qualsiasi tasto sul controller per collegarlo a questa porta.</translation>
    </message>
</context>
<context>
    <name>GroupName</name>
    <message>
        <location filename="../src/core/special-groups.cpp" line="15"/>
        <source>Favourites</source>
        <translation>Preferiti</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="17"/>
        <source>Automatically Added</source>
        <translation>Aggiunti Automaticamente</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="19"/>
        <source>Uncategorized</source>
        <translation>Non Classificato</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="21"/>
        <source>Want To Play</source>
        <translation>Voglio Giocare</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="23"/>
        <source>In Progress</source>
        <translation>In Corso</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="25"/>
        <source>Completed</source>
        <translation>Completato</translation>
    </message>
</context>
<context>
    <name>HotkeyEditWidget</name>
    <message>
        <location filename="../src/ui/hotkey-edit-widget.cpp" line="7"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
</context>
<context>
    <name>InputModeSelect</name>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="171"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="172"/>
        <source>Maps your gamepad inputs to a single N64 controller using your controller profile</source>
        <translation>Associa gli input del tuo gamepad ad un solo controller N64 usando il profilo del tuo controller</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="193"/>
        <source>Dual Analog</source>
        <translation>Dual Analog</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="194"/>
        <source>Your gamepad inputs that normally bind to the C buttons instead bind to the analog stick on a second N64 controller</source>
        <translation>Gli input del tuo gamepad, che generalmente si associano ai pulsanti C, corrispondono invece alla levetta analogica su un secondo controller N64</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="215"/>
        <source>GoldenEye</source>
        <translation>GoldenEye</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="216"/>
        <source>Maps your gamepad inputs to two N64 controllers suitable for playing GoldenEye with the 2.4 Goodhead control style</source>
        <translation>Associa gli input del tuo gamepad a due controller N64, adatti a giocare a GoldenEye con lo stile di controllo 2.4 Goodhead</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="237"/>
        <source>Clone</source>
        <translation>Clona</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="238"/>
        <source>Your gamepad inputs are sent to two controller ports instead of just one</source>
        <translation>Gli input del tuo gamepad vengono inviate a due porte del controller piuttosto che ad una</translation>
    </message>
</context>
<context>
    <name>KeyboardConfigDialog</name>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="14"/>
        <source>Configure Keyboard Controls</source>
        <translation>Configura i comandi della tastiera</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="28"/>
        <source>Hotkeys</source>
        <translation>Tasti Rapidi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="71"/>
        <source>Keyboard Controls</source>
        <translation>Comandi della tastiera</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="17"/>
        <source>Analog Up</source>
        <translation>Analogico Su</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="18"/>
        <source>Analog Down</source>
        <translation>Analogico Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="19"/>
        <source>Analog Left</source>
        <translation>Analogico Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="20"/>
        <source>Analog Right</source>
        <translation>Analogico Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="21"/>
        <source>C Up</source>
        <translation>C Su</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="22"/>
        <source>C Down</source>
        <translation>C Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="23"/>
        <source>C Left</source>
        <translation>C Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="24"/>
        <source>C Right</source>
        <translation>C Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="25"/>
        <source>D-Pad Up</source>
        <translation>Freccia Direzionale Su</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="26"/>
        <source>D-Pad Down</source>
        <translation>Freccia Direzionale Giù</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="27"/>
        <source>D-Pad Left</source>
        <translation>Freccia Direzionale Sinistra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="28"/>
        <source>D-Pad Right</source>
        <translation>Freccia Direzionale Destra</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="29"/>
        <source>A Button</source>
        <translation>Pulsante A</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="30"/>
        <source>B Button</source>
        <translation>Pulsante B</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="31"/>
        <source>L Trigger</source>
        <translation>Innesco L</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="32"/>
        <source>Z Trigger</source>
        <translation>Innesco Z</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="33"/>
        <source>R Trigger</source>
        <translation>Innesco R</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="34"/>
        <source>Start Button</source>
        <translation>Tasto d&apos;Invio</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="36"/>
        <source>Save State</source>
        <translation>Salvataggio Rapido</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="37"/>
        <source>Load State</source>
        <translation>Carica Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="38"/>
        <source>Previous State</source>
        <translation>Salvataggio Precedente</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="39"/>
        <source>Next State</source>
        <translation>Salvataggio Successivo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="40"/>
        <source>Previous Cheat</source>
        <translation>Trucco Precedente</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="41"/>
        <source>Next Cheat</source>
        <translation>Trucco Successivo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="42"/>
        <source>Toggle Cheat</source>
        <translation>Attiva/Disattiva Trucco</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="43"/>
        <source>Toggle FPS Display</source>
        <translation>Mostra/Nascondi FPS</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="44"/>
        <source>Pause/Unpause</source>
        <translation>Pausa/Riprendi</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="45"/>
        <source>Frame Advance</source>
        <translation>Avanzamento del fotogramma</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="46"/>
        <source>Fast Forward (Hold)</source>
        <translation>Avanti Veloce (Tieni Premuto)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="47"/>
        <source>Fast Forward (Toggle)</source>
        <translation>Avanti Veloce (Attiva/Disattiva)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="48"/>
        <source>Slow Motion (Hold)</source>
        <translation>Rallentatore (Tieni Premuto)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="49"/>
        <source>Slow Motion (Toggle)</source>
        <translation>Rallentatore (Attiva/Disattiva)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="50"/>
        <source>Rewind*</source>
        <translation>Riavvolgi*</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="51"/>
        <source>Quit Emulator</source>
        <translation>Chiudi Emulatore</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="52"/>
        <source>Hard Reset</source>
        <translation>Formattazione</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="53"/>
        <source>Toggle Fullscreen</source>
        <translation>Attiva/Disattiva Schermo Intero</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="54"/>
        <source>RetroArch Menu</source>
        <translation>Menù di RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="55"/>
        <source>Record Video</source>
        <translation>Registra Video</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="56"/>
        <source>Record Inputs</source>
        <translation>Registra Input</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="57"/>
        <source>Take Screenshot</source>
        <translation>Cattura Schermo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="58"/>
        <source>Raise Volume</source>
        <translation>Alza Volume</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="59"/>
        <source>Lower Volume</source>
        <translation>Abbassa Volume</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="60"/>
        <source>Mute/Unmute</source>
        <translation>Attiva/Disattiva Audio</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="92"/>
        <source>You must enable rewind functionality in the RetroArch menu to use this hotkey.</source>
        <translation>Per usare questo tasto rapido, devi abilitare la funzione riavvolgi nel menù di RetroArch .</translation>
    </message>
</context>
<context>
    <name>LogViewerDialog</name>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="14"/>
        <source>Log Viewer</source>
        <translation>Visualizzatore Registro</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="28"/>
        <source>Only show logs from this session</source>
        <translation>Mostra solo registri da questa sessione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="48"/>
        <source>Show timestamps</source>
        <translation>Mostra marcatori temporali</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="60"/>
        <source>Visible Logs</source>
        <translation>Registri Visibili</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="66"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="76"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="86"/>
        <source>Warn</source>
        <translation>Segnala</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="96"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="106"/>
        <source>Fatal</source>
        <translation>Fatale</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="43"/>
        <source>Parallel Launcher will now setup an isolated Flatpak installation to install and manage RetroArch. This is kept separate from your main system and user installations.</source>
        <translation>Parallel Launcher ora creerà un&apos;installazione remota del FlatPak per installare e amministrare RetroArch. Quest&apos;ultimo verrà tenuto separato dalle installazioni utente e quelle del sistema.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="190"/>
        <location filename="../src/main.cpp" line="239"/>
        <source>Installing RetroArch</source>
        <translation>Installando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="191"/>
        <source>Parallel Launcher will now install RetroArch.</source>
        <translation>Parallel Launcher adesso installerà RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="228"/>
        <source>Fatal Error</source>
        <translation>Errore Fatale</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="201"/>
        <source>Failed to install RetroArch.</source>
        <translation>Installazione di RetroArch non riuscita.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>Flatpak Setup</source>
        <translation>Installazione del FlatPak</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="229"/>
        <source>Failed to create Flatpak installation.</source>
        <translation>Creazione dell&apos;installazione del Flatpak non riuscita.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="240"/>
        <source>RetroArch will now be installed.</source>
        <translation>Adesso verrà installato RetroArch.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="67"/>
        <source>Refresh ROM List</source>
        <translation>Aggiorna Lista ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="84"/>
        <source>Configure Controller</source>
        <translation>Configura Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="101"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="131"/>
        <source>Searching for ROMs...</source>
        <translation>Cercando ROM...</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="188"/>
        <source>No ROMS have been found</source>
        <translation>Nessuna ROM è stata trovata</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="195"/>
        <location filename="../src/ui/designer/main-window.ui" line="316"/>
        <source>Manage ROM Sources</source>
        <translation>Gestisci Sorgenti di ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="266"/>
        <source>Download</source>
        <translation>Scaricati</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="283"/>
        <source>Play Multiplayer</source>
        <translation>Gioca Modalità Multigiocatore</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="294"/>
        <source>Play Singleplayer</source>
        <translation>Gioca Modalità Giocatore Singolo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="311"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="321"/>
        <source>Configure Controllers</source>
        <translation>Configura i Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="326"/>
        <source>Keyboard Controls and Hotkeys</source>
        <translation>Comandi da Tastiera e Tasti Rapidi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="329"/>
        <source>Configure keyboard controls and hotkeys</source>
        <translation>Configura comandi da tastiera e tasti rapidi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="334"/>
        <location filename="../src/ui/main-window.cpp" line="437"/>
        <source>Login to romhacking.com</source>
        <translation>Accedi a romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="339"/>
        <source>Logout of romhacking.com</source>
        <translation>Esci da romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="344"/>
        <source>Disable romhacking.com integration</source>
        <translation>Disabilità integrazione di romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="437"/>
        <source>Enable romhacking.com integration</source>
        <translation>Abilità integrazione di romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="472"/>
        <source>Confirm Disable</source>
        <translation>Conferma Disabilitazione</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="472"/>
        <source>Are you sure you want to disable romhacking.com integration?</source>
        <translation>Sei sicuro di voler disabilitare l&apos;integrazione di romhacking.com?</translation>
    </message>
</context>
<context>
    <name>ManageGroupsDialog</name>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="14"/>
        <source>Manage Groups</source>
        <translation>Gestisci Gruppi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="32"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="43"/>
        <source>Rename</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="54"/>
        <source>New</source>
        <translation>Nuovo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="47"/>
        <source>Confirm Delete</source>
        <translation>Conferma Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="47"/>
        <source>Are you sure you want to delete this group?</source>
        <translation>Sei sicuro di voler eliminare questo gruppo?</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="60"/>
        <source>Rename Group</source>
        <translation>Rinomina Gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="60"/>
        <source>Enter a new name for your group</source>
        <translation>Inserisci un nuovo nome per il tuo gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="70"/>
        <source>Rename Failed</source>
        <translation>Rinomina Non Riuscita</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="70"/>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="89"/>
        <source>A group with this name already exists.</source>
        <translation>Un gruppo con questo nome già esiste.</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="84"/>
        <source>Create Group</source>
        <translation>Crea Gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="84"/>
        <source>Enter a name for your new group</source>
        <translation>Inserisci un nome per il tuo nuovo gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="89"/>
        <source>Create Failed</source>
        <translation>Creazione non riuscita</translation>
    </message>
</context>
<context>
    <name>MultiplayerControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="14"/>
        <source>Select Controllers</source>
        <translation>Seleziona i Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="22"/>
        <source>Port 1</source>
        <translation>Porta 1</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="33"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="59"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="85"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="111"/>
        <source>-- None --</source>
        <translation>-- Nessuno --</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="41"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="67"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="93"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="119"/>
        <source>Detect Device</source>
        <translation>Rileva Dispositivo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="48"/>
        <source>Port 2</source>
        <translation>Porta 2</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="74"/>
        <source>Port 3</source>
        <translation>Porta 3</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="100"/>
        <source>Port 4</source>
        <translation>Porta 4</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="128"/>
        <source>Allow port 1 to save and load states</source>
        <translation>Permetti alla porta 1 di salvare e caricare i salvataggi</translation>
    </message>
</context>
<context>
    <name>NeutralInputDialog</name>
    <message>
        <location filename="../src/ui/designer/neutral-input-dialog.ui" line="14"/>
        <source>Return to Neutral</source>
        <translation>Ripristina posizione neutra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/neutral-input-dialog.ui" line="29"/>
        <source>Return all triggers and analog sticks to their neutral position, then press any button on the controller or click the OK button to continue.</source>
        <translation>Ripristina la posizione neutra di tutti i tasti d&apos;innesco e delle levette analogiche, poi premi uno dei pulsanti del tuo controller o clicca il tasto OK per continuare.</translation>
    </message>
</context>
<context>
    <name>NowPlayingWindow</name>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="29"/>
        <source>Now Playing: </source>
        <translation>Adesso in gioco: </translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="94"/>
        <source>Play Time</source>
        <translation>Tempo di Gioco</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="107"/>
        <source>Total</source>
        <translation>Totale</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="138"/>
        <source>This Session</source>
        <translation>Questa Sessione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="208"/>
        <source>Kill Emulator</source>
        <translation>Chiudi Emulatore</translation>
    </message>
</context>
<context>
    <name>RhdcDownloadDialog</name>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="132"/>
        <source>Downloading star layout</source>
        <translation>Scaricando layout delle stelle</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="157"/>
        <source>Failed to download star layout from RHDC</source>
        <translation>Non è stato possibile scaricare il layout delle stelle da RHDC</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="173"/>
        <source>Downloading patch</source>
        <translation>Scaricamento patch</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="206"/>
        <source>Failed to download patch from RHDC</source>
        <translation>Non è stato possibile scaricare la patch da RHDC</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="224"/>
        <source>Applying patch</source>
        <translation>Eseguendo patch</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="233"/>
        <source>The rom could not be installed because you do not have an unmodified copy of the US version of Super Mario 64 in your known roms list.</source>
        <translation>Non è stato possibile installare la ROM, perché non possiedi una copia inalterata della versione US di Super Mario 64 nella lista delle tue ROM conosciute.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="265"/>
        <source>The rom could not be installed because no bps patch was found.</source>
        <translation>Non è stato possibile installare la ROM, perché non è stata trovata nessuna patch bps.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="279"/>
        <source>Could not install &apos;%1&apos; because of an unexpected error while applying the patch</source>
        <translation>Non è stato possibile installare &apos;%1&apos; a causa di un errore imprevisto durante l&apos;esecuzione della patch</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="289"/>
        <source>Computing checksum</source>
        <translation>Calcolando checksum</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="303"/>
        <source>Romhack installed successfully</source>
        <translation>Romhack installata con successo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-download-dialog.ui" line="14"/>
        <source>Downloading Patch</source>
        <translation>Scaricamento Patch</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-download-dialog.ui" line="25"/>
        <source>Fetching hack info</source>
        <translation>Recupero informazioni sull&apos;hack</translation>
    </message>
</context>
<context>
    <name>RhdcHackView</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="25"/>
        <source>Hack List:</source>
        <translation>Lista Hack:</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="58"/>
        <source>Sort By:</source>
        <translation>Ordina per:</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="75"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="80"/>
        <source>Popularity</source>
        <translation>Popolarità</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="85"/>
        <source>Rating</source>
        <translation>Valutazione</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="90"/>
        <source>Difficulty</source>
        <translation>Difficoltà</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="95"/>
        <source>Last Played</source>
        <translation>Ultima Giocata</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="100"/>
        <source>Play Time</source>
        <translation>Tempo di Gioco</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack-view.ui" line="199"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="67"/>
        <source>All Hack Lists</source>
        <translation>Tutte le Liste Hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="114"/>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="120"/>
        <source>Authors:</source>
        <translation>Autori:</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="115"/>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="124"/>
        <source>Unknown</source>
        <extracomment>Shown when no authors are listed for a hack</extracomment>
        <translatorcomment>Mostrato quando nessun autore è elencato per un hack</translatorcomment>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="120"/>
        <source>Author:</source>
        <translation>Autore:</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="249"/>
        <source>Create List</source>
        <translation>Crea Elenco</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="249"/>
        <source>Enter a name for your new hack list</source>
        <translation>Inserisci un nome per il tuo nuovo elenco hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="254"/>
        <source>List Exists</source>
        <translation>L&apos;Elenco Esiste</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="254"/>
        <source>A hack list with this name already exists</source>
        <translation>Un elenco hack con questo nome già esiste</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="280"/>
        <source>Rate Hack</source>
        <translation>Valuta Hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="283"/>
        <source>Mark as Not Completed</source>
        <translation>Segna come Non Completato</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="285"/>
        <source>Mark as Completed</source>
        <translation>Segna come Completato</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="295"/>
        <source>Move to Hack List...</source>
        <translation>Sposta in Elenco Hack...</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="296"/>
        <source>Copy to Hack List...</source>
        <translation>Copia nell&apos;Elenco Hack...</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="303"/>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="304"/>
        <source>New List</source>
        <translation>Nuovo Elenco</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="310"/>
        <source>Remove from &apos;%1&apos;</source>
        <translation>Rimuovi da &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="317"/>
        <source>Delete Save File</source>
        <translation>Elimina File di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="320"/>
        <source>Edit Save File</source>
        <translation>Modifica File di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="324"/>
        <source>Unfollow Hack</source>
        <translation>Non seguire più questo Hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="326"/>
        <source>Uninstall Hack Version</source>
        <translation>Disinstalla questa versione dell&apos;hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="421"/>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="449"/>
        <source>Confirm Delete</source>
        <translation>Conferma Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="421"/>
        <source>Are you sure you want to delete your save file?</source>
        <translation>Sei sicuro di voler eliminare il tuo file di salvataggio?</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="440"/>
        <source>Confirm Unfollow</source>
        <translation>Conferma di non seguire più</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="440"/>
        <source>Are you sure you want to unfollow this hack? The ROM will not be deleted from your computer, but it will be removed from all of your hack lists on romhacking.com and your progress will no longer be synced with romhacking.com.</source>
        <translation>Sei sicuro di non volere più seguire questo hack? La ROM non verrà eliminata dal tuo computer, ma sarà rimossa da tutti i tuoi elenchi hack su romhacking.com e i tuoi progressi ad essa relativi non saranno più sincornizzati con romhacking.com.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-view.cpp" line="449"/>
        <source>Are you sure you want to delete this ROM file from your computer?</source>
        <translation>Sei sicuro di volere eliminare questo file ROM dal tuo computer?</translation>
    </message>
</context>
<context>
    <name>RhdcHackWidget</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="302"/>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="341"/>
        <source>Popularity (Downloads)</source>
        <translation>Popolarità (Scaricati)</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="385"/>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="424"/>
        <source>Rating</source>
        <translation>Valutazione</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="465"/>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="504"/>
        <source>Difficulty</source>
        <translation>Difficoltà</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="561"/>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="600"/>
        <source>Last Played</source>
        <extracomment>Date and time that a hack was last played</extracomment>
        <translatorcomment>Data e ora in cui un hack è stato giocato l&apos;ultima volta</translatorcomment>
        <translation>Ultima Giocata</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="641"/>
        <location filename="../src/rhdc/ui/designer/rhdc-hack.ui" line="680"/>
        <source>Total Play Time</source>
        <translation>Tempo Complessivo di Gioco</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-widget.cpp" line="102"/>
        <source>Never</source>
        <extracomment>Text shown in place of a date when a hack hasn&apos;t been played yet</extracomment>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-widget.cpp" line="111"/>
        <source>Completed</source>
        <translation>Completato</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-hack-widget.cpp" line="111"/>
        <source>Incomplete</source>
        <translation>Incompleto</translation>
    </message>
</context>
<context>
    <name>RhdcLoginDialog</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="14"/>
        <source>RHDC Login</source>
        <translation>Accesso RHDC</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="66"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To enable romhacking.com integration, you must have an unmodified copy of the US version of &lt;span style=&quot; font-style:italic;&quot;&gt;Super Mario 64&lt;/span&gt; in z64 format.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Per abilitare l&apos;integrazione con romhacking.com, è necessario possedere una copia inalterata della versione US di &lt;span style=&quot; font-style:italic;&quot;&gt;Super Mario 64&lt;/span&gt; in formato z64.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="128"/>
        <source>Browse for SM64 ROM</source>
        <translation>Cerca una ROM di SM64</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="180"/>
        <source>Sign in to romhacking.com</source>
        <translation>Accedi a romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="194"/>
        <source>Username</source>
        <translation>Nome Utente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="204"/>
        <source>Password</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="256"/>
        <source>Sign In</source>
        <translation>Accedi</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="365"/>
        <source>Please confirm your romhacking.com integration settings. You can always change these later in the settings dialog.</source>
        <translation>Per favore conferma le tue impostazioni per l&apos;integrazione di romhacking.com. Potrai sempre cambiarle in seguito nella finestra delle impostazioni.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="400"/>
        <source>Download Directory</source>
        <translation>Scarica Cartella</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="422"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="446"/>
        <source>Sets the directory that hacks downloaded from romhacking.com will be saved to. If you change this setting later, your roms will automatically be moved to the new directory.</source>
        <translation>Seleziona la cartella in cui verranno salvati gli hack scaricati da romhacking.com. Se cambierai queste impostazioni in seguito, le tue ROM verranno automaticamente spostate nella nuova cartella.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="478"/>
        <source>Enable Star Display</source>
        <translation>Abilita Visualizzazione delle Stelle</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="493"/>
        <source>If checked, when a rom is running that has a supported layout file from RHDC, a layout of all the stars in the hack will be shown. This layout updates automatically after the game is saved.</source>
        <translation>Se selezionato, quando è in esecuzione una rom che ha come supporto un file di layout da RHDC, verrà mostrato un layout di tutte le stelle nell&apos;hack. Questo layout si aggiorna automaticamente dopo il salvataggio del gioco.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="509"/>
        <source>Check all save slots</source>
        <translation>Verifica tutte le posizioni di salvataggio</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="527"/>
        <source>If checked, Parallel Launcher will submit your highest star count across all save slots to romhacking.com; otherwise, it will only submit your star count in slot A.</source>
        <translation>Se marcato, Parallel Launcher comunicherà il numero più alto di stelle tra tutti gli slot di salvataggio a romhacking.com; altrimenti, comunicherà solo il numero di stelle nello slot A.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="559"/>
        <source>Prefer HLE plugins</source>
        <translation>Preferisco plugin HLE</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="577"/>
        <source>If checked, Parallel Launcher will use the GLideN64 plugin instead of the ParaLLEl plugin when it guesses that ParrLLEl is probably the best plugin to use. Only check this if your computer has an old GPU with poor Vulkan support. If you still experience lag even with GLideN64, you may need to disable &apos;Emulate Framebuffer&apos; and/or &apos;Emulate N64 Depth Compare&apos; in the GFX Plugins section of your Parallel Launcher settings.</source>
        <translation>Se marcato, Parallel Launcher utilizzerà il plugin GLideN64 piuttosto che ParaLLEl quando ritiene che ParaLLEl sia probabilmente la scelta più adatta. Marca qui solo se il tuo computer ha una vecchia GPU con uno scarso supporto Vulkan. Se si verifica lag anche con GLideN64, potrebbe essere necessario disabilitare &apos;Emula Framebuffer&apos; e/o &apos;Emula N64 Depth Compare&apos; nella sezione Plugin GFX delle tue impostazioni di Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="61"/>
        <source>Select SM64 ROM</source>
        <translation>Seleziona ROM di SM64</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="67"/>
        <source>ROM Does not Match</source>
        <translation>La ROM non corrisponde</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="67"/>
        <source>The provided rom does not match the expected checksum.</source>
        <translation>La ROM fornita non combacia con il checksum previsto.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="103"/>
        <source>Select a new download directory</source>
        <translation>Seleziona una nuova cartella di scaricamento</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="111"/>
        <source>Enter your username</source>
        <translation>Inserisci il tuo nome utente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="116"/>
        <source>Enter your password</source>
        <translation>Inserisci la tua password</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="155"/>
        <source>Username or password is incorrect</source>
        <translation>Nome utente o password errati</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="158"/>
        <source>This account requires e-mail confirmation to activate.</source>
        <translation>Questo account richiede un&apos; e-mail di conferma per essere attivato.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="161"/>
        <source>The romhacking.com servers appear to be down.</source>
        <translation>I server di romhacking.com sembrano essere fuori uso.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="164"/>
        <source>An unknown error occurred.</source>
        <translation>Si è verificato un errore sconosciuto.</translation>
    </message>
</context>
<context>
    <name>RhdcRatingDialog</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="14"/>
        <source>Rate this Hack</source>
        <translation>Valuta questo Hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="25"/>
        <source>How would you rate this hack?</source>
        <translation>Come valuti questo hack?</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="51"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Quality. &lt;/span&gt;How enjoyable, impressive, and/or polished was this hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Qualità. &lt;/span&gt;Quanto è stato divertente, ammirevole e/o ricercato questo hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="162"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Difficulty. &lt;/span&gt;In general, how would you rate this hack&apos;s difficulty level?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Difficoltà. &lt;/span&gt;In generale, come valuteresti il livello di difficoltà di questo hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="9"/>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="23"/>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="37"/>
        <source>I can&apos;t decide or have no opinion</source>
        <extracomment>0</extracomment>
        <translatorcomment>0</translatorcomment>
        <translation>Non riesco a decidere o non ho nessuna opinione</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="10"/>
        <source>Zero Effort</source>
        <extracomment>1</extracomment>
        <translatorcomment>1</translatorcomment>
        <translation>Zero Impegno</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="11"/>
        <source>Poor Quality</source>
        <extracomment>2</extracomment>
        <translatorcomment>2</translatorcomment>
        <translation>Scarsa Qualità</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="12"/>
        <source>A Little Rough</source>
        <extracomment>3</extracomment>
        <translatorcomment>3</translatorcomment>
        <translation>Un po&apos; sbrigativo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="13"/>
        <source>Unremarkable</source>
        <extracomment>4</extracomment>
        <translatorcomment>4</translatorcomment>
        <translation>Mediocre</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="14"/>
        <source>Decent</source>
        <extracomment>5</extracomment>
        <translatorcomment>5</translatorcomment>
        <translation>Decente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="15"/>
        <source>Pretty Good</source>
        <extracomment>6</extracomment>
        <translatorcomment>6</translatorcomment>
        <translation>Abbastanza Buono</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="16"/>
        <source>Very Good</source>
        <extracomment>7</extracomment>
        <translatorcomment>7</translatorcomment>
        <translation>Molto Buono</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="17"/>
        <source>Excellent</source>
        <extracomment>8</extracomment>
        <translatorcomment>8</translatorcomment>
        <translation>Eccellente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="18"/>
        <source>Exceptional</source>
        <extracomment>9</extracomment>
        <translatorcomment>9</translatorcomment>
        <translation>Eccezionale</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="19"/>
        <source>Legendary</source>
        <extracomment>10</extracomment>
        <translatorcomment>10</translatorcomment>
        <translation>Leggendario</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="24"/>
        <source>No Challenge</source>
        <extracomment>1</extracomment>
        <translatorcomment>1</translatorcomment>
        <translation>Nessuna Sfida</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="25"/>
        <source>Very Easy</source>
        <extracomment>2</extracomment>
        <translatorcomment>2</translatorcomment>
        <translation>Molto Facile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="26"/>
        <source>Casual</source>
        <extracomment>3</extracomment>
        <translatorcomment>3</translatorcomment>
        <translation>Facile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="27"/>
        <source>Classic SM64</source>
        <extracomment>4</extracomment>
        <translatorcomment>4</translatorcomment>
        <translation>Classico SM64</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="28"/>
        <source>Moderate</source>
        <extracomment>5</extracomment>
        <translatorcomment>5</translatorcomment>
        <translation>Moderato</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="29"/>
        <source>Challenging</source>
        <extracomment>6</extracomment>
        <translatorcomment>6</translatorcomment>
        <translation>Impegnativo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="30"/>
        <source>Difficult</source>
        <extracomment>7</extracomment>
        <translatorcomment>7</translatorcomment>
        <translation>Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="31"/>
        <source>Very Difficult</source>
        <extracomment>8</extracomment>
        <translatorcomment>8</translatorcomment>
        <translation>Molto Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="32"/>
        <source>Extremely Difficult</source>
        <extracomment>9</extracomment>
        <translatorcomment>9</translatorcomment>
        <translation>Estremamente Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="33"/>
        <source>Borderline Kaizo</source>
        <extracomment>10</extracomment>
        <translatorcomment>10</translatorcomment>
        <translation>Quasi Kaizo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="38"/>
        <source>Beginner/Introductory Kaizo</source>
        <extracomment>1</extracomment>
        <translatorcomment>1</translatorcomment>
        <translation>Kaizo Principiante/Preliminare</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="39"/>
        <source>Easy Kaizo</source>
        <extracomment>2</extracomment>
        <translatorcomment>2</translatorcomment>
        <translation>Kaizo Facile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="40"/>
        <source>Standard Kaizo</source>
        <extracomment>3</extracomment>
        <translatorcomment>3</translatorcomment>
        <translation>Kaizo Normale</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="41"/>
        <source>Moderate Kaizo</source>
        <extracomment>4</extracomment>
        <translatorcomment>4</translatorcomment>
        <translation>Kaizo Moderato</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="42"/>
        <source>Challenging Kaizo</source>
        <extracomment>5</extracomment>
        <translatorcomment>5</translatorcomment>
        <translation>Kaizo Impegnativo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="43"/>
        <source>Difficult Kaizo</source>
        <extracomment>6</extracomment>
        <translatorcomment>6</translatorcomment>
        <translation>Kaizo Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="44"/>
        <source>Very Difficult Kaizo</source>
        <extracomment>7</extracomment>
        <translatorcomment>7</translatorcomment>
        <translation>Kaizo Molto Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="45"/>
        <source>Extremely Difficult Kaizo</source>
        <extracomment>8</extracomment>
        <translatorcomment>8</translatorcomment>
        <translation>Kaizo Estremamente Difficile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="46"/>
        <source>Hardest humanly possible Kaizo</source>
        <extracomment>9</extracomment>
        <translatorcomment>9</translatorcomment>
        <translation>Kaizo Umanamente Impossibile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="47"/>
        <source>TAS/Unbeatable</source>
        <extracomment>10</extracomment>
        <translatorcomment>10</translatorcomment>
        <translation>TAS/Imbattibile</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="58"/>
        <source>Submit</source>
        <translation>Invia</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="82"/>
        <source>Not Rated</source>
        <translation>Non Valutato</translation>
    </message>
</context>
<context>
    <name>RhdcSync</name>
    <message>
        <location filename="../src/rhdc/core/sync.cpp" line="193"/>
        <source>Failed to sync progress with romhacking.com</source>
        <translation>Sincronizzazione progressi con romhacking.com non riuscita</translation>
    </message>
    <message>
        <location filename="../src/rhdc/core/sync.cpp" line="200"/>
        <source>Failed to connect to romhacking.com</source>
        <translation>Connessione a romhacking.com non riuscita</translation>
    </message>
</context>
<context>
    <name>RomListModel</name>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="246"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="247"/>
        <source>Internal Name</source>
        <translation>Nome Interno</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="248"/>
        <source>File Path</source>
        <translation>Percorso File</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="249"/>
        <source>Last Played</source>
        <translation>Ultima Giocata</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="250"/>
        <source>Play Time</source>
        <translation>Tempo di Gioco</translation>
    </message>
</context>
<context>
    <name>RomListView</name>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="212"/>
        <source>Delete Save File</source>
        <translation>Elimina File di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="213"/>
        <source>[SM64] Edit Save File</source>
        <translation>[SM64] Modifica File di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="218"/>
        <source>Download</source>
        <translation>Scaricati</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="222"/>
        <source>Add to...</source>
        <translation>Aggiungi a...</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="229"/>
        <source>New Group</source>
        <translation>Nuovo Gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="233"/>
        <source>Remove from %1</source>
        <translation>Rimuovi da %1</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="239"/>
        <source>Open Containing Folder</source>
        <translation>Apri Cartella Contenente</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="240"/>
        <source>Delete ROM</source>
        <translation>Elimina ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="242"/>
        <location filename="../src/ui/rom-list-view.cpp" line="326"/>
        <source>Rename</source>
        <translation>Rinomina</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="244"/>
        <source>Revert ROM Name</source>
        <translation>Ripristina Nome della ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="249"/>
        <source>Rate Hack</source>
        <translation>Valuta Hack</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="252"/>
        <source>Mark as Not Completed</source>
        <translation>Segna come Non Completato</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="254"/>
        <source>Mark as Completed</source>
        <translation>Segna come Completato</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="263"/>
        <location filename="../src/ui/rom-list-view.cpp" line="317"/>
        <source>Confirm Delete</source>
        <translation>Conferma Eliminazione</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="263"/>
        <source>Are you sure you want to delete your save file?</source>
        <translation>Sei sicuro di voler eliminare il tuo file di salvataggio?</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="279"/>
        <source>Create Group</source>
        <translation>Crea Gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="279"/>
        <source>Enter a name for your new group</source>
        <translation>Inserisci un nome per il tuo nuovo gruppo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="285"/>
        <source>Group Exists</source>
        <translation>Il Gruppo Esiste</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="285"/>
        <source>A group with this name already exists</source>
        <translation>Un gruppo con questo nome già esiste</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="317"/>
        <source>This will completely remove the ROM file from your computer. Are you sure you want to delete this ROM?</source>
        <translation>Ciò rimuoverà completamente il file ROM dal tuo computer. Sei sicuro di voler eliminare questa ROM?</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="326"/>
        <source>Enter a new name for your rom</source>
        <translation>Inserisci un nuovo nome per la tua ROM</translation>
    </message>
</context>
<context>
    <name>RomSettingsWidget</name>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="22"/>
        <source>Input Mode</source>
        <translation>Modalità Input</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="81"/>
        <source>Unlocks the CPU to run at full speed, removing CPU-based lag you would encounter on console. This is almost always safe, but can rarely cause issues on certain ROMs.</source>
        <translation>Sblocca la CPU per eseguire alla massima velocità, rimuovendo il lag dovuto alla CPU in cui incorreresti sulla console. Questo è quasi sempre sicuro, ma può causare di rado problemi su determinate ROM.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="84"/>
        <source>Overclock CPU (Recommended)</source>
        <translation>Overclocca CPU (Raccomandato)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="100"/>
        <source>Alters the vertical interrupt timing. In most cases this either gives a slight performance boost or has no effect, but in some cases it can cause the game to run at the wrong framerate.</source>
        <translation>Modifica i tempi di interruzione verticale. Ciò nella maggior parte dei casi o fornisce un leggero incremento delle prestazioni oppure non ha nessun effetto, ma in alcuni casi può portare il gioco ad essere eseguito con una frequenza dei fotogrammi errata.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="103"/>
        <source>Overclock VI</source>
        <translation>Overclocca VI</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="116"/>
        <source>Enable widescreen mode for ROMs that support it.</source>
        <translation>Abilita schermo largo.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="119"/>
        <source>Widescreen</source>
        <translation>Schermo Largo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="132"/>
        <source>Upscale textures drawn using the TEX_RECT command. This can cause visual artifacts in some games.</source>
        <translation>Amplia le texture disegnate con l&apos;uso del comando TEX-RECT. Questo può causare anomalie visive in alcuni giochi.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="135"/>
        <source>Upscale TEXRECTs</source>
        <translation>Amplia TEXRECTs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="148"/>
        <source>Emulate the native framebuffer. This is required for some visual effects to work, but may cause lag on lower end GPUs</source>
        <translation>Emula il framebuffer nativo. Ciò è necessario per far funzionare alcuni effetti visivi, ma potrebbe causare lag su GPU di fascia bassa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="151"/>
        <source>Emulate Framebuffer</source>
        <translation>Emula Framebuffer</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="167"/>
        <source>Greatly increases accuracy by rendering decals correctly, but may cause a loss in performance</source>
        <translation>Aumenta notevolmente la precisione riproducendo correttamente le decalcomanie, ma può causare una riduzione delle prestazioni</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="170"/>
        <source>Emulate N64 Depth Compare</source>
        <translation>Emula Confronto Profondità N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="192"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;Not enabling CPU overlocking is likely to result in a laggy experience. This option should only be used for speedruns or testing where you want to approximate console CPU lag.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Attenzione: &lt;/span&gt;Non abilitando l&apos;overlock della CPU potrebbe causare una prestazione alterata da lag. Quest&apos;opzione dovrebbe essere utilizzata solo per le speedrun o test in cui si desidera avvicinarsi al lag della CPU della console.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="216"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;The GLideN64 plugin for ParallelN64 is severely out of date. If you want to use this plugin, you should use the Mupen64plus-next emulator core.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Attenzione: &lt;/span&gt;Il plugin GLideN64 per ParallelN64 è altamente obsoleto. Se si desidera usare questo plugin, è necessario utilizzare il core dell&apos;emulatore Mupen64plus-next.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="259"/>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="356"/>
        <source>Graphics Plugin</source>
        <translation>Plugin Video</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="268"/>
        <source>ParaLLEl (Recommended - very accurate to console)</source>
        <translation>ParaLLEl (Raccomandato - uguale alla console)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="281"/>
        <source>Glide64 (Inaccurate, but needed by some older romhacks)</source>
        <translation>Glide64 (Impreciso, ma necessario per alcune vecchie romhacks)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="311"/>
        <source>GLideN64 [Old]</source>
        <translation>GLideN64 [Vecchio]</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="365"/>
        <source>ParaLLEl (Recommended)</source>
        <translation>ParaLLEl (Raccomandato)</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-settings-widget.cpp" line="178"/>
        <source>Show Fewer Plugins</source>
        <translation>Mostra Meno Plugin</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-settings-widget.cpp" line="178"/>
        <source>Show More Plugins</source>
        <translation>Mostra Più Plugin</translation>
    </message>
</context>
<context>
    <name>RomSourceDialog</name>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="14"/>
        <source>Manage ROM Sources</source>
        <translation>Gestisci Sorgenti ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="31"/>
        <source>ROM Search Folders</source>
        <translation>Cartella di ricerca ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="68"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="82"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="69"/>
        <source>New Source</source>
        <translation>Nuova Sorgente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="103"/>
        <source>ROM Source</source>
        <translation>Sorgente ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="114"/>
        <source>Browse for a folder</source>
        <translation>Cerca una cartella</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="121"/>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="431"/>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="502"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="134"/>
        <source>Also scan all subfolders</source>
        <translation>Scansiona anche tutte le sottocartelle</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="137"/>
        <source>Recursive</source>
        <translation>Ricorrente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="168"/>
        <source>Ignore directories that begin with a period character</source>
        <translation>Ignora cartelle che iniziano con un segno di interpunzione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="171"/>
        <source>Ignore hidden directories</source>
        <translation>Ignora cartelle nascoste</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="183"/>
        <source>Max Depth</source>
        <translation>Profondità Massima</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="236"/>
        <source>Follow symbolic links to folders and ROMs</source>
        <translation>Segui i collegamenti simbolici a cartelle e a ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="239"/>
        <source>Follow Symlinks</source>
        <translation>Segui Collegamenti Simbolici</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="256"/>
        <source>Automatically add to groups</source>
        <translation>Aggiungi automaticamente ai gruppi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="289"/>
        <source>Manage Groups</source>
        <translation>Gestisci Gruppi</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="317"/>
        <source>Individual ROMs</source>
        <translation>ROM Indipendenti</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="348"/>
        <source>Forget Selected ROM</source>
        <translation>Dimentica ROM Selezionata</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="359"/>
        <source>Add New ROM(s)</source>
        <translation>Aggiungi Nuova/e ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="388"/>
        <source>BPS Patches</source>
        <translation>BPS Patch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="417"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="290"/>
        <source>Patch File</source>
        <translation>Patcha File</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="444"/>
        <source>Base ROM</source>
        <translation>ROM di Base</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="450"/>
        <source>Automatic (Search Existing ROMs)</source>
        <translation>Automatico (Cerca ROM Esistenti)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="463"/>
        <source>Provided ROM:</source>
        <translation>ROM Fornita:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="532"/>
        <source>Apply Patch</source>
        <translation>Esegui Patch</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="267"/>
        <source>Select one or more ROMs</source>
        <translation>Seleziona una o più ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="289"/>
        <source>Select a .bps patch file</source>
        <translation>Seleziona un file patch .bps</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="300"/>
        <source>Select a ROM</source>
        <translation>Seleziona una ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="329"/>
        <source>Patch Applied</source>
        <translation>Patch Eseguita</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="329"/>
        <source>Saved patched rom to %1</source>
        <translation>ROM patchata salvata a %1</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="344"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="347"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="351"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="353"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="357"/>
        <source>Patch Failed</source>
        <translation>Patch non riuscita</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="344"/>
        <source>Failed to patch ROM. The .bps patch appears to be invalid.</source>
        <translation>Patch della ROM non riuscita. La patch .bps non sembra essere valida.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="347"/>
        <source>Failed to patch ROM. The base ROM does not match what the patch expects.</source>
        <translation>Patch della ROM non riuscita. La ROM di Base non sembra coincidere con ciò che la patch richiede.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="351"/>
        <source>Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher.</source>
        <translation>Patch della ROM non riuscita. La ROM di Base da patchare non è riconosciuta da Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="353"/>
        <source>Failed to patch ROM. The base ROM is missing or invalid.</source>
        <translation>Patch della ROM non riuscita. La ROM di Base manca o non è valida.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="357"/>
        <source>Failed to patch ROM. An error occurred while writing the patched ROM to disk.</source>
        <translation>Patch della ROM non riuscita. Si è verificato un errore durante la trascrizione della ROM patchata sul disco.</translation>
    </message>
</context>
<context>
    <name>SaveFileEditorDialog</name>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="14"/>
        <source>Edit SM64 Save File</source>
        <translation>Modifica File di Salvataggio di SM64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;This is a save file editor for Super Mario 64 and SM64 romhacks. Attempting to use this save file editor with other ROMs will corrupt your save file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Attenzione: &lt;/span&gt;Questo è un editor di file di salvataggio per le romhack di Super Mario 64 e SM64. Se si tenta di utilizzare questo editor di file di salvataggio con altre ROM, il file di salvataggio verrà danneggiato.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="41"/>
        <source>Save Slot:</source>
        <translation>Slot di Salvataggio:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="55"/>
        <source>Slot A (Empty)</source>
        <translation>Slot A (Vuoto)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="60"/>
        <source>Slot B (Empty)</source>
        <translation>Slot B (Vuoto)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="65"/>
        <source>Slot C (Empty)</source>
        <translation>Slot C (Vuoto)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="70"/>
        <source>Slot D (Empty)</source>
        <translation>Slot D (Vuoto)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="95"/>
        <source>Delete Save Slot</source>
        <translation>Elimina Slot di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="106"/>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="58"/>
        <source>Edit Save Slot</source>
        <translation>Modifica Slot di Salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="13"/>
        <source>Slot %1 (Empty)</source>
        <translation>Slot %1 (Vuoto)</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="16"/>
        <source>Slot %1 (%2 Stars)</source>
        <translation>Slot %1 (%2 Stelle)</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="62"/>
        <source>Create Save Slot</source>
        <translation>Crea Slot di Salvataggio</translation>
    </message>
</context>
<context>
    <name>SaveSlotEditorDialog</name>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="14"/>
        <source>Edit Save Slot (SM64)</source>
        <translation>Modifica Slot di Salvataggio (SM64)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="20"/>
        <source>Show flags and stars unused in the vanilla game</source>
        <translation>Mostra flag e stelle non utilizzate nel gioco originale</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="32"/>
        <source>Flags</source>
        <translation>Flag</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="74"/>
        <source>Caps Unlocked</source>
        <translation>Cappelli Sbloccati</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="80"/>
        <source>Wing Cap</source>
        <translation>Cappello Alato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="93"/>
        <source>Metal Cap</source>
        <translation>Cappello di Metallo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="106"/>
        <source>Vanish Cap</source>
        <translation>Cappello Invinsibile</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="122"/>
        <source>Keys Collected</source>
        <translation>Chiavi Raccolte</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="128"/>
        <source>Basement Key</source>
        <translation>Chiave del Seminterrato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="141"/>
        <source>Upstairs Key</source>
        <translation>Chiave del Piano Superiore</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="157"/>
        <source>Unlocked Doors</source>
        <translation>Porte Sbloccate</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="163"/>
        <source>Basement Key Door</source>
        <translation>Portone del Seminterrato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="176"/>
        <source>Upstairs Key Door</source>
        <translation>Portone del Piano Superiore</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="189"/>
        <source>Peach&apos;s Secret Slide Door</source>
        <translation>Porta dello Scivolo Della Principessa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="202"/>
        <source>Whomp&apos;s Fortress Door</source>
        <translation>Porta della Fortezza di Womp</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="215"/>
        <source>Cool Cool Mountain Door</source>
        <translation>Porta di Monte Refrigerio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="228"/>
        <source>Jolly Rodger Bay Door</source>
        <translation>Porta di Baia Pirata</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="241"/>
        <source>Dark World Door</source>
        <translation>Porta di Bowser al Buio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="254"/>
        <source>Fire Sea Door</source>
        <translation>Porta di Bowser nel Lago di Lava</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="267"/>
        <source>50 Star Door</source>
        <translation>Porta da 50 Stelle</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="283"/>
        <source>Miscellaneous</source>
        <translation>Varie</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="289"/>
        <source>Moat Drained</source>
        <translation>Fossato Prosciugato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="302"/>
        <source>Bowser&apos;s Sub Gone</source>
        <translation>Sottomarino di Bowser Sparito</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="318"/>
        <source>Unused</source>
        <translation>Non Utilizzato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="366"/>
        <source>Lost/Stolen Cap</source>
        <translation>Cappello Perso/Rubato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="374"/>
        <source>Level</source>
        <translation>Livello</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="395"/>
        <source>Area</source>
        <translation>Area</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="427"/>
        <source>Cap Stolen By:</source>
        <translation>Cappello Rubato Da:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="434"/>
        <source>The flag indicates that Mario&apos;s cap is on the ground, however, when loading a save file, a cap that is on the ground is either given back to Mario or moved to the appropriate NPC for the area, so it will never actually be on the ground.</source>
        <translation>Il flag indica che il cappello di Mario è per terra, tuttavia, quando un file di salvataggio viene caricato, un cappello che si trova per terra o viene ridato indietro a Mario oppure viene spostato sull&apos;NPC appropriato per l&apos;area, così non sarà mai davvero per terra.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="437"/>
        <source>Automatic*</source>
        <translation>Automatico*</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="450"/>
        <source>Klepto (Bird)</source>
        <translation>Klepto (uccello)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="463"/>
        <source>Ukiki (Monkey)</source>
        <translation>Ukiki (scimmia)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="476"/>
        <source>Mr. Blizzard (Snowman)</source>
        <translation>Mr. Bufera (pupazzo di neve)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="499"/>
        <source>Stars and Coins</source>
        <translation>Stelle e Monete</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="44"/>
        <source>Big Boo&apos;s Haunt</source>
        <translation>Rifugio di Re Boo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="45"/>
        <source>Cool Cool Mountain</source>
        <translation>Monte Refrigerio</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="46"/>
        <source>Castle Interior</source>
        <translation>Interno del Castello</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="47"/>
        <source>Hazy Maze Cave</source>
        <translation>Grotta Labirinto</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="48"/>
        <source>Shifting Sand Land</source>
        <translation>Deserto Ingoiatutto</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="49"/>
        <source>Bob-Omb Battlefield</source>
        <translation>Battaglia di Bob-ombe</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="50"/>
        <source>Snowman&apos;s Land</source>
        <translation>Terra Innevata</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="51"/>
        <source>Wet Dry World</source>
        <translation>Bagna Asciuga</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="52"/>
        <source>Jolly Rodger Bay</source>
        <translation>Baia Pirata</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="53"/>
        <source>Tiny-Huge Island</source>
        <translation>Isola Granpiccola</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="54"/>
        <source>Tick Tock Clock</source>
        <translation>Pendolo Tictoccato</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="55"/>
        <source>Rainbow Ride</source>
        <translation>Cammino Arcobaleno</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="56"/>
        <source>Castle Grounds</source>
        <translation>Esterno del Castello</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="57"/>
        <source>Bowser in the Dark World</source>
        <translation>Bowser al Buio</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="58"/>
        <source>Vanish Cap Under the Moat</source>
        <translation>Il Segreto del Fossato</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="59"/>
        <source>Bowser in the Fire Sea</source>
        <translation>Bowser nel Lago di Lava</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="60"/>
        <source>Secret Aquarium</source>
        <translation>L’Aquario Segreto</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="61"/>
        <source>Bowser in the Sky</source>
        <translation>Bowser in Cielo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="62"/>
        <source>Lethal Lava Land</source>
        <translation>Lago di Lava</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="63"/>
        <source>Dire Dire Docks</source>
        <translation>Abisso Acquatico</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="64"/>
        <source>Whomp&apos;s Fortress</source>
        <translation>Fortezza di Womp</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="65"/>
        <source>End Screen</source>
        <translation>Schermata Finale</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="66"/>
        <source>Castle Courtyard</source>
        <translation>Cortile del Castello</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="67"/>
        <source>Peach&apos;s Secret Slide</source>
        <translation>Lo Scivolo della Principessa</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="68"/>
        <source>Cavern of the Metal Cap</source>
        <translation>Caverna di Metallo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="69"/>
        <source>Tower of the Wing Cap</source>
        <translation>Torre Arcobaleno</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="70"/>
        <source>Bowser 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="71"/>
        <source>Winged Mario over the Rainbow</source>
        <translation>Oltre l&apos;arcobaleno</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="73"/>
        <source>Bowser 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="74"/>
        <source>Bowser 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="76"/>
        <source>Tall, Tall Mountain</source>
        <translation>Monte Gigante</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="11"/>
        <source>8 Red Coins</source>
        <translation>8 Monete Rosse</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="12"/>
        <source>100 Coins</source>
        <translation>100 Monete</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="17"/>
        <source>Toad 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="18"/>
        <source>Toad 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="19"/>
        <source>Toad 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="20"/>
        <source>MIPS 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="21"/>
        <source>MIPS 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="27"/>
        <source>Big Bob-Omb on the Summit</source>
        <translation>Boss Bob-omba sulla cima</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="28"/>
        <source>Footface with Koopa the Quick</source>
        <translation>Gara con Koopa il Veloce</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="29"/>
        <source>Shoot to the Island in the Sky</source>
        <translation>Verso l&apos;Isola Gran piccola</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="30"/>
        <source>Find the 8 Red Coins</source>
        <translation>Trova le 8 Monete Rosse</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="31"/>
        <source>Mario Wings to the Sky</source>
        <translation>Mario Spicca il Volo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="32"/>
        <source>Behind Chain Chomp&apos;s Gate</source>
        <translation>Oltre il Cancello di Categnaccio</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="37"/>
        <source>Chip Off Whomp&apos;s Block</source>
        <translation>Schiaccia Womp</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="38"/>
        <source>To the Top of the Fortress</source>
        <translation>In Cima alla Fortezza</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="39"/>
        <source>Shoot into the Wild Blue</source>
        <translation>Lancio nel blu dipinto di blu</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="40"/>
        <source>Red Coins on the Floating Isle</source>
        <translation>Monete Rosse sull&apos;Isola Sospesa</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="41"/>
        <source>Fall onto the Caged Island</source>
        <translation>Caduta sull&apos;Isola Ingabbiata</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="42"/>
        <source>Blast Away the Wall</source>
        <translation>Distruggi il Muro</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="47"/>
        <source>Plunder in the Sunken Ship</source>
        <translation>Il Bottino della Nave Affondata</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="48"/>
        <source>Can the Eel Come Out to Play?</source>
        <translation>Voglio Giocare con l&apos;Anguilla!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="49"/>
        <source>Treasure of the Ocean Cave</source>
        <translation>Tesoro nella Grotta Subacquea</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="50"/>
        <source>Red Coins on the Ship Afloat</source>
        <translation>Monete Rosse sulla Nave</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="51"/>
        <source>Blast to the Stone Pillar</source>
        <translation>Afferra il Pilastro in Pietra</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="52"/>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="110"/>
        <source>Through the Jet Stream</source>
        <translation>Contro Corrente</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="57"/>
        <source>Slip Slidin&apos; Away</source>
        <translation>Scivolando verso la Meta</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="58"/>
        <source>Li&apos;l Penguin Lost</source>
        <translation>Smarrita una Pinguina...</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="59"/>
        <source>Big Penguin Race</source>
        <translation>Sfida al Pinguino Gigante</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="60"/>
        <source>Frosty Slide for 8 Red Coins</source>
        <translation>Le 8 Monete Rosse da Scivolo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="61"/>
        <source>Snowman&apos;s Lost his Head</source>
        <translation>Il Pupazzo ha Perso la Testa</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="62"/>
        <source>Wall Kicks Will Work</source>
        <translation>Il Super Salto a Parete di Mario</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="67"/>
        <source>Go on a Ghost Hunt</source>
        <translation>A Caccia di Fantasmi</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="68"/>
        <source>Ride Big Boo&apos;s Merry-Go-Round</source>
        <translation>La Giostra del Re Boo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="69"/>
        <source>Secret of the Haunted Books</source>
        <translation>I segreti dei libri posseduti</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="70"/>
        <source>Seek the 8 Red Coins</source>
        <translation>Cerca le 8 Monete Rosse</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="71"/>
        <source>Big Boo&apos;s Balcony</source>
        <translation>Il Balcone di Re Boo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="72"/>
        <source>Eye to Eye in the Secret Room</source>
        <translation>Occhi Aperti nella Stanza Segreta!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="77"/>
        <source>Swimming Beast in the Cavern</source>
        <translation>Mostro Acquatico nella Grotta</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="78"/>
        <source>Elevate for 8 Red Coins</source>
        <translation>Sali per le 8 Monete</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="79"/>
        <source>Metal-Head Mario Can Move!</source>
        <translation>Mario, che uomo di ferro!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="80"/>
        <source>Navigating the Toxic Maze</source>
        <translation>Nel Labirinto Velenoso</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="81"/>
        <source>A-maze-ing Emergency Exit</source>
        <translation>Anche i Labirinti hanno un&apos;Uscita</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="82"/>
        <source>Watch for Rolling Rocks</source>
        <translation>Rotolamento Massi</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="87"/>
        <source>Boil the Big Bully</source>
        <translation>Fallo Cuocere nel Suo Brodo!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="88"/>
        <source>Bully the Bullies</source>
        <translation>Prendili per le Corna</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="89"/>
        <source>8-Coin Puzzle with 15 Pieces</source>
        <translation>Puzzle a 15 Pezzi per 8 Monete</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="90"/>
        <source>Red-Hot Log Rolling</source>
        <translation>Corsa sul Tronco Ardente</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="91"/>
        <source>Hot-Foot-it into the Volcano</source>
        <translation>Sul Pendio del Vulcano</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="92"/>
        <source>Elevator Tour in the Volcano</source>
        <translation>Dentro il Vulcano</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="97"/>
        <source>In the Talons of the Big Bird</source>
        <translation>Tra gli Artigli del Grande Uccello</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="98"/>
        <source>Shining Atop the Pyramid</source>
        <translation>La Punta della Piramide</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="99"/>
        <source>Inside the Ancient Pyramid</source>
        <translation>All&apos;Esplorazione della Piramide</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="100"/>
        <source>Stand Tall on the Four Pillars</source>
        <translation>I Quattro Pilastri</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="101"/>
        <source>Free Flying for 8 Red Coins</source>
        <translation>Le 8 Monete in Volo Libero</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="102"/>
        <source>Pyramid Puzzle</source>
        <translation>Puzzle Piramidale</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="107"/>
        <source>Board Bowser&apos;s Sub</source>
        <translation>Il Sottomarino di Bowser</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="108"/>
        <source>Chests in the Current</source>
        <translation>Scrigni Portati dalla Corrente</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="109"/>
        <source>Pole-Jumping for Red Coins</source>
        <translation>Saltando di Palo in... Moneta Rossa</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="111"/>
        <source>The Manta Ray&apos;s Reward</source>
        <translation>La Ricompensa della Manta</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="112"/>
        <source>Collect the Caps...</source>
        <translation>Nella Gabbia</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="117"/>
        <source>Snowman&apos;s Big Head</source>
        <translation>Il Pupazzo si è Montato la Testa</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="118"/>
        <source>Chill with the Bully</source>
        <translation>Raffredda i bollenti spiriti</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="119"/>
        <source>In the Deep Freeze</source>
        <translation>Il cubo di ghiaccio</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="120"/>
        <source>Whirl from the Freezing Pond</source>
        <translation>Vola Oltre il Lago Gelato</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="121"/>
        <source>Shell Shreddin&apos; for Red Coins</source>
        <translation>Snowboard sul guscio per le monete rosse</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="122"/>
        <source>Into the Igloo</source>
        <translation>Dentro l&apos;Igloo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="127"/>
        <source>Shocking Arrow Lifts!</source>
        <translation>Sale o Scende?</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="128"/>
        <source>Top o&apos; the Town</source>
        <translation>Sopra la Città</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="129"/>
        <source>Secrets in the Shallows &amp; Sky</source>
        <translation>I 5 Segreti dall&apos;Alto in Basso</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="130"/>
        <source>Express Evelator--Hurry Up!</source>
        <translation>Ascensore Espresso - Affrettarsi!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="131"/>
        <source>Go to Town for Red Coins</source>
        <translation>Monete Rosse in Città</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="132"/>
        <source>Quick Race through Downtown!</source>
        <translation>Gara in Centro!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="137"/>
        <source>Scale the Mountain</source>
        <translation>Una Montagna da Scalare</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="138"/>
        <source>Mystery of the Monkey&apos;s Cage</source>
        <translation>Il Segreto della Gabbia</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="139"/>
        <source>Scary &apos;Shrooms, Red Coins</source>
        <translation>Monete Rosse e Funghi Spaventosi</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="140"/>
        <source>Mysterious Mountainside</source>
        <translation>Pendio Montano Misterioso</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="141"/>
        <source>Breathtaking View from Bridge</source>
        <translation>Panorama Mozzafiato dal Ponte</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="142"/>
        <source>Blast to the Lonely Mushroom</source>
        <translation>Il Fungo Solitario</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="147"/>
        <source>Pluck the Piranha Flower</source>
        <translation>Fai Fuori i Fiori Piranha</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="148"/>
        <source>The Tip Top of the Huge Island</source>
        <translation>Il Cucuzzolo dell&apos;Isola</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="149"/>
        <source>Rematch with Koopa the Quick</source>
        <translation>Rivincita con Koopa il Veloce</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="150"/>
        <source>Five Itty Bitty Secrets</source>
        <translation>I cinque piccoli segreti</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="151"/>
        <source>Wiggler&apos;s Red Coins</source>
        <translation>Le Monete Rosse del Torcibruco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="152"/>
        <source>Make Wiggler Squirm</source>
        <translation>Filo da Torcere per Torcibruco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="157"/>
        <source>Roll into the Cage</source>
        <translation>Mario in gabbia</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="158"/>
        <source>The Pit and the Pendulums</source>
        <translation>L&apos;interruttore sul pendolo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="159"/>
        <source>Get a Hand</source>
        <translation>Dammi una Mano</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="160"/>
        <source>Stomp on the Thwomp</source>
        <translation>Salta sul Twomp</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="161"/>
        <source>Timed Jumps on Moving Bars</source>
        <translation>Salti Sincronizzati</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="162"/>
        <source>Stop Time for Red Coins</source>
        <translation>Tempo Fermo, Monete Rosse</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="167"/>
        <source>Cruiser Crossing the Rainbow</source>
        <translation>In crociera sull&apos;arcobaleno</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="168"/>
        <source>The Big House in the Sky</source>
        <translation>Grande Casa in Cielo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="169"/>
        <source>Coins Amassed in a Maze</source>
        <translation>Monete nel Labirinto</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="170"/>
        <source>Swingin&apos; in the Breeze</source>
        <translation>Dondolando nella Brezza</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="171"/>
        <source>Tricky Triangles!</source>
        <translation>Triangoli Traditori!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="172"/>
        <source>Somewhere Over the Rainbow</source>
        <translation>Sopra l&apos;Arcobaleno</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="227"/>
        <source>Act 1 Star</source>
        <translation>Stella n°1</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="228"/>
        <source>Act 2 Star</source>
        <translation>Stella n°2</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="229"/>
        <source>Act 3 Star</source>
        <translation>Stella n°3</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="230"/>
        <source>Act 4 Star</source>
        <translation>Stella n°4</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="231"/>
        <source>Act 5 Star</source>
        <translation>Stella n°5</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="232"/>
        <source>Act 6 Star</source>
        <translation>Stella n°6</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="233"/>
        <source>100 Coin Star</source>
        <translation>Stella da 100 Monete</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="234"/>
        <source>Cannon Status</source>
        <translation>Stato del Cannone</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="235"/>
        <source>Coin High Score</source>
        <translation>Miglior Punteggio di Monete</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="264"/>
        <source>Peach&apos;s Castle</source>
        <translation>Castello di Peach</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="315"/>
        <source>-- None --</source>
        <translation>-- Nessuno --</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="44"/>
        <source>User Interface</source>
        <translation>Interfaccia Utente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="49"/>
        <source>Emulation</source>
        <translation>Emulazione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="54"/>
        <source>BPS Patches</source>
        <translation>Patch BPS</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="59"/>
        <source>GFX Plugins</source>
        <translation>Plugin GFX</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="64"/>
        <source>Updaters</source>
        <translation>Aggiornamenti</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="69"/>
        <source>Romhacking.com</source>
        <translation>Romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="108"/>
        <source>Theme (Requires Restart)</source>
        <translation>Tema (Richiede Riavvio)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="126"/>
        <source>Language (Requires Restart)</source>
        <translation>Lingua (Richiede Riavvio)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="141"/>
        <source>Hide launcher while playing ROM</source>
        <translation>Nascondi applicazione mentre giochi ad una ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="148"/>
        <source>Check for updates on startup</source>
        <translation>Verifica aggiornamenti all&apos;avvio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="158"/>
        <source>Visible Columns</source>
        <translation>Colonne Visibili</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="164"/>
        <source>The full path to the file</source>
        <translation>Il percorso completo del file</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="167"/>
        <source>File Path</source>
        <translation>Percorso File</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="177"/>
        <source>The filename without the extension</source>
        <translation>Il nome del file senza estensione</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="180"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="193"/>
        <source>The name stored in the ROM itself</source>
        <translation>Il nome memorizzato all&apos;interno della ROM stessa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="196"/>
        <source>Internal Name</source>
        <translation>Nome Interno</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="203"/>
        <source>The date you last played the ROM</source>
        <translation>La data in cui hai giocato alla ROM l&apos;ultima volta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="206"/>
        <source>Last Played</source>
        <translation>Ultima Giocata</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="216"/>
        <source>The total time spent playing the ROM</source>
        <translation>Il tempo complessivo che hai speso a giocare alla ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="219"/>
        <source>Total Play Time</source>
        <translation>Tempo Complessivo di Gioco</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="260"/>
        <source>Window Scale</source>
        <translation>Scala Finestra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="318"/>
        <source>Default ParallelN64 Plugin</source>
        <translation>Plugin Predefinito per ParallelN64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="328"/>
        <source>Default Mupen Plugin</source>
        <translation>Plugin Predefinito per Mupen</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="399"/>
        <source>Default Emulator Core</source>
        <translation>Core dell&apos;Emulatore Predefinito</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="411"/>
        <source>Vsync (May cause slight audio crackling)</source>
        <translation>Sincronizzazione Verticale (Potrebbe provocare un audio leggermente scoppiettante)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="418"/>
        <source>Pause when emulator loses focus</source>
        <translation>Metti in pausa l&apos;emulatore quando cambi finestra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="433"/>
        <source>Reset RetroArch Config</source>
        <translation>Ripristina Configurazione di RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="485"/>
        <source>When loading a BPS patch, save the patched ROM...</source>
        <translation>Quando viene caricata una patch BPS, salva la ROM patchata...</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="492"/>
        <source>To the same folder as the patch</source>
        <translation>Nella stessa cartella della patch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="505"/>
        <source>To this folder:</source>
        <translation>In questa cartella:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="547"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1232"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="582"/>
        <source>Global Settings</source>
        <translation>Impostazioni Globali</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="606"/>
        <source>Upscaling</source>
        <translation>Ampliamento</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="622"/>
        <source>Native (x1 - 320x240)</source>
        <translation>Nativo (x1 - 320x240)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="660"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="796"/>
        <source>Anti-Aliasing</source>
        <translation>Anti-Aliasing</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="695"/>
        <source>Filtering</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="706"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="711"/>
        <source>Anti-Alias</source>
        <translation>Anti-Alias</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="716"/>
        <source>Anti-Alias + Dedither</source>
        <translation>Anti-Alias + Dedither</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="721"/>
        <source>Anti-Alias + Blur</source>
        <translation>Anti-Alias + Sfocatura</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="726"/>
        <source>Filtered</source>
        <translation>Filtrato</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="774"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="918"/>
        <source>(Mupen64Plus-Next Only)</source>
        <translation>(Solo Mupen64Plus-Next)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="806"/>
        <source>Use N64 3-Point Filtering</source>
        <translation>Usa il filtro a 3 punti N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="830"/>
        <source>Default ROM Settings</source>
        <translation>Impostazioni Predefinite della ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="854"/>
        <source>Upscale textures drawn using the TEX_RECT command. This can cause visual artifacts in some games.</source>
        <translation>Amplia le texture disegnate con l&apos;uso del comando TEX_RECT. Questo può causare anomalie visive in alcuni giochi.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="857"/>
        <source>Upscale TEXRECTs</source>
        <translation>Amplia TEXRECTs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="877"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="968"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1012"/>
        <source>Apply to all existing ROMs</source>
        <translation>Applica a tutte le ROM esistenti</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="942"/>
        <source>Emulate the native framebuffer. This is required for some visual effects to work, but may cause lag on lower end GPUs</source>
        <translation>Emula il framebuffer nativo. Ciò è necessario per far funzionare alcuni effetti visivi, ma potrebbe causare lag su GPU di fascia bassa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="945"/>
        <source>Emulate Framebuffer</source>
        <translation>Emula Framebuffer</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="986"/>
        <source>Greatly increases accuracy by rendering decals correctly, but may cause a loss in performance</source>
        <translation>Aumenta notevolmente la precisione riproducendo correttamente le decalcomanie, ma può causare una riduzione delle prestazioni</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="989"/>
        <source>Emulate N64 Depth Compare</source>
        <translation>Emula Confronto Profondità N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1049"/>
        <source>Enable RetroArch Automatic Updates</source>
        <translation>Abilita Aggiornamenti Automatici per RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1059"/>
        <source>Enable ParallelN64 Automatic Updates</source>
        <translation>Abilita Aggiornamenti Automatici per ParallelN64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1069"/>
        <source>Enable Mupen64Plus-Next Automatic Updates</source>
        <translation>Abilita Aggiornamenti Automatici per Mupen64Plus-Next</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1097"/>
        <source>Use development branch</source>
        <translation>Utilizza ramo di sviluppo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1111"/>
        <source>Update Interval</source>
        <translation>Aggiorna Intervallo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1131"/>
        <source>Every Launch</source>
        <translation>Ogni Avvio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1136"/>
        <source>Daily</source>
        <translation>Quotidiano</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1141"/>
        <source>Weekly</source>
        <translation>Settimanale</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1146"/>
        <source>Monthly</source>
        <translation>Mensile</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1171"/>
        <source>Check for Updates</source>
        <translation>Verifica Aggiornamenti</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1210"/>
        <source>Download Directory</source>
        <translation>Scarica Cartella</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1222"/>
        <source>Sets the directory that hacks downloaded from romhacking.com will be saved to. If you change this setting later, your roms will automatically be moved to the new directory.</source>
        <translation>Seleziona la cartella in cui verranno salvati gli hack scaricati da romhacking.com. Se cambierai queste impostazioni in seguito, le tue ROM verranno automaticamente spostate nella nuova cartella.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1261"/>
        <source>Enable Star Display</source>
        <translation>Abilita Visualizzazione delle Stelle</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1271"/>
        <source>If checked, Parallel Launcher will submit your highest star count across all save slots to romhacking.com; otherwise, it will only submit your star count in slot A.</source>
        <translation>Se marcato, Parallel Launcher comunicherà il numero più alto di stelle tra tutti gli slot di salvataggio a romhacking.com; altrimenti, comunicherà solo il numero di stelle nello slot A.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1274"/>
        <source>Check all save slots</source>
        <translation>Verifica tutte le posizioni di salvataggio</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1281"/>
        <source>If checked, Parallel Launcher will use the GLideN64 plugin instead of the ParaLLEl plugin when it guesses that ParrLLEl is probably the best plugin to use. Only check this if your computer has an old GPU with poor Vulkan support. If you still experience lag even with GlideN64, you may need to disable &apos;Emulate Framebuffer&apos; and/or &apos;Emulate N64 Depth Compare&apos; in the GFX Plugins section of your Parallel Launcher settings.</source>
        <translation>Se marcato, Parallel Launcher utilizzerà il plugin GLideN64 piuttosto che ParaLLEl quando ritiene che ParaLLEl sia probabilmente la scelta più adatta. Marca qui solo se il tuo computer ha una vecchia GPU con uno scarso supporto Vulkan. Se si verifica lag anche con GLideN64, potrebbe essere necessario disabilitare &apos;Emula Framebuffer&apos; e/o &apos;Emula N64 Depth Compare&apos; nella sezione Plugin GFX delle tue impostazioni di Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1284"/>
        <source>Prefer HLE plugins</source>
        <translation>Preferisco HLE plugin</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="47"/>
        <source>Automatic (%1)</source>
        <translation>Automatico (%1)</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="232"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="236"/>
        <location filename="../src/ui/settings-dialog.cpp" line="243"/>
        <source>Select a Folder</source>
        <translation>Seleziona una Cartella</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="252"/>
        <source>Confirm Reset</source>
        <translation>Conferma Ripristino</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="253"/>
        <source>This will reset your RetroArch config file, undoing any changes you have made within RetroArch. Your Parallel Launcher settings will not be affected. Do you want to continue?</source>
        <translation>Questo ripristinerà i file di configurazione di RetroArch, annullando tutte le modifiche che hai apportato all&apos;interno di RetroArch. Le impostazioni di Parallel Launcher non saranno interessate. Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="256"/>
        <source>Config Reset</source>
        <translation>Ripristino Configurazione</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="256"/>
        <source>Your RetroArch config has been reset.</source>
        <translation>La configurazione di RetroArch è stata ripristinata.</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="258"/>
        <source>Oops</source>
        <translation>Oops</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="258"/>
        <source>An unknown error occurred. Your RetroArch config has not been reset.</source>
        <translation>Si è verificato un errore sconosciuto. La configurazione di RetroArch non è stata ripristinata.</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="276"/>
        <location filename="../src/ui/settings-dialog.cpp" line="282"/>
        <location filename="../src/ui/settings-dialog.cpp" line="288"/>
        <source>Confirm Apply All</source>
        <translation>Conferma Applica Tutto</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="276"/>
        <location filename="../src/ui/settings-dialog.cpp" line="282"/>
        <location filename="../src/ui/settings-dialog.cpp" line="288"/>
        <source>Apply this setting to all current roms?</source>
        <translation>Applicare quest&apos;impostazione a tutte le ROM attuali?</translation>
    </message>
</context>
<context>
    <name>SingleplayerControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/singleplayer-controller-select-dialog.ui" line="20"/>
        <source>Controller Select</source>
        <translation>Selezione Controller</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/singleplayer-controller-select-dialog.ui" line="32"/>
        <source>Multiple controllers are connected. Which one do you want to use?</source>
        <translation>Più di un controller è connesso. Quale vuoi usare?</translation>
    </message>
    <message>
        <location filename="../src/ui/singleplayer-controller-select-dialog.cpp" line="19"/>
        <source>Unknown Controller (%1)</source>
        <translation>Controller Non Riconosciuto (%1)</translation>
    </message>
</context>
<context>
    <name>StarDisplayWidget</name>
    <message>
        <location filename="../src/rhdc/ui/designer/star-display-widget.ui" line="30"/>
        <source>MARIO A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/star-display-widget.ui" line="60"/>
        <source>MARIO B</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/star-display-widget.ui" line="90"/>
        <source>MARIO C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/star-display-widget.ui" line="120"/>
        <source>MARIO D</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>UpdateDialog</name>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="14"/>
        <source>Update Available</source>
        <translation>Aggiornamento Disponibile</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="26"/>
        <source>A new update is available for Parallel Launcher. Would you like to update now?</source>
        <translation>Un nuovo aggiornamento è disponibile per Parallel Launcher. Vuoi aggiornare ora?</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="62"/>
        <source>Changelog:</source>
        <translation>Registro Modifiche:</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="79"/>
        <source>Don&apos;t remind me again</source>
        <translation>Non ricordarmelo di nuovo</translation>
    </message>
</context>
<context>
    <name>WindowsRetroArchUpdater</name>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="110"/>
        <source>Checking for RetroArch Updates</source>
        <translation>Verifica aggiornamenti per RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="237"/>
        <source>Download Failed</source>
        <translation>Scaricamento non riuscito</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="238"/>
        <source>Failed to download RetroArch.</source>
        <translation>Scaricamento di RetroArch non riuscito.</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="245"/>
        <source>Installing RetroArch</source>
        <translation>Installando RetroAch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="257"/>
        <source>Installation Error</source>
        <translation>Errore di Installazione</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="258"/>
        <source>An error occurred attempting to uncompress the portable RetroArch bundle</source>
        <translation>Si è verificato un errore durante il tentativo di decompressione del pacchetto esportabile di RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="295"/>
        <source>Install Update?</source>
        <translation>Installare Aggiornamento?</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="296"/>
        <source>An update for RetroArch is available. Would you like to install it now?</source>
        <translation>Un aggiornamento per RetroArch è disponibile. Vuoi installarlo ora?</translation>
    </message>
</context>
<context>
    <name>WindowsUpdater</name>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="52"/>
        <source>Download Failed</source>
        <translation>Scaricamento non riuscito</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="53"/>
        <source>Failed to download the latest installer. Try again later.</source>
        <translation>Non è stato possibile scaricare l&apos;ultima versione del programma di installazione. Riprova più tardi.</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="40"/>
        <source>Unexpected Error</source>
        <translation>Errore Inaspettato</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="41"/>
        <source>Failed to launch installer.</source>
        <translation>Avvio del programma di installazione non riuscito.</translation>
    </message>
</context>
</TS>
