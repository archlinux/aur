#include "layoutdescription.hpp"

#include <QBuffer>
#include "src/ui/icons.hpp"
#include "src/polyfill/base-directory.hpp"

fs::path LayoutDescription::pathForHack( const string &hackId ) {
	return BaseDir::data() / "jsml" / (hackId + ".json");
}

static constexpr char P_COURSE_DESCRIPTION[] = "courseDescription";
static constexpr char P_SECRET_DESCRIPTION[] = "secretDescription";
static constexpr char P_STAR_AMOUNT[] = "starAmount";
static constexpr char P_STARS_SHOWN[] = "starsShown";
static constexpr char P_GOLD_STAR[] = "goldStar";
static constexpr char P_DARK_STAR[] = "darkStar";

// Line Descriptions
static constexpr char P_LINE_DESCRIPTION_TYPE[] = "Type";
static constexpr char P_DISPLAY_TEXT[] = "text";
static constexpr char P_STAR_MASK[] = "starMask";
static constexpr char P_STAR_OFFSET[] = "offset";

static QPixmap desaturate( const QPixmap &source ) {
	QImage image = source.toImage().convertToFormat( QImage::Format_ARGB32 );

	const size_t numPixels = image.sizeInBytes() / 4;
	uint *pixels = (uint*)image.bits();

	qreal H, S, V, A;
	for( size_t i = 0; i < numPixels; i++ ) {
		QColor colour( (QRgb)pixels[i] );
		colour.setAlpha( pixels[i] >> 24 );
		colour.getHsvF( &H, &S, &V, &A );
		pixels[i] = (uint)QColor::fromHsvF( H, 0.0, V, A ).rgba();
	}

	return QPixmap::fromImage( image );
}

template<> LayoutDescription JsonSerializer::parse<LayoutDescription>( const Json &json ) {
	std::vector<LineDescription> courseDescription;

	if( json[P_COURSE_DESCRIPTION].exists() && json[P_COURSE_DESCRIPTION].isArray() ) {
		for( const Json &x : json[P_COURSE_DESCRIPTION].array() ) {
			courseDescription.push_back({
				x[P_LINE_DESCRIPTION_TYPE].getOrDefault<LayoutDescriptionType>( Unknown ),
				x[P_DISPLAY_TEXT].getOrDefault<string>( "" ),
				x[P_STAR_MASK].getOrDefault<ubyte>( 0 ),
				x[P_STAR_OFFSET].getOrDefault<int>( 0 )
			});
		}
	}

	std::vector<LineDescription> secretDescription;

	if( json[P_SECRET_DESCRIPTION].exists() && json[P_SECRET_DESCRIPTION].isArray() ) {
		for( const Json &x : json[P_SECRET_DESCRIPTION].array() ) {
			secretDescription.push_back({
				x[P_LINE_DESCRIPTION_TYPE].getOrDefault<LayoutDescriptionType>( Unknown ),
				x[P_DISPLAY_TEXT].getOrDefault<string>( "" ),
				x[P_STAR_MASK].getOrDefault<ubyte>( 0 ),
				x[P_STAR_OFFSET].getOrDefault<int>( 0 )
			});
		}
	}

	QPixmap goldStar;
	if( json[P_GOLD_STAR].hasValue() ) {
		QByteArray starBytes = QByteArray::fromBase64( json[P_GOLD_STAR].get<string>().c_str() );
		goldStar.loadFromData( starBytes );
	} else {
		goldStar = Icon::rhdc().pixmap( 32, 32 );
	}

	QPixmap darkStar;
	if( json[P_DARK_STAR].hasValue() ) {
		QByteArray starBytes = QByteArray::fromBase64( json[P_DARK_STAR].get<string>().c_str() );
		darkStar.loadFromData( starBytes );
	} else {
		darkStar = desaturate( goldStar );
	}

	return LayoutDescription {
		courseDescription,
		secretDescription,
		json[P_STAR_AMOUNT].getOrDefault<string>( "" ),
		json[P_STARS_SHOWN].getOrDefault<int>( 0 ),
		goldStar,
		darkStar
	};
}

template<> void JsonSerializer::serialize<LayoutDescription>( JsonWriter &jw, const LayoutDescription &layoutDescription ) {
	jw.writeObjectStart();
	jw.writePropertyName( P_COURSE_DESCRIPTION );
	jw.writeArrayStart();
	for( auto x : layoutDescription.courseDescription ) {
		jw.writeObjectStart();
		jw.writeProperty( P_LINE_DESCRIPTION_TYPE, x.type );
		jw.writeProperty( P_DISPLAY_TEXT, x.text );
		jw.writeProperty( P_STAR_MASK, x.starMask );
		jw.writeProperty( P_STAR_OFFSET, x.offset );
		jw.writeObjectEnd();
	}
	jw.writeArrayEnd();

	jw.writePropertyName( P_SECRET_DESCRIPTION );
	jw.writeArrayStart();
	for( auto x : layoutDescription.secretDescription ) {
		jw.writeObjectStart();
		jw.writeProperty( P_LINE_DESCRIPTION_TYPE, x.type );
		jw.writeProperty( P_DISPLAY_TEXT, x.text );
		jw.writeProperty( P_STAR_MASK, x.starMask );
		jw.writeProperty( P_STAR_OFFSET, x.offset );
		jw.writeObjectEnd();
	}
	jw.writeArrayEnd();

	QBuffer goldBuffer;
	goldBuffer.open( QIODevice::WriteOnly );
	layoutDescription.goldStar.save( &goldBuffer, "PNG" );
	jw.writeProperty( P_GOLD_STAR, goldBuffer.data().toBase64().toStdString() );
	goldBuffer.close();

	QBuffer darkBuffer;
	darkBuffer.open( QIODevice::WriteOnly );
	layoutDescription.darkStar.save( &darkBuffer, "PNG" );
	jw.writeProperty( P_DARK_STAR, darkBuffer.data().toBase64().toStdString() );
	darkBuffer.close();

	jw.writeProperty( P_STARS_SHOWN, layoutDescription.starsShown );
	jw.writeProperty( P_STAR_AMOUNT, layoutDescription.starAmount );

	jw.writeObjectEnd();
}
