#ifndef LAYOUTDESCRIPTION_HPP
#define LAYOUTDESCRIPTION_HPP

#include <QPixmap>
#include "src/types.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/json.hpp"

enum LayoutDescriptionType {
	Model,
	Stars,
	TextOnly,
	Unknown
};

struct LineDescription {
	LayoutDescriptionType type;
	string text;
	ubyte starMask;
	int offset;
	// The below is only used in memory reading.
	// ubyte highlightStarMask;
	// ubyte highlightOffset;
};

struct LayoutDescription {
	std::vector<LineDescription> courseDescription;
	std::vector<LineDescription> secretDescription;
	string starAmount;
	int starsShown;
	QPixmap goldStar;
	QPixmap darkStar;

	static fs::path pathForHack( const string &hackId );
	inline static bool exists( const string &hackId ) {
		return fs::existsSafe( pathForHack( hackId ) );
	}
};

namespace JsonSerializer {
	template<> LayoutDescription parse<LayoutDescription>( const Json &json );
	template<> void serialize<LayoutDescription>( JsonWriter &jw, const LayoutDescription &layoutDescription );
}

#endif // LAYOUTDESCRIPTION_HPP
