#include "src/rhdc/ui/star-display-widget.hpp"

#include "ui_star-display-widget.h"

#include <QFileInfo>
#include <QFile>
#include <QLabel>
#include <QHBoxLayout>
#include <fstream>
#include "src/ui/util.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/file-controller.hpp"
#include "src/ui/now-playing-window.hpp"

StarDisplayWidget::StarDisplayWidget(
	QWidget *parent,
	const string &romPath,
	const LayoutDescription &layout
) :
	QWidget( parent ),
	m_ui( new Ui::StarDisplayWidget ),
	m_romPath( romPath ),
	m_layoutDescription( layout )
{
	m_ui->setupUi( this );

	const string saveFilePath = RetroArch::getSaveFilePath( m_romPath ).u8string();
	if( FileController::loadRhdcSettings().checkAllSaveSlots ) {
		QFileInfo checkInfo( saveFilePath.c_str() );

		if( !checkInfo.exists() || !checkInfo.isReadable() ) {
			// The save file hasn't been created yet (most likely).
			m_ui->tabWidget->setCurrentIndex( 0 );
		} else {
			std::ifstream inSave( fs::path( saveFilePath.c_str() ).u8string() );
			SM64::SaveFile saveFile = SM64::SaveFile::read( inSave );
			inSave.close();

			int slotIndex = 0;
			int highestStars = 0;
			for( int i = 0; i < 4; i++ ) {
				SM64::SaveSlot slot = saveFile.slot( i );

				if( slot.countStars() > highestStars ) {
					highestStars = slot.countStars();
					slotIndex = i;
				}
			}

			m_ui->tabWidget->setCurrentIndex( slotIndex );
		}
	} else {
		m_ui->tabWidget->setCurrentIndex( 0 );
	}

	if( !fs::existsSafe( saveFilePath ) ) {
		QFile saveFile( saveFilePath.c_str() );
		saveFile.open( QFile::WriteOnly | QFile::Truncate );

		QByteArray zeroBuffer;
		zeroBuffer.fill( '\0', 296960 );

		saveFile.write( zeroBuffer );
		saveFile.flush();
	}

	m_watcher.addPath( saveFilePath.c_str() );
	QObject::connect( &m_watcher, SIGNAL( fileChanged(QString) ), this, SLOT( fileChangedSignal(QString) ) );

	fileChangedSignal( saveFilePath.c_str() );
}

StarDisplayWidget::~StarDisplayWidget() {
	delete m_ui;
}

void StarDisplayWidget::fileChangedSignal( const QString changedFilePath ) {

	// File could be deleted, make sure it exists.
	QFileInfo checkInfo( changedFilePath );

	SM64::SaveFile saveFile;
	if( !checkInfo.exists() || !checkInfo.isReadable() ) {
		// This is required to show an empty display.
		saveFile = SM64::SaveFile();
	} else {
		std::ifstream inSave( fs::path( changedFilePath.toStdString().c_str() ).u8string() );
		saveFile = SM64::SaveFile::read( inSave );
		inSave.close();
	}

	QVBoxLayout* layoutCourses[4] { m_ui->vLayoutCoursesA, m_ui->vLayoutCoursesB, m_ui->vLayoutCoursesC, m_ui->vLayoutCoursesD };
	QVBoxLayout* layoutSecrets[4] { m_ui->vLayoutSecretsA, m_ui->vLayoutSecretsB, m_ui->vLayoutSecretsC, m_ui->vLayoutSecretsD };

	for( int i = 0; i < 4; i++ ) {
		UiUtil::clearLayout( layoutCourses[i] );
		UiUtil::clearLayout( layoutSecrets[i] );

		SM64::SaveSlot slot = saveFile.slot( i );

		for( auto x : m_layoutDescription.courseDescription ) {
			addLineDescription( layoutCourses[i], x, slot );
		}

		for( auto x : m_layoutDescription.secretDescription ) {
			addLineDescription( layoutSecrets[i], x, slot );
		}
	}
}

void StarDisplayWidget::addLineDescription( QVBoxLayout *layout, LineDescription &lineDescription, const SM64::SaveSlot &slot ) {

	switch( lineDescription.type ) {
		case Model: {
			upgradeLayoutFormat( layout, lineDescription, slot );
			break;
		}
		case Stars: {
			addStarLine( layout, lineDescription, slot );
			break;
		}
		case TextOnly: {
			addTextLine( layout, lineDescription );
			break;
		}
		case Unknown: {
			RhdcApi::logApiError( "Invalid layout property found." );
			break;
		}
	}
}

void StarDisplayWidget::upgradeLayoutFormat( QVBoxLayout *layout, LineDescription &lineDescription, const SM64::SaveSlot &slot ) {
	if( lineDescription.offset == 0 && lineDescription.starMask == 0 ) {
		lineDescription.type = TextOnly;
		addLineDescription( layout, lineDescription, slot );
	} else {
		lineDescription.type = Stars;
		lineDescription.starMask = ( lineDescription.starMask >> 1 | ( 1 << 7 ) );
		lineDescription.offset += 8;
		addLineDescription( layout, lineDescription, slot );
	}
}

void StarDisplayWidget::addTextLine( QVBoxLayout *layout, const LineDescription &lineDescription ) {
	QHBoxLayout* hboxLayout = new QHBoxLayout();
	hboxLayout->addStretch();
	QLabel* textLabel = new QLabel( lineDescription.text.c_str() );
	hboxLayout->addWidget( textLabel );
	hboxLayout->addStretch();

	layout->addLayout( hboxLayout );
}

static inline bool isStarBitUsed( int n, ubyte starMask ) {
	return ( starMask & ( 1 << n ) );
}

static inline bool isStarBitSet( ubyte c, int n ) {
	return ( c & ( 1 << n ) );
}

void StarDisplayWidget::addStarLine( QVBoxLayout *layout, const LineDescription &lineDescription, const SM64::SaveSlot &slot ) {

	QHBoxLayout* hboxLayout = new QHBoxLayout();
	QLabel* starLabel = new QLabel( lineDescription.text.c_str() );
	hboxLayout->addWidget( starLabel );

	// Special case for castle stars.
	if( lineDescription.offset == 8 ) {
		for ( int i = 0; i < m_layoutDescription.starsShown; i++ ) {
			if( !isStarBitUsed( i, lineDescription.starMask ) ) {
				continue;
			}

			QLabel* starImage = new QLabel();
			if( isStarBitSet( slot.castleStars, i ) ) {
				starImage->setPixmap( m_layoutDescription.goldStar );
			} else {
				starImage->setPixmap( m_layoutDescription.darkStar );
			}
			hboxLayout->addWidget( starImage );
		}
	} else {
		for( int i = 0; i < m_layoutDescription.starsShown; i++ ) {
			if( !isStarBitUsed( i, lineDescription.starMask ) ) {
				continue;
			}

			QLabel* starImage = new QLabel();
			if( isStarBitSet( slot.starFlags[lineDescription.offset - 0x0C], i ) ) {
				starImage->setPixmap( m_layoutDescription.goldStar );
			} else {
				starImage->setPixmap( m_layoutDescription.darkStar );
			}
			hboxLayout->addWidget( starImage );
		}
	}

	hboxLayout->addStretch();

	layout->addLayout( hboxLayout );
}
