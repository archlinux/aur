#include "src/rhdc/ui/rhdc-hack-list-view.hpp"

#include <QScrollBar>
#include <algorithm>
#include "src/core/file-controller.hpp"
#include "src/core/qthread.hpp"
#include "src/db/data-provider.hpp"

static inline double getDifficulty( const RhdcHackExt &hack ) {
	const double difficulty = (hack.progress.difficulty > 0) ? (double)hack.progress.difficulty : hack.info.avgDifficulty;
	return (hack.info.category == "Kaizo") ? difficulty + 10.0 : difficulty;
}

static inline double getRating( const RhdcHackExt &hack ) {
	return (hack.progress.rating > 0) ? (double)hack.progress.rating : hack.info.avgRating;
}

static bool compareName( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return QString::compare( a->hack().info.name.c_str() , b->hack().info.name.c_str(), Qt::CaseInsensitive ) < 0;
}

static bool comparePopularity( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return a->hack().info.downloads < b->hack().info.downloads;
}

static bool compareRating( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return getRating( a->hack() ) < getRating( b->hack() );
}

static bool compareDifficulty( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return getDifficulty( a->hack() ) < getDifficulty( b->hack() );
}

static bool compareLastPlayed( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return a->hack().lastPlayed < b->hack().lastPlayed;
}

static bool comparePlayTime( const RhdcHackWidget *a, const RhdcHackWidget *b ) {
	return a->hack().playTime < b->hack().playTime;
}

static bool (*s_hackComparators[])(const RhdcHackWidget*,const RhdcHackWidget*) = {
	compareName,
	comparePopularity,
	compareRating,
	compareDifficulty,
	compareLastPlayed,
	comparePlayTime
};

RhdcHackRenderer::RhdcHackRenderer( QObject *parent ) : QStyledItemDelegate( parent ) {}
RhdcHackRenderer::~RhdcHackRenderer() {}

QWidget *RhdcHackRenderer::createEditor( QWidget *parent, const QStyleOptionViewItem&, const QModelIndex &index ) const {
	const RhdcHackListView *view = dynamic_cast<const RhdcHackListView*>( this->parent() );
	const RhdcHackWidget *widget = static_cast<const RhdcHackWidget*>( index.internalPointer() );

	if( widget == nullptr ) return new QWidget();
	QWidget *activeWidget = widget->clone( parent, true );
	activeWidget->setFixedWidth( view->width() - view->verticalScrollBar()->width() - 6 );
	return activeWidget;
}

void RhdcHackRenderer::paint( QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index ) const {
	const RhdcHackListView *view = static_cast<const RhdcHackListView*>( parent() );
	RhdcHackWidget *widget = static_cast<RhdcHackWidget*>( index.internalPointer() );
	if( widget == nullptr ) return;

	QStyleOptionViewItem preparedOption = option;
	initStyleOption( &preparedOption, index );

	const bool selected = (view->currentIndex() == index);
	if( selected ) {
		widget = widget->clone( nullptr, true );
	}

	widget->setFixedWidth( view->width() - view->verticalScrollBar()->width() - 6 );
	widget->render( painter,view->mapTo( view->window(), view->contentsRect().topLeft() + preparedOption.rect.topLeft() ) );

	if( selected ) widget->deleteLater();
}

QSize RhdcHackRenderer::sizeHint( const QStyleOptionViewItem&, const QModelIndex& ) const {
	const RhdcHackListView *view = dynamic_cast<const RhdcHackListView*>( parent() );
	if( view->width() < 550 ) {
		return QSize( 550, 129 );
	} else {
		return QSize( view->width(), 129 );
	}
}

RhdcHackListView::RhdcHackListView( QWidget *parent ) : QListView( parent ) {
	setModel( new RhdcHackListModel( this ) );
	setUniformItemSizes( true );
	setFlow( QListView::TopToBottom );
	setLayoutMode( QListView::Batched );
	setBatchSize( 10 );
	setItemDelegate( new RhdcHackRenderer( this ) );
	setEditTriggers( QAbstractItemView::CurrentChanged );

	connect( selectionModel(), SIGNAL( currentChanged(const QModelIndex&,const QModelIndex&) ), this, SLOT( modelIndexChanged(const QModelIndex&,const QModelIndex&) ) );
}

RhdcHackListView::~RhdcHackListView() {
	itemDelegate()->deleteLater();
	model()->deleteLater();
}

void RhdcHackListView::modelIndexChanged( const QModelIndex &index, const QModelIndex& ) {
	if( index.isValid() && index.internalPointer() ) {
		emit selectedHackChanged( &static_cast<const RhdcHackWidget*>( index.internalPointer() )->hack() );
	} else {
		emit selectedHackChanged( nullptr );
	}
}

void RhdcHackListView::focusInEvent( QFocusEvent *event ) {
	if( currentIndex().isValid() ) {
		edit( currentIndex() );
	}
	QListView::focusInEvent( event );
}

void RhdcHackListView::setPlaylist( const string &playlist ) {
	const RhdcHackExt *selectedHack = currentHack();
	const string selectedHackId = selectedHack ? selectedHack->info.hackId : "";

	scrollToTop();
	static_cast<RhdcHackListModel*>( model() )->setPlaylist( playlist );

	selectHack( selectedHackId );
}

void RhdcHackListView::reloadAllHacks() {
	const RhdcHackExt *selectedHack = currentHack();
	const string selectedHackId = selectedHack ? selectedHack->info.hackId : "";
	const int scrollY = verticalScrollBar()->value();
	static_cast<RhdcHackListModel*>( model() )->reloadAll();
	selectHack( selectedHackId );
	verticalScrollBar()->setRange( 0, model()->rowCount( QModelIndex() ) * 129 );
	verticalScrollBar()->setValue( scrollY );

	//FIXME: Dumb hack. Need to figure out what's causing the scrolling to reset in some cases
	QtThread::safeAsync( [this,scrollY](){
		verticalScrollBar()->setRange( 0, this->model()->rowCount( QModelIndex() ) * 129 );
		this->verticalScrollBar()->setValue( scrollY );
	});
}

void RhdcHackListView::reloadHack( const string &hackId ) {
	const RhdcHackExt *selectedHack = currentHack();
	const string selectedHackId = selectedHack ? selectedHack->info.hackId : "";
	static_cast<RhdcHackListModel*>( model() )->reloadOne( hackId );
	if( !selectedHackId.empty() ) selectHack( selectedHackId );
}

void RhdcHackListView::setSortOrder( RhdcSorting sortBy, bool ascending ) {
	const RhdcHackExt *selectedHack = currentHack();
	const string selectedHackId = selectedHack ? selectedHack->info.hackId : "";
	const int scrollY = verticalScrollBar()->value();

	static_cast<RhdcHackListModel*>( model() )->setSortOrder( sortBy, ascending );

	selectHack( selectedHackId );
	verticalScrollBar()->setValue( scrollY );
}

const RhdcHackExt *RhdcHackListView::currentHack() const {
	const QModelIndex i = currentIndex();
	if( i.isValid() && i.internalPointer() ) {
		return &static_cast<const RhdcHackWidget*>( i.internalPointer() )->hack();
	}
	return nullptr;
}

void RhdcHackListView::selectHack( const string &hackId ) {
	const QModelIndex index = static_cast<RhdcHackListModel*>( model() )->findHack( hackId );
	selectionModel()->setCurrentIndex( index, QItemSelectionModel::ClearAndSelect );
	if( index.isValid() ) scrollTo( index, QAbstractItemView::EnsureVisible );
	emit selectedHackChanged( currentHack() );
}

RhdcHackListModel::RhdcHackListModel( QObject *parent ) : QAbstractItemModel( parent ) {
	const RhdcUiState &uiState = FileController::loadUiState().rhdcList;
	m_sortBy = uiState.sortBy;
	m_sortAsc = uiState.sortAsc;
	m_playlist = uiState.playlist;
}

RhdcHackListModel::~RhdcHackListModel() {}

void RhdcHackListModel::reloadOne( const string &hackId ) {
	const auto row = m_indexMap.find( hackId );
	if( row == m_indexMap.end() || row->second >= (int)m_hacks.size() ) return;

	const QModelIndex hackIndex = createIndex( row->second, 0, (void*)m_hacks[row->second] );
	emit dataChanged( hackIndex, hackIndex );
}

void RhdcHackListModel::setPlaylist( const string &playlist ) {
	if( m_playlist == playlist ) return;
	m_playlist = playlist;
	reloadAll();
}

void RhdcHackListModel::reloadAll() {
	beginResetModel();

	for( RhdcHackWidget *hack : m_hacks ) delete hack;
	m_hacks.clear();

	const std::vector<RhdcHackExt> hacks = m_playlist.empty() ? DataProvider::fetchExtRhdcHacks() : DataProvider::fetchExtRhdcHacksInList( m_playlist );
	m_hacks.reserve( hacks.size() );
	for( const RhdcHackExt &hack : hacks ) {
		RhdcHackWidget *hackWidget = new RhdcHackWidget( nullptr, hack );
		m_hacks.push_back( hackWidget );
	}

	doSort();
	endResetModel();
}

QVariant RhdcHackListModel::data( const QModelIndex&, int ) const {
	return QVariant();
}

void RhdcHackListModel::doSort() {
	m_indexMap.clear();
	if( m_sortAsc ) {
		std::sort( m_hacks.begin(), m_hacks.end(), s_hackComparators[(int)m_sortBy] );
	} else {
		std::sort( m_hacks.rbegin(), m_hacks.rend(), s_hackComparators[(int)m_sortBy] );
	}

	int i = 0;
	for( const RhdcHackWidget *widget : m_hacks ) {
		m_indexMap[widget->hack().info.hackId] = i++;
	}
}

QModelIndex RhdcHackListModel::findHack( const string &hackId ) const {
	const auto row = m_indexMap.find( hackId );
	if( row == m_indexMap.end() || row->second >= (int)m_hacks.size() ) {
		return QModelIndex();
	}

	return createIndex( row->second, 0, (void*)m_hacks[row->second] );
}

Qt::ItemFlags RhdcHackListModel::flags( const QModelIndex &index ) const {
	if( !index.isValid() ) return Qt::NoItemFlags;
	return Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled | Qt::ItemNeverHasChildren;
}

QModelIndex RhdcHackListModel::index( int row, int column, const QModelIndex &parent ) const {
	if( column != 0 || parent.isValid() || row >= (int)m_hacks.size() ) return QModelIndex();
	return createIndex( row, 0, (void*)m_hacks[row] );
}

QModelIndex RhdcHackListModel::parent( const QModelIndex& ) const {
	return QModelIndex();
}

int RhdcHackListModel::rowCount( const QModelIndex &parent ) const {
	return parent.isValid() ? 0 : (int)m_hacks.size();
}

int RhdcHackListModel::columnCount( const QModelIndex& ) const {
	return 1;
}

void RhdcHackListModel::setSortOrder( RhdcSorting sortBy, bool ascending ) {
	m_sortBy = sortBy;
	m_sortAsc = ascending;
	beginResetModel();
	doSort();
	endResetModel();
}
