#ifndef STARDISPLAYWIDGET_HPP
#define STARDISPLAYWIDGET_HPP

#include <QWidget>
#include <QVBoxLayout>
#include <QFileSystemWatcher>
#include "src/core/numeric-string.hpp"
#include "src/rhdc/core/layoutdescription.hpp"
#include "src/rhdc/core/hack.hpp"
#include "src/core/sm64.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/core/rom.hpp"

namespace Ui {
	class StarDisplayWidget;
}

class StarDisplayWidget : public QWidget {
	Q_OBJECT

	private:
	Ui::StarDisplayWidget *m_ui;
	QFileSystemWatcher m_watcher;
	const string m_romPath;
	LayoutDescription m_layoutDescription;

	public:
	explicit StarDisplayWidget( QWidget *parent, const string &romPath, const LayoutDescription &layout );
	~StarDisplayWidget();

	private:
	void addLineDescription( QVBoxLayout *layout, LineDescription &lineDescription, const SM64::SaveSlot &slot );
	void upgradeLayoutFormat( QVBoxLayout *layout, LineDescription &lineDescription, const SM64::SaveSlot &slot );
	void addTextLine( QVBoxLayout *layout, const LineDescription &lineDescription );
	void addStarLine( QVBoxLayout *layout, const LineDescription &lineDescription, const SM64::SaveSlot &slot );

	private slots:
	void fileChangedSignal( const QString changedFilePath );
};

#endif // STARDISPLAYWIDGET_HPP
