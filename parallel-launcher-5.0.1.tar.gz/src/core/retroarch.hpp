#ifndef SRC_CORE_RETROARCH_HPP_
#define SRC_CORE_RETROARCH_HPP_

#include "src/types.hpp"
#include "src/core/controller.hpp"
#include "src/core/rom.hpp"
#include "src/polyfill/process.hpp"

namespace RetroArch {

	extern ubyte resolveUpscaling(
		ParallelUpscaling requestedUpscaling,
		ubyte windowScale
	) noexcept;

	extern AsyncProcess launchRom(
		fs::path romPath,
		const AppSettings &settings,
		const std::vector<PlayerController> &players,
		const RomInfo &romInfo,
		bool bindSavestate,
		GfxPlugin *plugin = nullptr
	);

	extern fs::path getSaveFilePath( const fs::path &romPath );

	extern bool isRetroArchInstalled();
	extern bool isEmulatorCoreInstalled( EmulatorCore core );

	extern fs::path getBasePath();
	extern fs::path getCorePath();
	extern fs::path getConfigPath();
#ifndef __linux__
	extern fs::path getExePath();
#endif

	extern bool resetConfig();
	extern void migrateSaves();

#ifdef __APPLE__
	extern void installAssets();
#endif

}

#endif /* SRC_CORE_RETROARCH_HPP_ */
