#include "src/ui/direct-play.hpp"

#include <QCoreApplication>
#include <QMessageBox>
#include <cstdlib>
#include "src/polyfill/sha1.hpp"
#include "src/ui/direct-play-window.hpp"
#include "src/ui/main-window.hpp"
#include "src/ui/play.hpp"
#include "src/core/updates.hpp"
#include "src/core/bps.hpp"
#include "src/db/data-provider.hpp"

static inline bool hasBpsExtension( const fs::path &path ) {
	const string extension = path.extension().u8string();
	return (
		extension.length() == 4 &&
		extension[0] == '.' &&
		( extension[1] == 'b' || extension[1] == 'B' ) &&
		( extension[2] == 'p' || extension[2] == 'P' ) &&
		( extension[3] == 's' || extension[3] == 'S' )
	);
}

static void playRom( const RomFile &romFile, const RomInfo &romInfo ) {
	if( !Game::play( romFile, romInfo, false, [](int64 runtimeMs) {
		RetroUpdater::checkForUpdates( true, runtimeMs < 2000, false );
		std::exit( 0 );
	})) std::exit( 1 );
}

static int runWithoutRom( QApplication &app ) {
	RetroUpdater::checkForUpdates( false, false, false );
	QGuiApplication::setQuitOnLastWindowClosed( false );
	MainWindow mainWindow;
	mainWindow.show();
	return app.exec();
}

int DirectPlay::start( QApplication &app, fs::path romPath ) {
	if( !fs::existsSafe( romPath ) ) {
		return runWithoutRom( app );
	}

	if( hasBpsExtension( romPath ) ) {
		fs::path patchedRomPath;
		Bps::BpsApplyError patchResult = Bps::tryApplyBps( romPath, patchedRomPath );
		switch( patchResult ) {
			case Bps::BpsApplyError::None:
				romPath = patchedRomPath;
				break;
			case Bps::BpsApplyError::InvalidBps:
				QMessageBox::critical(
					nullptr,
					QCoreApplication::translate( "DirectPlay", "Patch Failed" ),
					QCoreApplication::translate( "DirectPlay", "Failed to patch ROM. The .bps patch appears to be invalid." )
				);
				return runWithoutRom( app );
			case Bps::BpsApplyError::PatchFailed:
				QMessageBox::critical(
					nullptr,
					QCoreApplication::translate( "DirectPlay", "Patch Failed" ),
					QCoreApplication::translate( "DirectPlay", "Failed to patch ROM. The base ROM does not match what the patch expects.." )
				);
				return runWithoutRom( app );
			case Bps::BpsApplyError::NoBaseRom:
				QMessageBox::critical(
					nullptr,
					QCoreApplication::translate( "DirectPlay", "Patch Failed" ),
					QCoreApplication::translate( "DirectPlay", "Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher." )
				);
				return runWithoutRom( app );
			case Bps::BpsApplyError::WriteError:
				QMessageBox::critical(
					nullptr,
					QCoreApplication::translate( "DirectPlay", "Patch Failed" ),
					QCoreApplication::translate( "DirectPlay", "Failed to patch ROM. An error occurred while writing the patched ROM to disk." )
				);
				return runWithoutRom( app );
		}
	}

	RomInfo romInfo;
	RomFile romFile;
	if( DataProvider::tryFetchRomByPath( romPath, false, &romInfo, &romFile ) ) {
		playRom( romFile, romInfo );
		return app.exec();
	}

	romFile = RomFile{
		romPath,
		RomUtil::getLastModified( romPath ),
		Sha1::compute( romPath ),
		true
	};


	if( DataProvider::tryFetchRomByHash( romFile.sha1, false, &romInfo ) ) {
		DataProvider::addRomFile( romFile );
		playRom( romFile, romInfo );
		return app.exec();
	}

	DirectPlayWindow mainWindow( romFile );
	QObject::connect( &mainWindow, &DirectPlayWindow::play, [&](){
		if( !RomUtil::coveredBySearchPath( romPath ) ) {
			DataProvider::addManualRomPath( romPath );
		}

		romInfo = mainWindow.getRomInfo();
		DataProvider::addRomInfo( romInfo );
		DataProvider::addRomFile( romFile );
		playRom( romFile, romInfo );
	});

	mainWindow.show();
	QRect geo = mainWindow.geometry();
	geo.setHeight( 0 );
	mainWindow.setGeometry( geo );
	return app.exec();
}
