package main

import (
	"time"
	"github.com/spf13/viper"
	"github.com/op/go-logging"
	"path/filepath"
	"bitbucket.org/zombiezen/cardcpx/natsort"
	"github.com/scorredoira/email"
	"os"
	"errors"
	"fmt"
	"crypto/tls"
	"net/smtp"
	"strconv"
)

func findPicture() []string {
	log := logging.MustGetLogger("log")

	types := []string{"*.jpg", "*.JPG", "*.ppm", "*.PPM"}
	pictureList := []string{}
	
	log.Debug("Pictures extensions: %v", types)
	log.Debug("Picture path: %s", viper.GetString("default.picturePath"))

	for _, ext := range types {
		someFiles, err := filepath.Glob(filepath.Join(viper.GetString("default.picturePath"), ext))
		log.Debug("glob: %v", filepath.Join(viper.GetString("default.picturePath"), ext))
		log.Debug("pictures files: %v", someFiles)
		if err != nil {
			log.Warning("Unable to find pictures: %v", err)
		}

		for _, onePicture := range someFiles {
			pictureList = append(pictureList, onePicture)
		}
	}

	natsort.Strings(pictureList)
	log.Debug("pictureList: %v", pictureList)

	return pictureList
}

func removePicture(pictureList *[]string) {
	for _, pic := range *pictureList {
		os.Remove(pic)
	}
}

func sendvia25(mail *email.Message, host string, auth smtp.Auth) error {
	port := strconv.Itoa(viper.GetInt("email.port"))

	if err := email.Send(host + ":" + port, auth, mail); err != nil {
		return errors.New(fmt.Sprintf("Unable to send email: %v", err))
	}

	return nil
}

func sendvia587(mail *email.Message, host string, auth smtp.Auth) {
	sendvia25(mail, host, auth)
}

func sendvial465(mail *email.Message, host string, auth smtp.Auth) error {
	log := logging.MustGetLogger("log")

	tlsconfig := &tls.Config{
		InsecureSkipVerify: true,
		ServerName: viper.GetString("email.smtp"),
	}

	conn, err := tls.Dial("tcp", host + ":465", tlsconfig)
	if err != nil {
		return errors.New(fmt.Sprintf("Unable dial with server: \"%s:465\". Error: %v", host, err))
	}

	client, err := smtp.NewClient(conn, host)
	if err != nil {
		return errors.New(fmt.Sprintf("Unable to create a client to send an email. Error: %v", err))
	}

	if err := client.Auth(auth); err != nil {
		return errors.New(fmt.Sprintf("Unable to identify on server. Auth: %v. Error: %v", auth, err))
	}

	if err := client.Mail(mail.From); err != nil {
		return errors.New(fmt.Sprintf("Unable to define emmiter: %v", err))
	}

	for _, addr := range mail.To {
		log.Debug("From: %s", addr)
		if err := client.Rcpt(addr); err != nil {
			return errors.New(fmt.Sprintf("Unable to defined the recepter: %s. Error: %v", addr, err))
		}
	}

	data, err := client.Data()
	if err != nil {
		return errors.New(fmt.Sprintf("Unable to create buffer to write data: \"%v\"", err))
	}

	if _, err := data.Write(mail.Bytes()); err != nil {
		return errors.New("Unable to write data on server")
	}

	if err := data.Close(); err != nil {
		return errors.New("Unable to close buffer")
	}

	client.Quit()

	return nil
}

func sendEmail(pic *string) error {
	log := logging.MustGetLogger("log")

	mail := email.NewHTMLMessage("Détection d'un mouvement suspect", "")
	mail.From = viper.GetString("email.from")
	
	log.Debug("To: %v", viper.GetStringSlice("email.sendTo"))
	log.Debug("Number of recipients: %d", len(viper.GetStringSlice("email.sendTo")))
	
	mail.To = viper.GetStringSlice("email.sendTo")
	
	if err := mail.Attach(*pic); err != nil {
		return errors.New(fmt.Sprintf("Unable to attach %s: %v", *pic, err))
	}

	host := viper.GetString("email.smtp")
	log.Debug("Host: %s", host)
	
	username := viper.GetString("email.login")
	log.Debug("Username: %s", username)
	
	password := viper.GetString("email.password")
	log.Debug("Password: %s", password)

	auth := smtp.PlainAuth("", username, password, host)

	switch(viper.GetInt("email.port")) {
	case 25:
		log.Debug("Using 25 port number")
		sendvia25(mail, host, auth)
	case 587:
		log.Debug("Using 587 port number")
		sendvia587(mail, host, auth)
	case 465:
		log.Debug("Using 465 port number")
		sendvial465(mail, host, auth)
	default:
		log.Critical("\"%d\" is an unknown port to send email !", viper.GetInt("email.port"))
		os.Exit(1)
	}

	return nil
}

func startApp() {
	log := logging.MustGetLogger("log")

	log.Debug("Before starting to sleep. Waiting \"%ds\"", viper.GetInt("default.sleepBeforeStarting"))
	// Sleep before starting
	time.Sleep(time.Duration(viper.GetInt("default.sleepBeforeStarting")) * time.Second)
	log.Debug("After sleeping at the beginning")
	// Remove picture before starting
	pictureList := findPicture()
	removePicture(&pictureList)

	for {
		pictureList = findPicture()
		for _, pic := range pictureList {
			if err := sendEmail(&pic); err != nil {
				time.Sleep(20 * time.Second)
			} else {
				// remove picture
				removePicture(&[]string{pic})
			}
		}
		// wait before start another pictures search
		time.Sleep(time.Duration(viper.GetInt("default.timeToSleep")) * time.Second)
	}
}

func main() {
	// confPath := "cfg/"
	// confFilename := "mailmotion"
	// logFilename := "error.log"

	confPath := "/etc/mailmotion/"
	confFilename := "mailmotion"
	logFilename := "/var/log/mailmotion/error.log"

	fd := initLogging(&logFilename)
	defer fd.Close()

	loadConfig(&confPath, &confFilename)
	startApp()
}