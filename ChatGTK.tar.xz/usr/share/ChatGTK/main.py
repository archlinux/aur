#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("WebKit2", "4.0")
gi.require_version("AppIndicator3", "0.1")

from gi.repository import Gtk, WebKit2, AppIndicator3
import os

class ChatGPTTrayApp:
    def __init__(self):
        # 创建 AppIndicator 托盘图标
        self.indicator = AppIndicator3.Indicator.new(
            "chatgpt_indicator",
            os.path.abspath("/usr/share/ChatGTK/ChatGPT.svg"),
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS
        )
        self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        # 创建右键菜单
        self.menu = Gtk.Menu()

        show_item = Gtk.MenuItem(label="Show window")
        show_item.connect("activate", self.show_window)
        self.menu.append(show_item)

        quit_item = Gtk.MenuItem(label="Quit")
        quit_item.connect("activate", self.quit)
        self.menu.append(quit_item)

        self.menu.show_all()
        self.indicator.set_menu(self.menu)

        # 创建主窗口与 WebView
        self.create_window()

    def create_window(self):
        self.window = Gtk.Window(title="ChatGPT")
        self.window.set_default_size(1000, 700)
        self.window.connect("delete-event", self.on_window_close)

        scrolled_window = Gtk.ScrolledWindow()

        # 使用本地目录保存 cookie、缓存等数据
        data_dir = os.path.expanduser("~/.local/share/ChatGTK")
        os.makedirs(data_dir, exist_ok=True)

        data_manager = WebKit2.WebsiteDataManager(
            base_data_directory=data_dir,
            base_cache_directory=os.path.join(data_dir, "cache")
        )
        context = WebKit2.WebContext.new_with_website_data_manager(data_manager)

        self.webview = WebKit2.WebView.new_with_context(context)
        self.webview.load_uri("https://chatgpt.com")

        scrolled_window.add(self.webview)
        self.window.add(scrolled_window)
        self.window.show_all()

    def on_window_close(self, *args):
        self.window.hide()
        return True  # 阻止默认关闭行为

    def show_window(self, *args):
        self.window.show_all()
        self.window.present()

    def quit(self, *args):
        Gtk.main_quit()

def main():
    ChatGPTTrayApp()
    Gtk.main()

if __name__ == "__main__":
    main()
