#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("WebKit2", "4.1")
gi.require_version("AppIndicator3", "0.1")

from gi.repository import Gtk, WebKit2, AppIndicator3, GLib
import os

class ChatGPTTrayApp:
    def __init__(self):
        # 创建 AppIndicator 托盘图标
        self.indicator = AppIndicator3.Indicator.new(
            "chatgpt_indicator",
            os.path.abspath("/usr/share/ChatGTK/ChatGPT.svg"),
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS
        )
        self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        # 创建托盘菜单
        self.menu = Gtk.Menu()

        show_item = Gtk.MenuItem(label="Show Window")
        show_item.connect("activate", self.show_window)
        self.menu.append(show_item)

        quit_item = Gtk.MenuItem(label="Quit ChatGTK")
        quit_item.connect("activate", self.quit)
        self.menu.append(quit_item)

        self.menu.show_all()
        self.indicator.set_menu(self.menu)

        # 创建窗口
        self.create_window()

    def get_cookie_path(self):
        app_name = "ChatGTK"
        xdg_data_home = GLib.getenv("XDG_DATA_HOME") or os.path.join(GLib.get_home_dir(), ".local", "share")
        cookie_dir = os.path.join(xdg_data_home, app_name)
        os.makedirs(cookie_dir, exist_ok=True)
        return os.path.join(cookie_dir, "cookies.sqlite")

    def create_window(self):
        self.window = Gtk.Window(title="ChatGPT")
        self.window.set_default_size(1000, 700)
        self.window.connect("delete-event", self.on_window_close)

        scrolled_window = Gtk.ScrolledWindow()

        # 设置 cookie 持久化路径
        cookie_path = self.get_cookie_path()
        web_context = WebKit2.WebContext.get_default()
        cookie_manager = web_context.get_cookie_manager()
        cookie_manager.set_persistent_storage(cookie_path, WebKit2.CookiePersistentStorage.SQLITE)

        # 创建 WebView 并加载 ChatGPT
        self.webview = WebKit2.WebView.new_with_context(web_context)
        self.webview.load_uri("https://chatgpt.com")

        scrolled_window.add(self.webview)
        self.window.add(scrolled_window)
        self.window.show_all()

    def on_window_close(self, *args):
        self.window.hide()
        return True

    def show_window(self, *args):
        self.window.show_all()
        self.window.present()

    def quit(self, *args):
        Gtk.main_quit()

def main():
    ChatGPTTrayApp()
    Gtk.main()

if __name__ == "__main__":
    main()
