#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("WebKit2", "4.1")
gi.require_version("AppIndicator3", "0.1")

from gi.repository import Gtk, WebKit2, AppIndicator3, GLib
import dbus
import dbus.service
import dbus.mainloop.glib
import os

BUS_NAME = 'org.NekoLOvO.ChatGTK'
OBJECT_PATH = '/org/NekoLOvO/ChatGTK'

class ChatGTKService(dbus.service.Object):
    def __init__(self, app):
        self.app = app
        bus_name = dbus.service.BusName(BUS_NAME, bus=dbus.SessionBus())
        super().__init__(bus_name, OBJECT_PATH)

    @dbus.service.method(BUS_NAME)
    def ShowWindow(self):
        GLib.idle_add(self.app.show_window)

    @dbus.service.method(BUS_NAME)
    def HideWindow(self):
        GLib.idle_add(self.app.hide_window)

    @dbus.service.method(BUS_NAME)
    def ToggleWindow(self):
        GLib.idle_add(self.app.toggle_window)

    @dbus.service.method(BUS_NAME)
    def QuitApp(self):
        GLib.idle_add(Gtk.main_quit)

class ChatGTKApp:
    def __init__(self):
        self.create_tray()
        self.create_window()

    def create_tray(self):
        self.indicator = AppIndicator3.Indicator.new(
            "chatgpt_indicator",
            os.path.abspath("/usr/share/icons/hicolor/64x64/apps/ChatGTK.svg"),
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS
        )
        self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        self.menu = Gtk.Menu()

        toggle_item = Gtk.MenuItem(label="Show/Hide Window")
        toggle_item.connect("activate", self.toggle_window)
        self.menu.append(toggle_item)

        quit_item = Gtk.MenuItem(label="Quit ChatGTK")
        quit_item.connect("activate", self.quit)
        self.menu.append(quit_item)

        self.menu.show_all()
        self.indicator.set_menu(self.menu)

    def get_cookie_path(self):
        app_name = "ChatGTK"
        xdg_data_home = GLib.getenv("XDG_DATA_HOME") or os.path.join(GLib.get_home_dir(), ".local", "share")
        cookie_dir = os.path.join(xdg_data_home, app_name)
        os.makedirs(cookie_dir, exist_ok=True)
        return os.path.join(cookie_dir, "cookies.sqlite")

    def create_window(self):
        self.window = Gtk.Window(title="ChatGPT")
        self.window.set_default_size(1000, 700)
        self.window.connect("delete-event", self.on_window_close)

        scrolled_window = Gtk.ScrolledWindow()

        cookie_path = self.get_cookie_path()
        web_context = WebKit2.WebContext.get_default()
        cookie_manager = web_context.get_cookie_manager()
        cookie_manager.set_persistent_storage(cookie_path, WebKit2.CookiePersistentStorage.SQLITE)

        self.webview = WebKit2.WebView.new_with_context(web_context)
        self.webview.load_uri("https://chatgpt.com")

        scrolled_window.add(self.webview)
        self.window.add(scrolled_window)
        self.window.show_all()

    def on_window_close(self, *args):
        self.window.hide()
        return True

    def show_window(self, *args):
        self.window.show_all()
        self.window.present()

    def hide_window(self, *args):
        self.window.hide()

    def toggle_window(self, *args):
        if self.window.get_visible():
            self.hide_window()
        else:
            self.show_window()

    def quit(self, *args):
        Gtk.main_quit()

def main():
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    session_bus = dbus.SessionBus()

    try:
        proxy = session_bus.get_object(BUS_NAME, OBJECT_PATH)
        iface = dbus.Interface(proxy, BUS_NAME)
        iface.ToggleWindow()
        return
    except dbus.exceptions.DBusException:
        pass

    app = ChatGTKApp()
    service = ChatGTKService(app)
    Gtk.main()

if __name__ == "__main__":
    main()

