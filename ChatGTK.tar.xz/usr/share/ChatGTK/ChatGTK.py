#!/usr/bin/env python3
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("WebKit2", "4.0")
gi.require_version("AppIndicator3", "0.1")

from gi.repository import Gtk, WebKit2, AppIndicator3

import os

class ChatGPTTrayApp:
    def __init__(self):

        self.indicator = AppIndicator3.Indicator.new(
            "chatgpt_indicator",
            os.path.abspath("/usr/share/ChatGTK/ChatGPT.svg"),
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS
        )

        self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        self.menu = Gtk.Menu()
        quit_item = Gtk.MenuItem(label="Quit")
        quit_item.connect("activate", self.quit)
        self.menu.append(quit_item)
        self.menu.show_all()

        self.indicator.set_menu(self.menu)

        self.create_window()

    def create_window(self):
        self.window = Gtk.Window(title="ChatGPT")
        self.window.set_default_size(1000, 700)
        self.window.connect("delete-event", self.on_window_close)

        scrolled_window = Gtk.ScrolledWindow()

        self.webview = WebKit2.WebView()
        self.webview.load_uri("https://chatgpt.com")
        scrolled_window.add(self.webview)
        self.window.add(scrolled_window)

        self.window.show_all()

    def on_window_close(self, *args):
        self.window.hide()
        return True

    def show_window(self):
        self.window.show_all()
        self.window.present()

    def quit(self, *args):
        Gtk.main_quit()

def main():
    ChatGPTTrayApp()
    Gtk.main()

if __name__ == "__main__":
    main()
