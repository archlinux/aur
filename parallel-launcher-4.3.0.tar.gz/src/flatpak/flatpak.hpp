#ifndef SRC_POLYFILL_LINUX_FLATPAK_HPP_
#define SRC_POLYFILL_LINUX_FLATPAK_HPP_

#include <functional>
#include <vector>
#include "src/types.hpp"

namespace Flatpak {

	enum class OperationType {
		Install,
		Update,
		Remove
	};

	enum class OperationResult {
		Success,
		Failure,
		Cancelled
	};

	struct AsyncCallbacks {
		std::function<void(int)> onReady;
		std::function<void(OperationResult)> onFinished;
		std::function<void(string,string,OperationType)> onOperationStart;
		std::function<void(void)> onOperationFinished;
		std::function<void(string,int)> onOperationProgress;
		std::function<void(string)> onOperationError;
		std::function<bool(void)> getConfirmation;
	};

	typedef std::function<void(void)> CancelFunc;

	extern bool hasInstallation();
	extern bool createInstallation();
	extern bool isRetroArchInstalled();

	extern CancelFunc installRetroArchAsync( const AsyncCallbacks &callbacks );
	extern CancelFunc updateRuntimes( const AsyncCallbacks &callbacks );
	extern CancelFunc updateAll( const AsyncCallbacks &callbacks );

}



#endif /* SRC_POLYFILL_LINUX_FLATPAK_HPP_ */
