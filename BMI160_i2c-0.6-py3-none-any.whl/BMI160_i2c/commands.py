# command definitions
START_FOC       = (0x03)
ACC_MODE_NORMAL = (0x11)
GYR_MODE_NORMAL = (0x15)
FIFO_FLUSH      = (0xB0)
INT_RESET       = (0xB1)
STEP_CNT_CLR    = (0xB2)
SOFT_RESET      = (0xB6)