#!/bin/sh

mkdir /usr/share/gnome-background-properties 2> /dev/null
cp usr/share/gnome-background-properties/elementary-backgrounds.xml /usr/share/gnome-background-properties/
