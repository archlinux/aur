#pragma once
#include <stdbool.h>

int cmd_load_check(const char *input);
bool cmd_load_exec(char *input, int code);
