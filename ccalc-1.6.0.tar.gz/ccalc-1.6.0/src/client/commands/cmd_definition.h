#pragma once
#include <stdbool.h>

int cmd_definition_check(const char *input);
bool cmd_definition_exec(char *input, int code);
