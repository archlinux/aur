# Bloonix agent daemon

## About Bloonix

For general information about Bloonix, questions, ratings or other things please visit our base repository:

* https://github.com/bloonix/bloonix
