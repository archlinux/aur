#!/bin/bash

serverDir=/etc/connective-http
classPathFolders=( "libs/" )
mainType=org.asf.connective.standalone.main.ConnectiveStandalone
credtoolLibs=()
credtoolTarget=""
jvmArguments="-Djava.net.preferIPv4Stack=true"

if [ -f "/etc/connective-http/config.props" ]; then
    source "/etc/connective-http/config.props"
fi
if ! test -w "$serverDir"; then
    1>&2 echo "No access to server directory ($serverDir), cannot start the Connective HTTP server."
    exit 1
fi

cd "$serverDir"
if [ ! -d credentials ]; then
    mkdir credentials
fi

libs=$(find /usr/lib/connective-http -maxdepth 1 -name '*.jar' -exec echo -n :{} \;)
for cpEntry in "${classPathFolders[@]}"; do
    if [ ! -d "$cpEntry" ]; then
        mkdir -p "$cpEntry" || exit 1
    fi
    libs=$libs:$(find "$cpEntry" -name '*.jar' -exec echo -n :{} \;)
done
libs=$libs:$(find /usr/lib/connective-http/libs/ -name '*.jar' -exec echo -n :{} \;)
libs=${libs:1}

authbind --deep java -cp "$libs" $jvmArguments "$mainType" "$@"
exit $?
