#!/bin/bash

serverDir=/etc/connective-http
classPathFolders=( "libs/" )
mainType=org.asf.connective.standalone.main.ConnectiveStandalone
credtoolLibs=()
credtoolTarget=""

if [ -f "/etc/connective-http/config.props" ]; then
    source "/etc/connective-http/config.props"
fi
if ! test -w "$serverDir"/credentials; then
   echo No access to server credentials.
   exit 1
fi

cd "$serverDir"
genAuthConf=false
if [ "$credtoolTarget" != "" ] && [ ! -f "$serverDir/.credtool.target" ]; then
    genAuthConf=true
    echo "$credtoolTarget" > "$serverDir/.credtool.target"
    for lib in "${credtoolLibs[@]}"; do
        echo "$lib" >> "$serverDir/.credtool.target"
    done
fi

connective-http credtool "$@"
exitcode=$?

if [ "$genAuthConf" == "true" ]; then
   rm "$serverDir/.credtool.target"
fi
exit $exitcode
