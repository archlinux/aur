#ifdef WITH_OPTS_PARSER
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ws/options.h>

const WsChar cFlag              = '-';
const WsChar cVersion[]         = "Version";
const WsChar cBuild[]           = "Build";
const WsChar cUsage[]           = "Usage:";
const WsChar cOptions[]         = "Options";
const WsChar cDefault[]         = "default";
const WsChar cRequireValue[]    = "Value required for option";
const WsChar cOptionUndefined[] = "Undefined option";

WsInt     process_argc;
WsChar ** process_argv;
WsChar *  process_name;


static WsOption * options;


static void
undefined_option(const WsChar * arg);


static void
require_value(const WsChar * arg);


static void
show_usage();

static void
show_version();

extern       WsVersion version;


void
ws_options_set(WsOption * rules, WsInt argc, WsChar ** argv)
{
    int    i;
    WsChar * key;
    WsChar * value;
    WsOption * r;

    options      = rules;
    process_argc = argc;
    process_argv = argv;

    process_name = process_argv[0];
    key = process_name;

    while(*key)
    {
        key++;
        if (*key == '/') process_name = ++key;
    }


    for (i=1; i<process_argc; i++)
    {
        if (*process_argv[i] != cFlag)
            return undefined_option(process_argv[i]);

        key   = &process_argv[i][1];
        value = NULL;

        r = rules;
        while (r->name)
        {
            if (r->name == *key)
            {
                if (r->type != NULL)
                {
                    if (strlen(key)>1) /* -c/etc/openarc/openarc.conf */
                        value = key+1;
                    else
                    {
                        i++;
                        if (i<process_argc) /* -c /etc/openarc/openarc.conf */
                        {
                            value = process_argv[i];
                            r->setup(key, value);
                            break;
                        }
                        else /* no pair value: arcd -c */
                            return require_value(key);
                    }
                }
                else
                {
                    r->setup(key, NULL);
                    break;
                }
            }
            r++;
        }
        if (r->name == 0)
        {
            printf("really?\n");
            return undefined_option(key);
        }
    }
}


void
ws_options_version(const WsChar * key, const WsChar * value)
{
    show_version();

    exit( (key) ? EXIT_SUCCESS : EXIT_FAILURE );
}


void
ws_options_help(const WsChar * key, const WsChar * value)
{
    show_version();
    show_usage();
    
    exit( (key) ? EXIT_SUCCESS : EXIT_FAILURE );
}


static void
require_value(const WsChar * arg)
{
    fprintf(stderr, "%s: %s '-%s'\n", process_name, cRequireValue, arg);

    exit(EXIT_FAILURE);
}


static void
undefined_option(const WsChar * arg)
{
    fprintf(stderr, "%s: %s '-%s'\n", process_name, cOptionUndefined, arg);

    exit(EXIT_FAILURE);
}


static void
show_usage()
{
    WsOption        * p = options;
    int         l, width = 0;

    printf("%s: %s [-", cUsage, process_name);
    /* Options */

    while (p->name)
    {
        if (p->type)
        {
            l = strlen(p->type);
            if (l>width) width = l;
            printf("] [-%c %s", p->name, p->type);
        }
        else
        {
            printf("%c", p->name);
        }
        p++;
    }
    printf("]\n\n");

    printf("%s:\n", cOptions);


    WsChar type[width + 1];
    memset(type, ' ', width);
    type[width]=0;

    p = options;

    while (p->name)
    {
        l = 0;
        printf("  -%c ", p->name);
        if (p->type)
        {
            printf("%s", p->type);
            l = strlen(p->type);
        }

        printf("%s : %s ", &type[l], p->help);

        if (p->value)
        {
            printf("(%s: %s)", cDefault, p->value);
        }

        printf("\n");

        p++;
    }
    printf("\n");

}


static void
show_version()
{
    printf("%s: %s %u.%u.%u %s %u\n", process_name,
                                    cVersion,
                                    version.major & 0xFFFF,
                                    version.minor & 0xFFFF,
                                    version.release & 0xFFFF,
                                    cBuild,
                                    version.build & 0xFFFF
    );

}

#endif
