#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <ws/upload.h>


WsUpload *
ws_upload_new ()
{
    WsUpload * self = calloc(1, sizeof(WsUpload));
    self->moved = false;
    return self;
}


void
ws_upload_generate_path(WsUpload * self, WsChar * root, WsSize size)
{
    int  l;
    char sym[] = "0123456789qwertyuiopasdfghjklzxcvbnm";
    char * p;

    l = strlen(root);

    ws_string_set_length(&self->path, l+size+1);
    ws_string_set(&self->path, root);

    if (root[l-1] != '/')
    {
        self->path[l-1] = '/';
        l++;
    }

    p = &self->path[ l ];

    l+=size;

    while (p - self->path < l)
    {
        *p = sym[ rand() % (36-1) ]; /* 36 = length(sym) */
        p++;
    }
}


WsBool
ws_upload_move(WsUpload * self, char * new_path)
{
    if (!self->moved)
    {
        if (rename(self->path, new_path)==0)
        {
            self->moved = true;
            return true;
        }
    }

    return false;
}


void
ws_upload_free ( WsUpload * self )
{
    if (self)
    {
        ws_string_free(self->key);
        ws_string_free(self->name);
        ws_string_free(self->path);
        ws_string_free(self->type);
        free(self);
        *((void**) &self)=NULL;
    }
}


