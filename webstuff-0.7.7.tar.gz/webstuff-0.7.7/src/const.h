#ifndef _WS_CONST_H_
#define _WS_CONST_H_

#define WS_SERVER_SOFTWARE "webstuff"

#define WS_OUT_BUFFER_SIZE 4096


#endif
