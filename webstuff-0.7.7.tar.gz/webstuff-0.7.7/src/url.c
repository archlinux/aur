#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ws/http.h>
#include <ws/request.h>
#include <ws/list.h>
#include <ws/url.h>
#include <ws/string.h>


WsHttpStatus
ws_url_handler_call(WsUrl * urls, WsRequest * request)
{
    WsString        url = ws_request_get_env(request, wsDocumentUri);
    WsUrl         * u   = urls;

    WsHttpStatus    s = wsHttpNotFound;
    WsString      * matches=NULL;

    WsSize          i;
    size_t          nmatch = 4;
    regmatch_t      pmatch[ nmatch ];



    if (!url) return wsHttpBadRequest;

    url++; /* skip first / */

    while (u && u->re)
    {
        if (! u->handler) continue;

        if (regexec((regex_t *)u->re, url, nmatch, pmatch, 0)==0)
        {
            matches = calloc(nmatch, sizeof(WsString));
            for(i = 0; i<nmatch; i++)
            {
                if(pmatch[i].rm_so != -1)
                {
                    ws_string_copy( &matches[i],
                                    &url[pmatch[i].rm_so],
                                    pmatch[i].rm_eo );
                }
                else
                    break;
            }
            request->matches = matches;

            u->handler(request);
            s=ws_get_response_status(request);
            for(i = 0; i<nmatch; i++)
            {
                if(matches[i])
                     ws_string_free(matches[i]);
                else
                     break;
            }
            free(matches);
            matches=NULL;
            break;
        }
        u++;
    }
    return s;
}


