#ifndef _WS_MODULE_FULL_H_
#define _WS_MODULE_FULL_H_


#include <ws/module.h>
#include "connector.h"
#include "request.h"


/* methods for internal webstuff usage ------------------------------------- */


void
ws_module_add_request(WsModule * self, WsRequest * request);


WsRequest *
ws_module_get_request(WsModule * self);


WsConnector *
ws_module_get_connector(WsModule * self);


WsUrl *
ws_module_get_urls(WsModule * self);


const WsChar *
ws_module_get_ip_header(WsModule * self);

#endif
