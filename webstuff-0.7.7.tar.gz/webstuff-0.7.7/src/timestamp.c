#include <string.h>
#include <stdlib.h>
 #include <stdio.h>  /* debug */

#include <ws/timestamp.h>
#include <ws/string.h>

static int
get_digit(char * p, int size)
{
    char buf[size+1];
    buf[size]=0;
    strncpy(buf, p, size);

    return atoi(buf);
}


void
ws_now(WsTimestamp * ts)
{
    time_t rawtime;
    time ( &rawtime );

    memcpy(ts, localtime ( &rawtime ), sizeof(WsTimestamp));
}

WsTimestamp *
ws_timestamp_from_ascii(WsTimestamp * ts, WsChar * string)
{
    /* Ascii time: Tue Sep 15 16:27:37 2015 +0200 */
    if (!string) return NULL;
    /* get length */
    WsSize s = strlen(string);
    /* bad ascii time */
    if (s<24) return NULL;
    /* prepare time structure */
    if (!ts) ts=calloc(1, sizeof(WsTimestamp));

    WsChar * p;

    const char months[][4] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };

    p = &string[ 19 ];
    if (*p==' ') p++;

    ts->tm_year = get_digit(p, 4) - 1900;


    for (ts->tm_mon=0; ts->tm_mon<11; ts->tm_mon++)
    {
        if (strncmp(months[ts->tm_mon], &string[4], 3)==0) break;
    }
    ts->tm_mday = get_digit(&string[8], 2);
    ts->tm_hour = get_digit(&string[11], 2);
    ts->tm_min  = get_digit(&string[14], 2);
    ts->tm_sec  = get_digit(&string[17], 2);

    mktime ( ts );

    return ts;
}


void
ws_timestamp_set_from_string(WsTimestamp * ts, WsChar * string)
{
    char * e;

    e = strchr(string, '-');

    /* get current timeinfo and modify it according to string */
    ts->tm_year = get_digit(string, (int)(e-string)) - 1900;
    ts->tm_mon  = get_digit(e+1, 2)- 1;
    ts->tm_mday = get_digit(e+4, 2);
    ts->tm_hour = get_digit(e+7, 2);
    ts->tm_min  = get_digit(e+10, 2);
    ts->tm_sec  = get_digit(e+13, 2);

    mktime ( ts );
}


void
ws_timestamp_set_string(WsTimestamp * ts, WsString * string)
{
    /* Length(YYYY-MM-DD HH:MM:SS)=19, for strftime we have to pass 20 because
     * of NULL-termination, that is added automatically 
     * by ws_string_set_length
     * */
    ws_string_set_length(string, 19); 
    strftime (*string, 20, "%F %T", ts);
}

void
ws_timestamp_add_seconds(WsTimestamp * ts, WsInt seconds)
{
    time_t tm = mktime(ts) + seconds;
    memcpy(ts, localtime (&tm), sizeof(WsTimestamp));
}
