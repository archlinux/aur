#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <stdio.h> /* debug */

#include <ws/timer.h>

#include "connector.h"

static void
_ws_connector_thread(WsConnector * self);

static void *
is_link_free (WsLink * link, void * argument, bool * stop);


static void *
is_link_offline (WsLink * link, void * argument, bool * stop);


WsConnector *
ws_connector_new()
{
    WsConnector * self = calloc(1, sizeof(WsConnector));

    ws_thread_init(WS_THREAD(self));
    ws_thread_set_name(WS_THREAD(self), "Connector");
    WS_THREAD(self)->execute = (WsThreadFunction) _ws_connector_thread;

    ws_mutex_init(&self->lock);

    self->socket  = ws_socket_new();
    self->links = ws_list_new(8);
    self->links->free_item = (WsListItemDestructor) ws_link_free;

    return self;
}



void
ws_connector_free(WsConnector * self)
{
    if (!self) return;

    ws_list_free(self->links);
    ws_socket_free(self->socket);
    ws_mutex_destroy(&self->lock);
    ws_thread_free(WS_THREAD(self));
}


WsStatus
ws_connector_set_socket( WsConnector  * self,
                         const WsChar * host,
                         const WsInt    port )
{
    WsStatus s = ws_socket_set_address(self->socket, host, port);

    if (s != wsSuccess)
    {
        stdlog->error( WS_THREAD(self),
                              "bad address",
                              ws_socket_get_last_error() );
    }

    return s;
}


void
ws_connector_cleanup(WsConnector * self)
{
    uint32_t i=0;
    WsLink * link;

    ws_mutex_lock(&self->lock);

    while((link = ws_list_find( self->links,
                                (WsListCompare) is_link_offline,
                                NULL,
                                &i )) != NULL)
    {
        ws_list_remove(self->links, i);
        stdlog->state( WS_THREAD(self),
                             "link down %s:%d (%s)",
                             ws_socket_get_host(link->socket),
                             ws_socket_get_port(link->socket),
                             ws_status_get_text(ws_link_get_status(link)) );
        ws_link_free(link);
        i++;
    }

    ws_mutex_unlock(&self->lock);
}


WsLink *
ws_connector_hold_link(WsConnector * self)
{
    WsLink * link;
    ws_mutex_lock(&self->lock);

    if (self->it >= ws_list_get_count(self->links))
    {
        self->it = 0;
    }

    link = ws_list_find( self->links,
                         (WsListCompare) is_link_free,
                         NULL,
                         &self->it );

    if (link) ws_link_set_hold(link, true);
    self->it++;

    ws_mutex_unlock(&self->lock);

    return link;

}


void
ws_connector_release_link(WsConnector * self, WsLink * link)
{
    ws_mutex_lock(&self->lock);
    ws_link_set_hold(link, false);
    ws_mutex_unlock(&self->lock);

}


/* static
 *************************************************************************** */
static void
_ws_connector_thread(WsConnector * self)
{
    WsSocket       * client;
    WsStatus         s;
    time_t            ts;
    int               wait = 0;
    WsLink * link;


    while (! ws_thread_is_stopped(WS_THREAD(self)))
    {
        /* connection */
        if (! ws_socket_is_open(self->socket))
        {
            if (wait && difftime(time(NULL), ts) < wait )
            {
                ws_sleep(300);
                continue;
            }

            s = ws_socket_listen(self->socket);

            time(&ts);
            if (s != wsSuccess)
            {
                stdlog->error( WS_THREAD(self),
                                     ws_status_get_text(s),
                                     ws_socket_get_last_error() );

                wait = 10;
                continue;
            }
            wait = 0;
            stdlog->state( WS_THREAD(self), "listen %s:%d",
                                 ws_socket_get_host(self->socket),
                                 ws_socket_get_port(self->socket) );
        }

        /* accepting */

        s = ws_socket_accept( self->socket, &client );

        if (s != wsSuccess)
        {
            stdlog->error( WS_THREAD(self),
                                 ws_status_get_text(s),
                                 ws_socket_get_last_error() );
            continue;
        }

        if (client)
        {
            link = ws_link_new(client);
            ws_list_append(self->links, link);
            /* ws_list_append(self->links, ws_link_new(client));*/
            stdlog->state( WS_THREAD(self),
                                 "link up %s:%d (%p)",
                                 ws_socket_get_host(client),
                                 ws_socket_get_port(client),
                                 link );
        }
        else
            ws_sleep(300);
    }

    ws_socket_close(self->socket, true);
}


static void *
is_link_free (WsLink * link, void * argument, bool * stop)
{
    return (!ws_link_get_hold(link) && ws_link_is_up(link) ) ? link : NULL;
}


static void *
is_link_offline (WsLink * link, void * argument, bool * stop)
{
    return (!ws_link_get_hold(link) && !ws_link_is_up(link) ) ? link : NULL;
}

