#include <stdlib.h>
#include <stdio.h>

#include <ws/stream.h>
#include <ws/timer.h>
#include <ws/socket.h>
#include "link.h"
#include "connector.h"
#include "request.h"

#include "worker.h"

static void
ws_worker_thread(WsWorker * self);

static void
handler_fault (WsRequest * wsr);


extern const WsVersion wsVersion;



WsWorker *
ws_worker_new(int index, WsModule * module)
{
    WsWorker * self = calloc(1, sizeof(WsWorker));

    ws_thread_init(WS_THREAD(self));
    ws_thread_set_name_and_index(WS_THREAD(self), "worker", index);
    WS_THREAD(self)->execute = (WsThreadFunction) ws_worker_thread;

    self->h_fault = handler_fault;

    self->module = module;

    return self;
}

void
ws_worker_free(WsWorker * self)
{
    if (self)
    {
        ws_thread_free(WS_THREAD(self));
    }
}

static void
ws_worker_thread(WsWorker * self)
{
    WsUrl       * urls = ws_module_get_urls(self->module);
    WsRequest   * wsr;
    WsLink      * link;
    WsConnector * connector = ws_module_get_connector(self->module);

    WsHttpStatus status;
    
    if (self->on_start)
        self->data = self->on_start(self);

    while (! ws_thread_is_stopped(WS_THREAD(self)))
    {
        wsr = ws_module_get_request(self->module);

        if (!wsr)
        {
            ws_sleep(150);
            continue;
        }

        ws_request_set_worker(wsr, self);
        link = ws_request_get_link(wsr);



        stdlog->debug(WS_THREAD(self), "got request %p, %d", wsr,
                ws_get_response_status(wsr) );

        /* wsr->data = self->data; --> WsRequest has pointer to worker, so 
         * data is accessible too */

        status = ws_get_response_status(wsr);

        /* check if status was not changed during parsing */
        if (status == wsHttpOk)
            status = ws_url_handler_call(urls, wsr);

        if (status >= wsHttpBadRequest)
        {
            ws_set_response_status(wsr, status);
            stdlog->alert( WS_THREAD(self), 
                             "fallback response to client %s:%d",
                             NULL,
                             ws_socket_get_host(link->socket),
                             ws_socket_get_port(link->socket)
            );

            self->h_fault(wsr);
        }

        ws_request_set_responded(wsr);

        stdlog->state( WS_THREAD(self), "finished response to client %s:%d",
                ws_socket_get_host(link->socket),
                ws_socket_get_port(link->socket)
        );
        /* close connection if we don't need it */
        if (!ws_request_get_keep_alive(wsr))
        {
            stdlog->state(self, "close connection with client %s:%d",
                ws_socket_get_host(link->socket),
                ws_socket_get_port(link->socket)
                    );
            ws_link_set_down(link, wsConnectionClosed);
        }
        ws_request_free(wsr);
        ws_link_touch(link);
        ws_connector_release_link(connector, link);
    }
    if (self->on_stop) self->on_stop(self->data);
}

static void
handler_fault (WsRequest * wsr)
{
    ws_request_print_environ(wsr);

    ws_print(wsr, "<!DOCTYPE html>\n"
                  "<html>\n"
                  "<head>\n");
    ws_printf(wsr, "\t<title>%d: %s :: %s</title>\n", 
                   ws_get_response_status(wsr),
                   ws_get_http_status_text(ws_get_response_status(wsr)),
                   wsWebStuffServer );
    ws_print(wsr, "</head>\n"
                  "<body>\n");
    ws_printf(wsr, "\t<h1>%d: %s</h1>\n", ws_get_response_status(wsr),
                   ws_get_http_status_text(ws_get_response_status(wsr)) );

    ws_printf(wsr, "\t<p style=\"font-size: 12px; color: #363636;\">%s</p>\n",
                   wsWebStuffServer);
    ws_print(wsr, "</body>\n"
                  "</html>");

}
