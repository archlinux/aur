#include <stdlib.h>
#include <stdio.h>  // debug
#include <string.h>

#include <ws/stream.h>
#include <ws/socket.h>
#include "macro.h"


WsStream *
ws_stream_new(int size)
{
    WsStream * self = calloc (1, sizeof(WsStream));
    self->buffer = malloc(sizeof(char)*size);
    self->allocated = size;

    return self;
}

void
ws_stream_free(WsStream * self)
{
    if (!self) return;
    if (self->allocated && self->buffer)
        free(self->buffer);
    free(self);
}

WsInt
ws_stream_write(WsStream * self, const WsChar * buffer, WsSize size)
{
    int i;
    char              *  bf;

    // get channel

    // close stream
    if (!buffer && size==0) 
    {
        self->allocated = 0;
        return -1;
    }

    // extend buffer if necessary
    i = size - (self->allocated - self->size);
    if (i > 0)
    {
        if (i<512) i = 512;
        bf = malloc(sizeof(char)*(self->allocated+i));
        if (self->size > 0)
            memcpy(bf, self->buffer, sizeof(char)*self->size);

        free(self->buffer);
        self->buffer = bf;
        self->allocated+=i;
    }

    // write to buffer
    memcpy(&self->buffer[self->size], buffer, sizeof(char)*size);
    self->size += size;

    return size;
}

WsInt
ws_stream_read(WsStream * self, WsChar * buffer, WsSize size)
{
    int i;
    // if there is not enough data in stream and stream is not closed

    i = MIN(size, self->size);
    if (i>0)
    {
        memcpy(buffer, self->buffer, i);
        self->size -= i;
        // move buffer
        if (self->size>0) memcpy(buffer, &buffer[i], self->size);
    }
    else if (self->allocated == 0)
        i = -1; // stream is over

    return i;
}


bool
ws_stream_is_closed(WsStream * self)
{
    bool r;
    r = (self->allocated > 0) ? false : true;
    return r;

}

WsSize
ws_stream_get_size(WsStream * self)
{
    return self->size;
}


WsStatus
ws_stream_send_to_socket(WsStream * self, WsSocket * sock)
{
    WsStatus r = ws_socket_send(sock, self->buffer, self->size);

    self->size=0;

    return r;
}

