#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <assert.h>

#include <ws/pair.h>
#include <ws/upload.h>
#include <ws/stream.h>
#include <ws/socket.h>
#include <ws/thread.h>

#include "link.h"
#include "macro.h"
#include "http.h"

#include "request.h"


#ifdef HAVE_VA_ARG_LONG_DOUBLE_BUG
#define LONG_DOUBLE double
#else
#define LONG_DOUBLE long double
#endif


#define WS_FMT_BUFFLEN    25
#define WS_PRINTF_BUFFLEN 100


const  WsChar              cHeaderEnd[] = "\r\n";

const WsSize wsResponseHeadersCount = 4;

enum
{
    rfHeadersSent,
    rfServerHeaderSent,
    rfDateHeaderSent,
    rfConnectionHeaderSent,
    rfContentTypeHeaderSent,
    rfContentLengthHeaderSent,
    rfKeepAlive
};

struct _WsRequestPrivate
{
    WsByte              flags : 8;
    WsHttpStatus        status;
    WsLink        * link;
    WsStream      * stream;
    WsList        * headers;
    WsWorker      * worker;
    WsPointer       data;      /* data initiated by on_create */
    WsCreateEvent   on_request;
    WsDestroyEvent  on_response;

};


static void
_ws_request_env_init(WsRequest * self);

static void
_ws_vprintf_increment_copy(char ** dest, char **src, int n);


WsRequest  *
ws_request_new(WsLink * link)
{
    WsRequest * self;

    self       = calloc(1, sizeof(WsRequest));
    self->priv = calloc(1, sizeof(WsRequestPrivate));

    self->priv->link    = link;
    self->priv->status  = wsHttpOk;
    self->priv->stream  = ws_stream_new(4096);
    self->priv->headers = ws_list_new(wsResponseHeadersCount);

    self->environ = ws_list_new(wsRequestEnvironCount);
    self->get     = ws_list_new(0);
    self->post    = ws_list_new(0);
    self->cookie  = ws_list_new(0);
    self->upload  = ws_list_new(0);


    self->environ->free_item = (WsListItemDestructor) ws_pair_free;
    self->get->free_item     = (WsListItemDestructor) ws_pair_free;
    self->post->free_item    = (WsListItemDestructor) ws_pair_free;
    self->cookie->free_item  = (WsListItemDestructor) ws_pair_free;
    self->upload->free_item  = (WsListItemDestructor) ws_upload_free;

    self->priv->headers->free_item  = (WsListItemDestructor) ws_string_free;
    /* self->id      = id; */

    _ws_request_env_init(self);

    return self;
}



char *
ws_request_get_env(WsRequest * self, WsRequestEnviron var)
{
    WsPair * pair;
    if (var > wsRequestEnvironCount) return NULL;


    pair = ws_list_get_item(self->environ, var);
    if (!pair->value)
        ws_string_set(&pair->value, "");
    return pair->value;
}


WsString
ws_request_get_var(WsRequest * self, WsRequestVariable var, const WsChar * key)
{
    WsList * list;
    WsPair * pair = NULL;
    switch(var)
    {
        case wsGet     : list=self->get; break;
        case wsPost    : list=self->post; break;
        case wsCookie  : list=self->cookie; break;
        case wsEnviron : list=self->environ; break;
        default        : list=NULL;
    }

    if (list)
        pair = ws_list_find(
                list, ws_pair_compare_key, (const WsPointer) key, NULL);

    return (pair) ? pair->value : NULL;
}


void
ws_request_free(WsRequest * self)
{
    if (!self) return;

    ws_list_free (self->environ);
    ws_list_free (self->get);
    ws_list_free (self->post);
    ws_list_free (self->cookie);
    ws_list_free (self->upload);

    ws_list_free (self->priv->headers);
    ws_stream_free(self->priv->stream);

    /* matches will be free() by url handler */

    free(self->priv);
    free(self);
}



WsStatus
ws_request_send_status( WsRequest  * self)
{
    WsString     response = NULL;
    WsStatus     status = wsSuccess;
    WsChar       code[3+1];

    sprintf(code, "%d", self->priv->status);

    ws_string_join( &response, " ", WS_HTTP_VERSION, code,
                    ws_get_http_status_text(self->priv->status), cHeaderEnd,
                    NULL );

    if (ws_socket_send(
           self->priv->link->socket, response, ws_string_get_length(response)
       )==WS_SOCKET_ERROR) status = wsSocketWriteError;

    stdlog->save( WS_THREAD(self->priv->worker),
                   (status == wsSuccess) ? wsLogState : wsLogAlert,
                   ">>> %s (%s)", response, ws_status_get_text(status) );
    ws_string_free(response);

    return status;
}



WsStatus
ws_request_send_headers(WsRequest * self)
{
    time_t       rawtime;
    struct tm  * timeinfo;
    WsStatus     status = wsSuccess;
    WsSize       i, c;

    WsString     header = NULL;
    
    self->priv->flags |= (1 << rfHeadersSent);

    status = ws_request_send_status(self);
    if (status != wsSuccess) return status;

    /* Length(Content-Type: text/html; charset=UTF-8\n\r) = 40 */
    ws_string_set_length(&header, 40);

    /* send Server header */
    if (!(self->priv->flags & (1<<rfServerHeaderSent)))
    {
        ws_string_join( &header, "", "Server: ",
                        wsWebStuffServer, cHeaderEnd, NULL);
        if(ws_socket_send( self->priv->link->socket,
                header, ws_string_get_length(header))==WS_SOCKET_ERROR )
            status = wsSocketWriteError;
        if (status != wsSuccess) return status;
    }

    /* send Connection header */
    if (!(self->priv->flags & (1<<rfConnectionHeaderSent)))
    {
        ws_string_join( &header, "", "Connection: ",
           (ws_request_get_keep_alive(self)) ? wsHttpKeepAlive : "close",
            cHeaderEnd, NULL 
        );
        if (ws_socket_send( self->priv->link->socket,
                header, ws_string_get_length(header) )==WS_SOCKET_ERROR)
            status = wsSocketWriteError;
        if (status != wsSuccess) return status;
    }

    /* send Data header */
    if (!(self->priv->flags & (1<<rfDateHeaderSent)))
    {
        time (&rawtime);
        timeinfo = gmtime (&rawtime);

        ws_string_set(&header, "Date: ");

        strftime (&header[6], 40-6, WS_HTTP_TIMESTAMP, timeinfo);

        ws_string_append(&header, cHeaderEnd, 2);

        if (ws_socket_send( self->priv->link->socket,
                   header, ws_string_get_length(header))==WS_SOCKET_ERROR)
                status = wsSocketWriteError;
        if (status != wsSuccess) return status;
    }

    /* send Content-Type header */
    if (!(self->priv->flags & (1<<rfContentTypeHeaderSent)))
    {
        ws_string_set( &header, "Content-Type: text/html; charset=UTF-8\r\n");
        if (ws_socket_send( self->priv->link->socket,
                 header, ws_string_get_length(header) ) == WS_SOCKET_ERROR)
            status = wsSocketWriteError;

        if (status != wsSuccess) return status;
    }

    /* send Content-Length */
    if (!(self->priv->flags & (1<<rfContentLengthHeaderSent)) 
            && ws_request_get_keep_alive(self))
    {
        ws_string_set( &header, "Content-Length: " );
        sprintf(&header[strlen(header)], "%u",
                ws_stream_get_size(self->priv->stream));
        strcat(header, cHeaderEnd);

        if (ws_socket_send( self->priv->link->socket,
                 header, ws_string_get_length(header) ) == WS_SOCKET_ERROR)
            status = wsSocketWriteError;

        if (status != wsSuccess) return status;

    }

    ws_string_free( header );

    /* send all other headers */
    c = ws_list_get_count(self->priv->headers);
    for (i=0; i<c; i++)
    {
        header = ws_list_get_item(self->priv->headers, i);
        if (ws_socket_send( self->priv->link->socket,
                header, ws_string_get_length(header) ) == WS_SOCKET_ERROR)
            status = wsSocketWriteError;
        if (status != wsSuccess) return status;
    }

    /* send end of headers */
    if (ws_socket_send(
                self->priv->link->socket, cHeaderEnd, 2) ==WS_SOCKET_ERROR)
        status = wsSocketWriteError;

    
    return status;
}

WsLink *
ws_request_get_link(WsRequest * self)
{
    return self->priv->link;
}


void
ws_request_set_worker(WsRequest * self, WsWorker * worker)
{
    self->priv->worker = worker;
}


WsStatus
ws_put (const WsChar * data, WsInt size,  WsRequest * wsr)
{
    if (!ws_link_is_up(wsr->priv->link)) return wsSocketWriteError;

    WsStatus status = wsSuccess;

    if (data && size)
    {
        ws_stream_write(wsr->priv->stream, data, size);
        size = 1024;
    }
    else
        size = 0; /* force send all */

    /* response is ready or no need to keep alive and count length */
    if (!size || !ws_request_get_keep_alive(wsr))
    {
        if (!(wsr->priv->flags & (1<<rfHeadersSent)))
        {
            status = ws_request_send_headers(wsr);
            stdlog->save( WS_THREAD(wsr->priv->worker), 
                           (status == wsSuccess) ? wsLogState : wsLogAlert,
                           ">>> send headers (%s)",
                           ws_status_get_text(status) );
        }


        if (ws_stream_get_size(wsr->priv->stream) > size)
        {
            status = ws_stream_send_to_socket(
                     wsr->priv->stream, wsr->priv->link->socket );
        }
    }

    return status;
}

WsStatus
ws_print ( WsRequest * wsr, const WsChar * data)
{
    return ws_put(data, strlen(data), wsr);
}

WsStatus
ws_printf (WsRequest * wsr, const WsChar * format, ...)
{

    va_list   args;
    int       result;
    
    va_start (args, format);
    result = ws_vprintf (wsr, format, args);
    va_end (args);


    return result;
}


void
ws_set_cookie(WsRequest * wsr, const WsChar  * name,
                               const WsChar  * value,
                               WsInt           expires,
                               const WsChar  * path,
                               const WsChar  * domain,
                               WsBool          secure)
{

    time_t      rawtime;
    struct tm * timeinfo;
    int         l = strlen(name)+1+strlen(value)+1;
    char        buffer [MAX(l, 30)];

    const WsChar  header[] = "Set-Cookie: ";
    const WsChar  equal[]  = "=";

    WsString    sexpires  = NULL;
    WsString    spath     = NULL;
    WsString    sdomain   = NULL;
    WsString    ssecure   = NULL;

    WsString    cookie = NULL;

    if (wsr->priv->flags & (1<<rfHeadersSent))
    {
        ws_print(wsr, "<p>Could not add cookie information: already sent</p>");
        return ;
    }


    /* sync of request and resonse cookies
    cookie = (ws_pair*) ws_list_find_first(r->cookie, name);
    if (cookie)
    {
        if (expires < 0)
        {
            ws_list_remove(r->cookie, (void *)cookie);
            cookie = NULL;
        }
        else
        {
            if ( strcmp((char *)cookie->value, value))
            {
                ws_list_remove(r->cookie, (void *)cookie);
                ws_pair_free(cookie);
                ws_list_append(r->cookie, ws_pair_new_from_string(name,value));
            }
        }
    }
    else if (expires >= 0)
        ws_list_append(r->cookie, ws_pair_new_from_string(name, value));
    */

    if (expires > 0)
    {
        time (&rawtime);
        rawtime+=expires;
        timeinfo = gmtime (&rawtime);

        strftime (buffer,30, WS_HTTP_TIMESTAMP, timeinfo);

        ws_string_join(&sexpires, "; Expires=", buffer, NULL);
    }

    if (path)
        ws_string_join(&spath, "; Path=", path, NULL);

    if (domain)
        ws_string_join(&sdomain, "; Domain=", domain, NULL);

    if (secure)
        ws_string_set(&ssecure, "; secure");

    ws_string_join( &cookie, "", header,
                    name, equal, value,
                    sexpires, spath, sdomain, ssecure, cHeaderEnd,
                    NULL );

    ws_list_append(wsr->priv->headers, cookie);

    ws_string_free(    sexpires   );
    ws_string_free(    spath      );
    ws_string_free(    sdomain    );
    ws_string_free(    ssecure    );
}


void
ws_set_header(WsRequest * wsr, const WsChar * key, const WsChar * value)
{
    if (wsr->priv->flags & (1 << rfHeadersSent))
    {
        ws_print(wsr, "<p>Could not add header information: already sent</p>");
        return ;
    }

    WsString header = NULL;

    /* set flags for automatical headers, that we don't want to duplicate */
    if (strcmp(key, "Server")==0)
    {
        if (wsr->priv->flags & (1<<rfServerHeaderSent)) return;
        wsr->priv->flags |= (1<<rfServerHeaderSent);
    }
    else if (strcmp(key, "Date")==0)
    {
        if (wsr->priv->flags & (1<<rfDateHeaderSent)) return;
        wsr->priv->flags |= (1<<rfDateHeaderSent);
    }
    else if (strcmp(key, "Connection")==0)
    {
        if (wsr->priv->flags & (1<<rfConnectionHeaderSent)) return;
        wsr->priv->flags |= (1<<rfConnectionHeaderSent);
    }
    else if (strcmp(key, "Content-Type")==0)
    {
        if (wsr->priv->flags & (1<<rfContentTypeHeaderSent)) return;
        wsr->priv->flags |= (1<<rfContentTypeHeaderSent);
    }

    ws_string_join(&header, "", key, ": ", value, cHeaderEnd, NULL);
    ws_list_append(wsr->priv->headers, header);

}


void
ws_set_response_status(WsRequest * wsr, WsHttpStatus status)
{
    /* change status only if it was not sent */
    if (!(wsr->priv->flags & (1<<rfHeadersSent)))
        wsr->priv->status = status;
}


WsHttpStatus
ws_get_response_status(WsRequest * wsr)
{
    return wsr->priv->status;
}



/* modified from fastcgi library */
WsStatus
ws_vprintf(WsRequest * r, const char *format, va_list arg)
{
    if (!ws_link_is_up(r->priv->link)) return wsSocketWriteError;
    
    char *f, *fStop, *percentPtr, *p, *fmtBuffPtr, *buffPtr;
    int op, performedOp, sizeModifier, buffCount = 0, buffLen, specifierLength;
    int fastPath, n, auxBuffLen = 0, buffReqd, minWidth, precision, exp;
    char *auxBuffPtr = NULL;
    int streamCount = 0;
    char fmtBuff[WS_FMT_BUFFLEN];
    char buff[WS_PRINTF_BUFFLEN];

    int intArg;
    short shortArg;
    long longArg;
    unsigned unsignedArg;
    unsigned long uLongArg;
    unsigned short uShortArg;
    char *charPtrArg = NULL;
    void *voidPtrArg;
    int *intPtrArg;
    long *longPtrArg;
    short *shortPtrArg;
    double doubleArg = 0.0;
    LONG_DOUBLE lDoubleArg = 0.0L;

    fmtBuff[0] = '%';
    f = (char *) format;
    fStop = f + strlen(f);
    while (f != fStop) {
        percentPtr = (char *)memchr(f, '%', fStop - f);
        if(percentPtr == NULL) percentPtr = fStop;
        if(percentPtr != f) {
            if(ws_put(f, percentPtr - f, r) !=wsSuccess)
                goto ErrorReturn;
            streamCount += percentPtr - f;
            f = percentPtr;
            if(f == fStop) break;
    }
        fastPath = TRUE;
        /*
         * The following loop always executes either once or twice.
         */
        for (;;) {
            if(fastPath) {
                /*
                 * Fast path: Scan optimistically, hoping that no flags,
                 * minimum field width, or precision are specified.
                 * Use the preallocated buffer, which is large enough
                 * for all fast path cases.  If the conversion specifier
                 * is really more complex, run the loop a second time
                 * using the slow path.
                 * Note that fast path execution of %s bypasses the buffer
                 * and %f is not attempted on the fast path due to
                 * its large buffering requirements.
                 */
                op = *(percentPtr + 1);
                switch(op) {
                case 'l':
                case 'L':
                    case 'h':
                        sizeModifier = op;
                        op = *(percentPtr + 2);
                        fmtBuff[1] = (char) sizeModifier;
                        fmtBuff[2] = (char) op;
                        fmtBuff[3] = '\0';
                        specifierLength = 3;
                        break;
                default:
                        sizeModifier = ' ';
                        fmtBuff[1] = (char) op;
                        fmtBuff[2] = '\0';
                        specifierLength = 2;
                        break;
            }
                buffPtr = buff;
                buffLen = WS_PRINTF_BUFFLEN;
        } else {
                /*
                 * Slow path: Scan the conversion specifier and construct
                 * a new format string, compute an upper bound on the
                 * amount of buffering that sprintf will require,
                 * and allocate a larger buffer if necessary.
                 */
                p = percentPtr + 1;
                fmtBuffPtr = &fmtBuff[1];
                /*
                 * Scan flags
                 */
                n = strspn(p, "-0+ #");
                if(n > 5)
                    goto ErrorReturn;
                _ws_vprintf_increment_copy(&fmtBuffPtr, &p, n);
                /*
                 * Scan minimum field width
                 */
                n = strspn(p, "0123456789");
                if(n == 0) {
                    if(*p == '*') {
                        minWidth = va_arg(arg, int);
                        if(abs(minWidth) > 999999)
                            goto ErrorReturn;
            /*
             * The following use of strlen rather than the
             * value returned from sprintf is because SUNOS4
             * returns a char * instead of an int count.
             */
            sprintf(fmtBuffPtr, "%d", minWidth);
                        fmtBuffPtr += strlen(fmtBuffPtr);
                        p++;
                } else {
                        minWidth = 0;
                }
            } else if(n <= 6) {
                    minWidth = strtol(p, NULL, 10);
                    _ws_vprintf_increment_copy(&fmtBuffPtr, &p, n);
                } else {
                    goto ErrorReturn;
                }
                /*
                 * Scan precision
                 */
            if(*p == '.') {
                    _ws_vprintf_increment_copy(&fmtBuffPtr, &p, 1);
                    n = strspn(p, "0123456789");
                    if(n == 0) {
                        if(*p == '*') {
                            precision = va_arg(arg, int);
                            if(precision < 0) precision = 0;
                            if(precision > 999999)
                                goto ErrorReturn;
            /*
             * The following use of strlen rather than the
             * value returned from sprintf is because SUNOS4
             * returns a char * instead of an int count.
             */
                sprintf(fmtBuffPtr, "%d", precision);
                fmtBuffPtr += strlen(fmtBuffPtr);
                            p++;
                    } else {
                            precision = 0;
                    }
                } else if(n <= 6) {
                        precision = strtol(p, NULL, 10);
                        _ws_vprintf_increment_copy(&fmtBuffPtr, &p, n);
                    } else {
                        goto ErrorReturn;
                    }
                } else {
                    precision = -1;
                }
                /*
                 * Scan size modifier and conversion operation
                 */
                switch(*p) {
                case 'l':
                    case 'L':
                    case 'h':
                        sizeModifier = *p;
                        _ws_vprintf_increment_copy(&fmtBuffPtr, &p, 1);
                        break;
                default:
                        sizeModifier = ' ';
                        break;
                }
                op = *p;
                _ws_vprintf_increment_copy(&fmtBuffPtr, &p, 1);
                assert(fmtBuffPtr - fmtBuff < WS_FMT_BUFFLEN);
                *fmtBuffPtr = '\0';
                specifierLength = p - percentPtr;
                /*
                 * Bound the required buffer size.  For s and f
                 * conversions this requires examining the argument.
                 */
                switch(op) {
                case 'd':
                    case 'i':
                    case 'u':
                    case 'o':
                    case 'x':
                    case 'X':
                    case 'c':
                    case 'p':
                        buffReqd = MAX(precision, 46);
                        break;
                case 's':
                        charPtrArg = va_arg(arg, char *);
            if (!charPtrArg) charPtrArg = "(null)";
                        if(precision == -1) {
                buffReqd = strlen(charPtrArg);
                } else {
                p = (char *)memchr(charPtrArg, '\0', precision);
                            buffReqd =
                  (p == NULL) ? precision : p - charPtrArg;
            }
                        break;
                case 'f':
                        switch(sizeModifier) {
                            case ' ':
                                doubleArg = va_arg(arg, double);
                                frexp(doubleArg, &exp);
                                break;
                            case 'L':
                                lDoubleArg = va_arg(arg, LONG_DOUBLE);
                                /* XXX Need to check for the presence of 
                                 * frexpl() and use it if available */
                                frexp((double) lDoubleArg, &exp);
                                break;
                            default:
                                goto ErrorReturn;
                        }
                        if(precision == -1) precision = 6;
                        buffReqd = precision + 3 + ((exp > 0) ? exp/3 : 0);
                        break;
                case 'e':
                case 'E':
                case 'g':
                case 'G':
                        if(precision == -1) precision = 6;
                        buffReqd = precision + 8;
                        break;
                case 'n':
                case '%':
                default:
                        goto ErrorReturn;
                        break;
                }
                buffReqd = MAX(buffReqd + 10, minWidth);
                /*
                 * Allocate the buffer
                 */
            if(buffReqd <= WS_PRINTF_BUFFLEN) {
                    buffPtr = buff;
            buffLen = WS_PRINTF_BUFFLEN;
            } else {
                    if(auxBuffPtr == NULL || buffReqd > auxBuffLen) {
                if(auxBuffPtr != NULL) free(auxBuffPtr);
                        auxBuffPtr = (char *)malloc(buffReqd);
                        auxBuffLen = buffReqd;
                        if(auxBuffPtr == NULL)
                            goto ErrorReturn;
            }
                    buffPtr = auxBuffPtr;
            buffLen = auxBuffLen;
        }
        }
            /*
             * This giant switch statement requires the following variables
             * to be set up: op, sizeModifier, arg, buffPtr, fmtBuff.
             * When fastPath == FALSE and op == 's' or 'f', the argument
             * has been read into charPtrArg, doubleArg, or lDoubleArg.
             * The statement produces the boolean performedOp, TRUE iff
             * the op/sizeModifier were executed and argument consumed;
             * if performedOp, the characters written into buffPtr[]
             * and the character count buffCount (== EOF meaning error).
             *
             * The switch cases are arranged in the same order as in the
             * description of fprintf in section 15.11 of Harbison and Steele.
             */
            performedOp = TRUE;
            switch(op) {
            case 'd':
            case 'i':
                    switch(sizeModifier) {
                        case ' ':
                            intArg = va_arg(arg, int);
                sprintf(buffPtr, fmtBuff, intArg);
                            buffCount = strlen(buffPtr);
                            break;
                    case 'l':
                            longArg = va_arg(arg, long);
                            sprintf(buffPtr, fmtBuff, longArg);
                            buffCount = strlen(buffPtr);
                            break;
                    case 'h':
                            shortArg = (short) va_arg(arg, int);
                            sprintf(buffPtr, fmtBuff, shortArg);
                            buffCount = strlen(buffPtr);
                            break;
                    default:
                            goto ErrorReturn;
                }
                    break;
            case 'u':
                case 'o':
                case 'x':
                case 'X':
                    switch(sizeModifier) {
                        case ' ':
                            unsignedArg = va_arg(arg, unsigned);
                sprintf(buffPtr, fmtBuff, unsignedArg);
                            buffCount = strlen(buffPtr);
                            break;
                    case 'l':
                            uLongArg = va_arg(arg, unsigned long);
                sprintf(buffPtr, fmtBuff, uLongArg);
                            buffCount = strlen(buffPtr);
                            break;
                        case 'h':
                            uShortArg = (unsigned short) va_arg(arg, int);
                            sprintf(buffPtr, fmtBuff, uShortArg);
                            buffCount = strlen(buffPtr);
                            break;
                        default:
                            goto ErrorReturn;
                    }
                    break;
                case 'c':
                    switch(sizeModifier) {
                        case ' ':
                            intArg = va_arg(arg, int);
                sprintf(buffPtr, fmtBuff, intArg);
                            buffCount = strlen(buffPtr);
                            break;
                    case 'l':
                            /*
                             * XXX: Allowed by ISO C Amendment 1, but
                             * many platforms don't yet support wint_t
                             */
                            goto ErrorReturn;
                    default:
                            goto ErrorReturn;
                    }
                    break;
            case 's':
                    switch(sizeModifier) {
                        case ' ':
                    if(fastPath) {
                    buffPtr = va_arg(arg, char *);
                                buffCount = strlen(buffPtr);
                                buffLen = buffCount + 1;
                } else {
                sprintf(buffPtr, fmtBuff, charPtrArg);
                            buffCount = strlen(buffPtr);
                }
                break;
                    case 'l':
                            /*
                             * XXX: Don't know how to convert a sequence
                             * of wide characters into a byte r->out, or
                             * even how to predict the buffering required.
                             */
                            goto ErrorReturn;
                        default:
                            goto ErrorReturn;
                    }
                    break;
                case 'p':
                    if(sizeModifier != ' ')
                        goto ErrorReturn;
                    voidPtrArg = va_arg(arg, void *);
            sprintf(buffPtr, fmtBuff, voidPtrArg);
                    buffCount = strlen(buffPtr);
                    break;
                case 'n':
                    switch(sizeModifier) {
                        case ' ':
                            intPtrArg = va_arg(arg, int *);
                            *intPtrArg = streamCount;
                            break;
                        case 'l':
                            longPtrArg = va_arg(arg, long *);
                            *longPtrArg = streamCount;
                            break;
                        case 'h':
                            shortPtrArg = (short *) va_arg(arg, short *);
                            *shortPtrArg = (short) streamCount;
                            break;
                    default:
                            goto ErrorReturn;
                }
                    buffCount = 0;
                    break;
                case 'f':
            if(fastPath) {
                performedOp = FALSE;
                        break;
            }
                    switch(sizeModifier) {
                        case ' ':
                sprintf(buffPtr, fmtBuff, doubleArg);
                            buffCount = strlen(buffPtr);
                            break;
                        case 'L':
                sprintf(buffPtr, fmtBuff, lDoubleArg);
                            buffCount = strlen(buffPtr);
                            break;
                        default:
                            goto ErrorReturn;
                    }
                    break;
                case 'e':
                case 'E':
                case 'g':
                case 'G':
                    switch(sizeModifier) {
                        case ' ':
                            doubleArg = va_arg(arg, double);
                sprintf(buffPtr, fmtBuff, doubleArg);
                            buffCount = strlen(buffPtr);
                            break;
                        case 'L':
                            lDoubleArg = va_arg(arg, LONG_DOUBLE);
                sprintf(buffPtr, fmtBuff, lDoubleArg);
                            buffCount = strlen(buffPtr);
                            break;
                        default:
                            goto ErrorReturn;
                    }
                    break;
                case '%':
                    if(sizeModifier != ' ')
                        goto ErrorReturn;
                    buff[0] = '%';
                    buffCount = 1;
                    break;
                case '\0':
                    goto ErrorReturn;
                default:
                    performedOp = FALSE;
                    break;
            } /* switch(op) */
            if(performedOp) break;
            if(!fastPath)
                goto ErrorReturn;
            fastPath = FALSE;
        } /* for (;;) */
        assert(buffCount < buffLen);
        if(buffCount > 0) {
            if(ws_put(buffPtr, buffCount, r) != wsSuccess)
                goto ErrorReturn;
            streamCount += buffCount;
        } else if(buffCount < 0) {
            goto ErrorReturn;
    }
        f += specifierLength;
    } /* while(f != fStop) */
    goto NormalReturn;
  ErrorReturn:
    streamCount = -1;
  NormalReturn:
    if(auxBuffPtr != NULL) free(auxBuffPtr);
    return streamCount;
}



WsBool
ws_request_get_keep_alive(WsRequest * self)
{
    return (self->priv->flags & (1<<rfKeepAlive)) ? true : false;;
}

void
ws_request_set_keep_alive(WsRequest * self, WsBool keep)
{
    if(keep)
        self->priv->flags |= 1<<rfKeepAlive;
    else if (ws_request_get_keep_alive(self))
        self->priv->flags ^= 1<<rfKeepAlive;

}



void
ws_request_set_on_requested(WsRequest * wsr, WsCreateEvent on_request)
{
    wsr->priv->on_request = on_request;
}


void
ws_request_set_on_responded(WsRequest * wsr, WsDestroyEvent on_response)
{
    wsr->priv->on_response = on_response;
}


void
ws_request_set_requested(WsRequest * wsr)
{
    if (wsr->priv->on_request) wsr->priv->data = wsr->priv->on_request(wsr);
}

void
ws_request_set_responded(WsRequest * wsr)
{
    ws_put(NULL, 0, wsr);
    if (wsr->priv->on_request) wsr->priv->on_response(wsr->priv->data);
}


WsPointer
ws_request_get_data(WsRequest * wsr)
{
    return wsr->priv->data;
}


WsPointer
ws_request_get_worker_data(WsRequest * wsr)
{
    return wsr->priv->worker->data;
}


/* + debug methods --------------------------------------------------------- */





void
ws_request_print_environ(WsRequest * wsr)
{
    WsInt i, c;
    WsPair * p;

    c = ws_list_get_count(wsr->environ);

    printf("+ -- begin environment --------------------------------------------------------+\n");

    for (i = 0; i<c; i++)
    {
        p = ws_list_get_item(wsr->environ, i);
        printf ("%s: %s;\n", p->key, p->value);
    }
    printf("+ -- end environment ----------------------------------------------------------+\n");

}
/* STATIC ------------------------------------------------------------------ */

static void
_ws_vprintf_increment_copy(char ** dest, char **src, int n)
{
    char *pdest = *dest;
    char *psrc = *src;
    int i;
    for (i = 0; i < n; i++)
        *dest++ = *src++;
    *dest = pdest;
    *src = psrc;
}


static void
_ws_request_env_init(WsRequest * self)
{
    ws_list_set_item(
        self->environ, wsRequestUri,         ws_pair_new("REQUEST_URI", NULL) );
    ws_list_set_item(
        self->environ, wsRequestMethod,      ws_pair_new("REQUEST_METHOD", "GET") );
    ws_list_set_item(
        self->environ, wsRemoteAddr,         ws_pair_new("REMOTE_ADDR", NULL) );
    ws_list_set_item(
        self->environ, wsRemotePort,         ws_pair_new("REMOTE_PORT", NULL) );
    ws_list_set_item(
        self->environ, wsQueryString,        ws_pair_new("QUERY_STRING", NULL) );
    ws_list_set_item(
        self->environ, wsScriptName,         ws_pair_new("SCRIPT_NAME", NULL) );
    ws_list_set_item(
        self->environ, wsScriptFilename,     ws_pair_new("SCRIPT_FILENAME", NULL) );
    ws_list_set_item(
        self->environ, wsHttpHost,           ws_pair_new("HTTP_HOST", NULL) );
    ws_list_set_item(
        self->environ, wsHttpUserAgent,      ws_pair_new("HTTP_USER_AGENT", NULL) );
    ws_list_set_item(
        self->environ, wsHttpAccept,         ws_pair_new("HTTP_ACCEPT", NULL) );
    ws_list_set_item(
        self->environ, wsHttpAcceptLanguage, ws_pair_new("HTTP_ACCEPT_LANGUAGE", NULL) );
    ws_list_set_item(
        self->environ, wsHttpAcceptEncoding, ws_pair_new("HTTP_ACCEPT_ENCODING", NULL) );
    ws_list_set_item(
        self->environ, wsHttpCookie,         ws_pair_new("HTTP_COOKIE", NULL) );
    ws_list_set_item(
        self->environ, wsHttpConnection,     ws_pair_new("HTTP_CONNECTION", NULL) );
    ws_list_set_item(
        self->environ, wsContentType,        ws_pair_new("CONTENT_TYPE", NULL) );
    ws_list_set_item(
        self->environ, wsContentLength,      ws_pair_new("CONTENT_LENGTH", NULL) );
    ws_list_set_item(
        self->environ, wsServerSoftware,     ws_pair_new("SERVER_SOFTWARE", wsWebStuffServer) );
    ws_list_set_item(
        self->environ, wsServerName,         ws_pair_new("SERVER_NAME", NULL) );
    ws_list_set_item(
        self->environ, wsServerProtocol,     ws_pair_new("SERVER_PROTOCOL", "HTTP/1.1") );
    ws_list_set_item(
        self->environ, wsServerAddr,         ws_pair_new("SERVER_ADDR", NULL) );
    ws_list_set_item(
        self->environ, wsServerPort,         ws_pair_new("SERVER_PORT", NULL) );
    ws_list_set_item(
        self->environ, wsServerAdmin,        ws_pair_new("SERVER_ADMIN", NULL) );
    ws_list_set_item(
        self->environ, wsDocumentUri,        ws_pair_new("DOCUMENT_URI", NULL) );
    ws_list_set_item(
        self->environ, wsDocumentRoot,       ws_pair_new("DOCUMENT_ROOT", NULL) );
    ws_list_set_item(
        self->environ, wsGatewayInterface,   ws_pair_new("GATEWAY_INTERFACE", "CGI/1.1") );
}



void
ws_request_log (WsRequest * self, WsLogLevel level, const WsChar * message, ...)
{
    if (!stdlog || !self) return;

    va_list     args;
    WsString    m = NULL;

    ws_string_join(&m, "", ws_thread_get_name(WS_THREAD(self->priv->worker)),
                           " [", ws_request_get_env(self, wsRequestMethod),
                           " ", ws_request_get_env(self, wsRequestUri),
                           "]: ", message, NULL);

    va_start (args, message);
    ws_log_save (stdlog, level, m, args);
    va_end (args);

    ws_string_free(m);
}
