#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <ws/log.h>
#include <ws/timestamp.h>
#include <ws/thread.h>
#include <ws/string.h>

const WsChar   cAsciiLine[] = "+-----------------------------------------------------------------------------+\n";
const int    wsLogDefaultPathSize = 32;

struct _WsLogPrivate
{
    WsMutex            lock;
    int                level;
    WsString           file;
    const WsString   * name;
    const WsVersion  * version;
};

WsLog * stdlog = NULL;


static void
_log_save(WsPointer th, WsLogLevel level,  const WsChar   * msg, ...);

static void
_log_state(WsPointer th, const WsChar   * msg, ...);

static void
_log_debug(WsPointer th, const WsChar   * msg, ...);

static void
_log_alert(WsPointer th, const WsChar  * msg, const WsChar  * detail, ...);

static void
_log_error(WsPointer th, const WsChar  * msg, const WsChar  * detail, ...);

static WsString
_get_log_format( WsPointer * thread, const WsChar * msg, const WsChar * details );


WsLog *
ws_log_new(const WsString * name, const WsVersion * version)
{
    WsLog * self = calloc(1, sizeof(WsLog));
    self->priv    = calloc(1, sizeof(WsLogPrivate));
    ws_mutex_init(&self->priv->lock);
    self->priv->level = WS_LOG_ALL;

    self->priv->name = name;
    ws_string_set_length(&self->priv->file, 32);

    self->priv->version = version;

    if (!stdlog)
    {
        stdlog = self;
        stdlog->error = _log_error;
        stdlog->alert = _log_alert;
        stdlog->debug = _log_debug;
        stdlog->state = _log_state;
        stdlog->save  = _log_save;
    }

    return self;
}

void
ws_log_free(WsLog * self)
{
    void ** p = (void**)&self;
    if (self)
    {
        ws_mutex_destroy(&self->priv->lock);
        ws_string_free(self->priv->file);
        free(self->priv);
        free(self);
        *p = NULL;
    }
}

void
ws_log_set_level(WsLog * self, int value)
{
    ws_mutex_lock(&self->priv->lock);
    self->priv->level = value;
    ws_mutex_unlock(&self->priv->lock);
}

bool
ws_log_set_file(WsLog * self, WsChar * value)
{
    WsBool         error = false;
    FILE       * f;
    WsTimestamp  ts;
    WsString     strtime = NULL;

    ws_mutex_lock(&self->priv->lock);



    if (value && strcmp(value, "stdout"))
    {
        if((f=fopen(value, "a+"))!=NULL)
        {
            ws_now(&ts);
            ws_timestamp_set_string(&ts, &strtime);
    
            fputs(cAsciiLine, f);
            fprintf(f, "| %s | version %d.%d.%d build #%d | %s\n", 
                    *self->priv->name,
                    self->priv->version->major,
                    self->priv->version->minor,
                    self->priv->version->release,
                    self->priv->version->build,
                    strtime);
            fputs(cAsciiLine, f);

            fclose(f);
            ws_string_set(&self->priv->file, value);
        }
        else
        {
            printf("%p\n", self);
            fprintf( stderr, 
                     "Could not open log file '%s'\n", 
                     value );
            error = true;
        }
    }


    ws_mutex_unlock(&self->priv->lock);

    ws_string_free(strtime);

    return error;
}

void
ws_log_save(WsLog * self, WsLogLevel level,const  WsChar * message, va_list args)
{
    FILE * f = NULL;
    WsChar * label;

    WsTimestamp ts;
    WsString    strtime = NULL;

    ws_mutex_lock(&self->priv->lock);

    if (self->priv->level & level)
    {
        switch (level)
        {
            case wsLogError : label = "ERROR"; break;
            case wsLogAlert : label = "ALERT"; break;
            case wsLogDebug : label = "DEBUG"; break;
            default         : label = "STATE";
        }

        if (self->priv->file) f=fopen(self->priv->file, "a+");

        if (f == NULL) f = stdout;

        ws_now(&ts);
        ws_timestamp_set_string(&ts, &strtime);

        fprintf(f, "[%s] [%s] ", strtime, label);
        vfprintf (f, message, args);
        if (message[strlen(message)-1] != '\n') fputc('\n', f);

        if (f != stdout) fclose(f);
    }


    ws_mutex_unlock(&self->priv->lock);
    ws_string_free(strtime);
}

static void
_log_error(WsPointer th, const WsChar  * msg, const WsChar  * detail, ...)
{
    if (!stdlog) return;

    va_list     args;
    WsString   m = _get_log_format(th, msg, detail);

    va_start (args, detail);
    ws_log_save (stdlog, wsLogError, m, args);
    va_end (args);

    ws_string_free(m);
}

static void
_log_alert(WsPointer th, const WsChar  * msg, const WsChar  * detail, ...)
{
    if (!stdlog) return;

    va_list     args;
    WsString   m = _get_log_format(th, msg, detail);

    va_start (args, detail);
    ws_log_save (stdlog, wsLogAlert, m, args);
    va_end (args);

    ws_string_free(m);
}
static void
_log_debug(WsPointer th, const WsChar   * msg, ...)
{
    if (!stdlog) return;

    va_list     args;
    WsString   m = _get_log_format(th, msg, NULL);

    va_start (args, msg);
    ws_log_save (stdlog, wsLogDebug, m, args);
    va_end (args);

    ws_string_free(m);
}

static void
_log_state(WsPointer th, const WsChar   * msg, ...)
{
    if (!stdlog) return;

    va_list     args;
    WsString   m = _get_log_format(th, msg, NULL);

    va_start (args, msg);
    ws_log_save (stdlog, wsLogState, m, args);
    va_end (args);

    ws_string_free(m);
}

static void
_log_save(WsPointer th, WsLogLevel level,  const WsChar   * msg, ...)
{
    if (!stdlog) return;

    va_list     args;
    WsString   m = _get_log_format(th, msg, NULL);

    va_start (args, msg);
    ws_log_save (stdlog, level, m, args);
    va_end (args);

    ws_string_free(m);

}

static WsString
_get_log_format( WsPointer * th, const WsChar * msg, const WsChar * details )
{
    WsString m = NULL;

    ws_string_join(&m, "", ws_thread_get_name(WS_THREAD(th)),
                            ": ",
                            msg,
                            (details) ? " (" : "",
                            details, /* will be terminator if NULL */
                            ")",
                            NULL );

    return m;
}


