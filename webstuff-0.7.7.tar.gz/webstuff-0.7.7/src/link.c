#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <ws/pair.h>

#include "link.h"

#define STREAM_BUFFER 0xffff

enum
{
    lfHold,
    lfHasRequest
};

WsLink *
ws_link_new (WsSocket * client)
{
    WsLink * self = calloc(1, sizeof(WsLink));
    self->socket  = client;

    ws_link_touch(self);

    return self;
}


void
ws_link_free(WsLink * self)
{
    if (self)
    {
        ws_socket_free(self->socket);
        free(self);
        *((void**) &self) = NULL;
    }
}

bool
ws_link_get_hold(WsLink * self)
{
    return (self->flag & 1<<lfHold) ? true : false;
}

void
ws_link_set_hold(WsLink * self, bool hold)
{
    if (hold)
        self->flag |= 1<<lfHold;
    else if (self->flag & 1<<lfHold)
        self->flag ^= 1<<lfHold;
}


void
ws_link_touch(WsLink * self)
{
    time(&self->ts);
}


bool
ws_link_is_up(WsLink * self)
{
    bool res = ws_socket_is_open(self->socket);

    if (res)
    {
        res = difftime(time(NULL), self->ts) > 30 ? false : true;
        if (!res)
            ws_link_set_down(self, wsConnectionTimeout);
    }
    return res;
}


void
ws_link_set_down(WsLink * self, WsStatus status)
{
    self->status = status;
    ws_socket_close(self->socket, true);
}


WsStatus
ws_link_get_status(WsLink * self)
{
    return self->status;
}

/*

void
ws_link_request_start(WsLink * self)
{
    char buf[8];
    pthread_mutex_lock(&self->lock);
    if (!self->request)
        self->request = ws_request_new(1);
    ws_pair_value_set(self->request->env->first[REMOTE_ADDR], 
                      ws_socket_host_get(self->socket));
    sprintf(buf, "%d", ws_socket_port_get(self->socket));
    ws_pair_value_set(self->request->env->first[REMOTE_PORT], buf);
    self->flag |= ws_link_BUSY;

    pthread_mutex_unlock(&self->lock);
}

void
ws_link_request_stop(WsLink * self)
{
    pthread_mutex_lock(&self->lock);

//    if(self->flag & ws_link_REQUESTED)
//        self->flag ^= ws_link_REQUESTED;

    if(self->flag & ws_link_BUSY)
        self->flag ^= ws_link_BUSY;

    self->flag |= ws_link_DISCONNECTED;

    self->request = ws_request_free(self->request);
    self->response = ws_response_free(self->response);
    pthread_mutex_unlock(&self->lock);
}

int
ws_link_send_headers(WsLink * self, char * buffer, int buffer_size)
{
    ws_list * l = self->response->headers;
    ws_pair * p;

    l->iterator = l->first;

    // send status
    ws_response_status_get(self->response, buffer);
    if (ws_socket_write(self->socket, buffer, strlen(buffer)) < 0)
        return -1;

    // send headers
    while (l->iterator != l->last)
    {
        p = *l->iterator;

        // ignore too long headers > 64Kb
        if (strlen(p->key)+strlen(p->value)+4 > buffer_size)
            continue;

        sprintf(buffer, "%s: %s\r\n", p->key, p->value);
        if (ws_socket_write(self->socket, buffer, strlen(buffer))<0)
            return -1;

        l->iterator++;
    }
    //send end of headers
    if(ws_socket_write(self->socket, &buffer[strlen(buffer)-2], 2)<0)
        return -1;
        

    self->response->flag |= WS_RESPONSE_HEADERS_SENT;

    return 0;
}

int
ws_link_send_data(WsLink * self, char * buffer, int b_size)
{
    int length;
    while ((length = ws_stream_read(self->response->out, buffer, b_size))>0)
    {
        if (ws_socket_write(self->socket, buffer, length)<0)
            return -1;
    }
    if (self->response->out->size==0)
    {
        ws_link_request_stop(self);
        return 0;
    }
    else
        return 1;
}


*/
