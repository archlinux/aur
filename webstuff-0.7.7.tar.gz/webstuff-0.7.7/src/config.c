#ifdef WITH_CONF_PARSER
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <ws/config.h>
#include <ws/list.h>
#include <ws/string.h>


#define SHIFT 0                        /* index of indent with line shift */
#define EQUAL 1                        /* index of indent before '=' sign */
#define VALUE 2                        /* index of indent before value    */
#define COMNT 3                        /* index of indent before comment  */

/* globals
 *************************************************************************** */

const WsInt  cMaxLength = 255;
const WsChar lwConfigTrue[] = "true";
const WsChar lwConfigFalse[] = "false";


/* types
 *************************************************************************** */
typedef struct _WsConfigLine WsConfigLine;
typedef struct _WsConfigFind WsConfigFind;

struct _WsConfigPrivate
{
    WsList   * list;                  /* list of lines */
    WsSize    root;                  /* index of line with current section */
    WsSize    max_id;                /* node id generator */
};

struct _WsConfigLine
{
    WsByte     indent[4];             /* array of line indents */
    WsString   key;                   /* key name */
    WsString   value;                 /* value name */
    WsString   comment;               /* comment name */
    WsSize     node_id;               /* raw number of section */
};

struct _WsConfigFind
{
    const WsChar * key;
    WsConfigLine * root;
};


/* static
 *************************************************************************** */


/* main parsing method, called by ws_config_read
 * @param self WsConfig object
 * @param line buffer with null-terminated line
 * @param l pointer to WsConfigLine structure, that will be created and parsed
 * @param stack object of WsList that will be used as a stack for config nodes
 * @result wsSuccess or sConfigSyntaxError
 * */
static WsStatus
ws_config_read_line( WsConfig      * self,
                      WsChar           * line,
                      WsConfigLine ** l,
                      WsList        * stack );


/* find proper place to insert new node or key-value pair.
 * proper place is the end of node, or after last occurence of key in node
 * @param self WsConfig object
 * @param key  key text, NULL if key is not presented in config already
 * @param line pointer to line counter
 * @return indent
 * */
static WsByte
ws_config_get_insert_position( WsConfig  * self,
                                const WsChar * key, 
                                WsSize   * line);


/* get current root node. If node is not select, number of config lines will
 * be written into line
 * @param self WsConfig object
 * @param line pointer to line counter
 * @return pointer to line structure of root node or NULL if not found
 * */
static WsConfigLine *
ws_config_get_root( WsConfig  * self, WsSize * line );



/* common function to compare key name and node
 * @param item void pointer to line structure
 * @param argument void pointer to WsConfigFind structure
 * @return item pointer  or NULL if no condition
 * */
static void *
_find(void * item, void * argument, WsBool * stop);


/* compare item node id with argument
 * @param item void pointer to line structure
 * @param argument pointer to integer with node_id
 * @return item pointer or NULL if no condition 
 * */
static void *
_find_node(void * item, void * argument, WsBool * stop);


static void *
_find_last(void * item, void * argument, WsBool * stop);

/* free resources used by line structure
 * @param line pointer to WsConfigLine structure
 * */
static void
_free_line( WsConfigLine * line );


/* implementation
 *************************************************************************** */


WsConfig *
ws_config_new(const WsChar * file)
{
    WsConfig * self = calloc(1, sizeof(WsConfig));

    self->priv = calloc(1, sizeof(WsConfigPrivate));
    self->priv->list = ws_list_new(32);


    ws_list_set_item_destructor(
            self->priv->list, (WsListItemDestructor) _free_line);

    return self;
}


void
ws_config_free(WsConfig * self)
{
    if (self)
    {
        ws_list_empty(self->priv->list);
        ws_list_free(self->priv->list);
        free(self->priv);
        free(self);
        *((void**) &self) = NULL;
    }
}


WsSize
ws_config_get_lines(WsConfig * self)
{
    return ws_list_get_count(self->priv->list);
}


/* read methods
 *************************************************************************** */

WsStatus
ws_config_read(WsConfig * self, const WsChar * file)
{
    FILE         * fd;
    WsChar         line[ cMaxLength + 1 ];
    WsStatus       s = wsSuccess;
    WsList       * stack = ws_list_new(3);

    WsConfigLine  * l;

    fd = fopen(file, "r");
    if (!fd) return wsOpenFileError;


    while(fgets(line, cMaxLength, fd))
    {
        /* printf("read config line %s\n", line); */
        s = ws_config_read_line(self, line, &l, stack);

        if (l->key && !l->value) /* new node */
        {
            l->node_id = ++self->priv->max_id;
            ws_list_push(stack, l);
        }

        /*
        if (l)
            printf(
                "%d:\t%d\t%d\t%d\t%d\t%s = %s;\tc=%s\n",
                l->node_id,
                l->indent[0],
                l->indent[1],
                l->indent[2],
                l->indent[3],
                (l->key) ? l->key : "NULL",
                (l->value) ? l->value : "NULL",
                (l->comment) ? l->comment : "NULL"
            );
        */


        if (s != wsSuccess)
            break;
    }
    /*    printf("read finish\n"); */

    fclose(fd);

    ws_list_free(stack);
    self->priv->root = 0;

    return s;
}


const WsString
ws_config_get_string(WsConfig * self, const WsChar * key, const WsChar * fb)
{
    WsConfigLine * l = NULL;
    WsSize        c = 0;

    l = ws_config_get_root(self, &c);

    WsConfigFind selwh;

    selwh.key  = key;
    selwh.root = l;

    l = ws_list_find( self->priv->list, _find, &selwh, &c);

    return (const WsString) ((l && l->value) ? l->value : fb);
}


int
ws_config_get_integer(WsConfig * self, const WsChar * key, WsInt fb)
{
    WsInt    result = 0;
    const WsChar * value = ws_config_get_string(self, key, "");

    result = strtol(value, NULL, 10);
    if (!result && strcmp(value, "0")) result = fb;

    return result;
}

bool
ws_config_get_boolean(WsConfig * self, const WsChar * key, WsBool fb)
{
    const WsChar * value = ws_config_get_string(
            self, key, (fb) ? lwConfigTrue : lwConfigFalse
    );

    return (strcmp(value, lwConfigTrue)==0) ? true : false;
}


bool
ws_config_set_root(WsConfig * self, const WsChar * root)
{
    if (!root)
    {
        self->priv->root = 0;
        return true;
    }

    WsSize         i = 0;
    WsConfigLine  * l = ws_config_get_root(self, &i);
    WsConfigFind    find = {root, NULL};

    i = (l) ? i+1 : 0;
    
//    printf ("start @ %d", i);
    l = ws_list_find(self->priv->list, _find, &find, &i);



    if (!l)
    {
        self->priv->root = 0;
        return false;
    }
    
    self->priv->root = l->node_id;
    return true;
}


/* write methods
 *************************************************************************** */
WsStatus
ws_config_write(WsConfig * self, const WsChar * file)
{
    FILE          * fd;
    WsChar            line[ cMaxLength + 1 ];
    WsChar          * p;
    WsChar          * k;
    WsInt             i, c=ws_list_get_count(self->priv->list);
    WsConfigLine * l;

    fd = fopen(file, "w");
    if (!fd) return wsOpenFileError;

    for (i=0; i<c; i++)
    {
        p = line;

        l = ws_list_get_item(self->priv->list, i);

        memset(p, ' ', l->indent[0]);
        p += l->indent[0];

        if (l->key)
        {
            k = strrchr(l->key, '.');
            k = (!k) ? l->key : k+1;
            strcpy(p, k);
            p += strlen(k);

            if (!l->value)
            {
                *(p++) = ':';
            }
            else
            {
                memset(p, ' ', l->indent[1]);
                p += l->indent[1];
                *(p++) = '=';
            }
            memset(p, ' ', l->indent[2]);
            p += l->indent[2];

            if (l->value)
            {
                if (l->value)
                    strcpy(p, l->value);
                p += ws_string_get_length(l->value);
            }
        }

        if (l->comment)
        {
            memset(p, ' ', l->indent[3]);
            p += l->indent[3];
            if (l->comment)
                strcpy(p, l->comment);
            p+= ws_string_get_length(l->comment);
        }
        *(p++) = '\n';
        *(p)   = '\0';

        fputs(line, fd);
    }

    fclose(fd);

    return wsSuccess;
}


void
ws_config_set_string(WsConfig * self, const WsChar * key, const WsChar * value)
{
    WsSize           i=0;
    WsConfigLine    * l, * root=ws_config_get_root(self, &i);

    WsConfigFind    find = {key, root};


    l = ws_list_find(self->priv->list, _find, &find, &i);

    if (!l)
    {
        ws_config_get_insert_position(self, NULL, &i);

        l = calloc(1, sizeof(WsConfigLine));
        ws_string_set(&l->value, value);
        if (root)
        {
            ws_string_join(&l->key, "", root->key, ".", key, NULL);
            /*
            l->key = ws_string_new_with_size(
                 ws_string_get(root->key),
                 ws_string_get_length(root->key)+strlen(key)+1
            );
            ws_string_append(l->key, ".");
            ws_string_append(l->key, key);
            */
            l->indent[0] = root->indent[0]+4;
            l->node_id   = root->node_id;
        }
        else ws_string_set(&l->key, key);

        l->indent[1]=1;
        l->indent[2]=1;
        ws_list_insert(self->priv->list, l, i);
        //printf("<<< %s=%s @ %u:%u:%u\n", key, value, i, l->node_id, l->indent[0] & 0xFF);
    }
    else
        ws_string_set(&l->value, value);

}


void
ws_config_set_integer(WsConfig * self, const WsChar * key, WsInt value)
{
    WsChar buffer[10+1];

    sprintf(buffer, "%d", value);

    ws_config_set_string(self, key, buffer);
}


void
ws_config_set_boolean(WsConfig * self, const WsChar * key, WsBool value)
{
    ws_config_set_string(self, key, (value)?lwConfigTrue:lwConfigFalse);
}


/* node name has to be full name
 * new node will be set as current
 * */

void
ws_config_add_node(WsConfig * self, const WsChar * name)
{
    WsConfigLine    * l = calloc(1, sizeof(WsConfigLine));
    WsSize           i=0;

    l->indent[0] = ws_config_get_insert_position(self, name, &i);

    ws_string_set(&l->key, name);
    l->node_id = ++self->priv->max_id;
    l->indent[1] = 1;
    l->indent[2] = l->indent[1];

    ws_list_insert(self->priv->list, l, i);

    self->priv->root = l->node_id;
}



/* static
 *************************************************************************** */

static WsStatus
ws_config_read_line( WsConfig      * self,
                      WsChar           * line,
                      WsConfigLine ** l,
                      WsList        * stack )
{
//    printf ("<<< %s", line);
    WsInt             i = strlen(line)-1; /* pointer to current indent counter */
    WsChar          * p = line;           /* line iterator */
    WsChar          * b = NULL;           /* pointer to begin of word */
    WsChar            save;               /* variable to save character */
    WsConfigLine * node;




    *l = calloc(1, sizeof(WsConfigLine));
    ws_list_append(self->priv->list, *l);

    if (line[ i ] != '\n') return wsConfigSyntaxError;
    line[ i ] = 0;
    i = 0;

    /* indent */
    while ((*p == ' ' || *p == '\t') && *(p++)) (*l)->indent[SHIFT]++;



    if (*p==0) return wsSuccess;

    /* key */
    b = p;
    p += strcspn(b, ";:= ");

    /* if first symbol after indent is a stop symbol(could not be space) */
    if (b == p)
    {
        /* we have line with command */
        if (*p == ';')
        {
            ws_string_set(&(*l)->comment, b);
            return wsSuccess;
        } 
        else
            return wsConfigSyntaxError;
    }

    /* find root node */

    while (1)
    {
        node = ws_list_get_item(stack, ws_list_get_count(stack)-1);
        if (!node) break;

        if (node->indent[SHIFT] >= (*l)->indent[SHIFT])
        {
            ws_list_pop(stack);
        }
        else
            break;
    }

    if (node)
    {
        ws_string_join(&(*l)->key, "", node->key, ".", NULL);
        (*l)->node_id = node->node_id;
    }
    else
        ws_string_set(&(*l)->key, "");


    /* we have boundaries of key, so save it */
    save = *p;
    *p = 0;
    ws_string_append(&(*l)->key, b, 0);
    *p = save;

    (*l)->indent[EQUAL] += strcspn(p, ":=");
    p += (*l)->indent[EQUAL];

    /* check if line is over */
    if (*p == 0) return wsConfigSyntaxError;

    save = *p;

    p++;

    while ((*p == ' ' || *p == '\t') && *(p++)) (*l)->indent[VALUE]++;

    b = p;

    p = strchr(b, ';');

    /* save value */
    if (save == '=')
    {
        if (p)
        {
            i = 0;
            save = *p;
            *p = 0;
        }
        ws_string_set(&((*l)->value), b);
        (*l)->indent[COMNT] = ws_string_chop((*l)->value);
        if (p) *p = save;
    }
    else
    {
        if(!p) return wsSuccess;
        else if (p != b) return wsConfigSyntaxError;
    }

    if (p && *p == ';')
    {
        ws_string_set(&(*l)->comment, p);
    }



    return wsSuccess;
}


WsByte
ws_config_get_insert_position( WsConfig    * self, 
                               const WsChar  * key,
                               WsSize        * line )
{
    WsByte indent = 0;
    WsConfigFind    find; /* = {key, root}; */
    WsConfigLine    * l, * root=NULL;

    /*printf("<< key %s\n", key);*/

    root = ws_config_get_root(self, line);
    

    if (root)
    {
        /*printf("<< root @ %d:%d\n", root->node_id, *line);*/
        indent = root->indent[0]+4;
    }

    find.key  = key;
    find.root = root;
    (*line)++;

    if (find.key)
    {
        l = ws_list_find(self->priv->list, _find, &find, line);
        
        if(l) printf("<< same key @ %d\n", *line);

        if (!l) find.key = NULL;
    }

    if (!find.key && !find.root)
    {
        *line = ws_list_get_count(self->priv->list);
        return 0;
    }

    /* need last occurance of this key */
    l = ws_list_find(self->priv->list, _find_last, &find, line);
    
    if (!l) (*line)++;
        
    /*printf("<< result @ %d\n", *line);*/

    return indent;
}


static WsConfigLine *
ws_config_get_root( WsConfig  * self, WsSize * line )
{
    WsConfigLine    * root=NULL;

    *line = 0;

    if (self->priv->root)
        root = ws_list_find( self->priv->list,
                              _find_node,
                              &self->priv->root,
                              line );

    if (!root) *line = 0;

    return root;
}


static void *
_find(void * item, void * argument, WsBool * stop)
{
    WsConfigLine * line = item;
    if (!line) return NULL;
    if (!line->key) return NULL;

    WsConfigFind * find = (WsConfigFind *) argument;
    WsInt             shift = 0;

    if (find->root)
    {
//        printf("root selwh\n");
//???        if (line->node_id != find->root->node_id) return NULL;
        shift = strlen(find->root->key)+1;
    }

    /*printf("compare %s and %s \n", &key[shift], find->key);*/
    if (strcmp (&line->key[shift], find->key)==0)
        return item;

    return NULL;
}


static void *
_find_node(void * item, void * argument, WsBool * stop)
{
    WsConfigLine * line = item;

    return (line->node_id == *((WsInt *)argument)) ? item : NULL;
}


static void
_free_line( WsConfigLine * line )
{
    if (line)
    {
        if (line->key)     ws_string_free(line->key);
        if (line->value)   ws_string_free(line->value);
        if (line->comment) ws_string_free(line->comment);
        free(line);
        *((void **)&line) = NULL;
    }

}



static void *
_find_last(void * item, void * argument, WsBool * stop)
{
    WsConfigLine * line = item;
    if (!line->key) return NULL;

    WsConfigFind * find = (WsConfigFind *) argument;
    WsInt             shift = 0;

    if (find->root)
    {
        /* end of parent node - right place */
        if (line->indent[0] <= find->root->indent[0]) return item;

        shift = strlen(find->root->key)+1;
    }

    if (find->key)
    {
        /*printf("compare %s and %s \n", &key[shift], find->key); */
        if (strncmp (&line->key[shift], find->key, strlen(find->key))==0)
            return NULL;
    }

    return item;
}

#endif
