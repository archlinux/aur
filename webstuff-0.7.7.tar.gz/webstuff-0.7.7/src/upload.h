#ifndef _WS_UPLOAD_FULL_H_
#define _WS_UPLOAD_FULL_H_

#include <ws/upload.h>

void
ws_upload_generate_path(WsUpload * upload, WsChar * root, WsSize length);


#endif
