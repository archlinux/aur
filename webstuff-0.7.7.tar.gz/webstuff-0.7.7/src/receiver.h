#ifndef __WS_RECEIVER_H_
#define __WS_RECEIVER_H_

/* +-----------------------------------------------------------------------+
   | CLASS ws_parser
   +-----------------------------------------------------------------------+ */

#include <ws/types.h>
#include <ws/thread.h>

#include "module.h"

#define WS_RECEIVER_BUFFER_SIZE 0xffff

struct _WsReceiver
{
    WsThread    thread;

    /* begin parser data */
    WsByte        step;                               /* parse step flags    */
    WsSize        size;                               /* data in buffer */
    WsSize        clength;                            /* content-length */
    WsString      bound;                              /* multipart boundary */
    WsChar      * it;                                 /* buffer iterator */
    WsChar        buffer[WS_RECEIVER_BUFFER_SIZE]; /* read buffer */
    /* end parser data */
    WsCreateEvent      on_request_ready;
    WsDestroyEvent     on_request_response;
    
    WsModule  * module;
};


typedef struct _WsReceiver WsReceiver;


WsReceiver *
ws_receiver_new(WsInt index, WsModule * module);


void
ws_receiver_free(WsReceiver * self);


#endif
