#ifndef __WS_DEFINITIONS_H
#define __WS_DEFINITIONS_H

typedef unsigned int uint;

typedef unsigned char uchar;

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef MAX
#define MAX(x,y) ((x) > (y) ? (x) : (y))
#endif

#ifndef MIN
#define MIN(x,y) ((x) < (y) ? (x) : (y))
#endif





#endif
