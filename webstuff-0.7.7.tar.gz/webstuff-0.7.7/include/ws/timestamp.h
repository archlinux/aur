#ifndef _WS_DATETIME_H_
#define _WS_DATETIME_H_

#include <time.h>
#include <ws/types.h>

typedef struct tm WsTimestamp;

/* get current timestamp 
 * @param dt WsDatetime instance to save data in
 * @return WsDatetime instance, if dt=NULL, don't forget to free() result
 * */
void
ws_now(WsTimestamp * ts);


void
ws_timestamp_set_from_string(WsTimestamp * ts, WsChar * string);


void
ws_timestamp_set_string(WsTimestamp * ts, WsString * string);


void
ws_timestamp_add_seconds(WsTimestamp * ts, WsInt seconds);


WsTimestamp *
ws_timestamp_from_ascii(WsTimestamp * ts, WsChar * string);

#endif
