#ifndef _WS_LOG_H_
#define _WS_LOG_H_

/* Class WsLog
 *************************************************************************** */

#define WS_LOG_ALL  (wsLogError | wsLogAlert | wsLogState | wsLogDebug)

#include <time.h>
#include <stdarg.h>
#include <ws/types.h>



enum _WsLogLevel { wsLogDisabled = 0,
                     wsLogError    = 1,
                     wsLogAlert    = 2,
                     wsLogState    = 4,
                     wsLogDebug    = 8 };

typedef enum _WsLogLevel WsLogLevel;

typedef struct _WsLogPrivate WsLogPrivate;
typedef struct _WsLog WsLog;


typedef void (*WsLogDetailedCall)( WsPointer       thread,
                                    const WsChar  * msg,
                                    const WsChar  * details, 
                                    ...);

typedef void (*WsLogCall)(         WsPointer        thread,
                                    const WsChar   * msg,
                                    ...);

typedef void (*WsLogSaveCall)(     WsPointer        thread,
                                    WsLogLevel       level,
                                    const WsChar   * msg,
                                    ...);

struct _WsLog
{
    WsLogDetailedCall    error;
    WsLogDetailedCall    alert;
    WsLogCall            state;
    WsLogCall            debug;
    WsLogSaveCall        save;

    WsLogPrivate    * priv;
};


extern WsLog * stdlog;

/* creates new object of WsLog
 * @return new object of WsLog
 * */
WsLog *
ws_log_new(const WsString * name, const WsVersion * version);


/* clear resources used by WsLog
 * @param self WsLog object
 * */
void
ws_log_free(WsLog * self);


/* set log level of WsLog object
 * @param self WsLog object
 * @param level bit mask of WsLogLevel constants
 * */
void
ws_log_set_level(WsLog * self, WsInt level);


/* get log level of WsLog object
 * @param self WsLog object
 * @return log level
 * */
int
ws_log_get_level(WsLog * self);


/* set output file for WsLog object. 
 * If file = NULL, stdout and stderr will be used
 * @param self WsLog object
 * @param file null-terminated string with path to file
 * @return true if log file was opened sucessfully, other case false
 * */
WsBool
ws_log_set_file(WsLog * self, WsChar * file);


/* get output file using by WsLog object
 * @param self WsLog object
 * @return null-terminated string with path to file
 * */
WsChar *
ws_log_get_file(WsLog * self);


/* save formated message to log
 * @param self WsLog object
 * @param level defines level of logging message
 * @param message formated null-terminated string to be logged
 * @param arg standard va_list of passed arguments
 * */
void
ws_log_save( WsLog * self,
              WsLogLevel level, 
              const WsChar * message, 
              va_list arg );



#endif
