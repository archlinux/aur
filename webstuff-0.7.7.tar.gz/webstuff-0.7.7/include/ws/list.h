#ifndef _WS_LIST_
#define _WS_LIST_

#include <ws/types.h>

#define WS_LIST(x) ((WsList *)x)

/* WsList is quite imortant and wide used component. As it is obvious
 * from its name, WsList is a container for void* items.
 *
 * IMPORTANT NOTES:
 * @property size is a number of bytes allocated for list
 * @property count is a number of initiated items
 *
 * List can contain NULL pointers as any other.
 *
 * If whole allocated memory will be used by items, inserting of new one will
 * extend WsList size automaticaly
 *
 * -DSTACK enables pop and push methods:      ws_lists.o
 * -DQUEUE enables append and shift methods:  ws_listq.o
 *  Both directives enable everything:        ws_listqs.o
 *  None keeps only default WsList methods:  arc-list.o
 *
 * */

typedef struct _WsList             WsList;
typedef struct _WsListPrivate      WsListPrivate;
typedef enum   _WsListDirection    WsListDirection;


/* pointer to function that free memory used by item
 * @param item pointer to item to be free()
 * */
typedef void   (*WsListItemDestructor)(WsPointer item);


/* pointer to function that could change, replace or search item
 * @param item operating item
 * @param argument optional data
 * @param stop if set to true internal lookup loop will be stopped
 * @return new pointer, NULL if item does not sattisfy search condition
 * */
typedef WsPointer (*WsListCompare)(WsPointer item, WsPointer argument, WsBool * stop);


enum _WsListDirection { WsListFirstToLast, WsListLastToFirst };



struct _WsList
{
    WsListPrivate      * priv;
    WsListItemDestructor free_item;
};



/* creates new WsList object
 * @param size initial number or void* pointer that could be stored in list
 * @return new WsList object
 * */
WsList *
ws_list_new(WsSize   size);


/* free resources alloceted for WsList object, but do not touch items
 * @param self WsList object
 * */
void
ws_list_free(WsList * self);



/* free resources used by items with WsListItemDestructor free_item
 * @param self WsList object
 * */
void
ws_list_empty(WsList * self);



/* remove all NULL pointers from list and rearrange it
 * @param self WsList object
 * */
void
ws_list_clean(WsList * self);



/* set default destructor function for list items
 * @param self WsList object
 * */
void
ws_list_set_item_destructor(WsList * self, WsListItemDestructor free_item);



/* set new size of list,
 * so more memory will be allocated or unused will be free
 * @param self WsList object
 * */
void
ws_list_set_size(WsList * self, WsSize size);



/* get size of list
 * @param self WsList object
 * @return number of pointers that could be stored in WsList
 * */
WsSize
ws_list_get_size(WsList * self);



/* get number or initiated items in WsList
 * @param self WsList object
 * @return number or initiated items in WsList
 * */
WsSize
ws_list_get_count(WsList * self);



/* set new item at index position
 * @param self WsList object
 * @param index position where item has to be stored (must be < list size)
 * @item pointer to item that must be stored in list
 * */
void
ws_list_set_item(WsList * self, WsSize index, WsPointer item);



/* get item from some position of WsList
 * @param self WsList object
 * @param index position where item is stored (must be < list size)
 * @return  pointer to item that is stored in list or NULL if bad index
 * */
WsPointer
ws_list_get_item(WsList * self, WsSize index);




/* find item in list
 * @param self WsList object
 * @param comparer function that will return not-null value on found item
 * @param argument additional data that will be passed to comparer
 * @param position pointer where position of found item has to be stored
 * @return pointer to found item or NULL
 * */
WsPointer
ws_list_find(   WsList              * self,
                WsListCompare         comparer,
                const WsPointer       argument,
                WsSize              * position );


/* provides mass changing of whole list
 * @param self WsList object
 * @param direction defines go from first to last item or opposite direction
 * @param walker function that will operate item or return pointer to new one
 * @param argument additional data that will be passed to comparer
 * */
void
ws_list_walk(   WsList              * self,
                 WsListDirection       direction,
                 WsListCompare    walker,
                 void                 * argument );



/* insert new item into list at some position, 
 * memory will be allocated if necessary
 * @param self WsList object
 * @param item pointer to inserting item
 * @param position number from 0(prepend) to list size (append)
 * */
void
ws_list_insert( WsList              * self,
                 void                 * item,
                 WsSize               position );



/* remove item stored at some position from list
 * @param self WsList object
 * @param position of item in list
 * */
void
ws_list_remove( WsList              * self,
                 WsSize               position );



#ifdef STACK

/* for better perfomance new items will be pushed / poped at / from 
 * the end of list. 
 *
 * Using of 2 functions below grant you FILO model
 * */


/* push item into stack list
 * @param self WsList object
 * @param item that has to be pushed into stack list
 * */
void
ws_list_push(WsList *self, WsPointer item);



/* pop item out from stack list
 * @param self WsList object
 * @return pointer to popped item
 * */
WsPointer
ws_list_pop(WsList *self);

#endif

#ifdef QUEUE

/* Using of 2 functions below grant you FIFO model
 * */


/* shift item out from queue list
 * @param self WsList object
 * @return pointer to shifted item
 * */
WsPointer
ws_list_shift(WsList *self);



/* append item to queue list
 * @param self WsList object
 * @param item pointer to new item
 * */
void
ws_list_append(WsList * self, WsPointer item);


#endif


#endif
