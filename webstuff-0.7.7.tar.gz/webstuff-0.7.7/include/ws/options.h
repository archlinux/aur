#ifndef _LOWE_OPTIONS_H_
#define _LOWE_OPTIONS_H_

#include <ws/types.h>

typedef void  (*WsOptionFunc)(const WsChar * name, const WsChar * value);
typedef struct _WsOption WsOption;


struct _WsOption
{
    const WsChar      name;
    const WsChar    * type;
    const WsChar    * help;
    const WsChar    * value;
    WsOptionFunc    setup;
};



void
ws_options_set(WsOption * rules, WsInt argc, WsChar ** argv);


void
ws_options_help(const WsChar * key, const WsChar * value);


void
ws_options_version(const WsChar * key, const WsChar * value);


#endif
