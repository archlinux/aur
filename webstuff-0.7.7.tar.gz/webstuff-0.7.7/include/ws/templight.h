#ifndef __WS_TEMPLIGHT
#define __WS_TEMPLIGHT

#include <ws/types.h>
#include <ws/request.h>


enum
{
    aPlain = 1, /* data is text */
    aBlock,     /* data is block */
    aLabel,     /* data is label name */
    aLink       /* data is label name */
};

typedef struct _WsTemplight WsTemplight;


/* Constructor
 * template_name - name of template file without .tpl.html
 * root - absolute or relative path to templates folder
 * Result: a new instance of object */
WsTemplight *
ws_templight_new(const WsChar * template_name, char * root);


/* Constructor
 * Result: a new instance of object from template file */
WsTemplight *
ws_templight_new_as_block(char * block_name, int length);


const WsChar *
ws_templight_get_name(WsTemplight * self);


/* Clones template to new one
 * self - existing template
 * Result: new templight object with LINK atoms instead of PLAIN */
WsTemplight *
ws_templight_clone(WsTemplight * self);


/* Destructor
 * Ignores content of LINK atoms
 * Result: NULL */
void *
ws_templight_free(WsTemplight * self);



/* Repeates the sub block in atom
 * REsult: pointer to new block or NULL on fail */
WsTemplight *
ws_templight_new_block(WsTemplight * self, const char * block);


/* Composes one label inside block
 * Result: amount of composes */
int
ws_templight_set_string(WsTemplight * self, const char * label, const char * value);


int
ws_templight_set_int(WsTemplight * self, const char * label, const int value);


int
ws_templight_set_float(WsTemplight * self, const char * label, const float value);

int
ws_templight_set_block(WsTemplight * self, const char * label, WsTemplight * value);

/* Composes count of labels inside block
 * Result: amount of composes */
int
ws_templight_compose(WsTemplight * self, WsPair * label, int count);


/* Resets templight to default
 * Result: void
void
ws_templight_reset(ws_templight * self);
*/


/* Outputs templight
 * Result: void */
void
ws_templight_out(WsTemplight * self, WsRequest * wsr);

void
ws_templight_dump(WsTemplight * self);





#endif
