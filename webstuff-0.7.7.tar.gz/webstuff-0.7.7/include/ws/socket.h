#ifndef _WS_SOCKET_H_
#define _WS_SOCKET_H_

#include <stdbool.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <ws/status.h>
#include <ws/types.h>


#define WS_SOCKET_ERROR -1

typedef struct _WsSocketPriv WsSocketPriv;

typedef struct
{
    WsSocketPriv * priv;
} WsSocket;


/* Create new object of WsSocket
 * @param open if true socket will be opened in system
 * @return WsSocket object
 * */
WsSocket *
ws_socket_new();


/* free resources used by WsSocket
 * @param self WsSocket object
 * */
void
ws_socket_free(WsSocket * self);


bool
ws_socket_is_open(WsSocket * self);


WsStatus
ws_socket_open(WsSocket * self);

/* close socket
 * @param self WsSocket object
 * @param shutdown if true, socket will be shutted down for read and write
 * @return arcSuccess or arcSocketError on fault
 * */
WsStatus
ws_socket_close(WsSocket * self, bool shutdown);


/* get socket host 
 * @param self WsSocket object
 * @return host
 * */
char *
ws_socket_get_host(WsSocket * self);


/* get socket port
 * @param self WsSocket object
 * @return port
 * */
int
ws_socket_get_port(WsSocket * self);


uint32_t
ws_socket_get_in_addr(WsSocket * self);


WsStatus
ws_socket_set_address(WsSocket * self, const char * host, int port);


/* bind socket to some host and port
 * @param self WsSocket object
 * @param host null-terminated string with IP or hostname
 * @param port number of port
 * @return arcSuccess or arcAddressError or arcSocketError on fault
 * */
WsStatus
ws_socket_bind(WsSocket * self);


#ifdef CLIENT
/* connect socket to some remote host and port
 * @param self WsSocket object
 * @param host null-terminated string with IP or hostname
 * @param port number of port
 * @return arcSuccess or arcSocketError on fault
 * */
WsStatus
ws_socket_connect(WsSocket * self, const char * host, int port);
#endif


#ifdef SERVER
/* try to accept new connection from server socket
 * @param self WsSocket object of server socket
 * @return new client WsSocket object or NULL if noone connected
 * */
WsStatus
ws_socket_accept(WsSocket * self, WsSocket ** client);


/* start listening of socket on some local host and port
 * @param self WsSocket object
 * @param host null-terminated string with IP or hostname
 * @param port number of port
 * @return arcSuccess or arcSocketError on fault
 * */
WsStatus
ws_socket_listen(WsSocket * self);
#endif



/* read data from socket
 * @param self WsSocket object
 * @param buffer pointer to data has to be sent
 * @paramn length number of bytes to be sent
 * @return number of read bytes
 * */
int
ws_socket_read(WsSocket * self, char * buffer, int length);


/* send data through socket
 * @param self WsSocket object
 * @param buffer pointer to data has to be sent
 * @paramn length number of bytes to be sent
 * @return number of bytes sent, or -1 on fail
 * */
int
ws_socket_send(WsSocket * self, const WsChar * buffer, int length);


const char *
ws_socket_get_last_error();

#endif
