#ifndef _WS_STRING_H_
#define _WS_STRING_H_

#include <ws/types.h>

enum _WsReplaceOptions
{
    wsReplaceAll
};

typedef WsByte WsReplaceOptions;


/* set length of string;
 * if *target==NULL, memory will be allocated;
 * if size of source string is less than length, memory will be reallocated;
 * if memory is enough, just NULL byte will be set on length position
 * @param target pointer to target string
 * @param length amount of bytes for new string
 * */
void
ws_string_set_length(WsString * target, WsSize length);


/* free resources used by string
 * @param str pointer to string to be freed
 * */
void
ws_string_free(WsString str);


/* set string with new vlue
 * @param target string to keep new value, if target points to zero, new string
 * will be created
 * @param source initial string to be written in target
 * */
void
ws_string_set(WsString * target, const WsChar * source);


/* set string with new vlue
 * @param target string to keep new value, if target points to zero, new string
 * will be created
 * @param source initial string to be written in target
 * @param size number of bytes from source to be written to target, 0 = all
 * */
void
ws_string_copy(WsString * target, const WsChar * source, WsSize size);


/* get length of null-terminated string
 * @param str source string
 * @return number of characters in string
 * */
WsSize
ws_string_get_length(const WsString str);


/* get size of memory allocated for string. works only for strings created
 * by functions of this module
 * @param str source string
 * @return size of allocated memory
 * */
WsSize
ws_string_get_size(WsString str);


/* set target string with ASCII representation of HEX source buffer, each
 * byte in target string will be separated with space. Necessary length
 * of target string could be counted as (3*size - 1)
 * @param target string to keep result sequence.
 * @param source buffer of bytes
 * @param size number of bytes from buffer
 * */
void
ws_string_set_from_hex(WsString * target, const WsChar * source, WsSize size);


/* append one string to another one. Be careful, function will check how many
 * bytes were allocated. It is possible only if base string was created with
 * functions of this module
 * @param base pointer to string to which you append
 * @param appendix string to be appended
 * */
void
ws_string_append(WsString * base, const WsChar * appendix, WsSize size);


/* joins number of WsStrings into new one, using pattern as a splitter
 * @param target string. must be freed.
 * @param pattern string with splitter,
 * @param ... const WsString  to be joined. stop sequence with NULL
 * @param resulting string
 * */
void
ws_string_join(WsString * target, const WsChar * pattern,  ...);


/* replace pattern from haystack to needle
 * @param haystack source string
 * @param pattern  replace mask
 * @param needle   for what to replace patten
 * @param options  for future needs
 * @return new string, must be freed 
 * */
WsString
ws_string_replace( const WsChar      * haystack,
                   const WsChar      * pattern,
                   const WsChar      * needle,
                   WsReplaceOptions    options);


/* remove all space in the begining and in the end of string
 * @param str string to be chopped 
 * */
WsSize
ws_string_chop(WsString str);

#endif
