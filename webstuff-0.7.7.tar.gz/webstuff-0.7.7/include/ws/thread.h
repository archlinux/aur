#ifndef _WS_THREAD_H_
#define _WS_THREAD_H_

#include <pthread.h>
#include <stdbool.h>
#include <ws/log.h>

/* Class WsThread
 *************************************************************************** */

#define WS_THREAD(x) ((WsThread*)x)

typedef struct _WsThreadPriv WsThreadPriv;
typedef struct _WsThread     WsThread;

typedef void (*WsThreadFunction)(WsThread * self);
typedef void (*WsThreadEvent)(WsThread * self, void * data);

struct _WsThread
{
    void            (* execute)(WsThread * self);
    WsThreadEvent      on_start;
    WsThreadEvent      on_stop;

    WsThreadPriv     * priv;
};

#ifdef WIN32

typedef CRITICAL_SECTION WsMutex;

#else

typedef pthread_mutex_t WsMutex;

#endif




/* WsThread constructor
 * @param self WsThread object
 * */
void
ws_thread_init(WsThread * self);


/* WsThread destructor
 * @param self WsThread object
 * */
void
ws_thread_free(WsThread * self);


/* set WsThread name property
 * @param self WsThread object
 * @param value new name or NULL for empty
 * */
void
ws_thread_set_name(WsThread * self, const char * value);


/* set WsThread name property in format "name #index"
 * @param self WsThread object
 * @param value new name or NULL for empty
 * @param index index for name, if 0 index will be ignored
 * */
void
ws_thread_set_name_and_index(WsThread * self, const char * value, int index);


/* get WsThread name property
 * @param self WsThread object
 * @return null-terminated string with name
 * */
char *
ws_thread_get_name(WsThread * self);


/* set WsLog object to be used by WsThread
 * @param self WsThread object
 * @param log WsLog object
 * */
/*
void
ws_thread_set_log(WsThread * self, WsLog * log);
*/

/* get WsLog object to be used by WsThread
 * @param self WsThread object
 * @return WsLog object
 * */
/*
WsLog *
ws_thread_get_log(WsThread * self);
*/

/* write detailed message in format "thread name: message" with custom level
 * using WsLog object from appropriyte property of WsThread.
 * if log object is not set, message will be ignored
 * @param self WsThread object
 * @param level WsLogLevel
 * @param message formated null-terminated string
 * */
/*
void
ws_thread_log( WsThread  * self,
                WsLogLevel  level,
                const char * message, ...);
*/


/* write detailed error message in format "thread name: message (details)" 
 * using WsLog object from appropriyte property of WsThread.
 * if log object is not set, message will be ignored
 * @param self WsThread object
 * @param message formated null-terminated string
 * @param detail  null-terminated string with detailed information about error
 * */
/*
void
ws_thread_log_error( WsThread  * self,
                      const char * message,
                      const char * detail , ...);

*/
/* write detailed warning message in format "thread name: message (details)" 
 * using WsLog object from appropriyte property of WsThread.
 * if log object is not set, message will be ignored
 * @param self WsThread object
 * @param message formated null-terminated string
 * @param detail  null-terminated string with detailed information about alert
 * */
/*
void
ws_thread_log_alert( WsThread  * self,
                      const char * message,
                      const char * detail, ...);

*/
/* write state message in format "thread name: message" 
 * using WsLog object from appropriyte property of WsThread.
 * if log object is not set, message will be ignored
 * @param self WsThread object
 * @param message formated null-terminated string
 * */
/*
void
ws_thread_log_state(WsThread * self, const char * message, ...);
*/

/* write debug message in format "thread name: message" 
 * using WsLog object from appropriyte property of WsThread.
 * if log object is not set, message will be ignored
 * @param self WsThread object
 * @param message formated null-terminated string
 * */
/*
void
ws_thread_log_debug(WsThread * self, const char * message, ...);
*/

/* start thread. on fault write appropriate message to log
 * @param self WsThread object
 * @return 0 if success, postive value in case of error.
 * */
int
ws_thread_start(WsThread * self);


/* send stop signal to thread. on successfull exit appropriate message will 
 * be written to log
 * @param self WsThread object
 * */
void
ws_thread_stop(WsThread * self);


/* wait until thread terminated
 * @param self WsThread object
 * */
void
ws_thread_wait(WsThread * self);


/* get terminated state
 * @param self WsThread object
 * @return true if thread is terminated, false if not
 * */
bool
ws_thread_is_terminated(WsThread * self);



bool
ws_thread_is_stopped(WsThread * self);

/* check if thread is working. if not, check if there was error and write
 * appropriate message to log.
 * @param self WsThread object
 * @return true if thread is terminated, false if not
 * */
bool
ws_thread_checkout(WsThread * self);


WsChar **
ws_thread_get_pname(WsThread * self);



int
ws_mutex_init(WsMutex * mutex);


int
ws_mutex_destroy(WsMutex * mutex);


int
ws_mutex_lock(WsMutex * mutex);


int
ws_mutex_unlock(WsMutex * mutex);






#endif
