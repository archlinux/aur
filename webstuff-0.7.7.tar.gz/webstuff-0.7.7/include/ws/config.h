#ifndef _LOWE_CONFIG_H_
#define _LOWE_CONFIG_H_

/* WsConfig class operates with configuration files with Löwenware syntax.
 * It allows both: to read and to write your settings to text files.
 *
 * Löwenware Configuration Syntax:
 * 1. Comments. Everything that follow semicolon sign is a comment
 * 2. Nodes. Node defines group of parameters. Node name must begin from new
 *    line and colon sign must follow it
 * 3. Parameters and values. Must start from new line and end up on it. 
 *    Parameter should be splitted from value with equal sign.
 * 4. Indents are important. The define ownership of parameters and values to
 *    some node.
 *
 * ; + BEGIN EXAMPLE CONFIG ---------------------------------------------------
 * name = default config
 * file = lw/config.h
 * example:                             ; this is node
 *     indent = 4                       ; indent for this node is 4 spaces
 *     aim = demonstrate config usage
 *     syntax = strict
 *     speed  = fast
 * ; + END EXAMPLE CONFIG ---------------------------------------------------
 *
 * Tips:
 * 1. Reading and Writing of config will save indents and comments
 * 2. Do not keep WsConfig instance in memory all the time. Use it to read
 *    settings, pass it to necessary components of your program and free used
 *    resources.
 *
 * */

#include "status.h"
#include "types.h"

typedef struct _WsConfigPrivate WsConfigPrivate;
typedef struct _WsConfig        WsConfig;

struct _WsConfig
{
    WsConfigPrivate * priv;
};

/* create new empty instance of WsConfig
 * @return new WsConfig object
 * */
WsConfig *
ws_config_new();


/* free resources used by WsConfig object
 * @param self WsConfig object
 * */
void
ws_config_free(WsConfig * self);


/* get line number. can be used it in case of read error
 * @param self WsConfig object
 * @return line number
 * */
WsSize
ws_config_get_lines(WsConfig * self);


/* read methods
 *************************************************************************** */

/* read configuration from file
 * @param self WsConfig object
 * @param file null-terminated string with path to file
 * @return lwSuccess or lwReadFileError
 * */
WsStatus
ws_config_read(WsConfig * self, const WsChar * file);


/* get param as a string
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param fb null-terminated string with fallback value
 * @return null-terminated string with value
 * */
const WsString
ws_config_get_string(WsConfig * self, const WsChar * key, const WsChar * fb);


/* get param as an integer
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param fb fallback value
 * @return key value
 * */
int
ws_config_get_integer(WsConfig * self, const WsChar * key, WsInt fb);


/* get param as WsBoolean
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param fb fallback value
 * @return key value
 * */
WsBool
ws_config_get_boolean(WsConfig * self, const WsChar * key, WsBool fb);


/* change root to some child node. if same node requested, function works as 
 * an iterator. Use relative keys to access settings
 * @param self WsConfig object
 * @param key null-terminated string with node name, NULL for top level
 * @return true if node exists or false
 * */
WsBool
ws_config_set_root(WsConfig * self, const WsChar * root);

/* write methods
 *************************************************************************** */

/* write configuration to file
 * @param self WsConfig object
 * @param file null-terminated string with path to file
 * @return lwSuccess or lwWriteFileError
 * */
WsStatus
ws_config_write(WsConfig * self, const WsChar * file);


/* set key value
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param value null-terminated string with key value
 * */
void
ws_config_set_string(WsConfig * self, const WsChar * key, const WsChar * value);


/* set key value
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param value key value
 * */
void
ws_config_set_integer(WsConfig * self, const WsChar * key, WsInt value);


/* set key value
 * @param self WsConfig object
 * @param key null-terminated string with key name
 * @param value key value
 * */
void
ws_config_set_boolean(WsConfig * self, const WsChar * key, WsBool value);


/* add node to config
 * @param self WsConfig object
 * @param name null-terminated string with node name
 * */
void
ws_config_add_node(WsConfig * self, const WsChar * name);


#endif
