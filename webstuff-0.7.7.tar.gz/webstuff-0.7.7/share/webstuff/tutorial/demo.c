#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <time.h>
#include <sys/types.h> // struct passwd
#include <pwd.h>       // getpwnam

#include <ws/webstuff.h>

#define DEFAULT_USER    NULL /*"lowenware"*/
#define DEFAULT_PIDFILE "/tmp/webstuff_demo.pid"
#define DEFAULT_LOG     "/tmp/webstuff_demo.log"
#define DEFAULT_HOST    "0.0.0.0"
#define DEFAULT_PORT    8088
#define DEFAULT_THREADS 8
#define KILL_TIMEOUT    10

WsModule * module;
WsVersion  version = {3, 0, RELEASE, BUILD};

// start program
static int  start           (int argc, char ** argv);
// stop program
static int  stop            ();
// daemonize = save pidfile + setuid to user + fork to background
static void daemonize       (char * pidfile, char * username);
// handles SIGTERM, SIGHUP etc
static void signal_handler  (int signal);



int
main (int argc, char ** argv)
{
    // vars
    struct sigaction    sa;

    memset (&sa, '\0', sizeof(sa));
    sa.sa_handler = signal_handler;
    sa.sa_flags   = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaddset(&sa.sa_mask, SIGHUP);
    sigaddset(&sa.sa_mask, SIGTERM);
    sigaddset(&sa.sa_mask, SIGINT);
    sigaddset(&sa.sa_mask, SIGPIPE);

    if (sigaction(SIGHUP, &sa, NULL) == -1) 
        perror("Error: cannot handle SIGHUP"); // Should not happen

    if (sigaction(SIGTERM, &sa, NULL) == -1) 
        perror("Error: cannot handle SIGTERM"); // Should not happen

    if (sigaction(SIGINT, &sa, NULL) == -1) 
        perror("Error: cannot handle SIGINT"); // Should not happen
    
    if (sigaction(SIGPIPE, &sa, NULL) == -1) 
        perror("Error: cannot handle SIGPIPE"); // Should not happen


    // start service
    return start(argc, argv);
}


static int start (int argc, char ** argv)
{
    int ecode;

    if (argc > 1 && strcmp(argv[1], "-d")==0)
        daemonize(DEFAULT_PIDFILE, DEFAULT_USER);

    // configuration
    module = ws_module_new("webstuff.demo", &version);



    //settings
    ecode = (ws_module_set_log(module, DEFAULT_LOG, WS_LOG_ALL )) ?
        EXIT_FAILURE : EXIT_SUCCESS;

    ws_module_set_socket(  module, DEFAULT_HOST, DEFAULT_PORT );
    ws_module_set_threads( module, DEFAULT_THREADS );

    if (ecode == EXIT_SUCCESS)
        ws_module_start(module);

    ws_module_free(module);

    return ecode;
}

static int stop ()
{
    int     result=EXIT_FAILURE;
    time_t  ts;
    int     diff=-1;

    time(&ts);

    if (module)
    {
        stdlog->state(
                WS_THREAD(module), "shutting down all threads");
        ws_module_stop(module);

        while(diff < KILL_TIMEOUT)
        {
            if (diff < difftime(time(NULL), ts))
            {
                stdlog->state(
                    WS_THREAD(module), "force exit in %ds", KILL_TIMEOUT-diff-1);
                diff++;
            }

            if (ws_module_is_terminated(module))
            {
                stdlog->state( WS_THREAD(module), "normal exit");
                result = EXIT_SUCCESS;
                break;
            }

            ws_sleep(100);
        }

        if (result == EXIT_FAILURE)
                stdlog->error( WS_THREAD(module), 
                    "force exit (some threads was not terminated in "
                    "%d seconds timeout)", NULL,  KILL_TIMEOUT);
        ws_module_free(module);
    }
    else
        result = EXIT_SUCCESS;

    return result;
}

static void signal_handler (int signal)
{
    switch (signal)
    {
        case SIGHUP:
            if (module)
                stdlog->state(
                    WS_THREAD(module), "<< SIGHUP [%d]: reconfigure", signal);
            break;
        case SIGPIPE: // ignore SIGPIPE due to stability
            if (module)
                stdlog->state(
                    WS_THREAD(module), "<< SIGPIPE [%d]: ignore", signal);
            break;
        default:
            if (module)
                stdlog->state(
                    WS_THREAD(module), "<< SIGNAL [%d]: terminate", signal);
            exit(stop());
    }
}


static void daemonize (char * pidfile, char * user)
{
    FILE * pidfd;
    pid_t  pid;
    struct passwd * pswd;
 
    // fork to background
    if( (pid=fork()) < 0)
    {
        perror("could not fork to background\n");
        exit(EXIT_FAILURE);
    }
    else if (pid!=0)
    {
        // check pid file
        if (access(pidfile, 0) != -1)
        {
            printf("pid file '%s' exists. Already running?", pidfile);
            exit(EXIT_FAILURE);
        }
        // write pid file
        pidfd = fopen(DEFAULT_PIDFILE, "w+");
        if (!pidfd)
        {
            printf("could not create pid file '%s':%s", 
                    pidfile, strerror(errno));
            kill(pid, SIGTERM);
            exit(EXIT_FAILURE);
        }
        fprintf(pidfd, "%d", pid);
        fclose(pidfd);

        exit(EXIT_SUCCESS);
    }
    setsid();
    // set user
    if (user)
    {
        pswd = getpwnam(user);
        if (!pswd)
        {
            printf("could not get UID of user '%s': %s",
                    user, strerror(errno));
            exit(EXIT_FAILURE);
        }
        if (setuid(pswd->pw_uid))
        {
            printf("could not setuid() to user '%s:%d': %s",
                    user, pswd->pw_uid, strerror(errno));
            exit(EXIT_FAILURE);
        }
    }
}


