<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ro">
<context>
    <name>MainWindow</name>
    <message>
        <source>KEncFs - (c) 2010 by Felice Murolo - Salerno - Italia</source>
        <translation type="vanished">KEncFs - (c) 2010 de Felice Murolo - Salerno - Italia</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="33"/>
        <source>Encrypted FileSystem</source>
        <translation>Sistem de fișiere criptat</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="64"/>
        <source>&amp;Add</source>
        <translation>&amp;Adaugă</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="80"/>
        <source>&amp;Remove</source>
        <translation>În&amp;lătură</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="93"/>
        <source>E&amp;dit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="122"/>
        <source>&amp;Mount</source>
        <translation>&amp;Montează</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="132"/>
        <source>&amp;Umount</source>
        <translation>&amp;Demontează</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="109"/>
        <source>&amp;Browse</source>
        <translation>&amp;Răsfoiește</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="155"/>
        <source>&amp;Hide</source>
        <translation>&amp;Ascunde</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="165"/>
        <location filename="mainwindow.ui" line="233"/>
        <source>&amp;Exit</source>
        <translation>&amp;Termină</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="vanished">&amp;Fișier</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="209"/>
        <source>&amp;Hide / Show</source>
        <translation>&amp;Ascunde / Arată</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>Hide / Show</source>
        <translation>Ascunde / Arată</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="217"/>
        <source>&amp;Config</source>
        <translation>&amp;Configurare</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="220"/>
        <source>Config</source>
        <translation>Configurare</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="225"/>
        <source>&amp;About</source>
        <translation>&amp;Despre</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="228"/>
        <source>About</source>
        <translation>Despre</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="236"/>
        <source>Exit</source>
        <translation>Termină</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <source>Easy manager for encrypted filesystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>FileSystem ID</source>
        <translation>ID sistem de fișiere</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Mount Point</source>
        <translation>Punct de montare</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Encrypted Directory</source>
        <translation>Dosar criptat</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Status</source>
        <translation>Stare</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Encfs Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Fuse Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="116"/>
        <source>Add</source>
        <translation>Adaugă</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="117"/>
        <source>Remove</source>
        <translation>Înlătură</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="118"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="119"/>
        <source>Mount</source>
        <translation>Montează</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="120"/>
        <source>Umount</source>
        <translation>Demontează</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="121"/>
        <source>Browse</source>
        <translation>Răfoiește</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="290"/>
        <source>Do really you want to remove FileSystem &apos;</source>
        <translation>Dorești într-adevăr să ștergi sistemul de fișiere &apos;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="291"/>
        <source>Remove FileSystem</source>
        <translation>Șterge sistemul de fișiere</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="356"/>
        <source>Mounted</source>
        <translation>Montat</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="375"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="521"/>
        <source>Donations</source>
        <translation>Donații</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="521"/>
        <source>Please, consider to make a &lt;a href=&apos;https://www.linux-apps.com/p/1170068/&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please, consider to make a &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="vanished">Te rog să iei în considerare o &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Donație&lt;/a&gt; pentru munca mea.
Dacă îți place această aplicație, te rog donează ceva.
Toți banii obținuți vor fi donați pentru binefacere pentru inițiativele meritorii.

</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>I couldn&apos;t detect any system tray on this system.</source>
        <translation type="vanished">Nu am putut detecta o tavă de sistem.</translation>
    </message>
</context>
<context>
    <name>configDialog</name>
    <message>
        <location filename="configdialog.ui" line="14"/>
        <source>KEncFS - Confguration</source>
        <translation>KEncFS - Configurare</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="32"/>
        <source>&amp;Browse after mount (not for AutoMount function) </source>
        <oldsource>&amp;Browse after mount</oldsource>
        <translation type="unfinished">&amp;Răsfoiește după montare</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="59"/>
        <source>&amp;Start in TrayBar</source>
        <translation>&amp;Pornește în tava de sistem</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="85"/>
        <location filename="configdialog.cpp" line="44"/>
        <source>Icon&apos;s Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="140"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="22"/>
        <source>&amp;Use KDE Wallet</source>
        <translation>Folosește Portofelul &amp;KDE</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="42"/>
        <source>&amp;Try AutoMount on start (KDE Wallet must be enabled)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fsDialog</name>
    <message>
        <location filename="fsdialog.ui" line="14"/>
        <source>KEncFs - Add FileSystem</source>
        <translation>KEncFs - Adaugă sistem de fișiere</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="32"/>
        <source>FileSystem ID</source>
        <translation>ID sistem de fișiere</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="46"/>
        <source>Mountpoint</source>
        <translation>Punct de montare</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="60"/>
        <location filename="fsdialog.ui" line="81"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="67"/>
        <source>Encrypted Directory</source>
        <translation>Dosar criptat</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="88"/>
        <source>Auto &amp;Umount after 10 mins of inactivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="95"/>
        <source>Advanced &amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="106"/>
        <source>Encfs options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="124"/>
        <source>Fuse options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fatal Error</source>
        <translation type="vanished">Eroare fatală</translation>
    </message>
    <message>
        <source>Warning! &apos;encfs&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Atenție! &apos;encfs&apos; nu este instalat.

Te rog să îl instalezi!

</translation>
    </message>
    <message>
        <source>Warning! &apos;fusermount&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Atenție! &apos;fusermount&apos; nu este instalat.

Te rog să îl instalezi!

</translation>
    </message>
    <message>
        <source>Warning! &apos;dolphin&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Atenție! &apos;dolphin&apos; nu este instalat.

Te rog să îl instalezi!

</translation>
    </message>
    <message>
        <source>Select encrypted existing directory or create new</source>
        <translation type="vanished">Alege un dosar criptat existent sau creează unul nou</translation>
    </message>
    <message>
        <source>Select mountpoint existing directory or create new</source>
        <translation type="vanished">Alege un dosar existent ca punct de montare sau creează unul nou</translation>
    </message>
    <message>
        <source>Mounted</source>
        <translation type="vanished">Montat</translation>
    </message>
    <message>
        <source>Warning! MountPoint directory doesn&apos;t exists

</source>
        <translation type="vanished">Atenție! Dosarul pentru punctul de montare nu există

</translation>
    </message>
    <message>
        <source>Warning! Encrypted directory doesn&apos;t exists

</source>
        <translation type="vanished">Atenție! Dosarul criptat nu există

</translation>
    </message>
    <message>
        <source>Password Request</source>
        <translation type="vanished">Cerere pentru parolă</translation>
    </message>
    <message>
        <source>Password for Encrypted FileSystem:</source>
        <translation type="vanished">Parola pentru sistemul de fișiere criptat:</translation>
    </message>
    <message>
        <source>Error returned from Encfs:
</source>
        <oldsource>Encfs returns:
</oldsource>
        <translation type="vanished">Eroare întors de la encfs:</translation>
    </message>
    <message>
        <source>Mount error!

</source>
        <translation type="obsolete">Eroare la montare!

</translation>
    </message>
</context>
</TS>
