package paths

import (
	"fmt"
	"log"
	"os"
	"time"

	"git.sr.ht/~nedia/nedots/internal/term"
)

// Stores information on a file.
type FileInfo struct {
	Path      string    `json:"path"`
	IsRegular bool      `json:"is_regular"`
	IsDir     bool      `json:"is_dir"`
	Name      string    `json:"filename"`
	Size      int64     `json:"size"`
	Modified  time.Time `json:"modified"`
}

// Determines if this [*FileInfo] is the same as [other] by comparing
// [FileInfo.Name], [FileInfo.Size] & [FileInfo.Modified].
func (fi *FileInfo) Equals(other *FileInfo) bool {
	return fi.Name == other.Name &&
		fi.Size == other.Size &&
		fi.Modified == other.Modified
}

// Determines if this [*FileInfo] is newer than [other].
func (fi *FileInfo) Newer(other *FileInfo) bool {
	return fi.Modified.After(other.Modified)
}

// Return terminal friendly modified string.
func (fi FileInfo) ModifiedString() string {
	return fmt.Sprintf(
		"%s\t%s",
		term.Bold.String(fi.Name),
		term.Yellow.String(fi.Modified.String()),
	)
}

// Return terminal friendly string.
func (fi FileInfo) String() string {
	return fmt.Sprintf(
		"%s\tsize: %s\tupdated: %s",
		term.Bold.String(fi.Name),
		term.Green.String(fmt.Sprint(fi.Size)),
		term.Yellow.String(fi.Modified.String()),
	)
}

// Calls [os.Open] and then [os.File.Stat] to populate [FileInfo].
//
// Fatal on [os.File.Stat] errors.
func Open(p string) (FileInfo, error) {
	file, err := os.Open(p)
	if err != nil {
		return FileInfo{}, err
	}
	defer file.Close()

	info, err := file.Stat()
	if err != nil {
		log.Fatal(err)
	}

	isRegular := info.Mode().IsRegular()
	isDir := info.IsDir()
	name := info.Name()
	if isDir {
		name = name + "/"
	}

	return FileInfo{
		Path:      p,
		Name:      name,
		IsRegular: isRegular,
		IsDir:     isDir,
		Size:      info.Size(),
		Modified:  info.ModTime(),
	}, nil
}
