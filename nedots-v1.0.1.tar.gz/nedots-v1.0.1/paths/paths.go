package paths

import (
	"errors"
	"io/fs"
	"os"
	"path/filepath"

	"git.sr.ht/~nedia/nedots/internal/term"
)

var (
	// [os.UserHomeDir]
	Home string
	// [os.UserConfigDir]
	Config string
	// [os.UserCacheDir]
	Cache string
)

func init() {
	var err error
	check := func(err error) {
		if err != nil {
			term.Fatal(err)
		}
	}

	Config, err = os.UserConfigDir()
	check(err)
	Home, err = os.UserHomeDir()
	check(err)
	Cache, err = os.UserCacheDir()
	check(err)
}

// Expects [path] to be an absolute path that can be resolved, otherwise it's
// made absolute by [filepath.Abs], or in the event of failure, [Home] is
// prepended and then checked. If all operations fail, [fs.ErrNotExist] is
// returned.
func Resolve(path string) (string, error) {
	if Exists(path) {
		return path, nil
	}

	if abs, err := filepath.Abs(path); err != nil {
		return path, err
	} else if Exists(abs) {
		return abs, nil
	}

	if homed := PrependHome(path); Exists(homed) {
		return homed, nil
	}

	return path, fs.ErrNotExist
}

// Check if a file or directory exists at path.
func Exists(path string) bool {
	_, err := os.Stat(path)
	return !errors.Is(err, os.ErrNotExist)
}

// Prepend [Home] to this path.
func PrependHome(path string) string {
	return filepath.Join(Home, path)
}

// A [Path] is just a string that can be operated on.
//
// All operations are platform agnostic.
type Path string

// Check if this [*Path] Exists on the system.
func (p *Path) Exists() bool {
	return Exists(p.String())
}

// Calls [Resolve] on this [*Path].
func (p *Path) Resolve() (string, error) {
	return Resolve(p.String())
}

// Return [Path] as a string.
func (p Path) String() string {
	return string(p)
}
