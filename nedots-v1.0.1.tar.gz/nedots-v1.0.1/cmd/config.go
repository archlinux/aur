package cmd

import (
	"fmt"
	"log"
	"os"

	"git.sr.ht/~nedia/nedots/internal/config"
	"git.sr.ht/~nedia/nedots/paths"
	"git.sr.ht/~nedia/nedots/internal/term"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var configCmd = &cobra.Command{
	Use:   "config",
	Short: "Interact with nedots config file",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println(cfg.String())
	},
}

func init() {
	rootCmd.AddCommand(configCmd)

	configCmd.AddCommand(&cobra.Command{
		Use:   "add",
		Short: "Add a path to config",
		Args:  cobra.MinimumNArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			path := args[0]
			cfg.ResolvePaths()

			// Resolve the path to prevent bad entries in config.
			resolved, err := paths.Resolve(path)
			if err != nil {
				log.Fatal(err)
			}

			// Check if config already contains this path.
			for _, p := range cfg.Paths() {
				if p == resolved {
					fmt.Println("config already contains", path)
					os.Exit(0)
				}
			}

			viper.Set("dots", append(cfg.Dots, path))
			if err := viper.WriteConfig(); err != nil {
				log.Fatal(err)
			}
		},
	})

	configCmd.AddCommand(&cobra.Command{
		Use:     "repo",
		Short:   "Add a new repo to config",
		Example: "nedots config repo git@git.sr.ht:~nedia/config.nvim ~/.config/nvim",
		Args:    cobra.ExactArgs(2),
		Run: func(cmd *cobra.Command, args []string) {
			remote := args[0]
			path := args[1]

			var input string
			for input == "" {
				fmt.Printf(
					"confirm new repo: %s @ %s (y/n) ",
					term.Blue.String(remote),
					term.Yellow.String(path),
				)
				_, _ = fmt.Scanln(&input)
			}

			if input != "n" {
				viper.Set("repos", append(
					cfg.Repositories,
					config.GitRepository{Remote: remote, Path: path},
				))
				if err := viper.WriteConfig(); err != nil {
					log.Fatal(err)
				}
			}
		},
	})
}
