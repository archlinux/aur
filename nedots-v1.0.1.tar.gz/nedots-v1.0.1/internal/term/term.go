package term

import (
	"fmt"
	"log"
)

type Style string

const (
	Bold       Style = "bold"
	Gray        Style = "dim"
	Black      Style = "black"
	Red        Style = "red"
	Green      Style = "green"
	Yellow     Style = "yellow"
	Blue       Style = "blue"
	DarkYellow Style = "dark-yellow"
	BgWhite    Style = "bg-white"
	BgBlue     Style = "bg-blue"
)

func (s Style) String(str string) string {
	switch s {
	case Bold:
		return fmt.Sprintf("\033[01m%s\033[0m", str)
	case Gray:
		return fmt.Sprintf("\033[37m%s\033[0m", str)
	case Black:
		return fmt.Sprintf("\033[30m%s\033[0m", str)
	case Red:
		return fmt.Sprintf("\033[91m%s\033[0m", str)
	case Green:
		return fmt.Sprintf("\033[92m%s\033[0m", str)
	case Yellow:
		return fmt.Sprintf("\033[93m%s\033[0m", str)
	case Blue:
		return fmt.Sprintf("\033[94m%s\033[0m", str)
	case DarkYellow:
		return fmt.Sprintf("\033[33m%s\033[0m", str)
	case BgWhite:
		return fmt.Sprintf("\033[107m%s\033[0m", Black.String(Bold.String(str)))
	case BgBlue:
		return fmt.Sprintf("\033[44m%s\033[0m", Bold.String(str))
	default:
		return str
	}
}

var (
	ok   = Green.String(" OK")
	info = Bold.String("INF")
	err  = Red.String("ERR")
	cmd  = Blue.String("CMD")
)

func Okay(v ...any) {
	log.Printf("%s %s\n", ok, fmt.Sprint(v...))
}

func Okayf(format string, v ...any) {
	log.Printf("%s %s", ok, fmt.Sprintf(format, v...))
}

func Sokayf(format string, v ...any) string {
	return fmt.Sprintf("%s %s", ok, fmt.Sprintf(format, v...))
}

func Info(v ...any) {
	log.Printf("%s %s\n", info, fmt.Sprint(v...))
}

func Infof(format string, v ...any) {
	log.Printf("%s %s", info, fmt.Sprintf(format, v...))
}

func Error(v ...any) {
	log.Printf("%s %s\n", err, fmt.Sprint(v...))
}

func Errorf(format string, v ...any) {
	log.Printf("%s %s", err, fmt.Sprintf(format, v...))
}

func Serrorf(format string, v ...any) string {
	return fmt.Sprintf("%s %s", err, fmt.Sprintf(format, v...))
}

func Cmd(v ...any) {
	log.Printf("%s %s\n", cmd, fmt.Sprint(v...))
}

func Cmdf(format string, v ...any) {
	log.Printf("%s %s", cmd, fmt.Sprintf(format, v...))
}

func Fatal(v ...any) {
	log.Fatalf("%s %s\n", err, fmt.Sprint(v...))
}

func Fatalf(format string, v ...any) {
	log.Fatalf("%s %s", err, fmt.Sprintf(format, v...))
}
