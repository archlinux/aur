package config

import (
	"bytes"
	"testing"

	"github.com/spf13/viper"
)

var yaml = []byte(`
remote: git@some.remote:repo
dots:
- /some/dir
- /some/other/dir
repos:
- remote: git@some.other:remote/repo
  path: /some/path
`)

func init() {
	viper.SetConfigType("yaml")
}

func read(t *testing.T) error {
	err := viper.ReadConfig(bytes.NewBuffer(yaml))
	if err != nil {
		t.Fatalf("read failed: %v", err)
	}
	return err
}

func unmarshal(t *testing.T) (Config, error) {
	_ = read(t)

	var c Config
	err := viper.Unmarshal(&c)
	if err != nil {
		t.Fatalf("unmarshal failed: %v", err)
	}

	return c, err
}

func TestReadConfig(t *testing.T) {
	_ = read(t)
}

func TestUnmarshalConfig(t *testing.T) {
	c, _ := unmarshal(t)

	if c.Remote == "" {
		t.Error("unmarshalled /w errors: `Remote` == \"\".")
	} else if len(c.Dots) == 0 {
		t.Error("unmarshalled /w errors: `Dots` is empty.")
	} else if len(c.Repositories) == 0 {
		t.Error("unmarshalled /w errors: `Repositories` is empty.")
	} else {
		if c.Repositories[len(c.Repositories)-1].Remote == "" {
			t.Error("unmarshalled /w errors: `Remote` == \"\".")
		} else if c.Repositories[len(c.Repositories)-1].Path == "" {
			t.Error("unmarshalled /w errors: `Path` == \"\".")
		}
	}
}

func TestValidateConfig(t *testing.T) {
	c, _ := unmarshal(t)

	if c.Remote != "git@some.remote:repo" {
		t.Error("unmarshalled /w errors: `Remote` != \"git@some.remote:repo\".")
	} else if c.Dots[len(c.Dots)-1] != "/some/other/dir" {
		t.Error("unmarshalled /w errors: `Dots` != \"/some/other/dir\".")
	} else if c.Repositories[len(c.Repositories)-1].Remote != "git@some.other:remote/repo" {
		t.Error("unmarshalled /w errors: `Remote` != \"git@some.other:remote/repo\".")
	} else if c.Repositories[len(c.Repositories)-1].Path != "/some/path" {
		t.Error("unmarshalled /w errors: `Path` != \"/some/path\".")
	}
}
