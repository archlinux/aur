#include "src/ui/main-window.hpp"
#include "ui_main-window.h"

#include <QCoreApplication>
#include <QMessageBox>
#include <QCheckBox>
#include <QKeyEvent>
#include <QMenu>
#include "src/ui/icons.hpp"
#include "src/ui/rom-list-model.hpp"
#include "src/ui/rom-source-dialog.hpp"
#include "src/ui/settings-dialog.hpp"
#include "src/ui/controller-select-dialog.hpp"
#include "src/ui/keyboard-config-dialog.hpp"
#include "src/ui/save-file-editor-dialog.hpp"
#include "src/ui/save-slot-editor-dialog.hpp"
#include "src/ui/log-viewer-dialog.hpp"
#include "src/ui/core-installer.hpp"
#include "src/ui/toast.hpp"
#include "src/ui/play.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/rom-finder.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/rom.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/bps.hpp"
#include "src/core/version.hpp"
#include "src/core/time.hpp"
#include "src/input/gamepad-controller.hpp"
#include "src/db/data-provider.hpp"
#include "src/rhdc/core/credentials.hpp"
#include "src/rhdc/core/sync.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/rhdc/ui/rhdc-download-dialog.hpp"
#include "src/rhdc/ui/rhdc-login-dialog.hpp"

MainWindow::MainWindow() :
	QMainWindow( nullptr ),
	m_ui( new Ui::MainWindow ),
	m_showAllPlugins( false ),
	m_settings( FileController::loadAppSettings() ),
	m_exists( new bool( true ) )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );
	ToastMessageManager::setWindow( this );

#ifdef __APPLE__
	const char *styleFix = R"#(
min-height: 41px;
padding-left: 8px;
padding-right: 8px;
margin-bottom: 2px;
)#";
	m_ui->refreshButton->setStyleSheet( styleFix );
	m_ui->controllerConfigButton->setStyleSheet( styleFix );

	QFont titleFont = m_ui->titleLabel->font();
	titleFont.setPointSize( 18 );
	m_ui->titleLabel->setFont( titleFont );
#endif

	m_ui->titleLabel->setText( QString(
		( "Parallel Launcher v"s + CurrentVersion::Application.toString() ).c_str()
	));

	m_ui->controllerConfigButton->setIcon( Icon::gamepad() );
	m_ui->menuButton->setIcon( Icon::menu() );
	m_ui->refreshButton->setIcon( Icon::refresh() );
	m_ui->playSingleplayerButton->setIcon( Icon::play() );
	m_ui->playMultiplayerButton->setIcon( Icon::group() );
	m_ui->downloadButton->setIcon( Icon::download() );

	const UiState uiState = FileController::loadUiState();
	m_ui->romList->refetchAll();
	m_ui->romList->restoreTreeState( uiState.romList );
	m_ui->romView->setCurrentIndex( m_ui->romList->hasRoms() ? 1 : 0 );
		
	m_ui->actionSettings->setIcon( Icon::configure() );
	m_ui->actionManageSources->setIcon( Icon::search() );
	m_ui->actionConfigureControllers->setIcon( Icon::gamepad() );
	m_ui->actionConfigureKeyboard->setIcon( Icon::keyboard() );
	m_ui->rhdcLoginAction->setIcon( Icon::login() );
	m_ui->rhdcLogoutAction->setIcon( Icon::logout() );
	m_ui->rhdcDisableAction->setIcon( Icon::cancel() );

	m_ui->menuButton->addAction( m_ui->actionSettings );
	m_ui->menuButton->addAction( m_ui->actionManageSources );
	m_ui->menuButton->addAction( m_ui->actionConfigureControllers );
	m_ui->menuButton->addAction( m_ui->actionConfigureKeyboard );
	m_ui->menuButton->addAction( m_ui->rhdcLoginAction );
	m_ui->menuButton->addAction( m_ui->rhdcLogoutAction );
	m_ui->menuButton->addAction( m_ui->rhdcDisableAction );

	resize( uiState.windowWidth, uiState.windowHeight );

	m_showAllPlugins = uiState.showAllPlugins;
	m_ui->romSettings->setShowAllPlugins( m_showAllPlugins );

	connect( m_ui->refreshButton, SIGNAL(clicked()), this, SLOT(refreshRomList()) );
	connect( m_ui->romList->selectionModel(), SIGNAL(currentChanged(const QModelIndex&, const QModelIndex&)), this, SLOT(romSelectionChanged()) );
	connect( m_ui->romList, SIGNAL(editSave(fs::path)), this, SLOT(editSave(fs::path)) );
	connect( m_ui->romList, SIGNAL(launchRom()), this, SLOT(playSingleplayer()) );
	connect( m_ui->romList, SIGNAL(downloadPatch()), this, SLOT(download()) );

	reloadSettings();
	romSelectionChanged();

	refreshRomList();
	updateRhdcActions();
}

MainWindow::~MainWindow() {
	m_ui->romList->model()->deleteLater();
	delete m_ui;
}

void MainWindow::reloadSettings() {
	m_settings = FileController::loadAppSettings();

	m_ui->romList->setColumnHidden( 0, false );
	m_ui->romList->setColumnHidden( 1, !Flags::has( m_settings.visibleColumns, RomInfoColumn::InternalName ) );
	m_ui->romList->setColumnHidden( 2, !Flags::has( m_settings.visibleColumns, RomInfoColumn::Path ) );
	m_ui->romList->setColumnHidden( 3, !Flags::has( m_settings.visibleColumns, RomInfoColumn::LastPlayed ) );
	m_ui->romList->setColumnHidden( 4, !Flags::has( m_settings.visibleColumns, RomInfoColumn::PlayTime ) );
}

void MainWindow::refreshRomList() {
	m_romSearch.cancel();
	m_ui->searchIndicator->setVisible( true );
	std::shared_ptr<bool> windowExists = m_exists;
	m_romSearch = RomFinder::scanAsync( [this,windowExists](RomFinder::SearchResults result){
		if( !*windowExists || result == RomFinder::SearchResults::Cancelled ) return;
		if( result == RomFinder::SearchResults::Updated ) {
			this->m_ui->romList->refetchAll();
			this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
		}

		RHDC::sync( [this,windowExists](bool refetch) {
			this->m_ui->searchIndicator->setVisible( false );
			updateRhdcActions();
			if( refetch ) {
				this->m_ui->romList->refetchAll();
				this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
			}
		});
	});
}

void MainWindow::romSelectionChanged() {
	const RomReference rom = m_ui->romList->tryGetSelectedRom();
	const bool romSelected = (rom.info != nullptr);

	m_ui->romSettings->setEnabled( romSelected );
	if( romSelected ) {
		m_ui->romSettings->setSettings(
			rom.info->inputModeId,
			rom.info->emulator,
			rom.info->parallelPlugin,
			rom.info->mupenPlugin,
			rom.info->overclockCPU,
			rom.info->overclockVI,
			rom.info->widescreen,
			rom.info->parallelTexRectUpscaling,
			rom.info->glidenFramebufferEmulation,
			rom.info->glidenCorrectDepthCompare
		);
	}

	const bool showDownloadButton = rom.file != nullptr && !rom.file->local;
	m_ui->downloadButton->setVisible( showDownloadButton );
	m_ui->playSingleplayerButton->setVisible( !showDownloadButton );
	m_ui->playMultiplayerButton->setVisible( !showDownloadButton );
}

void MainWindow::overclockCpuChanged( bool overclock ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockCPU = overclock;
	DataProvider::updateRomCpuOverclocking( romInfo->sha1, overclock );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::overclockViChanged( bool overclock ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockVI = overclock;
	DataProvider::updateRomViOverclocking( romInfo->sha1, overclock );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::widescreenChanged( bool wide ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->widescreen = wide;
	DataProvider::updateRomWidescreen( romInfo->sha1, wide );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::parallelPluginChanged() {
	const GfxPlugin plugin = m_ui->romSettings->getParallelPlugin();

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->parallelPlugin == plugin ) return;

	romInfo->parallelPlugin = plugin;
	DataProvider::updateRomParallelPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::mupenPluginChanged() {
	const GfxPlugin plugin = m_ui->romSettings->getMupenPlugin();

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->mupenPlugin == plugin ) return;

	romInfo->mupenPlugin = plugin;
	DataProvider::updateRomMupenPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::inputModeChanged() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->inputModeId = m_ui->romSettings->getInputMode();
	DataProvider::updateRomInputMode( romInfo->sha1, romInfo->inputModeId );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::emulatorChanged() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->emulator = m_ui->romSettings->getEmulatorCore();
	DataProvider::updateRomEmulator( romInfo->sha1, romInfo->emulator );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::upscaleTexRectsChanged( bool upscale ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->parallelTexRectUpscaling = upscale;
	DataProvider::setRomParallelTexRectUpscaling( romInfo->sha1, upscale );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::emulateFramebufferChanged( bool emulate ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->glidenFramebufferEmulation = emulate;
	DataProvider::setRomGlidenFrameBufferEmulation( romInfo->sha1, emulate );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::accurateDepthCompareChanged( bool accurate ) {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->glidenCorrectDepthCompare = accurate;
	DataProvider::setRomGlidenAccurateDepthCompare( romInfo->sha1, accurate );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::showMorePluginsChanged( bool showAll ) {
	m_showAllPlugins = showAll;
}

void MainWindow::play( bool multiplayer ) {
	const RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.info == nullptr ) return;

	const string sha1 = rom.file->sha1;
	const QRect winGeo = geometry();
	hide();

	Game::play(
		*rom.file,
		*rom.info,
		multiplayer,
		[this,sha1,winGeo](int64) {
			this->setGeometry( winGeo );
			this->show();
			QTimer::singleShot( 50, [this,winGeo](){ this->setGeometry( winGeo ); } );
			this->m_ui->romList->refetchAll();
		}
	);
}

void MainWindow::playSingleplayer() {
	play( false );
}

void MainWindow::playMultiplayer() {
	play( true );
}

void MainWindow::configureController() {
	ControllerSelectDialog dialog;
	dialog.exec();
}

void MainWindow::configureKeyboard() {
	KeyboardConfigDialog dialog;
	dialog.exec();
}

void MainWindow::editSettings() {
	SettingsDialog *dialog = new SettingsDialog();
	dialog->exec();
	delete dialog;
	reloadSettings();
	m_ui->romList->refetchAll();
	m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
	romSelectionChanged();
}

void MainWindow::manageRomSources() {
	RomSourceDialog *dialog = new RomSourceDialog();
	dialog->exec();
	delete dialog;
	m_ui->romList->refetchAll();
	m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
	refreshRomList();
}

void MainWindow::closeEvent( QCloseEvent *event ) {
	const UiState uiState = {
		m_ui->romList->saveTreeState(),
		width(),
		height(),
		m_showAllPlugins
	};

	FileController::saveUiState( uiState );
	QMainWindow::closeEvent( event );
	QCoreApplication::quit();
}

void MainWindow::keyPressEvent( QKeyEvent *event ) {
	if( event->key() == Qt::Key_F7 ) {
		event->accept();
		LogViewerDialog().exec();
	} else {
		QMainWindow::keyPressEvent( event );
	}
}

void MainWindow::editSave( fs::path saveFilePath ) {
	SaveFileEditorDialog dialog( saveFilePath );
	if( dialog.exec() == QDialog::Accepted ) {
		SaveSlotEditorDialog dialog2( saveFilePath, dialog.getSaveSlot() );
		dialog2.exec();
	}
}

void MainWindow::updateRhdcActions() {
	const bool integrationEnabled = RhdcCredentials::exists() || DataProvider::hasRhdcData();
	const bool loggedIn = RhdcApi::isAuthenticated();

	m_ui->rhdcLoginAction->setText( integrationEnabled ? tr( "Login to romhacking.com" ) : tr( "Enable romhacking.com integration" ) );
	m_ui->rhdcLoginAction->setIcon( integrationEnabled ? Icon::login() : Icon::plugin() );
	m_ui->rhdcLoginAction->setVisible( !loggedIn );
	m_ui->rhdcLogoutAction->setVisible( loggedIn );
	m_ui->rhdcDisableAction->setVisible( integrationEnabled );
}

void MainWindow::rhdcLogin() {
	RhdcLoginDialog dialog;
	if( dialog.exec() == QDialog::Accepted ) {
		m_ui->searchIndicator->setVisible( true );
		updateRhdcActions();

		std::shared_ptr<bool> windowExists = m_exists;
		RHDC::sync( [this,windowExists](bool refetch) {
			if( !*windowExists ) return;
			this->m_ui->searchIndicator->setVisible( false );
			if( refetch ) {
				this->m_ui->romList->refetchAll();
				this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
			}
		});
	}
}

void MainWindow::rhdcLogout() {
	RhdcApi::logout();
	RhdcCredentials::forget();
	updateRhdcActions();
}

void MainWindow::rhdcDisable() {
	if( QMessageBox::question( this, tr( "Confirm Disable" ), tr( "Are you sure you want to disable romhacking.com integration?" ) ) == QMessageBox::Yes ) {
		m_romSearch.cancel();
		m_ui->searchIndicator->setVisible( false );
		RhdcApi::logout();
		RhdcCredentials::forget();
		DataProvider::clearAllRhdcData();
		updateRhdcActions();
	}
}

void MainWindow::download() {
	const RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.file == nullptr || rom.file->local ) return;

	TreeUiState uiState = m_ui->romList->saveTreeState();
	uiState.selectedRom = RhdcDownloadDialog::run( rom.rhdc->info.hackId, rom.file->path.u8string() );
	m_ui->romList->refetchAll();
	m_ui->romList->restoreTreeState( uiState );
	romSelectionChanged();
}
