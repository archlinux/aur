#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"
#include "src/rhdc/web/require-login.hpp"

#include <sstream>
#include <map>
#include "src/core/special-groups.hpp"
#include "src/core/logging.hpp"

struct GroupNameJson {
	string data;
};

template<> void JsonSerializer::serialize<GroupNameJson>( JsonWriter &jw, const GroupNameJson &obj ) {
	std::ostringstream doubleJson;
	JsonWriter innerWriter( &doubleJson, false );
	innerWriter.writeString( obj.data );

	jw.writeObjectStart();
	jw.writeProperty( "data", doubleJson.str() );
	jw.writeObjectEnd();
}

static inline string listToGroup( const string &listName ) {
	if( listName == "Want To Play" ) {
		return SpecialGroups::WantToPlay;
	} else if( listName == "In Progress" ) {
		return SpecialGroups::InProgress;
	} else if( listName == "Completed" ) {
		return SpecialGroups::Completed;
	} else if( listName == "Favorites" ) {
		return SpecialGroups::Favourites;
	} else return listName;
}

static inline std::optional<GfxPlugin> parsePlugin( const Json &jString ) {
	static const std::map<string,GfxPlugin> tokens = {
		{ "ParaLLEl", GfxPlugin::ParaLLEl },
		{ "GLideN64", GfxPlugin::GlideN64 },
		{ "Glide64", GfxPlugin::Glide64 },
		{ "Rice", GfxPlugin::Rice },
		{ "Angrylion", GfxPlugin::Angrylion }
	};

	const auto p = tokens.find( jString.getOrDefault<string>( "" ) );
	if( p == tokens.end() ) return std::nullopt;
	return p->second;
}

static inline PluginFlags parsePluginFlags( const Json &jArray ) {
	static const std::map<string,PluginFlags> tokens = {
		{ "upscale-texrects", PluginFlags::UpscaleTexrects },
		{ "allow-hle-fallback", PluginFlags::AllowHleFallback },
		{ "emulate-framebuffer", PluginFlags::EmulateFramebuffer },
		{ "accurate-depth-compare", PluginFlags::AcccurateDepthCompare }
	};

	PluginFlags flags = PluginFlags::None;
	if( !jArray.isArray() ) return flags;
	for( const Json &jString : jArray.array() ) {
		const auto f = tokens.find( jString.getOrDefault<string>( "" ) );
		if( f == tokens.end() ) continue;
		flags |= f->second;
	}

	return flags;
}

void RhdcApi::getFollowedHacksAsync(
	const std::function<void(HashMap<string,FollowedHack>&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getFollowedHacksAsync( onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/user/getlists" );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( !json.isObject() ) {
			logError( "Unexpected JSON format in response from RHDC getlists query" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		HashMap<string,FollowedHack> hackMap;
		const JObject lists = json.object();
		for( const auto &[key, hacks] : lists ) {
			if( !hacks.isArray() ) continue;
			const string group = listToGroup( key );
			for( const Json &hack : hacks.array() ) {
				const string hackId = hack["_id"].getOrDefault<string>( "" );
				if( hackId.empty() ) continue;
				if( hackMap.count( hackId ) > 0 ) {
					hackMap[hackId].groups.push_back( group );
				} else {
					const string slug = hack["urlTitle"].getOrDefault<string>( "" );
					if( slug.empty() || !hack["versions"].isArray() ) continue;

					const JArray versionsJson = hack["versions"].array();
					std::optional<GfxPlugin> plugin = std::nullopt;
					PluginFlags pluginFlags = PluginFlags::None;

					string downloadUrl;
					string primaryHash;
					std::vector<string> versions;
					versions.reserve( versionsJson.size() );
					for( const Json &version : versionsJson ) {
						string sha1 = version["patchedSha1"].getOrDefault<string>( "" );
						if( !sha1.empty() ) versions.push_back( sha1 );
						const string download = version["download"].getOrDefault<string>( "" );
						if( download.empty() ) continue;
						downloadUrl = "https://api.romhacking.com/game/"s + slug + '/' + ApiUtil::urlEncode( download );
						plugin = parsePlugin( version["plugin"] );
						pluginFlags = parsePluginFlags( version["pluginFlags"] );
						primaryHash = std::move( sha1 );
					}

					if( downloadUrl.empty() ) continue;

					hackMap[hackId] = FollowedHack{
						RhdcHackInfo {
							hackId,
							hack["title"].getOrDefault<string>( "" ),
							slug,
							hack["description"].getOrDefault<string>( "" ),
							hack["stars"].getOrDefault<int>( 0 ),
							hack["numDownloads"].getOrDefault<int>( 1 ),
							hack["rating"].getOrDefault<double>( 0.0 ),
							hack["difficulty"].getOrDefault<double>( 0.0 ),
							hack["category"].getOrDefault<string>( "None" )
						},
						downloadUrl,
						primaryHash,
						versions,
						{ group },
						plugin,
						pluginFlags
					};
				}
			}
		}

		onSuccess( hackMap );
	}, onFailure );
}

void RhdcApi::getRecommendedPlugin(
	const string &hackId,
	const std::function<void(PluginRecommendation&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getRecommendedPlugin( hackId, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/game/"s + hackId );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( !json.isObject() || !json["versions"].isArray() ) {
			logError( "Unexpected JSON format in response from RHDC game query" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		const JArray versionsJson = json["versions"].array();
		PluginRecommendation pluginRec = { std::nullopt, PluginFlags::None };

		string downloadUrl;
		string primaryHash;
		std::vector<string> versions;
		versions.reserve( versionsJson.size() );
		for( const Json &version : versionsJson ) {
			if( version["patchedSha1"].getOrDefault<string>( "" ).empty() ) continue;
			if( version["download"].getOrDefault<string>( "" ).empty() ) continue;

			const std::optional<GfxPlugin> plugin = parsePlugin( version["plugin"] );
			if( !plugin.has_value() ) continue;

			pluginRec.plugin = plugin;
			pluginRec.pluginFlags = parsePluginFlags( version["pluginFlags"] );
		}

		onSuccess( pluginRec );
	}, onFailure );
}


static void createListAsync(
	const string &group,
	const std::function<void(void)> &callback
) {
	QNetworkReply *response = ApiUtil::send<GroupNameJson>( HttpMethod::Post, "https://api.romhacking.com/user/createlist/", { group } );
	ApiUtil::onResponse( response, callback, [callback](ApiErrorType){ callback(); } );
}

void RhdcApi::addHackToListAsync(
	const string &hackId,
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ addHackToListAsync( hackId, group, onSuccess, onFailure ); })
	createListAsync( group, [=]() {
		QNetworkReply *response = ApiUtil::send( HttpMethod::Put, "https://api.romhacking.com/user/addtolist/"s + ApiUtil::urlEncode( group ) + '/' + hackId );
		ApiUtil::onResponse( response, onSuccess, onFailure );
	});
}

void RhdcApi::removeHackFromListAsync(
	const string &hackId,
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ removeHackFromListAsync( hackId, group, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Delete, "https://api.romhacking.com/user/deletefromlist/"s + ApiUtil::urlEncode( group ) + '/' + hackId );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::deleteListAsync(
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ deleteListAsync( group, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Delete, "https://api.romhacking.com/user/deletelist/"s + ApiUtil::urlEncode( group ) );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}


void RhdcApi::downloadHack(
	const string &downloadUrl,
	QFile *destinationFile,
	const std::function<void(int64,int64)> &onProgress,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ downloadHack( downloadUrl, destinationFile, onProgress, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, downloadUrl );

	QObject::connect( response, &QNetworkReply::readyRead, ApiUtil::web(), [=](){
		destinationFile->write( response->readAll() );
	});

	QObject::connect( response, &QNetworkReply::downloadProgress, ApiUtil::web(), [=](qint64 downloaded, qint64 total){
		onProgress( (int64)downloaded, (int64)total );
	});

	ApiUtil::onResponse( response, onSuccess, onFailure );
}
