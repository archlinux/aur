import sys
import os
from lib.paths import get_base_dir
import inspect
from PySide6.QtWidgets import QMessageBox, QWidget
from uiloader import loadUi
directory = get_base_dir()
sys.path.append(directory + "/lib")
from bbdd import Bbdd
from competitions import Competitions


class NewCompetition(QWidget):
	def __init__(self, mainWindows):
		QWidget.__init__(self)
		loadUi(directory + "/../ui/new_competition.ui", self)
		self.mainWindows = mainWindows
		self.btnAccept.clicked.connect(self.accept)
		self.btnCancel.clicked.connect(self.cancel)
		self.mainWindows.setWindowTitle(_("New Competition") + " | Betcon v" + mainWindows.version)
		self.txtName.returnPressed.connect(self.btnAccept.click)
		self.initData()
		self.translate()

	def translate(self):

		self.lblName.setText(_("Name"))
		self.lblRegion.setText(_("Region"))
		self.lblSport.setText(_("Sport"))

		self.btnCancel.setText(_("Cancel"))
		self.btnAccept.setText(_("Accept"))

	def initData(self):
		# cmbRegion
		bd = Bbdd()
		data = bd.select("region", "name")

		self.regionIndexToId = {}
		index = 0
		for i in data:
			id = i[0]
			name = i[1]
			self.cmbRegion.addItem(name)
			self.regionIndexToId[index] = id
			index += 1

		# cmbSport
		bd = Bbdd()
		data = bd.select("sport", "name")

		self.sportIndexToId = {}
		index = 0
		for i in data:
			id = i[0]
			name = i[1]
			self.cmbSport.addItem(name)
			self.sportIndexToId[index] = id
			index += 1

		bd.close()

	def close(self):
			self.mainWindows.setCentralWidget(Competitions(self.mainWindows))

	def cancel(self):
		self.close()

	def accept(self):
		data = []
		data.append(self.txtName.text())
		idRegion = self.regionIndexToId.get(self.cmbRegion.currentIndex())
		data.append(idRegion)
		idSport = self.sportIndexToId.get(self.cmbSport.currentIndex())
		data.append(idSport)



		columns = ["name", "region", "sport"]

		bbdd = Bbdd()
		bbdd.insert(columns, data, "competition")
		bbdd.close()

		QMessageBox.information(self, _("Added"), "New competition added.")

		self.close()

