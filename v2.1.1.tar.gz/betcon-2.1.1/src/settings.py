import sys
import os
from lib.paths import get_base_dir
import inspect

from PySide6.QtWidgets import QWidget, QApplication
from uiloader import loadUi
directory = get_base_dir()
sys.path.append(directory + "/lib")
from bbdd import Bbdd
from libyaml import LibYaml
from theme import apply_theme
from bets import Bets
from bookie import Bookie
import platform


class Settings(QWidget):
	def __init__(self, mainWindows):
		QWidget.__init__(self)
		loadUi(directory + "/../ui/settings.ui", self)
		self.mainWindows = mainWindows
		mainWindows.diconnectActions()
		self.mainWindows.setWindowTitle(_("Options") + " | Betcon v" + mainWindows.version)

		self.translate()
		self.btnAccept.clicked.connect(self.accept)
		self.btnCancel.clicked.connect(self.cancel)


		# TODO Al cargar el formulario debe actualiza el combobox con el valor del yml
		self.cmbLanguage.addItem("Deutsch", "de")
		self.cmbLanguage.addItem("English", "en")
		self.cmbLanguage.addItem("English (United Kingdom)", "en_GB")
		self.cmbLanguage.addItem("Español", "es")
		self.cmbLanguage.addItem("Kurdî", "ki")
		self.cmbLanguage.addItem("Português (Brasil)", "pt_BR")
		self.cmbLanguage.addItem("Türk", "tr")

		self.config = LibYaml()
		self.txtPercentage.setValue(float(self.config.stake["percentage"]))
		self.cmbOne.setCurrentIndex(self.config.stake["type"])
		self.txtStake.setValue(float(self.config.stake["stake"]))
		if self.config.stake["type"] == 0:
			self.txtStake.setEnabled(False)

		self.cmbOne.activated.connect(self.updateOne)
		self.btnCalc.clicked.connect(self.calcBank)

		self.txtCoin.setText(self.config.interface["coin"])
		if self.config.interface['bookieCountry'] == 'Y':
			self.chkCountryYes.setChecked(True)
		else:
			self.chkCountryNo.setChecked(True)

		theme_index = {"auto": 0, "dark": 1, "light": 2}
		current_theme = self.config.interface.get("theme", "auto")
		self.cmbTheme.setCurrentIndex(theme_index.get(current_theme, 0))

		langIndex = {"de": 0, "en": 1, "en_GB": 2, "es": 3, "ki": 4, "pt_BR": 5, "tr": 6}
		try:
			self.cmbLanguage.setCurrentIndex(langIndex[self.config.interface['lang']])
		except Exception:
			self.cmbLanguage.setCurrentIndex(langIndex["es"])

		if platform.system() == 'Linux':
			self.cmbLanguage.setEnabled(False)


	def translate(self):
		self.lblSetStake.setText(_("Stake"))
		self.lblCalculate.setText(_("Stake 1 calculation"))
		self.lblPercentage.setText(_("Stake 1 percentage"))
		self.lblStake.setText(_("Stake 1"))

		self.cmbOne.addItems([_("Calculated"), _("Fixed")])

		self.lblInterface.setText(_("Interface"))
		self.lblCoin.setText(_("Coin"))
		self.lblCountry.setText(_("Show countries of the bookies"))
		self.chkCountryYes.setText(_("Yes"))
		self.chkCountryNo.setText(_("No"))

		self.lblTheme.setText(_("Theme"))
		self.cmbTheme.addItem(_("Auto (system)"), "auto")
		self.cmbTheme.addItem(_("Dark"), "dark")
		self.cmbTheme.addItem(_("Light"), "light")

		self.btnCalc.setText(_("Calculate"))
		self.btnCancel.setText(_("Cancel"))
		self.btnAccept.setText(_("Accept"))

	def updateOne(self):
		result = self.cmbOne.currentIndex()
		self.txtStake.setEnabled(False) if result == 0 else self.txtStake.setEnabled(True)

	def calcBank(self):
		bd = Bbdd()
		bookies = Bookie.sumAll()
		bonus = Bookie.sumBonus()

		# CC
		cc = bd.select("bank", None, "id=1", "bank")
		cc = cc[0][0]

		# Paypal
		paypal = bd.select("bank", None, "id=2", "bank")
		paypal = paypal[0][0]

		# SKRILL
		skrill = bd.select("bank", None, "id=3", "bank")
		skrill = skrill[0][0]

		total = "{0:.2f}".format(cc + paypal + skrill + bonus + bookies)
		total = float(total) * (self.txtPercentage.value() * 0.01)
		self.txtStake.setValue(float(total))
		bd.close()

	def close(self):
		self.mainWindows.enableTools()
		self.mainWindows.setCentralWidget(Bets(self.mainWindows))

	def cancel(self):
		self.close()

	def accept(self):
		percentage = self.txtPercentage.text()[:-1]
		self.config.stake["percentage"] = float(percentage)

		self.config.stake["type"] = self.cmbOne.currentIndex()

		stake = self.txtStake.text()[:-1]
		self.config.stake["stake"] = float(stake)
		self.config.interface['coin'] = self.txtCoin.text()
		self.config.interface['bookieCountry'] = 'Y' if self.chkCountryYes.isChecked() else 'N'
		self.config.interface['lang'] = self.cmbLanguage.itemData(self.cmbLanguage.currentIndex())
		self.config.interface['theme'] = self.cmbTheme.currentData()
		self.config.save()
		apply_theme(QApplication.instance(), self.config.interface['theme'])
		self.close()

