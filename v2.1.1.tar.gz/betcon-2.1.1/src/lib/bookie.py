import os
from shutil import copy2
from os.path import expanduser

from bbdd import Bbdd

from images import Images


class Bookie:

	ruta = None
	#Setters

	def setId(self, id):
		self.id = id
		bd = Bbdd()

		self.name, self.country = bd.select("bookie", None, "id=" + str(self.id), "name, country")[0]

		bd.close()

	def setName(self, name):
		self.name = name

	def setCountry(self, country):
		self.country = country

	def setAll(self, name, country):
		self.setName(name)
		self.setCountry(country)

	def setRuta(self, ruta):
		self.ruta = ruta

	#Métodos auxiliares

	def isEmpty(self):
		if self.name is None:
			return True
		else:
			return False

	# Base de datos
	def insert(self):
		if not self.isEmpty():
			bd = Bbdd()
			msg = bd.insert(["name", "country"], [self.name, self.country], "bookie")
			bd.close()
		else:
			msg = "Faltan datos por introducir"

		return msg

	def update(self):
		if not self.isEmpty():
			bd = Bbdd()
			msg = bd.update(["name", "country"], [self.name, self.country], "bookie", "id=?", (self.id,))
			bd.close()
			if msg != 0:
				msg = "Se ha producido un error al actualizar la BBDD"
			if self.ruta is not None:
				try:
					if not os.path.exists(expanduser("~") + "/.betcon/resources/bookies"):
						os.makedirs(expanduser("~") + "/.betcon/resources/bookies")
					copy2(self.ruta, expanduser("~") + "/.betcon/resources/bookies/" + self.id + ".png")
					img = Images(expanduser("~") + "/.betcon/resources/bookies/" + self.id + ".png")
					img.resize(100, 20)
				except Exception:
					msg = "Imágen incorrecta"
		else:
			msg = "Faltan datos por introducir"
		return msg

	@staticmethod
	def selectAll():
		bd = Bbdd()
		data = bd.select("bookie", "name")

		items = []
		for i in data:
			item = Bookie()
			item.setId(i[0])
			items.append(item)

		bd.close()
		return items

	@staticmethod
	def delete(id):
		bd = Bbdd()
		msg = bd.delete("bookie", id)
		bd.close()
		if msg != 0:
			msg = "Se ha producido un error al actualizar la BBDD"
		return msg

	@staticmethod
	def deleteWhere(table, where, params=None):
		bd = Bbdd()
		msg = bd.deleteWhere(table, where, params)
		bd.close()
		if msg != 0:
			msg = "Se ha producido un error al actualizar la BBDD"
		return msg

	@staticmethod
	def sumAll(where=None, where_params=None):
		bd = Bbdd()
		data = bd.sum("movement", "money", where, where_params)
		if where is None:
			profit = bd.sum("bet", "profit")
			data += profit
		elif where.startswith("bookie"):
			profit = bd.sum("bet", "profit", where, where_params)
			data += profit

		bd.close()
		return data

	@staticmethod
	def sumBonus(date=None, bookie_id=None):
		bd = Bbdd()
		where_parts = ["free='True'"]
		params = []
		if date:
			where_parts.append("date LIKE ?")
			params.append(date)
		if bookie_id is not None:
			where_parts.append("bookie=?")
			params.append(int(bookie_id))
		data = bd.sum("bonus", "money", " AND ".join(where_parts), params or None)
		bd.close()
		return data
		return data
