pub fn about() {
    println!("gdrive is a command line application for interacting with Google Drive.");
    println!();
    println!(
        "For the latest information check out the project page: https://github.com/glotlabs/gdrive"
    );
    println!("You will also find link to the community chat and information on how to support the project.");
}
