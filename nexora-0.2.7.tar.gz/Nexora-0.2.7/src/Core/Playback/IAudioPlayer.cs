using Core.Playlists;

namespace Core.Playback;

public interface IAudioPlayer
{
    public IPlaylistItem? NowPlaying { get; }
    public bool IsPlaying { get; }
    public int Volume { get; set; }
    public float PlaybackPosition { get; set; }
    public bool Mute { get; set; }
    
    public event Action? PlaybackStarted;
    public event Action<float>? PlaybackPositionChanged;
    public event Action? PlaybackPaused;
    public event Action? PlaybackFinished;
    public event Action? PlaybackResumed;
    public event Action<float>? VolumeChanged;
    public event Action<bool>? MuteChanged;
    
    public void PlayTrack(IPlaylistItem playlistItem);
    public void PlayNextTrack();
    public void PlayPreviousTrack();
    public void TogglePause();
    public void SkipForward();
    public void SkipBack();
}
