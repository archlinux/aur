
/*
 * wmpiki
 *
 * Copyright (C) 2002,2003,2005 sill and pasp
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>

#include <sys/wait.h>
#include <sys/param.h>
#include <sys/types.h>

#include <X11/Xlib.h>
#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include "docklib.h"

#include "master.h"
#include "mask.h"

#define MAX_HOSTS			8
#define MIN_PERIOD			20
#define MAX_PERIOD			1200
#define	MAX_BUFFER_SIZE		256
#define PING_GREP			"bytes from"

typedef struct {
	char host[MAX_VALUE_LEN];
	char alias[MAX_VALUE_LEN];
	int update_period;
	int led;
} wmph;

wmph wmp_hosts[MAX_HOSTS];

char ping_options[MAX_VALUE_LEN];
int defined_hosts[MAX_HOSTS];
int defined_hosts_number;
int update_period;
int led_color;
int small_font;
int disable_logo;
int cmd_lmb, cmd_rmb;
char command_lmb[PATH_MAX], command_rmb[PATH_MAX];
/*----------------------------------------------------------------------*/

FILE *wmpiki_start_check_host(char *hostname)
{
char commandbuffer[MAX_BUFFER_SIZE];

	dcl_strcpy(commandbuffer, "ping ", MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, hostname, MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, " ", MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, ping_options, MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, " | grep '", MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, PING_GREP, MAX_BUFFER_SIZE);
	dcl_strcat(commandbuffer, "'", MAX_BUFFER_SIZE);
	
	return popen(commandbuffer, "r");
}

/*----------------------------------------------------------------------*/

void wmpiki_routine(int argc, char **argv)
{
XEvent Event;
FILE *ping_f[MAX_HOSTS];
char linebuffer[MAX_BUFFER_SIZE];
long start_time, current_time, next_time[MAX_HOSTS];
int i, launch, but_stat = -1;

int xfd = 0;
fd_set inputs;
struct timeval timeout;

int yposition = 21;
int yspacing = 5; 
int showed_hosts = 0;
int yposition_table[8] = { 28, 25, 23, 20, 17, 9, 9, 9 };
int yspacing_table[8] =  {  6,  6,  5,  4,  3, 3, 2, 1 };

	yposition = yposition_table[defined_hosts_number-1];
	yspacing += yspacing_table[defined_hosts_number-1]; 

	timeout.tv_sec = 0;
	timeout.tv_usec = 150000;

	dcl_open_x_window(argc, argv, wmpiki_master_xpm, wmpiki_mask_bits, MASK_WIDTH, MASK_HEIGHT);

	if (defined_hosts_number>=6) {
		/* hide wmpiki logo */
		dcl_copy_xpm_area(0, 64, 56, 9, 4, 5); 

	} else if (disable_logo) {
		yposition -= 5; 
		yspacing += 1; 
		/* hide wmpiki logo */
		dcl_copy_xpm_area(0, 64, 56, 9, 4, 5); 
	}

    /* add mouse region */
    dcl_add_mouse_region(0, 4, 4, 59, 59);

	start_time = time(0);              

	for (i=showed_hosts=0; i<MAX_HOSTS; i++) {
		
		ping_f[i] = NULL;
		
		next_time[i] = start_time;

		/* show aliases or hosts */
		if (defined_hosts[i] == true) {
			if (small_font)			
				dcl_draw_string(14, yposition + showed_hosts*yspacing,
						wmp_hosts[i].alias, FONT_SMALL, 9);
			else
				dcl_draw_string(15, yposition + showed_hosts*yspacing,
						wmp_hosts[i].alias, FONT_NORMAL, 7);

			/* show gray leds at startup*/
			dcl_draw_led (6, yposition + showed_hosts*yspacing, GRAY);

			showed_hosts++;
		}
	}


	xfd = ConnectionNumber(display);
	launch = 0;

	i = showed_hosts = 0;
	
	/* main loop */
	while (1) {
		waitpid(0, NULL, WNOHANG);

		FD_ZERO(&inputs);
		FD_SET(xfd, &inputs);

		/* run pings */
		current_time = time(0);
		for (i = 0; i < MAX_HOSTS; i++) {
			if (defined_hosts[i] == true) {

				if (ping_f[i] == NULL && launch == i && current_time >= next_time[i]) {
					next_time[i] = current_time + wmp_hosts[i].update_period;
					ping_f[i] = wmpiki_start_check_host(wmp_hosts[i].host);
				}

				if (ping_f[i] != NULL) {
					FD_SET(fileno(ping_f[i]), &inputs);
				}
			}
		}
		
		/* read events */
		switch (select(FD_SETSIZE, &inputs, NULL, NULL, &timeout)) {
			/* timeout */
			case 0:
				timeout.tv_sec = 0;
				timeout.tv_usec = 20000;
				dcl_redraw_window();
				launch = (launch + 1) % MAX_HOSTS; /* do not launch all pings at one time */
				break;
				
			/* error */
			case -1:
				break;

			/* X or ping */
			default:
				/* check X */
				while (FD_ISSET(xfd, &inputs) && XPending(display)) {
					XNextEvent(display, &Event);

					switch (Event.type) {
						case Expose:
							dcl_redraw_window();
							break;

						case DestroyNotify:
							XCloseDisplay(display);
							exit(0);
							break;
    
                        case ButtonPress:
                            but_stat = dcl_check_mouse_region(Event.xbutton.x, Event.xbutton.y);
                            break;
    
                        case ButtonRelease:
                            i = dcl_check_mouse_region(Event.xbutton.x, Event.xbutton.y);
                        
                            if(!i && Event.xbutton.button == LMB && cmd_lmb)
                                dcl_execute_command(command_lmb, 0);
                            else if(!i && Event.xbutton.button == RMB && cmd_rmb)
                                dcl_execute_command(command_rmb, 0);
                            break;
					}
				}

				/* update hosts */
				for (i = showed_hosts = 0; i < MAX_HOSTS; i++) {
					if(defined_hosts[i] == true) {
						if(ping_f[i] != NULL && FD_ISSET(fileno(ping_f[i]), &inputs)) {

							/* check ping */
							linebuffer[0] = '\0';
							while (fscanf (ping_f[i], "%[^\n]", linebuffer) == 1);

							if (!pclose(ping_f[i]))
								dcl_draw_led(6, yposition + showed_hosts*yspacing, wmp_hosts[i].led);

							else
								dcl_draw_led(6, yposition + showed_hosts*yspacing, GRAY);

							ping_f[i] = NULL;
						}
						showed_hosts++;
					}
				}
				break;
		}
	}
}

/*----------------------------------------------------------------------*/

void wmpiki_write_prefs(void) 
{
int i;
char tmpbuffer[MAX_VALUE_LEN];

	if (dcl_prefs_openfile (dcl_getfilename_config (".clay", "wmpiki.rc"), P_WRITE)) {
    
		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d", i+1);
			dcl_prefs_put_string (tmpbuffer, wmp_hosts[i].host);
		}

		dcl_prefs_put_lf ();
		dcl_prefs_put_int ("update_period", update_period);
		dcl_prefs_put_int ("led_color", led_color);
		dcl_prefs_put_int ("small_font", small_font);
		dcl_prefs_put_int ("disable_logo", disable_logo);
		dcl_prefs_put_string ("ping_options", ping_options);
        dcl_prefs_put_string ("command_lmb", command_lmb);
        dcl_prefs_put_string ("command_rmb", command_rmb);

		dcl_prefs_put_lf ();
		dcl_prefs_put_comment("==============================\n");
		dcl_prefs_put_comment("more detailed settings here...\n");

		dcl_prefs_put_lf ();
		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_alias", i+1);
			dcl_prefs_put_string(tmpbuffer, wmp_hosts[i].alias);
		}

		dcl_prefs_put_lf ();
		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_update_period", i+1);
			dcl_prefs_put_string(tmpbuffer, "");
		}

		dcl_prefs_put_lf ();
		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_led_color", i+1);
			dcl_prefs_put_string(tmpbuffer, "");
		}

		dcl_prefs_put_lf ();

	}
        
	dcl_prefs_closefile ();
}

/*----------------------------------------------------------------------*/

void wmpiki_read_prefs(void) 
{
char tmpbuffer[MAX_VALUE_LEN];
int i;

	defined_hosts_number = 0;

	if (dcl_prefs_openfile (dcl_getfilename_config(".clay", "wmpiki.rc"), P_READ)) {

		for(i=0; i<MAX_HOSTS; i++)
			defined_hosts[i] = false;

		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d", i+1);
			dcl_strcpy(wmp_hosts[i].host, dcl_prefs_get_string (tmpbuffer), MAX_VALUE_LEN);
			if (isalnum(wmp_hosts[i].host[0])) {
				defined_hosts[i] = true;
				defined_hosts_number++;
			}
		}

		update_period = dcl_prefs_get_int("update_period");

		if (update_period) {

			if (update_period > MAX_PERIOD)
				update_period = MAX_PERIOD;

			else if (update_period < MIN_PERIOD)
				update_period = MIN_PERIOD;

		}

		else
			update_period = 180;	

		led_color = dcl_prefs_get_int("led_color") % 10;
		if (led_color == GRAY || !led_color)
			led_color = GREEN;

		small_font = dcl_prefs_get_int("small_font") % 2;
		disable_logo = dcl_prefs_get_int("disable_logo") % 2;
		dcl_strcpy(ping_options, dcl_prefs_get_string ("ping_options"), MAX_VALUE_LEN);
        dcl_strcpy(command_lmb, dcl_prefs_get_string("command_lmb"), MAX_VALUE_LEN);
        dcl_strcpy(command_rmb, dcl_prefs_get_string("command_rmb"), MAX_VALUE_LEN);

        cmd_lmb = strlen(command_lmb);
        cmd_rmb = strlen(command_rmb);

		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_alias", i+1);
			dcl_strcpy(wmp_hosts[i].alias, dcl_prefs_get_string (tmpbuffer), MAX_VALUE_LEN);

			if (!strlen(wmp_hosts[i].alias))
				dcl_strcpy(wmp_hosts[i].alias, wmp_hosts[i].host, MAX_VALUE_LEN); 
		}

		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_update_period", i+1);
			wmp_hosts[i].update_period = dcl_prefs_get_int(tmpbuffer);

			if (wmp_hosts[i].update_period) {

				if (wmp_hosts[i].update_period > MAX_PERIOD)
					wmp_hosts[i].update_period = MAX_PERIOD;
	
				else if (wmp_hosts[i].update_period < MIN_PERIOD)
					wmp_hosts[i].update_period = MIN_PERIOD;

			}

			else {
				wmp_hosts[i].update_period = update_period;
			}
		}

		for(i=0; i<MAX_HOSTS; i++) {
			sprintf(tmpbuffer, "host%d_led_color", i+1);
			wmp_hosts[i].led = dcl_prefs_get_int(tmpbuffer) % 10;

			if (!wmp_hosts[i].led)
				wmp_hosts[i].led = led_color;

			else if (wmp_hosts[i].led == GRAY)
				wmp_hosts[i].led = GREEN;

		}
    
		dcl_prefs_closefile ();
        
	} else {

		for(i=0; i<MAX_HOSTS; i++)
			defined_hosts[i] = false;

		defined_hosts_number = 4;

		for(i=0; i<defined_hosts_number; i++) {
			defined_hosts[i] = true;
			dcl_strcpy(wmp_hosts[i].host, "localhost", MAX_VALUE_LEN);
			dcl_strcpy(wmp_hosts[i].alias, "local", MAX_VALUE_LEN);
			wmp_hosts[i].update_period = 180;
			wmp_hosts[i].led = GREEN;
		}

		update_period = 180;
		led_color = 2;
		small_font = 0;
		disable_logo = 0;
		dcl_strcpy(ping_options, "-c 1", MAX_VALUE_LEN);
        dcl_strcpy(command_lmb, "gnome-nettool", MAX_VALUE_LEN);
        dcl_strcpy(command_rmb, "ethereal", MAX_VALUE_LEN);

		wmpiki_write_prefs ();

	}
}

/*----------------------------------------------------------------------*/

int main(int argc, char **argv)
{
	wmpiki_read_prefs(); 
	wmpiki_routine(argc, argv);
	return 0;
}

