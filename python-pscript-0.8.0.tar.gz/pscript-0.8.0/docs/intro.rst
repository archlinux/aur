PScript introduction
====================

.. automodule:: pscript
