#pragma once
#include "../tree/node.h"

void simplification_init();
void simplification_unload();
bool core_simplify(Node **tree);
