#pragma once
#include "../tree/node.h"

double arith_evaluate(Node *node);
