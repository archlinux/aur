#pragma once
#include "../tree/node.h"

void core_update_history(ConstantType value);
bool core_replace_history(Node **tree);
