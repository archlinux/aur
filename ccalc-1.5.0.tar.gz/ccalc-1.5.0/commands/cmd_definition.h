#pragma once
#include <stdbool.h>

bool cmd_definition_check(char *input);
bool cmd_definition_exec(char *input);
