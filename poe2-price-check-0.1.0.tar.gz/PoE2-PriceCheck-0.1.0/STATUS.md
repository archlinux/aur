# Estado del proyecto — 1 agosto 2026

Punto de retomada tras una pausa. `CLAUDE.md` sigue siendo la referencia de
reglas; esto es la foto de qué está hecho, qué falta y qué se aprendió.

Rama `master`, árbol limpio, 17 commits ese día. Todo verde:

```bash
npx tsc --noEmit
npx tsx src/utils/parseItem.check.ts     # parser
npx tsx src/utils/priceCheck.check.ts    # contrato de búsqueda
npx tsx src/utils/weapon.check.ts        # DPS
cargo test --manifest-path src-tauri/Cargo.toml   # 10 tests de trade.rs
```

## Qué hace hoy la pestaña Price Check

Ctrl+C sobre un item en el juego → el watcher del portapapeles lo emite →
`parseItem` lo convierte en `ParsedItem` → el panel lo muestra en estilo
tooltip del juego → "Search trade" consulta la API real de GGG y lista los
resultados con su mediana en divines.

**Va solo contra trade2, nunca contra poe.ninja.** El atajo que mostraba el
precio de poe.ninja para uniques se eliminó a petición del usuario: la gracia
es ver las publicaciones reales. poe.ninja solo aporta las tasas de cambio
para normalizar los precios de los resultados a divine.

### La cabecera

Centrada como el tooltip del juego, sin pills ni cajas (dos rediseños
descartados antes de llegar aquí: chips-pill y ciclos yes/no visibles).

- **Rareza**: select limitado a las rarezas plausibles según el número de
  affixes explícitos (3+ → solo rare; 1-2 → magic/rare; 0 → las tres; unique
  fijo). Caret dorado para que se vea que despliega.
- **corrupted / fractured**: tres estados, click cicla `–` → `✓` → `✗`.
  `–` (any) es el default y no viaja en la query.
- **ilvl / Q% / sockets**: la etiqueta alterna, el número edita.
- **Stats base** (crítico, APS, defensas) y, en armas, **DPS**: filtros
  propios, independientes de los mods. Sin quality, Q arranca en 0.

### Los mods

Orden del portapapeles: enchant → runas → implicit → prefijos/sufijos. Click
en la línea alterna; min/max solo en los que tienen tirada. Las runas no
llevan min/max (valor fijo). El affix fracturado lleva tag dorado y el botón
⛓ lo marca. Las filas Σ suman mods que comparten statId.

### La búsqueda

`searchedStats(item, sel, sums)` es el contrato: lo que el panel muestra es
exactamente lo que viaja. El botón está activo sin mods marcados (buscar
bases es un caso de uso de primera).

Si vuelve vacía, el panel lista la búsqueda entera para que se vea qué filtro
la estrechó. Si un mod no tiene id en trade2, se avisa y se busca sin él.

## Lo que falta (por orden de utilidad)

1. **Botón "abrir en la web"** con el search id que ya devuelve la API:
   `pathofexile.com/trade2/search/poe2/<liga>/<id>`. Barato y muy útil para
   contrastar.
2. **Precio propio del item**: el copy trae `Note: ~b/o 15 divine` cuando el
   item está en una pestaña de venta. Hoy se ignora a propósito; mostrarlo
   permitiría comparar tu precio con el mercado. El usuario mostró interés.
3. **Mediana ponderada por antigüedad**: hoy es la mediana simple de los
   listados de menos de 7 días. Los más baratos suelen ser tabs muertas.
4. **Texto de un item fracturado real** para `parseItem.check.ts`: ese caso
   usa una cabecera inventada. El fractured de los guantes reales sí está
   cubierto, así que es cosmético.
5. Categorías del trade (`type_filters.category`) para buscar "cualquier
   arco" en vez de la base exacta.

## Verificación pendiente en vivo

Los últimos cuatro arreglos (reduced/increased, stats sin valor, anointments
vía grupo explicit, paréntesis vacíos) tienen test pero **no se llegaron a
probar contra la API real** — se acabó la sesión antes. Al retomar: copiar el
arco, el Headhunter y el Megalomaniac y confirmar que devuelven resultados.

## Cómo se depura esto

El log del Rust (`dev.log`) imprime la query entera antes de mandarla:

```bash
grep 'trade_search' dev.log | tail -3
```

Eso dice si el fallo está en la query o en el mercado. `0 results of 0 total`
es el servidor diciendo que no hay nada; `0 results of N total` con N > 0 es
un fallo nuestro al traer los detalles.

Para ver cómo indexa GGG un mod concreto, el dump cacheado es la fuente de
verdad — nunca adivinar el texto:

```bash
grep -o '"id":"[a-z]*\.stat_[0-9]*","text":"[^"]*Attack Speed[^"]*"' \
  ~/.config/com.poe2pricecheck.app/trade_stats.json
```

**Los probes con curl consumen el mismo presupuesto que la app**: van por la
misma IP. Un puñado de pruebas y un penalti de 8 minutos bloquea también al
usuario. Con sesión configurada el presupuesto es de la cuenta y no se cruzan.
