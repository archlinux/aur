# PoE2 Price Check

Tauri v2 + React + TypeScript desktop app showing Path of Exile 2 economy data
from poe.ninja. All HTTP lives in Rust (`src-tauri/src/api.rs`) and is reached
from the frontend through `invoke()` — the webview never calls poe.ninja
directly, which is what keeps CORS out of the picture.

## Never hardcode a league or a category

Both are discovered from poe.ninja's sitemap at runtime. Leagues rotate every few
months; anything written into the source is broken by the next one. If you need a
league name while debugging, take it from `fetch_leagues` output, not from a
string literal.

The same applies to the category list. `slug_to_api_type` has a small exception
table for slugs poe.ninja names differently — extend that when a category is
wrong, rather than introducing a fixed list of categories anywhere.

## poe.ninja fails silently

A wrong `type=` returns **HTTP 200 with `lines: []`**, never a 404. A category
that renders empty is far more likely to be a wrong type name or the wrong API
than a network problem. See the Data Sources section in `README.md` for the
exchange-vs-stash split.

When adding or debugging a category, verify against the real endpoint before
changing parsing code. The fastest way to find what poe.ninja actually calls is
to open the corresponding page and read its network requests — the type names
are not derivable from the URL slug in every case.

## Discovery is cached on disk

`discovery.json` in the config dir holds the last successful league list,
category list and stash-route map (~3 KB). Any of the three discovery paths
falls back to it rather than failing, so a sitemap change no longer empties the
app. Delete the file to force a clean rediscovery.

To test the fallback without touching the network stack, point the process at a
dead proxy — poe.ninja becomes unreachable while the vite dev server stays up:

```bash
HTTPS_PROXY=http://127.0.0.1:9 HTTP_PROXY=http://127.0.0.1:9 \
  NO_PROXY=localhost,127.0.0.1 npm run tauri dev
```

Only a well-formed empty response retires a cached route. A transport error
must not: it says nothing about which API serves a category, and discarding the
route on every network blip costs a wasted request to relearn.

## Never present old data as fresh

Prices are always live — nothing about them is written to disk. The one
exception is `lastGoodRef`, which keeps a category's previous values when its
refresh fails, so a blip does not blank the table.

That trade only holds if the age is visible. Each category carries the time its
data was actually obtained, reusing values does not touch it, and the status bar
names the categories that are behind. Anything added later that reuses old
values has to carry its own timestamp — the header's "Updated" is the cycle
time and does not speak for rows that did not refresh in it.

## Config lives under the bundle identifier

`~/.config/com.poe2pricecheck.app/`, from `identifier` in `tauri.conf.json` — not
the package name. Editing a file at any other path silently does nothing.

## Running it from a non-graphical shell

`npm run tauri dev` needs a display. A shell that did not inherit the desktop
session panics in GTK init (`Failed to initialize gtk backend!`). Pass the
session's variables explicitly:

```bash
XDG_RUNTIME_DIR=/run/user/1000 WAYLAND_DISPLAY=wayland-1 DISPLAY=:0 \
  npm run tauri dev > dev.log 2>&1
```

Rust-side `eprintln!` shows up in that log. Frontend `console.log` does **not** —
it stays in the webview, so use the devtools window for anything in `src/`.

Only one instance can run: the second fails on port 5173, not on anything
interesting.

## StrictMode doubles the startup fetches in dev

`main.tsx` mounts under `<React.StrictMode>`, so effects run twice and startup
does league discovery, category discovery and the whole price fetch more than
once. Cycles were seen going as high as five when the async pieces resolved in
an unlucky order. **This does not happen in a production build** — verified by
removing StrictMode and measuring: one of each.

Do not go hunting for a re-fetch loop before ruling this out. Count the cycles:

```bash
grep -c 'type=Currency ' dev.log     # price fetch cycles
grep -c 'fetching sitemap.xml' dev.log
```

A useful check after any change to the app: 32 price responses per cycle
(23 exchange + 9 stash) and no panics.

```bash
grep -c 'lines for' dev.log
grep -icE 'panic|PARSE ERROR' dev.log
```

## Refresh loop

`usePriceData` fetches currency first (it carries `chaosPerDivine`, which every
other category normalizes against), then the rest through a pool of 4.

Two things there are deliberate and easy to undo by accident:

- `divineRef`/`lastGoodRef` are refs, not state, so `fetchAll` does not depend on
  them. Adding either to the `useCallback` deps re-creates `fetchAll`, and the
  copy captured by `setInterval` goes stale — the symptom is auto-refreshes
  normalizing against a divine price of 0.
- A category that fails keeps its previous result instead of being blanked. The
  cache is scoped to the league it was fetched for.
- Runs carry a generation id. Switching league mid-fetch leaves the old run in
  flight, and it must not publish over the new league's data.

## UI notes

Native form controls need `appearance: none` before they match the theme. The
platform otherwise draws its own arrow, font and focus ring on top of whatever
colours are set — this bit the league `<select>` and the number inputs in the
price range, and will bite any control added later.

Item ids are `category::detailsId`. Never key them off the line index: on the
exchange route that index is the item's position in a price-sorted list, and
favorites are persisted by id.

To reset child state from a parent, adjust state during render rather than in
an effect. Effects run after paint, so an effect-based reset shows the old
value for one painted frame — visible as a stagger when several things clear
at once. `ItemTable`'s search reset is the worked example.

## The trade API punishes guessing

`src-tauri/src/trade.rs` talks to GGG's trade2. Its rate limit — 30 searches
per 5 minutes, then a 30-minute penalty, per IP — makes a wrong guess cost
real time, and the app shares that budget with any curl you run while
debugging. **Read `data/filters` and the cached `trade_stats.json` instead of
guessing.** Every rule below was a wrong guess that returned zero results and
looked exactly like an empty market:

- Filters live where `data/filters` says: `rarity`/`ilvl`/`quality` under
  `type_filters`, `corrupted`/`fractured_item` under `misc_filters`, DPS and
  defences under `equipment_filters`. Instant buyout is not a `sale_type` —
  it is `status: securable`.
- The same visible text can be two stat ids. Weapons and armour carry the
  `(Local)` variant of their own mods; filtering the global id on a bow
  matches nothing.
- GGG indexes one direction of a pair: "50% reduced X" is the negative side
  of "#% increased X", so it matches flipped, with the bound negated and its
  ends swapped.
- A number GGG spells out instead of writing `#` is part of the sentence, not
  a filterable roll (Headhunter's "for 60 seconds"). Those search by presence.
- Anointments say `{ Enhancement }` on the item but live in the `explicit`
  group, with a compound id (`explicit.stat_2954116742|3698`).

The clipboard is equally literal: the game prints `Allocates Spike Pit()` with
empty parens, and reads out an attack rate rounded to two decimals while
dividing internally by an attack *time* — so any DPS derived from it is up to
0.4% high and the search hands that margin back. Never assume the text is
clean; paste a real copy into `parseItem.check.ts` and let it decide.

## Price Check searches the trade site only

Never route that tab through poe.ninja, even when a price is already in hand
for a unique: the point is seeing the live listings. poe.ninja stays as the
source of exchange rates for normalising results to divine.

`searchedStats(item, sel, sums)` is the contract between panel and query —
what the panel shows is what travels. Anything added to one belongs in the
other. Searching with no mods selected is valid and must stay enabled: base
searches are a first-class use.
