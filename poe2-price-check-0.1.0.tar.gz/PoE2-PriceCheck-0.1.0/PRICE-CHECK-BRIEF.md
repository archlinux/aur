# Brief: the Price Check panel

> **Done and superseded — kept for the fixture and the reasoning only.**
> The panel shipped, the parser exists (`src/utils/parseItem.ts`) and the
> trade layer is live (`src-tauri/src/trade.rs`). The constraints below
> ("do not touch src-tauri", "do not call the trade API", "the parser does
> not exist") describe the state in July 2026 and no longer hold.
> For where the work actually stands, read `STATUS.md`.

Read `CLAUDE.md` first — its rules apply here in full. This file only covers
what is specific to the Price Check feature.

## Your job

Design and build **the Price Check page**: the React component and its CSS.

**In scope:** `src/components/PriceCheckTab.tsx`, new components it needs, and
styles in `src/styles.css`.

**Out of scope — do not touch:**

- Anything in `src-tauri/`. The Rust side is done and working.
- The trade API. Do not call it, do not write the fetch layer, do not import
  anything that would. It is rate limited to **30 searches per 5 minutes and
  30 minutes of ban if you overrun**, so an accidental loop during development
  is expensive. Build against the fixture described below.
- The parser. It does not exist yet. You define the TypeScript type you want to
  render and provide a fixture; the parser gets written afterwards to fill it.

So: a page that renders a parsed item and a set of trade results, driven by
static fixture data, correct and finished as a UI.

## What already works

Ctrl+C on a hovered item in Path of Exile 2 puts its text on the clipboard. A
watcher in `src-tauri/src/clipboard.rs` picks it up, filters on the
`Item Class:` prefix, and emits an `item-copied` Tauri event with the raw text.
`App.tsx` listens, stores it in `copiedItem`, and switches to the `price-check`
tab. Today `PriceCheckTab` just prints that raw text in a `<pre>`.

There is no global hotkey and nothing is injected into the game. Do not add one.

## The input: what the game gives you

Verbatim, from a real copy. This is your fixture — use it.

```
Item Class: Bows
Rarity: Rare
Torment Breeze
Obliterator Bow
--------
Quality: +26% (augmented)
Physical Damage: 274-509 (augmented)
Lightning Damage: 6-180 (lightning)
Critical Hit Chance: 8.51% (augmented)
Attacks per Second: 1.27 (augmented)
--------
Requires: Level 78, 163 Dex
--------
Sockets: S S
--------
Item Level: 79
--------
40% increased Physical Damage (rune)
--------
{ Implicit Modifier }
50% reduced Projectile Range
--------
{ Prefix Modifier "Cruel" (Tier: 3) — Damage, Physical, Attack }
148(135-154)% increased Physical Damage
{ Prefix Modifier "Electrocuting" (Tier: 2) — Damage, Elemental, Lightning, Attack }
Adds 6(1-10) to 180(157-196) Lightning Damage
{ Prefix Modifier "Conqueror's" (Tier: 3) — Damage, Physical, Attack }
63(55-64)% increased Physical Damage
+138(124-149) to Accuracy Rating
{ Suffix Modifier "of Shards" (Tier: 2) — Attack }
+149(125-150)% Surpassing chance to fire an additional Arrow
{ Desecrated Suffix Modifier "of Amanamu" (Tier: 1) }
15(12-18)% increased Attack Speed
Companions have 16(12-18)% increased Attack Speed
{ Crafted Suffix Modifier "of Calamity" (Tier: 3) — Attack, Critical }
+3.51(3.11-3.8)% to Critical Hit Chance
--------
Corrupted
```

Things in there that the design has to account for:

- **The app requires the game's "Advanced Mod Descriptions" option to be on.**
  That is a settled decision. It is what produces the `{ Prefix Modifier ... }`
  headers and the `148(135-154)` inline ranges, and it hands you the affix type,
  the **tier**, the tags, and **the roll range** with no external database. If
  the option is off, the app says so rather than guessing — you may need an
  error state for that.
- **A roll has a position in its range.** `148(135-154)` is 68% of the way up.
  This is the most useful number on the screen: it is what says whether the mod
  is good. Show it.
- **`(rune)` mods are not the item's.** `40% increased Physical Damage (rune)`
  comes from a socketed rune and must never be part of a search. Exclude it —
  but **show that it was excluded**. Silent exclusion means that the day it
  breaks, nobody notices.
- **One affix can produce two lines.** See "of Amanamu". Do not lay out on the
  assumption that one line equals one mod.
- **Two affixes can feed the same stat.** "Cruel" gives 148% increased Physical
  Damage and "Conqueror's" another 63%. **The trade searches the total, 211%.**
  If the user ticks both, the UI has to show the sum, because the sum is what
  gets searched and anything else looks like a bug.
- Rarity, item level, quality, sockets and `Corrupted` are all present and all
  matter to a buyer.

## The output: what a trade result looks like

Real shape, from a real response. Fixture this too.

```json
{
  "listing": {
    "indexed": "2026-06-24T19:35:19Z",
    "price": { "type": "~price", "amount": 1, "currency": "exalted" },
    "account": { "name": "Someone#1234", "online": { "league": "Runes of Aldur" } },
    "whisper": "@Character Hi, I would like to buy your ..."
  },
  "item": { "name": "...", "baseType": "...", "ilvl": 79, "explicitMods": ["..."] }
}
```

- Prices arrive in **mixed currencies** (exalted, regal, divine). The app
  already holds poe.ninja's rates, so normalising them costs nothing — show both
  the listed price and its normalised value.
- `listing.indexed` is often **weeks old**. Show every listing regardless of
  age — a season item still sitting there unsold is exactly the signal the user
  wants — but **the age is always visible on the row**. That is a hard
  requirement from `CLAUDE.md`: showing old data is fine, presenting it as fresh
  is not.
- `account.online` means the seller is connected right now. Worth a mark.
- `listing.whisper` is a ready-made buy message. Give it a copy button.

## Two states of the same page

1. **Currency, uniques, gems, tablets** — the price is already in the app from
   poe.ninja. No search, no button, no checkboxes: it just appears.
2. **Rares** — no price exists until the user runs a trade search. This state
   must read as an action the user takes, not as something loading.

Design both. State 2 is the harder one and the one the fixture covers.

## The search controls

The user picks which mods to search on, with checkboxes, and presses a button.
Nothing searches automatically. Two reasons, both real: the rate limit above,
and the user knows which mod matters on their item better than a heuristic
would. Pre-selecting a guess is a later refinement, not now.

**Show the remaining search budget.** GGG returns the current state in response
headers on every call, so the number is real, not estimated. Overrunning costs a
30-minute ban, which makes it the one number that cannot be hidden in a tooltip.

## A sketch, not a spec

This is roughly what was agreed. Improve it — the layout is yours, the content
is not.

```
Torment Breeze                 rare    ilvl 79
Obliterator Bow      Q +26%   corrupted   2 sockets
-----------------------------------------------
[x] T3   148%   increased Physical Damage
         135 |=============-----| 154      68%
[x] T2   6-180 Adds Lightning Damage                 94%
[ ] T3   +138  to Accuracy Rating
[ ] T2   +149% Surpassing chance to fire an extra Arrow
[ ] T1   15%   increased Attack Speed        desecrated
  not searched ---------------------------------
    40% increased Physical Damage              (rune)
-----------------------------------------------
[ Search trade ]        online [x]     27/30 in 5m
-----------------------------------------------
  1 ex     ~ 0.11 div    5 weeks ago    offline  [copy]
  1 regal  ~ 0.01 div    6 hours ago    online   [copy]
  2 ex     ~ 0.22 div    4 days ago     online   [copy]
```

## House rules for the UI

From `CLAUDE.md`, all learned the hard way here:

- **Native form controls need `appearance: none`** before they match the theme.
  Checkboxes and buttons in this design will otherwise be drawn by the platform
  with its own colours and focus ring. This has already bitten the league
  `<select>` and the price-range number inputs.
- **To reset child state from a parent, adjust state during render, not in an
  effect.** Effects run after paint, so an effect-based reset shows the previous
  item's data for one painted frame — very visible when a new item arrives.
  `ItemTable`'s search reset is the worked example in this repo.
- Colours come from the CSS variables at the top of `src/styles.css`
  (`--gold`, `--bg-secondary`, `--text-primary`, `--divine`, …). Do not
  introduce new hex values without a reason.
- Existing structure to match: `.tab-content` wrapper, `.tab-header` with an
  `<h2>` and a `.tab-subtitle`. Follow it.
- **Never hardcode a league or a category.** Both are discovered at runtime.
- React runs under `StrictMode` in dev, so effects run twice. Do not chase a
  double render as a bug.

## When you are done

`npx tsc --noEmit` must be clean. The app is normally already running under
`npm run tauri dev`, which hot-reloads the frontend.

Leave one runnable check behind for the non-trivial logic you add — the roll
percentage and the per-stat summing both deserve one. An `assert`-based test
file is enough; there is no test framework in this repo and you should not add
one.
