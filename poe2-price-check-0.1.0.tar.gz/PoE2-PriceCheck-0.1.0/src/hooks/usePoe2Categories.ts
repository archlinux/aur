import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";
import type { Category, Poe2CategoryInfo } from "../types";
import { buildCategoryFromInfo } from "../utils/categories";

export function usePoe2Categories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    invoke<Poe2CategoryInfo[]>("fetch_poe2_categories")
      .then((infos) => {
        setCategories(infos.map(buildCategoryFromInfo));
      })
      .catch((e) => {
        console.error("[usePoe2Categories] failed:", e);
      })
      .finally(() => setLoading(false));
  }, []);

  return { categories, loading };
}
