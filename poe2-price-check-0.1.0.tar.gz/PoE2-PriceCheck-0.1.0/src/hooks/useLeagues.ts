import { useState, useEffect, useMemo } from "react";
import { invoke } from "@tauri-apps/api/core";
import { parseLeagues, selectLeague } from "../utils/leagues";
import type { LeagueInfo, AppConfig } from "../types";

export function useLeagues(config: AppConfig) {
  const [leagues, setLeagues] = useState<LeagueInfo[]>([]);
  const [activeLeague, setActiveLeague] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    invoke<unknown>("fetch_leagues")
      .then((raw) => {
        if (cancelled) return;
        const parsed = parseLeagues(raw);
        setLeagues(parsed);
        const selected = selectLeague(parsed, config.preferred_league);
        console.log("[useLeagues] selected:", selected);
        setActiveLeague(selected);
        setError(null);
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        console.error("[useLeagues] fetch_leagues error:", e);
        setError(String(e));
        setActiveLeague("Standard");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [config.preferred_league]);

  // Compute the actual API league name based on difficulty.
  // leagues only contain SC entries; hcId is the HC variant name from discovery.
  const apiLeague = useMemo(() => {
    if (!activeLeague) return "";
    const leagueObj = leagues.find((l) => l.id === activeLeague);
    const hcId = leagueObj?.hcId;
    if (config.difficulty === "hardcore") {
      if (hcId) {
        console.log(`[useLeagues] apiLeague → "${hcId}" (HC, discovered hcId for "${activeLeague}")`);
        return hcId;
      }
      console.warn(`[useLeagues] HC requested for "${activeLeague}" but no hcId discovered — falling back to SC`);
    } else {
      console.log(`[useLeagues] apiLeague → "${activeLeague}" (SC, hcId=${hcId ?? "none"})`);
    }
    return activeLeague;
  }, [activeLeague, leagues, config.difficulty]);

  return { leagues, activeLeague, setActiveLeague, apiLeague, error, loading };
}
