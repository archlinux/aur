import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import type { AppConfig } from "../types";

const DEFAULT_CONFIG: AppConfig = {
  preferred_league: "latest",
  difficulty: "softcore",
  refresh_interval_minutes: 5,
  window_width: 1280,
  window_height: 800,
  theme: "dark",
};

export function useConfig() {
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    invoke<AppConfig>("get_config")
      .then(setConfig)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const updateConfig = useCallback(async (updates: Partial<AppConfig>) => {
    const next = { ...config, ...updates };
    setConfig(next);
    try {
      await invoke("save_config", { config: next });
    } catch (e) {
      console.error("Failed to save config:", e);
    }
  }, [config]);

  return { config, updateConfig, loading };
}
