import { useState, useEffect, useCallback, useRef } from "react";
import { invoke } from "@tauri-apps/api/core";

export function useFavorites() {
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  // Until the initial read lands, the empty set is not the user's data and must
  // not be written back over the file.
  const loaded = useRef(false);

  useEffect(() => {
    invoke<string[]>("get_favorites")
      .then((ids) => {
        loaded.current = true;
        setFavorites(new Set(ids));
      })
      .catch(console.error);
  }, []);

  // Persisting here rather than inside the updater: React may call an updater
  // more than once (StrictMode does in dev), and writing to disk is not
  // something to do twice per toggle.
  useEffect(() => {
    if (!loaded.current) return;
    invoke("save_favorites", { favorites: Array.from(favorites) }).catch(console.error);
  }, [favorites]);

  const toggle = useCallback((id: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  return { favorites, toggle };
}
