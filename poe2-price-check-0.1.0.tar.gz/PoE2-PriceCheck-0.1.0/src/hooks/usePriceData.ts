import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { invoke } from "@tauri-apps/api/core";
import type { NormalizedItem, AppConfig, Category, ItemOverviewResponse } from "../types";
import { normalizeItems } from "../utils/normalize";

interface PriceDataState {
  items: Map<string, NormalizedItem[]>;
  activeCategoryIds: Set<string> | null;
  lastUpdated: Date | null;
  loading: boolean;
  error: string | null;
  loadingCategory: string | null;
  /// Categories showing data older than the cycle that just finished.
  stale: { label: string; at: Date }[];
}

export function usePriceData(league: string, config: AppConfig, categories: Category[]) {
  const [state, setState] = useState<PriceDataState>({
    items: new Map(),
    activeCategoryIds: null,
    lastUpdated: null,
    loading: false,
    error: null,
    loadingCategory: null,
    stale: [],
  });
  const [divinePrice, setDivinePrice] = useState(0);
  // ref mirror: fetchAll must not depend on divinePrice, or the interval closure goes stale
  const divineRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // last good result per category: a transient API failure must not blank the table
  const lastGoodRef = useRef<Map<string, NormalizedItem[]>>(new Map());
  // When each category's data was actually obtained — not when the cycle that
  // reused it ran. Reporting the cycle time for reused data would overstate how
  // fresh it is, which is the whole point of keeping it.
  const fetchedAtRef = useRef<Map<string, number>>(new Map());
  const leagueRef = useRef("");
  // bumped per fetchAll; a run whose id is stale must not publish its results
  const runIdRef = useRef(0);

  // Depend on the category identities, not the array's. A re-fetch of the
  // category list produces an equal-but-new array, and keying the effect off
  // that would replay all 23 requests for no new information.
  const catKey = categories.map((c) => c.id).join(",");

  const fetchAll = useCallback(async () => {
    if (!league || categories.length === 0) return;
    console.log("[usePriceData] fetchAll for league:", league, "categories:", categories.length);

    // Switching league mid-fetch leaves the old run in flight. It must not
    // publish its results over the new league's, nor poison the cache.
    const runId = ++runIdRef.current;
    const isStale = () => runIdRef.current !== runId;

    setState((s) => ({ ...s, loading: true, error: null, loadingCategory: null }));

    // cached items belong to the league they were fetched for
    if (leagueRef.current !== league) {
      lastGoodRef.current = new Map();
      fetchedAtRef.current = new Map();
      leagueRef.current = league;
    }

    const cycleStart = Date.now();

    const newItems = new Map<string, NormalizedItem[]>();
    const errors: string[] = [];

    // Reads divineRef at normalize time, so anything fetched after currency uses the fresh rate.
    const fetchCategory = async (cat: Category) => {
      let normalized: NormalizedItem[] = [];
      let failed = false;

      try {
        console.log(`[usePriceData] API call: league="${league}" category="${cat.id}"`);
        const data = await invoke<ItemOverviewResponse>("fetch_item_overview", {
          league,
          category: cat.id,
        });
        console.log(`[usePriceData] ${cat.id}: ${data.lines.length} lines`);

        // Extract divine price from Currency category
        if (cat.slug === "currency" && data.chaosPerDivine && data.chaosPerDivine > 0) {
          divineRef.current = data.chaosPerDivine;
          setDivinePrice(data.chaosPerDivine);
          console.log("[usePriceData] divine price from Currency:", data.chaosPerDivine);
        }

        normalized = normalizeItems(data, cat.id, divineRef.current, cat.label);
      } catch (e) {
        console.error(`[usePriceData] poe.ninja error ${cat.id}:`, e);
        errors.push(`${cat.label}: ${String(e)}`);
        failed = true;
      }

      // poe.watch fallback when poe.ninja returns nothing
      if (normalized.length === 0 && cat.watchCategory) {
        console.log(`[usePriceData] ${cat.id}: trying poe.watch (${cat.watchCategory})`);
        try {
          const watchData = await invoke<ItemOverviewResponse>("fetch_watch_items", {
            league,
            watchCategory: cat.watchCategory,
          });
          console.log(`[usePriceData] poe.watch ${cat.id}: ${watchData.lines.length} items`);
          normalized = normalizeItems(watchData, cat.id, divineRef.current, cat.label);
        } catch (e) {
          console.warn(`[usePriceData] poe.watch fallback failed ${cat.id}:`, e);
        }
      }

      // fallback produced data → not a failure after all
      return { items: normalized, failed: failed && normalized.length === 0 };
    };

    const run = async (cat: Category) => {
      const { items, failed } = await fetchCategory(cat);
      if (isStale()) return;
      const prev = lastGoodRef.current.get(cat.id);
      if (failed && prev && prev.length > 0) {
        // Reused, so its fetch time stays whatever it already was.
        console.warn(`[usePriceData] ${cat.id}: keeping ${prev.length} cached items`);
        newItems.set(cat.id, prev);
      } else {
        newItems.set(cat.id, items);
        fetchedAtRef.current.set(cat.id, Date.now());
      }
      setState((s) => ({
        ...s,
        loadingCategory: `${newItems.size}/${categories.length} categories`,
      }));
    };

    // currency alone first: it carries chaosPerDivine, which every other category normalizes against
    const currency = categories.find((c) => c.slug === "currency");
    if (currency) await run(currency);

    // ponytail: fixed pool of 4, raise if poe.ninja tolerates more
    const queue = categories.filter((c) => c !== currency);
    await Promise.all(
      Array.from({ length: Math.min(4, queue.length) }, async () => {
        for (let cat = queue.shift(); cat; cat = queue.shift()) await run(cat);
      }),
    );

    if (isStale()) {
      console.log("[usePriceData] discarding stale run for league:", league);
      return;
    }
    lastGoodRef.current = newItems;

    const activeIds = new Set<string>();
    newItems.forEach((catItems, catId) => {
      if (catItems.length > 0) activeIds.add(catId);
    });

    const stale = categories
      .filter((c) => (newItems.get(c.id)?.length ?? 0) > 0)
      .map((c) => ({ label: c.label, at: fetchedAtRef.current.get(c.id) ?? 0 }))
      .filter((c) => c.at < cycleStart)
      .map((c) => ({ label: c.label, at: new Date(c.at) }));

    setState({
      items: newItems,
      activeCategoryIds: activeIds,
      lastUpdated: new Date(),
      loading: false,
      error: errors[0] ?? null,
      loadingCategory: null,
      stale,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [league, catKey]);

  // Initial fetch + auto-refresh
  useEffect(() => {
    if (!league || categories.length === 0) return;
    fetchAll();

    const intervalMs = (config.refresh_interval_minutes || 5) * 60 * 1000;
    timerRef.current = setInterval(fetchAll, intervalMs);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [league, catKey, config.refresh_interval_minutes]);

  // Memoized, not a function: consumers sort thousands of items off this, and a
  // fresh array on every render defeats their useMemo.
  const allItems = useMemo(() => {
    const all: NormalizedItem[] = [];
    state.items.forEach((items) => all.push(...items));
    return all;
  }, [state.items]);

  return {
    ...state,
    divinePrice,
    fetchAll,
    allItems,
  };
}
