// Run: npx tsx src/utils/priceCheck.check.ts
// @ts-ignore
import assert from "node:assert";
import {
  rollPct, sumCheckedByStatId, medianRecentDiv, toDivine, ageString,
  searchedStats, selKey, runeKey,
} from "./priceCheck";
import type { ParsedItem, Stat, TradeResult } from "../types/priceCheck";

// rollPct
assert.strictEqual(rollPct({ text: "", statId: "", value: 148, range: { min: 135, max: 154 } }), 68);
assert.strictEqual(rollPct({ text: "", statId: "", value: 135, range: { min: 135, max: 154 } }), 0);
assert.strictEqual(rollPct({ text: "", statId: "", value: 154, range: { min: 135, max: 154 } }), 100);
assert.strictEqual(rollPct({ text: "", statId: "", value: 10 }), null);          // no range
assert.strictEqual(rollPct({ text: "", statId: "", value: 5, range: { min: 5, max: 5 } }), null); // zero-width

// sumCheckedByStatId: only statIds with 2+ checked stats produce a sum
const phys1: Stat = { text: "148%", statId: "increased Physical Damage", value: 148 };
const phys2: Stat = { text: "63%", statId: "increased Physical Damage", value: 63 };
const acc: Stat = { text: "+138", statId: "to Accuracy Rating", value: 138 };
assert.deepStrictEqual(
  sumCheckedByStatId([phys1, phys2, acc]),
  new Map([["increased Physical Damage", 211]]),
);
assert.deepStrictEqual(sumCheckedByStatId([phys1, acc]), new Map());

// toDivine: chaos rates from poe.ninja; divinePrice = chaos per divine
const rates = new Map([["exalted", 55], ["regal", 5.5], ["divine", 550]]);
assert.strictEqual(toDivine(1, "exalted", rates, 550), 0.1);
assert.strictEqual(toDivine(2, "divine", rates, 550), 2);
assert.strictEqual(toDivine(1, "unknown-orb", rates, 550), null);
assert.strictEqual(toDivine(1, "exalted", rates, 0), null);

// medianRecentDiv: online-filtered rows come in; keep indexed < 7 days; median of div values
const now = new Date("2026-07-31T12:00:00Z").getTime();
const mk = (daysAgo: number, amount: number): TradeResult => ({
  listing: {
    indexed: new Date(now - daysAgo * 86400_000).toISOString(),
    price: { type: "~price", amount, currency: "exalted" },
    account: { name: "a#1" },
    whisper: "w",
  },
  item: { name: "", baseType: "", ilvl: 0, explicitMods: [] },
});
const med = medianRecentDiv([mk(1, 1), mk(2, 2), mk(40, 99)], rates, 550, now);
if (med) {
  assert.strictEqual(med.n, 2);
  assert.ok(Math.abs(med.div - 0.15) < 1e-9);                 // median of [0.1, 0.2]
} else {
  throw new Error("med should not be null");
}
assert.strictEqual(medianRecentDiv([mk(40, 99)], rates, 550, now), null);

// ageString
assert.strictEqual(ageString(new Date(now - 6 * 3600_000).toISOString(), now), "6 h ago");
assert.strictEqual(ageString(new Date(now - 4 * 86400_000).toISOString(), now), "4 d ago");
assert.strictEqual(ageString(new Date(now - 35 * 86400_000).toISOString(), now), "5 w ago");
assert.strictEqual(ageString(new Date(now - 30 * 60_000).toISOString(), now), "30 min ago");

// searchedStats: mirrors what the panel shows — checked stats not folded into
// an active Σ, plus one row per active Σ, min/max exactly as stored in state.
const item: ParsedItem = {
  itemClass: "Ring", rarity: "rare", name: "Test Ring", baseType: "Gold Ring",
  ilvl: 82, sockets: 0, corrupted: false, baseStats: [],
  affixes: [
    { kind: "prefix", tags: [], desecrated: false, crafted: false, stats: [phys1] },
    { kind: "prefix", tags: [], desecrated: false, crafted: false, stats: [phys2] },
    { kind: "suffix", tags: [], desecrated: false, crafted: false, stats: [acc] },
    // enchant sharing a statId with the explicits — must never fold into their Σ
    {
      kind: "enchant", tags: [], desecrated: false, crafted: false,
      stats: [{ text: "20% increased Physical Damage", statId: "increased Physical Damage", value: 20 }],
    },
  ],
  runeMods: [{ text: "40% increased Physical Damage", statId: "increased Physical Damage", value: 40 }],
};
const sel = {
  [selKey(0, 0)]: { checked: true, min: "100", max: "" },
  [selKey(1, 0)]: { checked: true, min: "50", max: "" },
  [selKey(2, 0)]: { checked: true, min: "120", max: "150" },
};
const sums = { "increased Physical Damage": { min: "211", max: "" } };
const searched = searchedStats(item, sel, sums);
// Σ rows carry a representative stat text (the trade layer matches ids by
// text — a bare total would be unmatchable), min/max from state.
assert.deepStrictEqual(searched, [
  { statId: "to Accuracy Rating", text: "+138", min: "120", max: "150" },
  { statId: "increased Physical Damage", text: "148%", min: "211", max: "" },
]);
// unseeded Σ falls back to blank, not the total (state, not display, is the source of truth)
assert.deepStrictEqual(
  searchedStats(item, sel, {}),
  [
    { statId: "to Accuracy Rating", text: "+138", min: "120", max: "150" },
    { statId: "increased Physical Damage", text: "148%", min: "", max: "" },
  ],
);

// enchant/rune selections carry a kind tag and never fold into Σ sums,
// even when the statId matches an explicit mod (trade2 namespaces them apart)
const selWithFixed = {
  ...sel,
  [selKey(3, 0)]: { checked: true, min: "20", max: "" },
  [runeKey(0)]: { checked: true, min: "", max: "" },
};
assert.deepStrictEqual(searchedStats(item, selWithFixed, sums), [
  { statId: "to Accuracy Rating", text: "+138", min: "120", max: "150" },
  { statId: "increased Physical Damage", text: "20% increased Physical Damage", min: "20", max: "", kind: "enchant" },
  { statId: "increased Physical Damage", text: "148%", min: "211", max: "" }, // Σ min still 211, not 231
  { statId: "increased Physical Damage", text: "40% increased Physical Damage", min: "40", max: "", kind: "rune" },
]);

console.log("priceCheck checks OK");
