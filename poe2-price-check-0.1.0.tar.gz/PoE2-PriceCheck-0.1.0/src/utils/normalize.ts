import type { ItemOverviewResponse, NormalizedItem } from "../types";

export function normalizeItems(
  data: ItemOverviewResponse,
  category: string,
  divinePrice = 0,
  // The API type name ("LineageSupportGems", "Ritual") is not what a reader
  // should see; carry the discovered label alongside it for display.
  categoryLabel?: string
): NormalizedItem[] {
  return data.lines.map((line) => ({
    // detailsId, never line.id: on the exchange route line.id is the item's
    // position in a list sorted by price, so favorites would follow the slot
    // rather than the item as prices move.
    id: `${category}::${line.detailsId || line.id}`,
    name: line.name,
    icon: line.icon,
    chaosValue: line.chaosValue,
    divineValue:
      line.divineValue > 0
        ? line.divineValue
        : divinePrice > 0
        ? line.chaosValue / divinePrice
        : 0,
    category,
    categoryLabel: categoryLabel ?? category,
    count: line.count,
    detailsId: line.detailsId,
    isCurrency: false,
    variant: line.variant,
    gemLevel: line.gemLevel,
    gemQuality: line.gemQuality,
    corrupted: line.corrupted,
    mapTier: line.mapTier,
    links: line.links,
  }));
}
