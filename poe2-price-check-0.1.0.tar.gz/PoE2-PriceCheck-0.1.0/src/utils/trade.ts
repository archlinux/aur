import { invoke } from "@tauri-apps/api/core";
import type { FilterState } from "../components/PriceCheckTab";
import type { ParsedItem, SearchBudget, SellerMode, TradeResult } from "../types/priceCheck";
import { searchedStats, type Selection, type SumEdits } from "./priceCheck";

export interface TradeSearchResponse {
  results: TradeResult[];
  budget: SearchBudget | null;   // null when GGG omitted the headers
  unmatched: string[];           // stat texts searched without (no trade2 id)
  total: number;
  retryAfterSecs: number | null; // seconds until the next search is allowed
}

export type BaseSel = Record<string, { on: boolean; min: string }>;

const num = (s: string) => (s.trim() === "" ? null : +s);

/** One search per user click — the rate limits (30/5min, 30-min ban) forbid
 *  anything automatic. The Rust side reads the headers and enforces it too. */
export function tradeSearch(
  league: string,
  item: ParsedItem,
  filters: FilterState,
  sel: Selection,
  sums: SumEdits,
  baseSel: BaseSel,
  seller: SellerMode,
): Promise<TradeSearchResponse> {
  const payload = {
    league,
    seller,
    rarity: filters.rarity,
    // uniques are a fixed item: exact name search; anything else goes by base
    name: item.rarity === "unique" && item.baseType ? item.name : null,
    baseType: item.baseType || null,
    // "any" stays out of the query entirely
    corrupted: filters.corrupted === "any" ? null : filters.corrupted === "yes",
    fractured: filters.fractured === "any" ? null : filters.fractured === "yes",
    ilvlMin: filters.ilvlOn ? num(filters.ilvl) : null,
    qualityMin: filters.qualityOn ? num(filters.quality) : null,
    socketsMin: filters.socketsOn ? num(filters.sockets) : null,
    baseStats: Object.entries(baseSel)
      .filter(([, s]) => s.on && s.min.trim() !== "")
      .map(([label, s]) => [label, +s.min] as [string, number]),
    // damage midpoints become DPS filters server-side: midpoint × APS
    aps: item.baseStats.find((b) => b.label === "Attacks per Second")?.value ?? null,
    // weapons/armour pieces carry the "(Local)" stat variants; base defences
    // or APS in the copied text are what betray one
    localMods: item.baseStats.some((b) =>
      ["Attacks per Second", "Armour", "Evasion Rating", "Energy Shield", "Runic Ward"].includes(b.label),
    ),
    stats: searchedStats(item, sel, sums).map((s) => ({
      text: s.text,
      kind: s.kind ?? null,
      min: num(s.min),
      max: num(s.max),
    })),
  };
  return invoke<TradeSearchResponse>("trade_search", { payload });
}
