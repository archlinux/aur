import type { Category, Poe2CategoryInfo } from "../types";

export const SPECIAL_TABS = [
  { id: "most-expensive", label: "Most Expensive", icon: "👑" },
  { id: "price-range", label: "Price Range", icon: "🔍" },
  { id: "favorites", label: "Favorites", icon: "⭐" },
  { id: "price-check", label: "Price Check", icon: "📋" },
];

export const isSpecialTab = (id: string) => SPECIAL_TABS.some((t) => t.id === id);

// Icon lookup by poe.ninja slug — new slugs get DEFAULT_ICON
const SLUG_ICONS: Record<string, string> = {
  "currency":              "💰",
  "fragments":             "🔮",
  "runes":                 "🔰",
  "essences":              "💎",
  "idols":                 "🗿",
  "soul-cores":            "🌑",
  "uncut-gems":            "🟢",
  "lineage-support-gems":  "🔵",
  "unique-weapons":        "⚔️",
  "unique-armours":        "🛡️",
  "unique-accessories":    "💍",
  "unique-flasks":         "🧪",
  "unique-jewels":         "🔶",
  "unique-charms":         "🧿",
  "unique-relics":         "✨",
  "unique-tablets":        "📜",
  "abyssal-bones":         "🦴",
  "breach-catalyst":       "⚗️",
  "expedition":            "🗺️",
  "liquid-emotions":       "💧",
  "omens":                 "🔮",
  "precursor-tablets":     "📋",
  "verisium":              "🌀",
};

const DEFAULT_CAT_ICON = "📦";

// poe.watch mixes PoE1+PoE2 data without separation — no reliable fallback
const WATCH_CATEGORY_MAP: Record<string, string> = {};

export function buildCategoryFromInfo(info: Poe2CategoryInfo): Category {
  return {
    id: info.apiType,
    slug: info.slug,
    label: info.label,
    icon: SLUG_ICONS[info.slug] ?? DEFAULT_CAT_ICON,
    watchCategory: WATCH_CATEGORY_MAP[info.slug],
  };
}
