import type { ParsedItem } from "../types/priceCheck";

/** Damage lines the trade site folds into elemental DPS. Chaos counts towards
 *  total DPS but has no elemental filter of its own. */
const ELEMENTAL = ["Fire Damage", "Cold Damage", "Lightning Damage"];
const DAMAGE_LINES = [...ELEMENTAL, "Physical Damage", "Chaos Damage"];

/**
 * Total DPS, as the trade site's Equipment Filters show it. Empty for
 * anything without an attack speed (armour, jewellery).
 *
 * Reads a touch high: the clipboard rounds attacks per second to two
 * decimals, while the game divides by an attack *time* internally (this bow
 * reads 1.27/s but is really 1/0.79 = 1.2658). The search compensates — see
 * the margin in trade.rs.
 */
export function derivedStats(item: ParsedItem): { label: string; value: number }[] {
  const aps = item.baseStats.find((b) => b.label === "Attacks per Second")?.value;
  if (!aps) return [];
  const damage = item.baseStats
    .filter((b) => DAMAGE_LINES.includes(b.label))
    .reduce((t, b) => t + b.value, 0);
  if (damage === 0) return [];
  return [{ label: "DPS", value: Math.round(damage * aps * 100) / 100 }];
}
