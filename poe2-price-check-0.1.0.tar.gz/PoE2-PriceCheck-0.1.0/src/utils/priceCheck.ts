import type { ParsedItem, Stat, TradeResult } from "../types/priceCheck";

export interface StatSel { checked: boolean; min: string; max: string }
export type Selection = Record<string, StatSel>;
export type SumEdits = Record<string, { min: string; max: string }>;

export function selKey(affixIdx: number, statIdx: number) {
  return `${affixIdx}:${statIdx}`;
}

/** Selection key for rune mods — fixed value, checkbox only. */
export function runeKey(idx: number) {
  return `rune:${idx}`;
}

/** Checked Stat objects in item order — enchants excluded: trade2 namespaces
 *  them apart from explicits, so they never fold into a Σ sum. */
export function checkedStats(item: ParsedItem, sel: Selection): Stat[] {
  const out: Stat[] = [];
  item.affixes.forEach((a, ai) => {
    if (a.kind === "enchant") return;
    a.stats.forEach((s, si) => {
      if (sel[selKey(ai, si)]?.checked) out.push(s);
    });
  });
  return out;
}

/** Roll position in its range, 0-100 rounded. null when no meaningful range. */
export function rollPct(stat: Stat): number | null {
  if (!stat.range) return null;
  const { min, max } = stat.range;
  if (max === min) return null;
  return Math.round(((stat.value - min) / (max - min)) * 100);
}

/** Totals per statId across checked stats; only ids fed by 2+ stats. */
export function sumCheckedByStatId(checked: Stat[]): Map<string, number> {
  const count = new Map<string, number>();
  const total = new Map<string, number>();
  for (const s of checked) {
    count.set(s.statId, (count.get(s.statId) ?? 0) + 1);
    total.set(s.statId, (total.get(s.statId) ?? 0) + s.value);
  }
  const sums = new Map<string, number>();
  for (const [id, n] of count) if (n >= 2) sums.set(id, total.get(id)!);
  return sums;
}

export interface SearchedStat {
  statId: string; text: string; min: string; max: string;
  /** trade2 stat group; absent = explicit chain (prefix/suffix/Σ rows) */
  kind?: "rune" | "enchant" | "implicit" | "unique";
}

/** What actually travels to a trade search: checked stats not folded into an
 *  active Σ, plus one row per active Σ — min/max always read from state, so
 *  this matches exactly what the panel displays. */
export function searchedStats(item: ParsedItem, sel: Selection, sums: SumEdits): SearchedStat[] {
  const checked = checkedStats(item, sel);
  const activeSums = sumCheckedByStatId(checked);

  // Σ rows must still name the stat: the trade layer matches ids by text, so
  // a bare total like "211" is unusable. First contributing text represents it.
  const sampleText = new Map<string, string>();
  for (const s of checked) if (!sampleText.has(s.statId)) sampleText.set(s.statId, s.text);

  const out: SearchedStat[] = [];
  item.affixes.forEach((a, ai) =>
    a.stats.forEach((s, si) => {
      const entry = sel[selKey(ai, si)];
      if (!entry?.checked) return;
      // enchants live outside Σ folding and carry their namespace tag
      if (a.kind === "enchant") {
        out.push({ statId: s.statId, text: s.text, min: entry.min, max: entry.max, kind: "enchant" });
        return;
      }
      if (activeSums.has(s.statId)) return;
      const kind = a.kind === "implicit" || a.kind === "unique" ? a.kind : undefined;
      out.push({ statId: s.statId, text: s.text, min: entry.min, max: entry.max, ...(kind && { kind }) });
    }),
  );
  for (const [statId, total] of activeSums) {
    const sum = sums[statId] ?? { min: "", max: "" };
    out.push({ statId, text: sampleText.get(statId) ?? `${total}`, min: sum.min, max: sum.max });
  }
  // rune mods have no roll: checked means "at least this exact value"
  item.runeMods.forEach((s, i) => {
    if (sel[runeKey(i)]?.checked)
      out.push({ statId: s.statId, text: s.text, min: String(s.value), max: "", kind: "rune" });
  });
  return out;
}

/** Listed price → divine, via chaos rates. null when the rate is unknown. */
export function toDivine(
  amount: number,
  currency: string,
  chaosRates: Map<string, number>, // currency slug → chaos per unit
  divinePrice: number,             // chaos per divine
): number | null {
  const rate = chaosRates.get(currency);
  if (rate === undefined || divinePrice <= 0) return null;
  return (amount * rate) / divinePrice;
}

const WEEK_MS = 7 * 86400_000;

/** Median (in div) of rows indexed < 7 days. null when none qualify or none normalise. */
export function medianRecentDiv(
  rows: TradeResult[],
  chaosRates: Map<string, number>,
  divinePrice: number,
  nowMs: number,
): { div: number; n: number } | null {
  const divs = rows
    .filter((r) => nowMs - Date.parse(r.listing.indexed) < WEEK_MS)
    .map((r) => toDivine(r.listing.price.amount, r.listing.price.currency, chaosRates, divinePrice))
    .filter((d): d is number => d !== null)
    .sort((a, b) => a - b);
  if (divs.length === 0) return null;
  const mid = Math.floor(divs.length / 2);
  const div = divs.length % 2 ? divs[mid] : (divs[mid - 1] + divs[mid]) / 2;
  return { div, n: divs.length };
}

/** "6 h ago" / "4 d ago" / "5 w ago" — age always visible, never hidden. */
export function ageString(indexed: string, nowMs: number): string {
  const mins = Math.max(0, Math.floor((nowMs - Date.parse(indexed)) / 60_000));
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} d ago`;
  return `${Math.floor(days / 7)} w ago`;
}

