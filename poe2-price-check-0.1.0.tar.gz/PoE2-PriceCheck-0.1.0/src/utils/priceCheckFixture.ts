import type { ParsedItem } from "../types/priceCheck";

// The brief's real copy, hand-parsed. The future parser must reproduce this.
export const FIXTURE_BOW: ParsedItem = {
  itemClass: "Bows",
  rarity: "rare",
  name: "Torment Breeze",
  baseType: "Obliterator Bow",
  ilvl: 79,
  baseStats: [
    { label: "Physical Damage", value: 391.5 },   // 274-509 midpoint
    { label: "Lightning Damage", value: 93 },     // 6-180 midpoint
    { label: "Critical Hit Chance", value: 8.51 },
    { label: "Attacks per Second", value: 1.27 },
  ],
  quality: 26,
  sockets: 2,
  corrupted: true,
  affixes: [
    {
      kind: "implicit", tags: [], desecrated: false, crafted: false,
      stats: [{ text: "50% reduced Projectile Range", statId: "reduced Projectile Range", value: 50 }],
    },
    {
      kind: "prefix", name: "Cruel", tier: 3,
      tags: ["Damage", "Physical", "Attack"], desecrated: false, crafted: false,
      stats: [{
        text: "148% increased Physical Damage", statId: "increased Physical Damage",
        value: 148, range: { min: 135, max: 154 },
      }],
    },
    {
      kind: "prefix", name: "Electrocuting", tier: 2,
      tags: ["Damage", "Elemental", "Lightning", "Attack"], desecrated: false, crafted: false,
      stats: [{
        // double value: midpoint of 6 and 180
        text: "Adds 6 to 180 Lightning Damage", statId: "Adds to Lightning Damage",
        value: 93, range: { min: 79, max: 103 }, // midpoints of (1-10) and (157-196)
      }],
    },
    {
      kind: "prefix", name: "Conqueror's", tier: 3,
      tags: ["Damage", "Physical", "Attack"], desecrated: false, crafted: false,
      stats: [
        {
          text: "63% increased Physical Damage", statId: "increased Physical Damage",
          value: 63, range: { min: 55, max: 64 },
        },
        {
          text: "+138 to Accuracy Rating", statId: "to Accuracy Rating",
          value: 138, range: { min: 124, max: 149 },
        },
      ],
    },
    {
      kind: "suffix", name: "of Shards", tier: 2,
      tags: ["Attack"], desecrated: false, crafted: false,
      stats: [{
        text: "+149% Surpassing chance to fire an additional Arrow",
        statId: "Surpassing chance to fire an additional Arrow",
        value: 149, range: { min: 125, max: 150 },
      }],
    },
    {
      kind: "suffix", name: "of Amanamu", tier: 1,
      tags: [], desecrated: true, crafted: false,
      stats: [
        {
          text: "15% increased Attack Speed", statId: "increased Attack Speed",
          value: 15, range: { min: 12, max: 18 },
        },
        {
          text: "Companions have 16% increased Attack Speed",
          statId: "Companions have increased Attack Speed",
          value: 16, range: { min: 12, max: 18 },
        },
      ],
    },
    {
      kind: "suffix", name: "of Calamity", tier: 3,
      tags: ["Attack", "Critical"], desecrated: false, crafted: true,
      stats: [{
        text: "+3.51% to Critical Hit Chance", statId: "to Critical Hit Chance",
        value: 3.51, range: { min: 3.11, max: 3.8 },
      }],
    },
  ],
  runeMods: [{
    text: "40% increased Physical Damage", statId: "increased Physical Damage", value: 40,
  }],
};
