// Run: npx tsx src/utils/weapon.check.ts
// @ts-ignore -- @types/node is not a direct dependency
import assert from "node:assert";
import { derivedStats } from "./weapon";
import { FIXTURE_BOW } from "./priceCheckFixture";
import type { ParsedItem } from "../types/priceCheck";

// The real bow: 274-509 phys, 6-180 lightning, 1.27 aps. The trade site shows
// DPS 613.29 for it (screenshot 2026-08-01); ours reads 0.33% high because the
// game divides by an attack time of 0.79s while the clipboard rounds to 1.27/s.
assert.deepStrictEqual(derivedStats(FIXTURE_BOW), [{ label: "DPS", value: 615.32 }]);

// within the rounding error the search margin gives back
const siteDps = 613.29;
const ours = derivedStats(FIXTURE_BOW)[0].value;
assert.ok(ours >= siteDps, `${ours} should not undershoot ${siteDps}`);
assert.ok(ours * 0.995 <= siteDps, `0.5% margin must clear ${siteDps}`);

// No attack speed (armour, jewellery) → nothing derived, no bogus DPS row
const jacket: ParsedItem = {
  ...FIXTURE_BOW,
  baseStats: [{ label: "Evasion Rating", value: 405 }, { label: "Energy Shield", value: 124 }],
};
assert.deepStrictEqual(derivedStats(jacket), []);

// A weapon with no damage lines at all derives nothing either
assert.deepStrictEqual(
  derivedStats({ ...FIXTURE_BOW, baseStats: [{ label: "Attacks per Second", value: 1.4 }] }),
  [],
);

console.log("weapon checks OK");
