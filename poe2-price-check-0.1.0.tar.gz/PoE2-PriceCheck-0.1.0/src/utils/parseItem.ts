import type { Affix, ParsedItem, Rarity, Stat } from "../types/priceCheck";

const RARITIES: readonly Rarity[] = ["normal", "magic", "rare", "unique"];

// "148(135-154)" — advanced-mod-descriptions inline range
const RANGE = /(\d+(?:\.\d+)?)\((\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)\)/g;

/** Grouping key: the stat text with numbers, %, + and ranges stripped. */
export function statIdOf(text: string): string {
  return text
    .replace(/[+%]/g, "")
    .replace(/\d+(?:\.\d+)?/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

const avg = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;

function parseStat(rawLine: string): Stat {
  const line = rawLine
    .replace(/\s*—\s*Unscalable Value$/, "")
    // the game itself prints empty parens on granted passives, e.g.
    // "Allocates Spike Pit()" on a Megalomaniac
    .replace(/\(\)/g, "")
    .trim();
  const matches = [...line.matchAll(RANGE)];
  const text = line.replace(RANGE, "$1");
  let value: number;
  let range: Stat["range"];
  if (matches.length > 0) {
    // "Adds 6(1-10) to 180(157-196)" carries two ranges; the trade filters on
    // the midpoint, so a multi-range line collapses to averages
    value = avg(matches.map((m) => +m[1]));
    const lo = avg(matches.map((m) => +m[2]));
    const hi = avg(matches.map((m) => +m[3]));
    // negative-is-better mods copy reversed, e.g. "71(80-70)% reduced"
    range = lo <= hi ? { min: lo, max: hi } : { min: hi, max: lo };
  } else {
    value = +(line.match(/\d+(?:\.\d+)?/)?.[0] ?? 0);
  }
  return { text, statId: statIdOf(text), value, ...(range && { range }) };
}

function parseHeader(inner: string): { fractured: boolean; affix: Affix } | null {
  // "{ Corruption Enhancement — tags }" / bare "{ Enhancement }" both mark
  // the mod a corruption (or anoint) adds; "{ Unique Modifier — tags }" is
  // a unique's fixed mod
  const kindWord = inner.match(/\b(Implicit|Prefix|Suffix|Unique) Modifier\b/)?.[1].toLowerCase()
    ?? (/\bEnhancement\b/.test(inner) ? "enchant" : null);
  if (!kindWord) return null;
  const name = inner.match(/"([^"]+)"/)?.[1];
  const tier = inner.match(/\(Tier: (\d+)\)/)?.[1];
  // tags run to the next "—", not the end: "— Damage, Attack — 20% Increased"
  // carries a quality note after the tag list
  const tags = inner.match(/—\s*([^—]+)/)?.[1].trim().split(", ") ?? [];
  return {
    fractured: /\bFractured\b/.test(inner),
    affix: {
      kind: kindWord as Affix["kind"],
      ...(name && { name }),
      ...(tier && { tier: +tier }),
      tags,
      desecrated: /\bDesecrated\b/.test(inner),
      crafted: /\bCrafted\b/.test(inner),
      stats: [],
    },
  };
}

/**
 * Raw clipboard text → ParsedItem. Returns null when the text is not an item,
 * or when a magic/rare item has no `{ … }` affix headers — that is Advanced
 * Mod Descriptions turned off, and the UI shows how to enable it. Unmodded
 * rarities (currency, gems…) legitimately have no headers and still parse.
 */
export function parseItem(text: string): ParsedItem | null {
  const sections = text.replace(/\r/g, "").trim().split(/\n-{4,}\n/);
  const head = sections[0].split("\n");
  const itemClass = head.find((l) => l.startsWith("Item Class: "))?.slice(12);
  const rawRarity = head.find((l) => l.startsWith("Rarity: "))?.slice(8);
  if (!itemClass || !rawRarity) return null;

  const nameLines = head.filter((l) => !l.includes(": "));
  const lower = rawRarity.toLowerCase() as Rarity;
  const rarity: Rarity = RARITIES.includes(lower) ? lower : "normal";
  if ((lower === "magic" || lower === "rare") && !text.includes("{ ")) return null;

  let ilvl = 0;
  const baseStats: { label: string; value: number }[] = [];
  let quality: number | undefined;
  let sockets = 0;
  let corrupted = false;
  let fracturedAffixIndex: number | undefined;
  const runeMods: Stat[] = [];
  const affixes: Affix[] = [];

  for (const sec of sections.slice(1)) {
    const lines = sec.split("\n").filter(Boolean);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const header = line.match(/^\{ (.+) \}$/);
      if (header) {
        const parsed = parseHeader(header[1]);
        if (!parsed) continue;
        while (i + 1 < lines.length && !lines[i + 1].startsWith("{")) {
          parsed.affix.stats.push(parseStat(lines[++i]));
        }
        if (parsed.fractured) fracturedAffixIndex = affixes.length;
        affixes.push(parsed.affix);
      } else if (/^Quality[^:]*: /.test(line)) {
        // "Quality: +26%" and "Quality (Attack Modifiers): +20%" both count
        quality = +(line.match(/\+?(\d+)%/)?.[1] ?? 0);
      } else if (line.startsWith("Sockets: ")) {
        sockets = line.slice(9).trim().split(/\s+/).length;
      } else if (line.startsWith("Item Level: ")) {
        ilvl = +line.slice(12);
      } else if (line === "Corrupted") {
        corrupted = true;
      } else if (line.endsWith(" (rune)")) {
        runeMods.push(parseStat(line.slice(0, -7)));
      } else if (!/^(Stack Size|Limited to|Note)\b/.test(line)) {
        // base item stats: "Label: N", "Label: N%" or "Label: A-B" (midpoint).
        // Non-numeric values (Requires, Grants Skill…) fall through harmlessly.
        const m = line.match(/^([A-Za-z][A-Za-z' ]*): (\d+(?:\.\d+)?)(?:-(\d+(?:\.\d+)?))?/);
        if (m) baseStats.push({ label: m[1], value: m[3] ? (+m[2] + +m[3]) / 2 : +m[2] });
      }
    }
  }

  return {
    itemClass,
    rarity,
    name: nameLines[0] ?? "",
    baseType: nameLines[1] ?? "",
    ilvl,
    baseStats,
    ...(quality !== undefined && { quality }),
    sockets,
    corrupted,
    ...(fracturedAffixIndex !== undefined && { fracturedAffixIndex }),
    affixes,
    runeMods,
  };
}
