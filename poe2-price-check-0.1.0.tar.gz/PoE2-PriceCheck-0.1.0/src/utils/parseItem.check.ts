// Run: npx tsx src/utils/parseItem.check.ts
// @ts-ignore -- @types/node is not a direct dependency
import assert from "node:assert";
import { parseItem, statIdOf } from "./parseItem";
import { FIXTURE_BOW } from "./priceCheckFixture";

// The brief's real copy, verbatim. Parsing it must reproduce FIXTURE_BOW.
const RAW_BOW = `Item Class: Bows
Rarity: Rare
Torment Breeze
Obliterator Bow
--------
Quality: +26% (augmented)
Physical Damage: 274-509 (augmented)
Lightning Damage: 6-180 (lightning)
Critical Hit Chance: 8.51% (augmented)
Attacks per Second: 1.27 (augmented)
--------
Requires: Level 78, 163 Dex
--------
Sockets: S S
--------
Item Level: 79
--------
40% increased Physical Damage (rune)
--------
{ Implicit Modifier }
50% reduced Projectile Range
--------
{ Prefix Modifier "Cruel" (Tier: 3) — Damage, Physical, Attack }
148(135-154)% increased Physical Damage
{ Prefix Modifier "Electrocuting" (Tier: 2) — Damage, Elemental, Lightning, Attack }
Adds 6(1-10) to 180(157-196) Lightning Damage
{ Prefix Modifier "Conqueror's" (Tier: 3) — Damage, Physical, Attack }
63(55-64)% increased Physical Damage
+138(124-149) to Accuracy Rating
{ Suffix Modifier "of Shards" (Tier: 2) — Attack }
+149(125-150)% Surpassing chance to fire an additional Arrow
{ Desecrated Suffix Modifier "of Amanamu" (Tier: 1) }
15(12-18)% increased Attack Speed
Companions have 16(12-18)% increased Attack Speed
{ Crafted Suffix Modifier "of Calamity" (Tier: 3) — Attack, Critical }
+3.51(3.11-3.8)% to Critical Hit Chance
--------
Corrupted`;

// statIdOf: numbers, %, + and parenthesised ranges vanish; spaces collapse
assert.strictEqual(statIdOf("148% increased Physical Damage"), "increased Physical Damage");
assert.strictEqual(statIdOf("63% increased Physical Damage"), "increased Physical Damage");
assert.strictEqual(statIdOf("Adds 6 to 180 Lightning Damage"), "Adds to Lightning Damage");
assert.strictEqual(statIdOf("+138 to Accuracy Rating"), "to Accuracy Rating");
assert.strictEqual(
  statIdOf("Companions have 16% increased Attack Speed"),
  "Companions have increased Attack Speed",
);
assert.strictEqual(statIdOf("+3.51% to Critical Hit Chance"), "to Critical Hit Chance");

// The whole item round-trips to the hand-parsed fixture
assert.deepStrictEqual(parseItem(RAW_BOW), FIXTURE_BOW);

// No advanced-mod headers -> null (the "option is off" error state)
assert.strictEqual(parseItem(RAW_BOW.replace(/\{ .*? \}\n/g, "")), null);
assert.strictEqual(parseItem("Item Class: Bows\nRarity: Rare\nSome Bow"), null);

// A fractured header marks the affix and the item
const RAW_FRACTURED = RAW_BOW.replace(
  '{ Prefix Modifier "Cruel" (Tier: 3)',
  '{ Fractured Prefix Modifier "Cruel" (Tier: 3)',
);
const fractured = parseItem(RAW_FRACTURED);
if (!fractured) throw new Error("fractured item did not parse");
assert.strictEqual(fractured.fracturedAffixIndex, 1); // affix 0 is the implicit
assert.deepStrictEqual(
  fractured.affixes.map((a) => a.name),
  FIXTURE_BOW.affixes.map((a) => a.name),
);

// A magic item with a single name line still parses
const RAW_MAGIC = `Item Class: Quivers
Rarity: Magic
Primed Quiver of the Drake
--------
Item Level: 42
--------
{ Suffix Modifier "of the Drake" (Tier: 6) — Elemental, Fire, Resistance }
+21(18-23)% to Fire Resistance`;
const magic = parseItem(RAW_MAGIC);
if (!magic) throw new Error("magic item did not parse");
assert.strictEqual(magic.rarity, "magic");
assert.strictEqual(magic.name, "Primed Quiver of the Drake");
assert.strictEqual(magic.baseType, "");
assert.strictEqual(magic.ilvl, 42);
assert.strictEqual(magic.quality, undefined);
assert.strictEqual(magic.sockets, 0);
assert.strictEqual(magic.corrupted, false);
assert.strictEqual(magic.affixes.length, 1);
assert.deepStrictEqual(magic.affixes[0].stats[0], {
  text: "+21% to Fire Resistance",
  statId: "to Fire Resistance",
  value: 21,
  range: { min: 18, max: 23 },
});

// Currency has no mods, hence no { } headers even with the option on —
// it must still parse so the poe.ninja price state can key off the name.
const RAW_CURRENCY = `Item Class: Stackable Currency
Rarity: Currency
Chaos Orb
--------
Stack Size: 20/20
--------
Reforges a rare item with new random modifiers`;
const currency = parseItem(RAW_CURRENCY);
if (!currency) throw new Error("currency did not parse");
assert.strictEqual(currency.name, "Chaos Orb");
assert.strictEqual(currency.itemClass, "Stackable Currency");
assert.strictEqual(currency.affixes.length, 0);

// A corruption-added mod copies as a "{ Corruption Enhancement — tags }"
// header (real copy, verbatim); it parses as an affix of kind "enchant".
// Corruption does not always add one — absence is fine.
const RAW_JACKET = `Item Class: Body Armours
Rarity: Magic
Maestro's Sleek Jacket of Convalescence
--------
Evasion Rating: 405 (augmented)
Energy Shield: 124 (augmented)
--------
Requires: Level 65, 67 Dex, 67 Int
--------
Item Level: 81
--------
{ Corruption Enhancement — Chaos, Resistance }
+15(13-19)% to Chaos Resistance
--------
{ Prefix Modifier "Maestro's" (Tier: 1) — Life, Evasion, Energy Shield }
42(39-42)% increased Evasion and Energy Shield
+47(42-49) to maximum Life
{ Suffix Modifier "of Convalescence" (Tier: 5) — Life }
13.9(13.1-18) Life Regeneration per second
--------
Corrupted`;
const jacket = parseItem(RAW_JACKET);
if (!jacket) throw new Error("jacket did not parse");
assert.strictEqual(jacket.rarity, "magic");
assert.strictEqual(jacket.corrupted, true);
assert.strictEqual(jacket.fracturedAffixIndex, undefined);
assert.deepStrictEqual(jacket.affixes[0], {
  kind: "enchant", tags: ["Chaos", "Resistance"], desecrated: false, crafted: false,
  stats: [{
    text: "+15% to Chaos Resistance", statId: "to Chaos Resistance",
    value: 15, range: { min: 13, max: 19 },
  }],
});
assert.deepStrictEqual(
  jacket.affixes.map((a) => [a.kind, a.name, a.stats.length]),
  [["enchant", undefined, 1], ["prefix", "Maestro's", 2], ["suffix", "of Convalescence", 1]],
);

// Amulet (real copy): bare "{ Enhancement }" is an enchant, "— Unscalable
// Value" strips from the stat text, "Quality (Attack Modifiers)" counts as
// quality, and the fractured header is found among ordinary prefixes.
const RAW_AMULET = `Item Class: Amulets
Rarity: Rare
Corpse Scarab
Lunar Amulet
--------
Quality (Attack Modifiers): +13% (augmented)
--------
Requires: Level 52
--------
Item Level: 79
--------
{ Enhancement }
Allocates Wild Storm — Unscalable Value
--------
{ Implicit Modifier — Energy Shield }
+26(20-30) to maximum Energy Shield
--------
{ Fractured Prefix Modifier "Chalybeous" (Tier: 5) — Mana }
+115(105-124) to maximum Mana
{ Prefix Modifier "Countess'" (Tier: 1) }
+47(47-50) to Spirit
{ Suffix Modifier "of Ruin" (Tier: 2) — Critical }
33(30-34)% increased Critical Hit Chance
--------
Fractured Item`;
const amulet = parseItem(RAW_AMULET);
if (!amulet) throw new Error("amulet did not parse");
assert.strictEqual(amulet.quality, 13);
assert.strictEqual(amulet.affixes[0].kind, "enchant");
assert.strictEqual(amulet.affixes[0].stats[0].text, "Allocates Wild Storm");
assert.strictEqual(amulet.fracturedAffixIndex, 2); // after enchant + implicit

// Unique (Headhunter): "{ Unique Modifier — tags }" parses as kind "unique",
// several implicits coexist, flavour text sections are ignored.
const RAW_HH = `Item Class: Belts
Rarity: Unique
Headhunter
Heavy Belt
--------
Requires: Level 50
--------
Item Level: 81
--------
{ Implicit Modifier }
22(20-30)% increased Stun Threshold
{ Implicit Modifier — Charm }
Has 2(1-3) Charm Slots
--------
{ Unique Modifier — Attribute }
+24(20-40) to Strength
{ Unique Modifier — Life }
+38(40-60) to maximum Life
{ Unique Modifier }
When you kill a Rare monster, you gain its Modifiers for 60 seconds
--------
"The head is where the Man is."
- Lavianga, Advisor to Kaom
--------
Corrupted`;
const hh = parseItem(RAW_HH);
if (!hh) throw new Error("headhunter did not parse");
assert.deepStrictEqual(
  hh.affixes.map((a) => a.kind),
  ["implicit", "implicit", "unique", "unique", "unique"],
);
assert.strictEqual(hh.corrupted, true);
assert.deepStrictEqual(hh.affixes[2].tags, ["Attribute"]);

// Tags stop at the second "—": "— Damage, ... — 20% Increased" must not leak
// the quality note into the tag list.
const ringAffix = parseItem(`Item Class: Rings
Rarity: Rare
Fate Spiral
Gold Ring
--------
Item Level: 82
--------
{ Prefix Modifier "Electrocuting" (Tier: 1) — Damage, Elemental, Lightning, Attack — 20% Increased }
Adds 3(1-4) to 67(60-71) Lightning damage to Attacks`)?.affixes[0];
assert.deepStrictEqual(ringAffix?.tags, ["Damage", "Elemental", "Lightning", "Attack"]);

// Reversed range "71(80-70)% reduced" normalises to min<=max
const flaskStat = parseItem(`Item Class: Mana Flasks
Rarity: Unique
Lavianga's Spirits
Gargantuan Mana Flask
--------
Item Level: 79
--------
{ Unique Modifier }
71(80-70)% reduced Amount Recovered
--------
Corrupted`)?.affixes[0].stats[0];
assert.deepStrictEqual(flaskStat, {
  text: "71% reduced Amount Recovered", statId: "reduced Amount Recovered",
  value: 71, range: { min: 70, max: 80 },
});

// Megalomaniac (real copy): the game prints empty parens after a granted
// passive, and the jewel's "Limited to" / price note must not become filters.
const RAW_JEWEL = `Item Class: Jewels
Rarity: Unique
Megalomaniac
Diamond
--------
Limited to: 1
--------
Item Level: 79
--------
{ Enhancement }
Allocates Spike Pit() — Unscalable Value
{ Enhancement }
Allocates Advanced Munitions() — Unscalable Value
--------
If you're going to act like you're better
than everyone else, make sure you are.
--------
Place into an allocated Jewel Socket on the Passive Skill Tree. Right click to remove from the Socket.
--------
Corrupted
--------
Note: ~b/o 15 divine`;
const jewel = parseItem(RAW_JEWEL);
if (!jewel) throw new Error("jewel did not parse");
assert.strictEqual(jewel.name, "Megalomaniac");
assert.strictEqual(jewel.baseType, "Diamond");
assert.strictEqual(jewel.corrupted, true);
assert.deepStrictEqual(jewel.baseStats, []); // "Limited to: 1" is not a stat
assert.deepStrictEqual(
  jewel.affixes.map((a) => [a.kind, a.stats[0].text]),
  [["enchant", "Allocates Spike Pit"], ["enchant", "Allocates Advanced Munitions"]],
);
// a granted passive carries no number: value 0, no range, statId is the text
assert.deepStrictEqual(jewel.affixes[0].stats[0], {
  text: "Allocates Spike Pit", statId: "Allocates Spike Pit", value: 0,
});

console.log("parseItem checks OK");
