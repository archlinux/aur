import type { LeagueInfo } from "../types";

export function parseLeagues(raw: unknown): LeagueInfo[] {
  if (!Array.isArray(raw)) return [];

  const parsed: LeagueInfo[] = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) continue;
    const l = item as Record<string, unknown>;
    const id = typeof l["id"] === "string" ? l["id"] : null;
    if (!id) continue;

    parsed.push({
      id,
      realm: typeof l["realm"] === "string" ? l["realm"] : "poe2",
      isHardcore: Boolean(l["isHardcore"]),
      isStandard: Boolean(l["isStandard"]),
      displayName: typeof l["displayName"] === "string" ? l["displayName"] : id,
      hcId: typeof l["hcId"] === "string" ? l["hcId"] : undefined,
    });
  }

  console.log("[parseLeagues] SC leagues:", parsed.map((l) => `${l.id}${l.hcId ? ` (HC: ${l.hcId})` : ""}`));
  return parsed;
}

export function selectLeague(leagues: LeagueInfo[], preferredLeague: string): string {
  // A stored league name wins, but only while that league still exists —
  // leagues end, and a saved name must not strand the app on a dead one.
  const saved = leagues.find((l) => l.id === preferredLeague);
  if (saved) return saved.id;

  if (preferredLeague === "standard") {
    return leagues.find((l) => l.isStandard)?.id ?? leagues[0]?.id ?? "Standard";
  }
  // Pick first temp (non-standard) league, fall back to Standard
  return leagues.find((l) => !l.isStandard)?.id ?? leagues[0]?.id ?? "Standard";
}
