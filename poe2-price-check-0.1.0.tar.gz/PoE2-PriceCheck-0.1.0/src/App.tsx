import { useState, useEffect, useRef, useMemo } from "react";
import { listen } from "@tauri-apps/api/event";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { CategoryTab } from "./components/CategoryTab";
import { MostExpensiveTab } from "./components/MostExpensiveTab";
import { PriceRangeTab, type PriceRange } from "./components/PriceRangeTab";
import { FavoritesTab } from "./components/FavoritesTab";
import { PriceCheckTab } from "./components/PriceCheckTab";
import { isSpecialTab } from "./utils/categories";
import { useConfig } from "./hooks/useConfig";
import { useFavorites } from "./hooks/useFavorites";
import { useLeagues } from "./hooks/useLeagues";
import { usePoe2Categories } from "./hooks/usePoe2Categories";
import { usePriceData } from "./hooks/usePriceData";

export default function App() {
  const { config, updateConfig } = useConfig();
  const { favorites, toggle: toggleFavorite } = useFavorites();
  const { leagues, activeLeague, setActiveLeague, apiLeague } = useLeagues(config);
  const { categories } = usePoe2Categories();
  const {
    items,
    activeCategoryIds,
    lastUpdated,
    loading,
    loadingCategory,
    divinePrice,
    error,
    stale,
    fetchAll,
    allItems,
  } = usePriceData(apiLeague, config, categories);

  const [activeTab, setActiveTab] = useState("most-expensive");
  // Lives here, not in the tab: the tab unmounts on every switch away.
  const [priceRange, setPriceRange] = useState<PriceRange>({
    min: "",
    max: "",
    unit: "chaos",
  });
  const [nextRefreshIn, setNextRefreshIn] = useState(0);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // The last item copied out of the game. It lives here rather than in the tab
  // because the tab unmounts on every switch away — a copy made while looking
  // at another category still has to land somewhere.
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  useEffect(() => {
    let stop: (() => void) | undefined;
    let cancelled = false;

    // listen() resolves after the fact, so an unmount racing it would leak the
    // listener. StrictMode makes that race happen on every dev startup.
    listen<string>("item-copied", (e) => {
      setCopiedItem(e.payload);
      setActiveTab("price-check");
    }).then((unlisten) => {
      if (cancelled) unlisten();
      else stop = unlisten;
    });

    return () => {
      cancelled = true;
      stop?.();
    };
  }, []);

  // Redirect to most-expensive if active category was pruned (returned 0 data)
  useEffect(() => {
    if (!activeCategoryIds) return;
    if (!isSpecialTab(activeTab) && !activeCategoryIds.has(activeTab)) {
      setActiveTab("most-expensive");
    }
  }, [activeCategoryIds, activeTab]);

  // F5 refetches prices. preventDefault matters: the webview would otherwise
  // reload the whole app, throwing away league discovery and every category.
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "F5") return;
      e.preventDefault();
      if (loading) return;
      fetchAll();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [fetchAll, loading]);

  // Countdown timer
  useEffect(() => {
    if (lastUpdated) {
      const intervalSecs = (config.refresh_interval_minutes || 5) * 60;
      setNextRefreshIn(intervalSecs);

      if (countdownRef.current) clearInterval(countdownRef.current);
      countdownRef.current = setInterval(() => {
        setNextRefreshIn((s) => Math.max(0, s - 1));
      }, 1000);
    }
    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [lastUpdated, config.refresh_interval_minutes]);

  const handleLeagueChange = (leagueId: string) => {
    setActiveLeague(leagueId);
    updateConfig({ preferred_league: leagueId });
  };

  const handleDifficultyChange = (d: string) => {
    updateConfig({ difficulty: d });
  };

  const exaltedPrice = useMemo(() => {
    // Locate the currency category by slug rather than by its API type name:
    // the type is poe.ninja's to rename, the slug is what we discover it by.
    const currencyId = categories.find((c) => c.slug === "currency")?.id;
    const currencyItems = (currencyId && items.get(currencyId)) || [];
    return currencyItems.find((i) => i.name === "Exalted Orb")?.chaosValue ?? 0;
  }, [items, categories]);

  const categoryIcons = useMemo(() => {
    const m = new Map<string, string>();
    items.forEach((catItems, catId) => {
      const icon = catItems[0]?.icon;
      if (icon) m.set(catId, icon);
    });
    return m;
  }, [items]);

  const activeCategory = categories.find((c) => c.id === activeTab);
  const currentItems = items.get(activeTab) ?? [];

  return (
    <ErrorBoundary>
      <div className="app-layout">
        <Header
          leagues={leagues}
          activeLeague={activeLeague}
          config={config}
          lastUpdated={lastUpdated}
          loading={loading}
          loadingCategory={loadingCategory}
          divinePrice={divinePrice}
          error={error}
          stale={stale}
          onLeagueChange={handleLeagueChange}
          onDifficultyChange={handleDifficultyChange}
          onRefresh={fetchAll}
          nextRefreshIn={nextRefreshIn}
        />

        <div className="app-body">
          <Sidebar
            activeTab={activeTab}
            categories={categories}
            activeCategoryIds={activeCategoryIds}
            categoryIcons={categoryIcons}
            onTabChange={setActiveTab}
          />

          <main className="main-content">
            <ErrorBoundary>
              {activeTab === "most-expensive" && (
                <MostExpensiveTab
                  allItems={allItems}
                  favorites={favorites}
                  onToggleFavorite={toggleFavorite}
                  loading={loading}
                  exaltedPrice={exaltedPrice}
                />
              )}
              {activeTab === "price-range" && (
                <PriceRangeTab
                  allItems={allItems}
                  favorites={favorites}
                  onToggleFavorite={toggleFavorite}
                  loading={loading}
                  exaltedPrice={exaltedPrice}
                  range={priceRange}
                  onRangeChange={setPriceRange}
                />
              )}
              {activeTab === "favorites" && (
                <FavoritesTab
                  allItems={allItems}
                  favorites={favorites}
                  onToggleFavorite={toggleFavorite}
                  exaltedPrice={exaltedPrice}
                />
              )}
              {activeTab === "price-check" && (
                <PriceCheckTab
                  text={copiedItem}
                  allItems={allItems}
                  divinePrice={divinePrice}
                  activeLeague={activeLeague}
                />
              )}
              {!isSpecialTab(activeTab) && activeCategory && (
                <CategoryTab
                  category={activeCategory}
                  items={currentItems}
                  favorites={favorites}
                  onToggleFavorite={toggleFavorite}
                  loading={loading && loadingCategory !== null}
                  exaltedPrice={exaltedPrice}
                />
              )}
            </ErrorBoundary>
          </main>
        </div>
      </div>
    </ErrorBoundary>
  );
}
