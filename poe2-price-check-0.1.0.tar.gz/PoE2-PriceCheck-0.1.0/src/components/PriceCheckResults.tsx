import type { TradeResult } from "../types/priceCheck";
import { ageString, medianRecentDiv, toDivine } from "../utils/priceCheck";

interface Props {
  results: TradeResult[]; // exactly what the trade search returned
  chaosRates: Map<string, number>;
  divinePrice: number;
}

export function PriceCheckResults({ results, chaosRates, divinePrice }: Props) {
  const now = Date.now();
  const shown = results
    .slice()
    .sort((a, b) => {
      const da = toDivine(a.listing.price.amount, a.listing.price.currency, chaosRates, divinePrice);
      const db = toDivine(b.listing.price.amount, b.listing.price.currency, chaosRates, divinePrice);
      if (da === null && db === null) return 0; // unknowns keep a stable order
      if (da === null) return 1;
      if (db === null) return -1;
      return da - db;
    });

  if (shown.length === 0) {
    return <div className="pc-no-results">The trade search returned no listings — loosen a filter.</div>;
  }

  const median = medianRecentDiv(shown, chaosRates, divinePrice, now);

  return (
    <div className="pc-results">
      {shown.map((r, i) => {
        const { amount, currency } = r.listing.price;
        const div = toDivine(amount, currency, chaosRates, divinePrice);
        const online = !!r.listing.account.online;
        return (
          <div className="pc-result" key={i}>
            <span className="pc-price">{amount} {currency}</span>
            <span className="pc-div">{div !== null ? `≈ ${div.toFixed(2)} div` : "—"}</span>
            <span className="pc-age">{ageString(r.listing.indexed, now)}</span>
            <span className={`pc-online ${online ? "on" : ""}`} title={online ? "Seller online" : "Seller offline"}>
              {online ? "●" : "○"}
            </span>
            <button
              type="button"
              className="pc-copy"
              title="Copy whisper"
              onClick={() => navigator.clipboard.writeText(r.listing.whisper).catch(() => {})}
            >
              ⧉
            </button>
          </div>
        );
      })}

      <div className="pc-median">
        {median
          ? <>median (recent, n={median.n}): <strong>{median.div.toFixed(2)} div</strong></>
          : "no listings recent enough for a median"}
      </div>
    </div>
  );
}
