import { useState, useEffect } from "react";
import type { Category } from "../types";
import { SPECIAL_TABS } from "../utils/categories";

interface Props {
  activeTab: string;
  categories: Category[];
  activeCategoryIds: Set<string> | null;
  categoryIcons?: Map<string, string>;
  onTabChange: (id: string) => void;
}

function CategoryIcon({ src, fallback }: { src?: string; fallback: string }) {
  // Store which src failed rather than a boolean, so a refresh bringing a new
  // icon URL gets a fresh attempt instead of staying stuck on the fallback.
  const [failedSrc, setFailedSrc] = useState<string | null>(null);

  if (!src || failedSrc === src) {
    return <span className="sidebar-cat-icon sidebar-cat-emoji">{fallback}</span>;
  }

  return (
    <img
      src={src}
      alt=""
      className="sidebar-cat-icon"
      loading="lazy"
      onError={() => setFailedSrc(src)}
    />
  );
}

export function Sidebar({ activeTab, categories, activeCategoryIds, categoryIcons, onTabChange }: Props) {
  // Collapsed sections live here only — they reset on relaunch. Persisting them
  // would mean a new config field on both sides for a preference this small.
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const visibleCategories = activeCategoryIds === null
    ? categories
    : categories.filter((c) => activeCategoryIds.has(c.id));

  // Grouped by slug shape rather than a fixed list, so a category poe.ninja
  // adds later lands somewhere sensible on its own. Tablets are checked first:
  // unique-tablets is a tablet, not a unique, the same way poe.ninja files it.
  const groups = [
    { title: "Exchange", cats: [] as Category[] },
    { title: "Uniques", cats: [] as Category[] },
    { title: "Tablets", cats: [] as Category[] },
  ];
  for (const cat of visibleCategories) {
    const idx = cat.slug.endsWith("-tablets") ? 2 : cat.slug.startsWith("unique-") ? 1 : 0;
    groups[idx].cats.push(cat);
  }

  const toggleSection = (title: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(title)) {
        next.delete(title);
      } else {
        next.add(title);
      }
      return next;
    });

  const sectionTitles = groups.filter((g) => g.cats.length > 0).map((g) => g.title);
  const titleKey = sectionTitles.join(",");

  // Ctrl+A folds every section, or unfolds them when they are all folded.
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== "a" || e.altKey) return;

      // Ctrl+A is select-all first and foremost: leave it alone while the user
      // is in the search box or any other text field.
      const el = document.activeElement as HTMLElement | null;
      const tag = el?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || el?.isContentEditable) return;

      e.preventDefault();
      setCollapsed((prev) =>
        prev.size === sectionTitles.length ? new Set() : new Set(sectionTitles)
      );
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [titleKey]);

  return (
    <nav className="sidebar">
      <div className="sidebar-section">
        <div className="sidebar-section-title">Special</div>
        {SPECIAL_TABS.map((tab) => (
          <button
            key={tab.id}
            className={`sidebar-item ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => onTabChange(tab.id)}
          >
            <span className="item-icon">{tab.icon}</span>
            <span className="item-label">{tab.label}</span>
          </button>
        ))}
      </div>

      {groups.map(
        (group, i) =>
          group.cats.length > 0 && (
            <div className="sidebar-section" key={group.title}>
              <button
                className="sidebar-section-title"
                onClick={() => toggleSection(group.title)}
                aria-expanded={!collapsed.has(group.title)}
              >
                <span>
                  {group.title}
                  {i === 0 && activeCategoryIds === null && categories.length > 0 && (
                    <span className="sidebar-loading"> …</span>
                  )}
                </span>
                <span className={`section-chevron ${collapsed.has(group.title) ? "closed" : ""}`}>
                  ▾
                </span>
              </button>
              {!collapsed.has(group.title) &&
                group.cats.map((cat) => (
                  <button
                    key={cat.id}
                    className={`sidebar-item ${activeTab === cat.id ? "active" : ""}`}
                    onClick={() => onTabChange(cat.id)}
                  >
                    <CategoryIcon src={categoryIcons?.get(cat.id)} fallback={cat.icon} />
                    <span className="item-label">{cat.label}</span>
                  </button>
                ))}
            </div>
          )
      )}

      {activeCategoryIds !== null && visibleCategories.length === 0 && (
        <div className="sidebar-empty">No data found</div>
      )}
    </nav>
  );
}
