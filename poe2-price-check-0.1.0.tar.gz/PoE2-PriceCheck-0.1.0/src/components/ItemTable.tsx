import { useState, useMemo } from "react";
import type { NormalizedItem, SortField, SortDirection } from "../types";

interface Props {
  items: NormalizedItem[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  showCategory?: boolean;
  loading?: boolean;
  exaltedPrice?: number;
  // Bumped by a parent to wipe the search box; the text lives here, so the
  // parent cannot clear it directly.
  clearSearchSignal?: number;
}

function slugifyName(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function ItemIcon({ icon, name }: { icon?: string; name: string }) {
  // How far the fallback chain got, tracked against the url it got there with.
  // Deriving the stage from the current prop means a refresh carrying a new
  // icon url restarts the chain instead of inheriting the old one's failures —
  // the previous version seeded state once and ignored the prop forever after.
  const [failed, setFailed] = useState<{ url: string; stage: 1 | 2 } | null>(null);

  const letter = (
    <div className="item-icon item-icon-letter" title={name}>
      {(name || "?").charAt(0).toUpperCase()}
    </div>
  );

  if (!icon) return letter;

  const stage = failed?.url === icon ? failed.stage : 0;
  if (stage === 2) return letter;

  const src = stage === 1 ? `https://poe2db.com/us/${slugifyName(name)}/image` : icon;

  return (
    <img
      src={src}
      alt=""
      className="item-icon"
      loading="lazy"
      onError={() => setFailed({ url: icon, stage: stage === 0 ? 1 : 2 })}
    />
  );
}

export function ItemTable({
  items,
  favorites,
  onToggleFavorite,
  showCategory,
  loading,
  exaltedPrice,
  clearSearchSignal,
}: Props) {
  const showExalted = (exaltedPrice ?? 0) > 0;
  // The exchange API carries no listing count, so for those categories the
  // column would be a wall of dashes with a sort control that does nothing.
  const showCount = useMemo(() => items.some((i) => i.count > 0), [items]);
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<SortField>("chaosValue");
  const [sortDir, setSortDir] = useState<SortDirection>("desc");

  // Adjusted during render, not in an effect: effects run after paint, so the
  // box would still show its text for one painted frame after the bounds had
  // already gone — the clear looked staggered. React re-runs this render
  // immediately and nothing intermediate reaches the screen.
  const [seenClearSignal, setSeenClearSignal] = useState(clearSearchSignal);
  if (clearSearchSignal !== seenClearSignal) {
    setSeenClearSignal(clearSearchSignal);
    setSearch("");
  }

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    let result = q ? items.filter((i) => i.name.toLowerCase().includes(q)) : [...items];

    result.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case "name":
          cmp = a.name.localeCompare(b.name);
          break;
        case "chaosValue":
          cmp = a.chaosValue - b.chaosValue;
          break;
        case "divineValue":
          cmp = a.divineValue - b.divineValue;
          break;
        case "exaltedValue":
          cmp = (exaltedPrice ? a.chaosValue / exaltedPrice : 0) - (exaltedPrice ? b.chaosValue / exaltedPrice : 0);
          break;
        case "count":
          cmp = a.count - b.count;
          break;
      }
      return sortDir === "asc" ? cmp : -cmp;
    });

    return result;
    // exaltedPrice belongs here: the exalted sort divides by it, so the order
    // is wrong until it changes when the rate arrives or moves.
  }, [items, search, sortField, sortDir, exaltedPrice]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("desc");
    }
  };

  const sortIcon = (field: SortField) => {
    if (sortField !== field) return <span className="sort-icon inactive">⇅</span>;
    return <span className="sort-icon active">{sortDir === "asc" ? "↑" : "↓"}</span>;
  };

  // toFixed pads with zeros ("4.00", "2.0k"); drop those so only real decimals show.
  const trimZeros = (s: string) => (s.includes(".") ? s.replace(/\.?0+$/, "") : s);

  const formatChaos = (v: number) => {
    if (v >= 1000) return `${trimZeros((v / 1000).toFixed(1))}k`;
    if (v >= 100) return v.toFixed(0);
    if (v >= 10) return trimZeros(v.toFixed(1));
    return trimZeros(v.toFixed(2));
  };

  const formatDivine = (v: number) => {
    if (v < 0.01) return "< 0.01";
    return trimZeros(v.toFixed(2));
  };

  const formatExalted = (chaosVal: number) => {
    if (!exaltedPrice) return "—";
    return formatChaos(chaosVal / exaltedPrice);
  };

  return (
    <div className="item-table-container">
      <div className="table-toolbar">
        <input
          type="search"
          placeholder="Search items…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
        />
        <span className="result-count">{filtered.length} items</span>
      </div>

      {loading ? (
        <div className="table-loading">
          <div className="spinner" />
          <span>Loading…</span>
        </div>
      ) : items.length === 0 ? (
        <div className="table-empty table-no-data">
          No price data available for this category in the selected league
        </div>
      ) : filtered.length === 0 ? (
        <div className="table-empty">No items match &ldquo;{search}&rdquo;</div>
      ) : (
        <div className="table-scroll">
          <table className="price-table">
            <thead>
              <tr>
                <th className="th-fav" />
                <th className="th-icon" />
                <th className="th-name sortable" onClick={() => handleSort("name")}>
                  Name {sortIcon("name")}
                </th>
                {showCategory && <th className="th-category">Category</th>}
                {showExalted && (
                  <th className="th-exalted sortable" onClick={() => handleSort("exaltedValue")}>
                    Exalted {sortIcon("exaltedValue")}
                  </th>
                )}
                <th className="th-chaos sortable" onClick={() => handleSort("chaosValue")}>
                  Chaos {sortIcon("chaosValue")}
                </th>
                <th className="th-divine sortable" onClick={() => handleSort("divineValue")}>
                  Divine {sortIcon("divineValue")}
                </th>
                {showCount && (
                  <th className="th-count sortable" onClick={() => handleSort("count")}>
                    Listed {sortIcon("count")}
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => (
                <tr key={item.id} className={favorites.has(item.id) ? "row-favorited" : ""}>
                  <td className="td-fav">
                    <button
                      className={`fav-btn ${favorites.has(item.id) ? "active" : ""}`}
                      onClick={() => onToggleFavorite(item.id)}
                      title={favorites.has(item.id) ? "Remove from favorites" : "Add to favorites"}
                    >
                      {favorites.has(item.id) ? "★" : "☆"}
                    </button>
                  </td>
                  <td className="td-icon">
                    <ItemIcon icon={item.icon} name={item.name} />
                  </td>
                  <td className="td-name">
                    <span className="item-name">{item.name}</span>
                    {item.variant && <span className="item-variant">{item.variant}</span>}
                    {item.gemLevel != null && (
                      <span className="item-gem-info">
                        L{item.gemLevel}
                        {item.gemQuality ? ` Q${item.gemQuality}` : ""}
                        {item.corrupted ? " (c)" : ""}
                      </span>
                    )}
                    {item.links != null && item.links > 0 && (
                      <span className="item-links">{item.links}L</span>
                    )}
                  </td>
                  {showCategory && (
                    <td className="td-category">
                      <span className="category-badge">{item.categoryLabel ?? item.category}</span>
                    </td>
                  )}
                  {showExalted && (
                    <td className="td-exalted">
                      <span className="exalted-value">{formatExalted(item.chaosValue)}</span>
                      <span className="exalted-icon">⬡</span>
                    </td>
                  )}
                  <td className="td-chaos">
                    <span className="chaos-value">{formatChaos(item.chaosValue)}</span>
                    <span className="chaos-icon">⚙</span>
                  </td>
                  <td className="td-divine">
                    <span className="divine-value">{formatDivine(item.divineValue)}</span>
                    <span className="divine-icon">✦</span>
                  </td>
                  {showCount && (
                    <td className="td-count">
                      {item.count > 0 ? item.count.toLocaleString() : "—"}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
