import type { ParsedItem, Stat } from "../types/priceCheck";
import {
  checkedStats, rollPct, runeKey, selKey, sumCheckedByStatId,
  type Selection, type StatSel, type SumEdits,
} from "../utils/priceCheck";

export { checkedStats, selKey };
export type { Selection, StatSel, SumEdits };

interface Props {
  item: ParsedItem;
  sel: Selection;
  onSel: (key: string, patch: Partial<StatSel>) => void;
  sums: SumEdits;
  onSum: (statId: string, patch: Partial<{ min: string; max: string }>) => void;
  fracturedAffix: number | null;
  onFractured: (affixIdx: number | null) => void;
}

export function PriceCheckMods({
  item, sel, onSel, sums, onSum, fracturedAffix, onFractured,
}: Props) {
  const checked = checkedStats(item, sel);
  const activeSums = sumCheckedByStatId(checked);

  // first checked stat's text per statId, used only to guess the Σ row's unit (M1)
  const sampleTextByStatId = new Map<string, string>();
  checked.forEach((s) => {
    if (!sampleTextByStatId.has(s.statId)) sampleTextByStatId.set(s.statId, s.text);
  });

  const renderAffix = (affix: ParsedItem["affixes"][number], ai: number) => (
        <div className="pc-affix" key={ai}>
          <div className="pc-affix-head">
            {affix.tier !== undefined && <span className="pc-tier">T{affix.tier}</span>}
            <span className={`pc-affix-kind pc-kind-${affix.kind}`}>{affix.kind}</span>
            {affix.name && <span className="pc-affix-name">{affix.name}</span>}
            {affix.desecrated && <span className="pc-affix-tag">desecrated</span>}
            {affix.crafted && <span className="pc-affix-tag">crafted</span>}
            {fracturedAffix === ai && <span className="pc-affix-tag pc-tag-fractured">fractured</span>}
            {(affix.kind === "prefix" || affix.kind === "suffix") && (
              <button
                type="button"
                className={`pc-fracture ${fracturedAffix === ai ? "on" : ""}`}
                title="Mark as the fractured affix"
                onClick={() => onFractured(fracturedAffix === ai ? null : ai)}
              >
                ⛓
              </button>
            )}
          </div>

          {affix.stats.map((stat, si) => {
            const key = selKey(ai, si);
            const s = sel[key] ?? { checked: false, min: "", max: "" };
            const pct = rollPct(stat);
            const summed = s.checked && activeSums.has(stat.statId);
            return (
              <div className={`pc-stat ${s.checked ? "checked" : ""}`} key={si}>
                <label className="pc-stat-line">
                  <input
                    type="checkbox"
                    checked={s.checked}
                    onChange={(e) => {
                      const checkedNow = e.target.checked;
                      const patch: Partial<StatSel> = { checked: checkedNow };
                      // only a rolled mod gets a seeded minimum: without a
                      // range the number may be part of the sentence
                      // ("…for 60 seconds"), not a value to filter on
                      if (checkedNow && !s.min && stat.range) patch.min = String(stat.value);
                      onSel(key, patch);

                      // seed the Σ row's min the moment it becomes active (I2/I4)
                      if (checkedNow) {
                        const future = sel[key]?.checked ? checked : [...checked, stat];
                        const total = sumCheckedByStatId(future).get(stat.statId);
                        if (total !== undefined && !sums[stat.statId]?.min) {
                          onSum(stat.statId, { min: String(total) });
                        }
                      }
                    }}
                  />
                  <span className="pc-stat-text">{stat.text}</span>
                  {pct !== null && <span className="pc-roll-pct">{pct}%</span>}
                </label>

                {stat.range && pct !== null && (
                  <div className="pc-roll">
                    <span className="pc-roll-end">{stat.range.min}</span>
                    <div className="pc-roll-bar">
                      <div
                        className="pc-roll-fill"
                        style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                      />
                    </div>
                    <span className="pc-roll-end">{stat.range.max}</span>
                  </div>
                )}

                {/* min/max hide while this stat feeds an active Σ row */}
                {s.checked && !summed && (
                  <div className="pc-minmax">
                    min
                    <input
                      type="number"
                      value={s.min}
                      onChange={(e) => onSel(key, { min: e.target.value })}
                    />
                    max
                    <input
                      type="number"
                      placeholder="—"
                      value={s.max}
                      onChange={(e) => onSel(key, { max: e.target.value })}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
  );

  // clipboard order: corruption enchant, then runes, then implicit and the rest
  return (
    <div className="pc-mods">
      {item.affixes.map((a, ai) => (a.kind === "enchant" ? renderAffix(a, ai) : null))}
      <RuneGroup mods={item.runeMods} sel={sel} onSel={onSel} />
      {item.affixes.map((a, ai) => (a.kind !== "enchant" ? renderAffix(a, ai) : null))}

      {/* Σ rows: what actually travels to the search for shared statIds */}
      {[...activeSums].map(([statId, total]) => {
        const isPercent = sampleTextByStatId.get(statId)?.includes("%") ?? true;
        return (
          <div className="pc-sum" key={statId}>
            <span className="pc-sum-sigma">Σ</span>
            <span className="pc-stat-text">{total}{isPercent ? "%" : ""} {statId}</span>
            <div className="pc-minmax">
              min
              <input
                type="number"
                value={sums[statId]?.min ?? ""}
                onChange={(e) => onSum(statId, { min: e.target.value })}
              />
              max
              <input
                type="number"
                placeholder="—"
                value={sums[statId]?.max ?? ""}
                onChange={(e) => onSum(statId, { max: e.target.value })}
              />
            </div>
          </div>
        );
      })}

    </div>
  );
}

/** Rune mods: fixed value, so a checkbox is the whole control —
 *  checked searches "at least this value", no min/max to edit. */
function RuneGroup({
  mods, sel, onSel,
}: {
  mods: Stat[];
  sel: Selection;
  onSel: (key: string, patch: Partial<StatSel>) => void;
}) {
  if (mods.length === 0) return null;
  return (
    <div className="pc-affix">
      <div className="pc-affix-head">
        <span className="pc-affix-kind pc-kind-rune">rune</span>
      </div>
      {mods.map((stat, i) => {
        const key = runeKey(i);
        const checked = sel[key]?.checked ?? false;
        return (
          <div className={`pc-stat ${checked ? "checked" : ""}`} key={i}>
            <label className="pc-stat-line">
              <input
                type="checkbox"
                checked={checked}
                onChange={(e) => onSel(key, { checked: e.target.checked })}
              />
              <span className="pc-stat-text">{stat.text}</span>
            </label>
          </div>
        );
      })}
    </div>
  );
}
