import { useMemo } from "react";
import type { NormalizedItem } from "../types";
import { ItemTable } from "./ItemTable";

interface Props {
  allItems: NormalizedItem[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  exaltedPrice?: number;
}

export function FavoritesTab({ allItems, favorites, onToggleFavorite, exaltedPrice }: Props) {
  const favorited = useMemo(
    () => allItems.filter((i) => favorites.has(i.id)),
    [allItems, favorites]
  );

  return (
    <div className="tab-content">
      <div className="tab-header">
        <h2>⭐ Favorites</h2>
        <p className="tab-subtitle">{favorited.length} saved items</p>
      </div>
      {favorited.length === 0 ? (
        <div className="favorites-empty">
          <p>No favorites yet.</p>
          <p>Click the ☆ icon next to any item to add it here.</p>
        </div>
      ) : (
        <ItemTable
          items={favorited}
          favorites={favorites}
          onToggleFavorite={onToggleFavorite}
          showCategory
          exaltedPrice={exaltedPrice}
        />
      )}
    </div>
  );
}
