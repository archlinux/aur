import { useEffect, useMemo, useState } from "react";
import type { NormalizedItem } from "../types";
import type { ParsedItem, Rarity, SearchBudget, SellerMode, TradeResult } from "../types/priceCheck";
import { parseItem } from "../utils/parseItem";
import { searchedStats } from "../utils/priceCheck";
import { derivedStats } from "../utils/weapon";
import { tradeSearch, type BaseSel } from "../utils/trade";
import { PriceCheckMods, type Selection, type StatSel, type SumEdits } from "./PriceCheckMods";
import { PriceCheckResults } from "./PriceCheckResults";
import { SessionButton } from "./SessionButton";

interface Props {
  text: string | null;
  allItems: NormalizedItem[];
  divinePrice: number;
  activeLeague: string;
}

export type TriState = "any" | "yes" | "no";

export interface FilterState {
  rarity: Rarity;                     // always searched; lit chip = its value
  corrupted: TriState;                // any = not sent to the search
  fractured: TriState;                // idem
  fracturedAffix: number | null;      // index into item.affixes, radio behaviour
  ilvl: string; ilvlOn: boolean;      // numeric fields kept as strings while editing
  quality: string; qualityOn: boolean;
  sockets: string; socketsOn: boolean;
}

export function initialFilters(item: ParsedItem): FilterState {
  return {
    rarity: item.rarity,
    corrupted: "any",
    fractured: item.fracturedAffixIndex !== undefined ? "yes" : "any",
    fracturedAffix: item.fracturedAffixIndex ?? null,
    ilvl: String(item.ilvl), ilvlOn: false,
    quality: String(item.quality ?? 0), qualityOn: false,
    sockets: String(item.sockets), socketsOn: false,
  };
}

/** Rarities the item could be listed as: its explicit affix count bounds it.
 *  3+ mods can only be rare; 1-2 magic or rare; 0 anything; uniques are unique. */
export function rarityOptions(item: ParsedItem): Rarity[] {
  if (item.rarity === "unique") return ["unique"];
  const n = item.affixes.filter((a) => a.kind === "prefix" || a.kind === "suffix").length;
  if (n > 2) return ["rare"];
  if (n > 0) return ["magic", "rare"];
  return ["normal", "magic", "rare"];
}

export function PriceCheckTab({ text, allItems, divinePrice, activeLeague }: Props) {
  if (!text) {
    return (
      <div className="tab-content">
        <TabHeader subtitle="Waiting for an item" />
        <div className="favorites-empty">
          <p>Hover an item in Path of Exile 2 and press Ctrl+C.</p>
          <p>It lands here.</p>
        </div>
      </div>
    );
  }

  const item = parseItem(text);
  if (!item) {
    return (
      <div className="tab-content">
        <TabHeader subtitle="Could not read the item's mods" />
        <div className="pc-error">
          <p>This item was copied without mod details.</p>
          <p>
            Enable <strong>Options → Game → Advanced Mod Descriptions</strong> in
            Path of Exile 2 and copy the item again.
          </p>
        </div>
      </div>
    );
  }

  // Always the full search panel — this tab prices against the trade site
  // only, never poe.ninja: the point is seeing the actual listings.
  // key={text} remounts per item, so every useState initialiser below runs
  // fresh: the render-time reset, no effects.
  return (
    <div className="tab-content">
      <TabHeader subtitle="Pick the mods that matter, then search" />
      <div className="table-scroll">
        <PriceCheckPanel
          key={text}
          item={item}
          allItems={allItems}
          divinePrice={divinePrice}
          activeLeague={activeLeague}
        />
      </div>
    </div>
  );
}

function TabHeader({ subtitle }: { subtitle: string }) {
  return (
    <div className="tab-header">
      <h2>📋 Price Check</h2>
      <p className="tab-subtitle">{subtitle}</p>
    </div>
  );
}

interface PanelProps {
  item: ParsedItem;
  allItems: NormalizedItem[];
  divinePrice: number;
  activeLeague: string;
}

function PriceCheckPanel({ item, allItems, divinePrice, activeLeague }: PanelProps) {
  const [filters, setFilters] = useState<FilterState>(() => initialFilters(item));
  // base item stats (crit, APS, evasion…): searchable without touching any mod
  const [baseSel, setBaseSel] = useState<BaseSel>({});
  const [sel, setSel] = useState<Selection>({});
  const [sums, setSums] = useState<SumEdits>({});
  const [sellerMode, setSellerMode] = useState<SellerMode>("instant");
  const [results, setResults] = useState<TradeResult[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [unmatched, setUnmatched] = useState<string[]>([]);
  // what the last search actually asked for — shown when it returns nothing
  const [lastSearch, setLastSearch] = useState<string[]>([]);
  // optimistic until the first response brings the real header state
  const [budget, setBudget] = useState<SearchBudget>({ remaining: 30, total: 30, windowSecs: 300 });
  // rate-limit cooldown: timestamp when searching reopens, ticked every second
  const [retryUntil, setRetryUntil] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (retryUntil === null) return;
    const id = setInterval(() => {
      setNow(Date.now());
      if (Date.now() >= retryUntil) setRetryUntil(null);
    }, 1000);
    return () => clearInterval(id);
  }, [retryUntil]);
  const cooldownSecs = retryUntil !== null ? Math.max(0, Math.ceil((retryUntil - now) / 1000)) : 0;

  // chaos rate per trade currency slug, from the prices the app already holds
  const chaosRates = useMemo(() => {
    const m = new Map<string, number>();
    const want: Record<string, string> = {
      exalted: "Exalted Orb", divine: "Divine Orb", regal: "Regal Orb",
      chaos: "Chaos Orb", annul: "Orb of Annulment", alch: "Orb of Alchemy",
    };
    for (const [slug, name] of Object.entries(want)) {
      const it = allItems.find((i) => i.name === name);
      if (it) m.set(slug, it.chaosValue);
    }
    return m;
  }, [allItems]);

  const rarities = rarityOptions(item);
  const searchableStats = [...item.baseStats, ...derivedStats(item)];

  const runSearch = async () => {
    setSearching(true);
    setSearchError(null);
    setLastSearch([
      ...(item.rarity === "unique" && item.baseType ? [item.name] : []),
      item.baseType || item.itemClass,
      filters.rarity,
      ...(filters.corrupted !== "any" ? [`corrupted: ${filters.corrupted}`] : []),
      ...(filters.fractured !== "any" ? [`fractured: ${filters.fractured}`] : []),
      { instant: "instant buyout", online: "online sellers", any: "any seller" }[sellerMode],
      ...(filters.ilvlOn ? [`ilvl ≥ ${filters.ilvl}`] : []),
      ...(filters.qualityOn ? [`Q ≥ ${filters.quality}`] : []),
      ...(filters.socketsOn ? [`sockets ≥ ${filters.sockets}`] : []),
      ...Object.entries(baseSel).filter(([, s]) => s.on).map(([l, s]) => `${l} ≥ ${s.min}`),
      ...searchedStats(item, sel, sums).map((s) =>
        `${s.text}${s.min ? ` ≥ ${s.min}` : ""}${s.max ? ` ≤ ${s.max}` : ""}`),
    ]);
    try {
      const resp = await tradeSearch(activeLeague, item, filters, sel, sums, baseSel, sellerMode);
      // a rate-limited answer has no rows; keep whatever the panel showed
      if (resp.retryAfterSecs && resp.results.length === 0) {
        if (resp.total > 0) {
          setSearchError(
            `The search matched ${resp.total} listings, but fetching them hit the rate limit — retry when the timer ends.`,
          );
        }
      } else {
        setResults(resp.results);
        setUnmatched(resp.unmatched);
      }
      if (resp.budget) setBudget(resp.budget);
      setRetryUntil(resp.retryAfterSecs ? Date.now() + resp.retryAfterSecs * 1000 : null);
    } catch (e) {
      setSearchError(String(e));
    } finally {
      setSearching(false);
    }
  };

  const set = (patch: Partial<FilterState>) => setFilters((f) => ({ ...f, ...patch }));
  const onSel = (key: string, patch: Partial<StatSel>) =>
    setSel((s) => {
      const prev = s[key] ?? { checked: false, min: "", max: "" };
      return { ...s, [key]: { ...prev, ...patch } };
    });
  const onSum = (statId: string, patch: Partial<{ min: string; max: string }>) =>
    setSums((s) => {
      const prev = s[statId] ?? { min: "", max: "" };
      return { ...s, [statId]: { ...prev, ...patch } };
    });

  return (
    <div className="pc-panel">
      <div className="pc-item-header pc-tooltip">
        <div className="pc-item-name">{item.name}</div>
        {item.baseType && <div className="pc-item-base">{item.baseType}</div>}

        <div className="pc-flt-line">
          <span className="pc-flt-fixed" title="Always searched">{item.itemClass}</span>
          <span className="pc-flt-sep">·</span>
          {rarities.length === 1 ? (
            <span className={`pc-flt-fixed rarity-${filters.rarity}`}>{filters.rarity}</span>
          ) : (
            <label className="pc-flt-selectwrap" title="Rarity to search">
              <select
                className={`pc-flt-select rarity-${filters.rarity}`}
                value={filters.rarity}
                onChange={(e) => set({ rarity: e.target.value as Rarity })}
              >
                {rarities.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              <span className="pc-flt-caret">▾</span>
            </label>
          )}
        </div>

        <div className="pc-flt-line">
          <TriChip
            label="corrupted"
            extraClass="pc-corrupted"
            value={filters.corrupted}
            onCycle={(v) => set({ corrupted: v })}
          />
          <TriChip
            label="fractured"
            value={filters.fractured}
            onCycle={(v) =>
              set({ fractured: v, fracturedAffix: v === "yes" ? filters.fracturedAffix : null })
            }
          />
        </div>

        <div className="pc-flt-line">
          <NumChip label="ilvl" field="ilvl" filters={filters} set={set} />
          <NumChip label="Q%" field="quality" filters={filters} set={set} />
          <NumChip label="sockets" field="sockets" filters={filters} set={set} />
        </div>

        {searchableStats.length > 0 && (
          <div className="pc-flt-line">
            {searchableStats.map((b) => {
              const s = baseSel[b.label] ?? { on: false, min: String(b.value) };
              const patch = (p: Partial<{ on: boolean; min: string }>) =>
                setBaseSel((prev) => ({ ...prev, [b.label]: { ...s, ...p } }));
              return (
                <span key={b.label} className={`pc-flt ${s.on ? "on" : ""}`}>
                  <button
                    type="button"
                    className="pc-flt-toggle"
                    title={s.on ? "Searched — click to ignore" : "Ignored — click to search"}
                    onClick={() => patch({ on: !s.on })}
                  >
                    {b.label} ≥
                  </button>
                  <input
                    type="number"
                    className="pc-flt-num"
                    value={s.min}
                    onChange={(e) => patch({ min: e.target.value, on: true })}
                  />
                </span>
              );
            })}
          </div>
        )}
      </div>
      <PriceCheckMods
        item={item}
        sel={sel}
        onSel={onSel}
        sums={sums}
        onSum={onSum}
        fracturedAffix={filters.fracturedAffix}
        onFractured={(i) => set({ fracturedAffix: i, fractured: i !== null ? "yes" : "any" })}
      />
      <div className="pc-action-bar">
        <button
          type="button"
          className="pc-search-btn"
          disabled={searching || cooldownSecs > 0}
          onClick={runSearch}
        >
          {searching ? "Searching…" : "Search trade"}
        </button>

        <select
          className="pc-seller-mode"
          value={sellerMode}
          onChange={(e) => setSellerMode(e.target.value as SellerMode)}
        >
          <option value="instant">Instant Buyout</option>
          <option value="online">Online sellers</option>
          <option value="any">Any seller</option>
        </select>

        <SessionButton />

        <span
          className={`pc-budget ${cooldownSecs > 0 ? "pc-budget-out" : ""}`}
          title="Trade searches left in the current window"
        >
          {cooldownSecs > 0 ? `◷ ${fmtSecs(cooldownSecs)}` : `${budget.remaining}/${budget.total} ◷${Math.round(budget.windowSecs / 60)}m`}
        </span>
      </div>

      {cooldownSecs > 0 && (
        <div className="pc-no-results">
          Rate limited — next search in {fmtSecs(cooldownSecs)}.
        </div>
      )}

      {searchError && <div className="pc-no-results">{searchError}</div>}
      {unmatched.length > 0 && !searchError && (
        <div className="pc-no-results">
          No trade stat id — searched without: {unmatched.join(" · ")}
        </div>
      )}
      {results !== null && results.length === 0 && !searchError && (
        <div className="pc-no-results">
          <p>No listings for this exact search:</p>
          <p className="pc-searched">{lastSearch.join("  ·  ")}</p>
          <p>Uncheck the most restrictive filter and search again.</p>
        </div>
      )}
      {results !== null && results.length > 0 && (
        <PriceCheckResults results={results} chaosRates={chaosRates} divinePrice={divinePrice} />
      )}
    </div>
  );
}

/** any → yes → no → any. "any" (–) stays out of the search entirely. */
function TriChip({
  label, value, onCycle, extraClass = "",
}: {
  label: string;
  value: TriState;
  onCycle: (v: TriState) => void;
  extraClass?: string;
}) {
  const next: Record<TriState, TriState> = { any: "yes", yes: "no", no: "any" };
  const symbol = { any: "–", yes: "✓", no: "✗" }[value];
  const title = {
    any: `${label}: not filtered`,
    yes: `Searching ${label} items`,
    no: `Searching non-${label} items`,
  }[value];
  return (
    <button
      type="button"
      className={`pc-flt ${extraClass} ${value !== "any" ? "on" : ""}`}
      title={`${title} — click to change`}
      onClick={() => onCycle(next[value])}
    >
      {label} {symbol}
    </button>
  );
}

/** 95 → "1:35"; 40 → "40s" */
function fmtSecs(s: number): string {
  return s >= 60 ? `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}` : `${s}s`;
}

type NumField = "ilvl" | "quality" | "sockets";

function NumChip({
  label, field, filters, set,
}: {
  label: string;
  field: NumField;
  filters: FilterState;
  set: (patch: Partial<FilterState>) => void;
}) {
  const onKey = `${field}On` as const;
  const on = filters[onKey];
  return (
    <span className={`pc-flt ${on ? "on" : ""}`}>
      <button
        type="button"
        className="pc-flt-toggle"
        title={on ? "Searched — click to ignore" : "Ignored — click to search"}
        onClick={() => set({ [onKey]: !on } as Partial<FilterState>)}
      >
        {label} ≥
      </button>
      <input
        type="number"
        className="pc-flt-num"
        value={filters[field]}
        onChange={(e) =>
          set({ [field]: e.target.value, [onKey]: true } as Partial<FilterState>)
        }
      />
    </span>
  );
}
