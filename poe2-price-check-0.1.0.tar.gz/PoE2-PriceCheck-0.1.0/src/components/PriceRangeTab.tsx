import { useMemo, useState } from "react";
import type { NormalizedItem } from "../types";
import { ItemTable } from "./ItemTable";

export type PriceUnit = "chaos" | "divine" | "exalted";

export interface PriceRange {
  min: string;
  max: string;
  unit: PriceUnit;
}

interface Props {
  allItems: NormalizedItem[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  loading: boolean;
  exaltedPrice?: number;
  // Held by App so switching tabs and coming back keeps the range.
  range: PriceRange;
  onRangeChange: (next: PriceRange) => void;
}

export function PriceRangeTab({
  allItems,
  favorites,
  onToggleFavorite,
  loading,
  exaltedPrice,
  range,
  onRangeChange,
}: Props) {
  // Transient on purpose: only its changes matter, not its value.
  const [clearSearch, setClearSearch] = useState(0);

  const { min, max } = range;
  const setMin = (v: string) => onRangeChange({ ...range, min: v });
  const setMax = (v: string) => onRangeChange({ ...range, max: v });
  const setUnit = (v: PriceUnit) => onRangeChange({ ...range, unit: v });

  const hasExalted = (exaltedPrice ?? 0) > 0;
  const units: PriceUnit[] = hasExalted ? ["chaos", "divine", "exalted"] : ["chaos", "divine"];
  // A stored exalted selection outlives the rate that justified it; fall back
  // rather than divide by a price that is no longer there.
  const unit = range.unit === "exalted" && !hasExalted ? "chaos" : range.unit;

  const inRange = useMemo(() => {
    // An empty or unparseable bound is no bound, so a range open on one side
    // still works: "everything above 5 divine".
    const lo = Number.parseFloat(min);
    const hi = Number.parseFloat(max);
    const low = Number.isFinite(lo) ? lo : -Infinity;
    const high = Number.isFinite(hi) ? hi : Infinity;

    const valueIn = (item: NormalizedItem) => {
      if (unit === "divine") return item.divineValue;
      if (unit === "exalted") return exaltedPrice ? item.chaosValue / exaltedPrice : 0;
      return item.chaosValue;
    };

    return allItems.filter((i) => {
      const v = valueIn(i);
      return v >= low && v <= high;
    });
  }, [allItems, min, max, unit, exaltedPrice]);

  const bounded = min !== "" || max !== "";

  return (
    <div className="tab-content">
      <div className="tab-header">
        <h2>🔍 Price Range</h2>
        <p className="tab-subtitle">
          {bounded
            ? `${inRange.length} items between the bounds, across all categories`
            : "Set a minimum, a maximum, or just one of the two"}
        </p>
      </div>

      <div className="range-controls">
        <label className="range-field">
          <span>Min</span>
          <input
            type="number"
            min="0"
            step="any"
            value={min}
            onChange={(e) => setMin(e.target.value)}
            placeholder="any"
            className="range-input"
          />
        </label>

        <label className="range-field">
          <span>Max</span>
          <input
            type="number"
            min="0"
            step="any"
            value={max}
            onChange={(e) => setMax(e.target.value)}
            placeholder="any"
            className="range-input"
          />
        </label>

        <div className="difficulty-toggle">
          {units.map((u) => (
            <button
              key={u}
              className={`diff-btn ${unit === u ? "active" : ""}`}
              onClick={() => setUnit(u)}
            >
              {u === "chaos" ? "Chaos" : u === "divine" ? "Divine" : "Exalted"}
            </button>
          ))}
        </div>

        {/* Always rendered: hiding it when there is nothing to clear made the
            button vanish under the cursor right after being clicked. */}
        <button
          className="range-clear"
          onClick={() => {
            onRangeChange({ ...range, min: "", max: "" });
            setClearSearch((n) => n + 1);
          }}
        >
          Clear
        </button>
      </div>

      <ItemTable
        items={inRange}
        favorites={favorites}
        onToggleFavorite={onToggleFavorite}
        showCategory
        loading={loading}
        exaltedPrice={exaltedPrice}
        clearSearchSignal={clearSearch}
      />
    </div>
  );
}
