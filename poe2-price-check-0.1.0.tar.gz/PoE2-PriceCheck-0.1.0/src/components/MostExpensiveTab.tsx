import { useMemo } from "react";
import type { NormalizedItem } from "../types";
import { ItemTable } from "./ItemTable";

interface Props {
  allItems: NormalizedItem[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  loading: boolean;
  exaltedPrice?: number;
}

export function MostExpensiveTab({ allItems, favorites, onToggleFavorite, loading, exaltedPrice }: Props) {
  const top100 = useMemo(() => {
    return [...allItems]
      .sort((a, b) => b.chaosValue - a.chaosValue)
      .slice(0, 100);
  }, [allItems]);

  return (
    <div className="tab-content">
      <div className="tab-header">
        <h2>👑 Most Expensive</h2>
        <p className="tab-subtitle">Top 100 items by chaos value across all categories</p>
      </div>
      <ItemTable
        items={top100}
        favorites={favorites}
        onToggleFavorite={onToggleFavorite}
        showCategory
        loading={loading}
        exaltedPrice={exaltedPrice}
      />
    </div>
  );
}
