import type { LeagueInfo, AppConfig } from "../types";

const oldest = (stale: { at: Date }[]) =>
  stale.reduce((a, b) => (a.at < b.at ? a : b)).at;

interface Props {
  leagues: LeagueInfo[];
  activeLeague: string;
  config: AppConfig;
  lastUpdated: Date | null;
  loading: boolean;
  loadingCategory: string | null;
  divinePrice: number;
  error: string | null;
  stale: { label: string; at: Date }[];
  onLeagueChange: (leagueId: string) => void;
  onDifficultyChange: (d: string) => void;
  onRefresh: () => void;
  nextRefreshIn: number;
}

export function Header({
  leagues,
  activeLeague,
  config,
  lastUpdated,
  loading,
  loadingCategory,
  divinePrice,
  error,
  stale,
  onLeagueChange,
  onDifficultyChange,
  onRefresh,
  nextRefreshIn,
}: Props) {
  const formatTime = (d: Date) =>
    d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <header className="app-header">
      <div className="header-brand">
        <span className="brand-icon">⚡</span>
        <span className="brand-name">PoE2 Price Check</span>
      </div>

      <div className="header-controls">
        <div className="control-group">
          <label>League</label>
          <select
            value={activeLeague}
            onChange={(e) => onLeagueChange(e.target.value)}
            className="league-select"
          >
            {leagues.length === 0 ? (
              <option value={activeLeague}>{activeLeague}</option>
            ) : (
              leagues.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.displayName}
                </option>
              ))
            )}
          </select>
        </div>

        <div className="control-group">
          <label>Mode</label>
          <div className="difficulty-toggle">
            <button
              className={`diff-btn ${config.difficulty === "softcore" ? "active" : ""}`}
              onClick={() => onDifficultyChange("softcore")}
            >
              SC
            </button>
            <button
              className={`diff-btn ${config.difficulty === "hardcore" ? "active" : ""}`}
              onClick={() => onDifficultyChange("hardcore")}
            >
              HC
            </button>
          </div>
        </div>

        <button
          className={`refresh-btn ${loading ? "spinning" : ""}`}
          onClick={onRefresh}
          disabled={loading}
          title="Refresh prices (F5)"
        >
          ↻
        </button>
      </div>

      <div className="status-bar">
        {loading && loadingCategory ? (
          <span className="status-loading">Loading {loadingCategory}…</span>
        ) : lastUpdated ? (
          <span className="status-ok">Updated {formatTime(lastUpdated)}</span>
        ) : null}
        {divinePrice > 0 && (
          <span className="status-divine">1 div = {Math.round(divinePrice)}c</span>
        )}

        {/* "Updated" above is the cycle time, which is not when these particular
            categories were fetched. Say so rather than let it stand for them. */}
        {!loading && stale.length > 0 && (
          <span
            className="status-stale"
            title={stale.map((s) => `${s.label}: ${formatTime(s.at)}`).join("\n")}
          >
            ⚠ {stale.length} {stale.length === 1 ? "category" : "categories"} from{" "}
            {formatTime(oldest(stale))}
          </span>
        )}

        {!loading && error && (
          <span className="status-error" title={error}>
            ⚠ {error.length > 60 ? `${error.slice(0, 60)}…` : error}
          </span>
        )}
        {!loading && nextRefreshIn > 0 && (
          <span className="status-next">Next in {formatCountdown(nextRefreshIn)}</span>
        )}
      </div>
    </header>
  );
}
