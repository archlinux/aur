import { useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";

/**
 * Optional trade session. Without one the app searches anonymously and
 * everything works — a session only moves the rate limit to the account's own
 * budget instead of sharing the IP's. The cookie is stored by the Rust side
 * and never read back into the webview.
 */
export function SessionButton() {
  const [stored, setStored] = useState(false);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    invoke<boolean>("has_session").then(setStored).catch(() => {});
  }, []);

  const save = async (value: string) => {
    setError(null);
    try {
      setStored(await invoke<boolean>("set_session", { poesessid: value }));
      setOpen(false);
      setDraft("");
    } catch (e) {
      setError(String(e));
    }
  };

  return (
    <span className="pc-session">
      <button
        type="button"
        className={`pc-flt ${stored ? "on" : ""}`}
        title={
          stored
            ? "Searching with your session — click to manage"
            : "Optional: use your poe.pathofexile.com session so searches count against your account's rate limit instead of your IP's"
        }
        onClick={() => setOpen((o) => !o)}
      >
        {stored ? "session ✓" : "session –"}
      </button>

      {open && (
        <div className="pc-session-pop">
          <p>
            Optional. Anonymous search works fine; a session just gives you your
            own rate-limit budget.
          </p>
          <p className="pc-session-how">
            pathofexile.com → F12 → Application → Cookies → copy POESESSID
          </p>
          <input
            type="password"
            placeholder={stored ? "stored — paste to replace" : "POESESSID"}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && draft.trim() && save(draft)}
          />
          <div className="pc-session-actions">
            <button type="button" disabled={!draft.trim()} onClick={() => save(draft)}>
              Save
            </button>
            {stored && (
              <button type="button" onClick={() => save("")}>
                Remove
              </button>
            )}
          </div>
          {error && <p className="pc-session-error">{error}</p>}
        </div>
      )}
    </span>
  );
}
