import type { NormalizedItem, Category } from "../types";
import { ItemTable } from "./ItemTable";

interface Props {
  category: Category;
  items: NormalizedItem[];
  favorites: Set<string>;
  onToggleFavorite: (id: string) => void;
  loading: boolean;
  exaltedPrice?: number;
}

export function CategoryTab({ category, items, favorites, onToggleFavorite, loading, exaltedPrice }: Props) {
  return (
    <div className="tab-content">
      <div className="tab-header">
        <h2>
          {category.icon} {category.label}
        </h2>
        <p className="tab-subtitle">{items.length} items</p>
      </div>
      <ItemTable
        items={items}
        favorites={favorites}
        onToggleFavorite={onToggleFavorite}
        loading={loading}
        exaltedPrice={exaltedPrice}
      />
    </div>
  );
}
