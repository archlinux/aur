export type Rarity = "normal" | "magic" | "rare" | "unique";

export interface Stat {
  text: string;               // "148% increased Physical Damage"
  statId: string;             // key for cross-affix summing, e.g. "increased Physical Damage"
  value: number;              // 148; midpoint for double values (6-180 → 93)
  range?: { min: number; max: number };
}

export interface Affix {
  kind: "prefix" | "suffix" | "implicit" | "enchant" | "unique"; // enchant = { (Corruption) Enhancement }
  name?: string;
  tier?: number;
  tags: string[];
  desecrated: boolean;
  crafted: boolean;
  stats: Stat[];
}

export interface ParsedItem {
  itemClass: string;
  rarity: Rarity;
  name: string;
  baseType: string;
  ilvl: number;
  /** "Physical Damage: 274-509", "Critical Hit Chance: 8.51%"… — ranges as midpoint */
  baseStats: { label: string; value: number }[];
  quality?: number;
  sockets: number;
  corrupted: boolean;
  fracturedAffixIndex?: number;
  affixes: Affix[];
  runeMods: Stat[];     // "(rune)" lines; fixed value, no roll
}

export interface TradeResult {
  listing: {
    indexed: string;          // ISO date
    price: { type: string; amount: number; currency: string };
    account: { name: string; online?: { league: string } };
    whisper: string;
  };
  item: { name: string; baseType: string; ilvl: number; explicitMods: string[] };
}

/** Travels inside the trade query (status/sale_type) — never a client-side
 *  filter over fetched rows. */
export type SellerMode = "instant" | "online" | "any";

export interface SearchBudget { remaining: number; total: number; windowSecs: number }
