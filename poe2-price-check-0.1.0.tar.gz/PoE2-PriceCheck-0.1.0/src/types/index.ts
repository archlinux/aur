export interface AppConfig {
  preferred_league: string;
  difficulty: string;
  refresh_interval_minutes: number;
  window_width: number;
  window_height: number;
  theme: string;
}

export interface ItemLine {
  id: number;
  name: string;
  icon?: string;
  mapTier?: number;
  levelRequired?: number;
  baseType?: string;
  variant?: string;
  links?: number;
  gemLevel?: number;
  gemQuality?: number;
  itemType?: string;
  chaosValue: number;
  divineValue: number;
  count: number;
  detailsId: string;
  listingCount?: number;
  corrupted?: boolean;
}

export interface ItemOverviewResponse {
  lines: ItemLine[];
  chaosPerDivine?: number;
}

export interface Poe2CategoryInfo {
  apiType: string;
  slug: string;
  label: string;
}

export interface NormalizedItem {
  id: string;
  name: string;
  icon?: string;
  chaosValue: number;
  divineValue: number;
  category: string;
  categoryLabel?: string;
  count: number;
  detailsId: string;
  isCurrency: boolean;
  // extra fields for display
  variant?: string;
  gemLevel?: number;
  gemQuality?: number;
  corrupted?: boolean;
  mapTier?: number;
  links?: number;
}

export interface LeagueInfo {
  id: string;
  realm: string;
  isHardcore: boolean;
  isStandard: boolean;
  displayName: string;
  hcId?: string; // HC variant league name for API calls when difficulty=hardcore
}


export interface Category {
  id: string;
  slug: string;
  label: string;
  icon: string;
  watchCategory?: string;
}

export type SortField = "name" | "chaosValue" | "divineValue" | "exaltedValue" | "count";
export type SortDirection = "asc" | "desc";
