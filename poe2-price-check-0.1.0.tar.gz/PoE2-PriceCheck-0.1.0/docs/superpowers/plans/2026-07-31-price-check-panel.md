# Price Check Panel Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the Price Check page UI — parsed item, per-stat search controls, simulated trade results — driven entirely by fixture data.

**Architecture:** Pure logic (roll %, stat summing, median, currency normalisation) lives in `src/utils/priceCheck.ts` with an assert-based check file. Fixture data and a `parseItem` stub live in `src/utils/priceCheckFixture.ts`. The UI is `PriceCheckTab` (state router + header chips) plus two subcomponents, `PriceCheckMods` and `PriceCheckResults`. Per-item state reset is done by remounting the panel with `key={text}` — state initialisers run fresh per item, no effects.

**Tech Stack:** React 18 + TypeScript, plain CSS in `src/styles.css`, no new dependencies.

## Global Constraints

- Spec: `docs/superpowers/specs/2026-07-31-price-check-panel-design.md`. Brief: `PRICE-CHECK-BRIEF.md`.
- **Do not touch `src-tauri/`.** Do not call or import anything reaching the trade API.
- Never hardcode a league or a category.
- Colours only from existing CSS variables (`--gold`, `--bg-secondary`, `--divine`, …); no new hex values without a reason.
- `appearance: none` on every checkbox, select and number input added.
- Reset child state during render (remount via `key`), never in an effect.
- Match existing structure: `.tab-content` wrapper, `.tab-header` with `<h2>` + `.tab-subtitle`.
- No test framework. One assert file, run with `npx tsx src/utils/priceCheck.check.ts`.
- Done means `npx tsc --noEmit` clean.

---

### Task 1: Types + pure logic + checks

**Files:**
- Create: `src/types/priceCheck.ts`
- Create: `src/utils/priceCheck.ts`
- Create: `src/utils/priceCheck.check.ts`

**Interfaces:**
- Consumes: `NormalizedItem` from `src/types/index.ts` (has `name`, `chaosValue`).
- Produces: all types below; functions `rollPct`, `sumCheckedByStatId`, `medianRecentDiv`, `toDivine`, `ageString`, `filterBySellerMode`. Later tasks import these exact names.

- [ ] **Step 1: Write the types**

`src/types/priceCheck.ts`:

```ts
export type Rarity = "normal" | "magic" | "rare" | "unique";

export interface Stat {
  text: string;               // "148% increased Physical Damage"
  statId: string;             // key for cross-affix summing, e.g. "increased Physical Damage"
  value: number;              // 148; midpoint for double values (6-180 → 93)
  range?: { min: number; max: number };
}

export interface Affix {
  kind: "prefix" | "suffix" | "implicit";
  name?: string;
  tier?: number;
  tags: string[];
  desecrated: boolean;
  crafted: boolean;
  stats: Stat[];
}

export interface ParsedItem {
  itemClass: string;
  rarity: Rarity;
  name: string;
  baseType: string;
  ilvl: number;
  quality?: number;
  sockets: number;
  corrupted: boolean;
  fracturedAffixIndex?: number;
  affixes: Affix[];
  runeMods: string[];
}

export interface TradeResult {
  listing: {
    indexed: string;          // ISO date
    price: { type: string; amount: number; currency: string };
    account: { name: string; online?: { league: string } };
    whisper: string;
    instant?: boolean;        // instant buyout; the real API layer maps this later
  };
  item: { name: string; baseType: string; ilvl: number; explicitMods: string[] };
}

export type SellerMode =
  | "instant"
  | "instant_or_person"
  | "person_online_league"
  | "person_online"
  | "any";

export interface SearchBudget { remaining: number; total: number; windowSecs: number }
```

- [ ] **Step 2: Write the failing checks**

`src/utils/priceCheck.check.ts`:

```ts
// Run: npx tsx src/utils/priceCheck.check.ts
import assert from "node:assert";
import {
  rollPct, sumCheckedByStatId, medianRecentDiv, toDivine, ageString,
  filterBySellerMode,
} from "./priceCheck";
import type { Stat, TradeResult } from "../types/priceCheck";

// rollPct
assert.strictEqual(rollPct({ text: "", statId: "", value: 148, range: { min: 135, max: 154 } }), 68);
assert.strictEqual(rollPct({ text: "", statId: "", value: 135, range: { min: 135, max: 154 } }), 0);
assert.strictEqual(rollPct({ text: "", statId: "", value: 154, range: { min: 135, max: 154 } }), 100);
assert.strictEqual(rollPct({ text: "", statId: "", value: 10 }), null);          // no range
assert.strictEqual(rollPct({ text: "", statId: "", value: 5, range: { min: 5, max: 5 } }), null); // zero-width

// sumCheckedByStatId: only statIds with 2+ checked stats produce a sum
const phys1: Stat = { text: "148%", statId: "increased Physical Damage", value: 148 };
const phys2: Stat = { text: "63%", statId: "increased Physical Damage", value: 63 };
const acc: Stat = { text: "+138", statId: "to Accuracy Rating", value: 138 };
assert.deepStrictEqual(
  sumCheckedByStatId([phys1, phys2, acc]),
  new Map([["increased Physical Damage", 211]]),
);
assert.deepStrictEqual(sumCheckedByStatId([phys1, acc]), new Map());

// toDivine: chaos rates from poe.ninja; divinePrice = chaos per divine
const rates = new Map([["exalted", 55], ["regal", 5.5], ["divine", 550]]);
assert.strictEqual(toDivine(1, "exalted", rates, 550), 0.1);
assert.strictEqual(toDivine(2, "divine", rates, 550), 2);
assert.strictEqual(toDivine(1, "unknown-orb", rates, 550), null);
assert.strictEqual(toDivine(1, "exalted", rates, 0), null);

// medianRecentDiv: online-filtered rows come in; keep indexed < 7 days; median of div values
const now = new Date("2026-07-31T12:00:00Z").getTime();
const mk = (daysAgo: number, amount: number): TradeResult => ({
  listing: {
    indexed: new Date(now - daysAgo * 86400_000).toISOString(),
    price: { type: "~price", amount, currency: "exalted" },
    account: { name: "a#1" },
    whisper: "w",
  },
  item: { name: "", baseType: "", ilvl: 0, explicitMods: [] },
});
const med = medianRecentDiv([mk(1, 1), mk(2, 2), mk(40, 99)], rates, 550, now);
assert.ok(med && med.n === 2);
assert.ok(Math.abs(med.div - 0.15) < 1e-9);                 // median of [0.1, 0.2]
assert.strictEqual(medianRecentDiv([mk(40, 99)], rates, 550, now), null);

// ageString
assert.strictEqual(ageString(new Date(now - 6 * 3600_000).toISOString(), now), "6 h ago");
assert.strictEqual(ageString(new Date(now - 4 * 86400_000).toISOString(), now), "4 d ago");
assert.strictEqual(ageString(new Date(now - 35 * 86400_000).toISOString(), now), "5 w ago");
assert.strictEqual(ageString(new Date(now - 30 * 60_000).toISOString(), now), "30 min ago");

// filterBySellerMode
const inst = mk(1, 1); inst.listing.instant = true;
const onl = mk(1, 2); onl.listing.account.online = { league: "X" };
const off = mk(1, 3);
const all = [inst, onl, off];
assert.deepStrictEqual(filterBySellerMode(all, "instant", "X"), [inst]);
assert.deepStrictEqual(filterBySellerMode(all, "instant_or_person", "X"), [inst, onl]);
assert.deepStrictEqual(filterBySellerMode(all, "person_online_league", "X"), [onl]);
assert.deepStrictEqual(filterBySellerMode(all, "person_online", "X"), [onl]);
assert.deepStrictEqual(filterBySellerMode(all, "any", "X"), all);

console.log("priceCheck checks OK");
```

- [ ] **Step 3: Run checks, verify they fail**

Run: `npx tsx src/utils/priceCheck.check.ts`
Expected: FAIL — cannot resolve `./priceCheck`.

- [ ] **Step 4: Implement the logic**

`src/utils/priceCheck.ts`:

```ts
import type { Stat, TradeResult, SellerMode } from "../types/priceCheck";

/** Roll position in its range, 0-100 rounded. null when no meaningful range. */
export function rollPct(stat: Stat): number | null {
  if (!stat.range) return null;
  const { min, max } = stat.range;
  if (max === min) return null;
  return Math.round(((stat.value - min) / (max - min)) * 100);
}

/** Totals per statId across checked stats; only ids fed by 2+ stats. */
export function sumCheckedByStatId(checked: Stat[]): Map<string, number> {
  const count = new Map<string, number>();
  const total = new Map<string, number>();
  for (const s of checked) {
    count.set(s.statId, (count.get(s.statId) ?? 0) + 1);
    total.set(s.statId, (total.get(s.statId) ?? 0) + s.value);
  }
  const sums = new Map<string, number>();
  for (const [id, n] of count) if (n >= 2) sums.set(id, total.get(id)!);
  return sums;
}

/** Listed price → divine, via chaos rates. null when the rate is unknown. */
export function toDivine(
  amount: number,
  currency: string,
  chaosRates: Map<string, number>, // currency slug → chaos per unit
  divinePrice: number,             // chaos per divine
): number | null {
  const rate = chaosRates.get(currency);
  if (rate === undefined || divinePrice <= 0) return null;
  return (amount * rate) / divinePrice;
}

const WEEK_MS = 7 * 86400_000;

/** Median (in div) of rows indexed < 7 days. null when none qualify or none normalise. */
export function medianRecentDiv(
  rows: TradeResult[],
  chaosRates: Map<string, number>,
  divinePrice: number,
  nowMs: number,
): { div: number; n: number } | null {
  const divs = rows
    .filter((r) => nowMs - Date.parse(r.listing.indexed) < WEEK_MS)
    .map((r) => toDivine(r.listing.price.amount, r.listing.price.currency, chaosRates, divinePrice))
    .filter((d): d is number => d !== null)
    .sort((a, b) => a - b);
  if (divs.length === 0) return null;
  const mid = Math.floor(divs.length / 2);
  const div = divs.length % 2 ? divs[mid] : (divs[mid - 1] + divs[mid]) / 2;
  return { div, n: divs.length };
}

/** "6 h ago" / "4 d ago" / "5 w ago" — age always visible, never hidden. */
export function ageString(indexed: string, nowMs: number): string {
  const mins = Math.max(0, Math.floor((nowMs - Date.parse(indexed)) / 60_000));
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} d ago`;
  return `${Math.floor(days / 7)} w ago`;
}

export function filterBySellerMode(
  rows: TradeResult[],
  mode: SellerMode,
  activeLeague: string,
): TradeResult[] {
  switch (mode) {
    case "instant":
      return rows.filter((r) => r.listing.instant);
    case "instant_or_person":
      return rows.filter((r) => r.listing.instant || r.listing.account.online);
    case "person_online_league":
      return rows.filter((r) => r.listing.account.online?.league === activeLeague);
    case "person_online":
      return rows.filter((r) => r.listing.account.online);
    case "any":
      return rows;
  }
}
```

- [ ] **Step 5: Run checks, verify they pass**

Run: `npx tsx src/utils/priceCheck.check.ts`
Expected: `priceCheck checks OK`
Also run: `npx tsc --noEmit` — clean.

- [ ] **Step 6: Commit**

```bash
git add src/types/priceCheck.ts src/utils/priceCheck.ts src/utils/priceCheck.check.ts
git commit -m "feat: price check types and pure logic with assert checks"
```

---

### Task 2: Fixture + parseItem stub

**Files:**
- Create: `src/utils/priceCheckFixture.ts`

**Interfaces:**
- Consumes: types from Task 1.
- Produces: `FIXTURE_BOW: ParsedItem`, `FIXTURE_RESULTS: TradeResult[]`, `FIXTURE_BUDGET: SearchBudget`, `parseItem(text: string): ParsedItem | null`, `mockSearch(): Promise<TradeResult[]>`. Later tasks import these exact names.

- [ ] **Step 1: Write the fixture module**

`src/utils/priceCheckFixture.ts` — the brief's bow, hand-parsed. Verbatim content:

```ts
import type { ParsedItem, TradeResult, SearchBudget } from "../types/priceCheck";

// The brief's real copy, hand-parsed. The future parser must reproduce this.
export const FIXTURE_BOW: ParsedItem = {
  itemClass: "Bows",
  rarity: "rare",
  name: "Torment Breeze",
  baseType: "Obliterator Bow",
  ilvl: 79,
  quality: 26,
  sockets: 2,
  corrupted: true,
  affixes: [
    {
      kind: "implicit", tags: [], desecrated: false, crafted: false,
      stats: [{ text: "50% reduced Projectile Range", statId: "reduced Projectile Range", value: 50 }],
    },
    {
      kind: "prefix", name: "Cruel", tier: 3,
      tags: ["Damage", "Physical", "Attack"], desecrated: false, crafted: false,
      stats: [{
        text: "148% increased Physical Damage", statId: "increased Physical Damage",
        value: 148, range: { min: 135, max: 154 },
      }],
    },
    {
      kind: "prefix", name: "Electrocuting", tier: 2,
      tags: ["Damage", "Elemental", "Lightning", "Attack"], desecrated: false, crafted: false,
      stats: [{
        // double value: midpoint of 6 and 180
        text: "Adds 6 to 180 Lightning Damage", statId: "Adds Lightning Damage",
        value: 93, range: { min: 79, max: 103 }, // midpoints of (1-10) and (157-196)
      }],
    },
    {
      kind: "prefix", name: "Conqueror's", tier: 3,
      tags: ["Damage", "Physical", "Attack"], desecrated: false, crafted: false,
      stats: [
        {
          text: "63% increased Physical Damage", statId: "increased Physical Damage",
          value: 63, range: { min: 55, max: 64 },
        },
        {
          text: "+138 to Accuracy Rating", statId: "to Accuracy Rating",
          value: 138, range: { min: 124, max: 149 },
        },
      ],
    },
    {
      kind: "suffix", name: "of Shards", tier: 2,
      tags: ["Attack"], desecrated: false, crafted: false,
      stats: [{
        text: "+149% Surpassing chance to fire an additional Arrow",
        statId: "Surpassing chance to fire an additional Arrow",
        value: 149, range: { min: 125, max: 150 },
      }],
    },
    {
      kind: "suffix", name: "of Amanamu", tier: 1,
      tags: [], desecrated: true, crafted: false,
      stats: [
        {
          text: "15% increased Attack Speed", statId: "increased Attack Speed",
          value: 15, range: { min: 12, max: 18 },
        },
        {
          text: "Companions have 16% increased Attack Speed",
          statId: "Companions increased Attack Speed",
          value: 16, range: { min: 12, max: 18 },
        },
      ],
    },
    {
      kind: "suffix", name: "of Calamity", tier: 3,
      tags: ["Attack", "Critical"], desecrated: false, crafted: true,
      stats: [{
        text: "+3.51% to Critical Hit Chance", statId: "to Critical Hit Chance",
        value: 3.51, range: { min: 3.11, max: 3.8 },
      }],
    },
  ],
  runeMods: ["40% increased Physical Damage (rune)"],
};

const daysAgo = (d: number) => new Date(Date.now() - d * 86400_000).toISOString();
const hoursAgo = (h: number) => new Date(Date.now() - h * 3600_000).toISOString();

export const FIXTURE_RESULTS: TradeResult[] = [
  {
    listing: {
      indexed: daysAgo(35),
      price: { type: "~price", amount: 1, currency: "exalted" },
      account: { name: "OldSeller#1234" },
      whisper: "@OldSeller Hi, I would like to buy your Torment Breeze Obliterator Bow listed for 1 exalted",
    },
    item: { name: "Torment Breeze", baseType: "Obliterator Bow", ilvl: 79, explicitMods: [] },
  },
  {
    listing: {
      indexed: hoursAgo(6),
      price: { type: "~price", amount: 1, currency: "regal" },
      account: { name: "Quick#5678", online: { league: "__active__" } },
      whisper: "@Quick Hi, I would like to buy your Torment Breeze Obliterator Bow listed for 1 regal",
      instant: true,
    },
    item: { name: "Torment Breeze", baseType: "Obliterator Bow", ilvl: 79, explicitMods: [] },
  },
  {
    listing: {
      indexed: daysAgo(4),
      price: { type: "~price", amount: 2, currency: "exalted" },
      account: { name: "Trader#9012", online: { league: "__active__" } },
      whisper: "@Trader Hi, I would like to buy your Torment Breeze Obliterator Bow listed for 2 exalted",
      instant: true,
    },
    item: { name: "Torment Breeze", baseType: "Obliterator Bow", ilvl: 79, explicitMods: [] },
  },
  {
    listing: {
      indexed: daysAgo(2),
      price: { type: "~price", amount: 3, currency: "exalted" },
      account: { name: "Person#3456", online: { league: "__active__" } },
      whisper: "@Person Hi, I would like to buy your Torment Breeze Obliterator Bow listed for 3 exalted",
    },
    item: { name: "Torment Breeze", baseType: "Obliterator Bow", ilvl: 79, explicitMods: [] },
  },
];

export const FIXTURE_BUDGET: SearchBudget = { remaining: 27, total: 30, windowSecs: 300 };

/**
 * Parser stub. Real parsing comes later; the contract is ParsedItem.
 * Returns null when Advanced Mod Descriptions is off (no "{ ... }" headers),
 * which is exactly the error state the UI must show.
 */
export function parseItem(text: string): ParsedItem | null {
  if (!text.includes("{ ")) return null;
  return FIXTURE_BOW;
}

/** Simulated search: a delay, then the fixture rows. The real API is never touched here. */
export function mockSearch(): Promise<TradeResult[]> {
  return new Promise((resolve) => setTimeout(() => resolve(FIXTURE_RESULTS), 600));
}
```

Note `online: { league: "__active__" }`: the component replaces `__active__` with the app's active league at render time (fixture must not hardcode a league name — house rule).

- [ ] **Step 2: Verify it compiles**

Run: `npx tsc --noEmit`
Expected: clean.

- [ ] **Step 3: Commit**

```bash
git add src/utils/priceCheckFixture.ts
git commit -m "feat: price check fixture data and parser stub"
```

---

### Task 3: PriceCheckTab rewrite — state router + header chips

**Files:**
- Modify: `src/components/PriceCheckTab.tsx` (full rewrite)
- Modify: `src/App.tsx` (pass new props)
- Modify: `src/styles.css` (append panel + chip styles)

**Interfaces:**
- Consumes: Task 1 types; Task 2 `parseItem`; `NormalizedItem` from `src/types/index.ts`.
- Produces: `PriceCheckTab` props `{ text: string | null; allItems: NormalizedItem[]; divinePrice: number; activeLeague: string }`; exported `FilterState` interface and `PriceCheckPanel` internal component that Tasks 4-5 extend. `FilterState` exact shape below.

- [ ] **Step 1: Rewrite PriceCheckTab**

`src/components/PriceCheckTab.tsx`:

```tsx
import { useState } from "react";
import type { NormalizedItem } from "../types";
import type { ParsedItem, Rarity } from "../types/priceCheck";
import { parseItem } from "../utils/priceCheckFixture";

interface Props {
  text: string | null;
  allItems: NormalizedItem[];
  divinePrice: number;
  activeLeague: string;
}

export interface FilterState {
  rarity: Rarity; rarityOn: boolean;
  corrupted: boolean; corruptedOn: boolean;
  fractured: boolean; fracturedOn: boolean;
  fracturedAffix: number | null;      // index into item.affixes, radio behaviour
  ilvl: string; ilvlOn: boolean;      // numeric fields kept as strings while editing
  quality: string; qualityOn: boolean;
  sockets: string; socketsOn: boolean;
}

export function initialFilters(item: ParsedItem): FilterState {
  return {
    rarity: item.rarity, rarityOn: true,
    corrupted: item.corrupted, corruptedOn: true,
    fractured: item.fracturedAffixIndex !== undefined,
    fracturedOn: item.fracturedAffixIndex !== undefined,
    fracturedAffix: item.fracturedAffixIndex ?? null,
    ilvl: String(item.ilvl), ilvlOn: false,
    quality: item.quality !== undefined ? String(item.quality) : "", qualityOn: false,
    sockets: String(item.sockets), socketsOn: false,
  };
}

export function PriceCheckTab({ text, allItems, divinePrice, activeLeague }: Props) {
  if (!text) {
    return (
      <div className="tab-content">
        <TabHeader subtitle="Waiting for an item" />
        <div className="favorites-empty">
          <p>Hover an item in Path of Exile 2 and press Ctrl+C.</p>
          <p>It lands here.</p>
        </div>
      </div>
    );
  }

  const item = parseItem(text);
  if (!item) {
    return (
      <div className="tab-content">
        <TabHeader subtitle="Could not read the item's mods" />
        <div className="pc-error">
          <p>This item was copied without mod details.</p>
          <p>
            Enable <strong>Options → Game → Advanced Mod Descriptions</strong> in
            Path of Exile 2 and copy the item again.
          </p>
        </div>
      </div>
    );
  }

  // State 1: the app already holds a poe.ninja price for this item.
  const ninja = allItems.find((i) => i.name === item.name || i.name === item.baseType);
  if (ninja) {
    return (
      <div className="tab-content">
        <TabHeader subtitle="Priced from poe.ninja — no search needed" />
        <div className="pc-panel">
          <ItemHeaderStatic item={item} />
          <div className="pc-ninja-price">
            <span className="chaos-value">{ninja.chaosValue.toFixed(1)}c</span>
            {divinePrice > 0 && (
              <span className="divine-value">
                ≈ {(ninja.chaosValue / divinePrice).toFixed(2)} div
              </span>
            )}
          </div>
        </div>
      </div>
    );
  }

  // State 2: rare — full search panel. key={text} remounts per item, so every
  // useState initialiser below runs fresh: the render-time reset, no effects.
  return (
    <div className="tab-content">
      <TabHeader subtitle="Pick the mods that matter, then search" />
      <PriceCheckPanel
        key={text}
        item={item}
        allItems={allItems}
        divinePrice={divinePrice}
        activeLeague={activeLeague}
      />
    </div>
  );
}

function TabHeader({ subtitle }: { subtitle: string }) {
  return (
    <div className="tab-header">
      <h2>📋 Price Check</h2>
      <p className="tab-subtitle">{subtitle}</p>
    </div>
  );
}

function ItemHeaderStatic({ item }: { item: ParsedItem }) {
  return (
    <div className="pc-item-header">
      <div className="pc-item-names">
        <span className="pc-item-name">{item.name}</span>
        <span className="pc-item-base">{item.baseType}</span>
      </div>
      <div className="pc-chips">
        <span className="pc-chip on">{item.itemClass}</span>
        <span className={`pc-chip rarity-${item.rarity}`}>{item.rarity}</span>
        <span className="pc-chip">ilvl {item.ilvl}</span>
        {item.quality !== undefined && <span className="pc-chip">Q +{item.quality}%</span>}
        {item.corrupted && <span className="pc-chip pc-corrupted">corrupted</span>}
      </div>
    </div>
  );
}

interface PanelProps {
  item: ParsedItem;
  allItems: NormalizedItem[];
  divinePrice: number;
  activeLeague: string;
}

function PriceCheckPanel({ item, allItems, divinePrice, activeLeague }: PanelProps) {
  const [filters, setFilters] = useState<FilterState>(() => initialFilters(item));

  const set = (patch: Partial<FilterState>) => setFilters((f) => ({ ...f, ...patch }));

  return (
    <div className="pc-panel">
      <div className="pc-item-header">
        <div className="pc-item-names">
          <span className="pc-item-name">{item.name}</span>
          <span className="pc-item-base">{item.baseType}</span>
        </div>
        <div className="pc-chips">
          {/* Item class: always searched, visible, not toggleable */}
          <span className="pc-chip on pc-chip-fixed" title="Always searched">
            {item.itemClass}
          </span>

          <label className={`pc-chip ${filters.rarityOn ? "on" : ""}`}>
            <input
              type="checkbox"
              checked={filters.rarityOn}
              onChange={(e) => set({ rarityOn: e.target.checked })}
            />
            <select
              value={filters.rarity}
              onChange={(e) => set({ rarity: e.target.value as Rarity, rarityOn: true })}
            >
              <option value="normal">normal</option>
              <option value="magic">magic</option>
              <option value="rare">rare</option>
              <option value="unique">unique</option>
            </select>
          </label>

          <label className={`pc-chip ${filters.corruptedOn ? "on" : ""}`}>
            <input
              type="checkbox"
              checked={filters.corruptedOn}
              onChange={(e) => set({ corruptedOn: e.target.checked })}
            />
            corrupted
            <select
              value={filters.corrupted ? "yes" : "no"}
              onChange={(e) => set({ corrupted: e.target.value === "yes", corruptedOn: true })}
            >
              <option value="yes">yes</option>
              <option value="no">no</option>
            </select>
          </label>

          <label className={`pc-chip ${filters.fracturedOn ? "on" : ""}`}>
            <input
              type="checkbox"
              checked={filters.fracturedOn}
              onChange={(e) => set({ fracturedOn: e.target.checked })}
            />
            fractured
            <select
              value={filters.fractured ? "yes" : "no"}
              onChange={(e) => set({ fractured: e.target.value === "yes", fracturedOn: true })}
            >
              <option value="yes">yes</option>
              <option value="no">no</option>
            </select>
          </label>

          <NumChip label="ilvl" field="ilvl" filters={filters} set={set} />
          <NumChip label="Q%" field="quality" filters={filters} set={set} />
          <NumChip label="sockets" field="sockets" filters={filters} set={set} />
        </div>
      </div>
      {/* Task 4 mounts <PriceCheckMods> here; Task 5 mounts the action bar + results */}
    </div>
  );
}

function NumChip({
  label, field, filters, set,
}: {
  label: string;
  field: "ilvl" | "quality" | "sockets";
  filters: FilterState;
  set: (patch: Partial<FilterState>) => void;
}) {
  const on = filters[`${field}On`];
  return (
    <label className={`pc-chip ${on ? "on" : ""}`}>
      <input
        type="checkbox"
        checked={on}
        onChange={(e) => set({ [`${field}On`]: e.target.checked } as Partial<FilterState>)}
      />
      {label} ≥
      <input
        type="number"
        className="pc-chip-num"
        value={filters[field]}
        onChange={(e) =>
          set({ [field]: e.target.value, [`${field}On`]: true } as Partial<FilterState>)
        }
      />
    </label>
  );
}
```

- [ ] **Step 2: Pass the new props from App**

In `src/App.tsx`, change the price-check line to:

```tsx
{activeTab === "price-check" && (
  <PriceCheckTab
    text={copiedItem}
    allItems={allItems}
    divinePrice={divinePrice}
    activeLeague={activeLeague}
  />
)}
```

(`allItems`, `divinePrice`, `activeLeague` all already exist in `App`.)

- [ ] **Step 3: Append styles**

Append to `src/styles.css` (colours only from existing variables):

```css
/* ===== PRICE CHECK ===== */
.pc-panel {
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: 6px;
  max-width: 720px;
}

.pc-error {
  padding: 24px;
  color: var(--text-secondary);
  line-height: 1.6;
}

.pc-item-header {
  padding: 12px 16px;
  border-bottom: 1px solid var(--border);
}

.pc-item-names { display: flex; gap: 10px; align-items: baseline; }
.pc-item-name { color: var(--gold-bright); font-weight: 600; font-size: 15px; }
.pc-item-base { color: var(--text-secondary); }

.pc-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }

.pc-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 2px 8px;
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--text-dim);
  font-size: 12px;
  cursor: pointer;
  user-select: none;
}
.pc-chip.on { color: var(--text-primary); border-color: var(--border-bright); }
.pc-chip-fixed { cursor: default; color: var(--gold); }
.pc-chip.pc-corrupted, .pc-chip .pc-corrupted { color: var(--red); }
.pc-chip.rarity-rare { color: var(--divine); }
.pc-chip.rarity-unique { color: var(--gold); }

.pc-chip input[type="checkbox"] {
  appearance: none;
  width: 12px; height: 12px;
  border: 1px solid var(--border-bright);
  border-radius: 3px;
  background: var(--bg-tertiary);
  cursor: pointer;
}
.pc-chip input[type="checkbox"]:checked {
  background: var(--gold-dim);
  border-color: var(--gold);
}

.pc-chip select {
  appearance: none;
  background: transparent;
  border: none;
  color: inherit;
  font: inherit;
  cursor: pointer;
}

.pc-chip-num {
  appearance: none;
  -moz-appearance: textfield;
  width: 44px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border);
  border-radius: 3px;
  color: var(--text-primary);
  font: inherit;
  padding: 1px 4px;
}
.pc-chip-num::-webkit-outer-spin-button,
.pc-chip-num::-webkit-inner-spin-button { appearance: none; margin: 0; }

.pc-ninja-price {
  padding: 20px 16px;
  display: flex;
  gap: 12px;
  align-items: baseline;
  font-size: 18px;
}
```

- [ ] **Step 4: Verify**

Run: `npx tsc --noEmit` — clean.
Visual (app already running under `npm run tauri dev`): copy the fixture bow text into the clipboard while the game window pattern matches, or temporarily paste the brief's item text via the existing `item-copied` flow. Header chips render, toggle, and edit.

- [ ] **Step 5: Commit**

```bash
git add src/components/PriceCheckTab.tsx src/App.tsx src/styles.css
git commit -m "feat: price check panel states and header filter chips"
```

---

### Task 4: Mod list — affix groups, stat rows, roll bars, Σ row, runes

**Files:**
- Create: `src/components/PriceCheckMods.tsx`
- Modify: `src/components/PriceCheckTab.tsx` (mount it, own the selection state)
- Modify: `src/styles.css` (append)

**Interfaces:**
- Consumes: Task 1 `rollPct`, `sumCheckedByStatId`; Task 3 `FilterState`.
- Produces: `PriceCheckMods` component and the selection state shape that Task 5 reads to build the search summary:

```ts
export interface StatSel { checked: boolean; min: string; max: string }
export type Selection = Record<string, StatSel>;       // key: `${affixIdx}:${statIdx}`
export type SumEdits = Record<string, { min: string; max: string }>; // key: statId
```

- [ ] **Step 1: Write PriceCheckMods**

`src/components/PriceCheckMods.tsx`:

```tsx
import type { ParsedItem, Stat } from "../types/priceCheck";
import { rollPct, sumCheckedByStatId } from "../utils/priceCheck";

export interface StatSel { checked: boolean; min: string; max: string }
export type Selection = Record<string, StatSel>;
export type SumEdits = Record<string, { min: string; max: string }>;

export function selKey(affixIdx: number, statIdx: number) {
  return `${affixIdx}:${statIdx}`;
}

/** All checked Stat objects, in item order. Task 5 uses this too. */
export function checkedStats(item: ParsedItem, sel: Selection): Stat[] {
  const out: Stat[] = [];
  item.affixes.forEach((a, ai) =>
    a.stats.forEach((s, si) => {
      if (sel[selKey(ai, si)]?.checked) out.push(s);
    }),
  );
  return out;
}

interface Props {
  item: ParsedItem;
  sel: Selection;
  onSel: (key: string, patch: Partial<StatSel>) => void;
  sums: SumEdits;
  onSum: (statId: string, patch: Partial<{ min: string; max: string }>) => void;
  fracturedAffix: number | null;
  onFractured: (affixIdx: number | null) => void;
}

export function PriceCheckMods({
  item, sel, onSel, sums, onSum, fracturedAffix, onFractured,
}: Props) {
  const activeSums = sumCheckedByStatId(checkedStats(item, sel));

  return (
    <div className="pc-mods">
      {item.affixes.map((affix, ai) => (
        <div className="pc-affix" key={ai}>
          <div className="pc-affix-head">
            {affix.tier !== undefined && <span className="pc-tier">T{affix.tier}</span>}
            <span className="pc-affix-kind">{affix.kind}</span>
            {affix.name && <span className="pc-affix-name">{affix.name}</span>}
            {affix.desecrated && <span className="pc-affix-tag">desecrated</span>}
            {affix.crafted && <span className="pc-affix-tag">crafted</span>}
            <button
              type="button"
              className={`pc-fracture ${fracturedAffix === ai ? "on" : ""}`}
              title="Mark as the fractured affix"
              onClick={() => onFractured(fracturedAffix === ai ? null : ai)}
            >
              ⛓
            </button>
          </div>

          {affix.stats.map((stat, si) => {
            const key = selKey(ai, si);
            const s = sel[key] ?? { checked: false, min: "", max: "" };
            const pct = rollPct(stat);
            const summed = s.checked && activeSums.has(stat.statId);
            return (
              <div className={`pc-stat ${s.checked ? "checked" : ""}`} key={si}>
                <label className="pc-stat-line">
                  <input
                    type="checkbox"
                    checked={s.checked}
                    onChange={(e) => onSel(key, { checked: e.target.checked })}
                  />
                  <span className="pc-stat-text">{stat.text}</span>
                  {pct !== null && <span className="pc-roll-pct">{pct}%</span>}
                </label>

                {stat.range && (
                  <div className="pc-roll">
                    <span className="pc-roll-end">{stat.range.min}</span>
                    <div className="pc-roll-bar">
                      <div className="pc-roll-fill" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="pc-roll-end">{stat.range.max}</span>
                  </div>
                )}

                {/* min/max hide while this stat feeds an active Σ row */}
                {s.checked && !summed && (
                  <div className="pc-minmax">
                    min
                    <input
                      type="number"
                      value={s.min || String(stat.value)}
                      onChange={(e) => onSel(key, { min: e.target.value })}
                    />
                    max
                    <input
                      type="number"
                      placeholder="—"
                      value={s.max}
                      onChange={(e) => onSel(key, { max: e.target.value })}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}

      {/* Σ rows: what actually travels to the search for shared statIds */}
      {[...activeSums].map(([statId, total]) => (
        <div className="pc-sum" key={statId}>
          <span className="pc-sum-sigma">Σ</span>
          <span className="pc-stat-text">{total}% {statId}</span>
          <div className="pc-minmax">
            min
            <input
              type="number"
              value={sums[statId]?.min || String(total)}
              onChange={(e) => onSum(statId, { min: e.target.value })}
            />
            max
            <input
              type="number"
              placeholder="—"
              value={sums[statId]?.max ?? ""}
              onChange={(e) => onSum(statId, { max: e.target.value })}
            />
          </div>
        </div>
      ))}

      {item.runeMods.length > 0 && (
        <div className="pc-runes">
          <div className="pc-runes-label">not searched</div>
          {item.runeMods.map((m) => (
            <div className="pc-rune-mod" key={m}>{m}</div>
          ))}
        </div>
      )}
    </div>
  );
}
```

Note: the Σ row prints `{total}% {statId}` — right for percent stats, which is the only case the fixture produces two of. Flat-value shared stats would render oddly; acceptable until a real parser produces one.

- [ ] **Step 2: Own the state in PriceCheckPanel and mount**

In `PriceCheckPanel` (Task 3), add:

```tsx
import { PriceCheckMods, checkedStats, type Selection, type SumEdits } from "./PriceCheckMods";

// inside PriceCheckPanel, after filters:
const [sel, setSel] = useState<Selection>({});
const [sums, setSums] = useState<SumEdits>({});

const onSel = (key: string, patch: Partial<StatSel>) =>
  setSel((s) => ({ ...s, [key]: { checked: false, min: "", max: "", ...s[key], ...patch } }));
const onSum = (statId: string, patch: Partial<{ min: string; max: string }>) =>
  setSums((s) => ({ ...s, [statId]: { min: "", max: "", ...s[statId], ...patch } }));
```

(import `StatSel` type too) and mount below the header:

```tsx
<PriceCheckMods
  item={item}
  sel={sel}
  onSel={onSel}
  sums={sums}
  onSum={onSum}
  fracturedAffix={filters.fracturedAffix}
  onFractured={(i) => set({ fracturedAffix: i, fractured: i !== null, fracturedOn: i !== null })}
/>
```

- [ ] **Step 3: Append styles**

```css
.pc-mods { padding: 8px 16px; border-bottom: 1px solid var(--border); }

.pc-affix { margin: 8px 0; }
.pc-affix-head {
  display: flex; gap: 8px; align-items: center;
  color: var(--text-dim); font-size: 11px;
}
.pc-tier {
  color: var(--gold);
  border: 1px solid var(--gold-dim);
  border-radius: 3px;
  padding: 0 4px;
}
.pc-affix-name { color: var(--text-secondary); }
.pc-affix-tag { color: var(--chaos); }
.pc-fracture {
  appearance: none;
  background: none; border: none;
  color: var(--text-dim); cursor: pointer; font-size: 12px;
  margin-left: auto;
}
.pc-fracture.on { color: var(--gold-bright); }

.pc-stat { padding: 3px 0 3px 8px; }
.pc-stat-line { display: flex; gap: 8px; align-items: center; cursor: pointer; }
.pc-stat-line input[type="checkbox"] {
  appearance: none;
  width: 14px; height: 14px; flex: none;
  border: 1px solid var(--border-bright); border-radius: 3px;
  background: var(--bg-tertiary); cursor: pointer;
}
.pc-stat-line input[type="checkbox"]:checked {
  background: var(--gold-dim); border-color: var(--gold);
}
.pc-stat-text { color: var(--text-primary); }
.pc-stat.checked .pc-stat-text { color: var(--gold-bright); }
.pc-roll-pct { margin-left: auto; color: var(--green); font-size: 12px; }

.pc-roll { display: flex; gap: 6px; align-items: center; margin: 2px 0 0 22px; }
.pc-roll-end { color: var(--text-dim); font-size: 11px; }
.pc-roll-bar {
  flex: 1; max-width: 220px; height: 6px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border); border-radius: 3px;
  overflow: hidden;
}
.pc-roll-fill { height: 100%; background: var(--gold-dim); }

.pc-minmax {
  display: flex; gap: 6px; align-items: center;
  margin: 3px 0 0 22px;
  color: var(--text-dim); font-size: 11px;
}
.pc-minmax input {
  appearance: none;
  -moz-appearance: textfield;
  width: 56px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border); border-radius: 3px;
  color: var(--text-primary); font: inherit; padding: 1px 4px;
}
.pc-minmax input::-webkit-outer-spin-button,
.pc-minmax input::-webkit-inner-spin-button { appearance: none; margin: 0; }

.pc-sum {
  display: flex; gap: 8px; align-items: center;
  margin: 8px 0; padding: 6px 8px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-bright); border-radius: 4px;
}
.pc-sum-sigma { color: var(--gold); font-weight: 600; }
.pc-sum .pc-minmax { margin: 0 0 0 auto; }

.pc-runes { margin: 10px 0 6px; }
.pc-runes-label {
  color: var(--text-dim); font-size: 11px;
  display: flex; align-items: center; gap: 8px;
}
.pc-runes-label::after {
  content: ""; flex: 1; border-top: 1px solid var(--border);
}
.pc-rune-mod { color: var(--text-dim); padding: 2px 0 0 8px; font-style: italic; }
```

- [ ] **Step 4: Verify**

Run: `npx tsc --noEmit` — clean.
Visual: check Cruel + Conqueror's phys lines → Σ 211% row appears, child min/max fields hide; uncheck one → Σ disappears, fields return. Amanamu's two lines check independently. Rune section dimmed with "not searched" rule. ⛓ toggles as radio.

- [ ] **Step 5: Commit**

```bash
git add src/components/PriceCheckMods.tsx src/components/PriceCheckTab.tsx src/styles.css
git commit -m "feat: price check mod list with per-stat selection and sum rows"
```

---

### Task 5: Action bar + results + median footer

**Files:**
- Create: `src/components/PriceCheckResults.tsx`
- Modify: `src/components/PriceCheckTab.tsx` (search state + mount)
- Modify: `src/styles.css` (append)

**Interfaces:**
- Consumes: Task 1 `toDivine`, `medianRecentDiv`, `ageString`, `filterBySellerMode`, `SellerMode`, `SearchBudget`, `TradeResult`; Task 2 `mockSearch`, `FIXTURE_BUDGET`; Task 4 `checkedStats`.
- Produces: `PriceCheckResults` component (props below); search flow inside `PriceCheckPanel`.

- [ ] **Step 1: Write PriceCheckResults**

`src/components/PriceCheckResults.tsx`:

```tsx
import type { SellerMode, TradeResult } from "../types/priceCheck";
import { ageString, filterBySellerMode, medianRecentDiv, toDivine } from "../utils/priceCheck";

interface Props {
  results: TradeResult[];       // raw, unfiltered
  sellerMode: SellerMode;
  activeLeague: string;
  chaosRates: Map<string, number>;
  divinePrice: number;
}

export function PriceCheckResults({
  results, sellerMode, activeLeague, chaosRates, divinePrice,
}: Props) {
  const now = Date.now();
  const shown = filterBySellerMode(results, sellerMode, activeLeague)
    .slice()
    .sort((a, b) => {
      const da = toDivine(a.listing.price.amount, a.listing.price.currency, chaosRates, divinePrice);
      const db = toDivine(b.listing.price.amount, b.listing.price.currency, chaosRates, divinePrice);
      return (da ?? Infinity) - (db ?? Infinity);
    });

  if (shown.length === 0) {
    return <div className="pc-no-results">No listings match this filter.</div>;
  }

  const median = medianRecentDiv(shown, chaosRates, divinePrice, now);

  return (
    <div className="pc-results">
      {shown.map((r, i) => {
        const { amount, currency } = r.listing.price;
        const div = toDivine(amount, currency, chaosRates, divinePrice);
        const online = !!r.listing.account.online;
        return (
          <div className="pc-result" key={i}>
            <span className="pc-price">{amount} {currency}</span>
            <span className="pc-div">{div !== null ? `≈ ${div.toFixed(2)} div` : ""}</span>
            <span className="pc-age">{ageString(r.listing.indexed, now)}</span>
            <span className={`pc-online ${online ? "on" : ""}`} title={online ? "Seller online" : "Seller offline"}>
              {online ? "●" : "○"}
            </span>
            <button
              type="button"
              className="pc-copy"
              title="Copy whisper"
              onClick={() => navigator.clipboard.writeText(r.listing.whisper)}
            >
              ⧉
            </button>
          </div>
        );
      })}

      <div className="pc-median">
        {median
          ? <>median (recent, n={median.n}): <strong>{median.div.toFixed(2)} div</strong></>
          : "no listings recent enough for a median"}
      </div>
    </div>
  );
}
```

- [ ] **Step 2: Search state + action bar in PriceCheckPanel**

Add to `PriceCheckPanel` in `PriceCheckTab.tsx`:

```tsx
import { useMemo } from "react";
import type { SellerMode, TradeResult } from "../types/priceCheck";
import { FIXTURE_BUDGET, mockSearch } from "../utils/priceCheckFixture";
import { PriceCheckResults } from "./PriceCheckResults";

// state:
const [sellerMode, setSellerMode] = useState<SellerMode>("instant");
const [results, setResults] = useState<TradeResult[] | null>(null);
const [searching, setSearching] = useState(false);
const budget = FIXTURE_BUDGET; // real headers replace this with the API layer

// chaos rate per trade currency slug, from the prices the app already holds
const chaosRates = useMemo(() => {
  const m = new Map<string, number>();
  const want: Record<string, string> = {
    exalted: "Exalted Orb", divine: "Divine Orb", regal: "Regal Orb",
    chaos: "Chaos Orb", annul: "Orb of Annulment", alch: "Orb of Alchemy",
  };
  for (const [slug, name] of Object.entries(want)) {
    const it = allItems.find((i) => i.name === name);
    if (it) m.set(slug, it.chaosValue);
  }
  return m;
}, [allItems]);

const anyChecked = checkedStats(item, sel).length > 0;

const runSearch = async () => {
  setSearching(true);
  try {
    // fixture rows use "__active__" as a placeholder league; stamp the real one
    const rows = (await mockSearch()).map((r) =>
      r.listing.account.online
        ? { ...r, listing: { ...r.listing, account: { ...r.listing.account, online: { league: activeLeague } } } }
        : r,
    );
    setResults(rows);
  } finally {
    setSearching(false);
  }
};
```

and render after `<PriceCheckMods …/>`:

```tsx
<div className="pc-action-bar">
  <button
    type="button"
    className="pc-search-btn"
    disabled={searching || !anyChecked || budget.remaining === 0}
    onClick={runSearch}
  >
    {searching ? "Searching…" : "Search trade"}
  </button>

  <select
    className="pc-seller-mode"
    value={sellerMode}
    onChange={(e) => setSellerMode(e.target.value as SellerMode)}
  >
    <option value="instant">Instant Buyout</option>
    <option value="instant_or_person">Instant Buyout and In Person</option>
    <option value="person_online_league">In Person (Online in League)</option>
    <option value="person_online">In Person (Online)</option>
    <option value="any">Any</option>
  </select>

  <span
    className={`pc-budget ${budget.remaining === 0 ? "pc-budget-out" : ""}`}
    title="Trade searches left in the current window"
  >
    {budget.remaining}/{budget.total} ◷{Math.round(budget.windowSecs / 60)}m
  </span>
</div>

{budget.remaining === 0 && (
  <div className="pc-no-results">
    Search budget exhausted — wait for the window to reset (◷{Math.round(budget.windowSecs / 60)}m).
  </div>
)}

{results !== null && (
  <PriceCheckResults
    results={results}
    sellerMode={sellerMode}
    activeLeague={activeLeague}
    chaosRates={chaosRates}
    divinePrice={divinePrice}
  />
)}
```

- [ ] **Step 3: Append styles**

```css
.pc-action-bar {
  display: flex; gap: 10px; align-items: center;
  padding: 10px 16px;
  border-bottom: 1px solid var(--border);
}
.pc-search-btn {
  appearance: none;
  background: var(--gold-dim);
  border: 1px solid var(--gold);
  border-radius: 4px;
  color: var(--bg-primary);
  font: inherit; font-weight: 600;
  padding: 5px 14px;
  cursor: pointer;
}
.pc-search-btn:hover:not(:disabled) { background: var(--gold); }
.pc-search-btn:disabled {
  background: var(--bg-tertiary);
  border-color: var(--border);
  color: var(--text-dim);
  cursor: default;
}
.pc-seller-mode {
  appearance: none;
  background: var(--bg-tertiary);
  border: 1px solid var(--border);
  border-radius: 4px;
  color: var(--text-primary);
  font: inherit; padding: 4px 8px;
  cursor: pointer;
}
.pc-budget { margin-left: auto; color: var(--text-secondary); font-size: 12px; }
.pc-budget-out { color: var(--red); }

.pc-results { padding: 6px 16px 10px; }
.pc-result {
  display: grid;
  grid-template-columns: 90px 100px 1fr 20px 28px;
  gap: 8px; align-items: center;
  padding: 4px 0;
  border-bottom: 1px solid var(--border);
}
.pc-price { color: var(--gold-bright); }
.pc-div { color: var(--divine); font-size: 12px; }
.pc-age { color: var(--text-secondary); font-size: 12px; }
.pc-online { color: var(--text-dim); }
.pc-online.on { color: var(--green); }
.pc-copy {
  appearance: none;
  background: none; border: 1px solid var(--border);
  border-radius: 3px;
  color: var(--text-secondary);
  cursor: pointer; padding: 1px 6px;
}
.pc-copy:hover { color: var(--gold-bright); border-color: var(--border-bright); }

.pc-no-results { padding: 14px 16px; color: var(--text-secondary); }
.pc-median {
  padding: 8px 0 2px;
  color: var(--text-secondary);
  font-size: 12px;
}
.pc-median strong { color: var(--divine); }
```

- [ ] **Step 4: Verify**

Run: `npx tsc --noEmit` — clean.
Run: `npx tsx src/utils/priceCheck.check.ts` — still OK.
Visual: button disabled until a stat is checked; search shows the 3 instant/online rows under default mode and all 4 under Any; rows sorted by ≈div ascending; ages visible; ⧉ copies the whisper; median footer shows `n=`.

- [ ] **Step 5: Commit**

```bash
git add src/components/PriceCheckResults.tsx src/components/PriceCheckTab.tsx src/styles.css
git commit -m "feat: price check search bar, results list and median footer"
```

---

### Task 6: Final verification

**Files:** none new.

- [ ] **Step 1: Full check run**

```bash
npx tsc --noEmit
npx tsx src/utils/priceCheck.check.ts
```

Expected: both clean.

- [ ] **Step 2: App health check** (per CLAUDE.md, after any change)

```bash
grep -c 'lines for' dev.log          # 32 per cycle
grep -icE 'panic|PARSE ERROR' dev.log  # 0
```

- [ ] **Step 3: Visual walkthrough of every state**

1. No item → waiting message.
2. Text without `{ ` headers → Advanced Mod Descriptions error panel.
3. Fixture bow → full panel; new copy of a different text remounts and resets.
4. An item whose name matches a poe.ninja item (e.g. copy text for a unique the app prices) → state 1 price, no controls.
5. Seller-mode "Any" vs default → row set changes, median recomputes.

- [ ] **Step 4: Commit anything outstanding**

```bash
git status
git add -A && git commit -m "feat: price check panel complete"
```
