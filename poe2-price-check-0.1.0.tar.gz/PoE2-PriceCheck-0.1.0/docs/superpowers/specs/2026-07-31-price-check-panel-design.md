# Price Check panel — design

Companion to `PRICE-CHECK-BRIEF.md`, which defines scope and constraints.
This document records the decisions taken on top of it. Everything here is
driven by items arriving over Ctrl+C (`item-copied` event → `copiedItem`);
the panel has no other input.

## Types (contract for the future parser)

```ts
type Rarity = "normal" | "magic" | "rare" | "unique";

interface ParsedItem {
  itemClass: string;          // "Bows"
  rarity: Rarity;
  name: string;               // "Torment Breeze"
  baseType: string;           // "Obliterator Bow"
  ilvl: number;
  quality?: number;           // 26 for "+26%"
  sockets: number;            // count of "S" entries
  corrupted: boolean;
  fracturedAffixIndex?: number; // index into affixes, if the item text marks one
  affixes: Affix[];
  runeMods: string[];         // shown, never searched
}

interface Affix {
  kind: "prefix" | "suffix" | "implicit";
  name?: string;              // "Cruel" — implicits have none
  tier?: number;
  tags: string[];             // ["Damage", "Physical", "Attack"]
  desecrated: boolean;
  crafted: boolean;
  stats: Stat[];              // one affix can carry several lines
}

interface Stat {
  text: string;               // display line, e.g. "148% increased Physical Damage"
  statId: string;             // key used for cross-affix summing
  value: number;              // 148 (midpoint for two-part values like 6-180 → use avg)
  range?: { min: number; max: number }; // from "(135-154)"
  rollPct?: number;           // (value - min) / (max - min), when range exists
}

interface TradeResult {       // the brief's fixture shape, verbatim
  listing: {
    indexed: string;
    price: { type: string; amount: number; currency: string };
    account: { name: string; online?: { league: string } };
    whisper: string;
  };
  item: { name: string; baseType: string; ilvl: number; explicitMods: string[] };
}
```

The bow fixture from the brief is hardcoded in a module, pre-parsed into
`ParsedItem` by hand. The search is simulated: a delay plus a fixed
`TradeResult[]`. The real trade API is neither called nor imported.

## Layout

Single column, top to bottom:

### Header — editable filter chips

Every fact shown in the header is also a search filter chip. A chip has an
on/off state (off = not part of the search) and, where noted, an editable
value defaulting to the item's own:

- **Item class** — always on, visible, not toggleable. Appears in the search
  summary like everything else (no silent inclusion).
- **Rarity** — selector: normal / magic / rare / unique. Default: item's.
- **Corrupted** — yes/no. Default: item's.
- **Fractured** — yes/no. Default: whether the item has a fractured affix.
- **Item level, quality, sockets** — toggle + editable numeric value
  (searched as minimum). Default value: the item's.

### Mod list — one row per stat, grouped by affix

Each affix renders a visual group header (tier badge, affix name,
desecrated/crafted marker) with one row per stat beneath it:

- **Checkbox per stat line**, not per affix. Checking the attack-speed line
  of "of Amanamu" without its companion line is the point.
- **Roll bar** with the range endpoints and the roll's position as a
  percentage (`148 (135–154) → 68%`). Shown when the stat has a range.
- **Min/max fields** appear when the stat is checked. Default: min = the
  item's roll, max = empty. What is shown is what is searched.
- **Fractured marker** per affix, radio behaviour — at most one affix is
  fractured at a time. Default: the parsed one, if any. When the Fractured
  chip is on, the marked affix's stats are searched as fractured mods.

### Sum row (Σ)

When two or more **checked** stats share a `statId`, a Σ row appears showing
the total (Cruel 148% + Conqueror's 63% → `Σ 211% increased Physical
Damage`). The Σ row is what travels to the search; its min/max is edited on
the Σ row itself, and the child rows' min/max fields hide while the sum is
active.

### "Not searched" section

Rune mods, dimmed, no checkbox, labelled as excluded. Exclusion is visible,
never silent.

### Action bar

- `[ Search trade ]` button. Nothing searches automatically.
- Seller-mode dropdown mirroring the trade site's options; default
  **Instant Buyout**. This is the only results filter besides the active
  league (taken from the app's league state — never hardcoded).
- Search budget, always visible: `27/30 ◷5m`, read from response headers
  (fixture supplies a static value).

### Results

- Sorted by price ascending.
- Row: listed price, ≈ divine value (normalised with the app's poe.ninja
  rates), age of `listing.indexed`, online mark (● / ○), whisper copy
  button (⧉). Age is always visible on the row.
- Footer: **median of the visible rows** (after the seller-mode filter)
  restricted to listings indexed < 7 days, with the sample size always
  shown: `median (recent, n=4): 2 ex`. Never hidden, never without its `n`.

## States

1. **Priced categories** (currency, uniques, gems, tablets): header plus the
   poe.ninja price the app already holds. No checkboxes, no button.
2. **Rares**: the full layout above. Reads as an action to take, not as
   something loading.
3. **Advanced Mod Descriptions off** (item text has no `{ … }` headers): a
   panel explaining the option must be enabled in the game, and where. No
   guessing.
4. **Budget exhausted (0/30)**: button disabled, countdown to the window
   reset visible.
5. **Zero results**: an explicit message, not an empty table.

## Implementation notes

- Scope: `src/components/PriceCheckTab.tsx` plus new components it needs;
  styles in `src/styles.css` using the existing CSS variables. No new hex
  values without a reason.
- `appearance: none` on every checkbox, select and number input.
- New-item reset: adjust state during render (the `ItemTable` pattern), not
  in an effect — no one-frame flash of the previous item.
- `src-tauri/` untouched. No trade API imports anywhere.
- One assert-based check file covering `rollPct` and per-`statId` summing.
  No test framework.
- Done when `npx tsc --noEmit` is clean.
