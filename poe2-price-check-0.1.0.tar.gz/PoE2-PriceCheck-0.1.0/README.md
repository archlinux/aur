# PoE2 Price Check

Price checker for Path of Exile 2 that runs natively on Wayland — built on and
for Hyprland. Ctrl+C an item in game and get the live trade listings, plus the
whole poe.ninja economy in the other tabs.

## Why this exists

The established PoE2 price checkers are Windows-first and built as a transparent
always-on-top overlay drawn over the game window, driven by a globally grabbed
hotkey. Wayland allows neither by design: a client cannot place itself over
another application's window, and there is no global key grab.

So this is not an overlay. It is an ordinary window, and the trigger is the
game's own Ctrl+C — the clipboard is the one channel that behaves the same
everywhere. Put it on a second monitor, or bind it to a Hyprland scratchpad and
toggle it over the game.

The clipboard watcher shells out to `wl-paste --watch` (see
`src-tauri/src/clipboard.rs`), so **`wl-clipboard` is required** and the Price
Check tab is Wayland-only. Without it the app still runs; item copy just logs
that it is off and the economy tabs work as normal.

Being a normal window costs the at-a-glance overlay and buys a real UI: the
whole economy in tabs, favourites, sortable tables, and enough room to pick
which mods go into the search.

## Features

- All poe.ninja categories: Currency, Fragments, Gems, Maps, Uniques, Divination Cards, etc.
- **Price Check** tab: Ctrl+C an item in game and search it on the official
  trade site — pick the mods that matter, filter by base stats and DPS, and
  get the live listings with a median. Optional session cookie for a
  per-account rate budget. See `STATUS.md`.
- **Most Expensive** tab: top 100 items across all categories
- **Favorites** tab: star any item, persists across sessions
- Auto-refresh every N minutes (configurable)
- Dynamic league detection — no hardcoded league names
- Sortable tables, search/filter, item icons
- Dark PoE-themed UI with gold accents

## Dependencies

### Arch Linux

```bash
# Rust toolchain
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source ~/.cargo/env

# Node.js
sudo pacman -S nodejs npm

# Tauri system deps
sudo pacman -S webkit2gtk-4.1 base-devel curl wget file openssl appmenu-gtk-module gtk3 \
  libappindicator-gtk3 librsvg xdotool

# Required for the Price Check tab: the clipboard watcher runs `wl-paste --watch`
sudo pacman -S wl-clipboard

# Optional: for building .deb/.rpm
sudo pacman -S dpkg rpm-tools

# AUR: tauri-cli (or install via cargo below)
# cargo install tauri-cli --version "^2"
```

### Other Linux (Ubuntu/Debian)

```bash
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file libssl-dev \
  libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev

# Required for the Price Check tab
sudo apt install wl-clipboard
```

### Windows / macOS

See [Tauri prerequisites](https://tauri.app/start/prerequisites/). The economy
tabs are portable, but the Price Check tab is not: the clipboard watcher is
`wl-paste`. Porting it means swapping `clipboard.rs` for a cross-platform
clipboard, which nothing here does today.

## Development

```bash
# Install frontend deps
npm install

# Run in development (hot-reload)
npm run tauri dev
```

## Build

```bash
# Production build (creates AppImage on Linux)
npm run tauri build
```

Output bundles are in `src-tauri/target/release/bundle/`.

## Config File

Location (Linux): `~/.config/com.poe2pricecheck.app/config.toml`

The directory comes from the bundle identifier in `tauri.conf.json`, not the package name.

```toml
preferred_league = "latest"   # "latest" or "standard"
difficulty = "softcore"        # "softcore" or "hardcore"
refresh_interval_minutes = 5
window_width = 1280
window_height = 800
theme = "dark"

# Optional. Set from the Price Check panel ("session" button), never by hand.
# Without it the app searches the trade site anonymously, which works fine —
# a session only moves the rate limit to your account's own budget instead of
# sharing your IP's. It is a full account session: treat it as a password.
# poesessid = "..."
```

Favorites: `~/.config/com.poe2pricecheck.app/favorites.json`
Trade stat definitions (cache): `~/.config/com.poe2pricecheck.app/trade_stats.json`

## Data Sources

poe.ninja serves PoE2 economy data from two different APIs, and a category lives
on exactly one of them:

| API | Path | Serves |
|---|---|---|
| Exchange | `/poe2/api/economy/exchange/current/overview` | Currency, Fragments, Essences, Runes, gems… — anything traded on the in-game currency exchange |
| Stash | `/poe2/api/economy/stash/current/item/overview` | Uniques, tablets — priced by scraping public stash tabs |

Asking the exchange API for a stash category returns **HTTP 200 with an empty
`lines` array**, not an error, so a wrong guess fails silently.

`fetch_item_overview` tries the exchange first and falls back to stash when the
result is empty. The winning route is remembered per league+category, so later
refreshes skip the wasted request. A remembered route that comes back empty is
discarded and re-probed, so a category moving between APIs self-corrects.

The two responses have different shapes — the stash API puts item metadata
inline on each line instead of in a separate `items` array, and uses a numeric
`id`. Both share the same price convention: `primaryValue` is in divine, and
`core.rates.chaos` converts to chaos.

If both APIs come back empty, poe.watch is tried as a last resort.

### Remembered discovery

Everything discovered by scraping — the league list, the category list, and
which API serves each category — is written to `discovery.json` next to the
config, and reused when a later discovery fails. About 3 KB.

This is the app's answer to its most fragile coupling: a sitemap or `<title>`
change would otherwise leave it with an empty sidebar and no error. Nothing in
that file is hardcoded; every value was learned from poe.ninja, and a
successful discovery overwrites it.

It also removes the repeated cost of relearning facts that change once a
league: a launch no longer downloads the 386 KB sitemap twice, and the
remembered routes save the nine wasted exchange requests that the unique
categories used to cost on the first refresh after every launch.

### Category and league names

Neither is hardcoded. Both are discovered from poe.ninja's sitemap at startup, so
a new challenge league works without a code change.

Category slugs are converted to API type names by capitalising the words
(`soul-cores` → `SoulCores`), with a small exception table in `slug_to_api_type`
for the ones poe.ninja names differently — `unique-relics` is
`UniqueSanctumRelics`, `omens` is `Ritual`. A wrong type name is invisible: it
returns an empty list rather than a 404. When a category renders empty, check
that mapping first.

## Project Structure

```
src-tauri/
  src/
    main.rs       Entry point
    lib.rs        Tauri app setup, command registration
    api.rs        HTTP calls to poe.ninja
    trade.rs      GGG trade2: stat index, query building, rate budget
    clipboard.rs  Watches the clipboard for copied items
    discovery.rs  Remembered leagues/categories/routes
    config.rs     Config load/save (TOML), optional session cookie
    state.rs      Shared app state
  tauri.conf.json Tauri configuration
  Cargo.toml

src/
  components/     React UI components
    Header.tsx    League selector, refresh button, status bar
    Sidebar.tsx   Category navigation
    ItemTable.tsx Sortable/filterable price table
    CategoryTab.tsx
    MostExpensiveTab.tsx
    FavoritesTab.tsx
    ErrorBoundary.tsx
  hooks/
    useConfig.ts    Config R/W via Tauri commands
    useFavorites.ts Favorites persistence
    useLeagues.ts   Dynamic league detection
    usePriceData.ts Fetch + cache all category data
  types/index.ts  Shared TypeScript types
  utils/
    categories.ts  Category list + endpoints
    leagues.ts     League parsing + selection
    normalize.ts   poe.ninja response → NormalizedItem
  styles.css
```

## Disclaimer

Unofficial fan project. Not affiliated with, endorsed by or connected to
Grinding Gear Games or poe.ninja. Path of Exile and all related assets are the
property of Grinding Gear Games.

Economy data comes from [poe.ninja](https://poe.ninja); listings come from GGG's
official trade API. Item icons are linked from GGG's CDN, never redistributed
here. Every request identifies itself with a contactable User-Agent — if you run
one of those services and want this to back off, the address is in the UA.

## License

MIT — see [LICENSE](LICENSE).
