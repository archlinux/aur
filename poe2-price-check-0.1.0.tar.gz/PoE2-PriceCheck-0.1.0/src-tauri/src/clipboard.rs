use std::io::Read;
use std::process::{Command, Stdio};
use tauri::{AppHandle, Emitter};

// Every item PoE2 copies starts with this line. Nothing else on the clipboard
// reaches the frontend, so copying ordinary text elsewhere is ignored.
const ITEM_PREFIX: &str = "Item Class:";

// wl-paste --watch frames nothing of its own, so the helper prints a record
// separator after each payload and we split on it. Item text is multi-line and
// contains blank lines, so no line-based delimiter would do.
const SEP: u8 = 0x1e;

/// The clipboard as it stands right now, or an empty string if it cannot be
/// read. Used only to know what was already there before we started watching.
fn current_clipboard() -> String {
    Command::new("wl-paste")
        .args(["--no-newline", "--type", "text/plain"])
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default()
}

/// Forwards items copied out of Path of Exile 2 to the frontend as
/// `item-copied` events.
///
/// There is no global hotkey and nothing is injected into the game: PoE2
/// already copies the hovered item on Ctrl+C, which is the whole trigger.
/// Watching costs one child process and stops when the app does — the watcher
/// is this process.
pub fn watch(app: AppHandle) {
    std::thread::spawn(move || {
        // `last` deduplicates: the same copy can surface more than once, since
        // the clipboard offers several mime types. It starts at whatever is on
        // the clipboard already, because --watch fires once for the current
        // content the moment it starts, and an item copied before launch is not
        // something the user just did. Seeding beats skipping the first record:
        // on an empty clipboard nothing fires at startup, and a count-based
        // skip would eat the first real copy instead. Read before the spawn so
        // nothing copied in between is mistaken for what was already there.
        let mut last = current_clipboard();

        // --watch runs the command once per clipboard change with the new
        // content on its stdin. Event-driven; no polling loop of ours.
        let mut child = match Command::new("wl-paste")
            .args([
                "--type",
                "text/plain",
                "--watch",
                "sh",
                "-c",
                "cat; printf '\\036'",
            ])
            .stdout(Stdio::piped())
            .spawn()
        {
            Ok(child) => child,
            Err(e) => {
                eprintln!("clipboard: wl-paste unavailable, item copy is off: {e}");
                return;
            }
        };

        let mut stdout = child.stdout.take().expect("stdout is piped");
        let mut buf: Vec<u8> = Vec::new();
        let mut chunk = [0u8; 8192];

        loop {
            let read = match stdout.read(&mut chunk) {
                Ok(0) => break,
                Ok(n) => n,
                Err(e) => {
                    eprintln!("clipboard: read failed: {e}");
                    break;
                }
            };
            buf.extend_from_slice(&chunk[..read]);

            while let Some(end) = buf.iter().position(|&b| b == SEP) {
                let payload: Vec<u8> = buf.drain(..=end).collect();
                let text = String::from_utf8_lossy(&payload[..end]).trim().to_string();

                if !text.starts_with(ITEM_PREFIX) || text == last {
                    continue;
                }
                last = text.clone();

                match app.emit("item-copied", &text) {
                    Ok(()) => eprintln!(
                        "[clipboard] item copied: {} bytes, {} lines",
                        text.len(),
                        text.lines().count()
                    ),
                    Err(e) => eprintln!("[clipboard] emit failed: {e}"),
                }
            }
        }

        let _ = child.wait();
    });
}
