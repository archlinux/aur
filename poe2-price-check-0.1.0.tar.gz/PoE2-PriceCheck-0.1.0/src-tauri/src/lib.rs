mod api;
mod clipboard;
mod config;
mod discovery;
mod state;
mod trade;

use tauri::Manager;

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            let app_handle = app.handle().clone();
            let config = config::load_config(&app_handle).unwrap_or_default();
            app.manage(state::AppState::new(config));
            clipboard::watch(app_handle);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            api::fetch_leagues,
            api::fetch_item_overview,
            api::fetch_watch_items,
            api::fetch_poe2_categories,
            api::fetch_image,
            trade::trade_search,
            config::get_config,
            config::save_config,
            config::has_session,
            config::set_session,
            config::get_favorites,
            config::save_favorites,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
