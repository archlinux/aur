#![allow(non_snake_case)]
use crate::discovery;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// poe.ninja's PoE2 economy API (new format, 2025+)
const POE_NINJA_POE2_BASE: &str = "https://poe.ninja/poe2/api/economy/exchange/current/overview";
// Uniques and tablets are not traded on the exchange; poe.ninja serves them from
// stash-tab scraping instead, with item metadata inline on each line.
const POE_NINJA_POE2_STASH: &str =
    "https://poe.ninja/poe2/api/economy/stash/current/item/overview";

// ──────────────────────────────────────────────
// New poe.ninja PoE2 API response structures
// ──────────────────────────────────────────────

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2Line {
    id: String,
    primaryValue: f64,
    volumePrimaryValue: Option<f64>,
    sparkline: Option<Poe2Sparkline>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2Sparkline {
    totalChange: f64,
    data: Vec<Option<f64>>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2ItemMeta {
    id: String,
    name: String,
    image: Option<String>,
    category: Option<String>,
    detailsId: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2Core {
    primary: String,
    secondary: String,
    rates: HashMap<String, f64>,
    items: Vec<Poe2ItemMeta>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2OverviewResponse {
    core: Poe2Core,
    lines: Vec<Poe2Line>,
    items: Vec<Poe2ItemMeta>,
}

/// Stash-API line. Unlike the exchange API, metadata lives on the line itself
/// rather than in a separate `items` array, and `id` is numeric.
#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2StashLine {
    id: i64,
    name: String,
    baseType: Option<String>,
    detailsId: Option<String>,
    icon: Option<String>,
    primaryValue: f64,
    listingCount: Option<i64>,
    corrupted: Option<bool>,
    levelRequired: Option<i64>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Poe2StashResponse {
    core: Poe2Core,
    lines: Vec<Poe2StashLine>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ItemLine {
    pub id: i64,
    pub name: String,
    pub icon: Option<String>,
    pub chaosValue: f64,
    pub divineValue: f64,
    pub count: i64,
    pub detailsId: String,
    pub variant: Option<String>,
    pub corrupted: Option<bool>,
    pub gemLevel: Option<i32>,
    pub gemQuality: Option<i32>,
    pub links: Option<i32>,
    pub mapTier: Option<i32>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ItemOverviewResponse {
    pub lines: Vec<ItemLine>,
    #[serde(rename = "chaosPerDivine")]
    pub chaos_per_divine: Option<f64>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Poe2CategoryInfo {
    #[serde(rename = "apiType")]
    pub api_type: String,
    pub slug: String,
    pub label: String,
}

// ──────────────────────────────────────────────
// HTTP client
// ──────────────────────────────────────────────

/// Named honestly, with a way to be reached: a service that can tell this app
/// apart from a browser can ask it to back off instead of banning the IP.
pub const UA: &str = "PoE2-PriceCheck/0.1 (contact: manelfernando864@gmail.com)";

/// Shared across every request: a fresh Client per call means a fresh connection
/// pool and a fresh TLS handshake, which the parallel category fetch multiplies.
fn build_client() -> reqwest::Client {
    static CLIENT: std::sync::OnceLock<reqwest::Client> = std::sync::OnceLock::new();
    CLIENT
        .get_or_init(|| {
            reqwest::Client::builder()
                .user_agent(UA)
                .timeout(std::time::Duration::from_secs(30))
                .build()
                .expect("failed to build HTTP client")
        })
        .clone()
}

fn absolute_icon(path: &str) -> String {
    if path.starts_with("http") {
        return path.to_string();
    }
    // poe.ninja returns relative paths like /gen/image/{b64}/{hash}/{name}.png
    // These are served from web.poecdn.com, not poe.ninja itself.
    format!("https://web.poecdn.com{}", path)
}

// ──────────────────────────────────────────────
// League discovery from poe.ninja sitemap + title tags
// ──────────────────────────────────────────────

fn parse_poe2_league_slugs(sitemap: &str) -> Vec<String> {
    // Extract unique PoE2 league slugs from sitemap URLs like /poe2/economy/{slug}/{category}
    // League slugs are all lowercase alpha (no hyphens), e.g. "standard", "runesofaldur"
    // Category slugs have hyphens, e.g. "unique-weapons" — we exclude those
    let prefix = "/poe2/economy/";
    let mut seen = std::collections::HashSet::new();
    let mut slugs: Vec<String> = Vec::new();
    let mut search = sitemap;

    while let Some(idx) = search.find(prefix) {
        search = &search[idx + prefix.len()..];
        let end = search.find(|c: char| c == '/' || c == '<').unwrap_or(search.len());
        let slug = &search[..end];
        if !slug.is_empty()
            && slug.chars().all(|c| c.is_ascii_lowercase())  // alpha only = league slug
            && seen.insert(slug.to_string())
        {
            slugs.push(slug.to_string());
        }
    }
    eprintln!("[parse_poe2_league_slugs] found slugs: {:?}", slugs);
    slugs
}

fn extract_league_name_from_title(html: &str) -> Option<String> {
    // Title format: "{Category} - {LeagueName} - Path of Exile 2 - poe.ninja"
    let start = html.find("<title>")? + 7;
    let end = html.find("</title>")?;
    let title = &html[start..end];
    let parts: Vec<&str> = title.splitn(4, " - ").collect();
    if parts.len() >= 2 {
        Some(parts[1].trim().to_string())
    } else {
        None
    }
}

// ──────────────────────────────────────────────
// Tauri commands
// ──────────────────────────────────────────────

/// Falls back to the last successful discovery. Scraping is the fragile part of
/// this app; a remembered league list is stale at worst, and only after a league
/// actually rotates.
fn cached_leagues_or(app: &tauri::AppHandle, why: String) -> Result<serde_json::Value, String> {
    match discovery::get(app).leagues {
        Some(cached) => {
            eprintln!("[fetch_leagues] {} — falling back to cached leagues", why);
            Ok(cached)
        }
        None => Err(why),
    }
}

#[tauri::command]
pub async fn fetch_leagues(app: tauri::AppHandle) -> Result<serde_json::Value, String> {
    let client = build_client();

    // Step 1: parse PoE2 league slugs from sitemap
    eprintln!("[fetch_leagues] fetching sitemap.xml");
    let sitemap = match client.get("https://poe.ninja/sitemap.xml").send().await {
        Ok(resp) => match resp.text().await {
            Ok(text) => text,
            Err(e) => return cached_leagues_or(&app, e.to_string()),
        },
        Err(e) => return cached_leagues_or(&app, e.to_string()),
    };

    let slugs = parse_poe2_league_slugs(&sitemap);
    if slugs.is_empty() {
        return cached_leagues_or(&app, "No PoE2 league slugs found in sitemap.xml".to_string());
    }

    // Step 2: for each slug, fetch the economy/currency page and extract display
    // name from <title>. These run concurrently — one full HTML page per league
    // in series is the slowest thing between launch and the first render.
    let mut tasks = tokio::task::JoinSet::new();
    for (idx, slug) in slugs.iter().enumerate() {
        let client = client.clone();
        let slug = slug.clone();
        tasks.spawn(async move {
            let url = format!("https://poe.ninja/poe2/economy/{}/currency", slug);
            eprintln!("[fetch_leagues] fetching {}", url);
            let html = match client.get(&url).send().await {
                Ok(resp) if resp.status().is_success() => resp.text().await.unwrap_or_default(),
                Ok(resp) => {
                    eprintln!("[fetch_leagues] HTTP {} for {}", resp.status(), url);
                    return (idx, None);
                }
                Err(e) => {
                    eprintln!("[fetch_leagues] request failed for {}: {}", slug, e);
                    return (idx, None);
                }
            };
            match extract_league_name_from_title(&html) {
                Some(name) => {
                    eprintln!("[fetch_leagues] slug={} → \"{}\"", slug, name);
                    (idx, Some(name))
                }
                None => {
                    eprintln!("[fetch_leagues] could not extract title for slug={}", slug);
                    (idx, None)
                }
            }
        });
    }

    // Completion order is arbitrary; sitemap order decides which temp league is
    // picked as the default, so restore it before building the list.
    let mut named: Vec<(usize, String)> = Vec::new();
    while let Some(joined) = tasks.join_next().await {
        match joined {
            Ok((idx, Some(name))) => named.push((idx, name)),
            Ok((_, None)) => {}
            Err(e) => eprintln!("[fetch_leagues] task panicked: {}", e),
        }
    }
    named.sort_by_key(|(idx, _)| *idx);

    let leagues: Vec<serde_json::Value> = named
        .into_iter()
        .map(|(_, display_name)| {
            let dn_lower = display_name.to_lowercase();
            let is_hardcore = dn_lower.contains("hardcore") || dn_lower.starts_with("hc ");
            let is_standard = dn_lower == "standard" || dn_lower == "hardcore";
            serde_json::json!({
                "id": display_name,
                "realm": "poe2",
                "isHardcore": is_hardcore,
                "isStandard": is_standard,
                "displayName": display_name,
            })
        })
        .collect();

    if leagues.is_empty() {
        return cached_leagues_or(
            &app,
            "Could not resolve any PoE2 league display names from poe.ninja".to_string(),
        );
    }

    // Step 3: group HC variants by their SC counterpart, then return only SC leagues with hcId
    // HC naming conventions:
    //   "Hardcore" is the HC variant of "Standard"
    //   "HC {Name}" is the HC variant of "{Name}"
    let mut hc_map: std::collections::HashMap<String, String> = std::collections::HashMap::new();
    let mut sc_leagues: Vec<serde_json::Value> = Vec::new();

    for l in &leagues {
        let name = l["id"].as_str().unwrap_or("").to_string();
        let is_hc = l["isHardcore"].as_bool().unwrap_or(false);
        if is_hc {
            let sc_key = if name.to_lowercase() == "hardcore" {
                "Standard".to_string()
            } else if name.starts_with("HC ") {
                name[3..].to_string()
            } else {
                continue; // Unknown HC naming — skip
            };
            hc_map.insert(sc_key, name);
        } else {
            sc_leagues.push(l.clone());
        }
    }

    // Sort SC leagues: temp leagues first, Standard last
    sc_leagues.sort_by_key(|l| {
        if l["isStandard"].as_bool().unwrap_or(false) { 1 } else { 0 }
    });

    // Attach hcId to each SC league
    let result: Vec<serde_json::Value> = sc_leagues.into_iter().map(|mut l| {
        let name = l["id"].as_str().unwrap_or("").to_string();
        if let Some(hc_name) = hc_map.get(&name) {
            l["hcId"] = serde_json::Value::String(hc_name.clone());
        }
        l
    }).collect();

    eprintln!("[fetch_leagues] returning {} SC leagues: {:?}", result.len(),
        result.iter().map(|l| l["id"].as_str().unwrap_or("")).collect::<Vec<_>>());

    let value = serde_json::Value::Array(result);
    discovery::update(&app, |d| d.leagues = Some(value.clone()));
    Ok(value)
}

#[tauri::command]
pub async fn fetch_item_overview(
    app: tauri::AppHandle,
    league: String,
    category: String,
) -> Result<ItemOverviewResponse, String> {
    let client = build_client();
    let route_key = format!("{}|{}", league, category);

    // Known stash category: go straight there.
    if discovery::get(&app).stash_routes.contains(&route_key) {
        match fetch_stash_overview(&client, &league, &category).await {
            Ok(stash) if !stash.lines.is_empty() => return Ok(stash),
            // A well-formed empty answer means the category moved: forget the
            // route and probe the exchange again below.
            Ok(_) => {
                eprintln!("[fetch_item_overview] cached stash route empty for {}/{} — re-probing", league, category);
                discovery::update(&app, |d| {
                    d.stash_routes.remove(&route_key);
                });
            }
            // A transport error says nothing about which API serves this
            // category. Forgetting the route on every network blip throws away
            // knowledge that took a wasted request to learn.
            Err(e) => {
                eprintln!("[fetch_item_overview] cached stash route errored for {}/{}: {} — keeping route", league, category, e);
                return Err(e);
            }
        }
    }

    let url = format!("{}?league={}&type={}", POE_NINJA_POE2_BASE, urlencoding(&league), urlencoding(&category));
    eprintln!("[fetch_item_overview] GET {} (PoE2 item categories via exchange API)", url);

    let resp = client.get(&url).send().await.map_err(|e| e.to_string())?;
    let status = resp.status();
    if !status.is_success() {
        return Err(format!("HTTP {} for {}", status, url));
    }

    let body = resp.text().await.map_err(|e| e.to_string())?;
    let parsed: Poe2OverviewResponse = serde_json::from_str(&body)
        .map_err(|e| {
            eprintln!("[fetch_item_overview] PARSE ERROR {}/{}: {} — body[:300]: {:.300}", league, category, e, body);
            format!("parse error: {}", e)
        })?;

    let n = parsed.lines.len();
    if n == 0 {
        eprintln!("[fetch_item_overview] HTTP {} — 0 lines for {}/{} — trying stash API", status, league, category);
        match fetch_stash_overview(&client, &league, &category).await {
            Ok(stash) if !stash.lines.is_empty() => {
                discovery::update(&app, |d| {
                    d.stash_routes.insert(route_key);
                });
                return Ok(stash);
            }
            Ok(_) => eprintln!("[fetch_item_overview] stash API also empty for {}/{}", league, category),
            Err(e) => eprintln!("[fetch_item_overview] stash API failed for {}/{}: {}", league, category, e),
        }
    } else {
        eprintln!("[fetch_item_overview] HTTP {} — {} lines for {}/{}", status, n, league, category);
    }

    let meta_map: HashMap<String, &Poe2ItemMeta> =
        parsed.items.iter().map(|m| (m.id.clone(), m)).collect();
    // Defaulting to 1.0 would make chaosValue equal divineValue and render a
    // table of plausible-looking wrong numbers. Fail instead — the frontend
    // keeps the previous good data for this category.
    let chaos_per_divine = parsed.core.rates.get("chaos").copied().ok_or_else(|| {
        format!("no chaos rate in response for {}/{}", league, category)
    })?;

    let lines: Vec<ItemLine> = parsed.lines.iter().enumerate().map(|(idx, line)| {
        let meta = meta_map.get(&line.id);
        ItemLine {
            id: idx as i64,
            name: meta.map(|m| m.name.as_str()).unwrap_or(&line.id).to_string(),
            icon: meta.and_then(|m| m.image.as_deref()).map(absolute_icon),
            chaosValue: line.primaryValue * chaos_per_divine,
            divineValue: line.primaryValue,
            count: 0,
            detailsId: meta.and_then(|m| m.detailsId.as_deref()).unwrap_or(&line.id).to_string(),
            variant: None,
            corrupted: None,
            gemLevel: None,
            gemQuality: None,
            links: None,
            mapTier: None,
        }
    }).collect();

    Ok(ItemOverviewResponse { lines, chaos_per_divine: Some(chaos_per_divine) })
}

/// Same league name the exchange API takes — league discovery stays dynamic.
async fn fetch_stash_overview(
    client: &reqwest::Client,
    league: &str,
    category: &str,
) -> Result<ItemOverviewResponse, String> {
    let url = format!(
        "{}?league={}&type={}",
        POE_NINJA_POE2_STASH,
        urlencoding(league),
        urlencoding(category)
    );
    eprintln!("[fetch_stash_overview] GET {}", url);

    let resp = client.get(&url).send().await.map_err(|e| e.to_string())?;
    let status = resp.status();
    if !status.is_success() {
        return Err(format!("HTTP {}", status));
    }

    let body = resp.text().await.map_err(|e| e.to_string())?;
    let parsed: Poe2StashResponse = serde_json::from_str(&body).map_err(|e| {
        eprintln!("[fetch_stash_overview] PARSE ERROR {}/{}: {} — body[:300]: {:.300}", league, category, e, body);
        format!("parse error: {}", e)
    })?;

    // Same rate convention as the exchange API: primaryValue is in divine.
    let chaos_per_divine = parsed.core.rates.get("chaos").copied().ok_or_else(|| {
        format!("no chaos rate in stash response for {}/{}", league, category)
    })?;
    eprintln!("[fetch_stash_overview] {} lines for {}/{}", parsed.lines.len(), league, category);

    let lines: Vec<ItemLine> = parsed
        .lines
        .iter()
        .map(|line| ItemLine {
            id: line.id,
            name: line.name.clone(),
            icon: line.icon.as_deref().map(absolute_icon),
            chaosValue: line.primaryValue * chaos_per_divine,
            divineValue: line.primaryValue,
            count: line.listingCount.unwrap_or(0),
            detailsId: line
                .detailsId
                .clone()
                .unwrap_or_else(|| line.name.clone()),
            // baseType distinguishes the several bases a unique can drop on
            variant: line.baseType.clone(),
            corrupted: line.corrupted,
            gemLevel: None,
            gemQuality: None,
            links: None,
            mapTier: None,
        })
        .collect();

    Ok(ItemOverviewResponse { lines, chaos_per_divine: Some(chaos_per_divine) })
}

// ──────────────────────────────────────────────
// poe.watch fallback
// ──────────────────────────────────────────────

#[derive(Debug, Deserialize)]
struct PoeWatchItem {
    id: u64,
    name: String,
    icon: Option<String>,
    mean: f64,
    divine: f64,
    daily: i64,
    #[serde(rename = "lowConfidence", default)]
    low_confidence: bool,
}

#[tauri::command]
pub async fn fetch_watch_items(league: String, watch_category: String) -> Result<ItemOverviewResponse, String> {
    let client = build_client();
    let url = format!(
        "https://api.poe.watch/get?category={}&league={}",
        urlencoding(&watch_category),
        urlencoding(&league)
    );
    eprintln!("[fetch_watch_items] GET {}", url);

    let resp = client.get(&url).send().await.map_err(|e| e.to_string())?;
    let status = resp.status();
    if !status.is_success() {
        return Err(format!("HTTP {} for {}", status, url));
    }

    let body = resp.text().await.map_err(|e| e.to_string())?;
    let watch_items: Vec<PoeWatchItem> = serde_json::from_str(&body)
        .map_err(|e| format!("poe.watch parse error: {} — preview: {:.200}", e, body))?;

    eprintln!("[fetch_watch_items] {} items for {}/{}", watch_items.len(), league, watch_category);

    let lines: Vec<ItemLine> = watch_items
        .into_iter()
        .filter(|i| !i.low_confidence)
        .enumerate()
        .map(|(idx, item)| ItemLine {
            id: idx as i64,
            name: item.name,
            icon: item.icon,
            chaosValue: item.mean,
            divineValue: item.divine,
            count: item.daily,
            detailsId: item.id.to_string(),
            variant: None,
            corrupted: None,
            gemLevel: None,
            gemQuality: None,
            links: None,
            mapTier: None,
        })
        .collect();

    Ok(ItemOverviewResponse { lines, chaos_per_divine: None })
}

// ──────────────────────────────────────────────
// Category discovery from poe.ninja sitemap
// ──────────────────────────────────────────────

fn slug_to_api_type(slug: &str) -> String {
    // poe.ninja uses non-obvious type strings for some slugs
    match slug {
        "abyssal-bones"   => return "Abyss".to_string(),
        "breach-catalyst" => return "Breach".to_string(),
        "liquid-emotions" => return "Delirium".to_string(),
        "omens"           => return "Ritual".to_string(),
        "unique-relics"   => return "UniqueSanctumRelics".to_string(),
        _ => {}
    }
    slug.split('-')
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => c.to_uppercase().to_string() + chars.as_str(),
            }
        })
        .collect()
}

fn slug_to_label(slug: &str) -> String {
    slug.split('-')
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                None => String::new(),
                Some(c) => c.to_uppercase().to_string() + chars.as_str(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

fn parse_poe2_slugs_from_sitemap(xml: &str) -> Vec<String> {
    let prefix = "/poe2/economy/";
    let mut seen = std::collections::HashSet::new();
    let mut slugs: Vec<String> = Vec::new();
    let mut search = xml;

    while let Some(idx) = search.find(prefix) {
        search = &search[idx + prefix.len()..];
        // skip league segment (up to next '/')
        if let Some(slash) = search.find('/') {
            let after_league = &search[slash + 1..];
            // extract slug up to next '/' or '<'
            let end = after_league
                .find(|c: char| c == '/' || c == '<')
                .unwrap_or(after_league.len());
            let slug = &after_league[..end];
            if !slug.is_empty()
                && slug.chars().all(|c| c.is_ascii_alphabetic() || c == '-')
                && seen.insert(slug.to_string())
            {
                slugs.push(slug.to_string());
            }
        }
    }
    slugs
}

fn cached_categories_or(
    app: &tauri::AppHandle,
    why: String,
) -> Result<Vec<Poe2CategoryInfo>, String> {
    let cached = discovery::get(app).categories;
    if cached.is_empty() {
        // Returning an empty list here used to leave the app with an empty
        // sidebar, no requests and no error — a silent failure. Say it instead.
        Err(why)
    } else {
        eprintln!("[fetch_poe2_categories] {} — falling back to {} cached categories", why, cached.len());
        Ok(cached)
    }
}

#[tauri::command]
pub async fn fetch_poe2_categories(
    app: tauri::AppHandle,
) -> Result<Vec<Poe2CategoryInfo>, String> {
    let client = build_client();
    let url = "https://poe.ninja/sitemap.xml";
    eprintln!("[fetch_poe2_categories] GET {}", url);

    let resp = match client.get(url).send().await {
        Ok(r) if r.status().is_success() => r,
        Ok(r) => return cached_categories_or(&app, format!("HTTP {} fetching sitemap", r.status())),
        Err(e) => return cached_categories_or(&app, e.to_string()),
    };

    let body = match resp.text().await {
        Ok(b) => b,
        Err(e) => return cached_categories_or(&app, e.to_string()),
    };

    let slugs = parse_poe2_slugs_from_sitemap(&body);
    eprintln!("[fetch_poe2_categories] {} unique slugs", slugs.len());
    if slugs.is_empty() {
        return cached_categories_or(&app, "no PoE2 category slugs in sitemap.xml".to_string());
    }

    let categories: Vec<Poe2CategoryInfo> = slugs
        .into_iter()
        .map(|slug| Poe2CategoryInfo {
            api_type: slug_to_api_type(&slug),
            label: slug_to_label(&slug),
            slug,
        })
        .collect();

    discovery::update(&app, |d| d.categories = categories.clone());
    Ok(categories)
}

#[tauri::command]
pub async fn fetch_image(url: String) -> Result<String, String> {
    use base64::{Engine as _, engine::general_purpose::STANDARD};
    let client = build_client();
    let resp = client
        .get(&url)
        .header("Referer", "https://poe.ninja/")
        .send()
        .await
        .map_err(|e| e.to_string())?;

    if !resp.status().is_success() {
        return Err(format!("HTTP {}", resp.status()));
    }

    let content_type = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("image/png")
        .to_string();

    let bytes = resp.bytes().await.map_err(|e| e.to_string())?;
    let b64 = STANDARD.encode(&bytes);
    Ok(format!("data:{};base64,{}", content_type, b64))
}

/// Percent-encodes UTF-8 bytes, not code points. Encoding the code point gives
/// the wrong escape for anything outside ASCII (ö → %F6 instead of %C3%B6) and
/// emits more than two hex digits above U+00FF.
fn urlencoding(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for &b in s.as_bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{:02X}", b)),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn urlencoding_encodes_utf8_bytes() {
        assert_eq!(urlencoding("Runes of Aldur"), "Runes%20of%20Aldur");
        assert_eq!(urlencoding("Mjolner-2.0_x~y"), "Mjolner-2.0_x~y");
        // ö is two bytes in UTF-8; encoding the code point would give %F6
        assert_eq!(urlencoding("Mjölner"), "Mj%C3%B6lner");
        // outside the BMP: four bytes, four escapes
        assert_eq!(urlencoding("😀"), "%F0%9F%98%80");
    }
}
