use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use tauri::{AppHandle, Manager};
use crate::state::AppState;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub preferred_league: String,
    pub difficulty: String,
    pub refresh_interval_minutes: u64,
    pub window_width: u32,
    pub window_height: u32,
    pub theme: String,
    /// Optional trade session cookie. Entirely opt-in: without it the app
    /// searches anonymously, which is why it must never be required anywhere.
    /// Never handed to the webview — see `get_config`.
    #[serde(default)]
    pub poesessid: Option<String>,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            preferred_league: "latest".to_string(),
            difficulty: "softcore".to_string(),
            refresh_interval_minutes: 5,
            window_width: 1280,
            window_height: 800,
            theme: "dark".to_string(),
            poesessid: None,
        }
    }
}

fn config_path(app: &AppHandle) -> PathBuf {
    app.path()
        .app_config_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("config.toml")
}

fn favorites_path(app: &AppHandle) -> PathBuf {
    app.path()
        .app_config_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("favorites.json")
}

pub fn load_config(app: &AppHandle) -> Option<AppConfig> {
    let path = config_path(app);
    let content = std::fs::read_to_string(path).ok()?;
    toml::from_str(&content).ok()
}

fn write_config(app: &AppHandle, config: &AppConfig) -> Result<(), String> {
    let path = config_path(app);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let content = toml::to_string_pretty(config).map_err(|e| e.to_string())?;
    std::fs::write(&path, content).map_err(|e| e.to_string())
}

/// The session cookie is stripped: a credential has no business in the webview,
/// and nothing there needs it — the Rust side attaches it to trade requests.
#[tauri::command]
pub fn get_config(state: tauri::State<AppState>) -> AppConfig {
    AppConfig { poesessid: None, ..state.config.lock().unwrap().clone() }
}

#[tauri::command]
pub fn save_config(app: AppHandle, state: tauri::State<AppState>, config: AppConfig) -> Result<(), String> {
    let mut guard = state.config.lock().unwrap();
    // the frontend never receives the cookie, so it cannot send it back either
    let merged = AppConfig { poesessid: guard.poesessid.clone(), ..config };
    write_config(&app, &merged)?;
    *guard = merged;
    Ok(())
}

/// True when a session cookie is stored — all the UI is allowed to know.
#[tauri::command]
pub fn has_session(state: tauri::State<AppState>) -> bool {
    state.config.lock().unwrap().poesessid.is_some()
}

/// Stores or (with an empty string) clears the session cookie.
#[tauri::command]
pub fn set_session(
    app: AppHandle,
    state: tauri::State<AppState>,
    poesessid: String,
) -> Result<bool, String> {
    let value = poesessid.trim();
    let mut guard = state.config.lock().unwrap();
    guard.poesessid = (!value.is_empty()).then(|| value.to_string());
    let stored = guard.poesessid.is_some();
    write_config(&app, &guard)?;
    Ok(stored)
}

#[tauri::command]
pub fn get_favorites(app: AppHandle) -> Vec<String> {
    let path = favorites_path(&app);
    let content = std::fs::read_to_string(path).unwrap_or_else(|_| "[]".to_string());
    serde_json::from_str(&content).unwrap_or_default()
}

#[tauri::command]
pub fn save_favorites(app: AppHandle, favorites: Vec<String>) -> Result<(), String> {
    let path = favorites_path(&app);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let content = serde_json::to_string_pretty(&favorites).map_err(|e| e.to_string())?;
    std::fs::write(&path, content).map_err(|e| e.to_string())?;
    Ok(())
}
