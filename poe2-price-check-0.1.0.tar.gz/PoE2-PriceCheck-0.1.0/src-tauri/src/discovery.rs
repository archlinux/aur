//! What we last learned from poe.ninja, kept on disk.
//!
//! Leagues, categories and API routes are all discovered by scraping, which is
//! the most fragile coupling in the app: a sitemap or <title> change silently
//! yields nothing. Remembering the last successful discovery means a launch
//! survives that — and skips re-downloading a 386 KB sitemap twice to relearn
//! facts that change once a league.
//!
//! Nothing here is hardcoded: every value was learned from poe.ninja.

use crate::api::Poe2CategoryInfo;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};
use tauri::{AppHandle, Manager};

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct Discovery {
    /// Exactly what fetch_leagues returns, so it can be replayed verbatim.
    #[serde(default)]
    pub leagues: Option<serde_json::Value>,
    #[serde(default)]
    pub categories: Vec<Poe2CategoryInfo>,
    /// "league|category" pairs the stash API serves rather than the exchange.
    #[serde(default)]
    pub stash_routes: HashSet<String>,
}

fn path(app: &AppHandle) -> PathBuf {
    app.path()
        .app_config_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("discovery.json")
}

/// In-memory copy, read from disk once. Also the lock serialising the
/// read-modify-write, since three commands can be updating it concurrently.
fn cell() -> &'static Mutex<Option<Discovery>> {
    static CELL: OnceLock<Mutex<Option<Discovery>>> = OnceLock::new();
    CELL.get_or_init(|| Mutex::new(None))
}

fn load_from_disk(app: &AppHandle) -> Discovery {
    let p = path(app);
    match std::fs::read_to_string(&p) {
        Ok(text) => match serde_json::from_str::<Discovery>(&text) {
            Ok(d) => {
                eprintln!(
                    "[discovery] loaded {} categories, {} stash routes, leagues: {}",
                    d.categories.len(),
                    d.stash_routes.len(),
                    d.leagues.is_some()
                );
                d
            }
            // A corrupt file is not worth failing over: discovery will refill it.
            Err(e) => {
                eprintln!("[discovery] ignoring unreadable cache: {}", e);
                Discovery::default()
            }
        },
        Err(_) => Discovery::default(),
    }
}

pub fn get(app: &AppHandle) -> Discovery {
    let mut guard = cell().lock().unwrap();
    guard.get_or_insert_with(|| load_from_disk(app)).clone()
}

/// Applies a change and writes it through. A failed write is logged, not
/// propagated — losing the cache degrades startup, it does not break anything.
pub fn update(app: &AppHandle, f: impl FnOnce(&mut Discovery)) {
    let mut guard = cell().lock().unwrap();
    let current = guard.get_or_insert_with(|| load_from_disk(app));
    f(current);

    let p = path(app);
    if let Some(dir) = p.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    match serde_json::to_string_pretty(current) {
        Ok(text) => {
            if let Err(e) = std::fs::write(&p, text) {
                eprintln!("[discovery] could not write {}: {}", p.display(), e);
            }
        }
        Err(e) => eprintln!("[discovery] could not serialise: {}", e),
    }
}
