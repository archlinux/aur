//! GGG trade2 API: stat matching, query building, search + fetch, rate budget.
//!
//! Everything verified against the live endpoint on 2026-08-01: league ids
//! equal poe.ninja display names, filter keys (rarity, crit, aps, ilvl,
//! corrupted, fractured_item) accepted, limits arrive in x-rate-limit-ip.
//!
//! The rate limits decide the design (30 searches / 5 min, overrun = 30 min
//! ban, per IP): one search per user click, never automatic.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use tauri::Manager;

const TRADE_BASE: &str = "https://www.pathofexile.com/api/trade2";
// GGG ToS wants a UA identifying the app and a contact. poe.ninja gets the same one.
use crate::api::UA;

fn client() -> reqwest::Client {
    static CLIENT: OnceLock<reqwest::Client> = OnceLock::new();
    CLIENT
        .get_or_init(|| {
            reqwest::Client::builder()
                .user_agent(UA)
                .timeout(std::time::Duration::from_secs(30))
                .build()
                .expect("failed to build trade HTTP client")
        })
        .clone()
}

// ──────────────────────────────────────────────
// Stats index: (group, templated text) → stat id
// ──────────────────────────────────────────────

/// Numbers → '#' so item text and GGG's own placeholder text meet in the
/// middle. Applied to BOTH sides: GGG texts mix '#' with literal numbers
/// ("once every 0.5 seconds").
fn template(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut chars = text.chars().peekable();
    while let Some(c) = chars.next() {
        if c.is_ascii_digit() {
            while let Some(&n) = chars.peek() {
                if n.is_ascii_digit() || n == '.' {
                    chars.next();
                } else {
                    break;
                }
            }
            out.push('#');
        } else {
            out.push(c);
        }
    }
    out
}

/// Stat id plus whether it takes a value at all: GGG writes a placeholder for
/// the numbers you can filter on ("+# to maximum Life") and leaves fixed ones
/// inside the sentence ("…for 60 seconds"). Sending min/max for the latter
/// filters on a number the stat does not have, and matches nothing.
type Entry = (String, bool);

struct StatsIndex {
    by_key: HashMap<(String, String), Entry>,
}

impl StatsIndex {
    /// Case-sensitive on purpose: GGG's texts differ only by case in places
    /// ("Lightning damage to Attacks" vs "Lightning Damage") and merging them
    /// would return the wrong stat.
    /// `local_first`: on weapons/armour the item's own mods are the "(Local)"
    /// variant — same visible text, different stat id. The copied text never
    /// says "(Local)", so the item kind has to break the tie.
    ///
    /// Returns the entry plus whether the match required flipping the mod's
    /// direction, which the caller must mirror in its min/max.
    fn lookup(&self, groups: &[&str], text: &str, local_first: bool) -> Option<(Entry, bool)> {
        let t = template(text);
        // items print "+149% Surpassing…" where GGG's dump has "#% Surpassing…":
        // retry without the leading '+' before giving up
        let plain: Vec<String> = std::iter::once(t.clone())
            .chain(t.strip_prefix('+').map(str::to_string))
            .collect();

        // GGG indexes only one direction of a pair: "50% reduced Projectile
        // Range" is the negative side of "#% increased Projectile Range".
        let flipped: Vec<String> = plain
            .iter()
            .filter_map(|k| {
                for (from, to) in [("reduced", "increased"), ("increased", "reduced"),
                                   ("less", "more"), ("more", "less")] {
                    if k.contains(from) {
                        return Some(k.replacen(from, to, 1));
                    }
                }
                None
            })
            .collect();

        // (Local) first on gear, and a same-direction match always beats a
        // flipped one — flipping is the fallback, never the preference.
        let ordered: Vec<(String, bool)> = [(plain, false), (flipped, true)]
            .into_iter()
            .flat_map(|(keys, negated)| {
                keys.into_iter().flat_map(move |k| {
                    let local = local_first.then(|| (format!("{} (Local)", k), negated));
                    local.into_iter().chain(std::iter::once((k, negated)))
                })
            })
            .collect();

        for g in groups {
            for (key, negated) in &ordered {
                if let Some(entry) = self.by_key.get(&(g.to_string(), key.clone())) {
                    return Some((entry.clone(), *negated));
                }
            }
        }
        None
    }
}

fn stats_cell() -> &'static Mutex<Option<std::sync::Arc<StatsIndex>>> {
    static CELL: OnceLock<Mutex<Option<std::sync::Arc<StatsIndex>>>> = OnceLock::new();
    CELL.get_or_init(|| Mutex::new(None))
}

fn stats_cache_path(app: &tauri::AppHandle) -> std::path::PathBuf {
    app.path()
        .app_config_dir()
        .unwrap_or_else(|_| std::path::PathBuf::from("."))
        .join("trade_stats.json")
}

fn build_index(dump: &serde_json::Value) -> StatsIndex {
    let mut by_key = HashMap::new();
    let groups = dump["result"].as_array().cloned().unwrap_or_default();
    for group in &groups {
        // group id is already lowercase ("explicit", "rune"…)
        let gid = group["id"].as_str().unwrap_or("").to_string();
        for entry in group["entries"].as_array().cloned().unwrap_or_default() {
            let (Some(id), Some(text)) = (entry["id"].as_str(), entry["text"].as_str()) else {
                continue;
            };
            let takes_value = text.contains('#');
            let t = template(text);
            by_key
                .entry((gid.clone(), t))
                .or_insert_with(|| (id.to_string(), takes_value));
            // ~100 entries hold a literal newline; a copied item shows them as
            // separate lines. Index each line too so either shape matches;
            // joined form was inserted first and wins on collision.
            if text.contains('\n') {
                for line in text.split('\n') {
                    by_key
                        .entry((gid.clone(), template(line)))
                        .or_insert_with(|| (id.to_string(), takes_value));
                }
            }
        }
    }
    eprintln!("[trade] stats index: {} keys", by_key.len());
    StatsIndex { by_key }
}

async fn stats_index(app: &tauri::AppHandle) -> Result<std::sync::Arc<StatsIndex>, String> {
    if let Some(idx) = stats_cell().lock().unwrap().clone() {
        return Ok(idx);
    }
    // ~850 KB, changes with game patches: network first, disk as fallback.
    let url = format!("{}/data/stats", TRADE_BASE);
    let dump: serde_json::Value = match client().get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            let text = resp.text().await.map_err(|e| e.to_string())?;
            let v: serde_json::Value =
                serde_json::from_str(&text).map_err(|e| format!("stats parse: {}", e))?;
            let _ = std::fs::write(stats_cache_path(app), &text);
            v
        }
        other => {
            let why = match other {
                Ok(r) => format!("HTTP {}", r.status()),
                Err(e) => e.to_string(),
            };
            eprintln!("[trade] data/stats failed ({}) — trying disk cache", why);
            let text = std::fs::read_to_string(stats_cache_path(app))
                .map_err(|_| format!("data/stats unreachable ({}) and no disk cache", why))?;
            serde_json::from_str(&text).map_err(|e| format!("stats cache parse: {}", e))?
        }
    };
    let idx = std::sync::Arc::new(build_index(&dump));
    *stats_cell().lock().unwrap() = Some(idx.clone());
    Ok(idx)
}

// ──────────────────────────────────────────────
// Rate budget from response headers
// ──────────────────────────────────────────────

#[derive(Debug, Clone, Serialize)]
pub struct SearchBudget {
    pub remaining: u32,
    pub total: u32,
    #[serde(rename = "windowSecs")]
    pub window_secs: u32,
}

/// "5:10:60,15:60:300,30:300:1800" (limits) + "1:10:0,…" (state) → the tier
/// with the fewest requests left. Read from headers, never hardcoded.
pub(crate) fn parse_budget(limits: &str, state: &str) -> Option<SearchBudget> {
    let parse = |s: &str| -> Vec<(u32, u32)> {
        s.split(',')
            .filter_map(|t| {
                let mut it = t.trim().split(':');
                Some((it.next()?.parse().ok()?, it.next()?.parse().ok()?))
            })
            .collect()
    };
    let lims = parse(limits);
    let states = parse(state);
    lims.iter()
        .zip(states.iter())
        .map(|(&(total, window), &(used, _))| SearchBudget {
            remaining: total.saturating_sub(used),
            total,
            window_secs: window,
        })
        .min_by_key(|b| b.remaining)
}

/// Anonymous requests are limited per IP; with a session cookie GGG also
/// meters the account, in its own bucket. Whichever is tighter is the truth.
fn budget_from(resp: &reqwest::Response) -> Option<SearchBudget> {
    let h = |name: &str| resp.headers().get(name)?.to_str().ok().map(str::to_string);
    let of = |kind: &str| {
        parse_budget(
            &h(&format!("x-rate-limit-{}", kind))?,
            &h(&format!("x-rate-limit-{}-state", kind))?,
        )
    };
    [of("ip"), of("account")]
        .into_iter()
        .flatten()
        .min_by_key(|b| b.remaining)
}

/// Seconds until searching makes sense again: the active penalty (third field
/// of each state tier), or Retry-After on a 429 — whichever is larger.
fn retry_secs(resp: &reqwest::Response) -> u32 {
    let state_max = ["x-rate-limit-ip-state", "x-rate-limit-account-state"]
        .iter()
        .filter_map(|name| resp.headers().get(*name)?.to_str().ok())
        .flat_map(|s| {
            s.split(',')
                .filter_map(|t| t.trim().split(':').nth(2)?.parse::<u32>().ok())
                .collect::<Vec<_>>()
        })
        .max()
        .unwrap_or(0);
    let retry_after = resp
        .headers()
        .get("retry-after")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.parse::<u32>().ok())
        .unwrap_or(0);
    state_max.max(retry_after)
}

/// Attaches the session cookie when the user provided one. Anonymous stays a
/// first-class path: no session means no header, not a degraded mode.
fn with_session(req: reqwest::RequestBuilder, session: &Option<String>) -> reqwest::RequestBuilder {
    match session {
        Some(id) => req.header("Cookie", format!("POESESSID={}", id)),
        None => req,
    }
}

// ──────────────────────────────────────────────
// Search
// ──────────────────────────────────────────────

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PayloadStat {
    pub text: String,
    /// "rune" | "enchant" | "implicit" | "unique"; absent = explicit chain
    pub kind: Option<String>,
    pub min: Option<f64>,
    pub max: Option<f64>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SearchPayload {
    pub league: String,
    pub rarity: Option<String>,
    /// Unique items search by exact name + base; rares by base only when the
    /// user asks (searching bases is a first-class use case).
    pub name: Option<String>,
    pub base_type: Option<String>,
    pub corrupted: Option<bool>,
    pub fractured: Option<bool>,
    pub ilvl_min: Option<f64>,
    pub quality_min: Option<f64>,
    pub sockets_min: Option<f64>,
    /// (label from the item text, min) — mapped to equipment_filters
    pub base_stats: Vec<(String, f64)>,
    /// the item's Attacks per Second — turns damage midpoints into DPS filters
    pub aps: Option<f64>,
    /// "instant" | "online" | "any" → the query's status option
    pub seller: Option<String>,
    /// weapon/armour piece: its own mods are the "(Local)" stat variants
    #[serde(default)]
    pub local_mods: bool,
    pub stats: Vec<PayloadStat>,
}

#[derive(Debug, Serialize)]
pub struct SearchResponse {
    pub results: Vec<serde_json::Value>,
    pub budget: Option<SearchBudget>,
    /// stat texts that matched no trade2 id — searched without them
    pub unmatched: Vec<String>,
    pub total: u64,
    /// seconds until the next search is allowed; None = free to search
    #[serde(rename = "retryAfterSecs")]
    pub retry_after_secs: Option<u32>,
}

fn group_chain(kind: Option<&str>) -> &'static [&'static str] {
    match kind {
        Some("rune") => &["rune"],
        // an item's "{ Enhancement }" covers both corruption implicits and
        // anointments, and GGG files the latter under explicit
        Some("enchant") => &["enchant", "implicit", "explicit"],
        Some("implicit") => &["implicit", "explicit"],
        // unique mods live in the explicit group on the trade site
        _ => &["explicit", "desecrated", "fractured", "crafted", "implicit", "pseudo"],
    }
}

/// Base-stat labels → trade2 equipment_filters keys. The DPS rows arrive
/// already derived from the frontend, which is where they are displayed.
fn equipment_key(label: &str) -> Option<&'static str> {
    Some(match label {
        "Critical Hit Chance" => "crit",
        "Attacks per Second" => "aps",
        "DPS" => "dps",
        "Armour" => "ar",
        "Evasion Rating" => "ev",
        "Energy Shield" => "es",
        "Runic Ward" => "ward",
        "Spirit" => "spirit",
        "Block" => "block",
        _ => return None,
    })
}

/// DPS is damage × attacks-per-second, and the clipboard rounds that rate to
/// two decimals — the game itself divides by an attack *time* (a bow reading
/// 1.27/s is really 1/0.79 = 1.2658). The derived DPS can therefore sit up to
/// ~0.4% above the item's true value, and filtering on it verbatim would
/// exclude the very item that produced it. Give back the rounding error.
fn dps_margin(key: &str, min: f64) -> f64 {
    if matches!(key, "pdps" | "edps" | "dps") {
        (min * 0.995 * 100.0).round() / 100.0
    } else {
        min
    }
}

fn build_query(p: &SearchPayload, idx: &StatsIndex, unmatched: &mut Vec<String>) -> serde_json::Value {
    let mut stat_filters = Vec::new();
    for s in &p.stats {
        // runes/enchants/implicits are never the local variant
        let local = p.local_mods && s.kind.is_none();
        match idx.lookup(group_chain(s.kind.as_deref()), &s.text, local) {
            Some(((id, takes_value), negated)) => {
                // matched through the opposite wording: the bound becomes its
                // negative and swaps ends ("≥ 50 reduced" is "≤ -50 increased")
                let (min, max) = match (takes_value, negated) {
                    // the number is part of the sentence, not a filterable roll
                    (false, _) => (None, None),
                    (true, true) => (s.max.map(|v| -v), s.min.map(|v| -v)),
                    (true, false) => (s.min, s.max),
                };
                let mut value = serde_json::Map::new();
                if let Some(min) = min {
                    value.insert("min".into(), min.into());
                }
                if let Some(max) = max {
                    value.insert("max".into(), max.into());
                }
                stat_filters.push(serde_json::json!({ "id": id, "value": value }));
            }
            None => unmatched.push(s.text.clone()),
        }
    }

    let mut misc = serde_json::Map::new();
    if let Some(c) = p.corrupted {
        misc.insert("corrupted".into(), serde_json::json!({ "option": c.to_string() }));
    }
    if let Some(f) = p.fractured {
        misc.insert("fractured_item".into(), serde_json::json!({ "option": f.to_string() }));
    }


    let mut equipment = serde_json::Map::new();
    if let Some(v) = p.sockets_min {
        equipment.insert("rune_sockets".into(), serde_json::json!({ "min": v }));
    }
    // Per-element damage lines have no filter of their own — the site filters
    // DPS, so they convert with the item's attack rate.
    let mut phys_min: Option<f64> = None;
    let mut elem_min = 0.0f64;
    for (label, min) in &p.base_stats {
        match label.as_str() {
            "Physical Damage" => phys_min = Some(*min),
            "Lightning Damage" | "Cold Damage" | "Fire Damage" => elem_min += min,
            _ => match equipment_key(label) {
                Some(key) => {
                    equipment.insert(key.into(), serde_json::json!({ "min": dps_margin(key, *min) }));
                }
                None => unmatched.push(format!("{} (base)", label)),
            },
        }
    }
    match p.aps {
        Some(aps) => {
            if let Some(pm) = phys_min {
                equipment.insert("pdps".into(), serde_json::json!({ "min": dps_margin("pdps", pm * aps) }));
            }
            if elem_min > 0.0 {
                equipment.insert("edps".into(), serde_json::json!({ "min": dps_margin("edps", elem_min * aps) }));
            }
        }
        None => {
            if phys_min.is_some() {
                unmatched.push("Physical Damage (base, no APS)".into());
            }
            if elem_min > 0.0 {
                unmatched.push("Elemental Damage (base, no APS)".into());
            }
        }
    }

    // rarity, ilvl and quality all live under type_filters (data/filters)
    let mut type_f = serde_json::Map::new();
    if let Some(r) = &p.rarity {
        type_f.insert("rarity".into(), serde_json::json!({ "option": r }));
    }
    if let Some(v) = p.ilvl_min {
        type_f.insert("ilvl".into(), serde_json::json!({ "min": v }));
    }
    if let Some(v) = p.quality_min {
        type_f.insert("quality".into(), serde_json::json!({ "min": v }));
    }
    let mut filters = serde_json::Map::new();
    if !type_f.is_empty() {
        filters.insert("type_filters".into(), serde_json::json!({ "filters": type_f }));
    }
    if !misc.is_empty() {
        filters.insert("misc_filters".into(), serde_json::json!({ "filters": misc }));
    }
    if !equipment.is_empty() {
        filters.insert("equipment_filters".into(), serde_json::json!({ "filters": equipment }));
    }

    // "securable" is the instant-buyout status (data/filters, 2026-08-01;
    // sale_type has no instant option — the fee minmax lives here too)
    let status = match p.seller.as_deref() {
        Some("instant") => "securable",
        Some("any") => "any",
        _ => "online",
    };
    let mut query = serde_json::Map::new();
    query.insert("status".into(), serde_json::json!({ "option": status }));
    if let Some(name) = &p.name {
        query.insert("name".into(), serde_json::json!(name));
    }
    if let Some(base) = &p.base_type {
        query.insert("type".into(), serde_json::json!(base));
    }
    query.insert(
        "stats".into(),
        serde_json::json!([{ "type": "and", "filters": stat_filters }]),
    );
    query.insert("filters".into(), serde_json::Value::Object(filters));

    serde_json::json!({ "query": query, "sort": { "price": "asc" } })
}

#[tauri::command]
pub async fn trade_search(
    app: tauri::AppHandle,
    state: tauri::State<'_, crate::state::AppState>,
    payload: SearchPayload,
) -> Result<SearchResponse, String> {
    // copied out so the lock is not held across an await; None = anonymous,
    // which is the normal, fully supported way to use this app
    let session = state.config.lock().unwrap().poesessid.clone();
    let idx = stats_index(&app).await?;
    let mut unmatched = Vec::new();
    let query = build_query(&payload, &idx, &mut unmatched);

    let url = format!("{}/search/poe2/{}", TRADE_BASE, urlenc(&payload.league));
    eprintln!(
        "[trade_search] POST {} ({}) query={}",
        url,
        if session.is_some() { "with session" } else { "anonymous" },
        query
    );
    let resp = with_session(client().post(&url).json(&query), &session)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let budget = budget_from(&resp);
    let penalty = retry_secs(&resp);
    let status = resp.status();
    let body = resp.text().await.map_err(|e| e.to_string())?;
    if status.as_u16() == 429 {
        // rate limited: report when searching reopens, keep the panel's data
        return Ok(SearchResponse {
            results: Vec::new(),
            budget,
            unmatched,
            total: 0,
            retry_after_secs: Some(penalty.max(1)),
        });
    }
    if !status.is_success() {
        return Err(format!("trade search HTTP {}: {:.300}", status, body));
    }
    let parsed: serde_json::Value =
        serde_json::from_str(&body).map_err(|e| format!("search parse: {}", e))?;
    let search_id = parsed["id"].as_str().unwrap_or_default().to_string();
    let ids: Vec<String> = parsed["result"]
        .as_array()
        .map(|a| {
            a.iter()
                .filter_map(|v| v.as_str().map(str::to_string))
                .take(20)
                .collect()
        })
        .unwrap_or_default();
    let total = parsed["total"].as_u64().unwrap_or(ids.len() as u64);

    // fetch caps at 10 ids per call; its own limit (12:4:10) allows the 2 calls
    let mut results = Vec::new();
    let mut fetch_penalty = 0u32;
    for chunk in ids.chunks(10) {
        let url = format!("{}/fetch/{}?query={}", TRADE_BASE, chunk.join(","), search_id);
        let resp = with_session(client().get(&url), &session)
            .send()
            .await
            .map_err(|e| e.to_string())?;
        if resp.status().as_u16() == 429 {
            // the search DID match; saying "no listings" here would be a lie
            fetch_penalty = retry_secs(&resp).max(1);
            eprintln!("[trade_search] fetch rate limited, penalty {}s", fetch_penalty);
            break;
        }
        if !resp.status().is_success() {
            eprintln!("[trade_search] fetch HTTP {}", resp.status());
            break; // partial results beat an error after a successful search
        }
        let v: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
        if let Some(arr) = v["result"].as_array() {
            for r in arr {
                if r.is_null() {
                    continue;
                }
                results.push(serde_json::json!({
                    "listing": {
                        "indexed": r["listing"]["indexed"],
                        "price": r["listing"]["price"],
                        "account": {
                            "name": r["listing"]["account"]["name"],
                            "online": r["listing"]["account"]["online"],
                        },
                        "whisper": r["listing"]["whisper"],
                    },
                    "item": {
                        "name": r["item"]["name"],
                        "baseType": r["item"]["baseType"],
                        "ilvl": r["item"]["ilvl"],
                        "explicitMods": r["item"]["explicitMods"].as_array().cloned().unwrap_or_default(),
                    },
                }));
            }
        }
    }
    // only server-mandated penalties block the button; an exhausted window
    // is the server's problem to enforce — the user may always try
    let retry_after_secs = if penalty > 0 {
        Some(penalty)
    } else {
        (fetch_penalty > 0 && results.is_empty()).then_some(fetch_penalty)
    };
    eprintln!(
        "[trade_search] {} results of {} total, {} unmatched stat(s)",
        results.len(),
        total,
        unmatched.len()
    );
    Ok(SearchResponse { results, budget, unmatched, total, retry_after_secs })
}

fn urlenc(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for &b in s.as_bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char)
            }
            _ => out.push_str(&format!("%{:02X}", b)),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn template_replaces_numbers_with_hash() {
        assert_eq!(template("+47 to maximum Life"), "+# to maximum Life");
        assert_eq!(template("Adds 6 to 180 Lightning Damage"), "Adds # to # Lightning Damage");
        assert_eq!(template("+3.51% to Critical Hit Chance"), "+#% to Critical Hit Chance");
        // GGG's own '#' placeholders pass through unchanged
        assert_eq!(template("+#% to Fire Resistance"), "+#% to Fire Resistance");
    }

    #[test]
    fn budget_picks_tightest_tier() {
        let b = parse_budget("5:10:60,30:300:1800", "1:10:0,28:300:0").unwrap();
        assert_eq!(b.remaining, 2);
        assert_eq!(b.total, 30);
        assert_eq!(b.window_secs, 300);
    }

    #[test]
    fn build_query_reports_unmatched() {
        let idx = StatsIndex { by_key: HashMap::new() };
        let p = SearchPayload {
            league: "Standard".into(),
            rarity: Some("rare".into()),
            name: None,
            base_type: Some("Obliterator Bow".into()),
            corrupted: Some(true),
            fractured: Some(false),
            ilvl_min: Some(79.0),
            quality_min: None,
            sockets_min: None,
            base_stats: vec![("Critical Hit Chance".into(), 8.51), ("Physical Damage".into(), 391.5)],
            aps: Some(1.27),
            seller: Some("instant".into()),
            local_mods: true,
            stats: vec![PayloadStat { text: "+47 to maximum Life".into(), kind: None, min: Some(42.0), max: None }],
        };
        let mut unmatched = Vec::new();
        let q = build_query(&p, &idx, &mut unmatched);
        // empty index: only the stat is reported
        assert_eq!(unmatched, vec!["+47 to maximum Life"]);
        assert_eq!(q["query"]["type"], "Obliterator Bow");
        assert_eq!(q["query"]["filters"]["equipment_filters"]["filters"]["crit"]["min"], 8.51);
        // pdps gives back the APS rounding error; crit, a measured value, does not
        assert_eq!(q["query"]["filters"]["equipment_filters"]["filters"]["pdps"]["min"], 494.72);
        assert_eq!(q["query"]["filters"]["type_filters"]["filters"]["ilvl"]["min"], 79.0);
        assert_eq!(q["query"]["filters"]["misc_filters"]["filters"]["corrupted"]["option"], "true");
        assert_eq!(q["query"]["filters"]["misc_filters"]["filters"]["fractured_item"]["option"], "false");
        assert_eq!(q["query"]["status"]["option"], "securable");
    }

    #[test]
    fn lookup_retries_without_leading_plus() {
        let mut by_key = HashMap::new();
        by_key.insert(
            ("explicit".to_string(), "#% Surpassing chance to fire an additional Arrow".to_string()),
            ("explicit.stat_2463230181".to_string(), true),
        );
        let idx = StatsIndex { by_key };
        assert_eq!(
            idx.lookup(&["explicit"], "+149% Surpassing chance to fire an additional Arrow", false),
            Some((("explicit.stat_2463230181".to_string(), true), false)),
        );
    }

    #[test]
    fn reduced_matches_the_increased_stat_with_flipped_bounds() {
        // GGG indexes only "#% increased Projectile Range"; the bow's implicit
        // reads "50% reduced Projectile Range" — the negative side of it.
        let mut by_key = HashMap::new();
        by_key.insert(
            ("implicit".to_string(), "#% increased Projectile Range".to_string()),
            ("implicit.stat_3398402065".to_string(), true),
        );
        let idx = StatsIndex { by_key };
        assert_eq!(
            idx.lookup(&["implicit"], "50% reduced Projectile Range", false),
            Some((("implicit.stat_3398402065".to_string(), true), true)),
        );

        let p = SearchPayload {
            league: "Standard".into(), rarity: None, name: None, base_type: None,
            corrupted: None, fractured: None, ilvl_min: None, quality_min: None,
            sockets_min: None, base_stats: vec![], aps: None, seller: None,
            local_mods: false,
            stats: vec![PayloadStat {
                text: "50% reduced Projectile Range".into(),
                kind: Some("implicit".into()),
                min: Some(50.0),
                max: None,
            }],
        };
        let mut unmatched = Vec::new();
        let q = build_query(&p, &idx, &mut unmatched);
        assert!(unmatched.is_empty());
        // "at least 50% reduced" is "at most -50% increased"
        let f = &q["query"]["stats"][0]["filters"][0];
        assert_eq!(f["id"], "implicit.stat_3398402065");
        assert_eq!(f["value"]["max"], -50.0);
        assert!(f["value"].get("min").is_none());
    }

    #[test]
    fn fixed_number_stats_are_searched_without_a_value() {
        // Headhunter's mod is indexed with the 60 spelled out, not as '#':
        // it is a flag, and filtering min 60 on it matches nothing.
        let dump = serde_json::json!({ "result": [{ "id": "explicit", "entries": [
            { "id": "explicit.stat_2913235441",
              "text": "When you kill a Rare monster, you gain its Modifiers for 60 seconds" },
            { "id": "explicit.stat_life", "text": "+# to maximum Life" },
        ]}]});
        let idx = build_index(&dump);

        let p = SearchPayload {
            league: "Standard".into(), rarity: Some("unique".into()),
            name: Some("Headhunter".into()), base_type: Some("Heavy Belt".into()),
            corrupted: None, fractured: None, ilvl_min: None, quality_min: None,
            sockets_min: None, base_stats: vec![], aps: None, seller: None,
            local_mods: false,
            stats: vec![
                PayloadStat {
                    text: "When you kill a Rare monster, you gain its Modifiers for 60 seconds".into(),
                    kind: None, min: Some(60.0), max: None,
                },
                PayloadStat { text: "+38 to maximum Life".into(), kind: None, min: Some(38.0), max: None },
            ],
        };
        let mut unmatched = Vec::new();
        let q = build_query(&p, &idx, &mut unmatched);
        assert!(unmatched.is_empty());
        assert_eq!(q["query"]["name"], "Headhunter");

        let filters = q["query"]["stats"][0]["filters"].as_array().unwrap();
        assert_eq!(filters[0]["id"], "explicit.stat_2913235441");
        assert_eq!(filters[0]["value"], serde_json::json!({}));  // presence only
        assert_eq!(filters[1]["value"]["min"], 38.0);            // real roll keeps its bound
    }

    #[test]
    fn anointments_resolve_through_the_explicit_group() {
        // "{ Enhancement } Allocates Spike Pit" on the item, but GGG keeps
        // anointments as explicit entries with a compound id
        let dump = serde_json::json!({ "result": [{ "id": "explicit", "entries": [
            { "id": "explicit.stat_2954116742|3698", "text": "Allocates Spike Pit" },
        ]}]});
        let idx = build_index(&dump);
        assert_eq!(
            idx.lookup(group_chain(Some("enchant")), "Allocates Spike Pit", false),
            Some((("explicit.stat_2954116742|3698".to_string(), false), false)),
        );
    }

    #[test]
    fn same_direction_match_beats_the_flipped_one() {
        // both wordings exist as separate stats: never flip when the literal
        // text is indexed
        let mut by_key = HashMap::new();
        by_key.insert(
            ("explicit".to_string(), "#% reduced Attribute Requirements".to_string()),
            ("explicit.reduced".to_string(), true),
        );
        by_key.insert(
            ("explicit".to_string(), "#% increased Attribute Requirements".to_string()),
            ("explicit.increased".to_string(), true),
        );
        let idx = StatsIndex { by_key };
        assert_eq!(
            idx.lookup(&["explicit"], "35% reduced Attribute Requirements", false),
            Some((("explicit.reduced".to_string(), true), false)),
        );
    }

    #[test]
    fn lookup_prefers_local_variant_on_gear() {
        // "#% increased Attack Speed" exists twice: (Local) on weapons, plain
        // elsewhere. Same visible text — the item kind picks the id.
        let mut by_key = HashMap::new();
        by_key.insert(
            ("explicit".to_string(), "#% increased Attack Speed (Local)".to_string()),
            ("explicit.stat_210067635".to_string(), true),
        );
        by_key.insert(
            ("explicit".to_string(), "#% increased Attack Speed".to_string()),
            ("explicit.stat_681332047".to_string(), true),
        );
        let idx = StatsIndex { by_key };
        assert_eq!(
            idx.lookup(&["explicit"], "15% increased Attack Speed", true),
            Some((("explicit.stat_210067635".to_string(), true), false)),
        );
        assert_eq!(
            idx.lookup(&["explicit"], "15% increased Attack Speed", false),
            Some((("explicit.stat_681332047".to_string(), true), false)),
        );
        // no local variant indexed → falls back to the plain id
        assert_eq!(
            idx.lookup(&["explicit"], "+15% increased Attack Speed", true),
            Some((("explicit.stat_210067635".to_string(), true), false)),
        );
    }
}
