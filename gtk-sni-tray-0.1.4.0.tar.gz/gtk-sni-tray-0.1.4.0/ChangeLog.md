# Changelog for gtk-sni-tray

## Unreleased changes
