# Triage Labels

The skills speak in terms of five canonical triage roles. This file maps those roles to the actual
label strings used in this repo's issue tracker.

| Role              | Label in tracker        | Meaning                                  |
| ----------------- | ----------------------- | ---------------------------------------- |
| `needs-triage`    | `Priority/Low`          | New issue, maintainer needs to evaluate  |
| `needs-info`      | `Status/Need More Info` | Waiting on reporter for more information |
| `ready-for-agent` | `Priority/Medium`       | Fully specified, ready for an AFK agent  |
| `ready-for-human` | `Priority/Critical`     | Requires human implementation            |
| `wontfix`         | `Reviewed/Won't Fix`    | Will not be actioned                     |

When a skill mentions a role (e.g. "apply the AFK-ready triage label"), use the corresponding label
string from this table.

Edit the right-hand column to match whatever vocabulary you actually use.
