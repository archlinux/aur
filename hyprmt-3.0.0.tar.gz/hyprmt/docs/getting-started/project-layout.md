# Project Layout

## Root Files

- `Cargo.toml`: package metadata and dependency definitions
- `Cargo.lock`: resolved dependency versions
- `README.md`: short project summary and quick usage notes
- `LICENSE`: project license text

## Source Tree

- `src/main.rs`: command-line parsing, overlay prompt, and Hyprland IPC workflow
- `src/ipc.rs`: manual Hyprland IPC `eval` helper

## Documentation Tree

- `docs/SUMMARY.md`: documentation navigation
- `docs/architecture/`: design and behavior notes
- `docs/getting-started/`: setup and project orientation
- `docs/contributing/`: development and contribution guidance
