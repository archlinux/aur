# Summary

- [Architecture Overview](architecture/overview.md)
- [Known Limitations and Design Debt](architecture/known-limitations.md)
- [Building from Source](getting-started/building.md)
- [Project Layout](getting-started/project-layout.md)
- [Hyprland Bind Guide](getting-started/hyprland-bind-guide.md)
- [Code Style and Conventions](contributing/code-style.md)
- [Testing and Debugging](contributing/testing-and-debugging.md)
- [AI-Assisted Contributions](contributing/ai-assisted-contributions.md)
