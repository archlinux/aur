using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Core.Library;
using Core.Playback;
using Core.Playlists;
using Nexora.Media;
using Nexora.Threading;

namespace Nexora.ViewModels;

public partial class PlaybackVm : ViewModelBase
{
    [ObservableProperty]
    public partial bool IsPlaying { get; private set; }

    [ObservableProperty]
    public partial float PlaybackPosition { get; set; }

    [ObservableProperty]
    public partial TrackViewVm? PlayingTrackViewVm { get; set; }

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(VolumeIconName))]
    public partial int Volume { get; set; }

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(VolumeIconName))]
    public partial bool IsMuted { get; private set; }

    [ObservableProperty]
    public partial string? SeekPreviewTime { get; private set; }

    public string VolumeIconName => GetVolumeIconName();
    public bool IsDraggingVolume { get; set; }

    public bool IsDraggingPosition
    {
        get => isDraggingPosition;
        set
        {
            isDraggingPosition = value;

            if(value)
            {
                draggedTrack = audioPlayer.State.Track;
            }
            else
            {
                seekThrottler.Flush();
            }
        }
    }

    private readonly IAudioPlayer audioPlayer;
    private readonly Throttler seekThrottler;
    private bool isDraggingPosition;
    private IPlaylistItem? draggedTrack;
    private int volumeBeforeMute;
    private bool isUpdatingDisplay;

    public PlaybackVm(
        IAudioPlayer audioPlayer,
        TrackTagWriter tagWriter,
        ICoverCache coverCache,
        CoverViewerVm coverViewerVm,
        IUiDispatcher uiDispatcher,
        Throttler seekThrottler)
    {
        this.audioPlayer = audioPlayer;
        this.seekThrottler = seekThrottler;

        SetVolumeDisplay(audioPlayer.Volume);

        audioPlayer.StateChanged += state => uiDispatcher.Post(() =>
        {
            IsPlaying = state.Status == PlaybackStatus.Playing;

            if(state.Track == null)
            {
                PlayingTrackViewVm = null;
                SetPlaybackPositionDisplay(0);
                return;
            }

            var trackViewVm = PlayingTrackViewVm ?? new TrackViewVm(coverCache, coverViewerVm, uiDispatcher);
            trackViewVm.Update(state.Track);
            PlayingTrackViewVm = trackViewVm;
        });

        audioPlayer.PlaybackPositionChanged += value => uiDispatcher.Post(() =>
        {
            if(!IsDraggingPosition)
            {
                SetPlaybackPositionDisplay(value);
            }
        });

        audioPlayer.VolumeChanged += newVolume => uiDispatcher.Post(() =>
        {
            int volume = (int)MathF.Round(newVolume);

            if(IsMuted)
            {
                volumeBeforeMute = volume;
            }
            else if(!IsDraggingVolume)
            {
                SetVolumeDisplay(volume);
            }
        });

        audioPlayer.MuteChanged += isMuted => uiDispatcher.Post(() =>
        {
            ApplyMuteState(isMuted);
        });

        tagWriter.TrackChanged += audioTrack => uiDispatcher.Post(() =>
        {
            var playingTrack = audioPlayer.State.Track;

            if(playingTrack != null && playingTrack.AudioTrack == audioTrack)
            {
                PlayingTrackViewVm?.Update(playingTrack);
            }
        });
    }

    [RelayCommand]
    public void Pause()
    {
        audioPlayer.TogglePause();
    }

    [RelayCommand]
    public void PlayNextTrack()
    {
        audioPlayer.PlayNextTrack();
    }

    [RelayCommand]
    public void PlayPreviousTrack()
    {
        audioPlayer.PlayPreviousTrack();
    }

    [RelayCommand]
    public void ToggleMute()
    {
        SetMuted(!IsMuted);
    }

    public void SkipForward()
    {
        audioPlayer.SkipForward();
    }

    public void SkipBack()
    {
        audioPlayer.SkipBack();
    }

    public void PreviewSeek(double position)
    {
        var playingTrack = audioPlayer.State.Track;

        if(playingTrack == null)
        {
            SeekPreviewTime = null;
            return;
        }

        var time = playingTrack.AudioTrack.Metadata.Duration * Math.Clamp(position, 0, 1);
        SeekPreviewTime = $"{(int)time.TotalMinutes:00}:{time.Seconds:00}";
    }

    partial void OnVolumeChanged(int value)
    {
        if(isUpdatingDisplay)
        {
            return;
        }

        audioPlayer.Volume = Math.Clamp(value, 0, 100);

        if(IsMuted && value > 0)
        {
            volumeBeforeMute = value;
            SetMuted(false);
        }
    }

    private void SetMuted(bool isMuted)
    {
        audioPlayer.Mute = isMuted;
        ApplyMuteState(isMuted);
    }

    private void ApplyMuteState(bool isMuted)
    {
        if(IsMuted == isMuted)
        {
            return;
        }

        IsMuted = isMuted;

        if(isMuted)
        {
            volumeBeforeMute = Volume;
            SetVolumeDisplay(0);
        }
        else if(!IsDraggingVolume)
        {
            SetVolumeDisplay(volumeBeforeMute);
        }
    }

    partial void OnPlaybackPositionChanged(float value)
    {
        if(isUpdatingDisplay)
        {
            return;
        }

        if(!IsDraggingPosition)
        {
            audioPlayer.PlaybackPosition = value;
            return;
        }

        var track = draggedTrack;
        seekThrottler.Run(() => SeekDraggedTrack(track, value));
    }

    private void SeekDraggedTrack(IPlaylistItem? track, float position)
    {
        if(audioPlayer.State.Track == track)
        {
            audioPlayer.PlaybackPosition = position;
        }
    }

    private string GetVolumeIconName()
    {
        if(IsMuted)
        {
            return "speaker_mute";
        }

        if(Volume == 0)
        {
            return "speaker_silent";
        }

        return Volume <= 50 ? "speaker_low" : "speaker_loud";
    }

    private void SetVolumeDisplay(int volume)
    {
        isUpdatingDisplay = true;
        Volume = volume;
        isUpdatingDisplay = false;
    }

    private void SetPlaybackPositionDisplay(float position)
    {
        isUpdatingDisplay = true;
        PlaybackPosition = position;
        isUpdatingDisplay = false;
    }
}
