using System.Collections;
using Core.Tracks;

namespace Core.Playlists;

public class Playlist : IEnumerable<IPlaylistItem>
{
    public string Name { get; set; } = "";
    public bool IsEmpty => TrackCount == 0;
    public int TrackCount => items.Count;
    private readonly List<IPlaylistItem> items = [];

    public event Action<IPlaylistItem>? ItemAdded;
    public event Action<IPlaylistItem>? ItemRemoved;

    public IEnumerable<IPlaylistItem> GetAllItems()
    {
        return items;
    }

    public IPlaylistItem GetItem(int index)
    {
        if(index < 0 || index > items.Count - 1)
        {
            throw new ArgumentOutOfRangeException(nameof(index));
        }

        return items[index];
    }

    public void AddTrack(IAudioTrack audioTrack)
    {
        var item = new PlaylistItem(audioTrack, this, items.Count);
        items.Add(item);
        ItemAdded?.Invoke(item);
    }

    public virtual void RemoveItem(IPlaylistItem item)
    {
        int removedIndex = items.IndexOf(item);

        if(removedIndex < 0)
        {
            return;
        }

        items.RemoveAt(removedIndex);

        for(int index = removedIndex; index < items.Count; index++)
        {
            items[index].Index = index;
        }

        ItemRemoved?.Invoke(item);
    }

    public void AddTracks(IEnumerable<IAudioTrack> audioTracks)
    {
        foreach(var audioTrack in audioTracks)
        {
            AddTrack(audioTrack);
        }
    }

    public IEnumerator<IPlaylistItem> GetEnumerator()
    {
        foreach(var item in items)
        {
            yield return item;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
