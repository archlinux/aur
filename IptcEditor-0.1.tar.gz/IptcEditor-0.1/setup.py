from setuptools import setup, find_packages
import IptcEditor

setup(
        name='IptcEditor',
        author='Dan Bright',
        author_email='productions@zaziork.com',
        description=('A Python wrapper for "Exiv2", that allows reading and manipulation'
                     ' of image IPTC meta-data'),
        license='LICENSE.txt',
        keywords='IPTC, image tagging, photo tagging, image metadata',
        long_description=open('README').read(),
        classifiers=[
            'Development Status :: Beta',
            'Topic :: Utilities',
            'License :: GPLv3'
        ],
        version='0.1',
        packages=find_packages(),
        include_package_data=True,
        url='https://www.zaziork.com',
        install_requires=[
            'gi',
            'datetime'
        ]
)
