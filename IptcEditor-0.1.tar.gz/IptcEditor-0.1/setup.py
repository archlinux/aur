from setuptools import setup, find_packages
import IptcEditor

setup(
        name='IptcEditor',
        author='Dan Bright',
        author_email='productions@zaziork.com',
        description=('This is a python3 GTK3 wrapper for the EXIV2 application, which is used to read and edit IPTC (and other forms) of image metadata.'
        ' It can handle bulk operations on directories of image files.'),
        license='LICENSE.txt',
        keywords='IPTC, image tagging, photo tagging, image metadata',
        long_description=open('README').read(),
        classifiers=[
            'Development Status :: Beta',
            'Topic :: Utilities',
            'License :: GPLv3'
        ],
        version='0.1',
        packages=find_packages(),
        include_package_data=True,
        url='https://www.zaziork.com',
        install_requires=[
            'gi',
            'datetime'
        ]
)
