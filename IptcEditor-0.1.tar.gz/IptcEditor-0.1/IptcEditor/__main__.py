from IptcEditor import gui_gtk
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk



def run():
    # run the thang
    window = gui_gtk.NbLayout()
    window.connect('delete-event', Gtk.main_quit)
    window.show_all()
    if __name__ == '__main__':
        Gtk.main()

run()
