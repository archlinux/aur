import subprocess
import os


class TagEditor:
    def __init__(self):

        # set up variables
        self.filename = None
        self.directory = None
        self.old_tag = None
        self.new_tag = None
        self.ftr = []
        self.mode = 'KEY_PHRASES'

    def run_cli(self):
        while True:
            # ensure filename and directory are empty to begin with
            self.set_filename(None)
            self.set_directory(None)
            # get the input
            self.submit_input()
            # kick it off (if get_tags returns False, break and start loop over otherwise run replace_keyphrases).
            tag_string_list = self.get_tags()
            if not tag_string_list:
                break
            # if nothing to change, print the tags
            if not self.old_tag and not self.new_tag and not self.ftr:
                print('Tags are: {0}'.format([tag for tag in tag_string_list]))
            else:
                if (tag_string_list and self.filename) \
                        or (tag_string_list and self.directory) \
                                and self.mode == 'KEY_PHRASES':
                    self.replace_keyphrases(tag_string_list) or print('A problem occurred whilst replacing the tags!')
                # remove any additional unwanted tags
                elif self.ftr:
                    if self.remove_exif_field() is False:
                        print('There was a problem removing the fields marked for removal ...')
        # restart the loop after any error breaks
        self.run_cli()

    # set up the directory and file variables, and change directory to the image directory if necessary
    def prepare_to_run(self):
        # if both directory & filename entered, exit with a rude message
        if self.directory and self.filename:
            print('You submitted both a directory (for bulk processing), and an individual filename. '
                  'This was wrong. Bad panda!')
            return False
        # change cwd
        if self.directory:
            wd = self.directory.rstrip('/')
            try:
                os.chdir(wd)
            except FileNotFoundError:
                print('It seems that the directory you entered does not exist!')
                self.set_directory(None)
        elif self.filename:
            # if path,
            if '/' in self.filename:
                elements = self.filename.split('/')
                file = elements.pop()
                path = ''
                for ele in elements:
                    path += ele + '/'
                try:
                    os.chdir(path)
                    self.set_filename(file)
                except FileNotFoundError:
                    print('It seems that the path you entered is incorrect!')
                    self.set_filename(None)
        return True

    # # setters
    def set_filename(self, filename):
        self.filename = self.my_filter(filename)

    def set_directory(self, directory):
        self.directory = self.my_filter(directory)

    def set_old_tag(self, old_tag):
        self.old_tag = self.my_filter(old_tag)

    def set_new_tag(self, new_tag):
        self.new_tag = self.my_filter(new_tag)

    def set_ftr(self, fields_to_remove):
        self.ftr = [self.my_filter(fields) for fields in fields_to_remove]

    def set_mode(self, mode):
        if mode == 'TAG_TYPES':
            self.mode = 'TAG_TYPES'
        else:
            self.mode = 'KEY_PHRASES'

    def submit_input(self):
        filename = input('Input filename (leave blank if bulk operation): ')  # test.tif
        directory = input('Full path to directory (leave blank if NOT bulk operation): ')
        old_tag = input('Keyword "tag" to be replaced (cAse SenSitIve): ')
        new_tag = input('Replacement keyword "tag" (CaSE sEnsItivE): ')
        ftr = input('Name of fields to remove (if any, comma separated): ')  # e.g. Exif.Image.Software
        fields_to_remove = ftr.split(',') if ftr else []
        self.set_filename(filename)
        self.set_directory(directory)
        self.set_old_tag(old_tag)
        self.set_new_tag(new_tag)
        self.set_ftr(fields_to_remove)

    def get_tags(self):
        keyphrase_strings_list = []
        tag_type_list = []
        # change to working directory and set file or directory variables
        if not self.prepare_to_run():
            # if prepare_to_run returns False, break, which restarts the loop
            print('Oooops, there has been an error grabbing the keyword tags!')
            return False
        # if handling single file, not a directory (and image extension is allowed)
        if not self.directory and self.image_extension_checker():
            if self.mode == 'KEY_PHRASES':
                if self.generate_keyphrase_list():
                    keyphrase_strings_list.append(self.generate_keyphrase_list())
                return keyphrase_strings_list or False
            elif self.mode == 'TAG_TYPES':
                if self.generate_tag_type_list():
                    tag_type_list.append(self.generate_tag_type_list()) or False
                return tag_type_list or False
        elif self.directory:
            file_list = [file for file in os.listdir(os.getcwd()) if os.path.isfile(file)]
            if self.mode == 'KEY_PHRASES':
                for f in file_list:
                    # set active filename to file
                    self.set_filename(f)
                    # generate tag list, but only if image extension checker passes
                    more_tags = self.generate_keyphrase_list() if self.image_extension_checker() else None
                    if more_tags:
                        # append a new list inside the tagStringsContainer list containing the file tags
                        keyphrase_strings_list.append([tag for tag in more_tags])
                        # delete the temp holding list values, ready for re-use
                        del more_tags[:]
                return keyphrase_strings_list or False
            elif self.mode == 'TAG_TYPES':
                for f in file_list:
                    self.set_filename(f)
                    more_tags = self.generate_tag_type_list() if self.image_extension_checker() else None
                    if more_tags:
                        tag_type_list.append([tag for tag in more_tags])
                        del more_tags[:]
                return tag_type_list or False
        else:
            return False

    def generate_keyphrase_list(self):
        tag_strings = []
        # examine the existing IPTC tags1
        try:
            examine = subprocess.Popen(['exiv2', '-PI', self.filename], stdout=subprocess.PIPE, shell=False)
            output, error = examine.communicate()
        except FileNotFoundError:
            print('It appears that exiv2 may not be installed on your system!')
            return False
        if output:
            # decode the binary output to string
            decoded_output = output.decode()
            # split the string at linebreak, into a list of discrete tags
            tag_list = decoded_output.split('\n')
            # create a list in which to place each element of every tag
            elements_list = []
            ''' loop the tag list and add - to the new elements_list list - NEW lists of tags, split into elements,
            created by splitting the tag string at whitespace (default split())
            elements_list will be a list of lists of elements.
            '''
            for tag in tag_list:
                elements_list.append(tag.split())
            # loop the elements_list (which is a list of lists of elements)
            string_builder = []
            for listOfElements in elements_list:
                if listOfElements and listOfElements[0] == 'Iptc.Application2.Keywords':
                    # append small lists of each element number 3 and above, to the new string_builder list
                    string_builder.append(listOfElements[3:])
            ''' add each complete tag string (elements of stringbuilder joined to string)
            as an element in the new tagStrings list
            '''
            for element in string_builder:
                tag_strings.append(' '.join(element))
            # append the filename to the new list of file tags
            tag_strings.append(self.filename)
            return tag_strings
        else:
            # if no tags
            print('No IPTC data here ...')
            return False

    def generate_tag_type_list(self):
        tag_types = []
        # examine the existing IPTC tags types
        try:
            examine = subprocess.Popen(['exiv2', '-PI', self.filename], stdout=subprocess.PIPE, shell=False)
            output, error = examine.communicate()
        except FileNotFoundError:
            print('It appears that exiv2 may not be installed on your system!')
            return False
        if output:
            # decode the binary output to string
            decoded_output = output.decode()
            # split the string at linebreak, into a list of discrete tags
            tag_list = decoded_output.split('\n')
            # create a list in which to place each element of every tag
            elements_list = []
            for tag in tag_list:
                elements_list.append(tag.split())
            # loop the elements_list (which is a list of lists of elements)
            for listOfElements in elements_list:
                if listOfElements:
                    tag_types.append(listOfElements[0])
            tag_types.append(self.filename)
            return tag_types
        else:
            # if no tags
            print('No IPTC data here ...')
            return False

    def replace_keyphrases(self, tag_strings_list=None):
        if tag_strings_list:
            for tag_list in tag_strings_list:
                # get filename associated with each tag_list
                f = tag_list.pop()
                if tag_list:
                    if self.old_tag in tag_list:
                        # replace old string with new
                        for num, s in enumerate(tag_list):
                            if s == self.old_tag:
                                print('Being replaced!')
                                if not self.new_tag:
                                    # if no new tag, just delete the old
                                    del tag_list[num]
                                else:
                                    # replace the old tag with the new
                                    tag_list[num] = self.new_tag
                        # delete the old strings
                        subprocess.call(['exiv2', '-M', 'del Iptc.Application2.Keywords', f],
                                        stdout=subprocess.PIPE, shell=False)
                        # add the new strings and remove dupes just for good measure!
                        no_dupes = self.remove_dupes(tag_list)
                        if no_dupes:
                            for tag in no_dupes:
                                print('Replacing with: ', tag)
                                subprocess.call(
                                        ['exiv2', '-M', 'add Iptc.Application2.Keywords String {0}'.format(tag), f],
                                        stdout=subprocess.PIPE, shell=False)
                            print('Job done! The new tags for {0} are: '.format(f), tag_list)
                    else:
                        print('Dinae change ... the current tags for {0} are: '.format(f), tag_list)
                else:
                    # if tag list is empty (i.e. there no existing tags)
                    subprocess.call(
                            ['exiv2', '-M', 'add Iptc.Application2.Keywords String {0}'.
                                format(self.new_tag), self.filename],
                            stdout=subprocess.PIPE, shell=False)
                    print('Job done! The new tags for {0} are: '.format(self.filename), tag_list)
        else:
            return False

    def remove_exif_field(self):
        if self.ftr:
            # if scanning a directory
            if self.directory:
                wd = self.directory.rstrip('/')
                os.chdir(wd)
                file_list = [file for file in os.listdir(wd) if os.path.isfile(file)]
                for f in file_list:
                    for field in self.ftr:
                        subprocess.call(['exiv2', '-M', 'del {0}'.format(field), f],
                                        stdout=subprocess.PIPE, shell=False)
                        print('If field "{0}" did exist in {1}, it disnae now!'.format(field, f))
                # # clear fields to remove list
                del self.ftr[:]
                return True
            # if a single file
            elif self.filename and not self.directory:
                for field in self.ftr:
                    subprocess.call(['exiv2', '-M', 'del {0}'.format(field), self.filename],
                                    stdout=subprocess.PIPE, shell=False)
                    print('Field {0} removed!'.format(field))
                    # # clear field to remove
                del self.ftr[:]
                return True
            else:
                return False

    @staticmethod
    def remove_dupes(tag_list=None):
        discrete = set()
        no_dupes = []
        if tag_list:
            for tag in tag_list:
                if tag not in discrete:
                    no_dupes.append(tag)
                discrete.add(tag)
        return no_dupes

    def image_extension_checker(self):
        allowed_formats = ['jpg', 'tif', 'tiff', 'png', 'gif']
        return True if self.filename and self.filename.lower().split('.').pop() in allowed_formats else False

    @staticmethod
    def my_filter(incoming=None):
        if incoming is not None:
            # sanitize the strings
            extra_chars = [':', '.', ' ', '|', '-', '~', '*', '/', '\[', '\]', '!']
            return ''.join([c if c.isalnum() or c in extra_chars else '' for c in incoming])
        else:
            return None  # get the inputs


# run the thang
editor = TagEditor()
editor.set_mode('TAG_TYPES')  # can leave blank for default 'KEY_PHRASES'
if __name__ == '__main__':
    editor.run_cli()
