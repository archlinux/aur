import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from datetime import datetime
from IptcEditor.tag_editor import TagEditor


class NbLayout(Gtk.Window):
    def __init__(self):

        # # create instance of the editor
        self.editor = TagEditor()

        # # set up variables
        self.filename = self.directory = None

        # # # init the window object, passing the title
        Gtk.Window.__init__(self, title='My Notebook ...')

        # # set default window size
        self.set_default_size(800, 600)

        # # call my set_header method
        self.set_header()

        # # call my set_main_window method
        self.set_main_window()

    def set_header(self):

        # # set header bar
        header_bar = Gtk.HeaderBar()
        header_bar.set_show_close_button(True)
        # # add title to header bar
        header_bar.props.title = 'IPTC Tag Modifier'
        self.set_titlebar(header_bar)

    def set_main_window(self):

        # # create notebook
        self.set_border_width(10)
        self.notebook = Gtk.Notebook()
        self.add(self.notebook)

        # # add 'pages' to the notebook
        self.notebook.append_page(self.nb_page_1(), Gtk.Label('Source Selection'))
        self.notebook.append_page(self.nb_page_2(), Gtk.Label('Tagger'))

    def nb_page_1(self):

        # # set up initial variables
        file_label_text = 'Image file ...'
        directory_label_text = 'Image directory, for bulk operations ...'

        # # create page boxes
        self.page_1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.page_1.set_border_width(10)

        # # create buttons
        self.file_button = Gtk.Button(label='Choose a file')
        self.file_button.connect('clicked', self.file_selector)
        self.directory_button = Gtk.Button(label='Choose a directory (for bulk operations)')
        self.directory_button.connect('clicked', self.directory_selector)

        # # create labels
        self.file_label = Gtk.Label()
        self.directory_label = Gtk.Label()
        self.file_label.set_markup('<small>{txt}</small>'.format(txt=file_label_text))
        self.file_label.set_justify(Gtk.Justification.LEFT)
        self.file_label.set_line_wrap(True)
        self.directory_label.set_markup('<small>{txt}</small>'.format(txt=directory_label_text))
        self.directory_label.set_justify(Gtk.Justification.LEFT)
        self.directory_label.set_line_wrap(True)
        self.or_label = Gtk.Label()
        self.or_label.set_markup('<small><i>Or</i></small>')
        self.or_label.set_justify(Gtk.Justification.CENTER)

        # # create a grid
        self.grid = Gtk.Grid()
        self.grid.set_row_spacing(10)
        self.grid.set_column_spacing(10)
        self.grid.set_column_homogeneous(False)

        # # add button to grid as first reference object
        self.grid.add(self.file_button)

        # # attach other objects (labels & buttons) to the grid
        self.grid.attach(self.file_label, 1, 0, 2, 1)
        self.grid.attach(self.or_label, 0, 1, 1, 1)
        self.grid.attach(self.directory_button, 0, 2, 1, 1)
        self.grid.attach(self.directory_label, 1, 2, 2, 1)

        # # add grid to page
        self.page_1.pack_start(self.grid, True, True, 0)

        # # return the page
        return self.page_1

    def nb_page_2(self):

        # # create page boxes
        page_2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        page_2.set_border_width(10)

        # # create the page's grid
        tagger_grid = Gtk.Grid()
        tagger_grid.set_row_spacing(10)
        tagger_grid.set_column_spacing(10)
        tagger_grid.set_column_homogeneous(False)
        tagger_grid.set_row_homogeneous(False)

        # # create labels
        old_tag_label = Gtk.Label()
        new_tag_label = Gtk.Label()
        remove_field_label = Gtk.Label()
        activity_log_title = Gtk.Label()
        self.activity_log_label = Gtk.Label()  # make class attribute, for updating
        old_tag_label.set_markup('<b>Key phrase to replace</b>')
        old_tag_label.set_halign(Gtk.Align.START)
        new_tag_label.set_markup('<b>Replacement key phrase</b>')
        new_tag_label.set_halign(Gtk.Align.START)
        remove_field_label.set_markup('<b>Remove IPTC field</b>')
        remove_field_label.set_halign(Gtk.Align.START)
        activity_log_title.set_markup('<u><b><big>Activities This Session</big></b></u>')
        activity_log_title.set_valign(Gtk.Align.START)
        activity_log_title.set_halign(Gtk.Align.START)
        self.activity_log_label.set_valign(Gtk.Align.START)
        self.activity_log_label.set_halign(Gtk.Align.START)
        self.activity_log_label.set_line_wrap(True)

        # # create buttons
        display_iptc_kw_button = Gtk.Button('Display Key Phrases')
        display_iptc_kw_button.connect('clicked', self.display_kw_clicked)
        display_iptc_kw_button.set_halign(Gtk.Align.START)
        display_iptc_tags_button = Gtk.Button('Display IPTC Tag Types')
        display_iptc_tags_button.set_halign(Gtk.Align.START)
        display_iptc_tags_button.connect('clicked', self.display_tagtypes_clicked)
        replace_button = Gtk.Button('Replace Key Phrase')
        remove_button = Gtk.Button('Remove IPTC Tag Field')
        replace_button.connect('clicked', self.replace_clicked)
        replace_button.set_halign(Gtk.Align.START)
        remove_button.connect('clicked', self.remove_clicked)
        remove_button.set_halign(Gtk.Align.START)

        # # create box for top display buttons
        display_buttons_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        display_buttons_box.set_halign(Gtk.Align.START)
        display_buttons_box.pack_start(display_iptc_kw_button, True, True, 0)
        display_buttons_box.pack_start(display_iptc_tags_button, True, True, 0)

        # # create box for action buttons
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=15)
        button_box.set_halign(Gtk.Align.START)
        button_box.set_homogeneous(False)

        # # add action buttons to box
        button_box.pack_start(replace_button, True, True, 0)
        button_box.pack_start(remove_button, True, True, 0)

        # # create input fields
        self.old_tag_input = Gtk.Entry()
        self.old_tag_input.set_hexpand(True)
        self.new_tag_input = Gtk.Entry()
        self.remove_field_input = Gtk.Entry()

        # # create scroller for operation messages
        message_scroller = Gtk.ScrolledWindow()
        message_scroller.set_hexpand(True)
        message_scroller.set_vexpand(True)

        # # create box for the activity log
        activity_log_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        activity_log_container.set_valign(Gtk.Align.START)

        # # create activity log list
        self.activity_log = []

        # # add the labels to the box
        activity_log_container.pack_start(self.activity_log_label, True, True, 0)

        # # update the list and add to the label
        self.add_to_log('Awaiting instruction ...')

        # # add the box to the scroller
        message_scroller.add_with_viewport(activity_log_container)

        # # add the labels and input fields to the grid
        tagger_grid.attach(display_buttons_box, 0, 0, 1, 1)
        tagger_grid.attach(old_tag_label, 0, 1, 1, 1)
        tagger_grid.attach(self.old_tag_input, 1, 1, 2, 1)
        tagger_grid.attach(new_tag_label, 0, 2, 1, 1)
        tagger_grid.attach(self.new_tag_input, 1, 2, 2, 1)
        tagger_grid.attach(remove_field_label, 0, 3, 1, 1)
        tagger_grid.attach(self.remove_field_input, 1, 3, 2, 1)
        tagger_grid.attach(button_box, 1, 4, 1, 1)
        tagger_grid.attach(activity_log_title, 0, 6, 1, 1)
        tagger_grid.attach(message_scroller, 0, 7, 4, 1)

        # # add the grid to the page box
        page_2.pack_start(tagger_grid, True, True, 0)

        # # return the page
        return page_2

    def add_to_log(self, log_message=None):
        if log_message:
            time = datetime.now().strftime('%H:%M:%S')
            label = ''
            self.activity_log.append('<small>{0}</small>: <big><i>{1}</i></big>'.format(time, log_message))
            rev = reversed(self.activity_log)
            label += '\n\n'.join(rev)
            self.activity_log_label.set_markup(label)
        else:
            return False

    def file_selector(self, widget):
        dialog = Gtk.FileChooserDialog('Please select the image file',
                                       self, Gtk.FileChooserAction.OPEN,
                                       (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                                        Gtk.STOCK_OK, Gtk.ResponseType.OK))
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.file_label.set_markup('<small><b>{txt}</b></small>'.format(txt=dialog.get_filename()))
            self.directory_label.set_markup('<small><b>A single file selected.</b></small>')
            # get the filename from the file chooser dialog
            self.filename = dialog.get_filename()
            self.directory = None  # ensure directory is reset to None to prevent selecting both file & dir
            # # log activity
            self.add_to_log('File "{0}" selected for operation.'.format(dialog.get_filename()))
        elif response == Gtk.ResponseType.CANCEL:
            pass
        dialog.destroy()

    def directory_selector(self, widget):
        dialog = Gtk.FileChooserDialog('Please select the image files directory for bulk operations',
                                       self, Gtk.FileChooserAction.SELECT_FOLDER,
                                       (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                                        Gtk.STOCK_OK, Gtk.ResponseType.OK))
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.directory_label.set_markup('<small><b>{txt}</b></small>'.format(txt=dialog.get_filename()))
            self.file_label.set_markup('<small><b>A directory has been selected.</b></small>')
            self.directory = dialog.get_filename()
            self.filename = None  # ensure file is reset to None to prevent selecting both file & dir
            # # log the activity
            self.add_to_log('Directory "{0}" selected for operation.'.format(dialog.get_filename()))
        elif response == Gtk.ResponseType.CANCEL:
            pass
        dialog.destroy()

    def display_kw_clicked(self, button):
        # # create popup
        dialog = self.DialogPopup(self)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            dialog.destroy()
        elif response == Gtk.ResponseType.CANCEL:
            dialog.destroy()
        # # write to activity log
        self.add_to_log('Key phrases displayed.')

    def display_tagtypes_clicked(self, button):
        # # create popup
        dialog = self.DialogPopup(self, type='Tags')
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            dialog.destroy()
        elif response == Gtk.ResponseType.CANCEL:
            dialog.destroy()
        # # write to activity log
        self.add_to_log('IPTC tag types displayed.')

    def replace_clicked(self, button):
        if self.old_tag_input.get_text() and self.new_tag_input.get_text():
            # set the filename / directory name in the editor
            self.editor.set_filename(self.filename)
            self.editor.set_directory(self.directory)
            # set the old and new tags in the editor
            self.editor.set_old_tag(self.old_tag_input.get_text())
            self.editor.set_new_tag(self.new_tag_input.get_text())
            # grab the keyword tags and replace them
            if self.editor.replace_keyphrases(self.editor.get_tags()) is not False:
                self.add_to_log('Replaced key phrase "{0}" with "{1}"'.format(self.old_tag_input.get_text(),
                                                                              self.new_tag_input.get_text()))
                return True
        self.add_to_log('Tag replacement failed.')
        return False

    def remove_clicked(self, button):
        operate_on = None
        if self.remove_field_input.get_text():
            # # set the filename / directory name in the editor, and the field to remove
            if self.filename:
                self.editor.set_filename(self.filename)
                self.editor.set_ftr([self.remove_field_input.get_text()])
                operate_on = self.filename
            elif self.directory:
                self.editor.set_directory(self.directory)
                self.editor.set_ftr([self.remove_field_input.get_text()])  # ftr takes a list of fields to remove
                operate_on = self.directory
            # # remove the field
            if self.editor.remove_exif_field():
                # # write to log
                self.add_to_log('Tag {0} removed from {1}.'.format(
                        self.remove_field_input.get_text(), operate_on))
            else:
                self.add_to_log('Error: Tag {0} WAS NOT removed from {1}.'.format(
                        self.remove_field_input.get_text(), operate_on))

    class DialogPopup(Gtk.Dialog):
        def __init__(self, parent, type='Keywords'):
            # note: set parent to "parent" to attach popup to main window (it's parent).
            Gtk.Dialog.__init__(self, 'IPTC Keywords',
                                parent=parent,
                                flags=(Gtk.DialogFlags.MODAL),
                                buttons=(Gtk.STOCK_OK, Gtk.ResponseType.OK))
            self.set_default_size(1024, 768)
            self.set_border_width(30)
            # set the filename / directory name in the editor
            parent.editor.set_filename(parent.filename)
            parent.editor.set_directory(parent.directory)
            # grab the keywords or tags
            if type == 'Tags':
                parent.editor.set_mode('TAG_TYPES')
            elif type == 'Keywords':
                parent.editor.set_mode('KEY_PHRASES')
            result = parent.editor.get_tags()
            results_string = ''
            if result:
                for kws in result:
                    results_string += 'Image name "<b><i>{0}</i></b>" has the following: <b><i>{1}</i></b>\n'.format(
                            kws[-1], ' | '.join(kws[:-1]))
                print(results_string)
            else:
                results_string = 'There are no results to display!'
            # write the label
            label = Gtk.Label()
            label.set_markup(results_string)
            label.set_selectable(True)
            label.set_line_wrap(False)
            box = Gtk.Box()
            box.pack_start(label, True, True, 0)
            scroller = Gtk.ScrolledWindow()
            scroller.set_hexpand(True)
            scroller.set_vexpand(True)
            scroller.add_with_viewport(box)
            # create content area and add the label
            area = self.get_content_area()
            area.add(scroller)
            self.show_all()
