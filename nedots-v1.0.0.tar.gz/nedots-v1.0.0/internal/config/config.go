package config

import (
	"encoding/json"
	"log"

	"git.sr.ht/~nedia/nedots/paths"
)

type Config struct {
	Remote       string          `json:"remote"`
	Dots         []string        `json:"dots"`
	Repositories []GitRepository `json:"repos"  mapstructure:"repos"`
}

type GitRepository struct {
	Remote string `json:"remote"`
	Path   string `json:"path"`
}

// Collect all paths from [Config.Dots] & [Config.Repositories] into a single
// slice.
func (c *Config) Paths() []string {
	paths := c.Dots
	for _, r := range c.Repositories {
		paths = append(paths, r.Path)
	}
	return paths
}

// Iterates over [Config.Dots] & [Config.Repositories] and calls [paths.Resolve]
// on each.
func (c *Config) ResolvePaths() {
	resolve := func(p string, ch chan string) {
		resolved, err := paths.Resolve(p)
		if err != nil {
			log.Fatalf("%s: %s, have you run install?", p, err)
		}
		ch <- resolved
	}

	ch := make(chan string, len(c.Dots)+len(c.Repositories))
	for i, path := range c.Dots {
		go resolve(path, ch)
		c.Dots[i] = <-ch
	}

	for i, repo := range c.Repositories {
		go resolve(repo.Path, ch)
		c.Repositories[i].Path = <-ch
	}
}

func (c *Config) String() string {
	json, _ := json.MarshalIndent(c, "", "  ")
	return string(json)
}
