package paths

import (
	"testing"
	"time"
)

func openHome(t *testing.T) FileInfo {
	var err error
	info, err := Open(Home)
	if err != nil {
		t.Errorf("ERR %s", err)
	}
	return info
}

func TestOpenHome(t *testing.T) {
	_ = openHome(t)
}

func TestFileInfoEquals(t *testing.T) {
	info := openHome(t)
	if other := info; !info.Equals(&other) {
		t.Errorf("ERR %s != %s", info, other)
	}
}

func TestFileInfoNewer(t *testing.T) {
	info := openHome(t)
	other := info

	manyYearsAgo := time.Now().AddDate(-42, 0, 0)
	other.Modified = manyYearsAgo

	if !info.Newer(&other) {
		t.Errorf("ERR %s > %s", info.Modified.String(), other.Modified.String())
	}
}
