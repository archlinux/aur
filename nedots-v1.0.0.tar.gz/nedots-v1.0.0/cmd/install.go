package cmd

import (
	"fmt"
	"os"
	"os/user"
	"path/filepath"
	"strings"
	"text/tabwriter"

	"git.sr.ht/~nedia/nedots/cop"
	"git.sr.ht/~nedia/nedots/internal/term"
	"git.sr.ht/~nedia/nedots/paths"
	"github.com/spf13/cobra"
)

var (
	installCmd = &cobra.Command{
		Use:   "install",
		Short: "Install dotfiles by distributing cached files to their respective destination",
		Run:   install,
	}
)

func init() {
	rootCmd.AddCommand(installCmd)

	installCmd.Flags().BoolVarP(
		&fOverwrite,
		"overwrite",
		"w",
		false,
		"overwrite destination files with cached dotfiles",
	)
}

func install(cmd *cobra.Command, args []string) {
	dots := filepath.Join(cache, "dots")

	entries, err := os.ReadDir(dots)
	if err != nil {
		term.Fatalf(
			"%s have you run %s?",
			term.Bold.String("no dotfiles found"),
			term.Blue.String("init"),
		)
	}

	ch := make(chan copyState, len(entries))
	for _, entry := range entries {
		go func(path string, ch chan copyState) {
			if path == "home" {
				path = paths.Home
				if u, _ := user.Current(); !strings.Contains(path, u.Username) {
					ch <- copyState{
						State: false,
						Error: fmt.Errorf(
							"%s path does not belong to user %s",
							path,
							u.Username,
						),
					}
				}
			} else {
				path = "/" + path
			}

			cop := cop.New(filepath.Join(dots, path), path)
			state := &copyState{State: true, Inner: cop}

			if err := cop.Copy(fOverwrite); err != nil {
				state.State = false
				state.Error = err
			}

			ch <- *state
		}(entry.Name(), ch)
	}

	tw := tabwriter.NewWriter(os.Stdout, 1, 1, 1, ' ', 0)
	defer tw.Flush()

	for range entries {
		state := <-ch
		if state.State {
			fmt.Fprintln(tw, term.Sokayf(
				"copy\t%s\t%s",
				term.Bold.String(state.Inner.Source()),
				state.Inner,
			))
		} else {
			fmt.Fprintln(tw, term.Serrorf(
				"copy\t%s\t%s",
				term.Bold.String(state.Inner.Source()), state.Error.Error(),
			))
		}
	}
}
