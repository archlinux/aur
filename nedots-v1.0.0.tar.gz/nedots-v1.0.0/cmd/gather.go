package cmd

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"text/tabwriter"
	"time"

	"git.sr.ht/~nedia/nedots/cop"
	"git.sr.ht/~nedia/nedots/internal/config"
	"git.sr.ht/~nedia/nedots/internal/term"
	"github.com/spf13/cobra"
)

var (
	gatherCmd = &cobra.Command{
		Use:   "gather",
		Short: "Gather dotfiles by copying them into our cache",
		Run:   gather,
	}
)

func init() {
	rootCmd.AddCommand(gatherCmd)
}

func gather(cmd *cobra.Command, args []string) {
	cfg.ResolvePaths()
	dots := filepath.Join(cache, "dots")

	ch1 := make(chan copyState, len(cfg.Dots))
	for _, path := range cfg.Dots {
		go func(p string, ch chan copyState) {
			cop := cop.New(p, filepath.Join(dots, p))
			state := &copyState{State: true, Inner: cop}

			// Copy w/ overwrite.
			if err := cop.Copy(true); err != nil {
				state.Error = err
				state.State = false
			}

			ch <- *state
		}(path, ch1)
	}

	ch2 := make(chan repoState, len(cfg.Repositories))
	for _, v := range cfg.Repositories {
		go func(repo config.GitRepository, ch chan repoState) {
			run := func(path string, args ...string) ([]byte, error) {
				cmd := exec.Command(
					"git",
					append([]string{"-C", path}, args...)...,
				)
				cmd.Stderr = os.Stderr

				term.Cmdf("%s ...", strings.Join(cmd.Args, " "))
				return cmd.Output()
			}

			var out []byte
			out, err := run(repo.Path, "pull")
			if err != nil {
				err = fmt.Errorf("git pull %s", repo.Path)
			} else {
				if out, err = run(repo.Path, "add", "."); err == nil {
					// Discard output & errors from `git commit`, we don't care if there's
					// nothing to commit.
					now := fmt.Sprintf("Latest %s", time.Now().String())
					_, _ = run(repo.Path, "commit", "-q", "-m", now)

					out, err = run(repo.Path, "push")
				}
			}

			if len(out) > 0 {
				term.Cmd(out)
			}

			state := &repoState{State: true, Inner: &repo}
			if err != nil {
				state.State = false
				state.Error = err
			}

			ch <- *state
		}(v, ch2)
	}

	tw := tabwriter.NewWriter(os.Stdout, 1, 1, 1, ' ', 0)
	defer tw.Flush()

	for range cfg.Dots {
		state := <-ch1
		if state.State {
			fmt.Fprintln(tw, term.Sokayf(
				"copy\t%s\t%s",
				term.Bold.String(state.Inner.Source()),
				state.Inner,
			))
		} else {
			fmt.Fprintln(tw, term.Serrorf(
				"copy\t%s\t%s",
				term.Bold.String(state.Inner.Source()), state.Error.Error(),
			))
		}
	}

	for range cfg.Repositories {
		state := <-ch2
		if state.State {
			fmt.Fprintln(tw, term.Sokayf(
				"update\t%s",
				term.Bold.String(state.Inner.Remote),
			))
		} else {
			fmt.Fprintln(tw, term.Serrorf(
				"update\t%s\t%s",
				term.Bold.String(state.Inner.Remote),
				state.Error.Error(),
			))
		}
	}
}
