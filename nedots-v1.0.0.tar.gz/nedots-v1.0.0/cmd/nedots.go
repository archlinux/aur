package cmd

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"text/tabwriter"

	"git.sr.ht/~nedia/nedots/cop"
	"git.sr.ht/~nedia/nedots/internal/config"
	"git.sr.ht/~nedia/nedots/internal/term"
	"git.sr.ht/~nedia/nedots/paths"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
	"golang.org/x/exp/slices"
)

var (
	fConfig  string
	fVerbose bool

	rootCmd = &cobra.Command{
		Use:   "nedots",
		Short: "Manages configuration files",
		Run:   summarize,
	}

	cfg   config.Config
	cache string = filepath.Join(paths.Cache, "nedots")
)

type (
	state[T any] struct {
		State bool
		Inner *T
		Error error
	}

	copyState = state[cop.CopyOperation]
	repoState = state[config.GitRepository]
)

func init() {
	cobra.OnInitialize(func() {
		// Tell viper where our config file is.
		viper.SetConfigFile(fConfig)

		// Let viper take environment variables prefixed like this as config values.
		//
		// The user may use env vars like so:
		// ```sh
		// > NEDOTS_REMOTE="my_remote" nedots sync -vvv
		// ```
		viper.SetEnvPrefix("NEDOTS")
		viper.AutomaticEnv()

		// Try to read config.
		if err := viper.ReadInConfig(); err != nil {
			log.Fatal(err)
		}

		// Unmarshal the config to cfg.
		if err := viper.Unmarshal(&cfg); err != nil {
			log.Fatal(err)
		}
	})

	rootCmd.PersistentFlags().StringVarP(
		&fConfig,
		"config",
		"c",
		filepath.Join(paths.Config, "nedots", "config.yml"),
		"config file path",
	)
	rootCmd.PersistentFlags().BoolVarP(
		&fVerbose,
		"verbose",
		"v",
		false,
		"enable verbose output",
	)
}

func Execute() {
	ctx := context.Background()
	if err := rootCmd.ExecuteContext(ctx); err != nil {
		os.Exit(1)
	}
}

func summarize(cmd *cobra.Command, args []string) {
	tw := tabwriter.NewWriter(os.Stdout, 1, 1, 1, ' ', 0)
	defer tw.Flush()

	list := []string{}
	for _, p := range cfg.Paths() {
		resolved, err := paths.Resolve(p)
		if err != nil {
			term.Fatalf("%s %s", p, err)
		}

		info, err := paths.Open(resolved)
		if err != nil {
			term.Fatalf("%s %s", p, err)
		}

		list = append(list, info.String())
	}

	// entries, err := os.ReadDir(filepath.Join(cache, "dots"))
	// if err != nil {
	// 	term.Fatalf(
	// 		"%s have you run %s?",
	// 		term.Bold.String("no dotfiles found"),
	// 		term.Blue.String("init"),
	// 	)
	// }

	slices.Sort(list)
	for _, fi := range list {
		fmt.Fprintln(tw, fi)
	}
}
