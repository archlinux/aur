package main

import (
	"log"

	"git.sr.ht/~nedia/nedots/cmd"
)

func main() {
	// Disable datetime prefix
	log.SetFlags(0)

	cmd.Execute()
}
