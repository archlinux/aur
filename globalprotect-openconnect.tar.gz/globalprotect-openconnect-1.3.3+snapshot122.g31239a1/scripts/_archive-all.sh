#!/bin/bash -e

./scripts/prepare-packaging.sh

VERSION=$(cat VERSION VERSION_SUFFIX)

rm -rf ./artifacts && mkdir -p ./artifacts/{obs,aur}

# Add the version file
echo $VERSION > ./artifacts/VERSION

# Archive the source code
git-archive-all \
    --force-submodules \
    --prefix=globalprotect-openconnect-${VERSION}/ \
    ./artifacts/globalprotect-openconnect-${VERSION}.tar.gz

# Prepare the OBS package
cp ./packaging/obs/{*.changes,*.spec} ./artifacts/obs
cp ./artifacts/*.tar.gz ./artifacts/obs/globalprotect-openconnect.tar.gz

# Prepare the AUR package
cp ./packaging/aur/PKGBUILD ./artifacts/aur/PKGBUILD
cp ./artifacts/*.tar.gz ./artifacts/aur/globalprotect-openconnect.tar.gz