#!/bin/bash -e

./scripts/snapshot-version.sh
./scripts/_archive-all.sh

# Update the AUR package
cp ./packaging/aur/PKGBUILD-git ./artifacts/aur/PKGBUILD