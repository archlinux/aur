## Command

```sh
docker run --rm -it -v ${PWD}:/rpm --workdir=/rpm --entrypoint ./entrypoint.sh centos:8
```
