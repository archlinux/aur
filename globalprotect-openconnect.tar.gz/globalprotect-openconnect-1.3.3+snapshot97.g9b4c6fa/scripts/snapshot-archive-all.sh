#!/bin/bash -e

./scripts/snapshot-version.sh
./scripts/prepare-packaging.sh

VERSION=$(cat VERSION VERSION_SUFFIX)

rm -rf ./artifacts && mkdir -p ./artifacts/{obs,aur}

git-archive-all \
    --force-submodules \
    --prefix=globalprotect-openconnect-${VERSION}/ \
    ./artifacts/globalprotect-openconnect-${VERSION}.tar.gz

cp ./packaging/obs/{*.changes,*.spec} \
    ./artifacts/*.tar.gz \
    ./artifacts/obs

cp ./packaging/aur/PKGBUILD-git ./artifacts/aur/PKGBUILD
cp ./artifacts/*.tar.gz ./artifacts/aur/globalprotect-openconnect.tar.gz