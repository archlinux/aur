<div align="center">

# whispy

**Push-to-talk dictation for Hyprland and Omarchy.** Hold a key, speak, release — your words land in the focused field.

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![AUR](https://img.shields.io/aur/version/whispy?label=AUR)](https://aur.archlinux.org/packages/whispy)
[![CI](https://github.com/Ceereals/whispy/actions/workflows/ci.yml/badge.svg)](https://github.com/Ceereals/whispy/actions/workflows/ci.yml)
[![Rust](https://img.shields.io/badge/rust-stable-orange.svg)](https://www.rust-lang.org)

[Quickstart](#quickstart) · [Install](#install) · [Setup](#setup) · [How it works](#how-it-works) · [Configuration](#configuration) · [Requirements](#requirements)

<!-- Drop a real capture here: record the pill + a dictation into an app, save as docs/demo.gif -->
![whispy demo](docs/demo.gif)

</div>

Local, fast, Wayland-native dictation: a resident daemon keeps a
[whisper.cpp](https://github.com/ggerganov/whisper.cpp) model in RAM, a thin client is fired
from your Hyprland binds, and a [Quickshell](https://quickshell.org) pill shows live state.
Speech never leaves your machine. Hyprland — including [Omarchy](https://omarchy.org) 4 — gets
the full experience (pill overlay); dictation
also runs on **X11/Xorg and generic Wayland** (GNOME, KDE, Sway, XFCE, i3) — see
[Non-Hyprland](#non-hyprland-x11-and-generic-wayland).

## Quickstart

```sh
paru -S whispy            # install (Arch/CachyOS; `yay -S whispy` on Omarchy)
whispy-daemon setup       # build whisper.cpp, fetch model, enable service
```

Then add the keybinds `setup` prints — it detects Omarchy and Hyprland's Lua vs
hyprlang config. On **Omarchy 4**, append to `~/.config/hypr/bindings.lua`:

```lua
hl.unbind("SUPER + CTRL + X")  -- Omarchy's Voxtype dictation, if installed
hl.unbind("F9")
o.bind("SUPER + CTRL + X", "Toggle dictation", "whispy-client toggle")
o.bind("F9", "Start dictation (push-to-talk)", "whispy-client start")
o.bind("F9", "Stop dictation (push-to-talk)", "whispy-client stop", { release = true })
o.bind("SUPER + CTRL + SHIFT + X", "Cancel dictation", "whispy-client cancel")
```

On a classic `hyprland.conf`:

```ini
bindd = SUPER CTRL, X, Toggle dictation, exec, whispy-client toggle
bindd = , F9, Start dictation, exec, whispy-client start
bindr = , F9, exec, whispy-client stop
bindd = SUPER CTRL SHIFT, X, Cancel dictation, exec, whispy-client cancel
```

Hold **F9**, speak, release — the text is typed into your focused field (or tap
**SUPER+CTRL+X** to start and again to stop). See
[`docs/hyprland-setup.md`](docs/hyprland-setup.md) for the plain-Lua variant and the
[Omarchy notes](docs/hyprland-setup.md#omarchy).

## Install

**Any distro (script)** — one command, nothing to do after. On Arch it routes to the AUR
package; elsewhere it builds from source into `~/.local/bin`. Either way it then runs
`whispy-daemon setup` for you (whisper.cpp build, model download, ydotool + services):

```sh
./install.sh                         # add WHISPY_NO_SETUP=1 to install binaries only
```

**Arch / CachyOS (AUR):**

```sh
paru -S whispy            # or: yay -S whispy
whispy-daemon setup       # finish the one-time bootstrap
```

**From source:**

```sh
cargo build --release --locked
install -Dm755 target/release/whispy-{daemon,client} -t ~/.local/bin
whispy-daemon setup
```

## Setup

`whispy-daemon setup` is the one-time bootstrap (idempotent — safe to re-run). It **builds
whisper.cpp** (Vulkan or CPU, per `stt.backend` — auto-detected by default), **downloads the
model**, grants ydotool uinput access, seeds
`~/.config/whispy`, enables the `whispy-daemon` **and** `ydotoold` user services, and — if
Quickshell is present — runs the pill as its own `whispy-pill` service (no `shell.qml` edit),
then **verifies** the running system:

```sh
whispy-daemon setup                 # --quickshell forces the pill; --no-pill installs the
                                    # module but skips the service (embed PillPanel yourself)
```

Run any step on its own with:

```sh
whispy-daemon setup doctor|whisper|model|ydotool|systemd|quickshell|omarchy|verify|keybinds
```

The only manual step left is the keybinds — `setup` prints them at the end, in the syntax of
the config it finds (Omarchy 4 `bindings.lua`, Hyprland Lua, or `hyprland.conf`); reprint them
with `whispy-daemon setup keybinds` (see
[`docs/hyprland-setup.md`](docs/hyprland-setup.md); X11/GNOME equivalents under
[Non-Hyprland](#non-hyprland-x11-and-generic-wayland)). Re-run `whispy-daemon setup verify` any
time to check that the model, daemon, `ydotoold`, and whisper-server are all up.

## How it works

```
Hyprland keybind ──► whispy-client ──(unix socket)──► whispy-daemon ──► whisper-server (Vulkan/CPU)
                                                          │
                                                          ├─► state.json ──► Quickshell pill
                                                          └─► inject ──► focused app
```

- **whispy-daemon** — resident service: supervises a `whisper-server` child (model stays
  in RAM), captures audio (PipeWire), filters hallucinations, injects text, publishes state.
- **whispy-client** — tiny binary called from Hyprland binds (`start` / `stop` / `cancel` / `toggle`).
- **whisper-server** — whisper.cpp built with the backend `stt.backend` picks: Vulkan (developed on AMD RDNA4, no ROCm) or CPU (OpenBLAS-accelerated when available).
- **pill UI** — Quickshell layer overlay reading the state file ([`ui/quickshell/`](ui/quickshell/)).
- **Omarchy bar widget** — the same live state as an Omarchy 4 bar widget plugin ([`ui/omarchy/`](ui/omarchy/));
  `setup` installs it and puts it on the bar, see the [Omarchy notes](docs/hyprland-setup.md#omarchy).

**Two injection modes** (`injection.mode`):

| Mode | How | Best for |
|------|-----|----------|
| `paste` *(default)* | `wl-copy` + `ydotool` Ctrl+V, with clipboard save/restore | GUI fields; preserves accents |
| `type` | types directly via `wtype` (virtual keyboard) | terminals too; touches no clipboard |

State & IPC paths (everything is namespaced `whispy`):

- socket — `$XDG_RUNTIME_DIR/whispy/whispy.sock`
- state — `$XDG_RUNTIME_DIR/whispy/state.json` (atomic writes, ≤20 Hz) ← the pill reads this
- logs — `$XDG_STATE_HOME/whispy/{daemon.log,whisper-server.log}` (JSON lines) and
  `transcripts.jsonl` (every clip's text, for `whispy-daemon stats`); each is capped
  (10 MB, or 5 MB for transcripts) and keeps one rotated `.1` generation

## Configuration

The everyday settings have a screen: **`whispy-daemon settings`** picks the microphone (with a
live level meter and a test dictation, `t`), the language, paste vs type, and the silence
auto-stop, and shows the latest transcripts with why any were dropped. It edits your
`config.toml` in place (comments kept) and restarts the daemon on save. On Omarchy, open it
floating like Omarchy's own TUIs:

```sh
omarchy-launch-tui --app-id=TUI.float whispy-daemon settings
```

Defaults are baked into the daemon (see [`config/default.toml`](config/default.toml)). Override
any of them by copying the file to `$XDG_CONFIG_HOME/whispy/config.toml`. Common knobs: the
model and `whisper-server` paths (`[stt]`), the per-request `stt.timeout_secs`, the hallucination
filter thresholds (`[filter]`), and `injection.mode` to switch between paste and type.

To tune the filter, run **`whispy-daemon stats`** — it summarizes the transcript log
(`$XDG_STATE_HOME/whispy/transcripts.jsonl`) as accepted vs dropped clips, broken down by drop
reason, so you can see whether `fuzzy_ratio` / confidence bounds are too aggressive.

## Requirements

- PipeWire (`pw-record`), `libnotify`, `ydotool` (paste mode — works on both Wayland and X11)
- **Wayland**: `wl-clipboard` (paste mode) and/or `wtype` (type mode)
- **X11/Xorg** (e.g. XFCE, i3, Cinnamon, GNOME-on-Xorg): `xdotool` + `xclip` **or** `xsel`
- For the Vulkan backend: a Vulkan-capable GPU (developed on RX 9070 XT / RDNA4) + `vulkan-icd-loader`,
  and to build it: `glslc` (Arch: `shaderc`), `vulkan-headers`, `spirv-headers`. Not needed for the CPU backend.
  The AUR package pulls all of these in; `setup` names any that are missing before it starts the build.
- Build tools for `setup whisper`: `git`, `cmake`, a C/C++ compiler
- Optional: `openblas` for ~3-4× faster CPU inference; [Quickshell](https://quickshell.org) (Qt 6.5+) for the pill overlay (Wayland layer-shell only)

Run `whispy-daemon setup doctor` to see exactly which tools your session needs — it detects
the display server and lists the per-backend dependencies.

### Non-Hyprland: X11 and generic Wayland

Dictation runs everywhere; only the on-screen pill is Hyprland/layer-shell specific.

- **Display server** — `injection.backend` (`[injection]` in config) selects the injection path:
  `auto` (default) detects `WAYLAND_DISPLAY` then `DISPLAY`; force it with `"wayland"` or `"x11"`.
  On X11, injection uses `xdotool type` / `xclip`/`xsel` instead of `wtype` / `wl-clipboard`.
- **Status UI** — the Quickshell pill needs `wlr-layer-shell`, which X11 and GNOME/Mutter-Wayland
  don't provide, so it's skipped there. Instead whispy fires desktop **notifications** on
  success/error (`ui.notify = "auto"` notifies on X11, `"on"` always, `"off"` never).
  `state.json` is still written, so you can wire your own tray/status indicator.
- **Keybinds** — there are no Hyprland binds off Hyprland. Map your push-to-talk key to
  `whispy-client toggle` (and `whispy-client cancel`) through your environment:
  - **XFCE**: Settings → Keyboard → Application Shortcuts
  - **X11 WMs** (i3/bspwm/...): `xbindkeys`, `sxhkd`, or the WM's own bind syntax
  - **GNOME**: Settings → Keyboard → Custom Shortcuts
- **Window-class auto-workflow** — uses `xdotool` on X11 and `hyprctl`/`swaymsg` on Wayland;
  on GNOME/KDE-Wayland (no universal protocol) it's skipped. Manual `--workflow NAME` works everywhere.

> **Platform notes.** `setup whisper` builds whisper.cpp with the backend `stt.backend` selects:
> `auto` (default) builds Vulkan when its loader is present, else a CPU build (OpenBLAS-accelerated
> when `libopenblas` is installed) — so GPU-less machines work out of the box. Force it with
> `stt.backend = "vulkan"` or `"cpu"`. NVIDIA (CUDA) users should build whisper.cpp themselves and
> point `stt.server_bin` at it.

<details>
<summary><b>Project layout</b></summary>

```
crates/common   shared protocol + state types (serde)
crates/daemon   the daemon (audio, stt, filter, inject, state, server, whisper)
crates/client   the thin client
config/         default.toml, hallucinations.toml
systemd/        whispy-daemon.service (user unit)
scripts/        benchmark.sh, setup-ydotool.sh
packaging/aur/  PKGBUILD (whispy) + whispy-git/PKGBUILD
ui/quickshell/  Quickshell pill overlay (reads state.json)
ui/omarchy/     Omarchy 4 bar widget plugin (manifest.json + whispy.qml) + its QML tests
docs/           spike, benchmark, hyprland setup
```

See [`docs/spike-fork-vs-build.md`](docs/spike-fork-vs-build.md) for the build-vs-fork
decision and [`docs/stt-benchmark.md`](docs/stt-benchmark.md) for model benchmarks.

</details>

<details>
<summary><b>Roadmap</b></summary>

- [x] Spike: build vs fork → full custom (Rust)
- [x] Step 0 — scaffold cargo workspace
- [x] Step 1 — build whisper.cpp (Vulkan) + models + benchmark → large-v3-turbo-q5_0
- [x] Step 2 — daemon skeleton (socket, whisper supervise, state, systemd)
- [x] Step 3 — audio capture (pw-record, RMS, gain/normalize)
- [x] Step 4 — inference + hallucination filter (+ transcripts.jsonl)
- [x] Step 5 — injection (wl-copy + ydotool; needs ydotool setup)
- [x] Step 6 — thin client (start/stop/cancel/toggle) + Hyprland binds doc
- [x] Step 7 — pill UI integration (module in `ui/quickshell/`)
- [x] Step 8 — QoL (cancel-on-Escape bind, notify-send on hard errors)

</details>

## License

[MIT](LICENSE) © Riccardo Romoli
