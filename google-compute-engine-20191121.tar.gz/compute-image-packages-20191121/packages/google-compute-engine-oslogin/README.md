## OS Login Guest Environment for Google Compute Engine

**This package has moved. The OS Login on-guest components are now located in
the [guest-oslogin](https://github.com/GoogleCloudPlatform/guest-oslogin) repo**
