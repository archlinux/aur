#!/bin/sh
# Dummy script, to make sure systemd executes the cmdline stage (which exports
# the 'root' variable required for expand_root)
