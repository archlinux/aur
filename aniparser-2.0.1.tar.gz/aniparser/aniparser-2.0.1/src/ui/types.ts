export enum MainType {
  MainPage,
}
