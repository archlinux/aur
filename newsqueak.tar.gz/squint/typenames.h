char *Ttypename[]={
	"TNosuchtype",
	"TAggr",
	"TAny",
	"TArray",
	"TChan",
	"TChar",
	"TID",
	"TInt",
	"TProg",
	"TStruct",
	"TType",
	"TUnit",
};
