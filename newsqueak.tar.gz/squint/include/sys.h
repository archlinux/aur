builtin open: 	prog(array of char, int) of int;
builtin close:	prog(int);
builtin create:	prog(array of char, int, int) of int;
builtin read:	prog(int) of array of char;
builtin write:	prog(int, array of char);
