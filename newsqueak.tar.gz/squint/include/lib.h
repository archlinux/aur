builtin abort:prog(msg:array of char);
builtin suspend:prog(msg:array of char);
builtin rand:prog() of int;
builtin strchr:prog(a:array of char, c:int) of int;
