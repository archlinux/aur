#ifndef HFATAL
#define HFATAL

void fatal(const char *fmt, ...);

#endif
