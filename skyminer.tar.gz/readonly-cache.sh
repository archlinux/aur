#!/bin/bash
#run the readonlycache binary with nohup (host /var/cache/pacman/pkg on 127.0.0.1:8080)
#nohup readonlycache > /dev/null 2>&1 &cd $pwd
readonlycache
