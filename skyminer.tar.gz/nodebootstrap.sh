#!/bin/bash
#root portion of the setup customization
set -e
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi

# backup the mirrorlist
if [ ! -f /etc/pacman.d/mirrorlist-bak ]; then
  cp /etc/pacman.d/mirrorlist /etc/pacman.d/mirrorlist-bak
fi
echo "backed up pacman mirrorlist" > ~/nodebootstrap.log

#backup pacman.conf
if [ ! -f /etc/pacman.conf-bak ]; then
  cp /etc/pacman.conf /etc/pacman.conf-bak
fi
echo "backed up pacman.conf" >> ~/nodebootstrap.log

HOST_NAME=$(cat /etc/hostname)
if [ $HOST_NAME == *"alarm"*  ]; then
echo "Skyminer node setup"
echo "Setting hostname, please enter a unique identifier for this node"
read -p "A number between 1 and 8 is recommended: " -r
HOST_NAME=${REPLY}
echo "node$HOST_NAME" > /etc/hostname
#else
#echo "$HOST_NAME" > /etc/hostname
#fi
echo "hostname set to node$HOST_NAME" >> ~/nodebootstrap.log
fi

if [ ! -z $1 ]; then
SKYMGRIP=${1}
fi

if [ -z $SKYMGRIP ]; then
  set -e
#prompt to enter sky manager IP address
read -p "Please input sky manager IP address: " -r
SKYMGRIP=${REPLY}
fi
echo "configuring with skymanager ip: $SKYMGRIP" >> ~/nodebootstrap.log
#set the manager IP as a mirror for pacman to retrieve updates from
echo  "$(echo "Server = http://$SKYMGRIP:8080" | cat - /etc/pacman.d/mirrorlist-bak)" > /root/mirrorlist
mv /root/mirrorlist /etc/pacman.d/mirrorlist
echo "added skymanager as an update mirror in /etc/pacman.d/mirrorlist" >> ~/nodebootstrap.log

#add the skyminer repo to pacman.conf
cat /etc/pacman.conf-bak > /root/pacman.conf
echo -e "
[skyminer]
SigLevel = PackageOptional
Server = http://$SKYMGRIP:8080
" >> /root/pacman.conf
mv /root/pacman.conf /etc/pacman.conf
echo "added skyminer repo in /etc/pacman.conf" >> ~/nodebootstrap.log

#boilerplate archlinux setup
pacman-key --init
echo "initialized pacman keyring" >> ~/nodebootstrap.log
pacman-key --populate
echo "populated pacman keyring" >> ~/nodebootstrap.log

#sync the repos
pacman -Syy
echo "synced pacman databases" >> ~/nodebootstrap.log

#update the keyring first to avoid errors from missing keys
pacman -S archlinux-keyring --noconfirm
echo "reinstalled archlinux keyring" >> ~/nodebootstrap.log

#install skywire from the skyminer repo on the manager
yes | pacman -S skywire --noconfirm
echo "skywire installed from skyminer repo" >> ~/nodebootstrap.log

#run the setup scripts provided by the skywire package
skywire-setuser
skywire-node-setup $SKYMGRIP
echo "node configured with manager address $SKYMGRIP " >> ~/nodebootstrap.log

#enable node service
systemctl enable skywire-node.service
echo "enabled skywire-node.service" >> ~/nodebootstrap.log

#install macchanger, create and enable a systemd service or MAC address will be 36:c9:e3:f1:b8:05
pacman -S macchanger --noconfirm
echo "installed macchanger" >> ~/nodebootstrap.log

systemctl enable macchanger.service
echo "enabled macchanger.service" >> ~/nodebootstrap.log

#full system update
yes | pacman -Syu --noconfirm
echo "system fully updated" >> ~/nodebootstrap.log
echo "skywire node configuration completed" >> ~/nodebootstrap.log
echo "$date" >> ~/nodebootstrap.log
echo "rebooting now" >> ~/nodebootstrap.log

#reboot for stablity because the kernel was probably updated
reboot now
