#!/bin/bash
#root portion of the setup customization
set -e

if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi

#set hostname to skymanager
echo "skymanager" > /etc/hostname
echo "Hostname changed to skymanager" >> /root/skybootstrap.log
set +e
TESTARCH=$(uname -m | grep x86_64)
if [[ $TESTARCH == *"x86_64"* ]]; then
  echo "achitecture x86_64 detected, skipping mirrorlist configuration"
else
#the automatic mirror was not working last I checked
echo -e '# New Jersey' > /root/mirrorlist
echo -e 'Server = http://nj.us.mirror.archlinuxarm.org/$arch/$repo' >> /root/mirrorlist
echo -e "# California" >> /root/mirrorlist
echo -e 'Server = http://ca.us.mirror.archlinuxarm.org/$arch/$repo' >> /root/mirrorlist
echo -e '# Florida' >> /root/mirrorlist
echo -e 'Server = http://fl.us.mirror.archlinuxarm.org/$arch/$repo' >> /root/mirrorlist
echo -e '# Illinois' >> /root/mirrorlist
echo -e 'Server = http://il.us.mirror.archlinuxarm.org/$arch/$repo' >> /root/mirrorlist

# make sure the mirrorlist doesn't get corrupted if the script is rerun
if [ ! -f /etc/pacman.d/mirrorlist-bak ]; then
  cp /etc/pacman.d/mirrorlist /etc/pacman.d/mirrorlist-bak
  cat /etc/pacman.d/mirrorlist-bak >> /root/mirrorlist
else
  cat  /etc/pacman.d/mirrorlist-bak >> /root/mirrorlist
fi
mv  /root/mirrorlist /etc/pacman.d/mirrorlist
fi
echo "patched /etc/pacman.d/mirrorlist" >> /root/skybootstrap.log
set -e

systemctl enable fixinternet.service
echo "enabled fixinternet.service" >> /root/skybootstrap.log

systemctl start fixinternet.service
echo "started fixinternet.service" >> /root/skybootstrap.log

#boilerplate archlinux setup
pacman-key --init
echo "initialized pacman keyring" >> /root/skybootstrap.log
pacman-key --populate
echo "populated pacman keyring" >> /root/skybootstrap.log

#sync the repos
pacman -Syy
echo "pacman databases synced" >> /root/skybootstrap.log

#update the keyring first to avoid errors from missing keys
pacman -S archlinux-keyring --noconfirm
echo "reinstalled archlinux keyring" >> /root/skybootstrap.log

#install a few things needed for makepkg
yes | pacman -S base-devel git sudo --needed --noconfirm
echo "installed base-devel packages git and sudo" >> /root/skybootstrap.log

#install macchanger, create and enable a systemd service or MAC address will be 36:c9:e3:f1:b8:05
pacman -S macchanger --noconfirm --needed
echo "installed macchanger" >> /root/skybootstrap.log

systemctl enable macchanger.service
echo "enabled macchanger service" >> /root/skybootstrap.log

#set easy sudo for user portion of configuration
ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
wfile=/etc/sudoers
wfile1=/etc/sudoers-bak
wfile2=/root/sudoers
if [ ! -f $wfile1 ]; then
  cp $wfile $wfile1
  cp -a $wfile1 $wfile2
  echo "$ISO_USER ALL=(ALL:ALL) NOPASSWD:ALL" >> $wfile2
  mv $wfile2 $wfile
else
  cp -a $wfile1 $wfile2
  echo "$ISO_USER ALL=(ALL:ALL) NOPASSWD:ALL" >> $wfile2
  mv $wfile2 $wfile
fi

echo "sudo permissions granted to $ISO_USER" >> /root/skybootstrap.log
#run the user portion of the configuration - makepkg cannot be run as root
su -c "skybootstrap-alarm" $ISO_USER
