#!/bin/bash
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi
#build the readonlycache binary and symlink to /usr/bin (required for readonly-cache.service)
if [ ! -f /usr/lib/skycoin/go/bin/readonlycache ]; then
  cd /usr/lib/skycoin/go/bin/
  go build /usr/lib/skycoin/skyminer/readonlycache.go
  ln -f /usr/lib/skycoin/go/bin/readonlycache /usr/bin/readonlycache
fi
