#!/bin/bash
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi
#add all packages in yay's cache to custom local repo and symlink them to pacman's cache
repo-add -n /var/lib/pacman/sync/skyminer.db.tar.gz /home/*/.cache/yay/*/*.pkg.tar.xz
ln -f /var/lib/pacman/sync/* /var/cache/pacman/pkg/
ln -f /home/*/.cache/yay/*/*.pkg.tar.xz /var/cache/pacman/pkg/
