#!/bin/bash
#user portion of the setup customization
#rerun to update AUR packages
set -e
if [[ $EUID -eq 0 ]]; then
   echo "Please do not run this script as root." 1>&2
   exit 100
fi
echo "$date" >> ~/skybootstrap-alarm.log

package=yay-git
if pacman -Qi $package > /dev/null ; then
  echo "$package is installed, rebuilding to the latest commits with:"
  echo "yay -S $package"
  yay -S --noconfirm $package
else
  echo "$package is not installed, manually building"
  #clone the build dir for yay-git to it's future package cache
mkdir -p ~/.cache/yay/ && cd ~/.cache/yay/
echo "git clone https://aur.archlinux.org/$package"
git clone https://aur.archlinux.org/$package
echo "cd $package"
cd $package
echo "mkepkg -scif"
yes | makepkg -scif --noconfirm
cd ~/
echo "$package installed"
fi
echo "installed yay-git" >> ~/skybootstrap-alarm.log
#install skywire with yay
package=skywire
if pacman -Qi $package > /dev/null ; then
  echo "$package is installed, rebuilding with the latest commits with:"
  echo "yay -S $package"
  yay -S --noconfirm $package
else
  echo "installing $package now with:"
  echo "yay -S $package"
  yay -S --noconfirm $package
fi
echo "installed skywire with yay" >> ~/skybootstrap-alarm.log


sudo skywire-setuser $(whoami)
echo "configured skywire systemd service to run as $whoami" >> ~/skybootstrap-alarm.log

#enable skywire-manager systemd service
sudo systemctl enable skywire-manager.service
echo "enabled skywire-manager.service" >> ~/skybootstrap-alarm.log

#sync databases before upgrade
sudo pacman -Syy
echo "synced package databases" >> ~/skybootstrap-alarm.log

#packages in yay's cache are added to the skyminer local repo hosted by the manager
sudo skyminer-repo-update
echo "added packages to skyminer repo" >> ~/skybootstrap-alarm.log

#enable the service to host these on the LAN
sudo readonly-cache-setup
sudo systemctl enable readonly-cache.service
echo "enabled readonly-cache.service" >> ~/skybootstrap-alarm.log

#systemctl daemon-reload
#full system update
yes | sudo pacman -Syu --noconfirm
echo "system fully updated" >> ~/skybootstrap-alarm.log
echo "$date" >> ~/skybootstrap-alarm.log

#reboot
sudo reboot now
