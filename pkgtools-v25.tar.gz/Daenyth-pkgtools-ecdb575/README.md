This is a collection of scripts for Arch Linux packages.

This repository contains the following scripts:
	- newpkg
	- spec2arch
	- pkgconflict
	- whoneeds
	- pkgclean
	- maintpkg
	- pip2arch
