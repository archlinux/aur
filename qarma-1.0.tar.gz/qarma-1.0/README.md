qarma
=====

Zenity Clone for Qt4/Qt5

Q: Why do you waste time cloning a perfectly fine tool?

A:
"The answer is that GTK+ is primarily intended to be used on the GNOME desktop"
"GTK+ must focus on being the toolkit of the GNOME platform first, and tackle integration second."

                                            --- https://lwn.net/Articles/562856/

http://blogs.gnome.org/mclasen/2014/03/21/dialogs-in-gtk-3-12/

Q: Does the name mean anything?
A: Yes.