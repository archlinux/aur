#!/bin/bash
# Simona Pisano - 2018-11-18 -
# simona-scripts
# Libertamente utilizzabile sotto GPL v3

  #srun-mount-img() {

    # ------------------------------------------------------------------------------------------------------------------------
    # INPUT PARAMETER --------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------------

    allow_formats="raw qcow2 vdi blkdebug blklogwrites blkreplay blkverify bochs cloop copy-on-read dmg file ftp ftps gluster host_cdrom host_device http https iscsi iser luks nbd nfs null-aio null-co nvme parallels qcow qed quorum rbd replication sheepdog ssh throttle vhdx vmdk vpc vvfat"
    allow_formats_iso="iso nrg bin img mdf"
    allow_formats_crypto="tcrypt plain luks luks1 luks2 loopaes"

    if [[ $1 == "-h" || $1 == "--help" ]] ; then
      echo "Sintax 1: srun-mount-img [--help|-h]"
      echo "Sintax 2: srun-mount-img [path/]file-name.ext] [format | part#] [mount-path | part#] [--force-iso-stdmount]"
      echo "           --force-iso-stdmount   -> forse in iso sudo mount 'mount -o loop' instead 'fuseiso'"
      echo "Warning 1: part# in in format 0-9 with one integer value"
      echo "Warning 2: format must be explicily specified if file extension do not say itself the correct format."
      echo "Warning 3: all parameters are case sensitive."
      echo "Default: srun-mount-img image.raw raw 0 \${HOME}/mount/image"
      echo "Minimal: srun-mount-img file.ext"
      echo "Typical: srun-mount-img file.ext 2"
      echo "Allowed formats: ${allow_formats} ${allow_formats_iso} ${allow_formats_crypto}"
      return 0
    fi

    # DEFAULTS -------------------------------------------------------------------------------------------------------------
    full_path_image="image.raw"
    n_part=0
    #n_part=2
    mount_where="$HOME/mount/image"
    format="" #something required (no default allowed)

    # PARS -----------------------------------------------------------------------------------------------------------------
    #parameter $1: name file used as image
    par=$1; [[ $1 != "" && ${par:0:1} != "-" ]] && full_path_image=$1
    image="${full_path_image##*/}" # estract substring: take only final part after last '/' char
    [[ ! -f "$full_path_image" ]] && { echo "*None* *to* *do*: file image $full_path_image not found!! Exit."; return 1; }

    ext="${image##*.}" # extract substring: take only final part after last '.' char
    [[ $ext != "" ]] && format=$ext

    #parameter $2: format or partition number
    case $2 in
      [0-9]* ) n_part=$2 ;;
      [a-z]* ) format=$2 ;;
    esac

    #parameter $3: mount path or partition number
    case $3 in
      [0-9]* ) n_part=$3 ;;
      * ) par=$3; [[ $3 != "" && ${par:0:1} != "-" ]] && format=$3 ;;
    esac

    [[ $format == "" ]] && { echo "[ERR] Format missing. Please insert it as second par. Exit."; return 1; }
    if [[ ! $allow_formats =~ $format && ! $allow_formats_iso =~ $format && ! $allow_formats_crypto =~ $format ]] ; then
      echo "[ERR] Format $format unknown or not supported. Sorry. Exit."
      return 1
    fi

    #parameter 4: mount path
    par=$4; [[ $4 != "" && ${par:0:1} != "-" ]] && mount_where=$4

    [[ ! -d $mount_where ]] && { echo "[NOTE] Please create $mount_where with 'mkdir -p $mount_where'. Exit."; return 1; }

    #display default
    [[ $full_path_image == "image.raw" ]] && echo "Default: 'image.raw' image file"
    [[ $allow_formats =~ $format && $n_part == 0 ]] && echo "Default: partition number 0"
    [[ $mount_where == "$HOME/mount/image" ]] && echo "Default: '$HOME/mount/image' dir where mount image"

    [[ -d "$mount_where/$image" ]] && { echo "[ERR] $image found. umount/rm -r \"$mount_where/$image\". Exit."; return 1; }

    forceIsoStdMount=false #default par
    while [ $# -ne 0 ] ; do
      arg="$1"
      case "$arg" in
        --force-iso-stdmount) forceIsoStdMount=true ;;
        *) ;;
      esac
      shift
    done

    # ------------------------------------------------------------------------------------------------------------------------
    # WORK -------------------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------------

    # vm images -----------------------------------------------------------------------------------------------------------
    if [[ $allow_formats =~ $format ]] ; then

      [[ ! -r /bin/qemu-nbd ]] && { echo "[ERR] Missing qemu-nbd cmd! Exit"; return 1; }

      sudo modprobe nbd max_part=63
      [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'modprobe nbd max_part=63'! Exit."; return 1; }
      echo "nbd module prepared..."

      sudo qemu-nbd -c /dev/nbd0 --format=$format "$full_path_image"
      [[ $? -ne 0 ]] && { echo "[ERR] No exec 'qemu-nbd -c /dev/nbd0 --format=$format \"$full_path_image\"'! Exit."; return 1; }
      echo "qemu nbd started..."

      mkdir -p "$mount_where/$image"
      if [ $? -ne 0 ]; then
        sudo qemu-nbd -d /dev/nbd0 >/dev/null #undo
        [[ $? -ne 0 ]] && echo "[WARNING] Can't exec cmd 'qemu-nbd -d /dev/nbd0'!" || echo "qemu nbd stopped..."
        echo "[ERR] Can't create dir $mount_where/$image! Exit."
        return 1
      fi

      if [[ n_part -eq 0 ]] ; then
        #ls /dev/nbd0p?
        #echo -n "* "; for dev_part in /dev/nbd0p* ; do echo $dev_part; done
        #echo -n "? "; for dev_part in /dev/nbd0p? ; do echo $dev_part; done
        #echo -n "[0-9] "; for dev_part in /dev/nbd0p[0-9] ; do echo $dev_part; done
        #return
        for dev_part in /dev/nbd0p[0-9] ; do
          part=${dev_part:10:1} # estrae substring: dopo n-esimo carattere (0 based) per N caratteri
          mkdir -p "$mount_where/$image/$part"
          if [ $? -ne 0 ]; then
            echo "[WARNING] Can't create dir $mount_where/$image/$part and mount part $part..."
          els
            sudo mount $dev_part "$mount_where/$image/$part"
            if [ $? -ne 0 ]; then
              sudo qemu-nbd -d /dev/nbd0 >/dev/null #undo
              [[ $? -ne 0 ]] && echo "[WARNING] Can't exec cmd 'qemu-nbd -d /dev/nbd0'!" || echo "qemu nbd stopped..."
              #rmdir -r "$mount_where/$image" #undo
              #[ $? -ne 0 ] && echo "Can't execute command 'rmdir $mount_where/$image'!"
              echo "[ERR] Can't exec cmd 'mount $dev_part $mount_where/\"$image/$part\"'! Exit."
              return 1
            fi
          fi
          echo "Mount $dev_part ... [part# $part] on $mount_where/$image/$part done."
        done
      else
        sudo mount /dev/nbd0p$n_part "$mount_where/$image"
        if [ $? -ne 0 ]; then
          sudo qemu-nbd -d /dev/nbd0 >/dev/null #undo
          [[ $? -ne 0 ]] && echo "[WARNING] Can't exec cmd 'qemu-nbd -d /dev/nbd0'!" || echo "qemu nbd stopped..."
          rmdir "$mount_where/$image" #undo
          [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'rmdir $mount_where/$image'!"
          echo "[ERR] Part num $n_part really exist? Can't mount /dev/nbd0p$n_part on $mount_where/\"$image\"'! Exit."
          return 1
        fi
        echo "Mount /dev/nbd0p$n_part ... [partition $n_part] on $mount_where/$image done."
      fi

    # iso images ----------------------------------------------------------------------------------------------------------
    elif [[ $allow_formats_iso =~ $format ]] ; then
      iso_mount_type=""
      if [[ -r /bin/fuseiso && "$forceIsoStdMount" != true ]] ; then

        mkdir -p "$mount_where/$image"
        [[ $? -ne 0 ]] && { echo "[ERROR] Can't create dir $mount_where/$image! Exit."; return 1; }

        fuseiso "$full_path_image" "$mount_where/$image"
        if [ $? -ne 0 ]; then
          rmdir "$mount_where/$image" #undo
          [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'rmdir $mount_where/$image'!"
          echo "[ERR] Can't exec cmd 'fuseiso "$full_path_image" /mnt'! Exit."
          return 1
        fi
        echo "Mount (fuseiso) $mount_where/$image done."
        iso_mount_type="fuseiso"
      else

        mkdir -p "$mount_where/$image"
        [[ $? -ne 0 ]] && { echo "[ERROR] Can't create dir $mount_where/$image! Exit."; return 1; }

        sudo mount -o loop "$full_path_image" "$mount_where/$image"
        if [ $? -ne 0 ]; then
          rmdir "$mount_where/$image" #undo
          [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'rmdir $mount_where/$image'!"
          echo "[ERR] Can't exec cmd 'mount -o loop \"$full_path_image\" \"$mount_where/$image\"'! Exit."
          return 1
        fi

        echo "Mount (sudo mount loop) $mount_where/$image done."
        iso_mount_type="mount-loop"

      fi

    # crypto images -------------------------------------------------------------------------------------------------------
    elif [[ $allow_formats_crypto =~ $format ]] ; then

      [[ ! -r /bin/cryptsetup ]] && { echo "[ERR] Missing cryptsetup cmd! Exit"; return 1; }

      mkdir -p "$mount_where/$image"
      [[ $? -ne 0 ]] && { echo "[ERR] Can't create dir $mount_where/$image! Exit."; return 1 ; }

      sudo cryptsetup open --type $format "$full_path_image" crypt-disk
      if [ $? -ne 0 ]; then
        rmdir "$mount_where/$image" #undo
        [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'rmdir $mount_where/$image'!"
        echo "[ERR] Can't exec cmd 'cryptsetup open --type $format \"$full_path_image\" crypt-disk'!"
        return 1
      fi
      sudo mount -o uid=1000 /dev/mapper/crypt-disk "$mount_where/$image"
      if [ $? -ne 0 ]; then
        sudo cryptsetup close crypt-disk #undo
        [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'cryptsetup close crypt-disk'!"
        rmdir "$mount_where/$image" #undo
        [ $? -ne 0 ] && echo "[WARNING] Can't exec cmd 'rmdir $mount_where/$image'!"
        echo "[ERR] Can't exec cmd 'mount -o uid=1000 /dev/mapper/crypt-disk \"$mount_where/$image\"'!"
        return 1
      fi

      echo "Mount 'pwd-crypt..."
    fi

    cd "$mount_where/$image"
    [[ $? -ne 0 ]] && { echo "[ERROR] Can't exec cmd 'cd \"$mount_where/$image\"'! Exit."; return 1; }

    start_evid="\e[1;39;41m"
    stop_evid="\e[0m"
    exit_string="Done. [MEMO] Dont' forget to use ${start_evid}srun-umount-img \"${image}\""
    [[ $format != $ext ]] && exit_string="${exit_string} ${format}"
    [[ $iso_mount_type == "mount-loop" && "$forceIsoStdMount" == true ]] && exit_string="${exit_string} --force-iso-stdmount"
    exit_string="${exit_string}${stop_evid} when finished."
    echo -e "$exit_string"
    return 0
  #}

