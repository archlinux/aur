#!/bin/bash
# Simona Pisano - 2018-11-18 -
# simona-scripts
# Libertamente utilizzabile sotto GPL v3

echo "simona-scripts - GPL v3 license"
echo "image-mount.sh"
echo "image-umount.sh"
echo "pendrive-detect.sh   - detect a pendrive"
echo "ioscheduler-list.sh"
echo "boot-kernel-list.sh"

