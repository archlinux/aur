#!/bin/bash
# Simona Pisano - 2018-11-18
# simona-scripts
# Libertamente utilizzabile sotto GPL v3

  #srun-umount-img() {

    if [[ $1 == "-h" || $1 == "--help" ]] ; then
      echo "Sintax 1: srun-umount-img [--help|-h]"
      echo "Sintax 2: srun-umount-img reset [path]"
      echo "Sintax 3: srun-umount-img image.ext [format] [mount-path] [--force-iso-stdmount]"
      echo "        --force-iso-stdmount   -> forse in iso mount 'mount -o loop' instead 'fuseiso'"
      echo "Warning: format must be explicily specified if file extension do not say itself the correct format."
      echo "Warning: all parameters are case sensitive."
      echo "Default: srun-mount-img image.raw raw 0 \$HOME/mount/image"
      echo "Minimal: srun-mount-img file.ext"
      echo "Typical: srun-mount-img file.ext 2"
      echo "Allowed formats: $allow_formats $allow_formats_iso $allow_formats_crypto"
      return 0
    fi

    if [[ $1 == "reset" ]] ; then
      mount_where="$HOME/mount/image" #default
      [[ $2 != "" ]] && mount_where=$2
      cd "$mount_where"
      [[ $? -ne 0 ]] && echo "[ERR] Can't 'cd \"$mount_where\"'! Reset so don't Exit."
      if [[ -r /bin/qemu-nbd ]] ; then
        sudo qemu-nbd -d /dev/nbd0 >/dev/null
        [[ $? -ne 0 ]] && echo "qemu-nbd test: 'qemu-nbd -d /dev/nbd0' fail." || echo "qemu nbd stopped..."
      fi
      if [[ -r /bin/fuseiso ]] ; then
        for dir in "$mount_where" ; do
          fusermount -u "$dir"
          [[ $? -ne 0 ]] && echo "fusemount -u test: 'fusemount -u \"$dir\"' fail." || echo "fusemount ok"
        done
      fi
      if [[ -r /bin/cryptsetup ]] ; then
        sudo cryptsetup close crypt-disk
        [[ $? -ne 0 ]] && echo "cryptsetup test: Can't close."
      fi
      for dir in "$mount_where" ; do
        sudo umount "$dir"
        [[ $? -ne 0 ]] && echo "umount test: \"$dir\" fail." || echo "umount ok"
      done
      sudo umount "$mount_where"
      [[ $? -ne 0 ]] && echo "Can't 'umount \"$mount_where\"'! Reset so don't Exit."
      return 0
      echo "Done."
    fi

    # ------------------------------------------------------------------------------------------------------------------------
    # INPUT PARAMETER --------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------------

    allow_formats="raw qcow2 vdi blkdebug blklogwrites blkreplay blkverify bochs cloop copy-on-read dmg file ftp ftps gluster host_cdrom host_device http https iscsi iser luks nbd nfs null-aio null-co nvme parallels qcow qed quorum rbd replication sheepdog ssh throttle vhdx vmdk vpc vvfat"
    allow_formats_iso="iso nrg bin img mdf"
    allow_formats_crypto="tcrypt plain luks luks1 luks2 loopaes"

    #þarameter $1
    full_path_image="image.raw" #default
    par=$1
    if [[ $1 != "" && ${par:0:1} != "-" ]] ; then
      full_path_image=$1
    else
      echo "Default: 'image.raw' image file"
    fi
    image="${full_path_image##*/}" # estract substring: take only final string after last /
    ext="${image##*.}" #estract sbustring: take only final string aster last .

    #þarameter $2
    format="" #no default
    par=$2
    if [[ $2 != "" && ${par:0:1} != "-" ]] ; then
      format=$2
    else
      [[ $ext != "" ]] && format=$ext
    fi

    [[ $format == "" ]] && { echo "[ERROR] Format missing. Insert as second par. Exit."; return 1; }

    #þarameter $3
    mount_where="$HOME/mount/image" #default
    [[ $3 != "" ]] && mount_where=$3

    [[ ! -d "$mount_where/$image" ]] && { echo "*None* *to* *do*. Dir $mount_where/$image do not exist!! Exit."; return 1; }

    forceIsoStdMount=false #default par
    while [ $# -ne 0 ] ; do
      arg="$1"
      case "$arg" in
        --force-iso-stdmount) forceIsoStdMount=true ;;
        *) ;;
      esac
      shift
    done

    # ------------------------------------------------------------------------------------------------------------------------
    # WORK -------------------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------------------------

    #before exit for mounted directory if inside
    if [[ $PWD == "$mount_where/$image" ]] ; then
      cd "$mount_where"
      [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'cd \"$mount_where\"'! Exit."; return 1; }
    fi

    # vm images -----------------------------------------------------------------------------------------------------------
    if [[ $allow_formats =~ $format ]] ; then

      [[ ! -r /bin/qemu-nbd ]] && { echo "[ERR] Missing qemu-nbd cmd! Exit"; return 1; }

      sudo umount "$mount_where/$image"
      [[ ! -d "$mount_where/$image" ]] && echo "umount $mount_where/$image done." || echo "Can't umount $mount_where/$image!!"

      sudo qemu-nbd -d /dev/nbd0 >/dev/null
      [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'qemu-nbd -d /dev/nbd0'! Exit."; return 1; }
      echo "qemu nbd stopped..."

    # iso images ----------------------------------------------------------------------------------------------------------
    elif [[ $allow_formats_iso =~ $format ]] ; then

      if [[ -r /bin/fuseiso && "$forceIsoStdMount" != true ]] ; then

        fusermount -u "$mount_where/$image"
        [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'fusemount -u \"$mount_where/$image\"'! Exit."; return 1; }
        echo "umount (fusermount -u) $mount_where/$image done."

      else

        sudo umount "$mount_where/$image"
        [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'umount \"$mount_where/$image\"'! Exit."; return 1; }
        echo "umount (sudo umount loop) $mount_where/$image done."

      fi

    # crypto images -------------------------------------------------------------------------------------------------------
    elif [[ $allow_formats_crypto =~ $format ]] ; then

      [[ ! -r /bin/cryptsetup ]] && { echo "[ERR] Missing cryptsetup cmd! Exit"; return 1; }

      sudo umount "$mount_where/$image"
      [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'umount \"$mount_where/$image\"'!"; return 1; }

      sudo cryptsetup close crypt-disk
      [[ $? -ne 0 ]] && { echo "[ERR] Can't exec cmd 'cryptsetup close crypt-disk'!"; return 1; }

      echo "Umount \"$mount_where/$image\"..."
    else
      echo "[ERR] Format $format unknown or absent. Exit."
      return 1
    fi

    for dir in $mount_where/$image/[0-9] ; do [[ -d "$dir" ]] && rmdir "$dir"; done
    rmdir "$mount_where/$image"
    if [[ $? -ne 0 ]] ; then
      echo "[ERR] Can't exec 'rmdir $mount_where/$image'! Exit."
      sudo rm -r "$mount_where/$image"
      [[ $? -ne 0 ]] && echo "[ERR] sudo rm -r $mount_where/$image fail!" || echo "Sudo removed dir '$mount_where/$image'."
      return 1
    else
      echo "Removed dir '$mount_where/$image'."
    fi

    echo "Done."
    return 0
  #}

