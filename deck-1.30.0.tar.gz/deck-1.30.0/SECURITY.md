# Security Policy

## Supported Versions

See our [Version Compatibility Documentation](https://docs.konghq.com/kubernetes-ingress-controller/latest/references/version-compatibility/#kubernetes).

## Reporting a Vulnerability

See our [Reporting A Vulnerability Documentation](https://docs.konghq.com/enterprise/latest/kong-security-update-process/#reporting-a-vulnerability).
