package main

import (
	"encoding/json"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
	"time"
)

var logger *log.Logger

type Config struct {
	User     string
	Password string
	Url_list []string
}

func get_current_ip(cfg *Config) string {
	for _, url := range cfg.Url_list {
		client := http.Client{Timeout: 30 * time.Second}

		resp, err := client.Get(url)
		if err != nil {
			logger.Println("Unable to connect on \""+url+"\":", err)
			continue
		}
		defer resp.Body.Close()

		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			logger.Println("Unable to read internet page:", err)
			continue
		}
		return strings.Trim(string(body), "\n")
	}

	logger.Fatal("Unable to get internet IP address !")

	return ""
}

func load_conf(conf_file *string) *Config {
	var conf Config

	file, err := ioutil.ReadFile(*conf_file)
	if err != nil {
		logger.Fatal("Unable to read file config:", err)
	}
	json.Unmarshal(file, &conf)

	return &conf
}

func load_old_ip(file *string) string {
	ip, err := ioutil.ReadFile(*file)
	if err != nil {
		return ""
	}

	return string(ip)
}

func setting_logging(log_file *string) *os.File {
	var fd *os.File

	fd, err := os.OpenFile(*log_file, os.O_WRONLY|os.O_APPEND|os.O_CREATE, 0644)
	if err != nil {
		log.Fatal("Unable to open \""+*log_file+"\":", err)
	}

	log.SetOutput(fd)
	logger = log.New(io.MultiWriter(fd, os.Stdout), "", log.Ldate|log.Lshortfile|log.Ltime)

	return fd
}

func update_hopper_if_needed(cfg *Config, ip_file *string, old_ip *string, current_ip *string) {
	if *old_ip != *current_ip {
		client := http.Client{Timeout: 30 * time.Second}
		url := "http://" + cfg.User + ":" + cfg.Password + "@ipv4.www.hopper.pw/nic/update"

		resp, err := client.Get(url)
		if err != nil {
			logger.Fatal("Unable to connect on \""+url+"\":", err)
		}
		defer resp.Body.Close()

		body, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			logger.Fatal("Unable to get internet page:", err)
		}

		if strings.Contains(string(body), "nochg") || strings.Contains(string(body), "good") {
			if err := ioutil.WriteFile(*ip_file, []byte(*current_ip), 0644); err != nil {
				logger.Fatal("Unable to write into \""+*ip_file+"\":", err)
			}

		} else {
			logger.Fatal("Identification failure when updating IP:", string(body))
		}
	} else {
		logger.Println("Nothing to do")
	}
}

func main() {
	conf_file := "/etc/hopper_update/hopper_update.json"
	old_ip_file := "/var/log/hopper_update/old_ip_file"
	log_file := "/var/log/hopper_update/errors.log"

	/*
		conf_file := "hopper_update.json"
		old_ip_file := "old_ip_file.txt"
		log_file := "errors.log"
	*/

	fd_log := setting_logging(&log_file)
	defer fd_log.Close()

	cfg := load_conf(&conf_file)
	old_ip := load_old_ip(&old_ip_file)
	current_ip := get_current_ip(cfg)
	update_hopper_if_needed(cfg, &old_ip_file, &old_ip, &current_ip)
}
