# Audio Attribution

## chime.wav

Chime_01.wav by Andromadax24 -- https://freesound.org/s/186719/ -- License: Attribution 4.0
