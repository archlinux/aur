#
# Copyright (C) 2015  FreeIPA Contributors see COPYING for license
#

from ipaplatform.redhat.constants import RedHatConstantsNamespace, User, Group


class ArchConstantsNamespace(RedHatConstantsNamespace):
    pass


constants = ArchConstantsNamespace()
