#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rossat::rossat" for configuration "Release"
set_property(TARGET rossat::rossat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rossat::rossat PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librossat.so.1.0.1"
  IMPORTED_SONAME_RELEASE "librossat.so.1"
  )

list(APPEND _cmake_import_check_targets rossat::rossat )
list(APPEND _cmake_import_check_files_for_rossat::rossat "${_IMPORT_PREFIX}/lib/librossat.so.1.0.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
