#pragma once

#include <vector>
#include <iostream>
#include <stdio.h>

namespace terxel
{
    class Color
    {
        public:
            unsigned char r = 0;
            unsigned char g = 0;
            unsigned char b = 0;

            bool enabled = false;
    };

    class Terxel
    {
        public:
            Terxel();
            Terxel(Color first, Color second);
            void Draw();

        public:
            Color top;
            Color bottom;
    };

    class Terxture
    {
        public:
            Terxture(int width, int height);
            void SetPixel(int x, int y, Color color);
            void Draw();
        
        private:
            const int width;
            const int height;
            std::vector<Terxel> terxels;
    };
}
