g++ main.cpp -o gradient
