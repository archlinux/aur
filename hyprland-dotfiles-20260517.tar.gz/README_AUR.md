This repository includes packaging templates to create an AUR package for these Hyprland dotfiles.

Quick steps to publish to AUR

1. Update `PKGBUILD` and `.SRCINFO` `source` URLs to point to your public git repo (GitHub/GitLab).
2. Commit and push your repo.
3. Build and generate `.SRCINFO` locally:

```bash
makepkg --printsrcinfo > .SRCINFO
```

4. Create an AUR package (on aur.archlinux.org) and upload using `git` per AUR docs.

Usage after install

- The package installs files to `/usr/share/hyprland-dotfiles`.
- Run `hyprland-dotfiles-install` as your user to copy configs into `~/.config` (it prompts before overwriting).
- To help install dependencies, use the included helper to check and optionally install required packages:

```bash
# show missing packages and suggested commands
./packaging/check-deps.sh

# run and prompt to install missing required packages via pacman
./packaging/check-deps.sh --install
```

The script attempts to detect installed packages via `pacman -Qi`. For AUR-only packages, use an AUR helper such as `yay` to install them.

Notes

- Arch packages should avoid modifying arbitrary user home directories during installation; this package provides the configs in `/usr/share/` and a helper the user can run to copy files into their home.
- Adjust `pkgname`, `pkgver`, `pkgrel`, `license`, `depends`, and `url` in `PKGBUILD` as needed before publishing.
