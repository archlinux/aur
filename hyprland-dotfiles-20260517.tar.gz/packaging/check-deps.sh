#!/bin/sh
# Check for required and optional packages and print install commands.
# By default this only reports missing packages. Use `--install` to invoke
# `sudo pacman -S` for missing official packages (prompts before running).

set -e

deps="hyprland wayland"
optdeps="waybar rofi kitty"

missing_deps=""
missing_opt=""

check_pkg() {
  pkg="$1"
  if command -v pacman >/dev/null 2>&1; then
    if pacman -Qi "$pkg" >/dev/null 2>&1; then
      return 0
    else
      return 1
    fi
  else
    # If pacman not available, try to detect by command name
    if command -v "$pkg" >/dev/null 2>&1; then
      return 0
    else
      return 1
    fi
  fi
}

for p in $deps; do
  if ! check_pkg "$p"; then
    missing_deps="$missing_deps $p"
  fi
done

for p in $optdeps; do
  if ! check_pkg "$p"; then
    missing_opt="$missing_opt $p"
  fi
done

if [ -z "$missing_deps" ] && [ -z "$missing_opt" ]; then
  echo "All required and optional packages appear to be installed."
  exit 0
fi

if [ -n "$missing_deps" ]; then
  echo "Missing required packages:$missing_deps"
  echo
  echo "Install with pacman (official repos):"
  echo "  sudo pacman -S $missing_deps"
  echo
  echo "Or with an AUR helper (installs AUR packages too):"
  echo "  yay -S $missing_deps"
fi

if [ -n "$missing_opt" ]; then
  echo "Missing optional packages:$missing_opt"
  echo "Install optional packages if you want additional components:"
  echo "  sudo pacman -S $missing_opt"
fi

if [ "$1" = "--install" ] && [ -n "$missing_deps" ]; then
  printf "Run sudo pacman -S %s now? [y/N] " "$missing_deps"
  read ans
  case "$ans" in
    [yY]*) sudo pacman -S $missing_deps ;;
    *) echo "Skipped installation." ;;
  esac
fi
