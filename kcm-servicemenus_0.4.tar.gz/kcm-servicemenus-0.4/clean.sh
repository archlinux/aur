project=kcm-servicemenu 

rm -rf `find . -name "CMakeCache.txt"`
rm -rf `find . -name "*.cmake"`
rm -rf `find . -name "moc_*"`
rm -rf `find . -name "ui_*.h"`
rm -rf `find . -name "*_automoc.cpp"`
rm -rf `find . -name "*.pot"`
rm -rf `find . -name "*.moc"`
rm -rf `find . -name "*.files"`
rm -rf `find . -name "*.gmo"`
rm -rf `find . -name Makefile`
rm -rf `find . -type d -name CMakeFiles`
rm -rf install_manifest.txt
rm -rf lib

rm -rf CMakeTmp
rm -rf obj-i486-linux-gnu
rm -rf debian/tmp
rm -rf debian/$project
rm -rf debian/compat
rm -rf debian/files
rm -rf debian/stamp-makefile-build
rm -rf debian/*.debhelper.log
rm -rf debian/*.substvars




