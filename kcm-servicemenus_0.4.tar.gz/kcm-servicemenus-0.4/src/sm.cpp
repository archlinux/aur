/***************************************************************************
 *   Copyright (C) 2008 by Fabian Wuertz  				   *
 *   xadras@sdixu.com							   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/





#include <QLabel>
#include <QStringList>
#include <QTreeWidget>
#include <QLabel>
#include <QPushButton>


#include <QFile>
#include <QTextStream>

#include <QProcess>

#include <QXmlStreamReader>
#include <QXmlSimpleReader>
#include <QXmlDefaultHandler>
#include <QDomDocument>


#include <kapplication.h>
#include <kglobalsettings.h>
#include <kgenericfactory.h>
#include <kiconloader.h>
#include <kio/job.h>
#include <kio/deletejob.h>
#include <kio/netaccess.h>
#include <knewstuff2/engine.h>
#include <kmessagebox.h>
#include <kstandarddirs.h>
#include <ktar.h>
#include <kurlrequesterdialog.h>
#include <klocale.h>
#include <KDesktopFile>


#include "sm.h"



//------------------------------------------------------------------------------
//--- init ---------------------------------------------------------------------
//------------------------------------------------------------------------------

K_PLUGIN_FACTORY(SmFactory, registerPlugin<sm>();)
K_EXPORT_PLUGIN(SmFactory("kcm_servicemenus"));


sm::sm( QWidget *parent, const QVariantList &) 
	: KCModule(SmFactory::componentData(), parent)

{

	// locate directories
	homeDir = KStandardDirs::locateLocal("home", "");
	appsDir = KStandardDirs::locateLocal("data", "");
	servicesDir = KStandardDirs::locateLocal("services", "");

	if( !QFile::exists( appsDir+"/kcm_servicemenus" ) )
		QDir(appsDir).mkdir("kcm_servicemenus");
	if( !QFile::exists( appsDir+"/ServiceMenusMetadata" ) )
		QDir(appsDir).mkdir("ServiceMenusMetadata");
	if( !QFile::exists( appsDir+"/kcm_servicemenus/downloads" ) )
		QDir(appsDir+"/kcm_servicemenus").mkdir("downloads");

	addGui();
	showInstalledMenus();

}


void sm::addGui() {

	setupUi(this);

	// new button
	newButton->setIcon( KIcon("get-hot-new-stuff") );
	connect(newButton,SIGNAL(clicked()),SLOT(installInternetMenu()));

	// install button
	installButton->setIcon( KIcon("document-import") );
	connect(installButton, SIGNAL(clicked()), SLOT(installLocalMenu()));

	// remove button
	removeButton->setIcon( KIcon("edit-delete") );
	connect(removeButton,  SIGNAL(clicked()), SLOT(removeMenu()));

	// info button
	infoButton->setIcon( KIcon("help-about") );
	connect(infoButton,  SIGNAL(clicked()), SLOT(showMenuInfo()));

	// back button
	backButton->setIcon( KIcon("go-previous") );
	connect(backButton,  SIGNAL(clicked()), SLOT(back()));

	// treewidget
	treeWidget->setAllColumnsShowFocus( true );
	treeWidget->setRootIsDecorated(false);
	treeWidget->setSortingEnabled(true);
	connect(treeWidget, SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this, SLOT( showMenuInfo() ) );

	//
	connect(treeWidget_2, SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this, SLOT( showHomepage() ) );

	stackedWidget->setCurrentIndex(0);

}

void sm::showInstalledMenus() {

  
	treeWidget->clear();
	QStringList menuPaths = KGlobal::dirs()->findAllResources ("data", "ServiceMenusMetadata/*/metadata.desktop");
	foreach(QString menuPath, menuPaths) {
		KDesktopFile config(menuPath);
		KConfigGroup configGroup = config.desktopGroup();
			
		QTreeWidgetItem *item = new QTreeWidgetItem(treeWidget, 0);
		item->setText( 0, config.readName() );
		item->setText( 1, config.readComment() );

		item->setText( 2, menuPath.replace("/metadata.desktop", "") );
		item->setText( 3, configGroup.readEntry( "X-KDE-PluginInfo-Author",  "" ) );
		item->setText( 4, configGroup.readEntry( "X-KDE-PluginInfo-Email",   "" ) );
		item->setText( 5, configGroup.readEntry( "X-KDE-PluginInfo-Version", "" ) );
		item->setText( 6, configGroup.readEntry( "X-KDE-PluginInfo-Website", "" ) );
		item->setText( 7, configGroup.readEntry( "X-KDE-PluginInfo-License", "" ) );

	}
}


//------------------------------------------------------------------------------
//--- install new menus --------------------------------------------------------
//------------------------------------------------------------------------------

void sm::installLocalMenu()
{
	KUrl menuUrl = KUrlRequesterDialog::getUrl(QString(), this, i18n("Drag or type service type URL"));
	kDebug() << menuUrl.prettyUrl();
	installMenu(menuUrl);
}


void sm::installInternetMenu() {

	QStringList filesBeforeInstall = QDir( appsDir+"/kcm_servicemenus/downloads/" ).entryList( QDir::Files );

	KNS::Engine engine(this);
	if (engine.init("servicemenus.knsrc"))
		KNS::Entry::List entries = engine.downloadDialogModal(this); 

	QStringList filesAfterInstall = QDir( appsDir+"/kcm_servicemenus/downloads/" ).entryList( QDir::Files );
	for (QStringList::Iterator it = filesAfterInstall.begin(); it != filesAfterInstall.end(); ++it) {
		if( !filesBeforeInstall.contains(*it) )
		{
			QTreeWidgetItem *item = new QTreeWidgetItem(treeWidget, 0);
			item->setText( 0, *it );
			KUrl menuUrl = KUrl::fromPath(appsDir+"/kcm_servicemenus/downloads/"+*it);
			installMenu(menuUrl);
		}
	}
}

void sm::installMenu(KUrl menuUrl) {

	if (menuUrl.url().isEmpty()) return;
	
	// load tar file
	QString archiveName;
	// serviceMenuTmpFile contains the name of the downloaded file
	if (!KIO::NetAccess::download(menuUrl, archiveName, this)) {
		QString sorryText;
		if (menuUrl.isLocalFile())
		    sorryText = i18n("Unable to find the service menu archive %1.",
				menuUrl.prettyUrl());
		else
		    sorryText = i18n("Unable to download the serice menu archive;\n"
				"please check that address %1 is correct.",
				menuUrl.prettyUrl());
		KMessageBox::sorry(this, sorryText);
		return;
	}
	KTar archive(archiveName);
	archive.open(QIODevice::ReadOnly);
	const KArchiveDirectory* rootDir = archive.directory();
	QStringList entries = rootDir->entries();
	QString menuName = menuUrl.fileName().replace(".tar.gz", "").split("_")[0];


	
	int random_number = rand();
	QString tmpDir = "/tmp/kcm_servicemenus-"+QString::number(random_number)+"/";
	if( QFile::exists( tmpDir ) )
		KIO::NetAccess::del(tmpDir, NULL);

	for (QStringList::Iterator it = entries.begin(); it != entries.end(); ++it) {
		KArchiveDirectory* extractedFiles = dynamic_cast<KArchiveDirectory*>( const_cast<KArchiveEntry*>( rootDir->entry(*it)));
		if (extractedFiles == NULL) {
			// we tell back that something went wrong, but try to install as much
			// as possible
			continue;
		}
		extractedFiles->copyTo(tmpDir);
	}

	archive.close();



	// copy files
	if( !QFile::exists( homeDir+"bin" ) )
		QDir(homeDir).mkdir("bin");
	if( !QFile::exists( appsDir+"/ServiceMenusMetadata/"+menuName ) )
		QDir(appsDir+"/ServiceMenusMetadata").mkdir(menuName);
	if( !QFile::exists( servicesDir+"/ServiceMenus" ) )
		QDir(servicesDir).mkdir("ServiceMenus");

	// kcm_servicemenus
	if( QFile::exists( tmpDir+"/metadata.desktop" ) and QFile::exists( tmpDir+"bin" ) and QFile::exists( tmpDir+"desktop" )  ) {
		// copy metadata file
		QFile(tmpDir+"/metadata.desktop").copy( appsDir+"/ServiceMenusMetadata/"+menuName+"/metadata.desktop" );
		// copy bin files
		binFiles = QDir( tmpDir+"bin" ).entryList( QDir::Files );
		for ( QStringList::Iterator it = binFiles.begin(); it != binFiles.end(); ++it ) {
			QFile(tmpDir+"bin/"+*it).copy( homeDir+"bin/"+*it );
			QFile(homeDir+"bin/"+*it).setPermissions( QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner );
		}
		// copy desktop files
		desktopFiles = QDir( tmpDir+"desktop" ).entryList( QDir::Files );
		for ( QStringList::Iterator it = desktopFiles.begin(); it != desktopFiles.end(); ++it ) {
			QFile(tmpDir+"desktop/"+*it).copy( servicesDir+"ServiceMenus/"+*it );
		}
	}
	// normal service menu
	else
	{
		binFiles.clear();
		desktopFiles.clear();
		searchForFiles(tmpDir);
		writeIndex(menuUrl.fileName());
	}

	KIO::NetAccess::del(tmpDir, NULL);

	// write uninstall informations
	QFile file( appsDir+"/ServiceMenusMetadata/"+menuName+"/files.txt" );
	if ( !file.open(QIODevice::WriteOnly | QIODevice::Text) ) 
		return;
	QString files;
	for(int i = 0; i < desktopFiles.count(); i++)
		files += servicesDir+"ServiceMenus/"+desktopFiles[i]+"\n";
	for(int i = 0; i < binFiles.count(); i++)
		files += homeDir+"bin/"+binFiles[i]+"\n";
	QTextStream out(&file);
	out << files;


	showInstalledMenus();
}

//------------------------------------------------------------------------------
//--- remove installed menus ---------------------------------------------------
//------------------------------------------------------------------------------

void sm::removeMenu() {


	if ( treeWidget->selectedItems().count() < 1 ) {
		KMessageBox::information(this, i18n("Please select an entry!"));
		return;
	}
		
	
        QString menuPath = treeWidget->selectedItems().first()->text(2);

	QFile file( menuPath+"/files.txt" );
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
		return;

	QStringList remove;
	while (!file.atEnd())
		remove.append( file.readLine().replace("\n","") );

	for(int i = 0; i < remove.count(); i++) {
		QFile f1( remove[i] );
		f1.remove();
	}

	QFile f2( menuPath+"/metadata.desktop" );
	f2.remove();
	QFile f3( menuPath+"/files.txt" );
	f3.remove();


	KIO::NetAccess::del(menuPath, NULL);


	showInstalledMenus();
}


//------------------------------------------------------------------------------
//--- menu info ----------------------------------------------------------------
//------------------------------------------------------------------------------

void sm::showMenuInfo() {

	if ( treeWidget->selectedItems().count() < 1 ) {
		KMessageBox::information(this, i18n("Please select an entry!"));
		return;
	}


	stackedWidget->setCurrentIndex(1);
	treeWidget_2->clear();
	treeWidget_3->clear();
	treeWidget_4->clear();
	toolBox->setCurrentIndex(0);


	nameLabel->setText( i18n("Name") + ": " + treeWidget->selectedItems().first()->text(0) );
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("Description")  << treeWidget->selectedItems().first()->text(1)), 0);
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("Author")       << treeWidget->selectedItems().first()->text(3)), 0);
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("Author Email") << treeWidget->selectedItems().first()->text(4)), 0);
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("Version")      << treeWidget->selectedItems().first()->text(5)), 0);
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("Homepage")     << treeWidget->selectedItems().first()->text(6)), 0);
        new QTreeWidgetItem(treeWidget_2, (QStringList() << i18n("License")      << treeWidget->selectedItems().first()->text(7)), 0);

	QString menuPath = treeWidget->selectedItems().first()->text(2);
	QFile file( menuPath+"/files.txt" );
	if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
		return;

	QStringList remove;
	while (!file.atEnd())
		remove.append( file.readLine().replace("\n","") );

	for(int i = 0; i < remove.count(); i++) {
		if ( remove[i].contains(".desktop") ) {
			QTreeWidgetItem *item5 = new QTreeWidgetItem(treeWidget_3, 0);
			item5->setText( 0, remove[i] );
		}
		else {
			QTreeWidgetItem *item5 = new QTreeWidgetItem(treeWidget_4, 0);
			item5->setText( 0, remove[i] );
		}
	}
}


void sm::back() {
	stackedWidget->setCurrentIndex(0);
}


void sm::showHomepage() {
  
	if ( treeWidget_2->selectedItems().count() < 1 )
		return;
	if( treeWidget_2->selectedItems().first()->text(0) != i18n("Homepage") )
		return;
	if( treeWidget_2->selectedItems().first()->text(1) == "" )
		return;
	
	QString program = "xdg-open";
	QStringList arguments;
	arguments << treeWidget_2->selectedItems().first()->text(1);

	QProcess *myProcess = new QProcess(this);
	myProcess->start(program, arguments);
}


//------------------------------------------------------------------------------
//--- more functions -----------------------------------------------------------
//------------------------------------------------------------------------------


void sm::searchForFiles(QString input) {

	QDir inputDir = QDir(input);
      

	QStringList desktopArray = inputDir.entryList( QDir::Files );
	for ( QStringList::Iterator it = desktopArray.begin(); it != desktopArray.end(); ++it )
	{
		QString fileType = "";

		if( QString(*it).contains(".desktop") )
			fileType = "desktop";
		else if( QString(*it).contains(".pl") or QString(*it).contains(".py") or QString(*it).contains(".sh") )
			fileType = "bin";
		else if( !QString(*it).contains(".") ) {
			QFile file( input+*it );
			if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
				  return;
			QString firstLine = file.readLine();
			if ( firstLine.contains("#!") )
				  fileType = "bin";
		}

		if( fileType == "desktop" )
		{
			desktopFiles.append(*it);
			QFile(input+*it).copy( servicesDir+"ServiceMenus/"+*it );
		}
		else if( fileType == "bin" and *it != "install.sh" and *it != "installKDE4.sh" and *it != "uninstall.sh" and *it != "copyroot" and  QString(*it) != "removeroot")
		{
			binFiles.append(*it);
			QFile(input+*it).copy( homeDir+"bin/"+*it );
			QFile(homeDir+"bin/"+*it).setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
		}
	}

	QStringList dirArray = inputDir.entryList( QDir::Dirs );
	for ( QStringList::Iterator it = dirArray.begin(); it != dirArray.end(); ++it )
		if( *it != "." and *it != ".."  and !QString(*it).contains("KDE3") and !QString(*it).contains("kde3"))
			searchForFiles(input+*it+"/");
}


void sm::writeIndex(QString input) {

	QString menuName = input.replace(".tar.gz", "").split("_")[0];

	QStringList ghnsTmpFiles = QDir(appsDir+"/knewstuff2-entries.registry/").entryList( QDir::Files );
	QStringListIterator ghnsTmpFilesIterator(ghnsTmpFiles);
	bool stop = FALSE;
	while (ghnsTmpFilesIterator.hasNext() and stop == FALSE ) {
		QString filePath= appsDir+"/knewstuff2-entries.registry/"+ghnsTmpFilesIterator.next();
		QFile file(filePath);
		if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
			return;
		QTextStream stream( &file );
		if ( stream.readLine().contains(input) ) {

			// write index file
			QFile outfile( appsDir+"ServiceMenusMetadata/"+menuName+"/metadata.desktop" );
			if ( !outfile.open(QIODevice::WriteOnly | QIODevice::Text) ) 
				return;
			QString content = "[Desktop Entry]\n";

			while ( !stream.atEnd() ) {
				QString line = stream.readLine(); // line of text excluding '\n'
                                if ( line.contains( "<name") )
					content += "Name="+line.split(">")[1].split("<")[0]+"\n";
				else if( line.contains( "<author>") )
					content += "X-KDE-PluginInfo-Author="+line.split(">")[1].split("<")[0]+"\n";
				else if( line.contains( "<version>") )
					content += "X-KDE-PluginInfo-Version="+line.split(">")[1].split("<")[0]+"\n";
				else if( line.contains( "<licence>") )
					content += "X-KDE-PluginInfo-License="+line.split(">")[1].split("<")[0]+"\n";
                                else if( line.contains( "<id>") )
                                        content += "homepage=http://www.kde-apps.org/content/show.php?content="+line.split(">")[1].split("<")[0]+"\n";
			}

			QTextStream out(&outfile);
			out << content;

		}
		file.close();
	}
}




