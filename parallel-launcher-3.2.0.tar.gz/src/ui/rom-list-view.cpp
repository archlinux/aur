#include "src/ui/rom-list-view.hpp"

#include <QMenu>
#include <QHeaderView>
#include <QMessageBox>
#include <QInputDialog>
#include <cassert>
#include "src/polyfill/process.hpp"
#include "src/db/data-provider.hpp"
#include "src/core/special-groups.hpp"
#include "src/core/filesystem.hpp"
#include "src/core/retroarch.hpp"
#include "src/ui/rom-list-model.hpp"

RomListRenderer::RomListRenderer( QAbstractItemDelegate *innerDelegate ) :
	QAbstractItemDelegate( innerDelegate->parent() ),
	m_inner( innerDelegate )
{
	assert( parent() != nullptr );
}

void RomListRenderer::paint( QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index ) const {
	if( index.isValid() && !index.parent().isValid() ) {
		QStyleOptionViewItem newOption = option;
		newOption.font.setBold( true );

		const QTreeView *treeView = dynamic_cast<const QTreeView*>( parent() );
		assert( treeView != nullptr );

		int width = 0;
		const int numColumns = treeView->model()->columnCount();
		for( int i = 0; i < numColumns; i++ ) {
			width += treeView->columnWidth( i );
		}

		newOption.rect.setWidth( width );
		m_inner->paint( painter, newOption, index );
	} else {
		m_inner->paint( painter, option, index );
	}
}

QSize RomListRenderer::sizeHint( const QStyleOptionViewItem &option, const QModelIndex &index ) const {
	QSize size = m_inner->sizeHint( option, index );
	if( index.isValid() && !index.parent().isValid() ) {
		size.setWidth( 0 );
	}
	return size;
}

RomListView::RomListView( QWidget *parent ) : QTreeView( parent ) {
	setModel( new RomListModel( this ) );
	setContextMenuPolicy( Qt::CustomContextMenu );
	setItemDelegate( new RomListRenderer( itemDelegate() ) );
	header()->setSectionResizeMode( QHeaderView::Stretch );
	header()->setSectionResizeMode( 0, QHeaderView::Stretch );
	header()->setSectionResizeMode( 1, QHeaderView::ResizeToContents );
	header()->setSectionResizeMode( 2, QHeaderView::Interactive );
	header()->setSectionResizeMode( 3, QHeaderView::ResizeToContents );
	header()->setSectionResizeMode( 4, QHeaderView::ResizeToContents );
	header()->setSectionsMovable( false );
	header()->setStretchLastSection( false );

	connect( this, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(onRightClick(const QPoint &)) );
	connect( this, SIGNAL(doubleClicked(const QModelIndex &)), this, SLOT(onDoubleClick(const QModelIndex &)) );
}

RomListView::~RomListView() {
	model()->deleteLater();
}

void RomListView::refetchAll() {
	TreeUiState uiState = saveTreeState();
	static_cast<RomListModel*>( model() )->fullUpdate();
	restoreTreeState( uiState );
}

void RomListView::updateRomInfo( const RomInfo &romInfo, bool nameChanged, bool playTimeChanged ) {
	TreeUiState uiState = saveTreeState();
	static_cast<RomListModel*>( model() )->partialUpdate( romInfo, nameChanged, playTimeChanged );
	restoreTreeState( uiState );
}

RomReference RomListView::tryGetSelectedRom() const {
	return static_cast<RomListModel*>( model() )->tryGetRom( currentIndex() );
}

bool RomListView::hasRoms() const {
	return static_cast<RomListModel*>( model() )->hasRoms();
}

bool RomListView::selectRom( const string &group, const fs::path &rom ) {
	const QModelIndex index = static_cast<const RomListModel*>( model() )->tryGetIndex( group, rom );
	if( index.isValid() ) {
		setCurrentIndex( index );
		return true;
	}
	return false;
}

static constexpr char ACTION_DELETE_SAVE = 1;
static constexpr char ACTION_EDIT_SAVE = 2;
static constexpr char ACTION_ADD_GROUP = 3;
static constexpr char ACTION_CREATE_GROUP = 4;
static constexpr char ACTION_REMOVE_GROUP = 5;
static constexpr char ACTION_OPEN_FOLDER = 6;
static constexpr char ACTION_DELETE_ROM = 7;
static constexpr char ACTION_RENAME_ROM = 8;
static constexpr char ACTION_REVERT_NAME = 9;

static inline QVariant serializeAction( char actionType ) {
	char idStr[] = { actionType, '\0' };
	return QVariant::fromValue<QString>( QString( idStr ) );
}

static QVariant serializeAction( char actionType, const string &additonalData ) {
	char idStr[] = { actionType, '\0' };
	return QVariant::fromValue<QString>( QString( idStr ).append( additonalData.c_str() ) );
}

void RomListView::onRightClick( const QPoint &point ) {
	const QModelIndex romEntry = indexAt( point );
	if( !romEntry.isValid() ) return;
	this->setCurrentIndex( romEntry );

	RomReference rom = tryGetSelectedRom();
	if( rom.file == nullptr ) return;

	const std::vector<string> allGroups = DataProvider::fetchAllGroups();
	const fs::path saveFilePath = RetroArch::getSaveFilePath( rom.file->path );
	const string group = static_cast<const RomListModel*>( model() )->tryGetGroup( romEntry.parent() );

	QMenu contextMenu( this );
	if( fs::isRegularFileSafe( saveFilePath ) ) {
		contextMenu.addAction( "Delete Save File" )->setData( serializeAction( ACTION_DELETE_SAVE ) );
		contextMenu.addAction( "[SM64] Edit Save File" )->setData( serializeAction( ACTION_EDIT_SAVE ) );
		contextMenu.addSeparator();
	}

	bool existingGroupOptions = false;
	QMenu *tagMenu = contextMenu.addMenu( "Add to..." );
	for( const string &romGroup : allGroups ) {
		if( romGroup == group ) continue;
		existingGroupOptions = true;
		tagMenu->addAction( GroupName::localize( romGroup ) )->setData( serializeAction( ACTION_ADD_GROUP, romGroup ) );
	}
	if( existingGroupOptions ) tagMenu->addSeparator();
	tagMenu->addAction( "New Group" )->setData( serializeAction( ACTION_CREATE_GROUP ) );

	if( !group.empty() && group != SpecialGroups::Uncategorized ) {
		contextMenu.addAction( GroupName::localize( group ).prepend( "Remove from " ) )->setData( serializeAction( ACTION_REMOVE_GROUP ) );
	}

	contextMenu.addSeparator();
	contextMenu.addAction( "Open Containing Folder" )->setData( serializeAction( ACTION_OPEN_FOLDER ) );
	contextMenu.addAction( "Delete ROM" )->setData( serializeAction( ACTION_DELETE_ROM ) );
	contextMenu.addAction( "Rename" )->setData( serializeAction( ACTION_RENAME_ROM ) );
	if( !rom.info->name.empty() ) {
		contextMenu.addAction( "Revert ROM Name" )->setData( serializeAction( ACTION_REVERT_NAME ) );
	}

	const QAction *action = contextMenu.exec( mapToGlobal( point ) );
	if( action != nullptr && action->data().type() == QVariant::String ) {
		switch( action->data().value<QString>().toStdString().at( 0 ) ) {
			case ACTION_DELETE_SAVE: {
				if( QMessageBox::question( nullptr, "Confirm Delete", "Are you sure you want to delete your save file?" ) == QMessageBox::Yes ) {
					fs::remove( saveFilePath );
				}
				break;
			}
			case ACTION_ADD_GROUP: {
				DataProvider::addToGroup( rom.file->sha1, action->data().value<QString>().toStdString().substr( 1 ) );
				refetchAll();
				break;
			}
			case ACTION_CREATE_GROUP: {
				const QString tagString = QInputDialog::getText( nullptr, "Create Group", "Enter a name for your new group" );
				if( tagString.isEmpty() || tagString.isNull() ) return;

				const string groupName = tagString.toStdString();
				for( const string &g : allGroups ) {
					if( groupName != g ) continue;
					QMessageBox::critical( nullptr, "Group Exists", "A group with this name already exists" );
					return;
				}

				DataProvider::addGroup( groupName );
				DataProvider::addToGroup( rom.file->sha1, groupName );
				refetchAll();
				break;
			}
			case ACTION_EDIT_SAVE: {
				emit editSave( saveFilePath );
				break;
			}
			case ACTION_REMOVE_GROUP: {
				DataProvider::removeFromGroup( rom.file->sha1, group );
				refetchAll();
				break;
			}
			case ACTION_OPEN_FOLDER: {
#ifdef _WIN32
				AsyncProcess( "explorer.exe", { rom.file->path.parent_path().u8string() } ).detach();
#else
				AsyncProcess( "xdg-open", { rom.file->path.parent_path().string() } ).detach();
#endif
				break;
			}
			case ACTION_DELETE_ROM: {
				if( QMessageBox::question( nullptr, "Confirm Delete", "This will completely remove the ROM file from your computer. Are you sure you want to delete this ROM?" ) == QMessageBox::Yes ) {
					DataProvider::deleteRomPath( rom.file->path );
					std::error_code err;
					fs::remove( rom.file->path, err );
					refetchAll();
				}
				break;
			}
			case ACTION_RENAME_ROM: {
				const string name = QInputDialog::getText( nullptr, "Rename", "Enter a new name for your rom" ).toStdString();
				if( name.empty() ) return;
				rom.info->name = name;
				DataProvider::renameRom( rom.file->sha1, name );
				updateRomInfo( *rom.info, true, false );
				break;
			}
			case ACTION_REVERT_NAME: {
				rom.info->name.clear();
				DataProvider::renameRom( rom.file->sha1, "" );
				updateRomInfo( *rom.info, true, false );
				break;
			}
			default: break;
		}
	}

}

void RomListView::onDoubleClick( const QModelIndex &index ) {
	const RomReference rom = static_cast<RomListModel*>( model() )->tryGetRom( index );
	if( rom.file != nullptr ) {
		emit launchRom();
	}
}

TreeUiState RomListView::saveTreeState() const {
	TreeUiState uiState;

	const RomReference selectedRom = tryGetSelectedRom();
	if( selectedRom.file != nullptr ) {
		uiState.selectedRom = selectedRom.file->path;
		uiState.selectedGroup = static_cast<const RomListModel*>( model() )->tryGetGroup( currentIndex().parent() );
	}

	const int numGroups = model()->rowCount();
	for( int i = 0; i < numGroups; i++ ) {
		const QModelIndex index = model()->index( i, 0 );
		if( isExpanded( index ) ) {
			uiState.expandedGroups.push_back(
				static_cast<const RomListModel*>( model() )->tryGetGroup( index )
			);
		}
	}

	return uiState;
}

void RomListView::restoreTreeState( const TreeUiState &state ) {
	for( const string &group : state.expandedGroups ) {
		const QModelIndex index = static_cast<const RomListModel*>( model() )->tryGetIndex( group );
		if( index.isValid() ) {
			expand( index );
		}
	}

	if( !state.selectedRom.empty() ) {
		selectRom( state.selectedGroup, state.selectedRom );
	}
}
