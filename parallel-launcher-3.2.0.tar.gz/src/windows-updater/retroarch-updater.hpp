#ifndef SRC_WINDOWS_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_
#define SRC_WINDOWS_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_

namespace WindowsRetroArchUpdater {

	extern bool install();
	extern void update();

}

#endif /* SRC_WINDOWS_UPDATER_RETROARCH_UPDATE_DIALOG_HPP_ */
