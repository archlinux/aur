#ifndef SRC_CORE_ROM_HPP_
#define SRC_CORE_ROM_HPP_

#include <set>
#include "src/core/filesystem.hpp"
#include "src/core/settings.hpp"
#include "src/core/uuid.hpp"
#include "src/core/json.hpp"

struct RomFile {
	fs::path path;
	int64 lastModified;
	string sha1;
};

struct RomInfo {
	string sha1;
	string name;
	string internalName;
	EmulatorCore emulator;
	GfxPlugin parallelPlugin;
	GfxPlugin mupenPlugin;
	int64 lastPlayed;
	int64 playTime;
	std::set<string> groups;
	bool overclockCPU;
	bool overclockVI;
	uint crc32;
	Uuid inputModeId;
	bool widescreen;
};

struct RomReference {
	RomFile *file;
	RomInfo *info;
};

struct RomSource {
	fs::path folder;
	bool recursive;
	bool ignoreHidden;
	bool followSymlinks;
	ubyte maxDepth;
	std::set<string> autoTags;
};

namespace JsonSerializer {
	template<> void serialize<RomSource>( JsonWriter &jw, const RomSource &obj );
	template<> RomSource parse<RomSource>( const Json &json );

	template<> void serialize<fs::path>( JsonWriter &jw, const fs::path &obj );
	template<> fs::path parse<fs::path>( const Json &json );
}

namespace RomUtil {
	extern string getInternalName( const fs::path romPath );
	extern int64 getLastModified( const fs::path romPath );
	extern uint getCrc32( const fs::path &romPath );

	extern bool coveredBySearchPath( const fs::path &romPath );
}

#endif /* SRC_CORE_ROM_HPP_ */
