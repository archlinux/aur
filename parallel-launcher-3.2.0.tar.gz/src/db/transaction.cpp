#include "src/db/transaction.hpp"

#include "src/db/sqlite.hpp"
#include <cassert>

SqlTransaction::SqlTransaction() noexcept : m_committed( false ) {
	static SqlCommand s_beginSql( "BEGIN TRANSACTION" );
	s_beginSql.execNonQuery();
}

SqlTransaction::SqlTransaction( SqlTransaction &&other ) noexcept : m_committed( other.m_committed ) {
	other.m_committed = true;
}

SqlTransaction::~SqlTransaction() noexcept {
	if( m_committed ) return;
	static SqlCommand s_rollbackSql( "ROLLBACK TRANSACTION" );
	s_rollbackSql.execNonQuery();
}

void SqlTransaction::commit() noexcept {
	assert( !m_committed );
	static SqlCommand s_commitSql( "COMMIT TRANSACTION" );
	s_commitSql.execNonQuery();
	m_committed = true;
}
