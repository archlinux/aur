### RunAsUnified
Run the app with one of three shell switches - PowerShell/CMD/Bash!
## ON LINUX ```SUDO``` IS REQUIRED

For example: 
  * ```ruas pwsh script.ps1```
  * ```ruas cmd script.cmd```
  * ```ruas bash pacman -Syu```
