# RAPD
[![forthebadge](https://forthebadge.com/images/badges/made-with-rust.svg)](https://forthebadge.com)

## What is rapd
Rapd is the Rust audio player daemon, you can find more info [here](https://rapd.readthedocs.io/en/latest/)
