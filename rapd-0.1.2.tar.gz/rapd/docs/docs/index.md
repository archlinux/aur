# RAPD
Rust Audio Player Daemon

## Features
  - Low CPU, and Memory Footprint	
  - Use any client you want without migrating you're music
  - Runs in the background so music can run without a Xorg, or Wayland session running
  - Anybody can build a client for RAPD
