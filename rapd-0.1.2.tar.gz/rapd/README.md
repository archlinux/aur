# RAPD
The Rust Audio Player Daemon

[![Documentation Status](https://readthedocs.org/projects/rapd/badge/?version=latest)](https://rapd.readthedocs.io/en/latest/?badge=latest)

[![asciicast](https://asciinema.org/a/468543.svg)](https://asciinema.org/a/468543)

## What rapd trys to do
Rapd is not a spotify client, or an advanced music player. Its an audio/music daemon that runs in the background that accepts connections via its TCP socket.
Rapd aims to be a fast, lightweight, free, and open-source program to play music or audio on you're machine and thats it.

## Why not mpd?
Mpd is a cool concept, if it worked(for me). It had weird permisson problems with my music folder, and other things that bugged me.

## Documentation
You can find the docs [here](https://www.interfiber.dev/rapd )
