# TODO

  - [x] Remove plugins, and replace them with hooks
  - [ ] Finish support for metadata
  - [ ] Build release
