# RAPD

## Whats here
This folder contains the source code for the rap daemon, the client source code can be found in ```../rapc```
