#ifndef SRC_WINDOWS_UPDATER_DOWNLOAD_DIALOG_HPP_
#define SRC_WINDOWS_UPDATER_DOWNLOAD_DIALOG_HPP_

#include <QProgressDialog>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrl>
#include <QFile>
#include "src/core/filesystem.hpp"

class DownloadDialog : public QProgressDialog {
	Q_OBJECT

	private:
	QNetworkAccessManager *m_networkManager;
	QNetworkReply *m_stream;
	QFile *m_file;

	public:
	DownloadDialog( const QUrl &url, const fs::path &filePath );
	~DownloadDialog();

	private slots:
	void onDownloadProgress( qint64 downloaded, qint64 total );
	void onDownloadFailed( QNetworkReply::NetworkError error );
	void onDownloadFinished();
	void dataReceived();

};


#endif /* SRC_WINDOWS_UPDATER_DOWNLOAD_DIALOG_HPP_ */
