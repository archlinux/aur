#include "src/ui/settings-dialog.hpp"
#include "ui_settings-dialog.h"

#include <QMessageBox>
#include "src/ui/icons.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/numeric-string.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/updates.hpp"
#include "src/db/data-provider.hpp"
#include "src/ui/util.hpp"
#include "src/polyfill/file-dialog.hpp"
#include "src/rhdc/core/sync.hpp"

#ifdef _WIN32
#include <QStyleFactory>
#endif

static const GfxPlugin m_mupenPlugins[] = {
	GfxPlugin::ParaLLEl,
	GfxPlugin::Angrylion,
	GfxPlugin::GlideN64
};

SettingsDialog::SettingsDialog( QWidget *parent ) :
	QDialog( parent ),
	m_ui( new Ui::SettingsDialog )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );
	m_ui->bpsBrowseButton->setIcon( Icon::browse() );
	m_ui->rhdcBrowseButton->setIcon( Icon::browse() );
	m_ui->resetConfigButton->setIcon( Icon::undo() );

#ifdef _WIN32
	m_ui->themeSelect->addItems( QStyleFactory::keys() );
#else
	m_ui->updateCheckbox->setVisible( false );
	m_ui->themePanel->setVisible( false );
#endif
}

SettingsDialog::~SettingsDialog() {
	delete m_ui;
}

void SettingsDialog::showEvent( QShowEvent *event ) {
	const AppSettings settings = FileController::loadAppSettings();
	const InstalledVersionsInfo versions = FileController::loadInstalledVersions();

	m_ui->windowScaleSelect->setCurrentIndex( (int)settings.windowScale - 1 );
	m_ui->parallelPluginSelect->setCurrentIndex( (int)settings.defaultParallelPlugin - 1 );
	switch( settings.defaultMupenPlugin ) {
		case GfxPlugin::GlideN64: m_ui->mupenPluginSelect->setCurrentIndex( 2 ); break;
		case GfxPlugin::Angrylion: m_ui->mupenPluginSelect->setCurrentIndex( 1 ); break;
		default: m_ui->mupenPluginSelect->setCurrentIndex( 0 ); break;
	}
	m_ui->emulatorCoreSelect->setCurrentIndex( (int)settings.defaultEmulator - 1 );
	m_ui->vsyncCheckbox->setChecked( settings.vsync );
	m_ui->hideLauncherCheckbox->setChecked( settings.hideWhenPlaying );
	m_ui->showInternalNameCheckbox->setChecked( Flags::has( settings.visibleColumns, RomInfoColumn::InternalName ) );
	m_ui->showFilePathCheckbox->setChecked( Flags::has( settings.visibleColumns, RomInfoColumn::Path ) );
	m_ui->showLastPlayedCheckbox->setChecked( Flags::has( settings.visibleColumns, RomInfoColumn::LastPlayed ) );
	m_ui->showPlayTimeCheckbox->setChecked( Flags::has( settings.visibleColumns, RomInfoColumn::PlayTime ) );
#ifdef _WIN32
	m_ui->updateCheckbox->setChecked( settings.checkForUpdates );
	m_ui->themeSelect->setCurrentText( settings.windowsTheme.c_str() );
#endif

	m_ui->bpsRelativeRadio->setChecked( settings.patchToSameFolder );
	m_ui->bpsFixedRadio->setChecked( !settings.patchToSameFolder );
	m_ui->bpsSavePathPanel->setEnabled( !settings.patchToSameFolder );
	m_ui->bpsPath->setText( settings.patchedRomFolder.u8string().c_str() );

	m_ui->upscalingSelect->setCurrentIndex( (int)settings.parallelUpscaling );
	m_ui->parallelAntiAliasingCheckbox->setChecked( settings.parallelAntiAliasing );
	m_ui->upscaleTexRectsCheckbox->setChecked( settings.parallelTexRectUpscaling );
	m_ui->angrylionFilteringSelect->setCurrentIndex( (int)settings.angrylionFiltering );
	m_ui->glidenAntiAliasingCheckbox->setChecked( settings.glidenAntiAliasing );
	m_ui->glidenPointFilteringCheckbox->setChecked( settings.glidenThreePointFiltering );
	m_ui->glidenDepthBufferCheckbox->setChecked( settings.glidenFramebufferEmulation && settings.glidenCorrectDepthCompare );
	m_ui->emulateFramebufferCheckbox->setChecked( settings.glidenFramebufferEmulation );
	m_ui->glidenDepthBufferCheckbox->setEnabled( settings.glidenFramebufferEmulation );

	m_ui->updateRetroarchCheckbox->setChecked( !versions.retroArchVersion.lock );
	m_ui->updateParallelCheckbox->setChecked( !versions.parallelVersion.lock );
	m_ui->updateMupenCheckbox->setChecked( !versions.mupenVersion.lock );
	m_ui->useDevBranchCheckbox->setChecked( settings.mupenDevBranch );
	m_ui->updateIntervalSelect->setCurrentIndex( (int)settings.coreUpdateInterval );

	const RhdcSettings rhdcSettings = FileController::loadRhdcSettings();
	m_ui->rhdcPathInput->setText( rhdcSettings.downloadDirectory.u8string().c_str() );
	m_ui->allSlotsCheckbox->setChecked( rhdcSettings.checkAllSaveSlots );
	m_ui->preferHleCheckbox->setChecked( rhdcSettings.preferHle );
	m_ui->syncGroupsCheckbox->setChecked( rhdcSettings.syncGroups );

	windowScaleChanged( (int)settings.windowScale - 1 );

	QDialog::showEvent( event );
	UiUtil::shrinkToFit( this, Qt::Horizontal | Qt::Vertical );
}

void SettingsDialog::closeEvent( QCloseEvent *event ) {
	save();
	QDialog::closeEvent( event );
}

void SettingsDialog::save() const {
	AppSettings settings = FileController::loadAppSettings();
	InstalledVersionsInfo versions = FileController::loadInstalledVersions();

	settings.visibleColumns = (RomInfoColumn)0;
	if( m_ui->showInternalNameCheckbox->isChecked() ) settings.visibleColumns |= RomInfoColumn::InternalName;
	if( m_ui->showFilePathCheckbox->isChecked() ) settings.visibleColumns |= RomInfoColumn::Path;
	if( m_ui->showLastPlayedCheckbox->isChecked() ) settings.visibleColumns |= RomInfoColumn::LastPlayed;
	if( m_ui->showPlayTimeCheckbox->isChecked() ) settings.visibleColumns |= RomInfoColumn::PlayTime;

#ifdef _WIN32
	settings.windowsTheme = m_ui->themeSelect->currentText().toStdString();
#endif

	if( settings.parallelTexRectUpscaling != m_ui->upscaleTexRectsCheckbox->isChecked() ) {
		DataProvider::setDefaultParallelTexRectUpscaling( m_ui->upscaleTexRectsCheckbox->isChecked() );
	}

	if( settings.glidenFramebufferEmulation != m_ui->emulateFramebufferCheckbox->isChecked() ) {
		DataProvider::setDefaultGlidenFrameBufferEmulation( m_ui->emulateFramebufferCheckbox->isChecked() );
	}

	if( settings.glidenCorrectDepthCompare != m_ui->glidenDepthBufferCheckbox->isChecked() ) {
		DataProvider::setDefaultGlidenAccurateDepthCompare( m_ui->glidenDepthBufferCheckbox->isChecked() );
	}

	settings.defaultParallelPlugin = (GfxPlugin)(m_ui->parallelPluginSelect->currentIndex() + 1);
	settings.defaultMupenPlugin = m_mupenPlugins[ m_ui->mupenPluginSelect->currentIndex() ];
	settings.defaultEmulator = (EmulatorCore)(m_ui->emulatorCoreSelect->currentIndex() + 1);
	settings.windowScale = (ubyte)(m_ui->windowScaleSelect->currentIndex() + 1);
	settings.vsync = m_ui->vsyncCheckbox->isChecked();
	settings.hideWhenPlaying = m_ui->hideLauncherCheckbox->isChecked();
	settings.patchToSameFolder = m_ui->bpsRelativeRadio->isChecked();
	settings.patchedRomFolder = fs::to_path( m_ui->bpsPath->text().toStdString() );

	settings.parallelUpscaling = (ParallelUpscaling)m_ui->upscalingSelect->currentIndex();
	settings.parallelAntiAliasing = m_ui->parallelAntiAliasingCheckbox->isChecked();
	settings.parallelTexRectUpscaling = m_ui->upscaleTexRectsCheckbox->isChecked();
	settings.angrylionFiltering = (AngrylionFiltering)m_ui->angrylionFilteringSelect->currentIndex();
	settings.glidenAntiAliasing = m_ui->glidenAntiAliasingCheckbox->isChecked();
	settings.glidenThreePointFiltering = m_ui->glidenPointFilteringCheckbox->isChecked();
	settings.glidenFramebufferEmulation = m_ui->emulateFramebufferCheckbox->isChecked();
	if( m_ui->glidenDepthBufferCheckbox->isEnabled() ) {
		settings.glidenCorrectDepthCompare = m_ui->glidenDepthBufferCheckbox->isChecked();
	}

	versions.retroArchVersion.lock = !m_ui->updateRetroarchCheckbox->isChecked();
	versions.parallelVersion.lock = !m_ui->updateParallelCheckbox->isChecked();
	versions.mupenVersion.lock = !m_ui->updateMupenCheckbox->isChecked();
	settings.mupenDevBranch = m_ui->useDevBranchCheckbox->isChecked();
	settings.coreUpdateInterval = (CoreUpdateInterval)m_ui->updateIntervalSelect->currentIndex();

	RhdcSettings rhdcSettings = FileController::loadRhdcSettings();
	const fs::path newRhdcDownloadDir = fs::to_path( m_ui->rhdcPathInput->text().toStdString() );
	if( rhdcSettings.downloadDirectory != newRhdcDownloadDir ) {
		RHDC::moveRhdcFolder( rhdcSettings.downloadDirectory, newRhdcDownloadDir );
		rhdcSettings.downloadDirectory = newRhdcDownloadDir;
	}
	rhdcSettings.checkAllSaveSlots = m_ui->allSlotsCheckbox->isChecked();
	rhdcSettings.preferHle = m_ui->preferHleCheckbox->isChecked();
	rhdcSettings.syncGroups = m_ui->syncGroupsCheckbox->isChecked();

	FileController::saveAppSettings( settings );
	FileController::saveInstalledVersions( versions );
	FileController::saveRhdcSettings( rhdcSettings );
}

void SettingsDialog::windowScaleChanged( int index ) {
	int autoScale;
	switch( index ) {
		case 0: autoScale = 1; break;
		case 1: autoScale = 2; break;
		case 7: autoScale = 8; break;
		default: autoScale = 4; break;
	}

	const int autoWidth = 320 * autoScale;
	const int autoHeight = 240 * autoScale;

	const string autoText = "Auto (x"s + Number::toString( autoScale ) + " - " + Number::toString( autoWidth ) + 'x' + Number::toString( autoHeight ) + ')';
	m_ui->upscalingSelect->setItemText( 0, autoText.c_str() );
}

void SettingsDialog::browseForBpsPath() {
	fs::path folderPath = FileDialog::getDirectory( "Select a Folder" );
	if( !folderPath.empty() ) {
		m_ui->bpsPath->setText( folderPath.u8string().c_str() );
	}
}

void SettingsDialog::browseForRhdcDir() {
	fs::path folderPath = FileDialog::getDirectory( "Select a Folder" );
	if( !folderPath.empty() ) {
		m_ui->rhdcPathInput->setText( folderPath.u8string().c_str() );
	}
}

static const char *s_confirmResetMessage = ""
	"This will reset your RetroArch config file, undoing any changes you have made within RetroArch. "
	"Your Parallel Launcher settings will not be affected. Do you want to continue?";

void SettingsDialog::resetConfig() {
	if( QMessageBox::question( this, "Confirm Reset", s_confirmResetMessage ) == QMessageBox::Yes ) {
		if( RetroArch::resetConfig() ) {
			QMessageBox::information( this, "Config Reset", "Your RetroArch config has been reset." );
		} else {
			QMessageBox::critical( this, "Oops", "An unknown error occurred. Your RetroArch config has not been reset." );
		}
	}
}

void SettingsDialog::updateCores() {
	AppSettings settings = FileController::loadAppSettings();
	InstalledVersionsInfo coreVersions = FileController::loadInstalledVersions();
	coreVersions.retroArchVersion.lock = !m_ui->updateRetroarchCheckbox->isChecked();
	coreVersions.parallelVersion.lock = !m_ui->updateParallelCheckbox->isChecked();
	coreVersions.mupenVersion.lock = !m_ui->updateMupenCheckbox->isChecked();
	settings.mupenDevBranch = m_ui->useDevBranchCheckbox->isChecked();
	FileController::saveAppSettings( settings );
	FileController::saveInstalledVersions( coreVersions );
	RetroUpdater::checkForUpdates( false, true, true );
}

void SettingsDialog::applyAll_accurateDepthCompare() {
	if( QMessageBox::question( this, "Confirm Apply All", "Apply this setting to all current roms?" ) == QMessageBox::Yes ) {
		DataProvider::setAllGlidenAccurateDepthCompare( m_ui->glidenDepthBufferCheckbox->isChecked() );
	}
}

void SettingsDialog::applyAll_emulateFramebuffer() {
	if( QMessageBox::question( this, "Confirm Apply All", "Apply this setting to all current roms?" ) == QMessageBox::Yes ) {
		DataProvider::setAllGlidenFrameBufferEmulation( m_ui->emulateFramebufferCheckbox->isChecked() );
	}
}

void SettingsDialog::applyAll_upscaleTexRects() {
	if( QMessageBox::question( this, "Confirm Apply All", "Apply this setting to all current roms?" ) == QMessageBox::Yes ) {
		DataProvider::setAllParallelTexRectUpscaling( m_ui->upscaleTexRectsCheckbox->isChecked() );
	}
}

void SettingsDialog::fbEmulationToggled( bool enabled ) {
	m_ui->glidenDepthBufferCheckbox->setEnabled( enabled );
	m_ui->glidenDepthBufferCheckbox->setChecked( enabled ? FileController::loadAppSettings().glidenCorrectDepthCompare : false );
}
