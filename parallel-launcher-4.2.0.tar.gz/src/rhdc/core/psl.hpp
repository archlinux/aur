#ifndef SRC_RHDC_CORE_PSL_HPP_
#define SRC_RHDC_CORE_PSL_HPP_

#include <unordered_map>
#include "src/core/filesystem.hpp"
#include "src/core/json.hpp"

struct StarBitsLocation {
	string name;
	uint byteOffset;
	ushort numBytes;
	ubyte bitMask;
};

struct ParallelStarLayout {

	ubyte numSlots;
	uint slotsStart;
	uint slotSize;
	uint activeBit;
	std::vector<StarBitsLocation> starBits;

	int getStarCount( const fs::path &saveFilePath ) const;

};

class LayoutManager {

	private:
	HashMap<string,string> m_hackMap;
	HashMap<string,ParallelStarLayout> m_layoutMap;

	public:
	LayoutManager() {}
	LayoutManager(
		HashMap<string,string> &&hackMap,
		HashMap<string,ParallelStarLayout> &&layoutMap
	) noexcept :
		m_hackMap( hackMap ),
		m_layoutMap( layoutMap )
	{}

	~LayoutManager() {}

	inline const ParallelStarLayout *tryGetLayout( const string &hackId ) const {
		const auto i = m_hackMap.find( hackId );
		if( i == m_hackMap.end() ) return nullptr;
		const auto j = m_layoutMap.find( i->second );
		if( j == m_layoutMap.end() ) return nullptr;
		return &j->second;
	}

	void serialize( JsonWriter &jw ) const;

};

namespace JsonSerializer {
	template<> void serialize<ParallelStarLayout>( JsonWriter &jw, const ParallelStarLayout &obj );
	template<> ParallelStarLayout parse<ParallelStarLayout>( const Json &json );

	template<> void serialize<LayoutManager>( JsonWriter &jw, const LayoutManager &obj );
	template<> LayoutManager parse<LayoutManager>( const Json &json );
}

#endif /* SRC_RHDC_CORE_PSL_HPP_ */
