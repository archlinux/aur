#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"

bool RhdcApi::isAuthenticated() noexcept {
	return !ApiUtil::identity().authToken.isNull();
}

struct CredentialsJson {
	RhdcCredentials data;
};

template<> void JsonSerializer::serialize<CredentialsJson>( JsonWriter &jw, const CredentialsJson &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( "username", obj.data.username );
	jw.writeProperty( "password", obj.data.password );
	jw.writeObjectEnd();
}

static void whoamiAsync(
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/user/profile/"s + ApiUtil::urlEncode( ApiUtil::identity().username ) );
	ApiUtil::onResponse( response,
		[=]() {
			const Json json = ApiUtil::readJson( response );
			const string userId = json["_id"].getOrDefault<string>( "" );
			if( userId.empty() ) {
				RhdcApi::logout();
				onFailure( ApiErrorType::JsonError );
			} else {
				ApiUtil::identity().userId = userId;
				onSuccess();
			}
		},
		[=](ApiErrorType err) {
			RhdcApi::logout();
			onFailure( err );
		}
	);
}

void RhdcApi::loginAsync(
	const RhdcCredentials &credentials,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	QNetworkReply *response = ApiUtil::send<CredentialsJson>( HttpMethod::Post, "https://api.romhacking.com/login", { credentials } );
	ApiUtil::onResponse( response,
		[=]() {
			const Json json = ApiUtil::readJson( response );
			const string token = json["token"].getOrDefault<string>( "" );
			if( token.empty() ) {
				onFailure( ApiErrorType::JsonError );
			} else {
				ApiUtil::identity().username = credentials.username;
				ApiUtil::identity().authToken = QByteArray( ("Bearer "s + token).c_str() );
				whoamiAsync( onSuccess, onFailure );
			}
		},
		[=](ApiErrorType err) {
			const int statusCode = ApiUtil::getStatusCode( response );
			if( statusCode == (int)HttpStatusCode::BadRequest || statusCode == (int)HttpStatusCode::Unauthorized ) {
				const Json json = ApiUtil::readJson( response );
				if( json["needsEmailVerification"].getOrDefault<bool>( false ) ) {
					onFailure( ApiErrorType::RegistrationRequired );
				} else {
					onFailure( ApiErrorType::NotAuthorized );
				}
			} else {
				onFailure( err );
			}
		}
	);
}

void RhdcApi::logout() noexcept {
	ApiUtil::identity().username.clear();
	ApiUtil::identity().userId.clear();
	ApiUtil::identity().authToken.clear();
}
