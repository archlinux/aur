#include "src/rhdc/ui/rhdc-download-dialog.hpp"
#include "ui_rhdc-download-dialog.h"

#include <cctype>
#include <cstdio>
#include <thread>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QFile>
#include "src/polyfill/base-directory.hpp"
#include "src/polyfill/sha1.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/numeric-string.hpp"
#include "src/core/qthread.hpp"
#include "src/core/logging.hpp"
#include "src/core/sm64.hpp"
#include "src/core/bps.hpp"
#include "src/core/zip.hpp"
#include "src/db/data-provider.hpp"
#include "src/ui/toast.hpp"
#include "src/ui/icons.hpp"
#include "src/rhdc/core/plugin-detect.hpp"

RhdcDownloadDialog::RhdcDownloadDialog() :
	QDialog( nullptr ),
	m_ui( new Ui::RhdcDownloadDialog )
{
	m_ui->setupUi( this );
	setModal( true );
	setWindowIcon( Icon::appIcon() );
	m_ui->romProgressBar->setRange( 0, 100 );
}

RhdcDownloadDialog::~RhdcDownloadDialog() {
	delete m_ui;
}

static inline string getExtensionLowerCase( const fs::path &path ) {
	string extension = path.extension().u8string();
	for( char &c : extension ) {
		c = (char)std::tolower( c );
	}
	return extension;
}

static void extractAndPatch(
	FollowedHack hack,
	fs::path temporaryPath,
	std::function<void(void)> callback
) {
	std::error_code err;
	fs::path sm64path;
	if( !SM64::tryGetPath( sm64path ) ) {
		fs::remove( temporaryPath, err );
		QtThread::safeAsync( callback );
		return;
	}

	if( getExtensionLowerCase( temporaryPath ) == ".zip" ) {
		const fs::path zipDir = BaseDir::temp() / "rhdc-extracted";
		fs::remove_all( zipDir, err );
		fs::create_directories( zipDir, err );
		Zip::unzip( temporaryPath, zipDir );
		bool foundPatch = false;
		for( const auto &i : fs::recursive_directory_iterator( zipDir ) ) {
			if( fs::isDirectorySafe( i.path() ) ) continue;
			if( getExtensionLowerCase( i.path() ) != ".bps" ) continue;
			temporaryPath.replace_filename( i.path().filename() );
			fs::rename( i.path(), temporaryPath, err );
			if( fs::isRegularFileSafe( temporaryPath ) ) {
				foundPatch = true;
				break;
			}
		}
		fs::remove_all( zipDir, err );
		if( !foundPatch ) temporaryPath = fs::path();
	}

	if( getExtensionLowerCase( temporaryPath ) != ".bps" ) {
		const string message = "Could not install '"s + hack.info.name + "' because no bps patch was found";
		QtThread::safeAsync( [message,callback](){
			ToastMessageManager::display( ToastType::Warn, message );
			logWarn( message );
			callback();
		});
		return;
	}

	const RhdcSettings &settings = FileController::loadRhdcSettings();
	const string romFilename = temporaryPath.stem().u8string() + ' ' + hack.info.hackId + ".z64";
	fs::path romPath = settings.downloadDirectory / romFilename;

	const Bps::BpsApplyError bpsErr = Bps::tryApplyBps( temporaryPath, sm64path, romPath );
	if( bpsErr != Bps::BpsApplyError::None ) {
		const string message = "Could not install '"s + hack.info.name + "' because of an unexpected error while applying the patch";
		fs::remove( temporaryPath, err );
		QtThread::safeAsync( [message,callback](){
			ToastMessageManager::display( ToastType::Warn, message );
			logWarn( message );
			callback();
		});
		return;
	}

	fs::remove( temporaryPath, err );

	std::set<string> groups;
	if( settings.syncGroups ) {
		for( const string &group : hack.groups ) {
			groups.insert( group );
		}
	}

	const string sha1 = Sha1::compute( romPath );
	DataProvider::addRhdcHackVersion( hack.info.hackId, sha1 );

	DataProvider::addRomFile({
		romPath,
		RomUtil::getLastModified( romPath ),
		sha1
	});

	AutoPlugin autoPlugin = AutoPlugin::detect( romPath, hack.plugin, hack.pluginFlags );
	DataProvider::addRomInfo({
		sha1,
		hack.info.name,
		RomUtil::getInternalName( romPath ),
		autoPlugin.emulator,
		autoPlugin.parallelPlugin,
		autoPlugin.mupenPlugin,
		autoPlugin.upscaleTexrects,
		autoPlugin.emulateFramebuffer,
		autoPlugin.accurateDepthCompare,
		0,
		0,
		std::move( groups ),
		true,
		false,
		RomUtil::getCrc32( romPath ),
		DefaultInputModes::Normal.id,
		false
	});

	QtThread::safeAsync( callback );
}

static inline QString overallProgressText( size_t i, size_t n ) {
	return QString( (Number::toString( (int)i ) + " / " + Number::toString( (int)n ) + " downloaded").c_str() );
}

static inline QString romProgressText( qint64 d, qint64 t ) {
	char buffer[32];
	const double dm = (double)d / 1048576.0;
	const double dt = (double)t / 1048576.0;
	std::snprintf( buffer, 32, "%6.2f / %04.2f MiB", dm, dt );
	return QString( buffer );
}

void RhdcDownloadDialog::downloadHack(
	const std::shared_ptr<bool> &dialogExists,
	RhdcDownloadDialog *dialog,
	HashMap<string,FollowedHack>::const_iterator current,
	size_t romsDownloaded,
	size_t totalRoms
) {
	if( !*dialogExists ) return;

	if( romsDownloaded >= totalRoms ) {
		dialog->close();
		return;
	}

	const FollowedHack &hack = current->second;
	dialog->m_ui->overallStatus->setText( overallProgressText( romsDownloaded, totalRoms ) );
	dialog->m_ui->overallProgressBar->setValue( 100 * (int)romsDownloaded );
	dialog->m_ui->romStatus->setText( ("Downloading "s + hack.info.name).c_str() );
	dialog->m_ui->romProgressBar->setRange( 0, 100 );
	dialog->m_ui->romProgressBar->setValue( 0 );
	dialog->m_ui->downloadedLabel->setText( "Waiting for romhacking.com to respond" );

	const QUrl downloadUrl( hack.downloadUrl.c_str() );
	const fs::path tempDownloadPath = BaseDir::temp() / downloadUrl.fileName().toStdString();
	QFile *file = new QFile( tempDownloadPath.u8string().c_str() );
	file->open( QIODevice::WriteOnly | QIODevice::Truncate );

	QNetworkAccessManager *web = new QNetworkAccessManager();
	QNetworkReply *response = web->get( QNetworkRequest( downloadUrl ) );

	QObject::connect( response, &QNetworkReply::readyRead, web, [=](){
		file->write( response->readAll() );
	});

	QObject::connect( response, &QNetworkReply::downloadProgress, web, [=](qint64 downloaded, qint64 total){
		if( !*dialogExists ) return;
		dialog->m_ui->downloadedLabel->setText( romProgressText( downloaded, total ) );
		const int p = (int)(100.0 * downloaded / total + 0.5);
		dialog->m_ui->overallProgressBar->setValue( 100 * (int)romsDownloaded + p );
		dialog->m_ui->romProgressBar->setValue( p );
	});

	QObject::connect( response, &QNetworkReply::finished, web, [=](){
		if( *dialogExists ) {
			file->close();
			response->deleteLater();
			web->deleteLater();
			file->deleteLater();
			dialog->m_ui->romProgressBar->setRange( 0, 0 );
			dialog->m_ui->downloadedLabel->setText( "Patching and validating rom" );
			std::thread( extractAndPatch, hack, tempDownloadPath, [=](){
				if( !*dialogExists ) return;
				downloadHack( dialogExists, dialog, std::next( current, 1 ), romsDownloaded + 1, totalRoms );
			}).detach();
		} else {
			file->close();
			file->deleteLater();
			response->deleteLater();
			web->deleteLater();
			std::error_code err;
			fs::remove( tempDownloadPath, err );
		}
	});
}

void RhdcDownloadDialog::run( const HashMap<string,FollowedHack> &hacks ) {
	if( hacks.empty() ) return;

	std::shared_ptr<bool> dialogExists( new bool( true ) );
	RhdcDownloadDialog dialog;
	dialog.m_ui->overallProgressBar->setRange( 0, 100 * (int)hacks.size() );
	dialog.m_ui->overallProgressBar->setValue( 0 );
	downloadHack( dialogExists, &dialog, hacks.begin(), 0, hacks.size() );
	dialog.exec();
	*dialogExists = false;
}
