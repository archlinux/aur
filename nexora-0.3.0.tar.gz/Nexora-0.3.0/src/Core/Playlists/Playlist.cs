using System.Collections;
using Core.Playback;

namespace Core.Playlists;

public class Playlist : IEnumerable<IPlaylistItem>
{
    public string Name = string.Empty;
    public bool IsEmpty => TrackCount == 0;
    public int TrackCount => items.Count;
    
    private readonly List<IPlaylistItem> items = [];

    public event Action<IPlaylistItem>? ItemAdded;

    public IEnumerable<IPlaylistItem> GetAllItems()
    {
        return items;
    }

    public IPlaylistItem GetItem(int index)
    {
        if(index < 0 || index > items.Count - 1)
        {
            throw new ArgumentOutOfRangeException(nameof(index));
        }

        return items[index];
    }

    public void AddTrack(IAudioTrack audioTrack)
    {
        var item = new PlaylistItem(audioTrack, this, items.Count);
        items.Add(item);
        ItemAdded?.Invoke(item);
    }

    public void AddTracks(IEnumerable<IAudioTrack> audioTracks)
    {
        foreach(var audioTrack in audioTracks)
        {
            AddTrack(audioTrack);
        }
    }

    public IEnumerator<IPlaylistItem> GetEnumerator()
    {
        foreach(var item in items)
        {
            yield return item;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}
