<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="en_CA">
<context>
    <name>BindInputDialog</name>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="14"/>
        <source>Bind Input</source>
        <translation>Asignar entrada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="38"/>
        <source>To map a button or axis to this input, either press a button on your controller or hold a control stick or trigger in a different position for a half second.</source>
        <translation>Para asignar un botón o un eje a esta entrada, pulsa un botón en tu mando o mantén un stick o un gatillo en una posición durante medio segundo.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="76"/>
        <source>Skip</source>
        <translation>Saltar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/bind-input-dialog.ui" line="87"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>ControllerConfigDialog</name>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="14"/>
        <source>Configure Controller</source>
        <translation>Configurar mando</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="25"/>
        <source>Configuring Controller:</source>
        <translation>Configurando mando:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="62"/>
        <source>Quick Configure</source>
        <translation>Configuración rápida</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="86"/>
        <source>Enable Rumble</source>
        <translation>Activar vibración</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="99"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="18"/>
        <source>Analog Up</source>
        <translation>Stick Arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="122"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="19"/>
        <source>Analog Down</source>
        <translation>Stick Abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="145"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="20"/>
        <source>Analog Left</source>
        <translation>Stick Izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="168"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="21"/>
        <source>Analog Right</source>
        <translation>Stick Derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="191"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="30"/>
        <source>A Button</source>
        <translation>Botón A</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="214"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="31"/>
        <source>B Button</source>
        <translation>Botón B</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="248"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="22"/>
        <source>C Up</source>
        <translation>C Arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="271"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="23"/>
        <source>C Down</source>
        <translation>C Abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="294"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="24"/>
        <source>C Left</source>
        <translation>C Izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="317"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="25"/>
        <source>C Right</source>
        <translation>C Derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="340"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="33"/>
        <source>Z Trigger</source>
        <translation>Gatillo Z</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="363"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="34"/>
        <source>R Trigger</source>
        <translation>Gatillo R</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="397"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="26"/>
        <source>D-Pad Up</source>
        <translation>D-Pad Arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="420"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="27"/>
        <source>D-Pad Down</source>
        <translation>D-Pad Abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="443"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="28"/>
        <source>D-Pad Left</source>
        <translation>D-Pad Izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="466"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="29"/>
        <source>D-Pad Right</source>
        <translation>D-Pad Derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="489"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="35"/>
        <source>Start Button</source>
        <translation>Botón Start</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="512"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="32"/>
        <source>L Trigger</source>
        <translation>Gatillo L</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="550"/>
        <source>Sensitivity</source>
        <translation>Sensibilidad</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="576"/>
        <source>Deadzone</source>
        <translation>Zona muerta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="635"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="36"/>
        <source>Save State</source>
        <translation>Guardar estado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="664"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="37"/>
        <source>Load State</source>
        <translation>Cargar estado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="712"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="39"/>
        <source>Toggle Slow Motion</source>
        <translation>Alternar cámara lenta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="722"/>
        <location filename="../src/ui/controller-config-dialog.cpp" line="38"/>
        <source>Toggle Fast Forward</source>
        <translation>Alternar cámara rápida</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="787"/>
        <source>Save As</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="807"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-config-dialog.ui" line="821"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="69"/>
        <source>Not Bound</source>
        <translation>No asignado</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="72"/>
        <source>Button %1</source>
        <translation>Botón %1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="75"/>
        <source>Axis -%1</source>
        <translation>Eje -%1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="78"/>
        <source>Axis +%1</source>
        <translation>Eje +%1</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="81"/>
        <source>Hat %1 Up</source>
        <translation>Botón direccional %1 Arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="84"/>
        <source>Hat %1 Down</source>
        <translation>Botón direccional %1 Abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="87"/>
        <source>Hat %1 Left</source>
        <translation>Botón direccional %1 Izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="90"/>
        <source>Hat %1 Right</source>
        <translation>Botón direccional %1 Derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="132"/>
        <source>Enter Profile Name</source>
        <translation>Introducir nombre del perfil</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="132"/>
        <source>Enter a name for your new controller profile.</source>
        <translation>Introduce un nombre para tu nuevo perfil de mando.</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="138"/>
        <source>Failed to Save Profile</source>
        <translation>Fallo al guardar perfil</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-config-dialog.cpp" line="138"/>
        <source>A default controller profile with that name already exists.</source>
        <translation>Ya existe un perfil predeterminado con ese nombre.</translation>
    </message>
</context>
<context>
    <name>ControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="14"/>
        <source>Select Controller</source>
        <translation>Elegir mando</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="23"/>
        <source>Connected Controllers</source>
        <translation>Mandos conectados</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="52"/>
        <source>Controller Profiles</source>
        <translation>Perfiles de mando</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="67"/>
        <source>Edit Profile</source>
        <translation>Editar perfil</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/controller-select-dialog.ui" line="78"/>
        <source>Delete Profile</source>
        <translation>Borrar perfil</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-select-dialog.cpp" line="169"/>
        <source>Confirm Delete</source>
        <translation>Confirmar borrado</translation>
    </message>
    <message>
        <location filename="../src/ui/controller-select-dialog.cpp" line="169"/>
        <source>Are you sure you want to delete controller profile &apos;%1&apos;?</source>
        <translation>¿Estás seguro de que quieres borrar el perfil de mando %1?</translation>
    </message>
</context>
<context>
    <name>CoreFinderDialog</name>
    <message>
        <location filename="../src/ui/core-finder-dialog.cpp" line="11"/>
        <source>Searching for latest core version...</source>
        <translation>Buscando la última versión del núcleo...</translation>
    </message>
</context>
<context>
    <name>CoreInstaller</name>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="23"/>
        <source>Download Failed</source>
        <translation>Descarga fallida</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="24"/>
        <source>Failed to download emulator core</source>
        <translation>Fallo al descargar el núcleo del emulador</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="32"/>
        <source>Installation Failed</source>
        <translation>Instalación fallida</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="33"/>
        <source>Failed to install emulator core</source>
        <translation>Fallo al instalar el núcleo del emulador</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="43"/>
        <source>Installation Successful</source>
        <translation>Instalación completada</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="44"/>
        <source>Core installed successfully.</source>
        <translation>El núcleo se ha instalado correctamente.</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="64"/>
        <source>Core Unavailable</source>
        <translation>Núcleo no disponible</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="65"/>
        <source>Sorry! The Mupen64plus-Next emulator core is not available on MacOS. Try using ParallelN64 instead.</source>
        <translation>¡Perdón! El núcleo Mupen64Plus-Next no está disponible para MacOS. Intenta usar ParallelN64 en su lugar.</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="73"/>
        <source>Install Emulator Core?</source>
        <translation>¿Quieres instalar este núcleo del emulator?</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="74"/>
        <source>This emulator core is not installed. Would you like to install it now?</source>
        <translation>Este núcleo de emulador no está instalado. ¿Quieres instalarlo ahora?</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="134"/>
        <source>Core Update Available</source>
        <translation>Actualización del núcleo disponible</translation>
    </message>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="135"/>
        <source>An update is available for %1. Would you like to install it now?</source>
        <translation>Hay una actualización disponible para %1. ¿Te gustaría instalarla ahora?</translation>
    </message>
</context>
<context>
    <name>DirectPlay</name>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="55"/>
        <location filename="../src/ui/direct-play.cpp" line="62"/>
        <location filename="../src/ui/direct-play.cpp" line="69"/>
        <location filename="../src/ui/direct-play.cpp" line="76"/>
        <source>Patch Failed</source>
        <translation>Parche fallido</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="56"/>
        <source>Failed to patch ROM. The .bps patch appears to be invalid.</source>
        <translation>Fallo al parchear la ROM. El parche .bps parece no ser válido.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="63"/>
        <source>Failed to patch ROM. The base ROM does not match what the patch expects..</source>
        <translation>Fallo al parchear la ROM. La ROM base no coincide con la que el parche requiere.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="70"/>
        <source>Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher.</source>
        <translation>Fallo al parchear la ROM. Parallel Launcher no tiene constancia de la ROM requerida para el parche.</translation>
    </message>
    <message>
        <location filename="../src/ui/direct-play.cpp" line="77"/>
        <source>Failed to patch ROM. An error occurred while writing the patched ROM to disk.</source>
        <translation>Fallo al parchear la ROM. Se produjo un error al escribir la ROM parcheada al disco.</translation>
    </message>
</context>
<context>
    <name>DirectPlayWindow</name>
    <message>
        <location filename="../src/ui/designer/direct-play-window.ui" line="14"/>
        <source>ROM Settings</source>
        <translation>Opciones de la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/direct-play-window.ui" line="27"/>
        <source>This is your first time running this ROM. Please select any ROM specific settings. You can always change these settings later.</source>
        <translation>Esta es la primera vez que abres esta ROM. Por favor, elige las opciones específicas para esta ROM que desees. Siempre puedes cambiarlo más adelante.</translation>
    </message>
</context>
<context>
    <name>DownloadDialog</name>
    <message>
        <location filename="../src/ui/core-installer.cpp" line="20"/>
        <source>Downloading core...</source>
        <translation>Descargando núcleo...</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="237"/>
        <source>Downloading RetroArch</source>
        <translation>Descargando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="48"/>
        <source>Downloading installer...</source>
        <translation>Descargando instalador...</translation>
    </message>
</context>
<context>
    <name>ErrorNotifier</name>
    <message>
        <location filename="../src/ui/error-notifier.cpp" line="5"/>
        <source>The application encountered an unexpected error:</source>
        <translation>El programa encontró un error inesperado:</translation>
    </message>
    <message>
        <location filename="../src/ui/error-notifier.cpp" line="12"/>
        <source>Unhandled Error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>FlatpakProgressDialog</name>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.ui" line="14"/>
        <source>Flatpak Operation</source>
        <translation>Operación de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="425"/>
        <source>Updating RetroArch</source>
        <translation>Actualizando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="426"/>
        <source>Checking for RetroArch updates</source>
        <translation>Buscando actualizaciones para RetroArch</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="427"/>
        <source>RetroArch updated successfully.</source>
        <translation>Se ha actualizado RetroArch correctamente.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="428"/>
        <source>Failed to update RetroArch.</source>
        <translation>Se ha producido un error al actualizar RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="429"/>
        <source>An update for RetroArch is available. Would you like to install it now?</source>
        <translation>Hay una actualización disponible para RetroArch. ¿Quieres instalarla?</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="442"/>
        <source>Updating Runtimes</source>
        <translation>Actualizando runtimes</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="443"/>
        <source>Checking for runtime updates</source>
        <translation>Buscando actualziaciones del runtime</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="444"/>
        <source>Flatpak runtimes updated successfully.</source>
        <translation>Runtimes del flatpak actualizadas correctamente.</translation>
    </message>
    <message>
        <location filename="../src/core/updates.cpp" line="445"/>
        <source>Failed to update Flatpak runtimes.</source>
        <translation>Se ha producido un error al actualizar los runtimes de Flatpak.</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="25"/>
        <source>Installing</source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="27"/>
        <source>Updating</source>
        <translation>Actualizando</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="29"/>
        <source>Removing</source>
        <translation>Borrando</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="31"/>
        <source>Configuring</source>
        <translation>Configurando</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="58"/>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="60"/>
        <source>Initializing...</source>
        <translation>Inicializando...</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="126"/>
        <source>Finalizing...</source>
        <translation>Terminando...</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="154"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="167"/>
        <source>Operation Succeeded</source>
        <translation>Operación completada</translation>
    </message>
    <message>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="171"/>
        <location filename="../src/flatpak/flatpak-progress-dialog.cpp" line="173"/>
        <source>Operation Failed</source>
        <translation>Operación fallida</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="248"/>
        <source>Installing RetroArch</source>
        <translation>Instalando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="249"/>
        <source>Preparing to install RetroArch...</source>
        <translation>Preparando para instalar RetroArch...</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="250"/>
        <source>RetroArch installed successfully.</source>
        <translation>Se ha instalado RetroArch correctamente.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="251"/>
        <source>Failed to install RetroArch.</source>
        <translation>Fallo al instalar RetroArch.</translation>
    </message>
</context>
<context>
    <name>Game</name>
    <message>
        <location filename="../src/ui/play.cpp" line="22"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics plugins. Alternatively, if you have a very old onboard graphics card, it is possible that Vulkan is not supported on your system. In either case, using another graphics plugin might resolve the issue.</source>
        <translation>El emulador se ha cerrado inmediatamente después de abrirse. Si puedes abrir otras ROMs sin problema, esta ROM podría tener código inválido o inseguro del RSP que no puede ejecutarse en plugins que emulan correctamente la consola. Por otro lado, si tienes una tarjeta gráfica muy vieja o integrada, es posible que tu sistema no soporte Vulkan. En ambos casos, usar un plugin gráfico distinto podría resolver el problema.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="28"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics plugins. If this is the case, try running the ROM with another graphics plugin instead.</source>
        <translation>El emulador se ha cerrado inmediatamente después de abrirse. Si puedes abrir otras ROMs sin problema, esta ROM podría tener código inválido o inseguro del RSP que no puede ejecutarse en plugins que emulan correctamente la consola. Si este fuera el caso, intenta abrir esta ROM con otro plugin gráfico.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="33"/>
        <source>The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then this ROM is most likely corrupt.</source>
        <translation>El emulador se ha cerrado inmediatamente después de abrirse. Si puedes abrir otras ROMs sin problema, lo más probable es que esta ROM esté corrupta.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="110"/>
        <source>Emulator Missing</source>
        <translation>Falta el emulador</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="111"/>
        <source>Failed to launch emulator. It does not appear to be installed.</source>
        <translation>Fallo al ejecutar el emulador. Parece que no está instalado.</translation>
    </message>
    <message>
        <location filename="../src/ui/play.cpp" line="200"/>
        <source>Possible ROM Error</source>
        <translation>Posible error en la ROM</translation>
    </message>
</context>
<context>
    <name>GetControllerPortDialog</name>
    <message>
        <location filename="../src/ui/get-controller-port-dialog.cpp" line="8"/>
        <source>Choose Controller</source>
        <translation>Elegir mando</translation>
    </message>
    <message>
        <location filename="../src/ui/get-controller-port-dialog.cpp" line="9"/>
        <source>Press any button on the controller to bind to this port.</source>
        <translation>Pulsa cualquier botón en el mando para asignarlo a este puerto.</translation>
    </message>
</context>
<context>
    <name>GroupName</name>
    <message>
        <location filename="../src/core/special-groups.cpp" line="15"/>
        <source>Favourites</source>
        <translation>Favoritos</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="17"/>
        <source>Automatically Added</source>
        <translation>Añadidos automáticamente</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="19"/>
        <source>Uncategorized</source>
        <translation>Sin categoría</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="21"/>
        <source>Want To Play</source>
        <translation>Quiero jugar</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="23"/>
        <source>In Progress</source>
        <translation>En progreso</translation>
    </message>
    <message>
        <location filename="../src/core/special-groups.cpp" line="25"/>
        <source>Completed</source>
        <translation>Completados</translation>
    </message>
</context>
<context>
    <name>HotkeyEditWidget</name>
    <message>
        <location filename="../src/ui/hotkey-edit-widget.cpp" line="8"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
</context>
<context>
    <name>InputModeSelect</name>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="171"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="172"/>
        <source>Maps your gamepad inputs to a single N64 controller using your controller profile</source>
        <translation>Asigna tus entradas del mando a un solo mando de N64 usando tu perfil de configuración</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="193"/>
        <source>Dual Analog</source>
        <translation>Analógico doble</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="194"/>
        <source>Your gamepad inputs that normally bind to the C buttons instead bind to the analog stick on a second N64 controller</source>
        <translation>Las entradas del mando que normalmente estarían asignadas a los botones C se asignarán an stick analógico de un segundo mando de N64 en su lugar</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="215"/>
        <source>GoldenEye</source>
        <translation>GoldenEye</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="216"/>
        <source>Maps your gamepad inputs to two N64 controllers suitable for playing GoldenEye with the 2.4 Goodhead control style</source>
        <translation>Asigna tus entradas del mando  a dos mandos de N64 con una configuración apropiada para jugar a GoldenEye con el estilo de control &quot;2.4 Goodhead&quot;</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="237"/>
        <source>Clone</source>
        <translation>Clonar</translation>
    </message>
    <message>
        <location filename="../src/core/preset-controllers.cpp" line="238"/>
        <source>Your gamepad inputs are sent to two controller ports instead of just one</source>
        <translation>Tus entradas del mando se envían a dos puertos de mando en lugar de solo a uno</translation>
    </message>
</context>
<context>
    <name>KeyboardConfigDialog</name>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="14"/>
        <source>Configure Keyboard Controls</source>
        <translation>Configurar controles de teclado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="28"/>
        <source>Hotkeys</source>
        <translation>Atajos de teclado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/keyboard-config-dialog.ui" line="71"/>
        <source>Keyboard Controls</source>
        <translation>Controles de teclado</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="17"/>
        <source>Analog Up</source>
        <translation>Stick analógico arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="18"/>
        <source>Analog Down</source>
        <translation>Stick analógico abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="19"/>
        <source>Analog Left</source>
        <translation>Stick analógico izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="20"/>
        <source>Analog Right</source>
        <translation>Stick analógico derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="21"/>
        <source>C Up</source>
        <translation>C arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="22"/>
        <source>C Down</source>
        <translation>C abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="23"/>
        <source>C Left</source>
        <translation>C izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="24"/>
        <source>C Right</source>
        <translation>C derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="25"/>
        <source>D-Pad Up</source>
        <translation>D-Pad arriba</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="26"/>
        <source>D-Pad Down</source>
        <translation>D-Pad abajo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="27"/>
        <source>D-Pad Left</source>
        <translation>D-Pad izquierda</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="28"/>
        <source>D-Pad Right</source>
        <translation>D-Pad derecha</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="29"/>
        <source>A Button</source>
        <translation>Botón A</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="30"/>
        <source>B Button</source>
        <translation>Botón B</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="31"/>
        <source>L Trigger</source>
        <translation>Gatillo L</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="32"/>
        <source>Z Trigger</source>
        <translation>Gatillo Z</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="33"/>
        <source>R Trigger</source>
        <translation>Gatillo R</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="34"/>
        <source>Start Button</source>
        <translation>Botón Start</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="36"/>
        <source>Save State</source>
        <translation>Guardar estado</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="37"/>
        <source>Load State</source>
        <translation>Cargar estado guardado</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="38"/>
        <source>Previous State</source>
        <translation>Estado guardado anterior</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="39"/>
        <source>Next State</source>
        <translation>Siguiente estado guardado</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="40"/>
        <source>Previous Cheat</source>
        <translation>Truco anterior</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="41"/>
        <source>Next Cheat</source>
        <translation>Siguiente truco</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="42"/>
        <source>Toggle Cheat</source>
        <translation>Alternar truco</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="43"/>
        <source>Toggle FPS Display</source>
        <translation>Alternar contador de FPS</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="44"/>
        <source>Pause/Unpause</source>
        <translation>Activar/desactivar pausa</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="45"/>
        <source>Frame Advance</source>
        <translation>Avanzar fotograma</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="46"/>
        <source>Fast Forward (Hold)</source>
        <translation>Cámara rápida (mantener)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="47"/>
        <source>Fast Forward (Toggle)</source>
        <translation>Cámara rápida (alternar)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="48"/>
        <source>Slow Motion (Hold)</source>
        <translation>Cámara lenta (mantener)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="49"/>
        <source>Slow Motion (Toggle)</source>
        <translation>Cámra lenta (alternar)</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="50"/>
        <source>Rewind*</source>
        <translation>Rebobinar*</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="51"/>
        <source>Quit Emulator</source>
        <translation>Salir del emulador</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="52"/>
        <source>Hard Reset</source>
        <translation>Reinicio completo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="53"/>
        <source>Toggle Fullscreen</source>
        <translation>Alternar pantalla completa</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="54"/>
        <source>RetroArch Menu</source>
        <translation>Menú de RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="55"/>
        <source>Record Video</source>
        <translation>Grabar vídeo</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="56"/>
        <source>Record Inputs</source>
        <translation>Grabar entradas de mando</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="57"/>
        <source>Take Screenshot</source>
        <translation>Tomar captura de pantalla</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="58"/>
        <source>Raise Volume</source>
        <translation>Aumentar volumen</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="59"/>
        <source>Lower Volume</source>
        <translation>Bajar volumen</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="60"/>
        <source>Mute/Unmute</source>
        <translation>Activar/desactivar silencio</translation>
    </message>
    <message>
        <location filename="../src/ui/keyboard-config-dialog.cpp" line="92"/>
        <source>You must enable rewind functionality in the RetroArch menu to use this hotkey.</source>
        <translation>Debes activar la función de rebobinado en el menú de RetroArch para usar este atajo de teclado.</translation>
    </message>
</context>
<context>
    <name>LogViewerDialog</name>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="14"/>
        <source>Log Viewer</source>
        <translation>Visor de registros</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="28"/>
        <source>Only show logs from this session</source>
        <translation>Solo mostrar registros de esta sesión</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="48"/>
        <source>Show timestamps</source>
        <translation>Mostrar marcas de tiempo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="60"/>
        <source>Visible Logs</source>
        <translation>Registros visibles</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="66"/>
        <source>Debug</source>
        <translation>Depuración</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="76"/>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="86"/>
        <source>Warn</source>
        <translation>Advertencias</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="96"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/log-viewer-dialog.ui" line="106"/>
        <source>Fatal</source>
        <translation>Fatal</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../src/main.cpp" line="43"/>
        <source>Parallel Launcher will now setup an isolated Flatpak installation to install and manage RetroArch. This is kept separate from your main system and user installations.</source>
        <translation>Parallel launcher va a configurar una instalación aislada de Flatpak para instalar y administrar RetroArch. Esta se mantendrá aparte de tus instalaciones principales de sistema y de usuario.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="190"/>
        <location filename="../src/main.cpp" line="239"/>
        <source>Installing RetroArch</source>
        <translation>Instalando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="191"/>
        <source>Parallel Launcher will now install RetroArch.</source>
        <translation>Parallel Launcher va a instalar RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="200"/>
        <location filename="../src/main.cpp" line="228"/>
        <source>Fatal Error</source>
        <translation>Error irrecuperable</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="201"/>
        <source>Failed to install RetroArch.</source>
        <translation>No se ha podido instalar RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="210"/>
        <source>Flatpak Setup</source>
        <translation>Configuración de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="229"/>
        <source>Failed to create Flatpak installation.</source>
        <translation>No se ha podido crear una instalación de Flatpak.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="240"/>
        <source>RetroArch will now be installed.</source>
        <translation>Se va a instalar RetroArch.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="48"/>
        <source>Refresh ROM List</source>
        <translation>Actualizar lista de ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="65"/>
        <source>Configure Controller</source>
        <translation>Configurar mando</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="82"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="112"/>
        <source>Searching for ROMs...</source>
        <translation>Buscando ROMs...</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="169"/>
        <source>No ROMS have been found</source>
        <translation>No se ha encontrado ninguna ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="176"/>
        <location filename="../src/ui/designer/main-window.ui" line="295"/>
        <source>Manage ROM Sources</source>
        <translation>Administrar fuentes de ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="246"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="262"/>
        <source>Play Multiplayer</source>
        <translation>Jugar (multijugador)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="273"/>
        <source>Play Singleplayer</source>
        <translation>Jugar (un jugador)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="290"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="300"/>
        <source>Configure Controllers</source>
        <translation>Configurar mandos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="305"/>
        <source>Keyboard Controls and Hotkeys</source>
        <translation>Controles y atajos de teclado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="308"/>
        <source>Configure keyboard controls and hotkeys</source>
        <translation>Configurar controles y atajos de teclado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="313"/>
        <location filename="../src/ui/main-window.cpp" line="366"/>
        <source>Login to romhacking.com</source>
        <translation>Iniciar sesión en romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="318"/>
        <source>Logout of romhacking.com</source>
        <translation>Cerrar sesión en romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/main-window.ui" line="323"/>
        <source>Disable romhacking.com integration</source>
        <translation>Desactivar integración con romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="366"/>
        <source>Enable romhacking.com integration</source>
        <translation>Activar integración con romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="398"/>
        <source>Confirm Disable</source>
        <translation>Confirmar desactivación</translation>
    </message>
    <message>
        <location filename="../src/ui/main-window.cpp" line="398"/>
        <source>Are you sure you want to disable romhacking.com integration?</source>
        <translation>¿Estás seguro de que quieres desactivar la integración con romhacking.com?</translation>
    </message>
</context>
<context>
    <name>ManageGroupsDialog</name>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="14"/>
        <source>Manage Groups</source>
        <translation>Administrar grupos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="32"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="43"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/manage-groups-dialog.ui" line="54"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="47"/>
        <source>Confirm Delete</source>
        <translation>Confirmar borrado</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="47"/>
        <source>Are you sure you want to delete this group?</source>
        <translation>¿Estás segurto de que quieres borrar este grupo?</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="60"/>
        <source>Rename Group</source>
        <translation>Renombrar grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="60"/>
        <source>Enter a new name for your group</source>
        <translation>Introduce un nuevo nombre para tu grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="70"/>
        <source>Rename Failed</source>
        <translation>Fallo al renombrar</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="70"/>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="89"/>
        <source>A group with this name already exists.</source>
        <translation>Ya existe un grupo con este nombre.</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="84"/>
        <source>Create Group</source>
        <translation>Crear grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="84"/>
        <source>Enter a name for your new group</source>
        <translation>Introduce un nombre para tu nuevo grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/manage-groups-dialog.cpp" line="89"/>
        <source>Create Failed</source>
        <translation>Creación fallida</translation>
    </message>
</context>
<context>
    <name>MultiplayerControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="14"/>
        <source>Select Controllers</source>
        <translation>Elegir mandos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="22"/>
        <source>Port 1</source>
        <translation>Puerto 1</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="33"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="59"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="85"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="111"/>
        <source>-- None --</source>
        <translation>-- Ninguno --</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="41"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="67"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="93"/>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="119"/>
        <source>Detect Device</source>
        <translation>Detectar dispositivo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="48"/>
        <source>Port 2</source>
        <translation>Puerto 2</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="74"/>
        <source>Port 3</source>
        <translation>Puerto 3</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="100"/>
        <source>Port 4</source>
        <translation>Puerto 4</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/multiplayer-controller-select-dialog.ui" line="128"/>
        <source>Allow port 1 to save and load states</source>
        <translation>Permitir que el puerto 1 guarde y borre estados</translation>
    </message>
</context>
<context>
    <name>NeutralInputDialog</name>
    <message>
        <location filename="../src/ui/designer/neutral-input-dialog.ui" line="14"/>
        <source>Return to Neutral</source>
        <translation>Volver a la posición neutral</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/neutral-input-dialog.ui" line="29"/>
        <source>Return all triggers and analog sticks to their neutral position, then press any button on the controller or click the OK button to continue.</source>
        <translation>Deja que los sticks y los gatillos vuelvan a su posición neutral, y después pulsa cualquier botón en el mando o haz click en el botón Aceptar para continuar.</translation>
    </message>
</context>
<context>
    <name>NowPlayingWindow</name>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="29"/>
        <source>Now Playing: </source>
        <translation>Jugando ahora: </translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="94"/>
        <source>Play Time</source>
        <translation>Tiempo de juego</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="107"/>
        <source>Total</source>
        <translation>Total</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="138"/>
        <source>This Session</source>
        <translation>Esta sesión</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/now-playing-window.ui" line="208"/>
        <source>Kill Emulator</source>
        <translation>Matar emulador</translation>
    </message>
</context>
<context>
    <name>RhdcDownloadDialog</name>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="97"/>
        <source>Downloading patch</source>
        <translation>Descargando parche</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="130"/>
        <source>Failed to download patch from RHDC</source>
        <translation>No se ha podido descargar el parche de los servidores de RHDC</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="148"/>
        <source>Applying patch</source>
        <translation>Aplicando parche</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="157"/>
        <source>The rom could not be installed because you do not have an unmodified copy of the US version of Super Mario 64 in your known roms list.</source>
        <translation>No se ha podido instalar el parche porque no tienes una copia sin modificar de la versión americana de Super Mario 64 en tu lista de ROMs.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="189"/>
        <source>The rom could not be installed because no bps patch was found.</source>
        <translation>No se ha podido instalar la ROM porque no se encontró el parche bps.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="203"/>
        <source>Could not install &apos;%1&apos; because of an unexpected error while applying the patch</source>
        <translation>No se pudo instalar %1 debido a un error desconocido mientras se aplicaba el parche</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="213"/>
        <source>Computing checksum</source>
        <translation>Calculando suma de comprobación</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-download-dialog.cpp" line="224"/>
        <source>Romhack installed successfully</source>
        <translation>Romhack instalado correctamente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-download-dialog.ui" line="14"/>
        <source>Downloading Patch</source>
        <translation>Descargando parche</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-download-dialog.ui" line="25"/>
        <source>Fetching hack info</source>
        <translation>Obteniendo información del hack</translation>
    </message>
</context>
<context>
    <name>RhdcLoginDialog</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="14"/>
        <source>RHDC Login</source>
        <translation>Iniciar sesión en RHDC</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="66"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To enable romhacking.com integration, you must have an unmodified copy of the US version of &lt;span style=&quot; font-style:italic;&quot;&gt;Super Mario 64&lt;/span&gt; in z64 format.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Para activar la integración con romhacking.com, debes tener una copia sin modificar de la versión americana de &lt;span style=&quot; font-style:italic;&quot;&gt;Super Mario 64&lt;/span&gt; en formato z64.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="128"/>
        <source>Browse for SM64 ROM</source>
        <translation>Navegar a la ROM de SM64</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="180"/>
        <source>Sign in to romhacking.com</source>
        <translation>Iniciar sesión en romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="194"/>
        <source>Username</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="204"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="256"/>
        <source>Sign In</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="365"/>
        <source>Please confirm your romhacking.com integration settings. You can always change these later in the settings dialog.</source>
        <translation>Por favor, confirma tus ajustes para la integración con romhacking.com. Siempre puedes cambiar estas opciones más adelante en el menú de configuración.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="400"/>
        <source>Download Directory</source>
        <translation>Directorio de descargas</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="422"/>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="446"/>
        <source>Sets the directory that hacks downloaded from romhacking.com will be saved to. If you change this setting later, your roms will automatically be moved to the new directory.</source>
        <translation>Cambia el directorio en el que se descargan los hacks de romhacking.com. Si cambias esta opción más adelante, tus ROMs se moverán automáticamente al nuevo directorio.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="478"/>
        <source>Check all save slots</source>
        <translation>Comprobar todos los archivos guardados</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="496"/>
        <source>If checked, Parallel Launcher will submit your highest star count across all save slots to romhacking.com; otherwise, it will only submit your star count in slot A.</source>
        <translation>Si esta opción está activada, Parallel Launcher sincronizará el archivo guardado que más estrellas tenga con romhacking.com. De lo contrario, solo se sincronizarán las estrellas del archivo A.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="528"/>
        <source>Prefer HLE plugins</source>
        <translation>Preferir plugins HLE</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="546"/>
        <source>If checked, Parallel Launcher will use the GLideN64 plugin instead of the ParaLLEl plugin when it guesses that ParrLLEl is probably the best plugin to use. Only check this if your computer has an old GPU with poor Vulkan support. If you still experience lag even with GLideN64, you may need to disable &apos;Emulate Framebuffer&apos; and/or &apos;Emulate N64 Depth Compare&apos; in the GFX Plugins section of your Parallel Launcher settings.</source>
        <translation>Si esta opción está activada, Parallel Launcher usará el plugin GLideN64 en lugar de ParaLLEl en situaciones en las que normalmente el mejor plugin a usar sería ParaLLEl. Selecciona esta opción solo si tu ordenador tiene una tarjeta gráfica muy vieja con mal soporte para Vulkan. Si sufres ralentizaciones incluso con GLideN64, es posible que tengas que desactivar &quot;Emular framebuffer&quot; y/o &quot;Emular comparación de profundidad de N64&quot; en el apartado de plugins gráficos de la configuración de Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="578"/>
        <source>Sync groups</source>
        <translation>Sincronizar grupos</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-login-dialog.ui" line="599"/>
        <source>If checked, Parallel Launcher will sync your groups in Parallel Launcher with your lists on romhacking.com. Only groups containing at least one rom from romhacking.com will be synced.</source>
        <translation>Si esta opción está activada, Parallel Launcher sincronizará tus grupos del programa con tus listas en romhacking.com. Solo se sincronizarán aquellos grupos que contengan al menos una ROM de romhacking.com.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="61"/>
        <source>Select SM64 ROM</source>
        <translation>Elige la ROM de N64</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="67"/>
        <source>ROM Does not Match</source>
        <translation>la ROM no coincide</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="67"/>
        <source>The provided rom does not match the expected checksum.</source>
        <translation>La ROM proporcionada no coincide con la suma de comprobación.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="103"/>
        <source>Select a new download directory</source>
        <translation>Elige un nuevo directorio de descarga</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="111"/>
        <source>Enter your username</source>
        <translation>Introduce tu nombre de usuario</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="116"/>
        <source>Enter your password</source>
        <translation>Introduce tu contraseña</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="156"/>
        <source>Username or password is incorrect</source>
        <translation>El usuario o la contraseña son incorrectos</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="159"/>
        <source>This account requires e-mail confirmation to activate.</source>
        <translation>Esta cuenta requiere que se confirme el e-mail para activarse.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="162"/>
        <source>The romhacking.com servers appear to be down.</source>
        <translation>Los servidores de romhacking.com parecen estar caídos.</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-login-dialog.cpp" line="165"/>
        <source>An unknown error occurred.</source>
        <translation>Ha ocurrido un error desconocido.</translation>
    </message>
</context>
<context>
    <name>RhdcRatingDialog</name>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="14"/>
        <source>Rate this Hack</source>
        <translation>Puntuar este hack</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="25"/>
        <source>How would you rate this hack?</source>
        <translation>¿Cómo puntuarías este hack?</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="51"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Quality. &lt;/span&gt;How enjoyable, impressive, and/or polished was this hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Calidad. &lt;/span&gt;¿Cómo de disfrutable, impresionante y/o pulido te ha parecido este hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/designer/rhdc-rating-dialog.ui" line="162"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Difficulty. &lt;/span&gt;In general, how would you rate this hack&apos;s difficulty level?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Dificultad. &lt;/span&gt;En general, ¿Cómo de difícil crees que es este hack?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="9"/>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="23"/>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="37"/>
        <source>I can&apos;t decide or have no opinion</source>
        <extracomment>0</extracomment>
        <translation>No me puedo decidir o no tengo ninguna opinión</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="10"/>
        <source>Zero Effort</source>
        <extracomment>1</extracomment>
        <translation>Ningún esfuerzo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="11"/>
        <source>Poor Quality</source>
        <extracomment>2</extracomment>
        <translation>Baja calidad</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="12"/>
        <source>A Little Rough</source>
        <extracomment>3</extracomment>
        <translation>Un poco cutre</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="13"/>
        <source>Unremarkable</source>
        <extracomment>4</extracomment>
        <translation>Mediocre</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="14"/>
        <source>Decent</source>
        <extracomment>5</extracomment>
        <translation>Decente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="15"/>
        <source>Pretty Good</source>
        <extracomment>6</extracomment>
        <translation>Bastante bueno</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="16"/>
        <source>Very Good</source>
        <extracomment>7</extracomment>
        <translation>Muy bueno</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="17"/>
        <source>Excellent</source>
        <extracomment>8</extracomment>
        <translation>Excelente</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="18"/>
        <source>Exceptional</source>
        <extracomment>9</extracomment>
        <translation>Excepcional</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="19"/>
        <source>Legendary</source>
        <extracomment>10</extracomment>
        <translation>Legendario</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="24"/>
        <source>No Challenge</source>
        <extracomment>1</extracomment>
        <translation>Ningún reto</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="25"/>
        <source>Very Easy</source>
        <extracomment>2</extracomment>
        <translation>Muy fácil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="26"/>
        <source>Casual</source>
        <extracomment>3</extracomment>
        <translation>Casual</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="27"/>
        <source>Classic SM64</source>
        <extracomment>4</extracomment>
        <translation>Igual que el SM64 clásico</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="28"/>
        <source>Moderate</source>
        <extracomment>5</extracomment>
        <translation>Moderado</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="29"/>
        <source>Challenging</source>
        <extracomment>6</extracomment>
        <translation>Desafiante</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="30"/>
        <source>Difficult</source>
        <extracomment>7</extracomment>
        <translation>Difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="31"/>
        <source>Very Difficult</source>
        <extracomment>8</extracomment>
        <translation>Muy difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="32"/>
        <source>Extremely Difficult</source>
        <extracomment>9</extracomment>
        <translation>Extremadamente difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="33"/>
        <source>Borderline Kaizo</source>
        <extracomment>10</extracomment>
        <translation>Es casi un Kaizo</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="38"/>
        <source>Beginner/Introductory Kaizo</source>
        <extracomment>1</extracomment>
        <translation>Un Kaizo para principiantes</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="39"/>
        <source>Easy Kaizo</source>
        <extracomment>2</extracomment>
        <translation>Un Kaizo facilito</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="40"/>
        <source>Standard Kaizo</source>
        <extracomment>3</extracomment>
        <translation>Un Kaizo normal</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="41"/>
        <source>Moderate Kaizo</source>
        <extracomment>4</extracomment>
        <translation>Un Kaizo moderado</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="42"/>
        <source>Challenging Kaizo</source>
        <extracomment>5</extracomment>
        <translation>Un Kaizo desafiante</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="43"/>
        <source>Difficult Kaizo</source>
        <extracomment>6</extracomment>
        <translation>Un Kaizo difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="44"/>
        <source>Very Difficult Kaizo</source>
        <extracomment>7</extracomment>
        <translation>Un Kaizo muy difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="45"/>
        <source>Extremely Difficult Kaizo</source>
        <extracomment>8</extracomment>
        <translation>Un Kaizo extremadamente difícil</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="46"/>
        <source>Hardest humanly possible Kaizo</source>
        <extracomment>9</extracomment>
        <translation>Un kaizo casi imposible</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="47"/>
        <source>TAS/Unbeatable</source>
        <extracomment>10</extracomment>
        <translation>TAS/Imposible</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="58"/>
        <source>Submit</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <location filename="../src/rhdc/ui/rhdc-rating-dialog.cpp" line="82"/>
        <source>Not Rated</source>
        <translation>Sin puntuar</translation>
    </message>
</context>
<context>
    <name>RhdcSync</name>
    <message>
        <location filename="../src/rhdc/core/sync.cpp" line="164"/>
        <source>Failed to sync progress with romhacking.com</source>
        <translation>No se ha podido sincronizar el progreso con romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/rhdc/core/sync.cpp" line="171"/>
        <source>Failed to connect to romhacking.com</source>
        <translation>No se ha podido conectar a romhacking.com</translation>
    </message>
</context>
<context>
    <name>RomListModel</name>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="246"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="247"/>
        <source>Internal Name</source>
        <translation>Nombre interno</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="248"/>
        <source>File Path</source>
        <translation>Ruta del archivo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="249"/>
        <source>Last Played</source>
        <translation>Jugado por última vez</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-model.cpp" line="250"/>
        <source>Play Time</source>
        <translation>Tiempo de juego</translation>
    </message>
</context>
<context>
    <name>RomListView</name>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="206"/>
        <source>Delete Save File</source>
        <translation>Borrar partida guardada</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="207"/>
        <source>[SM64] Edit Save File</source>
        <translation>[SM64] Editar partida guardada</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="212"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="216"/>
        <source>Add to...</source>
        <translation>Añadir a....</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="223"/>
        <source>New Group</source>
        <translation>Nuevo grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="227"/>
        <source>Remove from %1</source>
        <translation>Eliminar de %1</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="233"/>
        <source>Open Containing Folder</source>
        <translation>Abrir carpeta contenedora</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="234"/>
        <source>Delete ROM</source>
        <translation>Borrar ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="236"/>
        <location filename="../src/ui/rom-list-view.cpp" line="327"/>
        <source>Rename</source>
        <translation>Renombrar</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="238"/>
        <source>Revert ROM Name</source>
        <translation>Revertir nombre de la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="243"/>
        <source>Rate Hack</source>
        <translation>Puntuar hack</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="246"/>
        <source>Mark as Not Completed</source>
        <translation>Marcar como no completado</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="248"/>
        <source>Mark as Completed</source>
        <translation>Marcar como completado</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="257"/>
        <location filename="../src/ui/rom-list-view.cpp" line="318"/>
        <source>Confirm Delete</source>
        <translation>Confirmar eliminación</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="257"/>
        <source>Are you sure you want to delete your save file?</source>
        <translation>¿Estás seguro de que quieres eliminar tu partida guardada?</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="276"/>
        <source>Create Group</source>
        <translation>Crear grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="276"/>
        <source>Enter a name for your new group</source>
        <translation>Escribe un nombre para tu nuevo grupo</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="282"/>
        <source>Group Exists</source>
        <translation>El grupo ya existe</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="282"/>
        <source>A group with this name already exists</source>
        <translation>Ya existe un grupo con este nombre</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="318"/>
        <source>This will completely remove the ROM file from your computer. Are you sure you want to delete this ROM?</source>
        <translation>Esto eliminará por completo la ROM de tu ordenador. ¿Estás seguro de que quieres eliminar esta ROM?</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-list-view.cpp" line="327"/>
        <source>Enter a new name for your rom</source>
        <translation>Escribe un nuevo nombre para to RUM</translation>
    </message>
</context>
<context>
    <name>RomSettingsWidget</name>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="22"/>
        <source>Input Mode</source>
        <translation>Modo de entrada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="81"/>
        <source>Unlocks the CPU to run at full speed, removing CPU-based lag you would encounter on console. This is almost always safe, but can rarely cause issues on certain ROMs.</source>
        <translation>Permite a la CPU funcionar a máxima velocidad, eliminando las ralentizaciones por CPU que ocurrirían en consola. Esto casi siempre es seguro, pero alguna vez puede producir fallos en ciertas ROMs.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="84"/>
        <source>Overclock CPU (Recommended)</source>
        <translation>Overclock de CPU (Recomendado)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="100"/>
        <source>Alters the vertical interrupt timing. In most cases this either gives a slight performance boost or has no effect, but in some cases it can cause the game to run at the wrong framerate.</source>
        <translation>Cambia el intervalo de &quot;interrupción vertical&quot;. En la mayoría de casos aumenta ligeramente el rendimiento o simplemente no hace nada, pero en ciertos casos puede provocar que el juego funcione a un framerate incorrecto.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="103"/>
        <source>Overclock VI</source>
        <translation>Overclock de VI</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="116"/>
        <source>Enable widescreen mode for ROMs that support it.</source>
        <translation>Activar modo panorámico para ROMs que lo admiten.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="119"/>
        <source>Widescreen</source>
        <translation>Panorámico</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="132"/>
        <source>Upscale textures drawn using the TEX_RECT command. This can cause visual artifacts in some games.</source>
        <translation>Reescalar las texturas dibujadas con el comando TEX_RECT. Esto puede causar fallos gráficos en algunos juegos.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="135"/>
        <source>Upscale TEXRECTs</source>
        <translation>Reescalar TEXRECTs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="148"/>
        <source>Emulate the native framebuffer. This is required for some visual effects to work, but may cause lag on lower end GPUs</source>
        <translation>Emula el framebuffer nativo. Esto es necesario para que funcionen algunos efectos visuales, pero podría causar ralentizaciones en GPUs poco potentes</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="151"/>
        <source>Emulate Framebuffer</source>
        <translation>Emular framebuffer</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="167"/>
        <source>Greatly increases accuracy by rendering decals correctly, but may cause a loss in performance</source>
        <translation>Aumenta mucho la precisión de la emulación renderizando los decals correctamente, pero podría causar una pérdida de rendimiento</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="170"/>
        <source>Emulate N64 Depth Compare</source>
        <translation>Emular la comparación de profundidad de N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="192"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;Not enabling CPU overlocking is likely to result in a laggy experience. This option should only be used for speedruns or testing where you want to approximate console CPU lag.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Advertencia: &lt;/span&gt;Lo más probable es que no activar el overclock de CPU provoque ralentizaciones. Esta opción solo debería usarse para speedruns, o cuando necesites hacer pruebas en las que tengas que aproximar las ralentizaciones de CPU de consola.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="216"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;The GLideN64 plugin for ParallelN64 is severely out of date. If you want to use this plugin, you should use the Mupen64plus-next emulator core.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Advertencia: &lt;/span&gt;El plugin GLideN64 para ParallelN64 está muy anticuado. Si quieres usar este plugin, deberías usar el núcleo Mupen64plus-next.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="259"/>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="356"/>
        <source>Graphics Plugin</source>
        <translation>Plugin gráfico</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="268"/>
        <source>ParaLLEl (Recommended - very accurate to console)</source>
        <translation>ParaLLEl (Recomendado - Emulación muy precisa)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="281"/>
        <source>Glide64 (Inaccurate, but needed by some older romhacks)</source>
        <translation>Glide64 (Poco preciso, pero es necesario para algunos romhacks antiguos)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="311"/>
        <source>GLideN64 [Old]</source>
        <translation>GLideN64 [Anticuado]</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-settings-widget.ui" line="365"/>
        <source>ParaLLEl (Recommended)</source>
        <translation>ParaLLEl (Recomendado)</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-settings-widget.cpp" line="170"/>
        <source>Show Fewer Plugins</source>
        <translation>Mostrar menos plugins</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-settings-widget.cpp" line="170"/>
        <source>Show More Plugins</source>
        <translation>Mostrar más plugins</translation>
    </message>
</context>
<context>
    <name>RomSourceDialog</name>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="14"/>
        <source>Manage ROM Sources</source>
        <translation>Administrar fuentes de ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="31"/>
        <source>ROM Search Folders</source>
        <translation>Carpetas para búsqueda de ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="68"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="82"/>
        <source>New Source</source>
        <translation>Nueva fuente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="103"/>
        <source>ROM Source</source>
        <translation>Fuente de la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="114"/>
        <source>Browse for a folder</source>
        <translation>Navegar a una carpeta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="121"/>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="431"/>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="502"/>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="134"/>
        <source>Also scan all subfolders</source>
        <translation>Escanear también todas las subcarpetas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="137"/>
        <source>Recursive</source>
        <translation>Recursiva</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="168"/>
        <source>Ignore directories that begin with a period character</source>
        <translation>Ignorar directorios cuyo nombre comience con un punto</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="171"/>
        <source>Ignore hidden directories</source>
        <translation>Ignorar directorios ocultos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="183"/>
        <source>Max Depth</source>
        <translation>Máxima profundidad</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="236"/>
        <source>Follow symbolic links to folders and ROMs</source>
        <translation>Respetar symlinks a carpetas y ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="239"/>
        <source>Follow Symlinks</source>
        <translation>Respetar symlinks</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="256"/>
        <source>Automatically add to groups</source>
        <translation>Añadir automaticamente a grupos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="289"/>
        <source>Manage Groups</source>
        <translation>Administrar grupos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="317"/>
        <source>Individual ROMs</source>
        <translation>ROMs individuales</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="348"/>
        <source>Forget Selected ROM</source>
        <translation>Olvidar ROM seleccionada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="359"/>
        <source>Add New ROM(s)</source>
        <translation>Añadir nueavs ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="388"/>
        <source>BPS Patches</source>
        <translation>Parches BPS</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="417"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="290"/>
        <source>Patch File</source>
        <translation>Archivo del parche</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="444"/>
        <source>Base ROM</source>
        <translation>ROM base</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="450"/>
        <source>Automatic (Search Existing ROMs)</source>
        <translation>Automático (Buscar ROMs existentes)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="463"/>
        <source>Provided ROM:</source>
        <translation>ROM proporcionada:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/rom-source-dialog.ui" line="532"/>
        <source>Apply Patch</source>
        <translation>Aplicar parche</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="267"/>
        <source>Select one or more ROMs</source>
        <translation>Selecciona una o más ROMs</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="289"/>
        <source>Select a .bps patch file</source>
        <translation>Selecciona un parche .bps</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="300"/>
        <source>Select a ROM</source>
        <translation>Selecciona una ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="329"/>
        <source>Patch Applied</source>
        <translation>Parche aplicado</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="329"/>
        <source>Saved patched rom to %1</source>
        <translation>La ROM parcheada se ha guardado en %1</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="344"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="347"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="351"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="353"/>
        <location filename="../src/ui/rom-source-dialog.cpp" line="357"/>
        <source>Patch Failed</source>
        <translation>Parcheo fallido</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="344"/>
        <source>Failed to patch ROM. The .bps patch appears to be invalid.</source>
        <translation>No se ha podido parchear la ROM. El parche .bps parece ser inválido.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="347"/>
        <source>Failed to patch ROM. The base ROM does not match what the patch expects.</source>
        <translation>No se ha podido parchear la ROM. La ROM base no coincide con la que requiere el parche.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="351"/>
        <source>Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher.</source>
        <translation>No se ha podido parchear la ROM. Parallel Launcher no tiene constancia de la ROM base requerida para este parche.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="353"/>
        <source>Failed to patch ROM. The base ROM is missing or invalid.</source>
        <translation>No se ha podido archear la ROM. La ROM base no existe o es inválida.</translation>
    </message>
    <message>
        <location filename="../src/ui/rom-source-dialog.cpp" line="357"/>
        <source>Failed to patch ROM. An error occurred while writing the patched ROM to disk.</source>
        <translation>No se ha podido parchear la ROM. Se ha producido un error al escribir la ROM parcheada al disco.</translation>
    </message>
</context>
<context>
    <name>SaveFileEditorDialog</name>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="14"/>
        <source>Edit SM64 Save File</source>
        <translation>Editar partida guardada de SM64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Warning: &lt;/span&gt;This is a save file editor for Super Mario 64 and SM64 romhacks. Attempting to use this save file editor with other ROMs will corrupt your save file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Advertencia: &lt;/span&gt;Este es un editor de partidas guardadas para Super Mario 64 y romhacks del mismo. Si intentas usar este editor para otras ROMs, corromperá tu partida guardada.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="41"/>
        <source>Save Slot:</source>
        <translation>Archivo de guardado:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="55"/>
        <source>Slot A (Empty)</source>
        <translation>Slot A (Empty)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="60"/>
        <source>Slot B (Empty)</source>
        <translation>Archiivo B (Vacío)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="65"/>
        <source>Slot C (Empty)</source>
        <translation>Archiivo C (Vacío)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="70"/>
        <source>Slot D (Empty)</source>
        <translation>Archiivo D (Vacío)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="95"/>
        <source>Delete Save Slot</source>
        <translation>Borrar partida guardada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-file-editor-dialog.ui" line="106"/>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="58"/>
        <source>Edit Save Slot</source>
        <translation>Editar partida guardada</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="13"/>
        <source>Slot %1 (Empty)</source>
        <translation>Archivo %1 (Vacío)</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="16"/>
        <source>Slot %1 (%2 Stars)</source>
        <translation>Archiivo %1 (%2 estrellas)</translation>
    </message>
    <message>
        <location filename="../src/ui/save-file-editor-dialog.cpp" line="62"/>
        <source>Create Save Slot</source>
        <translation>Crear partida guardada</translation>
    </message>
</context>
<context>
    <name>SaveSlotEditorDialog</name>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="14"/>
        <source>Edit Save Slot (SM64)</source>
        <translation>Editar partida guardada (SM64)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="20"/>
        <source>Show flags and stars unused in the vanilla game</source>
        <translation>Mostrar flags y estrellas que nunca se usan en el juego base</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="32"/>
        <source>Flags</source>
        <translation>Flags</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="74"/>
        <source>Caps Unlocked</source>
        <translation>Gorras desbloqueadas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="80"/>
        <source>Wing Cap</source>
        <translation>Gorra voladora</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="93"/>
        <source>Metal Cap</source>
        <translation>Gorra de metal</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="106"/>
        <source>Vanish Cap</source>
        <translation>Gorra de invisibilidad</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="122"/>
        <source>Keys Collected</source>
        <translation>Llaves obtenidas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="128"/>
        <source>Basement Key</source>
        <translation>Llave del sótano</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="141"/>
        <source>Upstairs Key</source>
        <translation>Llave de la segunda planta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="157"/>
        <source>Unlocked Doors</source>
        <translation>Puertas desbloqueadas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="163"/>
        <source>Basement Key Door</source>
        <translation>Puerta al sótano</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="176"/>
        <source>Upstairs Key Door</source>
        <translation>Puerta con llave de la segunda planta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="189"/>
        <source>Peach&apos;s Secret Slide Door</source>
        <translation>Puerta al tobogán secreto de la Princesa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="202"/>
        <source>Whomp&apos;s Fortress Door</source>
        <translation>Puerta de la Fortaleza de Piedra</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="215"/>
        <source>Cool Cool Mountain Door</source>
        <translation>Puerta a montaña helada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="228"/>
        <source>Jolly Rodger Bay Door</source>
        <translation>Puerta a la Bahía del Capitán</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="241"/>
        <source>Dark World Door</source>
        <translation>Puerta a Bowser en las tinieblas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="254"/>
        <source>Fire Sea Door</source>
        <translation>Puerta a Bowser en la lava</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="267"/>
        <source>50 Star Door</source>
        <translation>Puerta de 50 estrellas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="283"/>
        <source>Miscellaneous</source>
        <translation>Miscelánea</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="289"/>
        <source>Moat Drained</source>
        <translation>Foso vaciado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="302"/>
        <source>Bowser&apos;s Sub Gone</source>
        <translation>El submarino de Bowser se ha ido</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="318"/>
        <source>Unused</source>
        <translation>Sin usar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="366"/>
        <source>Lost/Stolen Cap</source>
        <translation>Gorra perdida o robada</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="374"/>
        <source>Level</source>
        <translation>Nivel</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="395"/>
        <source>Area</source>
        <translation>Área</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="427"/>
        <source>Cap Stolen By:</source>
        <translation>Gorra robada por:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="434"/>
        <source>The flag indicates that Mario&apos;s cap is on the ground, however, when loading a save file, a cap that is on the ground is either given back to Mario or moved to the appropriate NPC for the area, so it will never actually be on the ground.</source>
        <translation>Este flag indica que la gorra de Mario está en el suelo, no obstante, cuando cargas una partida guardada, una gorra que está en el suelo o bien vuelve a Mario o bien vuelve al NPC apropiado para el área, así que nunca estará realmente en el suelo.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="437"/>
        <source>Automatic*</source>
        <translation>Automático*</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="450"/>
        <source>Klepto (Bird)</source>
        <translation>Klepto (pájaro)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="463"/>
        <source>Ukiki (Monkey)</source>
        <translation>Troncui (mono)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="476"/>
        <source>Mr. Blizzard (Snowman)</source>
        <translation>Frido (monigote de nieve)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/save-slot-editor-dialog.ui" line="499"/>
        <source>Stars and Coins</source>
        <translation>Estrellas y monedas</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="44"/>
        <source>Big Boo&apos;s Haunt</source>
        <translation>Mansión Encantada</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="45"/>
        <source>Cool Cool Mountain</source>
        <translation>Montaña helada</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="46"/>
        <source>Castle Interior</source>
        <translation>Interior del castillo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="47"/>
        <source>Hazy Maze Cave</source>
        <translation>Cueva del laberinto</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="48"/>
        <source>Shifting Sand Land</source>
        <translation>Arenas Ardientes</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="49"/>
        <source>Bob-Omb Battlefield</source>
        <translation>Campo de los Bob-omb</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="50"/>
        <source>Snowman&apos;s Land</source>
        <translation>País de Nieve</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="51"/>
        <source>Wet Dry World</source>
        <translation>Ciudad Esponja</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="52"/>
        <source>Jolly Rodger Bay</source>
        <translation>Bahía del Capitán</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="53"/>
        <source>Tiny-Huge Island</source>
        <translation>Isla Peque-grande</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="54"/>
        <source>Tick Tock Clock</source>
        <translation>Reloj Tictac</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="55"/>
        <source>Rainbow Ride</source>
        <translation>Camino del arco iris</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="56"/>
        <source>Castle Grounds</source>
        <translation>Jardines del castillo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="57"/>
        <source>Bowser in the Dark World</source>
        <translation>Bowser en las tinieblas</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="58"/>
        <source>Vanish Cap Under the Moat</source>
        <translation>El Secreto del Foso</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="59"/>
        <source>Bowser in the Fire Sea</source>
        <translation>Bowser en la lava</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="60"/>
        <source>Secret Aquarium</source>
        <translation>El Acuario Secreto</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="61"/>
        <source>Bowser in the Sky</source>
        <translation>Bowser en el cielo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="62"/>
        <source>Lethal Lava Land</source>
        <translation>Tierra del Fuego</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="63"/>
        <source>Dire Dire Docks</source>
        <translation>Gran Muelle</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="64"/>
        <source>Whomp&apos;s Fortress</source>
        <translation>Fortaleza de piedra</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="65"/>
        <source>End Screen</source>
        <translation>Pantalla final</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="66"/>
        <source>Castle Courtyard</source>
        <translation>Patio del castillo</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="67"/>
        <source>Peach&apos;s Secret Slide</source>
        <translation>El Tobogán de la Princesa</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="68"/>
        <source>Cavern of the Metal Cap</source>
        <translation>Tras la cascada</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="69"/>
        <source>Tower of the Wing Cap</source>
        <translation>El Interruptor ?</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="70"/>
        <source>Bowser 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="71"/>
        <source>Winged Mario over the Rainbow</source>
        <translation>Sobre los Arco Iris</translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="73"/>
        <source>Bowser 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="74"/>
        <source>Bowser 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/core/sm64.cpp" line="76"/>
        <source>Tall, Tall Mountain</source>
        <translation>Montaña Escarpada</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="11"/>
        <source>8 Red Coins</source>
        <translation>8 Monedas Rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="12"/>
        <source>100 Coins</source>
        <translation>100 Monedas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="17"/>
        <source>Toad 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="18"/>
        <source>Toad 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="19"/>
        <source>Toad 3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="20"/>
        <source>MIPS 1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="21"/>
        <source>MIPS 2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="27"/>
        <source>Big Bob-Omb on the Summit</source>
        <translation>Gran Bob-omb en la cima</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="28"/>
        <source>Footface with Koopa the Quick</source>
        <translation>El reto de Koopa el rápido</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="29"/>
        <source>Shoot to the Island in the Sky</source>
        <translatorcomment>Not present in the DS version, so there&apos;s no official Spanish translation</translatorcomment>
        <translation>Disprara a la isla en el cielo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="30"/>
        <source>Find the 8 Red Coins</source>
        <translation>En busca de las 8 Monedas Rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="31"/>
        <source>Mario Wings to the Sky</source>
        <translation>El vuelo de Mario</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="32"/>
        <source>Behind Chain Chomp&apos;s Gate</source>
        <translation>Da rienda suelta a Chomp Cadenas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="37"/>
        <source>Chip Off Whomp&apos;s Block</source>
        <translation>Derroca a Roco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="38"/>
        <source>To the Top of the Fortress</source>
        <translation>En lo más alto de la fortaleza</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="39"/>
        <source>Shoot into the Wild Blue</source>
        <translation>Lanzado hacia el cielo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="40"/>
        <source>Red Coins on the Floating Isle</source>
        <translation>Monedas Rojas en la isla flotante</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="41"/>
        <source>Fall onto the Caged Island</source>
        <translation>Caída libre en la Isla de la Jaula</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="42"/>
        <source>Blast Away the Wall</source>
        <translation>A cañonazos contra el muro</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="47"/>
        <source>Plunder in the Sunken Ship</source>
        <translation>El botín del barco hundido</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="48"/>
        <source>Can the Eel Come Out to Play?</source>
        <translation>La morena la vigila</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="49"/>
        <source>Treasure of the Ocean Cave</source>
        <translation>Tesoro en la Cueva del Océano</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="50"/>
        <source>Red Coins on the Ship Afloat</source>
        <translation>Monedas Rojas como perlas del mar</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="51"/>
        <source>Blast to the Stone Pillar</source>
        <translation>Apunta a lo alto de la aguja</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="52"/>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="110"/>
        <source>Through the Jet Stream</source>
        <translation>Que no te lleve la corriente</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="57"/>
        <source>Slip Slidin&apos; Away</source>
        <translation>Al final del tobogán</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="58"/>
        <source>Li&apos;l Penguin Lost</source>
        <translation>Pequeño pingüino perdido</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="59"/>
        <source>Big Penguin Race</source>
        <translation>El más rápido del hielo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="60"/>
        <source>Frosty Slide for 8 Red Coins</source>
        <translation>8 Monedas Rojas en la montaña</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="61"/>
        <source>Snowman&apos;s Lost his Head</source>
        <translation>Muñeco de nieve sin cabeza</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="62"/>
        <source>Wall Kicks Will Work</source>
        <translation>Patada en la pared de Mario</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="67"/>
        <source>Go on a Ghost Hunt</source>
        <translation>Cazafantasmas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="68"/>
        <source>Ride Big Boo&apos;s Merry-Go-Round</source>
        <translation>El tiovivo del Gran Boo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="69"/>
        <source>Secret of the Haunted Books</source>
        <translation>El secreto que guardan los libros</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="70"/>
        <source>Seek the 8 Red Coins</source>
        <translation>Las 8 endiabladas Monedas Rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="71"/>
        <source>Big Boo&apos;s Balcony</source>
        <translation>El balcón del Gran Boo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="72"/>
        <source>Eye to Eye in the Secret Room</source>
        <translation>¡Ojo en la habitación secreta!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="77"/>
        <source>Swimming Beast in the Cavern</source>
        <translation>El monstruo de la Cueva del Lago</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="78"/>
        <source>Elevate for 8 Red Coins</source>
        <translation>El camino de las 8 Monedas Rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="79"/>
        <source>Metal-Head Mario Can Move!</source>
        <translation>¡Mario, el hombre de hierro!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="80"/>
        <source>Navigating the Toxic Maze</source>
        <translation>En el laberinto tóxico</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="81"/>
        <source>A-maze-ing Emergency Exit</source>
        <translation>La otra salida del laberinto</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="82"/>
        <source>Watch for Rolling Rocks</source>
        <translation>En las bolas de piedra</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="87"/>
        <source>Boil the Big Bully</source>
        <translation>Lava al gran Bronco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="88"/>
        <source>Bully the Bullies</source>
        <translation>Tres tristes Broncos</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="89"/>
        <source>8-Coin Puzzle with 15 Pieces</source>
        <translation>El puzle de las 8 Monedas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="90"/>
        <source>Red-Hot Log Rolling</source>
        <translation>¡Tronco, cómo quema!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="91"/>
        <source>Hot-Foot-it into the Volcano</source>
        <translation>En el corazón del volcán</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="92"/>
        <source>Elevator Tour in the Volcano</source>
        <translation>Escalada en el volcán</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="97"/>
        <source>In the Talons of the Big Bird</source>
        <translation>En las garras del pajarraco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="98"/>
        <source>Shining Atop the Pyramid</source>
        <translation>En lo alto de la pirámide</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="99"/>
        <source>Inside the Ancient Pyramid</source>
        <translation>El secreto de la pirámide</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="100"/>
        <source>Stand Tall on the Four Pillars</source>
        <translation>Corona los cuatro pilares</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="101"/>
        <source>Free Flying for 8 Red Coins</source>
        <translation>8 Monedas Rojas en vuelo libre</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="102"/>
        <source>Pyramid Puzzle</source>
        <translation>Laberinto de la pirámide</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="107"/>
        <source>Board Bowser&apos;s Sub</source>
        <translation>Sobre el submarino</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="108"/>
        <source>Chests in the Current</source>
        <translation>Cofres en la corriente</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="109"/>
        <source>Pole-Jumping for Red Coins</source>
        <translation>Monedas Rojas, poste a poste</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="111"/>
        <source>The Manta Ray&apos;s Reward</source>
        <translation>Tras la estela de la manta</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="112"/>
        <source>Collect the Caps...</source>
        <translation>Dentro de la jaula</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="117"/>
        <source>Snowman&apos;s Big Head</source>
        <translation>Sobre la cabeza del muñeco</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="118"/>
        <source>Chill with the Bully</source>
        <translation>El duelo del hielo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="119"/>
        <source>In the Deep Freeze</source>
        <translatorcomment>This star isn&apos;t present in the DS version, so there&apos;s no official translation</translatorcomment>
        <translation>En el frío profundo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="120"/>
        <source>Whirl from the Freezing Pond</source>
        <translation>Más allá del lago helado</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="121"/>
        <source>Shell Shreddin&apos; for Red Coins</source>
        <translation>Surfeando en busca de monedas rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="122"/>
        <source>Into the Igloo</source>
        <translation>En el iglú</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="127"/>
        <source>Shocking Arrow Lifts!</source>
        <translation>¡Mojando plataformas!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="128"/>
        <source>Top o&apos; the Town</source>
        <translation>En lo más alto de la ciudad</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="129"/>
        <source>Secrets in the Shallows &amp; Sky</source>
        <translation>Los 5 números secretos</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="130"/>
        <source>Express Evelator--Hurry Up!</source>
        <translation>Ascensor expreso: ¡Date pisa!</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="131"/>
        <source>Go to Town for Red Coins</source>
        <translation>El rojo brillo de la ciudad</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="132"/>
        <source>Quick Race through Downtown!</source>
        <translation>En la parte baja de la ciudad</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="137"/>
        <source>Scale the Mountain</source>
        <translation>Escala la montaña</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="138"/>
        <source>Mystery of the Monkey&apos;s Cage</source>
        <translation>El misterio de la jaula del mono</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="139"/>
        <source>Scary &apos;Shrooms, Red Coins</source>
        <translation>Monedas Rojas en los sombreros</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="140"/>
        <source>Mysterious Mountainside</source>
        <translation>El tobogán misterioso</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="141"/>
        <source>Breathtaking View from Bridge</source>
        <translation>Detrás de la cascada</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="142"/>
        <source>Blast to the Lonely Mushroom</source>
        <translation>Disparado al champiñón solitario</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="147"/>
        <source>Pluck the Piranha Flower</source>
        <translation>Sin miedo contra las flores piraña</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="148"/>
        <source>The Tip Top of the Huge Island</source>
        <translation>En lo alto de la isla gigante</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="149"/>
        <source>Rematch with Koopa the Quick</source>
        <translation>Revancha contra Koopa el rápido</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="150"/>
        <source>Five Itty Bitty Secrets</source>
        <translatorcomment>This star is not present in the DS version so there is no official translation</translatorcomment>
        <translation>Cinco pequeños secretillos</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="151"/>
        <source>Wiggler&apos;s Red Coins</source>
        <translation>Las Monedas Rojas de Floruga</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="152"/>
        <source>Make Wiggler Squirm</source>
        <translation>Dale a Floruga una lección</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="157"/>
        <source>Roll into the Cage</source>
        <translation>Mario en la jaula</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="158"/>
        <source>The Pit and the Pendulums</source>
        <translatorcomment>This star is a little different in the DS version, so there&apos;s no official translation</translatorcomment>
        <translation>El precipicio y los péndulos</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="159"/>
        <source>Get a Hand</source>
        <translation>Una manilla, por favor</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="160"/>
        <source>Stomp on the Thwomp</source>
        <translation>Pica a Roca Picuda</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="161"/>
        <source>Timed Jumps on Moving Bars</source>
        <translation>Las barras y barreras del tiempo</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="162"/>
        <source>Stop Time for Red Coins</source>
        <translation>Para el tiempo de Monedas Rojas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="167"/>
        <source>Cruiser Crossing the Rainbow</source>
        <translation>Mascarón estelar</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="168"/>
        <source>The Big House in the Sky</source>
        <translation>El casón celestial</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="169"/>
        <source>Coins Amassed in a Maze</source>
        <translation>Las Monedas del laberinto vertical</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="170"/>
        <source>Swingin&apos; in the Breeze</source>
        <translation>Después del vaivén</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="171"/>
        <source>Tricky Triangles!</source>
        <translation>El secreto de las pirámides</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="172"/>
        <source>Somewhere Over the Rainbow</source>
        <translation>En algún lugar del arco iris</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="227"/>
        <source>Act 1 Star</source>
        <translation>Estrella del acto 1</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="228"/>
        <source>Act 2 Star</source>
        <translation>Estrella del acto 2</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="229"/>
        <source>Act 3 Star</source>
        <translation>Estrella del acto 3</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="230"/>
        <source>Act 4 Star</source>
        <translation>Estrella del acto 4</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="231"/>
        <source>Act 5 Star</source>
        <translation>Estrella del acto 5</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="232"/>
        <source>Act 6 Star</source>
        <translation>Estrella del acto 6</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="233"/>
        <source>100 Coin Star</source>
        <translation>Estrella de 100 monedas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="234"/>
        <source>Cannon Status</source>
        <translation>Estado del cañón</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="235"/>
        <source>Coin High Score</source>
        <translation>Récord de monedas</translation>
    </message>
    <message>
        <location filename="../src/ui/save-slot-editor-dialog.cpp" line="315"/>
        <source>-- None --</source>
        <translation>-- Ninguno --</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="44"/>
        <source>User Interface</source>
        <translation>Interfaz</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="49"/>
        <source>Emulation</source>
        <translation>Emulación</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="54"/>
        <source>BPS Patches</source>
        <translation>Parches BPS</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="59"/>
        <source>GFX Plugins</source>
        <translation>Plugins gráficos</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="64"/>
        <source>Updaters</source>
        <translation>Actualizadores</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="69"/>
        <source>Romhacking.com</source>
        <translation>Romhacking.com</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="96"/>
        <source>Theme (Requires Restart)</source>
        <translation>Tema (Requiere reiniciar)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="112"/>
        <source>Hide launcher while playing ROM</source>
        <translation>Ocultar Parallel Launcher mientras juegas a la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="119"/>
        <source>Check for updates on startup</source>
        <translation>Comprobar actualizaciones al arranque</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="129"/>
        <source>Visible Columns</source>
        <translation>Columnas visibles</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="135"/>
        <source>The full path to the file</source>
        <translation>La ruta completa del archivo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="138"/>
        <source>File Path</source>
        <translation>Ruta del archivo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="148"/>
        <source>The filename without the extension</source>
        <translation>El nombre de archivo sin la extensión</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="151"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="164"/>
        <source>The name stored in the ROM itself</source>
        <translation>El nombre almacenado dentro de la propia ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="167"/>
        <source>Internal Name</source>
        <translation>Nombre interno</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="174"/>
        <source>The date you last played the ROM</source>
        <translation>La fecha en la que jugaste la ROM por última vez</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="177"/>
        <source>Last Played</source>
        <translation>Jugado por última vez</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="187"/>
        <source>The total time spent playing the ROM</source>
        <translation>El tiempo total que has empleado la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="190"/>
        <source>Total Play Time</source>
        <translation>Tiempo de juego total</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="231"/>
        <source>Window Scale</source>
        <translation>Escala de la ventana</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="289"/>
        <source>Default ParallelN64 Plugin</source>
        <translation>Plugin por defecto para ParallelN64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="299"/>
        <source>Default Mupen Plugin</source>
        <translation>Plugin por defecto para Mupen</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="370"/>
        <source>Default Emulator Core</source>
        <translation>Núcleo de emulación por defecto</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="382"/>
        <source>Vsync (May cause slight audio crackling)</source>
        <translation>Sincronización vertical (podría causar errores menores de audio)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="389"/>
        <source>Pause when emulator loses focus</source>
        <translation>Pausar emulación cuando la ventana no esté activa</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="404"/>
        <source>Reset RetroArch Config</source>
        <translation>Resetear configuración de RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="456"/>
        <source>When loading a BPS patch, save the patched ROM...</source>
        <translation>Cuando se cargue un parche BPS, guardar la ROM parcheada en...</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="463"/>
        <source>To the same folder as the patch</source>
        <translation>La misma carpeta en la que está el parche</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="476"/>
        <source>To this folder:</source>
        <translation>Esta carpeta:</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="518"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1203"/>
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="553"/>
        <source>Global Settings</source>
        <translation>Opciones globales</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="577"/>
        <source>Upscaling</source>
        <translation>Reescalar</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="593"/>
        <source>Native (x1 - 320x240)</source>
        <translation>Nativa (x1 - 320x240)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="631"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="767"/>
        <source>Anti-Aliasing</source>
        <translation>Anti-Aliasing</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="666"/>
        <source>Filtering</source>
        <translation>Filtrado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="677"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="682"/>
        <source>Anti-Alias</source>
        <translation>Anti-Aliasing</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="687"/>
        <source>Anti-Alias + Dedither</source>
        <translation>Anti-Aliasing + anti-dither</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="692"/>
        <source>Anti-Alias + Blur</source>
        <translation>Anti-Aliasing + difuminado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="697"/>
        <source>Filtered</source>
        <translation>Filtrado</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="745"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="889"/>
        <source>(Mupen64Plus-Next Only)</source>
        <translation>(Solo para Mupen64Plus-Next)</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="777"/>
        <source>Use N64 3-Point Filtering</source>
        <translation>Usar filtrado de 3 puntos de N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="801"/>
        <source>Default ROM Settings</source>
        <translation>Opciones por defecto de la ROM</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="825"/>
        <source>Upscale textures drawn using the TEX_RECT command. This can cause visual artifacts in some games.</source>
        <translation>Reescalar las texturas dibujadas con el comando TEX_RECT. Esto puede causar fallos gráficos en ciertos juegos.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="828"/>
        <source>Upscale TEXRECTs</source>
        <translation>Reescalar TEXRECTs</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="848"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="939"/>
        <location filename="../src/ui/designer/settings-dialog.ui" line="983"/>
        <source>Apply to all existing ROMs</source>
        <translation>Aplicar a ROMs existentes</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="913"/>
        <source>Emulate the native framebuffer. This is required for some visual effects to work, but may cause lag on lower end GPUs</source>
        <translation>Emula el framebuffer nativo. Esto es necesario para que funcionen algunos efectos visuales, pero podría causar ralentizaciones en GPUs poco potentes</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="916"/>
        <source>Emulate Framebuffer</source>
        <translation>Emular framebuffer</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="957"/>
        <source>Greatly increases accuracy by rendering decals correctly, but may cause a loss in performance</source>
        <translation>Aumenta mucho la precisión de la emulación, pero podría causar una pérdida de rendimiento</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="960"/>
        <source>Emulate N64 Depth Compare</source>
        <translation>Emular la comparación de profundidad de N64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1020"/>
        <source>Enable RetroArch Automatic Updates</source>
        <translation>Activar actualizaciones automáticas de RetroArch</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1030"/>
        <source>Enable ParallelN64 Automatic Updates</source>
        <translation>Activar actualizaciones automáticas de ParallelN64</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1040"/>
        <source>Enable Mupen64Plus-Next Automatic Updates</source>
        <translation>Activar actualizaciones automáticas de Mupen64Plus-Next</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1068"/>
        <source>Use development branch</source>
        <translation>Usar variante de desarrollo</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1082"/>
        <source>Update Interval</source>
        <translation>Intervalo de actualización</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1102"/>
        <source>Every Launch</source>
        <translation>Cada vez que se ejecuta</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1107"/>
        <source>Daily</source>
        <translation>Diariamente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1112"/>
        <source>Weekly</source>
        <translation>Semanalmente</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1117"/>
        <source>Monthly</source>
        <translation>Mensual</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1142"/>
        <source>Check for Updates</source>
        <translation>Comprobar actualizaciones</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1181"/>
        <source>Download Directory</source>
        <translation>Directorio de descargas</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1193"/>
        <source>Sets the directory that hacks downloaded from romhacking.com will be saved to. If you change this setting later, your roms will automatically be moved to the new directory.</source>
        <translation>Cambia el directorio en el que se descargan los hacks de romhacking.com. Si cambias esta opción más adelante, tus ROMs se moverán automáticamente al nuevo directorio.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1232"/>
        <source>If checked, Parallel Launcher will submit your highest star count across all save slots to romhacking.com; otherwise, it will only submit your star count in slot A.</source>
        <translation>Si esta opción está activada, Parallel Launcher sincronizará el archivo guardado que más estrellas tenga con romhacking.com. De lo contrario, solo se sincronizarán las estrellas del archivo A.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1235"/>
        <source>Check all save slots</source>
        <translation>Comprobar todos los archivos guardados</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1242"/>
        <source>If checked, Parallel Launcher will use the GLideN64 plugin instead of the ParaLLEl plugin when it guesses that ParrLLEl is probably the best plugin to use. Only check this if your computer has an old GPU with poor Vulkan support. If you still experience lag even with GlideN64, you may need to disable &apos;Emulate Framebuffer&apos; and/or &apos;Emulate N64 Depth Compare&apos; in the GFX Plugins section of your Parallel Launcher settings.</source>
        <translation>Si esta opción está activada, Parallel Launcher usará el plugin GLideN64 en lugar de ParaLLEl en situaciones en las que normalmente el mejor plugin a usar sería ParaLLEl. Selecciona esta opción solo si tu ordenador tiene una tarjeta gráfica muy vieja con mal soporte para Vulkan. Si sufres ralentizaciones incluso con GLideN64, es posible que tengas que desactivar &quot;Emular framebuffer&quot; y/o &quot;Emular comparación de profundidad de N64&quot; en el apartado de plugins gráficos de la configuración de Parallel Launcher.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1245"/>
        <source>Prefer HLE plugins</source>
        <translation>Preferir plugins HLE</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1252"/>
        <source>If checked, Parallel Launcher will sync your groups in Parallel Launcher with your lists on romhacking.com. Only groups containing at least one rom from romhacking.com will be synced.</source>
        <translation>Si esta opción está activada, Parallel Launcher sincronizará tus grupos del programa con tus listas en romhacking.com. Solo se sincronizarán aquellos grupos que contengan al menos una ROM de romhacking.com.</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/settings-dialog.ui" line="1255"/>
        <source>Sync groups</source>
        <translation>Sincronizar grupos</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="206"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="210"/>
        <location filename="../src/ui/settings-dialog.cpp" line="217"/>
        <source>Select a Folder</source>
        <translation>Selecciona una carpeta</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="226"/>
        <source>Confirm Reset</source>
        <translation>Confirmar restablecimiento</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="227"/>
        <source>This will reset your RetroArch config file, undoing any changes you have made within RetroArch. Your Parallel Launcher settings will not be affected. Do you want to continue?</source>
        <translation>Esto restablecerá tu archivo de configuración de RetroArch, deshaciendo cualquier cambio que hayas hecho dentro del mismo. Esto no afectará a tu configuración de Parallel Launcher. ¿Quieres continuar?</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="230"/>
        <source>Config Reset</source>
        <translation>Configurar restablecimiento</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="230"/>
        <source>Your RetroArch config has been reset.</source>
        <translation>Se ha restablecido tu configuración de RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="232"/>
        <source>Oops</source>
        <translation>Ups</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="232"/>
        <source>An unknown error occurred. Your RetroArch config has not been reset.</source>
        <translation>Se ha producido un error desconocido. No se ha restablecido tu configuración de RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="250"/>
        <location filename="../src/ui/settings-dialog.cpp" line="256"/>
        <location filename="../src/ui/settings-dialog.cpp" line="262"/>
        <source>Confirm Apply All</source>
        <translation>Confirmar aplicar todo</translation>
    </message>
    <message>
        <location filename="../src/ui/settings-dialog.cpp" line="250"/>
        <location filename="../src/ui/settings-dialog.cpp" line="256"/>
        <location filename="../src/ui/settings-dialog.cpp" line="262"/>
        <source>Apply this setting to all current roms?</source>
        <translation>¿Aplicar esta opción a todas las ROMs actuales?</translation>
    </message>
</context>
<context>
    <name>SingleplayerControllerSelectDialog</name>
    <message>
        <location filename="../src/ui/designer/singleplayer-controller-select-dialog.ui" line="20"/>
        <source>Controller Select</source>
        <translation>Elige un mando</translation>
    </message>
    <message>
        <location filename="../src/ui/designer/singleplayer-controller-select-dialog.ui" line="32"/>
        <source>Multiple controllers are connected. Which one do you want to use?</source>
        <translation>Hay varios mandos conectados. ¿Cúal quieres usar?</translation>
    </message>
    <message>
        <location filename="../src/ui/singleplayer-controller-select-dialog.cpp" line="19"/>
        <source>Unknown Controller (%1)</source>
        <translation>Mando desconocido (%1)</translation>
    </message>
</context>
<context>
    <name>UpdateDialog</name>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="14"/>
        <source>Update Available</source>
        <translation>Actualización disponible</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="26"/>
        <source>A new update is available for Parallel Launcher. Would you like to update now?</source>
        <translation>Hay una actualización disponible para Parallel Launcher. ¿Quieres instalarla?</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="62"/>
        <source>Changelog:</source>
        <translation>Lista de cambios:</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/update-dialog.ui" line="79"/>
        <source>Don&apos;t remind me again</source>
        <translation>No me lo vuelvas a recordar</translation>
    </message>
</context>
<context>
    <name>WindowsRetroArchUpdater</name>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="118"/>
        <source>Checking for RetroArch Updates</source>
        <translation>Buscando actualizaciones para RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="243"/>
        <source>Download Failed</source>
        <translation>Descarga fallida</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="244"/>
        <source>Failed to download RetroArch.</source>
        <translation>Fallo al instalar RetroArch.</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="251"/>
        <source>Installing RetroArch</source>
        <translation>Instalando RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="263"/>
        <source>Installation Error</source>
        <translation>Instalación fallida</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="264"/>
        <source>An error occurred attempting to uncompress the portable RetroArch bundle</source>
        <translation>Se ha producido un error al intentar descomprimir la versión portable de RetroArch</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="301"/>
        <source>Install Update?</source>
        <translation>¿Instalar actualización?</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/retroarch-updater.cpp" line="302"/>
        <source>An update for RetroArch is available. Would you like to install it now?</source>
        <translation>Hay una actualización disponible para RetroArch. ¿Quieres instalarla?</translation>
    </message>
</context>
<context>
    <name>WindowsUpdater</name>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="51"/>
        <source>Download Failed</source>
        <translation>Descarga fallida</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="52"/>
        <source>Failed to download the latest installer. Try again later.</source>
        <translation>No se ha podido descargar el instalador más reciente. Inténtalo de nuevo más tarde.</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="40"/>
        <source>Unexpected Error</source>
        <translation>Error inesperado</translation>
    </message>
    <message>
        <location filename="../src/windows-mac-updater/self-updater.cpp" line="41"/>
        <source>Failed to launch installer.</source>
        <translation>No se ha podido iniciar el instalador.</translation>
    </message>
</context>
</TS>
