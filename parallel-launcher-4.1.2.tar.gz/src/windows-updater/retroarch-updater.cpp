#include "src/windows-updater/retroarch-updater.hpp"

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProgressDialog>
#include <QMessageBox>
#include <functional>
#include <memory>
#include <thread>
#include "src/core/qthread.hpp"
#include "src/core/version.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/polyfill/base-directory.hpp"
#include "src/polyfill/process.hpp"
#include "src/ui/download-dialog.hpp"

#if QT_VERSION >= QT_VERSION_CHECK( 5, 15, 0 )
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::errorOccurred )
#else
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::error )
#endif

static void headAsync(
	QNetworkAccessManager *web,
	const string &url,
	const std::function<void(bool)> &callback
) {
	QNetworkReply *response = web->head( QNetworkRequest( QUrl( url.c_str() ) ) );

	QObject::connect( response, ON_NETWORK_ERROR, web, [=](QNetworkReply::NetworkError error) {
		(void)error;
		response->deleteLater();
		callback( false );
	}, Qt::QueuedConnection );

	QObject::connect( response, &QNetworkReply::finished, web, [=](){
		if( response->error() != QNetworkReply::NoError ) return;
		bool hasStatusCode = false;
		const int statusCode = response->attribute( QNetworkRequest::HttpStatusCodeAttribute ).toInt( &hasStatusCode );
		response->deleteLater();
		callback( hasStatusCode && statusCode == 200 );
	}, Qt::QueuedConnection );
}

enum VersionMarch {
	Patch = 0,
	Minor = 1,
	Major = 2
};

static inline string buildDownloadUrl( const Version &version ) {
#ifdef _WIN64
	return "https://buildbot.libretro.com/stable/"s + version.toString() + "/windows/x86_64/RetroArch.7z";
#else
	return "https://buildbot.libretro.com/stable/"s + version.toString() + "/windows/x86/RetroArch.7z";
#endif
}

static inline Version marchVersion(
	Version version,
	VersionMarch versionMarch
) {
	switch( versionMarch ) {
		case VersionMarch::Patch: version.patch++; break;
		case VersionMarch::Minor: version.minor++; version.patch = 0; break;
		case VersionMarch::Major: version.major++; version.minor = 0; version.patch = 0; break;
		default: break;
	}
	return version;
}

static const Version EARLIEST_VERSION = Version{ 1, 9, 0 };

static void getWindowsDownloadHelper(
	QNetworkAccessManager *web,
	Version lastFoundVersion,
	Version earliestVersion,
	VersionMarch versionMarch,
	std::shared_ptr<bool> cancelled,
	std::function<void(Version)> callback
) {
	if( *cancelled ) {
		callback( EARLIEST_VERSION );
		return;
	}

	const string url = buildDownloadUrl( earliestVersion ).c_str();
	headAsync(
		web,
		url,
		[=](bool found) {
			if( found ) {
				getWindowsDownloadHelper( web, earliestVersion, marchVersion( earliestVersion, VersionMarch::Patch ), VersionMarch::Patch, cancelled, callback );
			} else if( versionMarch == VersionMarch::Major ) {
				callback( lastFoundVersion );
			} else {
				const VersionMarch newVersionMarch = (VersionMarch)((int)versionMarch + 1);
				getWindowsDownloadHelper( web, lastFoundVersion, marchVersion( earliestVersion, newVersionMarch ), newVersionMarch, cancelled, callback );
			}
		}
	);
}

static inline Version getLatestWindowsVersion(
	const Version &earliestVersion
) {
	QProgressDialog dialog;
	dialog.setRange( 0, 0 );
	dialog.setLabelText( "Checking for RetroArch Updates" );

	std::shared_ptr<bool> cancelled( new bool( false ) );
	Version latestVersion = earliestVersion;

	QNetworkAccessManager *web = new QNetworkAccessManager();
	getWindowsDownloadHelper( web, earliestVersion, earliestVersion, VersionMarch::Patch, cancelled, [cancelled,&latestVersion,&dialog](Version foundVersion){
		if( *cancelled ) return;
		latestVersion = foundVersion;
		dialog.close();
	});

	dialog.exec();
	*cancelled = true;
	web->deleteLater();
	return latestVersion;
}

#ifdef _WIN64
#define RA_ROOT "RetroArch-Win64"
#else
#define RA_ROOT "RetroArch-Win32"
#endif

static void installWorker(
	QProgressDialog *dialog,
	std::shared_ptr<bool> cancelled,
	bool *result
) {
	const fs::path installDir = RetroArch::getExePath().parent_path();

	std::error_code err;
	fs::remove_all( installDir, err );
	fs::create_directories( installDir, err );

	AsyncProcess extraction(
		(BaseDir::program() / "7za.exe").u8string(),
		{
			"x", (BaseDir::temp() / "retroarch.7z").u8string(),
			"-t7z",
			"-aoa",
			"-y",
			"-o"s + installDir.u8string()
		}
	);
	const uint exitCode = extraction.join();

	if( exitCode == 0 ) {
		if( fs::isDirectorySafe( installDir / RA_ROOT ) ) {
			const fs::path tempDir = installDir.parent_path() / "retroarch-temp";
			fs::remove_all( tempDir, err );
			fs::rename( installDir / RA_ROOT, tempDir, err );
			fs::remove_all( installDir, err );
			fs::rename( tempDir, installDir, err );
		}
	}

	QtThread::safeAsync( [=](){
		if( *cancelled ) return;
		*result = (exitCode == 0 && fs::existsSafe( RetroArch::getExePath() ));
		dialog->close();
	});
}

static inline bool downloadAndInstall( const Version &version ) {
	const fs::path tempBundlePath = BaseDir::temp() / "retroarch.7z";

	std::error_code err;
	fs::remove( tempBundlePath, err );

	if( !DownloadDialog::download(
		"Downloading RetroArch",
		buildDownloadUrl( version ),
		tempBundlePath
	)) {
		QMessageBox::critical( nullptr, "Download Failed", "Failed to download RetroArch." );
		return false;
	}

	QProgressDialog dialog;
	dialog.setRange( 0, 0 );
	dialog.setLabelText( "Installing RetroArch" );

	bool success = false;
	std::shared_ptr<bool> cancelled( new bool( false ) );

	std::thread( installWorker, &dialog, cancelled, &success ).detach();
	dialog.exec();
	*cancelled = true;

	if( !success ) {
		QMessageBox::critical( nullptr, "Installation Error", "An error occurred attempting to uncompress the portable RetroArch bundle" );
	}

	return success;
}

bool WindowsRetroArchUpdater::install() {
	const Version latestVersion = getLatestWindowsVersion( EARLIEST_VERSION );
	if( latestVersion < EARLIEST_VERSION ) {
		return false;
	}

	if( downloadAndInstall( latestVersion ) ) {
		InstalledVersionsInfo versions = FileController::loadInstalledVersions();
		versions.retroArchVersion.version = latestVersion;
		FileController::saveInstalledVersions( versions );
		return true;
	}

	return false;
}

void WindowsRetroArchUpdater::update() {
	InstalledVersionsInfo versions = FileController::loadInstalledVersions();
	Version &version = versions.retroArchVersion.version;
	if( version < EARLIEST_VERSION ) {
		version = EARLIEST_VERSION;
	}

	Version latestVersion = getLatestWindowsVersion( version );
	if( latestVersion <= version ) {
		return;
	}

	if( QMessageBox::question( nullptr, "Install Update?", "An update for RetroArch is available. Would you like to install it now?" ) != QMessageBox::Yes ) {
		return;
	}

	version = latestVersion;
	if( downloadAndInstall( latestVersion ) ) {
		FileController::saveInstalledVersions( versions );
	}
}
