#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"

#include "src/core/logging.hpp"

void RhdcApi::fetchLayoutsAysnc(
	const std::function<void(LayoutManager&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://parallel-launcher.ca/layouts.json" );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		LayoutManager layoutManager;
		try {
			layoutManager = JsonSerializer::parse<LayoutManager>( json );
		} catch( ... ) {
			logError( "JSON deserialization error reading star layouts" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		onSuccess( layoutManager );
	}, onFailure );
}
