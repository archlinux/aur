#include "src/rhdc/ui/rhdc-rating-dialog.hpp"
#include "ui_rhdc-rating-dialog.h"

#include <QPushButton>
#include "src/core/numeric-string.hpp"
#include "src/ui/icons.hpp"

static const char *s_qualityLabels[11] = {
	/*  0 */ "I can't decide or have no opinion",
	/*  1 */ "Zero Effort",
	/*  2 */ "Poor Quality",
	/*  3 */ "A Little Rough",
	/*  4 */ "Unremarkable",
	/*  5 */ "Decent",
	/*  6 */ "Pretty Good",
	/*  7 */ "Very Good",
	/*  8 */ "Excellent",
	/*  9 */ "Exceptional",
	/* 10 */ "Legendary"
};

static const char *s_difficultyLabels[11] = {
	/*  0 */ "I can't decide or have no opinion",
	/*  1 */ "No Challenge",
	/*  2 */ "Very Easy",
	/*  3 */ "Casual",
	/*  4 */ "Classic SM64",
	/*  5 */ "Moderate",
	/*  6 */ "Challenging",
	/*  7 */ "Difficult",
	/*  8 */ "Very Difficult",
	/*  9 */ "Extremely Difficult",
	/* 10 */ "Borderline Kaizo"
};

static const char *s_kaizoLabels[11] = {
	/*  0 */ "I can't decide or have no opinion",
	/*  1 */ "Beginner/Introductory Kaizo",
	/*  2 */ "Easy Kaizo",
	/*  3 */ "Standard Kaizo",
	/*  4 */ "Moderate Kaizo",
	/*  5 */ "Challenging Kaizo",
	/*  6 */ "Difficult Kaizo",
	/*  7 */ "Very Difficult Kaizo",
	/*  8 */ "Extremely Difficult Kaizo",
	/*  9 */ "Hardest humanly possible Kaizo",
	/* 10 */ "TAS/Unbeatable"
};

RhdcRatingDialog::RhdcRatingDialog( QWidget *parent ) :
	QDialog( parent ),
	m_ui( new Ui::RhdcRatingDialog ),
	m_kaizo( false )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );
	setModal( true );
	m_ui->buttonTray->button( QDialogButtonBox::Ok )->setText( "Submit" );
}

RhdcRatingDialog::~RhdcRatingDialog() {
	delete m_ui;
}

void RhdcRatingDialog::setRatings( ubyte quality, ubyte difficulty, bool isKaizo ) {
	m_kaizo = isKaizo;
	m_ui->qualitySlider->setValue( (int)quality );
	m_ui->difficultySlider->setValue( (int)difficulty );
	qualityChanged( (int)quality );
	difficultyChanged( (int)difficulty );
}

ubyte RhdcRatingDialog::getQuality() const {
	return (ubyte)m_ui->qualitySlider->value();
}

ubyte RhdcRatingDialog::getDifficulty() const {
	return (ubyte)m_ui->difficultySlider->value();
}

static QString makeScoreLabel( int score ) {
	if( score == 0 ) return QString( "Not Rated" );
	return QString( (Number::toString( score ) + "/10").c_str() );
}

void RhdcRatingDialog::qualityChanged( int rating ) {
	m_ui->qualityScoreLabel->setText( makeScoreLabel( rating ) );
	m_ui->qualityInfoLabel->setText( s_qualityLabels[rating] );
}

void RhdcRatingDialog::difficultyChanged( int rating ) {
	m_ui->difficultyScoreLabel->setText( makeScoreLabel( rating ) );
	m_ui->difficultyInfoLabel->setText( m_kaizo ? s_kaizoLabels[rating] : s_difficultyLabels[rating] );
}
