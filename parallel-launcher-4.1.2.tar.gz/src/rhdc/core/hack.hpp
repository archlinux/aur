#ifndef SRC_RHDC_CORE_HACK_HPP_
#define SRC_RHDC_CORE_HACK_HPP_

#include "src/types.hpp"

struct RhdcHackInfo {
	string hackId;
	string name;
	string slug;
	string description;
	int starCount;
	int downloads;
	double avgRating;
	double avgDifficulty;
	string category;
};

struct BasicRhdcHackInfo {
	string hackId;
	string name;
	int starCount;
	bool isKaizo;
};

struct RhdcHackProgress {
	ubyte rating;
	ubyte difficulty;
	ushort stars;
	bool completed;

	inline bool operator==( const RhdcHackProgress &other ) const noexcept {
		return (
			rating == other.rating &&
			difficulty == other.difficulty &&
			stars == other.stars &&
			completed == other.completed
		);
	}

	inline bool operator!=( const RhdcHackProgress &other ) const noexcept {
		return !(*this == other);
	}
};

struct RhdcHack {
	RhdcHackInfo info;
	RhdcHackProgress progress;
};

struct BasicRhdcHack {
	BasicRhdcHackInfo info;
	RhdcHackProgress progress;
};

struct StarpowerExt {
	RhdcHackProgress progress;
	int64 playTime;
	int starCount;
};

#endif /* SRC_RHDC_CORE_HACK_HPP_ */
