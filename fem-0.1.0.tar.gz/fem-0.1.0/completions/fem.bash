_fem() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}; do
        case "${i}" in
            fem) cmd="fem" ;;
            pull) cmd+="__pull" ;;
            push) cmd+="__push" ;;
            list) cmd+="__list" ;;
            show) cmd+="__show" ;;
            compose) cmd+="__compose" ;;
            cat) cmd+="__cat" ;;
            find) cmd+="__find" ;;
            tag) cmd+="__tag" ;;
        esac
    done

    case "${cmd}" in
        fem)
            opts="-c --config pull push list show cat compose find tag help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__pull)
            opts="-s -p -u -w -m -c --server --port --username --password --password-command --mailbox --ssl --all --pre-hook --post-hook --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__push)
            opts="-s -p -u -w -c --server --port --username --password --password-command --ssl --starttls --drafts-path --all-drafts --last-draft --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__list)
            opts="-d -c --maildir-path --limit --offset --format --table-fields --flag-new --flag-attachment --flag-encrypted --flag-signed --flag-reply --flag-tagged --date-format --order-by --no-thread --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__show)
            opts="-d -c --maildir-path --order-by --no-thread --flag-new --flag-attachment --flag-encrypted --flag-signed --flag-reply --flag-tagged --date-format --headers-show --headers-hide --multipart-handle --multipart-preference --no-multipart-preference --raw --force-color --no-color --color-header-key --color-header-value --color-part-separator --color-handler-info --color-handler-error --wrap --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__cat)
            opts="--hide-signature --collapse-citation --color-regex --no-color --force-color -c --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__compose)
            opts="-d -t -f -s -c --maildir-path --to --from --subject --drafts-path --no-include-headers --recover-last-draft --pre-compose-hook --post-compose-hook --template --message --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__find)
            opts="-d -F -H -b -c --maildir-path --folder --header --body --since --until --limit --offset --format --table-fields --flag-new --flag-attachment --flag-encrypted --flag-signed --flag-reply --flag-tagged --date-format --order-by --no-thread --label --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        fem__tag)
            opts="-d -c --label --maildir-path --order-by --no-thread --config help"
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
        *)
            COMPREPLY=($(compgen -W "${opts}" -- ${cur}))
            return 0
            ;;
    esac
}

complete -F _fem fem
