#compdef fem

_fem() {
    local -a commands

    _arguments -C \
        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files' \
        '(-): :->command' \
        '(-)*:: :->option-or-argument'

    case $state in
        command)
            commands=(
                'pull:Pull emails from an IMAP4 server'
                'push:Send an email message over SMTP'
                'list:List emails stored in the local Maildir'
                'show:Show a single email by its ID'
                'cat:Read from stdin and write to stdout'
                'compose:Create a new email draft'
                'find:Search local Maildir emails by header, body, or date'
                'tag:Tag an email (by its ID) with a label'
                'help:Show help information'
            )
            _describe 'command' commands
            ;;
        option-or-argument)
            case $words[1] in
                pull)
                    _arguments \
                        '(-s --server)'{-s,--server}'[IMAP server hostname]:hostname:' \
                        '(-p --port)'{-p,--port}'[IMAP server port]:port:' \
                        '(-u --username)'{-u,--username}'[Username for IMAP authentication]:username:' \
                        '(-w --password)'{-w,--password}'[Password for IMAP authentication]:password:' \
                        '--password-command[Command to get the IMAP password]:command:' \
                        '(-m --mailbox)'{-m,--mailbox}'[Mailbox to fetch]:mailbox:' \
                        '--ssl[Use SSL/TLS]' \
                        '--all[Fetch all emails, not just unseen]' \
                        '--pre-hook[Binary/script to run before each stored message (stdin/stdout transform)]:file:_files' \
                        '--post-hook[Binary/script to run after each stored message]:file:_files' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                push)
                    _arguments \
                        '(-s --server)'{-s,--server}'[SMTP server hostname]:hostname:' \
                        '(-p --port)'{-p,--port}'[SMTP server port]:port:' \
                        '(-u --username)'{-u,--username}'[Username for SMTP authentication]:username:' \
                        '(-w --password)'{-w,--password}'[Password for SMTP authentication]:password:' \
                        '--password-command[Command to get the SMTP password]:command:' \
                        '--ssl[Use SSL/TLS]' \
                        '--starttls[Use STARTTLS to upgrade the connection]' \
                        '--drafts-path[Directory containing draft emails]:dir:_files -/' \
                        '--all-drafts[Send every draft in the drafts directory]' \
                        '--last-draft[Send only the most recently modified draft]' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                list)
                    _arguments \
                        '(-d --maildir-path)'{-d,--maildir-path}'[Path to Maildir directory]:maildir:_files -/' \
                        '--limit[Maximum number of emails to display]:limit:' \
                        '--offset[Number of emails to skip]:offset:' \
                        '--format[Output format (table/json/table-raw/tsv)]:format:' \
                        '--table-fields[Table fields (comma-separated)]:fields:' \
                        '--flag-new[Character(s) for new/unread flag]' \
                        '--flag-attachment[Character(s) for attachment flag]' \
                        '--flag-encrypted[Character(s) for encrypted flag]' \
                        '--flag-signed[Character(s) for PGP/MIME signature flag]' \
                        '--flag-tagged[Character(s) for tag flag]' \
                        '--flag-reply[Character(s) for reply flag]' \
                        '--date-format[Date/time format (chrono strftime)]:format:' \
                        '--order-by[Sort order (field:direction)]:order:' \
                        '--no-thread[Disable reply threading (strict global order)]' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                show)
                    _arguments \
                        '(-d --maildir-path)'{-d,--maildir-path}'[Path to Maildir directory]:maildir:_files -/' \
                        '--order-by[Sort order (field:direction)]:order:' \
                        '--no-thread[Disable reply threading (strict global order)]' \
                        '--flag-new[Character(s) for new/unread flag]' \
                        '--flag-attachment[Character(s) for attachment flag]' \
                        '--flag-encrypted[Character(s) for encrypted flag]' \
                        '--flag-signed[Character(s) for PGP/MIME signature flag]' \
                        '--flag-tagged[Character(s) for tag flag]' \
                        '--flag-reply[Character(s) for reply flag]' \
                        '--date-format[Date/time format (chrono strftime)]:format:' \
                        '--headers-show[Headers to show (comma-separated)]:headers:' \
                        '--headers-hide[Headers to hide (comma-separated)]:headers:' \
                        '--multipart-handle[MIME type handler (type=command)]:handler:' \
                        '--raw[Show raw email without any processing]' \
                        '--no-color[Disable colored output]' \
                        '--force-color[Force colored output even when piped]' \
                        '--color-header-key[Color for header keys (bg,fg,modifier)]:spec:' \
                        '--color-header-value[Color for header values (bg,fg,modifier)]:spec:' \
                        '--color-part-separator[Color for part separators (bg,fg,modifier)]:spec:' \
                        '--color-handler-info[Color for handler info messages (bg,fg,modifier)]:spec:' \
                        '--color-handler-error[Color for handler stderr messages on success (bg,fg,modifier)]:spec:' \
                        '--wrap[Wrap output width (0 = no wrap, default: 100)]:width:' \
                        '--multipart-preference[Type preference (preferred,fallback)]:pref:' \
                        '--no-multipart-preference[Disable type preference, show all parts]' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                cat)
                    _arguments \
                        '--hide-signature[Remove email signature (from --  delimiter)]' \
                        '--collapse-citation[Collapse consecutive citations (> ...) into one marker]' \
                        '--color-regex[Color regex (spec pattern)]:spec: :pattern:' \
                        '--no-color[Disable colored output]' \
                        '--force-color[Force colored output even when piped]' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                find)
                    _arguments \
                        '--maildir-path[Path to Maildir directory]:maildir:_files -/' \
                        '(-F --folder)'{-F,--folder}'[Sub-folder to search]:folder:' \
                        '(-H --header)'{-H,--header}'[Match a header value (NAME=REGEX)]:criterion:' \
                        '(-b --body)'{-b,--body}'[Match the decoded text body]:regex:' \
                        '--since[Only emails on or after this date]:date:' \
                        '--until[Only emails on or before this date]:date:' \
                        '--limit[Maximum number of emails to display]:limit:' \
                        '--offset[Number of emails to skip]:offset:' \
                        '--format[Output format (table/json/table-raw/tsv)]:format:' \
                        '--table-fields[Table fields (comma-separated)]:fields:' \
                        '--flag-new[Character(s) for new/unread flag]' \
                        '--flag-attachment[Character(s) for attachment flag]' \
                        '--flag-encrypted[Character(s) for encrypted flag]' \
                        '--flag-signed[Character(s) for PGP/MIME signature flag]' \
                        '--flag-tagged[Character(s) for tag flag]' \
                        '--flag-reply[Character(s) for reply flag]' \
                        '--date-format[Date/time format (chrono strftime)]:format:' \
                        '--order-by[Sort order (field:direction)]:order:' \
                        '--no-thread[Disable reply threading (strict global order)]' \
                        '--label[Only match emails carrying this label]:label:' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                compose)
                    _arguments \
                        '(-d --maildir-path)'{-d,--maildir-path}'[Maildir to scan for autocompletion contacts]:dir:_files -/' \
                        '(-t --to)'{-t,--to}'[Recipient email address]:to:' \
                        '(-f --from)'{-f,--from}'[Sender email address]:from:' \
                        '(-s --subject)'{-s,--subject}'[Email subject]:subject:' \
                        '--drafts-path[Directory for draft emails]:dir:_files -/' \
                        '--no-include-headers[Omit headers from temp editor file]' \
                        '--recover-last-draft[Recover last draft and continue editing]' \
                        '--pre-compose-hook[Binary to run before composing]:file:_files' \
                        '--post-compose-hook[Binary to run after composing]:file:_files' \
                        '--template[Path to EML template file]:file:_files' \
                        '--message[Full message content, no editor]:message:' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
                tag)
                    _arguments \
                        '(-d --maildir-path)'{-d,--maildir-path}'[Path to Maildir directory]:maildir:_files -/' \
                        '--label[Label to attach to the email]:label:' \
                        '--order-by[Sort order (field:direction)]:order:' \
                        '--no-thread[Disable reply threading (strict global order)]' \
                        '(-c --config)'{-c,--config}'[Path to TOML config file]:config:_files'
                    ;;
            esac
            ;;
    esac
}

_fem
