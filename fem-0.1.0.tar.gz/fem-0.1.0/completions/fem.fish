complete -c fem -f

# Subcommands
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a compose -d "Create a new email draft"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a pull -d "Pull emails from an IMAP4 server"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a push -d "Send an email message over SMTP"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a list -d "List emails stored in the local Maildir"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a show -d "Show a single email by its ID"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a cat -d "Read from stdin and write to stdout"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a find -d "Search local Maildir emails by header, body, or date"
complete -c fem -n "not __fish_seen_subcommand_from pull push list show cat compose find tag help" -a tag -d "Tag an email (by its ID) with a label"

# Global options
complete -c fem -s c -l config -d "Path to TOML config file" -r -F

# compose subcommand
complete -c fem -n "__fish_seen_subcommand_from compose" -s d -l maildir-path -d "Maildir to scan for autocompletion contacts" -r -F
complete -c fem -n "__fish_seen_subcommand_from compose" -s t -l to -d "Recipient email address" -r
complete -c fem -n "__fish_seen_subcommand_from compose" -s f -l from -d "Sender email address" -r
complete -c fem -n "__fish_seen_subcommand_from compose" -s s -l subject -d "Email subject" -r
complete -c fem -n "__fish_seen_subcommand_from compose" -l drafts-path -d "Directory for draft emails" -r -F
complete -c fem -n "__fish_seen_subcommand_from compose" -l no-include-headers -d "Omit headers from temp editor file"
complete -c fem -n "__fish_seen_subcommand_from compose" -l recover-last-draft -d "Recover last draft and continue editing"
complete -c fem -n "__fish_seen_subcommand_from compose" -l pre-compose-hook -d "Binary to run before composing" -r -F
complete -c fem -n "__fish_seen_subcommand_from compose" -l post-compose-hook -d "Binary to run after composing" -r -F
complete -c fem -n "__fish_seen_subcommand_from compose" -l template -d "Path to EML template file" -r -F
complete -c fem -n "__fish_seen_subcommand_from compose" -l message -d "Full message content, no editor" -r
complete -c fem -n "__fish_seen_subcommand_from compose" -s c -l config -d "Path to TOML config file" -r -F
# pull subcommand
complete -c fem -n "__fish_seen_subcommand_from pull" -s s -l server -d "IMAP server hostname" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -s p -l port -d "IMAP server port" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -s u -l username -d "Username for IMAP authentication" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -s w -l password -d "Password for IMAP authentication" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -l password-command -d "Command to get the IMAP password" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -s m -l mailbox -d "Mailbox to fetch" -r
complete -c fem -n "__fish_seen_subcommand_from pull" -l ssl -d "Use SSL/TLS"
complete -c fem -n "__fish_seen_subcommand_from pull" -l all -d "Fetch all emails, not just unseen"
complete -c fem -n "__fish_seen_subcommand_from pull" -l pre-hook -d "Binary/script to run before each stored message (stdin/stdout transform)" -r -F
complete -c fem -n "__fish_seen_subcommand_from pull" -l post-hook -d "Binary/script to run after each stored message" -r -F
complete -c fem -n "__fish_seen_subcommand_from pull" -s c -l config -d "Path to TOML config file" -r -F
# push subcommand
complete -c fem -n "__fish_seen_subcommand_from push" -s s -l server -d "SMTP server hostname" -r
complete -c fem -n "__fish_seen_subcommand_from push" -s p -l port -d "SMTP server port" -r
complete -c fem -n "__fish_seen_subcommand_from push" -s u -l username -d "Username for SMTP authentication" -r
complete -c fem -n "__fish_seen_subcommand_from push" -s w -l password -d "Password for SMTP authentication" -r
complete -c fem -n "__fish_seen_subcommand_from push" -l password-command -d "Command to get the SMTP password" -r
complete -c fem -n "__fish_seen_subcommand_from push" -l ssl -d "Use SSL/TLS"
complete -c fem -n "__fish_seen_subcommand_from push" -l starttls -d "Use STARTTLS to upgrade the connection"
complete -c fem -n "__fish_seen_subcommand_from push" -l drafts-path -d "Directory containing draft emails" -r -F
complete -c fem -n "__fish_seen_subcommand_from push" -l all-drafts -d "Send every draft in the drafts directory"
complete -c fem -n "__fish_seen_subcommand_from push" -l last-draft -d "Send only the most recently modified draft"
complete -c fem -n "__fish_seen_subcommand_from push" -s c -l config -d "Path to TOML config file" -r -F

# list subcommand
complete -c fem -n "__fish_seen_subcommand_from list" -s d -l maildir-path -d "Path to Maildir directory" -r -F
complete -c fem -n "__fish_seen_subcommand_from list" -l limit -d "Maximum number of emails to display" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l offset -d "Number of emails to skip" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l format -d "Output format (table/json/table-raw/tsv)" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l table-fields -d "Table fields (comma-separated)" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-new -d "Character(s) for new/unread flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-attachment -d "Character(s) for attachment flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-encrypted -d "Character(s) for encrypted flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-signed -d "Character(s) for PGP/MIME signature flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-tagged -d "Character(s) for tag flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l flag-reply -d "Character(s) for reply flag" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l date-format -d "Date/time format (chrono strftime syntax)" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l order-by -d "Sort order (field:direction)" -r
complete -c fem -n "__fish_seen_subcommand_from list" -l no-thread -d "Disable reply threading (strict global order)"
complete -c fem -n "__fish_seen_subcommand_from list" -s c -l config -d "Path to TOML config file" -r -F

# show subcommand
complete -c fem -n "__fish_seen_subcommand_from show" -s d -l maildir-path -d "Path to Maildir directory" -r -F
complete -c fem -n "__fish_seen_subcommand_from show" -l order-by -d "Sort order (field:direction)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l no-thread -d "Disable reply threading"
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-new -d "Character(s) for new/unread flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-attachment -d "Character(s) for attachment flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-encrypted -d "Character(s) for encrypted flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-signed -d "Character(s) for PGP/MIME signature flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-tagged -d "Character(s) for tag flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l flag-reply -d "Character(s) for reply flag" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l date-format -d "Date/time format (chrono strftime syntax)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l headers-show -d "Headers to show (comma-separated)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l headers-hide -d "Headers to hide (comma-separated)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l multipart-handle -d "MIME type handler (type=command)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l raw -d "Show raw email without any processing"
complete -c fem -n "__fish_seen_subcommand_from show" -l no-color -d "Disable colored output"
complete -c fem -n "__fish_seen_subcommand_from show" -l force-color -d "Force colored output even when piped"
complete -c fem -n "__fish_seen_subcommand_from show" -l color-header-key -d "Color for header keys (bg,fg,modifier)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l color-header-value -d "Color for header values (bg,fg,modifier)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l color-part-separator -d "Color for part separators (bg,fg,modifier)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l color-handler-info -d "Color for handler info messages (bg,fg,modifier)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l color-handler-error -d "Color for handler stderr messages on success (bg,fg,modifier)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l multipart-preference -d "Type preference (preferred,fallback)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -l no-multipart-preference -d "Disable type preference, show all parts"
complete -c fem -n "__fish_seen_subcommand_from show" -l wrap -d "Wrap output width (0 = no wrap)" -r
complete -c fem -n "__fish_seen_subcommand_from show" -s c -l config -d "Path to TOML config file" -r -F

# cat subcommand
complete -c fem -n "__fish_seen_subcommand_from cat" -l hide-signature -d "Remove email signature (from --  delimiter)"
complete -c fem -n "__fish_seen_subcommand_from cat" -l collapse-citation -d "Collapse consecutive citations (> ...) into one marker"
complete -c fem -n "__fish_seen_subcommand_from cat" -l color-regex -d "Color regex (spec pattern)" -r
complete -c fem -n "__fish_seen_subcommand_from cat" -l no-color -d "Disable colored output"
complete -c fem -n "__fish_seen_subcommand_from cat" -l force-color -d "Force colored output even when piped"
complete -c fem -n "__fish_seen_subcommand_from cat" -s c -l config -d "Path to TOML config file" -r -F

# find subcommand
complete -c fem -n "__fish_seen_subcommand_from find" -s d -l maildir-path -d "Path to Maildir directory" -r -F
complete -c fem -n "__fish_seen_subcommand_from find" -s F -l folder -d "Sub-folder to search" -r
complete -c fem -n "__fish_seen_subcommand_from find" -s H -l header -d "Match a header value (NAME=REGEX)" -r
complete -c fem -n "__fish_seen_subcommand_from find" -s b -l body -d "Match the decoded text body" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l since -d "Only emails on or after this date" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l until -d "Only emails on or before this date" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l limit -d "Maximum number of emails to display" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l offset -d "Number of emails to skip" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l format -d "Output format (table/json/table-raw/tsv)" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l table-fields -d "Table fields (comma-separated)" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-new -d "Character(s) for new/unread flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-attachment -d "Character(s) for attachment flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-encrypted -d "Character(s) for encrypted flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-signed -d "Character(s) for PGP/MIME signature flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-tagged -d "Character(s) for tag flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l flag-reply -d "Character(s) for reply flag" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l date-format -d "Date/time format (chrono strftime syntax)" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l order-by -d "Sort order (field:direction)" -r
complete -c fem -n "__fish_seen_subcommand_from find" -l no-thread -d "Disable reply threading (strict global order)"
complete -c fem -n "__fish_seen_subcommand_from find" -l label -d "Only match emails carrying this label" -r
complete -c fem -n "__fish_seen_subcommand_from find" -s c -l config -d "Path to TOML config file" -r -F

# tag subcommand
complete -c fem -n "__fish_seen_subcommand_from tag" -s d -l maildir-path -d "Path to Maildir directory" -r -F
complete -c fem -n "__fish_seen_subcommand_from tag" -l label -d "Label to attach to the email" -r
complete -c fem -n "__fish_seen_subcommand_from tag" -l order-by -d "Sort order (field:direction)" -r
complete -c fem -n "__fish_seen_subcommand_from tag" -l no-thread -d "Disable reply threading (strict global order)"
complete -c fem -n "__fish_seen_subcommand_from tag" -s c -l config -d "Path to TOML config file" -r -F
