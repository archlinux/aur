//! Print a single email by its ID, with optional MIME processing.
//!
//! Looks up the email by the number shown in `fem list`, applies the configured
//! header filtering (`--headers-show`/`--headers-hide`), and renders the body.
//! MIME multipart parts can be piped through external handlers
//! (`--multipart-handle TYPE=COMMAND`), preferred over other types
//! (`--multipart-preference`), or shown raw (`--raw`). Long lines are wrapped
//! to `--wrap` columns (default 100). Colored output can be forced or disabled
//! and the ANSI colors for header keys, values, part separators, and handler
//! status messages are configurable.

use crate::config::ShowConfig;
use crate::list::{self, Field, OrderBy};
use anyhow::Context;
use os_pipe::pipe;
use regex::Regex;
use std::collections::{HashMap, HashSet};
use std::io::{IsTerminal, Read};
use std::os::unix::io::AsRawFd;
use std::os::unix::process::CommandExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use unicode_width::UnicodeWidthStr;

extern "C" {
    fn dup2(oldfd: i32, newfd: i32) -> i32;
    fn close(fd: i32) -> i32;
}

const RST: &str = "\x1b[0m";

static NO_COLOR_FLAG: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

fn use_color() -> bool {
    !NO_COLOR_FLAG.load(std::sync::atomic::Ordering::Relaxed)
}

fn parse_color_spec(s: &str) -> (Option<u8>, Option<u8>, String) {
    let parts: Vec<&str> = s.splitn(3, ',').collect();
    let bg = parts.first().and_then(|p| p.trim().parse::<u8>().ok());
    let fg = parts.get(1).and_then(|p| p.trim().parse::<u8>().ok());
    let modifier = parts.get(2).unwrap_or(&"").trim().to_lowercase();
    (bg, fg, modifier)
}

fn make_ansi(bg: Option<u8>, fg: Option<u8>, modifier: &str) -> String {
    let mut code = String::new();
    if let Some(b) = bg {
        code.push_str(&format!("\x1b[48;5;{}m", b));
    }
    if let Some(f) = fg {
        code.push_str(&format!("\x1b[38;5;{}m", f));
    }
    match modifier {
        "bold" => code.push_str("\x1b[1m"),
        "blink" => code.push_str("\x1b[5m"),
        "underline" => code.push_str("\x1b[4m"),
        "reverse" => code.push_str("\x1b[7m"),
        _ => {}
    }
    code
}

fn make_err_ansi(sep_spec: &str) -> (String, String) {
    let (_, fg, modifier) = parse_color_spec(sep_spec);
    let sep_ansi = make_ansi(Some(196), fg, &modifier);
    let err_ansi = if fg.is_some() || !modifier.is_empty() {
        let mut c = String::new();
        if let Some(f) = fg {
            c.push_str(&format!("\x1b[38;5;{}m", f));
        }
        match modifier.as_str() {
            "bold" => c.push_str("\x1b[1m"),
            "blink" => c.push_str("\x1b[5m"),
            "underline" => c.push_str("\x1b[4m"),
            "reverse" => c.push_str("\x1b[7m"),
            _ => {}
        }
        c
    } else {
        "\x1b[1m".to_string()
    };
    (sep_ansi, err_ansi)
}

static CUSTOM_HDR_KEY: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static CUSTOM_HDR_VAL: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static CUSTOM_SEP_CLR: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static CUSTOM_ERR_CLR: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static CUSTOM_INFO_CLR: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static CUSTOM_ERR_MSG_CLR: std::sync::OnceLock<String> = std::sync::OnceLock::new();

fn hdr_key_clr() -> &'static str {
    CUSTOM_HDR_KEY.get().map(|s| s.as_str()).unwrap_or("\x1b[1;38;5;27m")
}
fn hdr_val_clr() -> &'static str {
    CUSTOM_HDR_VAL.get().map(|s| s.as_str()).unwrap_or("\x1b[1;38;5;255m")
}
fn sep_clr() -> &'static str {
    CUSTOM_SEP_CLR.get().map(|s| s.as_str()).unwrap_or("\x1b[48;5;226;38;5;16m")
}
fn err_clr() -> &'static str {
    CUSTOM_ERR_CLR.get().map(|s| s.as_str()).unwrap_or("\x1b[48;5;196;1;38;5;226m")
}
fn info_clr() -> &'static str {
    CUSTOM_INFO_CLR.get().map(|s| s.as_str()).unwrap_or("\x1b[38;5;2m")
}
fn err_msg_clr() -> &'static str {
    CUSTOM_ERR_MSG_CLR.get().map(|s| s.as_str()).unwrap_or("\x1b[38;5;9m")
}

const DEFAULT_HEADERS_SHOW: &[&str] = &[
    "From",
    "To",
    "Subject",
    "Date",
    "List-Unsubscribe",
];

const DEFAULT_MULTIPART_PREFERENCE: &str = "text/plain,text/html";

fn default_multipart_handlers() -> HashMap<String, String> {
    let mut m = HashMap::new();
    m.insert("text/plain".to_string(), "fem cat".to_string());
    m.insert("text/html".to_string(), "lynx -dump -stdin -assume_charset=utf-8".to_string());
    m
}

/// Command-line arguments for the show subcommand.
#[derive(Default)]
pub struct ShowArgs {
    pub id: usize,
    pub maildir_path: Option<String>,
    pub order_by: Option<String>,
    pub no_thread: bool,
    pub flag_new: Option<String>,
    pub flag_attachment: Option<String>,
    pub flag_encrypted: Option<String>,
    pub flag_signed: Option<String>,
    pub flag_reply: Option<String>,
    pub flag_tagged: Option<String>,
    pub date_format: Option<String>,
    pub headers_show: Option<String>,
    pub headers_hide: Option<String>,
    pub multipart_handle: Vec<String>,
    pub raw: bool,
    pub multipart_preference: Vec<String>,
    pub no_multipart_preference: bool,
    pub no_color: bool,
    pub force_color: bool,
    pub color_header_key: Option<String>,
    pub color_header_value: Option<String>,
    pub color_part_separator: Option<String>,
    pub color_handler_info: Option<String>,
    pub color_handler_error: Option<String>,
    pub wrap: Option<usize>,
}

fn parse_multipart_handlers(pairs: &[String]) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for s in pairs {
        if let Some(eq_idx) = s.find('=') {
            let key = s[..eq_idx].trim().to_lowercase();
            let val = s[eq_idx + 1..].trim().to_string();
            if !key.is_empty() && !val.is_empty() {
                map.entry(key).or_insert(val);
            }
        }
    }
    map
}

impl From<ShowArgs> for ShowConfig {
    fn from(args: ShowArgs) -> Self {
        let cli_handlers = if args.multipart_handle.is_empty() {
            None
        } else {
            Some(parse_multipart_handlers(&args.multipart_handle))
        };
        ShowConfig {
            maildir_path: args.maildir_path,
            order_by: args.order_by,
            no_thread: if args.no_thread { Some(true) } else { None },
            flag_new: args.flag_new,
            flag_attachment: args.flag_attachment,
            flag_encrypted: args.flag_encrypted,
            flag_signed: args.flag_signed,
            flag_reply: args.flag_reply,
            flag_tagged: args.flag_tagged,
            date_format: args.date_format,
            headers_show: args.headers_show,
            headers_hide: args.headers_hide,
            multipart_handle: cli_handlers,
            raw: if args.raw { Some(true) } else { None },
            multipart_preference: if args.multipart_preference.is_empty() {
                None
            } else {
                Some(args.multipart_preference)
            },
            no_multipart_preference: if args.no_multipart_preference { Some(true) } else { None },
            no_color: if args.no_color { Some(true) } else { None },
            force_color: if args.force_color { Some(true) } else { None },
            color_header_key: args.color_header_key,
            color_header_value: args.color_header_value,
            color_part_separator: args.color_part_separator,
            color_handler_info: args.color_handler_info,
            color_handler_error: args.color_handler_error,
            wrap: args.wrap,
        }
    }
}

fn merge_config(config: ShowConfig, args: ShowArgs) -> ShowConfig {
    let args_cfg: ShowConfig = args.into();
    ShowConfig {
        maildir_path: args_cfg.maildir_path.or(config.maildir_path),
        order_by: args_cfg.order_by.or(config.order_by),
        no_thread: args_cfg.no_thread.or(config.no_thread),
        flag_new: args_cfg.flag_new.or(config.flag_new),
        flag_attachment: args_cfg.flag_attachment.or(config.flag_attachment),
        flag_encrypted: args_cfg.flag_encrypted.or(config.flag_encrypted),
        flag_signed: args_cfg.flag_signed.or(config.flag_signed),
        flag_reply: args_cfg.flag_reply.or(config.flag_reply),
        flag_tagged: args_cfg.flag_tagged.or(config.flag_tagged),
        date_format: args_cfg.date_format.or(config.date_format),
        headers_show: args_cfg.headers_show.or(config.headers_show),
        headers_hide: args_cfg.headers_hide.or(config.headers_hide),
        multipart_handle: args_cfg.multipart_handle.or(config.multipart_handle),
        raw: args_cfg.raw.or(config.raw),
        multipart_preference: args_cfg.multipart_preference.or(config.multipart_preference),
        no_multipart_preference: args_cfg.no_multipart_preference.or(config.no_multipart_preference),
        no_color: args_cfg.no_color.or(config.no_color),
        force_color: args_cfg.force_color.or(config.force_color),
        color_header_key: args_cfg.color_header_key.or(config.color_header_key),
        color_header_value: args_cfg.color_header_value.or(config.color_header_value),
        color_part_separator: args_cfg.color_part_separator.or(config.color_part_separator),
        color_handler_info: args_cfg.color_handler_info.or(config.color_handler_info),
        color_handler_error: args_cfg.color_handler_error.or(config.color_handler_error),
        wrap: args_cfg.wrap.or(config.wrap),
    }
}

fn parse_header_list(s: &str) -> Vec<String> {
    s.split(',')
        .map(|h| h.trim().to_string())
        .filter(|h| !h.is_empty())
        .collect()
}

fn find_body_boundary(raw: &str) -> usize {
    if let Some(i) = raw.find("\r\n\r\n") {
        i + 4
    } else if let Some(i) = raw.find("\n\n") {
        i + 2
    } else {
        raw.len()
    }
}

fn parse_preferences(list: &[String]) -> Vec<(String, String)> {
    let mut pairs = Vec::new();
    for entry in list {
        if let Some(comma) = entry.find(',') {
            let a = entry[..comma].trim().to_lowercase();
            let b = entry[comma + 1..].trim().to_lowercase();
            if !a.is_empty() && !b.is_empty() {
                pairs.push((a, b));
            }
        }
    }
    pairs
}

fn collect_handled_types(
    part: &mailparse::ParsedMail,
    handlers: &HashMap<String, String>,
) -> HashSet<String> {
    if part.subparts.is_empty() {
        let ct = part.ctype.mimetype.to_lowercase();
        if handlers.contains_key(&ct) {
            let mut s = HashSet::new();
            s.insert(ct);
            s
        } else {
            HashSet::new()
        }
    } else {
        let mut types = HashSet::new();
        for sub in &part.subparts {
            types.extend(collect_handled_types(sub, handlers));
        }
        types
    }
}

fn compute_hidden_types(
    handled: &HashSet<String>,
    preferences: &[(String, String)],
) -> HashSet<String> {
    let mut hidden = HashSet::new();
    for (preferred, fallback) in preferences {
        if handled.contains(preferred) {
            hidden.insert(fallback.clone());
        }
    }
    hidden
}

fn process_multipart_body(
    raw: &str,
    handlers: &HashMap<String, String>,
    preferences: &[(String, String)],
) -> anyhow::Result<String> {
    let parsed = mailparse::parse_mail(raw.as_bytes())
        .context("failed to parse MIME message")?;

    if !parsed.ctype.mimetype.starts_with("multipart/") {
        let body = parsed.get_body()
            .context("failed to decode email body")?;
        let ct = parsed.ctype.mimetype.to_lowercase();
        if let Some(handler_cmd) = handlers.get(&ct) {
            let charset = parsed.ctype.params.get("charset").map(|s| s.as_str());
            let sep = part_separator(&ct, charset, false);
            let mut child = std::process::Command::new("sh")
                .arg("-c")
                .arg(handler_cmd)
                .stdin(std::process::Stdio::piped())
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .spawn()
                .context("failed to spawn handler for non-multipart body")?;
            use std::io::Write;
            let _ = child.stdin.take()
                .expect("stdin available")
                .write_all(body.as_bytes());
            let output = child.wait_with_output()
                .context("handler failed")?;
            let mut result = sep;
            result.push_str(String::from_utf8_lossy(&output.stdout).trim_end_matches(&['\r', '\n'][..]));
            result.push('\n');
            return Ok(result);
        }
        return Ok(body);
    }

    let handled = collect_handled_types(&parsed, handlers);
    let hide = compute_hidden_types(&handled, preferences);

    let mut out = String::new();
    process_parts(&parsed, handlers, &hide, preferences, &mut out);
    Ok(out)
}

fn part_separator(content_type: &str, charset: Option<&str>, is_error: bool) -> String {
    let label = match charset {
        Some(ch) if !ch.eq_ignore_ascii_case("utf-8") && !ch.eq_ignore_ascii_case("us-ascii") =>
            format!("[{} ({})]", content_type, ch),
        _ => format!("[{}]", content_type),
    };
    let clr = use_color();
    let sep = if clr {
        if is_error {
            format!("{}{}{}", err_clr(), label, RST)
        } else {
            format!("{}{}{}", sep_clr(), label, RST)
        }
    } else {
        label
    };
    format!("\n{}\n\n", sep)
}

fn decode_part_body(part: &mailparse::ParsedMail) -> anyhow::Result<String> {
    if let Ok(body) = part.get_body() {
        return Ok(body);
    }
    let raw = part.get_body_raw()
        .context("failed to decode MIME part body")?;
    let charset_param = part.ctype.params.get("charset").map(|s| s.as_str());
    match charset_param {
        Some(ch) if !ch.eq_ignore_ascii_case("utf-8") && !ch.eq_ignore_ascii_case("us-ascii") =>
        {
            if let Some(enc) = encoding_rs::Encoding::for_label(ch.as_bytes()) {
                match enc.decode_without_bom_handling_and_without_replacement(&raw) {
                    Some(cow) => Ok(cow.into_owned()),
                    None => {
                        let (cow, _, _) = enc.decode(&raw);
                        Ok(cow.into_owned())
                    }
                }
            } else {
                Ok(String::from_utf8_lossy(&raw).into_owned())
            }
        }
        _ => Ok(String::from_utf8_lossy(&raw).into_owned()),
    }
}

fn write_error(out: &mut String, display_type: &str, charset: Option<&str>, msg: &str) {
    out.push_str(&part_separator(display_type, charset, true));
    let clr = use_color();
    if clr {
        out.push_str(&format!("{}[ERROR: {}]{}\n", err_clr(), msg, RST));
    } else {
        out.push_str(&format!("[ERROR: {}]\n", msg));
    }
}

fn has_handled_descendant(part: &mailparse::ParsedMail, handlers: &HashMap<String, String>) -> bool {
    if part.subparts.is_empty() {
        let ct = part.ctype.mimetype.to_lowercase();
        handlers.contains_key(&ct)
    } else {
        part.subparts.iter().any(|sub| has_handled_descendant(sub, handlers))
    }
}

fn pipe_to_handler(
    cmd: &str,
    input: &str,
    display_type: &str,
    charset: Option<&str>,
    out: &mut String,
) {
    let mut child = match Command::new("sh")
        .arg("-c")
        .arg(cmd)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(e) => {
            write_error(out, display_type, charset, &e.to_string());
            return;
        }
    };

    use std::io::Write;
    if let Err(e) = child.stdin
        .take()
        .expect("child stdin should be available")
        .write_all(input.as_bytes())
    {
        write_error(out, display_type, charset, &e.to_string());
        return;
    }

    let output = match child.wait_with_output() {
        Ok(o) => o,
        Err(e) => {
            write_error(out, display_type, charset, &e.to_string());
            return;
        }
    };

    if !output.status.success() {
        let code_info = output.status
            .code()
            .map(|c| format!("exit code {}", c))
            .unwrap_or_else(|| "process terminated".to_string());
        let stderr = String::from_utf8_lossy(&output.stderr);
        let err_msg = if stderr.trim().is_empty() {
            code_info
        } else {
            format!("{}: {}", code_info, stderr.trim())
        };
        write_error(out, display_type, charset, &err_msg);
        return;
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    let trimmed = stdout.trim_end_matches(&['\r', '\n'][..]);
    out.push_str(&part_separator(display_type, charset, false));
    out.push_str(trimmed);
    out.push('\n');
}

type HandlerResult = std::result::Result<(String, String, String), String>;

fn run_handler(handler_cmd: &str, input: &str) -> HandlerResult {
    let (mut reader, writer) = pipe().map_err(|e| e.to_string())?;
    let writer_fd = writer.as_raw_fd();

    let mut command = Command::new("sh");
    command.arg("-c").arg(handler_cmd)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    unsafe {
        command.pre_exec(move || {
            dup2(writer_fd, 3);
            close(writer_fd);
            Ok(())
        });
    }

    let mut child = command.spawn().map_err(|e| e.to_string())?;

    use std::io::Write;
    child.stdin
        .take()
        .expect("child stdin should be available")
        .write_all(input.as_bytes())
        .map_err(|e| e.to_string())?;

    drop(writer);
    let output = child.wait_with_output().map_err(|e| e.to_string())?;

    let mut fd3_out = String::new();
    let _ = reader.read_to_string(&mut fd3_out);

    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    if !output.status.success() {
        let code_info = output.status
            .code()
            .map(|c| format!("exit code {}", c))
            .unwrap_or_else(|| "process terminated".to_string());
        let err_msg = if stderr.trim().is_empty() {
            code_info
        } else {
            format!("{}: {}", code_info, stderr.trim())
        };
        return Err(err_msg);
    }

    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    Ok((stdout, stderr, fd3_out))
}

fn process_parts(
    part: &mailparse::ParsedMail,
    handlers: &HashMap<String, String>,
    hide: &HashSet<String>,
    preferences: &[(String, String)],
    out: &mut String,
) {
    let content_type = part.ctype.mimetype.to_lowercase();
    let display_type = &part.ctype.mimetype;
    if part.subparts.is_empty() {
        let charset = part.ctype.params.get("charset").map(|s| s.as_str());
        if hide.contains(&content_type) {
            return;
        }
        match handlers.get(&content_type) {
            Some(handler_cmd) => {
                let body = match decode_part_body(part) {
                    Ok(b) => b,
                    Err(e) => {
                        write_error(out, display_type, charset, &e.to_string());
                        return;
                    }
                };
                pipe_to_handler(handler_cmd, &body, display_type, charset, out);
            }
            None => {
                let raw_label = match charset {
                    Some(ch) if !ch.eq_ignore_ascii_case("utf-8") && !ch.eq_ignore_ascii_case("us-ascii") =>
                        format!("[{} ({})]", display_type, ch),
                    _ => format!("[{}]", display_type),
                };
                if use_color() {
                    out.push_str(&format!("\n{}{}{}\n", sep_clr(), raw_label, RST));
                } else {
                    out.push_str(&format!("\n{}\n", raw_label));
                }
            }
        }
        return;
    }

    // Non-leaf: multipart wrapper
    if let Some(handler_cmd) = handlers.get(&content_type) {
        let boundary = part.ctype.params.get("boundary").map(|s| s.as_str()).unwrap_or("boundary");
        let mut raw = String::new();
        for sub in &part.subparts {
            raw.push_str(&format!("--{}\r\n", boundary));
            raw.push_str(&String::from_utf8_lossy(sub.raw_bytes));
        }
        raw.push_str(&format!("--{}--\r\n", boundary));
        match run_handler(handler_cmd, &raw) {
            Ok((stdout, stderr, fd3_output)) => {
                let has_fd3 = !fd3_output.trim().is_empty();
                let has_err = !stderr.trim().is_empty();
                if has_fd3 || has_err {
                    if !out.is_empty() {
                        out.push('\n');
                    }
                    out.push_str(&part_separator(display_type, None, has_err));
                    let clr = use_color();
                    for line in fd3_output.lines() {
                        if clr {
                            out.push_str(&format!("{}{} {}{}\n", info_clr(), display_type, line, RST));
                        } else {
                            out.push_str(display_type);
                            out.push(' ');
                            out.push_str(line);
                            out.push('\n');
                        }
                    }
                    for line in stderr.lines() {
                        if clr {
                            out.push_str(&format!("{}{} {}{}\n", err_msg_clr(), display_type, line, RST));
                        } else {
                            out.push_str(display_type);
                            out.push(' ');
                            out.push_str(line);
                            out.push('\n');
                        }
                    }
                }
                if !stdout.trim().is_empty() {
                    match process_multipart_body(&stdout, handlers, preferences) {
                        Ok(processed) => {
                            if !processed.trim().is_empty() {
                                out.push('\n');
                                out.push_str(&processed);
                            }
                        }
                        Err(_) => {
                            out.push('\n');
                            out.push_str(&stdout);
                        }
                    }
                }
            }
            Err(err_msg) => {
                write_error(out, display_type, None, &err_msg);
            }
        }
        return;
    }

    if !hide.contains(&content_type) && !has_handled_descendant(part, handlers) {
        let sub_types: Vec<&str> = part.subparts.iter().map(|sub| sub.ctype.mimetype.as_str()).collect();
        let raw_label = format!("[{}+{}]", display_type, sub_types.join("+"));
        if use_color() {
            out.push_str(&format!("\n{}{}{}\n", sep_clr(), raw_label, RST));
        } else {
            out.push_str(&format!("\n{}\n", raw_label));
        }
        return;
    }

    if hide.contains(&content_type) {
        return;
    }

    for sub in &part.subparts {
        process_parts(sub, handlers, hide, preferences, out);
    }
}

fn filter_email_content(
    raw: &str,
    show: Option<&str>,
    hide: Option<&str>,
    multipart_handlers: Option<&HashMap<String, String>>,
    preferences: &[(String, String)],
) -> anyhow::Result<String> {
    let show_list = show.map(parse_header_list);
    let hide_list = hide.map(parse_header_list);

    match (&show_list, &hide_list) {
        (Some(s), Some(h)) if !s.is_empty() && !h.is_empty() => {
            return Ok(raw.to_string());
        }
        _ => {}
    }

    let body_idx = find_body_boundary(raw);
    let body = &raw[body_idx..];

    let parsed = mailparse::parse_mail(raw.as_bytes())
        .context("failed to parse email headers")?;
    let headers: Vec<(String, String)> = parsed
        .headers
        .iter()
        .map(|h| (h.get_key(), h.get_value()))
        .collect();

    let filtered: Vec<(String, String)> = if let Some(ref show_headers) = show_list {
        if show_headers.is_empty() {
            let mut result = Vec::new();
            for wanted in DEFAULT_HEADERS_SHOW {
                for (name, value) in &headers {
                    if wanted.eq_ignore_ascii_case(name) {
                        result.push((name.clone(), value.clone()));
                    }
                }
            }
            result
        } else {
            let mut result = Vec::new();
            for wanted in show_headers {
                for (name, value) in &headers {
                    if wanted.eq_ignore_ascii_case(name) {
                        result.push((name.clone(), value.clone()));
                    }
                }
            }
            result
        }
    } else if let Some(ref hide_headers) = hide_list {
        if hide_headers.is_empty() {
            headers
        } else {
            headers
                .iter()
                .filter(|(name, _)| {
                    !hide_headers
                        .iter()
                        .any(|h| h.eq_ignore_ascii_case(name))
                })
                .cloned()
                .collect()
        }
    } else {
        let mut result = Vec::new();
        for wanted in DEFAULT_HEADERS_SHOW {
            for (name, value) in &headers {
                if wanted.eq_ignore_ascii_case(name) {
                    result.push((name.clone(), value.clone()));
                }
            }
        }
        result
    };

    let mut out = String::new();
    let clr = use_color();
    for (name, value) in &filtered {
        if clr {
            out.push_str(hdr_key_clr());
            out.push_str(name);
            out.push_str(RST);
            out.push_str(": ");
            out.push_str(hdr_val_clr());
            out.push_str(value);
            out.push_str(RST);
        } else {
            out.push_str(name);
            out.push_str(": ");
            out.push_str(value);
        }
        out.push('\n');
    }

    let body_content = if let Some(handlers) = multipart_handlers {
        if !handlers.is_empty() {
            process_multipart_body(raw, handlers, preferences)
                .unwrap_or_else(|_| body.to_string())
        } else {
            body.to_string()
        }
    } else {
        body.to_string()
    };
    if !body_content.is_empty() && !body_content.starts_with('\n') {
        out.push('\n');
    }
    out.push_str(&body_content);
    Ok(out)
}

fn has_ansi(s: &str) -> bool {
    s.contains('\x1b')
}

fn wrap_output(text: &str, width: usize) -> String {
    let url_re = Regex::new(r#"https?://[^\s<>"']+|www\.[^\s<>"']+|(?:<)?mailto:[^\s<>"']+(?:>)?"#).unwrap();

    let mut out = String::new();
    for line in text.lines() {
        if has_ansi(line) || line.trim_start().starts_with('>') {
            out.push_str(line);
            out.push('\n');
            continue;
        }

        if UnicodeWidthStr::width(line) <= width {
            out.push_str(line);
            out.push('\n');
            continue;
        }

        let mut pos = 0;
        while pos < line.len() {
            let remaining = &line[pos..];
            if UnicodeWidthStr::width(remaining) <= width {
                out.push_str(remaining);
                out.push('\n');
                break;
            }

            if let Some(m) = url_re.find_at(remaining, 0) {
                if m.start() == 0 {
                    out.push_str(m.as_str());
                    pos += m.len();
                    if UnicodeWidthStr::width(m.as_str()) >= width {
                        out.push('\n');
                    }
                    continue;
                }
                let url_start = m.start();
                if url_start < width {
                    if let Some(sp) = remaining[..url_start].rfind(' ') {
                        out.push_str(&remaining[..sp]);
                        out.push('\n');
                        pos += sp + 1;
                        continue;
                    }
                }
            }

            let seg_vis = UnicodeWidthStr::width(remaining);
            let mut seg_end = remaining.len();
            if seg_vis > width {
                let mut vw = 0;
                for (i, c) in remaining.char_indices() {
                    let cw = UnicodeWidthStr::width(c.to_string().as_str());
                    if vw + cw > width {
                        seg_end = i;
                        break;
                    }
                    vw += cw;
                }
            }

            let seg = &remaining[..seg_end];
            if let Some(sp) = seg.rfind(' ') {
                out.push_str(&remaining[..sp]);
                out.push('\n');
                pos += sp + 1;
            } else {
                out.push_str(seg);
                out.push('\n');
                pos += seg.len();
            }
        }
    }
    out
}

/// Print a single email by its ID to stdout, applying header filtering, MIME
/// processing, multipart handlers, and wrapping according to the merged
/// config and CLI arguments.
pub fn run(config: ShowConfig, args: ShowArgs, default_data_dir: PathBuf) -> anyhow::Result<()> {
    let id = args.id;
    let cli_show = args.headers_show.is_some();
    let cli_hide = args.headers_hide.is_some();

    let mut cfg = merge_config(config, args);
    crate::resolve_mutual_exclusion(
        cli_show,
        cli_hide,
        &mut cfg.headers_show,
        &mut cfg.headers_hide,
        "headers-show",
        "headers-hide",
    )?;

    let no_color = cfg.no_color.unwrap_or(false) && !cfg.force_color.unwrap_or(false);
    NO_COLOR_FLAG.store(no_color, std::sync::atomic::Ordering::Relaxed);

    if let Some(spec) = &cfg.color_header_key {
        let (bg, fg, m) = parse_color_spec(spec);
        CUSTOM_HDR_KEY.set(make_ansi(bg, fg, &m)).ok();
    }
    if let Some(spec) = &cfg.color_header_value {
        let (bg, fg, m) = parse_color_spec(spec);
        CUSTOM_HDR_VAL.set(make_ansi(bg, fg, &m)).ok();
    }
    if let Some(spec) = &cfg.color_part_separator {
        let (bg, fg, m) = parse_color_spec(spec);
        CUSTOM_SEP_CLR.set(make_ansi(bg, fg, &m)).ok();
        let (err_sep, _) = make_err_ansi(spec);
        CUSTOM_ERR_CLR.set(err_sep).ok();
    }
    if let Some(spec) = &cfg.color_handler_info {
        let (bg, fg, m) = parse_color_spec(spec);
        CUSTOM_INFO_CLR.set(make_ansi(bg, fg, &m)).ok();
    }
    if let Some(spec) = &cfg.color_handler_error {
        let (bg, fg, m) = parse_color_spec(spec);
        CUSTOM_ERR_MSG_CLR.set(make_ansi(bg, fg, &m)).ok();
    }

    let maildir_path = cfg
        .maildir_path
        .map(PathBuf::from)
        .unwrap_or(default_data_dir);
    if id == 0 {
        anyhow::bail!("email ID must be a positive integer (1-based)");
    }

    let flag_new = cfg.flag_new.unwrap_or_else(|| "N".to_string());
    let flag_attachment = cfg.flag_attachment.unwrap_or_else(|| "A".to_string());
    let flag_encrypted = cfg.flag_encrypted.unwrap_or_else(|| "E".to_string());
    let flag_signed = cfg.flag_signed.unwrap_or_else(|| "S".to_string());
    let flag_reply = cfg.flag_reply.unwrap_or_else(|| "R".to_string());
    let flag_tagged = cfg.flag_tagged.unwrap_or_else(|| "T".to_string());
    let date_format = cfg
        .date_format
        .unwrap_or_else(|| list::DEFAULT_DATE_FORMAT.to_string());
    let order_by = cfg
        .order_by
        .as_deref()
        .and_then(list::parse_order_by)
        .unwrap_or(OrderBy { field: Field::Date, descending: true });

    let no_thread = cfg.no_thread.unwrap_or(false);

    let ctx = list::DisplayCtx {
        flag_new: &flag_new,
        flag_attachment: &flag_attachment,
        flag_encrypted: &flag_encrypted,
        flag_signed: &flag_signed,
        flag_reply: &flag_reply,
        flag_tagged: &flag_tagged,
        date_format: &date_format,
    };

    let infos = list::ordered_infos(&maildir_path, &ctx, &order_by, no_thread)?;

    if infos.is_empty() {
        anyhow::bail!("no emails found in mailbox");
    }

    if id > infos.len() {
        anyhow::bail!(
            "email ID {id} is out of range (mailbox has {} emails)",
            infos.len()
        );
    }

    let info = &infos[id - 1];
    let content = std::fs::read_to_string(&info.path)
        .with_context(|| format!("failed to read email file: {}", info.path.display()))?;

    if cfg.raw.unwrap_or(false) {
        print!("{content}");
        return Ok(());
    }

    let is_term = std::io::stdout().is_terminal() || cfg.force_color.unwrap_or(false);
    let mut handlers: HashMap<String, String> = default_multipart_handlers().into_iter().map(|(k, v)| {
        if let Some(rest) = v.strip_prefix("fem ") {
            let exe = std::env::current_exe()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_else(|_| "fem".to_string());
            let color_flag = if is_term { " --force-color" } else { " --no-color" };
            (k, format!("{} {}{}", exe, rest, color_flag))
        } else {
            (k, v)
        }
    }).collect();
    if let Some(user_handlers) = cfg.multipart_handle.clone() {
        for (k, v) in user_handlers {
            handlers.insert(k, v);
        }
    }

    let preferences = if cfg.no_multipart_preference.unwrap_or(false) {
        Vec::new()
    } else {
        let pref_list = cfg.multipart_preference.unwrap_or_else(|| vec![DEFAULT_MULTIPART_PREFERENCE.to_string()]);
        parse_preferences(&pref_list)
    };

    let filtered = filter_email_content(
        &content,
        cfg.headers_show.as_deref(),
        cfg.headers_hide.as_deref(),
        Some(&handlers),
        &preferences,
    )?;
    let wrap_width = cfg.wrap.unwrap_or(100);
    if wrap_width > 0 {
        print!("{}", wrap_output(&filtered, wrap_width));
    } else {
        print!("{filtered}");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Serializes tests that read or mutate the process-global color flag.
    static COLOR_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    /// Acquire the color lock and force color output off.
    fn color_disabled() -> std::sync::MutexGuard<'static, ()> {
        let g = COLOR_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
        NO_COLOR_FLAG.store(true, std::sync::atomic::Ordering::Relaxed);
        g
    }

    /// Acquire the color lock and force color output on.
    fn color_enabled() -> std::sync::MutexGuard<'static, ()> {
        let g = COLOR_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner);
        NO_COLOR_FLAG.store(false, std::sync::atomic::Ordering::Relaxed);
        g
    }

    #[test]
    fn test_parse_preferences_empty() {
        let result = parse_preferences(&[]);
        assert!(result.is_empty());
    }

    #[test]
    fn test_parse_preferences_single_pair() {
        let result = parse_preferences(&["text/plain,text/html".to_string()]);
        assert_eq!(result.len(), 1);
        assert_eq!(result[0].0, "text/plain");
        assert_eq!(result[0].1, "text/html");
    }

    #[test]
    fn test_parse_preferences_multiple_pairs() {
        let result = parse_preferences(&[
            "text/plain,text/html".to_string(),
            "text/enriched,text/plain".to_string(),
        ]);
        assert_eq!(result.len(), 2);
        assert_eq!(result[0].1, "text/html");
        assert_eq!(result[1].0, "text/enriched");
    }

    #[test]
    fn test_parse_preferences_normalizes_case() {
        let result = parse_preferences(&["TEXT/PLAIN,text/html".to_string()]);
        assert_eq!(result[0].0, "text/plain");
    }

    #[test]
    fn test_parse_preferences_skips_invalid() {
        let result = parse_preferences(&["nocomma".to_string()]);
        assert!(result.is_empty());
    }

    #[test]
    fn test_parse_header_list_simple() {
        let result = parse_header_list("From,To,Subject");
        assert_eq!(result, vec!["From", "To", "Subject"]);
    }

    #[test]
    fn test_parse_header_list_empty() {
        let result = parse_header_list("");
        assert!(result.is_empty());
    }

    #[test]
    fn test_part_separator_no_charset() {
        let result = part_separator("text/plain", None, false);
        assert!(result.contains("[text/plain]"));
    }

    #[test]
    fn test_part_separator_with_charset() {
        let result = part_separator("text/plain", Some("iso-8859-1"), false);
        assert!(result.contains("[text/plain (iso-8859-1)]"));
    }

    #[test]
    fn test_find_body_boundary_crlf() {
        let raw = "Header: value\r\n\r\nbody";
        assert_eq!(find_body_boundary(raw), 17);
    }

    #[test]
    fn test_find_body_boundary_lf() {
        let raw = "Header: value\n\nbody";
        assert_eq!(find_body_boundary(raw), 15);
    }

    #[test]
    fn test_find_body_boundary_no_separator() {
        let raw = "no empty line here";
        assert_eq!(find_body_boundary(raw), raw.len());
    }

    #[test]
    fn test_compute_hidden_types_no_match() {
        let handled: HashSet<String> = ["text/plain".into()].into();
        let prefs = vec![("text/html".into(), "text/plain".into())];
        let result = compute_hidden_types(&handled, &prefs);
        assert!(result.is_empty());
    }

    #[test]
    fn test_compute_hidden_types_match() {
        let handled: HashSet<String> = ["text/plain".into(), "text/html".into()].into();
        let prefs = vec![("text/plain".into(), "text/html".into())];
        let result = compute_hidden_types(&handled, &prefs);
        assert_eq!(result.len(), 1);
        assert!(result.contains("text/html"));
    }

    #[test]
    fn test_compute_hidden_types_no_prefs() {
        let handled: HashSet<String> = ["text/plain".into()].into();
        let result = compute_hidden_types(&handled, &[]);
        assert!(result.is_empty());
    }

    #[test]
    fn test_compute_hidden_types_multiple_pairs() {
        let handled: HashSet<String> = ["text/plain".into(), "application/pdf".into()].into();
        let prefs = vec![
            ("text/plain".into(), "text/html".into()),
            ("application/pdf".into(), "image/png".into()),
        ];
        let result = compute_hidden_types(&handled, &prefs);
        assert_eq!(result.len(), 2);
        assert!(result.contains("text/html"));
        assert!(result.contains("image/png"));
    }

    #[test]
    fn test_filter_email_content_no_headers_filter_no_handlers() {
        let _g = color_disabled();
        let raw = "From: a@x.com\r\nTo: b@x.com\r\n\r\nHello body";
        let result = filter_email_content(raw, None, None, None, &[]).unwrap();
        assert!(result.contains("From: a@x.com"));
        assert!(result.contains("Hello body"));
    }

    #[test]
    fn test_filter_email_content_show_headers() {
        let _g = color_disabled();
        let raw = "From: a@x.com\r\nTo: b@x.com\r\nSubject: T\r\n\r\nBody";
        let result = filter_email_content(raw, Some("From,Subject"), None, None, &[]).unwrap();
        assert!(result.contains("From: a@x.com"));
        assert!(result.contains("Subject: T"));
        assert!(!result.contains("To:"));
        assert!(result.contains("Body"));
    }

    #[test]
    fn test_filter_email_content_hide_headers() {
        let _g = color_disabled();
        let raw = "From: a@x.com\r\nTo: b@x.com\r\nSubject: T\r\n\r\nBody";
        let result = filter_email_content(raw, None, Some("To"), None, &[]).unwrap();
        assert!(result.contains("From:"));
        assert!(!result.contains("To:"));
        assert!(result.contains("Subject: T"));
        assert!(result.contains("Body"));
    }

    #[test]
    fn test_filter_email_content_mutual_exclusion_returns_raw() {
        let raw = "From: a\r\n\r\nbody";
        let result = filter_email_content(raw, Some("From"), Some("To"), None, &[]).unwrap();
        assert_eq!(result, raw);
    }

    #[test]
    fn test_decode_part_body_utf8() {
        let raw = "From: a\r\nContent-Type: text/plain; charset=utf-8\r\n\r\nHello";
        let parsed = mailparse::parse_mail(raw.as_bytes()).unwrap();
        let result = decode_part_body(&parsed).unwrap();
        assert_eq!(result, "Hello");
    }

    #[test]
    fn test_decode_part_body_base64() {
        let raw = "From: a\r\nContent-Type: text/plain\r\nContent-Transfer-Encoding: base64\r\n\r\nSGVsbG8=";
        let parsed = mailparse::parse_mail(raw.as_bytes()).unwrap();
        let result = decode_part_body(&parsed).unwrap();
        assert_eq!(result, "Hello");
    }

    #[test]
    fn test_default_multipart_handlers() {
        let handlers = default_multipart_handlers();
        assert!(handlers.contains_key("text/plain"));
        assert!(handlers.contains_key("text/html"));
        assert_eq!(handlers.get("text/plain").unwrap(), "fem cat");
    }

    #[test]
    fn test_multipart_body_non_multipart() {
        let raw = "From: a\r\n\r\nSimple body";
        let handlers = HashMap::new();
        let result = process_multipart_body(raw, &handlers, &[]).unwrap();
        assert_eq!(result, "Simple body");
    }

    #[test]
    fn test_filter_email_content_non_multipart_with_handlers() {
        let raw = "From: a\r\nContent-Type: text/plain\r\n\r\nBody text";
        let handlers = HashMap::new();
        let result = filter_email_content(raw, None, None, Some(&handlers), &[]).unwrap();
        assert!(result.contains("Body text"));
    }

    #[test]
    fn test_color_spec_parsing() {
        assert_eq!(parse_color_spec("22,33,bold"), (Some(22), Some(33), "bold".to_string()));
        assert_eq!(parse_color_spec("22"), (Some(22), None, String::new()));
        assert_eq!(parse_color_spec(",,underline"), (None, None, "underline".to_string()));
        assert_eq!(parse_color_spec("10,20"), (Some(10), Some(20), String::new()));
        assert_eq!(parse_color_spec("ab,cd"), (None, None, String::new()));
    }

    #[test]
    fn test_make_ansi_combines_codes() {
        assert_eq!(make_ansi(Some(1), Some(2), "bold"), "\x1b[48;5;1m\x1b[38;5;2m\x1b[1m");
        assert_eq!(make_ansi(Some(3), None, "blink"), "\x1b[48;5;3m\x1b[5m");
        assert_eq!(make_ansi(None, Some(4), "underline"), "\x1b[38;5;4m\x1b[4m");
        assert_eq!(make_ansi(None, Some(7), "reverse"), "\x1b[38;5;7m\x1b[7m");
        assert_eq!(make_ansi(Some(9), Some(8), "bogus"), "\x1b[48;5;9m\x1b[38;5;8m");
        assert_eq!(make_ansi(None, None, ""), "");
    }

    #[test]
    fn test_make_err_ansi_specs() {
        let (sep, err) = make_err_ansi(",,bold");
        assert_eq!(sep, "\x1b[48;5;196m\x1b[1m");
        assert_eq!(err, "\x1b[1m");

        let (sep, err) = make_err_ansi(",33,");
        assert_eq!(sep, "\x1b[48;5;196m\x1b[38;5;33m");
        assert_eq!(err, "\x1b[38;5;33m");

        let (_, err) = make_err_ansi(",10,underline");
        assert_eq!(err, "\x1b[38;5;10m\x1b[4m");
    }

    #[test]
    fn test_wrap_output_keeps_short_lines() {
        assert_eq!(wrap_output("short line\n", 20), "short line\n");
        assert_eq!(wrap_output("", 20), "");
    }

    #[test]
    fn test_wrap_output_skips_ansi_and_citations() {
        let ansi = "\x1b[1mhello\x1b[0m";
        assert_eq!(wrap_output(ansi, 5), format!("{ansi}\n"));
        let citation = "> a quoted line that is far longer than the wrap width";
        assert_eq!(wrap_output(citation, 10), format!("{citation}\n"));
    }

    #[test]
    fn test_wrap_output_breaks_long_lines() {
        let out = wrap_output("this is a very long line that exceeds the width", 10);
        let lines: Vec<&str> = out.lines().collect();
        assert!(lines.len() > 1, "long line must be broken: {out}");
        for line in &lines {
            assert!(UnicodeWidthStr::width(*line) <= 10, "line too wide: '{line}'");
        }
    }

    #[test]
    fn test_wrap_output_keeps_urls_intact() {
        let url = "https://example.com/a/very/long/path";
        let out = wrap_output(&format!("see {url} for details"), 30);
        assert!(out.contains(url), "URL must not be split: {out}");
    }

    #[test]
    fn test_parse_multipart_handlers_pairs() {
        let m = parse_multipart_handlers(&[
            "multipart/encrypted=/path/gpg.sh".to_string(),
            "text/html=lynx -dump".to_string(),
        ]);
        assert_eq!(m.get("multipart/encrypted").map(String::as_str), Some("/path/gpg.sh"));
        assert_eq!(m.get("text/html").map(String::as_str), Some("lynx -dump"));
        assert!(parse_multipart_handlers(&["no-equals".to_string()]).is_empty());
        assert!(parse_multipart_handlers(&["=value".to_string()]).is_empty());
        assert!(parse_multipart_handlers(&["key=".to_string()]).is_empty());
        assert_eq!(m.len(), 2);
    }

    #[test]
    fn test_merge_config_cli_overrides_config() {
        let config = ShowConfig {
            headers_show: Some("From".to_string()),
            no_color: Some(true),
            wrap: Some(40),
            order_by: Some("date:desc".to_string()),
            multipart_handle: Some(HashMap::from([("text/html".to_string(), "w3m".to_string())])),
            ..Default::default()
        };
        let args = ShowArgs {
            headers_show: Some("Subject".to_string()),
            wrap: Some(80),
            order_by: Some("from:asc".to_string()),
            multipart_handle: vec!["text/html=lynx".to_string()],
            force_color: true,
            ..Default::default()
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.headers_show.as_deref(), Some("Subject"));
        assert_eq!(merged.wrap, Some(80));
        assert_eq!(merged.order_by.as_deref(), Some("from:asc"));
        assert_eq!(
            merged.multipart_handle.as_ref().unwrap().get("text/html").map(String::as_str),
            Some("lynx")
        );
        assert_eq!(merged.force_color, Some(true));
        assert_eq!(merged.no_color, Some(true), "unset --no-color keeps the config value");
    }

    #[test]
    fn test_filter_email_content_color_flag_toggles_ansi() {
        let raw = "From: a@x\r\nSubject: Hi\r\n\r\nbody";

        let colored = {
            let _g = color_enabled();
            filter_email_content(raw, None, None, None, &[]).unwrap()
        };
        assert!(colored.contains('\x1b'), "color on must emit ANSI: {colored:?}");

        let plain = {
            let _g = color_disabled();
            filter_email_content(raw, None, None, None, &[]).unwrap()
        };
        assert!(!plain.contains('\x1b'), "color off must not emit ANSI: {plain:?}");
    }

    #[test]
    fn test_ordered_infos_show_custom_flags_and_date_format() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = crate::maildir::Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        maildir.deliver(b"From: a@x\r\nSubject: S\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nbody").unwrap();

        let ob = list::OrderBy { field: list::Field::Date, descending: true };
        let ctx = list::DisplayCtx {
            flag_new: "N",
            flag_attachment: "A",
            flag_encrypted: "E",
            flag_signed: "S",
            flag_reply: "R",
            flag_tagged: "T",
            date_format: "%Y-%m-%d",
        };
        let infos = list::ordered_infos(&dir.path().join("maildir"), &ctx, &ob, false).unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].date, "2026-07-29", "custom date format must apply");
        assert_eq!(infos[0].flags, "N", "new message must carry the new flag");
    }

    fn deliver_one(dir: &tempfile::TempDir) -> crate::maildir::Maildir {
        let maildir = crate::maildir::Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        maildir.deliver(b"From: a@x\r\nSubject: S\r\n\r\nbody").unwrap();
        maildir
    }

    #[test]
    fn test_headers_show_cli_wins_over_config_hide() {
        let _g = color_disabled();
        let dir = tempfile::tempdir().unwrap();
        deliver_one(&dir);

        let config = ShowConfig {
            headers_hide: Some("From".to_string()),
            ..Default::default()
        };
        let args = ShowArgs {
            id: 1,
            maildir_path: Some(dir.path().join("maildir").to_str().unwrap().to_string()),
            headers_show: Some("From".to_string()),
            raw: true,
            ..Default::default()
        };
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_ok(), "cli --headers-show must win over config hide: {res:?}");
    }

    #[test]
    fn test_headers_hide_cli_wins_over_config_show() {
        let _g = color_disabled();
        let dir = tempfile::tempdir().unwrap();
        deliver_one(&dir);

        let config = ShowConfig {
            headers_show: Some("From".to_string()),
            ..Default::default()
        };
        let args = ShowArgs {
            id: 1,
            maildir_path: Some(dir.path().join("maildir").to_str().unwrap().to_string()),
            headers_hide: Some("From".to_string()),
            raw: true,
            ..Default::default()
        };
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_ok(), "cli --headers-hide must win over config show: {res:?}");
    }

    #[test]
    fn test_headers_conflict_both_cli_errors() {
        let _g = color_disabled();
        let dir = tempfile::tempdir().unwrap();
        deliver_one(&dir);

        let args = ShowArgs {
            id: 1,
            maildir_path: Some(dir.path().join("maildir").to_str().unwrap().to_string()),
            headers_show: Some("From".to_string()),
            headers_hide: Some("Subject".to_string()),
            raw: true,
            ..Default::default()
        };
        let res = run(ShowConfig::default(), args, std::path::PathBuf::new());
        assert!(res.is_err(), "both on CLI must stay mutually exclusive");
        assert!(format!("{:?}", res).contains("mutually exclusive"));
    }

    #[test]
    fn test_headers_conflict_both_config_errors() {
        let _g = color_disabled();
        let dir = tempfile::tempdir().unwrap();
        deliver_one(&dir);

        let config = ShowConfig {
            headers_show: Some("From".to_string()),
            headers_hide: Some("Subject".to_string()),
            ..Default::default()
        };
        let args = ShowArgs {
            id: 1,
            maildir_path: Some(dir.path().join("maildir").to_str().unwrap().to_string()),
            raw: true,
            ..Default::default()
        };
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_err(), "both set in config must stay mutually exclusive");
        assert!(format!("{:?}", res).contains("mutually exclusive"));
    }
}
