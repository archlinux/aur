//! Build a contact list from the local Maildir for address autocompletion.
//!
//! Scans every message in the Maildir, collects the addresses found in the
//! `From`, `To`, and `Cc` headers (including any RFC 2047 encoded display
//! names), deduplicates them, and caches the result in a file keyed by a
//! fingerprint of the Maildir contents. When the Maildir changes, the cache is
//! rebuilt on the next call.
//!
//! Contacts are matched with a case-insensitive substring against both the
//! display name and the address, so typing `pepe` matches both `Pepe Poco`
//! and `pepepoco@gmail.com`.

use crate::list;
use crate::maildir::Maildir;
use std::collections::HashMap;
use std::path::Path;
use std::time::SystemTime;

/// A single contact: a display name and an email address.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Contact {
    /// Display name (may be empty).
    pub name: String,
    /// Email address.
    pub email: String,
}

impl Contact {
    /// Whether the contact matches a typed prefix (case-insensitive substring).
    pub fn matches(&self, prefix: &str) -> bool {
        let prefix = prefix.to_lowercase();
        self.email.to_lowercase().contains(&prefix) || self.name.to_lowercase().contains(&prefix)
    }

    /// The RFC 5322 form: `"Name" <email>` when a name is present, else `email`.
    pub fn formatted(&self) -> String {
        if self.name.is_empty() {
            self.email.clone()
        } else if needs_quoting(&self.name) {
            format!("\"{}\" <{}>", self.name, self.email)
        } else {
            format!("{} <{}>", self.name, self.email)
        }
    }
}

/// Whether a display name needs surrounding quotes per RFC 5322.
fn needs_quoting(name: &str) -> bool {
    name.chars().any(|c| c.is_whitespace() || "(),:;<>@[]\"\\".contains(c))
}

/// Split a header value into its top-level comma-separated parts, ignoring
/// commas inside quotes, angle brackets, or parentheses.
fn split_addresses(value: &str) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut start = 0usize;
    let mut in_quote = false;
    let mut angle = 0u32;
    let mut paren = 0u32;
    for (i, c) in value.char_indices() {
        match c {
            '"' => in_quote = !in_quote,
            '<' if !in_quote => angle += 1,
            '>' if !in_quote => angle = angle.saturating_sub(1),
            '(' if !in_quote => paren += 1,
            ')' if !in_quote => paren = paren.saturating_sub(1),
            ',' if !in_quote && angle == 0 && paren == 0 => {
                parts.push(&value[start..i]);
                start = i + 1;
            }
            _ => {}
        }
    }
    parts.push(&value[start..]);
    parts
}

/// Parse one address part like `Pepe Poco <pepepoco@gmail.com>`, returning
/// the display name (unquoted) and the address. Handles bare `user@example.com`
/// forms too.
fn parse_one(part: &str) -> Option<Contact> {
    let part = part.trim();
    if part.is_empty() {
        return None;
    }
    if let Some(open) = part.rfind('<') {
        if let Some(close) = part[open..].find('>') {
            let email = part[open + 1..open + close].trim().to_string();
            let name = part[..open].trim().trim_matches('"').trim().to_string();
            if email.contains('@') {
                return Some(Contact { name, email });
            }
        }
    }
    if part.contains('@') {
        return Some(Contact { name: String::new(), email: part.to_string() });
    }
    None
}

/// Parse a header value into a list of contacts.
pub fn parse_addresses(value: &str) -> Vec<Contact> {
    split_addresses(value).iter().filter_map(|part| parse_one(part)).collect()
}

/// Scan a single message's headers, adding any new contacts to `out`.
fn collect_from_message(path: &Path, out: &mut HashMap<String, Contact>) {
    let content = match crate::find::read_header_block(path) {
        Ok(Some(block)) => block,
        _ => match std::fs::read(path) {
            Ok(c) => c,
            Err(_) => return,
        },
    };
    let Ok(parsed) = mailparse::parse_mail(&content) else { return };
    for header in ["From", "To", "Cc"] {
        let Some(value) = list::header_value(&parsed.headers, header) else { continue };
        for contact in parse_addresses(&value) {
            let key = contact.email.to_lowercase();
            match out.get(&key) {
                // Prefer the variant that has a display name.
                Some(existing) if existing.name.is_empty() && !contact.name.is_empty() => {
                    out.insert(key, contact);
                }
                Some(_) => {}
                None => {
                    out.insert(key, contact);
                }
            }
        }
    }
}

/// The newest modification time (nanos since epoch) across all message files.
fn newest_mtime(maildir: &Maildir) -> Option<u128> {
    let messages = maildir.list_messages().ok()?;
    messages
        .iter()
        .filter_map(|p| std::fs::metadata(p).ok()?.modified().ok())
        .filter_map(|m| m.duration_since(SystemTime::UNIX_EPOCH).ok())
        .map(|d| d.as_nanos())
        .max()
}

/// A change-detection fingerprint for a Maildir, packed into a single value.
///
/// The high 64 bits hold the message count and the low 64 bits hold the newest
/// message modification time. Counting messages makes the fingerprint robust on
/// filesystems with coarse mtime granularity, where two messages written within
/// the same timestamp tick would otherwise be indistinguishable.
fn maildir_fingerprint(maildir: &Maildir) -> Option<u128> {
    let messages = maildir.list_messages().ok()?;
    let newest = newest_mtime(maildir).unwrap_or(0);
    Some(((messages.len() as u128) << 64) | newest)
}

/// Scan the whole Maildir and return the deduplicated, sorted contact list.
pub fn scan_maildir(maildir_path: &Path) -> Vec<Contact> {
    let maildir = Maildir::new(maildir_path.to_path_buf());
    let mut by_email: HashMap<String, Contact> = HashMap::new();
    if let Ok(messages) = maildir.list_messages() {
        for path in messages {
            collect_from_message(&path, &mut by_email);
        }
    }
    let mut contacts: Vec<Contact> = by_email.into_values().collect();
    contacts.sort_by(|a, b| {
        a.email
            .to_lowercase()
            .cmp(&b.email.to_lowercase())
            .then_with(|| a.name.cmp(&b.name))
    });
    contacts
}

/// Load the contact list for a Maildir, using the cache file when it is fresh.
///
/// The cache is keyed by a fingerprint of the Maildir (message count and newest
/// modification time): when the Maildir is unchanged since the cache was written,
/// the cached contacts are returned; otherwise the Maildir is rescanned and the
/// cache is rewritten.
pub fn load_or_scan(maildir_path: &Path, cache_file: &Path) -> Vec<Contact> {
    let maildir = Maildir::new(maildir_path.to_path_buf());
    let newest = maildir_fingerprint(&maildir).unwrap_or(0);
    if let Ok(cached) = std::fs::read_to_string(cache_file) {
        if let Some((stamp, contacts)) = parse_cache(&cached) {
            if stamp == newest {
                return contacts;
            }
        }
    }
    let contacts = scan_maildir(maildir_path);
    if let Some(parent) = cache_file.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Ok(text) = serialize_cache(&contacts, newest) {
        let _ = std::fs::write(cache_file, text);
    }
    contacts
}

/// Serialize the contact list to the cache text format.
fn serialize_cache(contacts: &[Contact], stamp: u128) -> std::io::Result<String> {
    let mut out = String::new();
    out.push_str("# fem contacts cache v1\n");
    out.push_str(&format!("fingerprint {stamp}\n"));
    for contact in contacts {
        let name = contact.name.replace('\\', "\\\\").replace('\n', "\\n").replace('\t', "\\t");
        let email = contact.email.replace('\\', "\\\\");
        out.push_str(&format!("{}\t{}\n", name, email));
    }
    Ok(out)
}

/// Parse the cache text format back into a stamp and a contact list.
fn parse_cache(text: &str) -> Option<(u128, Vec<Contact>)> {
    let mut lines = text.lines();
    if lines.next()? != "# fem contacts cache v1" {
        return None;
    }
    let stamp = lines.next()?.strip_prefix("fingerprint ")?.parse().ok()?;
    let mut contacts = Vec::new();
    for line in lines {
        if line.is_empty() {
            continue;
        }
        let (name, email) = line.split_once('\t')?;
        let name = name.replace("\\n", "\n").replace("\\t", "\t").replace("\\\\", "\\");
        let email = email.replace("\\\\", "\\");
        contacts.push(Contact { name, email });
    }
    Some((stamp, contacts))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn parse_bare_address() {
        let c = parse_addresses("pepepoco@gmail.com");
        assert_eq!(c.len(), 1);
        assert_eq!(c[0].email, "pepepoco@gmail.com");
        assert_eq!(c[0].name, "");
    }

    #[test]
    fn parse_name_and_address() {
        let c = parse_addresses("Pepe Poco <pepepoco@gmail.com>");
        assert_eq!(c.len(), 1);
        assert_eq!(c[0].name, "Pepe Poco");
        assert_eq!(c[0].email, "pepepoco@gmail.com");
    }

    #[test]
    fn parse_quoted_name() {
        let c = parse_addresses("\"Doe, John\" <john@example.com>");
        assert_eq!(c.len(), 1);
        assert_eq!(c[0].name, "Doe, John");
        assert_eq!(c[0].email, "john@example.com");
    }

    #[test]
    fn parse_multiple_addresses() {
        let c = parse_addresses("a@example.com, \"B C\" <b@example.com>");
        assert_eq!(c.len(), 2);
        assert_eq!(c[0].name, "");
        assert_eq!(c[0].email, "a@example.com");
        assert_eq!(c[1].name, "B C");
    }

    #[test]
    fn parse_skips_empty_parts() {
        let c = parse_addresses(",a@example.com,,");
        assert_eq!(c.len(), 1);
        assert_eq!(c[0].email, "a@example.com");
    }

    #[test]
    fn contact_matches_prefix_case_insensitive() {
        let c = Contact { name: "Pepe Poco".into(), email: "pepepoco@gmail.com".into() };
        assert!(c.matches("pepe"));
        assert!(c.matches("POCO"));
        assert!(c.matches("pepepoco@gmail.com"));
        assert!(!c.matches("nobody"));
    }

    #[test]
    fn contact_formatted() {
        let with_name = Contact { name: "Pepe Poco".into(), email: "pepepoco@gmail.com".into() };
        assert_eq!(with_name.formatted(), "\"Pepe Poco\" <pepepoco@gmail.com>");
        let no_name = Contact { name: String::new(), email: "pepe@x.com".into() };
        assert_eq!(no_name.formatted(), "pepe@x.com");
    }

    #[test]
    fn cache_round_trip_and_fingerprint() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().join("maildir"));
        maildir.ensure_dirs().unwrap();

        maildir
            .deliver(b"From: Alice <alice@example.com>\r\nTo: bob@example.com\r\n\r\nhi")
            .unwrap();
        let stamp = newest_mtime(&maildir).unwrap();
        let text = serialize_cache(&scan_maildir(maildir.path()), stamp).unwrap();
        let (parsed_stamp, contacts) = parse_cache(&text).unwrap();
        assert_eq!(parsed_stamp, stamp);
        assert_eq!(contacts.len(), 2);
    }

    #[test]
    fn load_or_scan_writes_and_reads_cache() {
        let dir = tempfile::tempdir().unwrap();
        let maildir_path = dir.path().join("maildir");
        let maildir = Maildir::new(maildir_path.clone());
        maildir.ensure_dirs().unwrap();
        let cache_file = dir.path().join("contacts.cache");

        maildir
            .deliver(b"From: Alice <alice@example.com>\r\nTo: bob@example.com\r\n\r\nhi")
            .unwrap();

        let first = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(first.len(), 2);
        assert!(cache_file.exists());

        let second = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(second, first);
    }

    #[test]
    fn load_or_scan_rebuilds_when_maildir_changes() {
        let dir = tempfile::tempdir().unwrap();
        let maildir_path = dir.path().join("maildir");
        let maildir = Maildir::new(maildir_path.clone());
        maildir.ensure_dirs().unwrap();
        let cache_file = dir.path().join("contacts.cache");

        maildir.deliver(b"From: a@example.com\r\n\r\nhi").unwrap();
        let before = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(before.len(), 1);

        maildir.deliver(b"From: b@example.com\r\n\r\nhi").unwrap();
        let after = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(after.len(), 2);
    }

    #[test]
    fn scan_maildir_dedupes_by_email() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().join("maildir"));
        maildir.ensure_dirs().unwrap();
        maildir.deliver(b"From: Alice <alice@example.com>\r\nTo: bob@example.com\r\n\r\n1").unwrap();
        maildir.deliver(b"From: alice@example.com\r\n\r\n2").unwrap();
        let contacts = scan_maildir(maildir.path());
        let alice: Vec<_> = contacts.iter().filter(|c| c.email == "alice@example.com").collect();
        assert_eq!(alice.len(), 1);
        assert_eq!(alice[0].name, "Alice");
    }

    #[test]
    fn cache_handles_control_char_escapes() {
        let contacts = vec![Contact { name: "A\tB\nC".into(), email: "x@y.com".into() }];
        let text = serialize_cache(&contacts, 42).unwrap();
        let (stamp, parsed) = parse_cache(&text).unwrap();
        assert_eq!(stamp, 42);
        assert_eq!(parsed, contacts);
    }

    #[test]
    fn parse_cache_rejects_bad_format() {
        assert!(parse_cache("garbage\n").is_none());
    }

    #[test]
    fn write_and_read_cache_uses_real_file() {
        let dir = tempfile::tempdir().unwrap();
        let maildir_path = dir.path().join("maildir");
        let maildir = Maildir::new(maildir_path.clone());
        maildir.ensure_dirs().unwrap();
        let cache_file = dir.path().join("nested").join("cache");

        maildir.deliver(b"From: Alice <alice@example.com>\r\n\r\nhi").unwrap();
        let contacts = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(contacts.len(), 1);
        assert!(cache_file.exists());

        let mut handle = std::fs::OpenOptions::new().append(true).open(&cache_file).unwrap();
        writeln!(handle, "corrupting-the-cache").unwrap();
        drop(handle);
        // A corrupt/partial cache just triggers a rescan rather than a crash.
        let contacts = load_or_scan(&maildir_path, &cache_file);
        assert_eq!(contacts.len(), 1);
    }
}
