//! Command-line entry point for `fem`.
//!
//! Parses the top-level CLI with clap and dispatches each subcommand (`pull`,
//! `push`, `list`, `show`, `cat`, `compose`, `find`) to its module, passing
//! the merged per-subcommand config, CLI args, and the resolved data directory.

use clap::{Parser, Subcommand};
use std::io::IsTerminal;

#[derive(Parser)]
#[command(name = "fem", about = "CLI-based email management")]
struct Cli {
    #[command(subcommand)]
    command: Commands,

    /// Path to TOML config file [default: $XDG_CONFIG_HOME/fem/fem.toml]
    #[arg(short = 'c', long = "config", global = true)]
    config: Option<String>,
}

#[derive(Subcommand)]
enum Commands {
    /// Pull emails from an IMAP4 server and store them locally in Maildir format
    Pull(PullCliArgs),
    /// Send an email message over SMTP (reads a raw message from stdin, or sends drafts)
    Push(PushCliArgs),
    /// List emails stored in the local Maildir
    List(ListCliArgs),
    /// Show a single email by its ID (as displayed in fem list)
    Show(ShowCliArgs),
    /// Read from stdin and write to stdout (like cat)
    Cat(CatCliArgs),
    /// Create a new email draft
    Compose(ComposeCliArgs),
    /// Search local Maildir emails by header, body text, or date range
    Find(FindCliArgs),
    /// Tag an email (by its ID as shown in fem list) with a label
    Tag(TagCliArgs),
}

#[derive(clap::Args)]
struct PullCliArgs {
    /// IMAP server hostname
    #[arg(short = 's', long)]
    server: Option<String>,
    /// IMAP server port
    #[arg(short = 'p', long)]
    port: Option<u16>,
    /// Username for IMAP authentication
    #[arg(short = 'u', long)]
    username: Option<String>,
    /// Password for IMAP authentication (prompts if omitted)
    #[arg(short = 'w', long)]
    password: Option<String>,
    /// Command to get the IMAP password (reads first line of stdout)
    #[arg(long = "password-command")]
    password_command: Option<String>,
    /// Mailbox to fetch (default: INBOX)
    #[arg(short = 'm', long)]
    mailbox: Option<String>,
    /// Use SSL/TLS (default: true)
    #[arg(long)]
    ssl: Option<bool>,
    /// Fetch all emails, not just unseen ones
    #[arg(long, action = clap::ArgAction::SetTrue)]
    all: bool,
    /// Binary/script to run before each message is stored (the raw message is
    /// fed on stdin; its stdout becomes the stored message; no output skips the
    /// message; a non-zero exit stops the pull)
    #[arg(long = "pre-hook")]
    pre_hook: Option<String>,
    /// Binary/script to run after each message is stored (receives the message
    /// path as $1; a non-zero exit stops the pull)
    #[arg(long = "post-hook")]
    post_hook: Option<String>,
}

#[derive(clap::Args)]
struct PushCliArgs {
    /// SMTP server hostname
    #[arg(short = 's', long)]
    server: Option<String>,
    /// SMTP server port
    #[arg(short = 'p', long)]
    port: Option<u16>,
    /// Username for SMTP authentication
    #[arg(short = 'u', long)]
    username: Option<String>,
    /// Password for SMTP authentication (prompts if omitted)
    #[arg(short = 'w', long)]
    password: Option<String>,
    /// Command to get the SMTP password (reads first line of stdout)
    #[arg(long = "password-command")]
    password_command: Option<String>,
    /// Use SSL/TLS (default: true)
    #[arg(long)]
    ssl: Option<bool>,
    /// Use STARTTLS to upgrade the connection (mutually exclusive with --ssl)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    starttls: bool,
    /// Directory containing draft emails (default: <data_dir>/drafts)
    #[arg(long = "drafts-path")]
    drafts_path: Option<String>,
    /// Send all drafts in the drafts directory (no stdin expected)
    #[arg(long = "all-drafts", action = clap::ArgAction::SetTrue)]
    all_drafts: bool,
    /// Send only the most recently modified draft (no stdin expected)
    #[arg(long = "last-draft", action = clap::ArgAction::SetTrue)]
    last_draft: bool,
}

#[derive(clap::Args)]
struct ListCliArgs {
    /// Path to Maildir directory (defaults to XDG data dir)
    #[arg(short = 'd', long)]
    maildir_path: Option<String>,
    /// Maximum number of emails to display (default: 25)
    #[arg(long)]
    limit: Option<usize>,
    /// Number of emails to skip before displaying (default: 0)
    #[arg(long)]
    offset: Option<usize>,
    /// Output format: table, json, table-raw, tsv (default: table)
    #[arg(long)]
    format: Option<String>,
    /// Table fields: comma-separated field names, each optionally suffixed with :width (e.g. subject:40, from:30)
    #[arg(long)]
    table_fields: Option<String>,
    /// Character(s) for the new/unread flag (default: N)
    #[arg(long)]
    flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    #[arg(long)]
    flag_attachment: Option<String>,
    /// Character(s) for the reply flag (default: R)
    #[arg(long)]
    flag_reply: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    #[arg(long)]
    flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    #[arg(long)]
    flag_signed: Option<String>,
    /// Character(s) for the tag flag (default: T)
    #[arg(long)]
    flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    #[arg(long)]
    date_format: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    #[arg(long)]
    order_by: Option<String>,
    /// Disable reply threading (show emails in strict global order)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    no_thread: bool,
}

#[derive(clap::Args)]
struct ShowCliArgs {
    /// Email ID (1-based, as shown in fem list)
    id: usize,
    /// Path to Maildir directory (defaults to XDG data dir)
    #[arg(short = 'd', long)]
    maildir_path: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    #[arg(long)]
    order_by: Option<String>,
    /// Disable reply threading (show emails in strict global order)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    no_thread: bool,
    /// Character(s) for the new/unread flag (default: N)
    #[arg(long)]
    flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    #[arg(long)]
    flag_attachment: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    #[arg(long)]
    flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    #[arg(long)]
    flag_signed: Option<String>,
    /// Character(s) for the reply flag (default: R)
    #[arg(long)]
    flag_reply: Option<String>,
    /// Character(s) for the tag flag (default: T)
    #[arg(long)]
    flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    #[arg(long)]
    date_format: Option<String>,
    /// Comma-separated list of headers to show (default: From,To,Subject,List-Unsubscribe,Date)
    #[arg(long)]
    headers_show: Option<String>,
    /// Comma-separated list of headers to hide (mutually exclusive with --headers-show;
    /// if --headers-show is set in config it is ignored)
    #[arg(long)]
    headers_hide: Option<String>,
    /// Multipart MIME type handler (format: type=command, repeatable)
    #[arg(long = "multipart-handle")]
    multipart_handle: Vec<String>,
    /// Show raw email content without any header filtering or MIME processing
    #[arg(long, action = clap::ArgAction::SetTrue)]
    raw: bool,
    /// Multipart type preference pairs (format: preferred,fallback, repeatable)
    #[arg(long = "multipart-preference")]
    multipart_preference: Vec<String>,
    /// Disable multipart type preference, show all parts
    #[arg(long = "no-multipart-preference", action = clap::ArgAction::SetTrue)]
    no_multipart_preference: bool,
    /// Disable colored output
    #[arg(long = "no-color", action = clap::ArgAction::SetTrue)]
    no_color: bool,
    /// Force colored output even when piped
    #[arg(long = "force-color", action = clap::ArgAction::SetTrue)]
    force_color: bool,
    /// Color for header keys (bgcolor,fgcolor,modifier)
    #[arg(long)]
    color_header_key: Option<String>,
    /// Color for header values (bgcolor,fgcolor,modifier)
    #[arg(long)]
    color_header_value: Option<String>,
    /// Color for part separators (bgcolor,fgcolor,modifier)
    #[arg(long)]
    color_part_separator: Option<String>,
    /// Color for handler info messages (bgcolor,fgcolor,modifier)
    #[arg(long)]
    color_handler_info: Option<String>,
    /// Color for handler stderr messages on success (bgcolor,fgcolor,modifier)
    #[arg(long)]
    color_handler_error: Option<String>,
    /// Wrap output width (0 = no wrap, default: 100)
    #[arg(long)]
    wrap: Option<usize>,
}

#[derive(clap::Args)]
struct CatCliArgs {
    /// Remove the email signature from output (from the --  delimiter) (default: false)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    hide_signature: bool,
    /// Collapse consecutive citation lines (> ...) into a single marker (default: false)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    collapse_citation: bool,
    /// Color regex pairs: spec,pattern (repeatable, format: bg,fg,modifier regex)
    #[arg(long = "color-regex", number_of_values = 2)]
    color_regex: Vec<String>,
    /// Disable colored output
    #[arg(long = "no-color", action = clap::ArgAction::SetTrue)]
    no_color: bool,
    /// Force colored output even when piped
    #[arg(long = "force-color", action = clap::ArgAction::SetTrue)]
    force_color: bool,
}

#[derive(clap::Args)]
struct ComposeCliArgs {
    /// Maildir to scan for autocompletion contacts (default: data dir)
    #[arg(short = 'd', long = "maildir-path")]
    maildir_path: Option<String>,
    /// Recipient email address (prompts if omitted)
    #[arg(short = 't', long)]
    to: Option<String>,
    /// Sender email address (prompts if omitted)
    #[arg(short = 'f', long)]
    from: Option<String>,
    /// Email subject (prompts if omitted)
    #[arg(short = 's', long)]
    subject: Option<String>,
    /// Directory for draft emails (default: <data_dir>/drafts)
    #[arg(long = "drafts-path")]
    drafts_path: Option<String>,
    /// Omit headers from the temporary editor file (headers are still added to the saved draft)
    #[arg(long = "no-include-headers", action = clap::ArgAction::SetTrue)]
    no_include_headers: bool,
    /// Recover the last draft and continue editing
    #[arg(long = "recover-last-draft", action = clap::ArgAction::SetTrue)]
    recover_last_draft: bool,
    /// Binary to run before composing (receives temp eml path), repeatable
    #[arg(long = "pre-compose-hook")]
    pre_compose_hook: Vec<String>,
    /// Binary to run after composing and before saving (receives temp eml path), repeatable
    #[arg(long = "post-compose-hook")]
    post_compose_hook: Vec<String>,
    /// Path to an EML template file used as the initial draft. Its To/From/Subject
    /// and Message-ID headers are replaced; other headers are kept
    #[arg(long)]
    template: Option<String>,
    /// Full message content taken directly from the command line (no editor).
    /// Headers in the message are mixed with the automatic ones. Mutually
    /// exclusive with --template; if --template is set in config it is ignored
    #[arg(long)]
    message: Option<String>,
}

#[derive(clap::Args)]
struct FindCliArgs {
    /// Regex matched against the whole raw message (headers and body)
    pattern: Option<String>,
    /// Path to Maildir directory (defaults to XDG data dir)
    #[arg(short = 'd', long)]
    maildir_path: Option<String>,
    /// Sub-folder to search (a maildir under the data directory)
    #[arg(short = 'F', long)]
    folder: Option<String>,
    /// Match a specific header value with a regex (NAME=REGEX, repeatable)
    #[arg(short = 'H', long)]
    header: Vec<String>,
    /// Match the decoded text body with a regex
    #[arg(short = 'b', long)]
    body: Option<String>,
    /// Only emails on or after this date (inclusive)
    #[arg(long)]
    since: Option<String>,
    /// Only emails on or before this date (inclusive)
    #[arg(long)]
    until: Option<String>,
    /// Maximum number of emails to display (default: 25)
    #[arg(long)]
    limit: Option<usize>,
    /// Number of emails to skip before displaying (default: 0)
    #[arg(long)]
    offset: Option<usize>,
    /// Output format: table, json, table-raw, tsv (default: table)
    #[arg(long)]
    format: Option<String>,
    /// Table fields: comma-separated field names, each optionally suffixed with :width (e.g. subject:40, from:30)
    #[arg(long)]
    table_fields: Option<String>,
    /// Character(s) for the new/unread flag (default: N)
    #[arg(long)]
    flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    #[arg(long)]
    flag_attachment: Option<String>,
    /// Character(s) for the reply flag (default: R)
    #[arg(long)]
    flag_reply: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    #[arg(long)]
    flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    #[arg(long)]
    flag_signed: Option<String>,
    /// Character(s) for the tag flag (default: T)
    #[arg(long)]
    flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    #[arg(long)]
    date_format: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    #[arg(long)]
    order_by: Option<String>,
    /// Disable reply threading (show emails in strict global order)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    no_thread: bool,
    /// Only match emails carrying this label (as set by `fem tag`)
    #[arg(long)]
    label: Option<String>,
}

#[derive(clap::Args)]
struct TagCliArgs {
    /// Email ID (1-based, as shown in fem list)
    id: usize,
    /// Label to attach to the email (required)
    #[arg(long)]
    label: Option<String>,
    /// Path to Maildir directory (defaults to XDG data dir)
    #[arg(short = 'd', long)]
    maildir_path: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    #[arg(long)]
    order_by: Option<String>,
    /// Disable reply threading (show emails in strict global order)
    #[arg(long, action = clap::ArgAction::SetTrue)]
    no_thread: bool,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    let config = fem::config::load_config()?;
    let data_dir = fem::config::data_dir()?;

    match cli.command {
        Commands::Pull(ca) => {
            let args = fem::pull::PullArgs {
                server: ca.server,
                port: ca.port,
                username: ca.username,
                password: ca.password,
                password_command: ca.password_command,
                mailbox: ca.mailbox,
                ssl: ca.ssl,
                all: ca.all,
                pre_hook: ca.pre_hook,
                post_hook: ca.post_hook,
            };
            fem::pull::run(config.pull, args, data_dir).await
        }
        Commands::Push(ca) => {
            let args = fem::push::PushArgs {
                server: ca.server,
                port: ca.port,
                username: ca.username,
                password: ca.password,
                password_command: ca.password_command,
                ssl: ca.ssl,
                starttls: if ca.starttls { Some(true) } else { None },
                drafts_path: ca.drafts_path,
                all_drafts: ca.all_drafts,
                last_draft: ca.last_draft,
            };
            fem::push::run(config.push, args, data_dir).await
        }
        Commands::List(ca) => {
            let args = fem::list::ListArgs {
                maildir_path: ca.maildir_path,
                limit: ca.limit,
                offset: ca.offset,
                format: ca.format,
                table_fields: ca.table_fields,
                flag_new: ca.flag_new,
                flag_attachment: ca.flag_attachment,
                flag_encrypted: ca.flag_encrypted,
                flag_signed: ca.flag_signed,
                flag_reply: ca.flag_reply,
                flag_tagged: ca.flag_tagged,
                date_format: ca.date_format,
                order_by: ca.order_by,
                no_thread: ca.no_thread,
            };
            fem::list::run(config.list, args, data_dir)
        }
        Commands::Show(ca) => {
            let args = fem::show::ShowArgs {
                id: ca.id,
                maildir_path: ca.maildir_path,
                order_by: ca.order_by,
                no_thread: ca.no_thread,
                flag_new: ca.flag_new,
                flag_attachment: ca.flag_attachment,
                flag_encrypted: ca.flag_encrypted,
                flag_signed: ca.flag_signed,
                flag_reply: ca.flag_reply,
                flag_tagged: ca.flag_tagged,
                date_format: ca.date_format,
                headers_show: ca.headers_show,
                headers_hide: ca.headers_hide,
                multipart_handle: ca.multipart_handle,
                raw: ca.raw,
                multipart_preference: ca.multipart_preference,
                no_multipart_preference: ca.no_multipart_preference,
                no_color: ca.no_color,
                force_color: ca.force_color,
                color_header_key: ca.color_header_key,
                color_header_value: ca.color_header_value,
                color_part_separator: ca.color_part_separator,
                color_handler_info: ca.color_handler_info,
                color_handler_error: ca.color_handler_error,
                wrap: ca.wrap,
            };
            fem::show::run(config.show, args, data_dir)
        }
        Commands::Cat(ca) => {
            use std::io::{self, Read, Write};
            let hide_sig = ca.hide_signature || config.cat.hide_signature.unwrap_or(false);
            let collapse = ca.collapse_citation || config.cat.collapse_citation.unwrap_or(false);
            let mut input = String::new();
            io::stdin().read_to_string(&mut input)?;

            let color_pairs = if !ca.color_regex.is_empty() {
                ca.color_regex.chunks(2).map(|c| (c[0].clone(), c[1].clone())).collect::<Vec<_>>()
            } else if let Some(ref cfg_pairs) = config.cat.color_regex {
                cfg_pairs.chunks(2).map(|c| (c[0].clone(), c[1].clone())).collect::<Vec<_>>()
            } else {
                fem::cat::default_color_pairs()
            };

            let no_color = ca.no_color || config.cat.no_color.unwrap_or(false);
            let force_color = ca.force_color || config.cat.force_color.unwrap_or(false);
            let use_color = !no_color && (force_color || std::io::stdout().is_terminal());

            let output = fem::cat::process(&input, hide_sig, collapse, &color_pairs, use_color);
            io::stdout().write_all(output.as_bytes())?;
            io::stdout().flush()?;
            Ok(())
        }
        Commands::Compose(ca) => {
            let args = fem::compose::ComposeArgs {
                maildir_path: ca.maildir_path,
                to: ca.to,
                from: ca.from,
                subject: ca.subject,
                drafts_path: ca.drafts_path,
                no_include_headers: ca.no_include_headers,
                recover_last_draft: ca.recover_last_draft,
                pre_compose_hook: ca.pre_compose_hook,
                post_compose_hook: ca.post_compose_hook,
                template: ca.template,
                message: ca.message,
            };
            fem::compose::run(config.compose, args, data_dir)
        }
        Commands::Find(ca) => {
            let args = fem::find::FindArgs {
                pattern: ca.pattern,
                maildir_path: ca.maildir_path,
                folder: ca.folder,
                header: ca.header,
                body: ca.body,
                since: ca.since,
                until: ca.until,
                limit: ca.limit,
                offset: ca.offset,
                format: ca.format,
                table_fields: ca.table_fields,
                flag_new: ca.flag_new,
                flag_attachment: ca.flag_attachment,
                flag_encrypted: ca.flag_encrypted,
                flag_signed: ca.flag_signed,
                flag_reply: ca.flag_reply,
                flag_tagged: ca.flag_tagged,
                date_format: ca.date_format,
                order_by: ca.order_by,
                no_thread: ca.no_thread,
                label: ca.label,
            };
            fem::find::run(config.find, args, data_dir)
        }
        Commands::Tag(ca) => {
            let args = fem::tag::TagArgs {
                id: ca.id,
                label: ca.label,
                maildir_path: ca.maildir_path,
                order_by: ca.order_by,
                no_thread: ca.no_thread,
            };
            let (path, added) = fem::tag::run(config.tag, args, data_dir)?;
            if added {
                eprintln!("Tagged {}", path.display());
            } else {
                eprintln!("Message already tagged: {}", path.display());
            }
            Ok(())
        }
    }
}
