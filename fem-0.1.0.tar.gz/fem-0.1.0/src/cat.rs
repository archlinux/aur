//! Read email text from stdin and write processed text to stdout.
//!
//! `fem cat` behaves like `cat`, applying optional text transformations:
//! hiding the signature block (from the `-- ` delimiter), collapsing runs of
//! consecutive quoted lines into a single marker, and coloring lines matching
//! a list of regexes. It is also the default handler for `text/plain` parts in
//! `fem show`.

use regex::{Regex, RegexBuilder};

/// Apply `fem cat` text processing and return the transformed output.
///
/// The transformations are applied in this order: citation collapsing, then
/// signature hiding, then regex coloring (only when `use_color` is true and
/// `color_pairs` is non-empty). Each pair in `color_pairs` is
/// `(spec, pattern)` where `spec` is `bgcolor,fgcolor,modifier`.
pub fn process(
    input: &str,
    hide_sig: bool,
    collapse_citation: bool,
    color_pairs: &[(String, String)],
    use_color: bool,
) -> String {
    let mut output = input.to_string();

    if collapse_citation {
        output = collapse_citations(&output);
    }

    if hide_sig {
        output = hide_signature(&output);
    }

    if use_color && !color_pairs.is_empty() {
        output = apply_color(&output, color_pairs);
    }

    output
}

/// Collapse consecutive quoted (`> ...`) lines into a single marker.
fn collapse_citations(input: &str) -> String {
    let crlf = input.contains("\r\n");
    let sep = if crlf { "\r\n" } else { "\n" };
    let lines: Vec<&str> = input.split(sep).collect();
    let mut result: Vec<String> = Vec::with_capacity(lines.len());
    let mut pending: Vec<&str> = Vec::new();
    for line in &lines {
        if line.starts_with('>') {
            pending.push(line);
        } else {
            flush_citation(&mut pending, &mut result);
            result.push(line.to_string());
        }
    }
    flush_citation(&mut pending, &mut result);
    result.join(sep)
}

/// Emit the buffered quoted lines into `result` (a single line stays as-is,
/// multiple lines collapse to a marker).
fn flush_citation(pending: &mut Vec<&str>, result: &mut Vec<String>) {
    match pending.len() {
        0 => {}
        1 => result.push(pending[0].to_string()),
        _ => result.push("> [previous message]".to_string()),
    }
    pending.clear();
}

/// Truncate `input` at the signature delimiter (`-- `) if present.
fn hide_signature(input: &str) -> String {
    let sig_pos = input.find("\r\n-- \r\n").or_else(|| input.find("\n-- \n"));
    match sig_pos {
        Some(pos) => input[..pos].to_string(),
        None => input.to_string(),
    }
}

/// Wrap every regex match in ANSI color codes, working from the end backwards
/// so earlier replacements do not shift later match offsets.
fn apply_color(input: &str, color_pairs: &[(String, String)]) -> String {
    let rst = "\x1b[0m";
    let ansi_pairs: Vec<(String, Regex)> = color_pairs
        .iter()
        .filter_map(|(spec, pat)| {
            let parts: Vec<&str> = spec.splitn(3, ',').collect();
            let bg = parts.first().and_then(|p| p.trim().parse::<u8>().ok());
            let fg = parts.get(1).and_then(|p| p.trim().parse::<u8>().ok());
            let modifier = parts.get(2).unwrap_or(&"").trim().to_lowercase();
            let mut ansi = String::new();
            if let Some(b) = bg {
                ansi.push_str(&format!("\x1b[48;5;{}m", b));
            }
            if let Some(f) = fg {
                ansi.push_str(&format!("\x1b[38;5;{}m", f));
            }
            match modifier.as_str() {
                "bold" => ansi.push_str("\x1b[1m"),
                "blink" => ansi.push_str("\x1b[5m"),
                "underline" => ansi.push_str("\x1b[4m"),
                "reverse" => ansi.push_str("\x1b[7m"),
                _ => {}
            }
            RegexBuilder::new(pat).multi_line(true).build().ok().map(|re| (ansi, re))
        })
        .collect();

    let mut matches: Vec<(usize, usize, &str)> = Vec::new();
    for (ansi, re) in &ansi_pairs {
        for m in re.find_iter(input) {
            matches.push((m.start(), m.end(), ansi));
        }
    }
    matches.sort_by(|a, b| b.0.cmp(&a.0));

    let mut result = input.to_string();
    for (start, end, ansi) in &matches {
        let replacement = format!("{}{}{}", ansi, &result[*start..*end], rst);
        result.replace_range(*start..*end, &replacement);
    }
    result
}

/// The built-in default color pairs used when the user provides none.
pub fn default_color_pairs() -> Vec<(String, String)> {
    vec![
        (",244,".to_string(), r"^-- \r?\n(?:[^\r\n]+\r?\n)*|^-- [^\n]*$".to_string()),
        (",244,".to_string(), r"^( {0,4}[>|:#%]| {0,4}[a-zA-Z0-9]+[>|]+)+.*$".to_string()),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn collapse_citations_lf() {
        let input = "hello\n> one\n> two\n> three\nworld\n";
        assert_eq!(collapse_citations(input), "hello\n> [previous message]\nworld\n");
    }

    #[test]
    fn collapse_citations_crlf() {
        let input = "hello\r\n> one\r\n> two\r\nworld\r\n";
        assert_eq!(collapse_citations(input), "hello\r\n> [previous message]\r\nworld\r\n");
    }

    #[test]
    fn collapse_citations_single_quote_stays() {
        let input = "a\n> single\nb\n";
        assert_eq!(collapse_citations(input), "a\n> single\nb\n");
    }

    #[test]
    fn collapse_citations_trailing_run() {
        let input = "a\n> one\n> two\n";
        assert_eq!(collapse_citations(input), "a\n> [previous message]\n");
    }

    #[test]
    fn hide_signature_lf() {
        let input = "hello\n-- \nsignature lines\n";
        assert_eq!(hide_signature(input), "hello");
    }

    #[test]
    fn hide_signature_crlf() {
        let input = "hello\r\n-- \r\nsig\r\n";
        assert_eq!(hide_signature(input), "hello");
    }

    #[test]
    fn hide_signature_absent_keeps_input() {
        let input = "hello\nworld\n";
        assert_eq!(hide_signature(input), input);
    }

    #[test]
    fn apply_color_wraps_matches() {
        let pairs = vec![(",244,".to_string(), r"^-- .*$".to_string())];
        let out = apply_color("before\n-- signature\n", &pairs);
        assert!(out.contains("\x1b[38;5;244m-- signature\x1b[0m"), "{out:?}");
        assert!(out.contains("before\n"), "{out:?}");
    }

    #[test]
    fn apply_color_skips_invalid_specs() {
        let pairs = vec![("not-a-spec".to_string(), "(".to_string())];
        assert_eq!(apply_color("hello\n", &pairs), "hello\n");
    }

    #[test]
    fn process_no_options_passthrough() {
        let input = "To: a@x\n\nbody\n";
        assert_eq!(process(input, false, false, &[], false), input);
    }

    #[test]
    fn process_default_pairs_color_quotes_only_when_enabled() {
        let input = "> quoted line\nplain\n";
        let colored = process(input, false, false, &default_color_pairs(), true);
        assert!(colored.contains('\x1b'), "coloring must be applied when enabled: {colored:?}");

        let plain = process(input, false, false, &default_color_pairs(), false);
        assert_eq!(plain, input, "no color when disabled");
    }

    #[test]
    fn process_hides_signature() {
        let input = "body\n-- \nsig\n";
        let out = process(input, true, false, &[], false);
        assert_eq!(out, "body");
    }
}
