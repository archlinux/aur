//! Search local Maildir emails by header, body text, or date range.
//!
//! The `find` command scans a Maildir (optionally restricted to a single folder)
//! and returns the matching emails as a formatted table — the same rendering
//! used by `list`. All criteria are combined with AND: an email matches only
//! when it satisfies every given constraint.
//!
//! # Search Criteria
//!
//! - **Pattern** (the positional `PATTERN` argument): a regex matched against
//!   the raw message, headers and body included.
//! - **`--header NAME=REGEX`**: a regex matched against the values of a single
//!   header (header name matching is case-insensitive). Repeatable; each header
//!   criterion must be satisfied.
//! - **`--body REGEX`**: a regex matched against the decoded text parts of the
//!   message. Transfer encoding (base64/quoted-printable) and common charsets
//!   are decoded before matching.
//! - **`--since DATE` / `--until DATE`**: inclusive bounds on the `Date` header.
//!   Date-only values (`2026-01-15`) mean the start of that day for `--since`
//!   and the end of that day for `--until`.
//!
//! Regexes are Rust `regex` patterns; they are case-sensitive unless prefixed
//! with `(?i)`.
//!
//! # Efficiency
//!
//! Each message file is read and parsed exactly once. Header- and date-only
//! searches (no `PATTERN`, no `--body`) read just the header block of each
//! message instead of the whole file, and the decoded body is only materialized
//! when a `--body` criterion is present. The scan is parallelized across the
//! available CPU cores, and with `--no-thread` only the best
//! `offset + limit` matches are retained, so memory and sort cost scale with
//! the page size instead of the number of matches.

use crate::config::FindConfig;
use crate::list::{self, Field, OrderBy};
use crate::maildir::Maildir;
use anyhow::Context;
use chrono::{DateTime, FixedOffset, NaiveDate, NaiveDateTime, NaiveTime};
use regex::Regex;
use std::cmp::Ordering;
use std::collections::BinaryHeap;
use std::io::BufRead;
use std::path::{Path, PathBuf};

const DEFAULT_TABLE_FIELDS: &str = "number,flags,date,from,subject";

/// A compiled set of search criteria.
pub(crate) struct SearchQuery {
    pattern: Option<Regex>,
    body: Option<Regex>,
    headers: Vec<(String, Regex)>,
    since: Option<DateTime<FixedOffset>>,
    until: Option<DateTime<FixedOffset>>,
    /// Absolute paths of messages carrying the requested `--label`, when set.
    tagged_paths: Option<std::collections::HashSet<PathBuf>>,
    /// Absolute paths of all messages carrying any label (drives the T flag).
    all_tagged: std::collections::HashSet<PathBuf>,
}

/// Command-line arguments for the find subcommand.
#[derive(Default)]
pub struct FindArgs {
    pub pattern: Option<String>,
    pub maildir_path: Option<String>,
    pub folder: Option<String>,
    pub header: Vec<String>,
    pub body: Option<String>,
    pub since: Option<String>,
    pub until: Option<String>,
    pub limit: Option<usize>,
    pub offset: Option<usize>,
    pub format: Option<String>,
    pub table_fields: Option<String>,
    pub flag_new: Option<String>,
    pub flag_attachment: Option<String>,
    pub flag_encrypted: Option<String>,
    pub flag_signed: Option<String>,
    pub flag_reply: Option<String>,
    pub flag_tagged: Option<String>,
    pub date_format: Option<String>,
    pub order_by: Option<String>,
    pub no_thread: bool,
    pub label: Option<String>,
}

impl From<FindArgs> for FindConfig {
    fn from(args: FindArgs) -> Self {
        FindConfig {
            maildir_path: args.maildir_path,
            folder: args.folder,
            pattern: args.pattern,
            header: if args.header.is_empty() {
                None
            } else {
                Some(args.header)
            },
            body: args.body,
            since: args.since,
            until: args.until,
            limit: args.limit,
            offset: args.offset,
            format: args.format,
            table_fields: args.table_fields,
            flag_new: args.flag_new,
            flag_attachment: args.flag_attachment,
            flag_encrypted: args.flag_encrypted,
            flag_signed: args.flag_signed,
            flag_reply: args.flag_reply,
            flag_tagged: args.flag_tagged,
            date_format: args.date_format,
            order_by: args.order_by,
            no_thread: if args.no_thread { Some(true) } else { None },
            label: args.label,
        }
    }
}

fn merge_config(config: FindConfig, args: FindArgs) -> FindConfig {
    let args_cfg: FindConfig = args.into();
    FindConfig {
        maildir_path: args_cfg.maildir_path.or(config.maildir_path),
        folder: args_cfg.folder.or(config.folder),
        pattern: args_cfg.pattern.or(config.pattern),
        header: args_cfg.header.or(config.header),
        body: args_cfg.body.or(config.body),
        since: args_cfg.since.or(config.since),
        until: args_cfg.until.or(config.until),
        limit: args_cfg.limit.or(config.limit),
        offset: args_cfg.offset.or(config.offset),
        format: args_cfg.format.or(config.format),
        table_fields: args_cfg.table_fields.or(config.table_fields),
        flag_new: args_cfg.flag_new.or(config.flag_new),
        flag_attachment: args_cfg.flag_attachment.or(config.flag_attachment),
        flag_encrypted: args_cfg.flag_encrypted.or(config.flag_encrypted),
        flag_signed: args_cfg.flag_signed.or(config.flag_signed),
        flag_reply: args_cfg.flag_reply.or(config.flag_reply),
        flag_tagged: args_cfg.flag_tagged.or(config.flag_tagged),
        date_format: args_cfg.date_format.or(config.date_format),
        order_by: args_cfg.order_by.or(config.order_by),
        no_thread: args_cfg.no_thread.or(config.no_thread),
        label: args_cfg.label.or(config.label),
    }
}

/// Split a `NAME=REGEX` header criterion into its two parts.
fn split_header_criterion(s: &str) -> Option<(String, &str)> {
    let eq = s.find('=')?;
    let name = s[..eq].trim();
    let re = s[eq + 1..].trim();
    if name.is_empty() || re.is_empty() {
        return None;
    }
    Some((name.to_string(), re))
}

/// Parse a date bound. Date-only values resolve to the start of the day when
/// `end_of_day` is false and to the end of the day when it is true.
fn parse_date_boundary(s: &str, end_of_day: bool) -> Option<DateTime<FixedOffset>> {
    let s = s.trim();
    if let Ok(dt) = DateTime::parse_from_rfc3339(s) {
        return Some(dt);
    }
    if let Ok(dt) = DateTime::parse_from_rfc2822(s) {
        return Some(dt);
    }
    for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S"] {
        if let Ok(ndt) = NaiveDateTime::parse_from_str(s, fmt) {
            return Some(DateTime::from_naive_utc_and_offset(
                ndt,
                FixedOffset::east_opt(0)?,
            ));
        }
    }
    if let Ok(nd) = NaiveDate::parse_from_str(s, "%Y-%m-%d") {
        let time = if end_of_day {
            NaiveTime::from_hms_opt(23, 59, 59)?
        } else {
            NaiveTime::from_hms_opt(0, 0, 0)?
        };
        return Some(DateTime::from_naive_utc_and_offset(
            nd.and_time(time),
            FixedOffset::east_opt(0)?,
        ));
    }
    None
}

fn compile_regex(s: &str, what: &str) -> anyhow::Result<Regex> {
    Regex::new(s).map_err(|e| anyhow::anyhow!("invalid {what} regex `{s}`: {e}"))
}

fn build_query(cfg: &FindConfig) -> anyhow::Result<SearchQuery> {
    let pattern = cfg
        .pattern
        .as_deref()
        .map(|s| compile_regex(s, "search pattern"))
        .transpose()?;
    let body = cfg
        .body
        .as_deref()
        .map(|s| compile_regex(s, "--body"))
        .transpose()?;
    let mut headers = Vec::new();
    if let Some(entries) = &cfg.header {
        for entry in entries {
            let (name, re_str) = split_header_criterion(entry).ok_or_else(|| {
                anyhow::anyhow!("invalid --header criterion `{entry}`: expected NAME=REGEX")
            })?;
            headers.push((name, compile_regex(re_str, "--header")?));
        }
    }
    let since = match &cfg.since {
        Some(s) => Some(parse_date_boundary(s, false).ok_or_else(|| {
            anyhow::anyhow!("invalid --since date `{s}` (expected YYYY-MM-DD, RFC 2822, or RFC 3339)")
        })?),
        None => None,
    };
    let until = match &cfg.until {
        Some(s) => Some(parse_date_boundary(s, true).ok_or_else(|| {
            anyhow::anyhow!("invalid --until date `{s}` (expected YYYY-MM-DD, RFC 2822, or RFC 3339)")
        })?),
        None => None,
    };
    if let (Some(since), Some(until)) = (since, until) {
        if since > until {
            anyhow::bail!("--since date must not be after --until date");
        }
    }
    Ok(SearchQuery {
        pattern,
        body,
        headers,
        since,
        until,
        tagged_paths: None,
        all_tagged: std::collections::HashSet::new(),
    })
}

/// Decode a MIME part body, honoring its transfer encoding and charset.
fn decode_part_body(part: &mailparse::ParsedMail) -> anyhow::Result<String> {
    if let Ok(body) = part.get_body() {
        return Ok(body);
    }
    let raw = part.get_body_raw().context("failed to decode MIME part body")?;
    let charset = part.ctype.params.get("charset").map(|s| s.as_str());
    match charset {
        Some(ch) if !ch.eq_ignore_ascii_case("utf-8") && !ch.eq_ignore_ascii_case("us-ascii") => {
            if let Some(enc) = encoding_rs::Encoding::for_label(ch.as_bytes()) {
                match enc.decode_without_bom_handling_and_without_replacement(&raw) {
                    Some(cow) => Ok(cow.into_owned()),
                    None => {
                        let (cow, _, _) = enc.decode(&raw);
                        Ok(cow.into_owned())
                    }
                }
            } else {
                Ok(String::from_utf8_lossy(&raw).into_owned())
            }
        }
        _ => Ok(String::from_utf8_lossy(&raw).into_owned()),
    }
}

/// Collect the decoded bodies of all `text/*` leaf parts, joined by newlines.
fn decode_text_bodies(part: &mailparse::ParsedMail) -> String {
    let mut out = String::new();
    collect_text_bodies(part, &mut out);
    out
}

fn collect_text_bodies(part: &mailparse::ParsedMail, out: &mut String) {
    if part.subparts.is_empty() {
        if part.ctype.mimetype.to_lowercase().starts_with("text/") {
            if let Ok(body) = decode_part_body(part) {
                if !out.is_empty() {
                    out.push('\n');
                }
                out.push_str(&body);
            }
        }
        return;
    }
    for sub in &part.subparts {
        collect_text_bodies(sub, out);
    }
}

fn email_datetime(parsed: &mailparse::ParsedMail) -> Option<DateTime<FixedOffset>> {
    let raw = list::header_value(&parsed.headers, "Date").unwrap_or_default();
    DateTime::parse_from_rfc2822(&raw).ok()
}

/// Upper bound for a header block read in bytes. Real-world mail headers are
/// well under this; a larger block means a full read fallback.
const MAX_HEADER_BLOCK: usize = 64 * 1024;

/// Read just the header block of a message: everything up to and including the
/// first blank line, capped at [`MAX_HEADER_BLOCK`] bytes.
///
/// Returns `Ok(None)` when the header block exceeds the cap (the caller falls
/// back to a full read) and `Ok(Some(vec![]))` for an empty file.
pub(crate) fn read_header_block(path: &Path) -> std::io::Result<Option<Vec<u8>>> {
    let file = std::fs::File::open(path)?;
    let mut reader = std::io::BufReader::with_capacity(8192, file);
    let mut buf: Vec<u8> = Vec::with_capacity(4096);
    loop {
        let available = reader.fill_buf()?;
        if available.is_empty() {
            return Ok(Some(buf));
        }
        let take = available.len().min(MAX_HEADER_BLOCK - buf.len());
        buf.extend_from_slice(&available[..take]);
        reader.consume(take);
        if let Some(pos) = find_header_terminator(&buf) {
            buf.truncate(pos + 1);
            return Ok(Some(buf));
        }
        if buf.len() >= MAX_HEADER_BLOCK {
            return Ok(None);
        }
    }
}

/// Locate the first blank line — LF or CRLF terminated — in a header block.
fn find_header_terminator(chunk: &[u8]) -> Option<usize> {
    chunk
        .windows(2)
        .position(|w| w == b"\n\n")
        .or_else(|| chunk.windows(3).position(|w| w == b"\n\r\n"))
}

fn matches_query(parsed: &mailparse::ParsedMail, content: &[u8], query: &SearchQuery) -> bool {
    if let Some(re) = &query.pattern {
        let raw = String::from_utf8_lossy(content);
        if !re.is_match(&raw) {
            return false;
        }
    }
    for (name, re) in &query.headers {
        let matched = parsed
            .headers
            .iter()
            .any(|h| h.get_key().eq_ignore_ascii_case(name) && re.is_match(&h.get_value()));
        if !matched {
            return false;
        }
    }
    if let Some(re) = &query.body {
        if !re.is_match(&decode_text_bodies(parsed)) {
            return false;
        }
    }
    if query.since.is_some() || query.until.is_some() {
        let Some(dt) = email_datetime(parsed) else {
            return false;
        };
        if let Some(since) = query.since {
            if dt < since {
                return false;
            }
        }
        if let Some(until) = query.until {
            if dt > until {
                return false;
            }
        }
    }
    true
}

/// Resolve the directory to search: an explicit folder, or the maildir root.
fn resolve_search_path(maildir_path: PathBuf, folder: Option<&str>) -> PathBuf {
    match folder {
        Some(f) if !f.is_empty() => {
            let folder_path = PathBuf::from(f);
            if folder_path.is_absolute() {
                folder_path
            } else {
                maildir_path.join(folder_path)
            }
        }
        _ => maildir_path,
    }
}

/// A bounded heap entry ordered by the search order: the heap root (the
/// maximum) is the *worst* kept item — the candidate that sorts last — so it
/// is the one replaced when a better match arrives.
struct HeapItem {
    info: list::EmailInfo,
    order: OrderBy,
}

impl PartialEq for HeapItem {
    fn eq(&self, other: &Self) -> bool {
        list::cmp_infos(&self.info, &other.info, &self.order).is_eq()
    }
}

impl Eq for HeapItem {}

impl PartialOrd for HeapItem {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for HeapItem {
    fn cmp(&self, other: &Self) -> Ordering {
        list::cmp_infos(&self.info, &other.info, &self.order)
    }
}

/// Keep only the `keep` best candidates (by the search order) from a set of
/// match batches. With `keep == usize::MAX` all candidates are returned.
///
/// Each batch may already hold up to `keep` candidates (each worker prunes its
/// own chunk), so this runs in `O(batches * keep)` total rather than
/// `O(K log K)`, using `O(keep)` memory.
fn merge_top_k(
    parts: Vec<Vec<list::EmailInfo>>,
    keep: usize,
    order_by: &OrderBy,
) -> Vec<list::EmailInfo> {
    if keep == usize::MAX {
        return parts.into_iter().flatten().collect();
    }
    let mut heap: BinaryHeap<HeapItem> = BinaryHeap::new();
    for part in parts {
        for info in part {
            if heap.len() < keep {
                heap.push(HeapItem { info, order: *order_by });
            } else if let Some(worst) = heap.peek() {
                if list::cmp_infos(&info, &worst.info, order_by) == Ordering::Less {
                    heap.pop();
                    heap.push(HeapItem { info, order: *order_by });
                }
            }
        }
    }
    heap.into_iter().map(|h| h.info).collect()
}

/// Scan one chunk of message paths and return their `EmailInfo`s, pruned to
/// the `keep` best when bounded.
fn process_chunk(
    chunk: &[PathBuf],
    query: &SearchQuery,
    ctx: &list::DisplayCtx,
    extract_thread_refs: bool,
    keep: usize,
    order_by: &OrderBy,
) -> Vec<list::EmailInfo> {
    let mut local: Vec<list::EmailInfo> = Vec::new();
    for path in chunk {
        if let Some(info) = process_one(path, query, ctx, extract_thread_refs) {
            local.push(info);
        }
    }
    if keep == usize::MAX || local.len() <= keep {
        local
    } else {
        merge_top_k(vec![local], keep, order_by)
    }
}

/// Read, parse, and match a single message, returning its display info when it
/// matches the query.
///
/// When the query has no whole-message `PATTERN` and no `--body` criterion,
/// only the header block is read. Multipart messages still fall back to a full
/// read so attachment/encryption flags stay accurate.
fn process_one(
    path: &Path,
    query: &SearchQuery,
    ctx: &list::DisplayCtx,
    extract_thread_refs: bool,
) -> Option<list::EmailInfo> {
    if let Some(tagged) = &query.tagged_paths {
        if !tagged.contains(path) {
            return None;
        }
    }
    let is_tagged = query.all_tagged.contains(path);
    if query.pattern.is_none() && query.body.is_none() {
        if let Some(block) = read_header_block(path).ok().flatten() {
            if let Ok(parsed) = mailparse::parse_mail(&block) {
                if !parsed.ctype.mimetype.starts_with("multipart/") {
                    if !matches_query(&parsed, &block, query) {
                        return None;
                    }
                    let size = std::fs::metadata(path).map(|m| m.len()).unwrap_or(0);
                    return Some(list::email_info_from_parsed(
                        &parsed,
                        path,
                        ctx,
                        size,
                        extract_thread_refs,
                        is_tagged,
                    ));
                }
            }
        }
    }
    let content = std::fs::read(path).ok()?;
    let parsed = mailparse::parse_mail(&content).ok()?;
    if !matches_query(&parsed, &content, query) {
        return None;
    }
    let size = content.len() as u64;
    Some(list::email_info_from_parsed(
        &parsed,
        path,
        ctx,
        size,
        extract_thread_refs,
        is_tagged,
    ))
}

/// Search a Maildir (or folder) and return matching emails sorted by
/// `order_by`, threaded unless `no_thread` is set.
///
/// The scan is parallelized across the available CPU cores. When `no_thread`
/// is set and `keep` is not `usize::MAX`, only the `keep` best matches are
/// retained (a bounded top-K selection), so memory and sort cost scale with
/// `keep` rather than the total number of matches.
pub(crate) fn search_infos(
    maildir_path: &Path,
    query: &SearchQuery,
    ctx: &list::DisplayCtx,
    order_by: &OrderBy,
    no_thread: bool,
    keep: usize,
) -> anyhow::Result<Vec<list::EmailInfo>> {
    let maildir = Maildir::new(maildir_path.to_path_buf());
    let messages = maildir.list_messages()?;
    let extract_thread_refs = !no_thread;

    let workers = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .min(messages.len().max(1));

    let parts: Vec<Vec<list::EmailInfo>> = if workers <= 1 {
        vec![process_chunk(
            &messages,
            query,
            ctx,
            extract_thread_refs,
            keep,
            order_by,
        )]
    } else {
        let chunk_size = messages.len().div_ceil(workers);
        std::thread::scope(|scope| {
            messages
                .chunks(chunk_size)
                .map(|chunk| {
                    scope.spawn(move || {
                        process_chunk(chunk, query, ctx, extract_thread_refs, keep, order_by)
                    })
                })
                .collect::<Vec<_>>()
                .into_iter()
                .map(|handle| handle.join().expect("search worker thread panicked"))
                .collect()
        })
    };

    let mut infos = merge_top_k(parts, keep, order_by);
    list::sort_infos(&mut infos, order_by);
    if !no_thread {
        list::thread_emails(&mut infos, order_by);
    }
    Ok(infos)
}

/// Apply `offset`/`limit` pagination to a set of search results.
pub(crate) fn paginate(infos: Vec<list::EmailInfo>, offset: usize, limit: usize) -> Vec<list::EmailInfo> {
    infos.into_iter().skip(offset).take(limit).collect()
}

/// Search a Maildir (or a single folder) for messages matching the query and
/// print the results like `fem list`, according to the merged config and CLI
/// arguments.
pub fn run(config: FindConfig, args: FindArgs, default_data_dir: PathBuf) -> anyhow::Result<()> {
    let cfg = merge_config(config, args);

    let maildir_path = cfg
        .maildir_path
        .clone()
        .map(PathBuf::from)
        .unwrap_or(default_data_dir);
    let search_path = resolve_search_path(maildir_path.clone(), cfg.folder.as_deref());

    let mut query = build_query(&cfg)?;
    let store = crate::tags::TagStore::load(&maildir_path);
    query.all_tagged = store.tagged_paths();
    if let Some(label) = cfg.label.as_deref() {
        query.tagged_paths = Some(store.paths_with(label));
    }

    let flag_new = cfg.flag_new.unwrap_or_else(|| "N".to_string());
    let flag_attachment = cfg.flag_attachment.unwrap_or_else(|| "A".to_string());
    let flag_encrypted = cfg.flag_encrypted.unwrap_or_else(|| "E".to_string());
    let flag_signed = cfg.flag_signed.unwrap_or_else(|| "S".to_string());
    let flag_reply = cfg.flag_reply.unwrap_or_else(|| "R".to_string());
    let flag_tagged = cfg.flag_tagged.unwrap_or_else(|| "T".to_string());
    let date_format = cfg
        .date_format
        .as_deref()
        .unwrap_or(list::DEFAULT_DATE_FORMAT)
        .to_string();
    let order_by = cfg
        .order_by
        .as_deref()
        .and_then(list::parse_order_by)
        .unwrap_or(OrderBy { field: Field::Date, descending: true });
    let no_thread = cfg.no_thread.unwrap_or(false);

    let ctx = list::DisplayCtx {
        flag_new: &flag_new,
        flag_attachment: &flag_attachment,
        flag_encrypted: &flag_encrypted,
        flag_signed: &flag_signed,
        flag_reply: &flag_reply,
        flag_tagged: &flag_tagged,
        date_format: &date_format,
    };

    let offset = cfg.offset.unwrap_or(0);
    let limit = cfg.limit.unwrap_or(25);
    // Without threading, only the best `offset + limit` matches are needed, so
    // the scan keeps a bounded top-K instead of every match.
    let keep = if no_thread {
        offset.saturating_add(limit)
    } else {
        usize::MAX
    };

    let mut infos = search_infos(&search_path, &query, &ctx, &order_by, no_thread, keep)?;

    infos = paginate(infos, offset, limit);
    for (i, info) in infos.iter_mut().enumerate() {
        info.number = offset + i + 1;
    }

    if infos.is_empty() {
        return Ok(());
    }

    let fields = match cfg.table_fields.as_deref() {
        Some(f) if !f.is_empty() => list::parse_fields(f),
        _ => list::parse_fields(DEFAULT_TABLE_FIELDS),
    };
    if fields.is_empty() {
        return Ok(());
    }
    let output_fmt = cfg
        .format
        .as_deref()
        .map(list::parse_output_format)
        .unwrap_or(list::OutputFormat::Table);
    list::render_emails(&fields, output_fmt, &infos);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn build_maildir(dir: &tempfile::TempDir) -> crate::maildir::Maildir {
        let maildir = crate::maildir::Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        maildir
    }

    fn query_from(cfg: &FindConfig) -> SearchQuery {
        build_query(cfg).expect("query should compile")
    }

    #[test]
    fn split_header_criterion_parses_name_and_regex() {
        let (name, re) = split_header_criterion("Subject=^Re:").unwrap();
        assert_eq!(name, "Subject");
        assert_eq!(re, "^Re:");
        let (name, re) = split_header_criterion(" From = @example\\.com ").unwrap();
        assert_eq!(name, "From");
        assert_eq!(re, "@example\\.com");
    }

    #[test]
    fn split_header_criterion_rejects_malformed() {
        assert!(split_header_criterion("no-equals").is_none());
        assert!(split_header_criterion("=value").is_none());
        assert!(split_header_criterion("Name=").is_none());
        assert!(split_header_criterion("").is_none());
    }

    #[test]
    fn parse_date_boundary_date_only_since_and_until() {
        let since = parse_date_boundary("2026-01-15", false).unwrap();
        assert_eq!(since, DateTime::parse_from_rfc3339("2026-01-15T00:00:00Z").unwrap());
        let until = parse_date_boundary("2026-01-15", true).unwrap();
        assert_eq!(until, DateTime::parse_from_rfc3339("2026-01-15T23:59:59Z").unwrap());
    }

    #[test]
    fn parse_date_boundary_datetime_and_rfc_variants() {
        let dt = parse_date_boundary("2026-07-29 12:30:00", false).unwrap();
        assert_eq!(dt, DateTime::parse_from_rfc3339("2026-07-29T12:30:00Z").unwrap());
        let dt = parse_date_boundary("2026-07-29T10:00:00+02:00", false).unwrap();
        assert_eq!(dt, DateTime::parse_from_rfc3339("2026-07-29T10:00:00+02:00").unwrap());
        let dt = parse_date_boundary("Wed, 29 Jul 2026 10:00:00 +0000", false).unwrap();
        assert_eq!(dt, DateTime::parse_from_rfc3339("2026-07-29T10:00:00Z").unwrap());
    }

    #[test]
    fn parse_date_boundary_rejects_invalid() {
        assert!(parse_date_boundary("not a date", false).is_none());
        assert!(parse_date_boundary("", false).is_none());
        assert!(parse_date_boundary("  ", true).is_none());
    }

    #[test]
    fn build_query_parses_all_criteria() {
        let cfg = FindConfig {
            pattern: Some("invoice".to_string()),
            body: Some("urgent".to_string()),
            header: Some(vec![
                "Subject=^Re:".to_string(),
                "From=@example\\.com".to_string(),
            ]),
            since: Some("2026-01-01".to_string()),
            until: Some("2026-12-31".to_string()),
            ..Default::default()
        };
        let q = query_from(&cfg);
        assert!(q.pattern.is_some());
        assert!(q.body.is_some());
        assert_eq!(q.headers.len(), 2);
        assert_eq!(q.headers[0].0, "Subject");
        assert!(q.since.is_some());
        assert!(q.until.is_some());
    }

    #[test]
    fn build_query_rejects_invalid_regex() {
        let cfg = FindConfig {
            body: Some("[unclosed".to_string()),
            ..Default::default()
        };
        assert!(build_query(&cfg).is_err());
    }

    #[test]
    fn build_query_rejects_malformed_header_criterion() {
        let cfg = FindConfig {
            header: Some(vec!["NoEqualsHere".to_string()]),
            ..Default::default()
        };
        assert!(build_query(&cfg).is_err());
    }

    #[test]
    fn build_query_rejects_invalid_date() {
        let cfg = FindConfig {
            since: Some("bogus".to_string()),
            ..Default::default()
        };
        assert!(build_query(&cfg).is_err());
    }

    #[test]
    fn build_query_rejects_since_after_until() {
        let cfg = FindConfig {
            since: Some("2026-12-31".to_string()),
            until: Some("2026-01-01".to_string()),
            ..Default::default()
        };
        assert!(build_query(&cfg).is_err());
    }

    fn matches(parsed: &mailparse::ParsedMail, content: &[u8], q: &SearchQuery) -> bool {
        matches_query(parsed, content, q)
    }

    #[test]
    fn matches_pattern_finds_header_or_body_text() {
        let raw = b"From: alice@example.com\r\nSubject: Meeting tomorrow\r\n\r\nPlease bring the report.";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            pattern: Some("report".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            pattern: Some("Meeting".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            pattern: Some("nonexistent".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
    }

    #[test]
    fn matches_header_criterion_case_insensitive_name() {
        let raw = b"From: alice@example.com\r\nSubject: Re: hello\r\n\r\nbody";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            header: Some(vec!["subject=^Re:".to_string()]),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            header: Some(vec!["FROM=@example\\.com".to_string()]),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            header: Some(vec!["Subject=other".to_string()]),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
    }

    #[test]
    fn matches_body_only_matches_decoded_text() {
        let raw = b"From: a@x\r\nSubject: Meeting\r\n\r\nPlease bring the quarterly report.";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            body: Some("quarterly".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            body: Some("Meeting".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q), "body search must not see headers");
        let q = query_from(&FindConfig {
            body: Some("QUARTERLY".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q), "regex matching is case-sensitive");
    }

    #[test]
    fn matches_body_decodes_base64_and_charset() {
        let raw = b"From: a@x\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\nSGVsbG8gd29ybGQ=";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            body: Some("world".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
    }

    #[test]
    fn matches_date_range_bounds() {
        let raw = b"From: a@x\r\nSubject: S\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nbody";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            since: Some("2026-07-29".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q), "on the since day is included");
        let q = query_from(&FindConfig {
            until: Some("2026-07-29".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q), "on the until day is included");
        let q = query_from(&FindConfig {
            since: Some("2026-07-30".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            until: Some("2026-07-28".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
    }

    #[test]
    fn matches_date_filter_excludes_missing_date() {
        let raw = b"From: a@x\r\nSubject: S\r\n\r\nno date here";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            since: Some("2026-01-01".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
    }

    #[test]
    fn matches_all_criteria_are_anded() {
        let raw = b"From: alice@example.com\r\nSubject: Meeting\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nbring the report";
        let parsed = mailparse::parse_mail(raw).unwrap();
        let q = query_from(&FindConfig {
            pattern: Some("report".to_string()),
            header: Some(vec!["From=alice".to_string()]),
            since: Some("2026-07-29".to_string()),
            ..Default::default()
        });
        assert!(matches(&parsed, raw, &q));
        let q = query_from(&FindConfig {
            pattern: Some("report".to_string()),
            header: Some(vec!["From=bob".to_string()]),
            since: Some("2026-07-29".to_string()),
            ..Default::default()
        });
        assert!(!matches(&parsed, raw, &q));
    }

    #[test]
    fn resolve_search_path_default_and_folder() {
        let base = PathBuf::from("/data/fem");
        assert_eq!(resolve_search_path(base.clone(), None), base);
        assert_eq!(resolve_search_path(base.clone(), Some("")), base);
        assert_eq!(
            resolve_search_path(base.clone(), Some("drafts")),
            PathBuf::from("/data/fem/drafts")
        );
        assert_eq!(
            resolve_search_path(base.clone(), Some("/var/mail/archive")),
            PathBuf::from("/var/mail/archive")
        );
    }

    fn two_message_maildir() -> (tempfile::TempDir, PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        maildir
            .deliver(b"From: alice@example.com\r\nSubject: Meeting tomorrow\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nPlease bring the quarterly report.")
            .unwrap();
        maildir
            .deliver(b"From: carol@example.com\r\nSubject: Vacation plans\r\nDate: Thu, 30 Jul 2026 12:00:00 +0000\r\n\r\nThe beach is lovely.")
            .unwrap();
        let path = dir.path().join("maildir");
        (dir, path)
    }

    fn default_order() -> OrderBy {
        OrderBy { field: Field::Date, descending: true }
    }

    fn test_ctx() -> list::DisplayCtx<'static> {
        list::DisplayCtx {
            flag_new: "N",
            flag_attachment: "A",
            flag_encrypted: "E",
            flag_signed: "S",
            flag_reply: "R",
            flag_tagged: "T",
            date_format: "%Y",
        }
    }

    #[test]
    fn search_infos_filters_by_pattern() {
        let (_dir, path) = two_message_maildir();
        let q = query_from(&FindConfig {
            pattern: Some("report".to_string()),
            ..Default::default()
        });
        let infos = search_infos(&path, &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].subject, "Meeting tomorrow");
    }

    #[test]
    fn search_infos_filters_by_header_and_body() {
        let (_dir, path) = two_message_maildir();
        let q = query_from(&FindConfig {
            header: Some(vec!["Subject=^Meeting".to_string()]),
            ..Default::default()
        });
        let infos = search_infos(&path, &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].from, "alice@example.com");

        let q = query_from(&FindConfig {
            body: Some("beach".to_string()),
            ..Default::default()
        });
        let infos = search_infos(&path, &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].subject, "Vacation plans");
    }

    #[test]
    fn search_infos_filters_by_date_range() {
        let (_dir, path) = two_message_maildir();
        let q = query_from(&FindConfig {
            since: Some("2026-07-30".to_string()),
            ..Default::default()
        });
        let infos = search_infos(&path, &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].subject, "Vacation plans");
    }

    #[test]
    fn search_infos_empty_query_matches_all_sorted() {
        let (_dir, path) = two_message_maildir();
        let q = query_from(&FindConfig::default());
        let infos = search_infos(&path, &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos.len(), 2);
        assert_eq!(infos[0].subject, "Vacation plans", "newest first by default");
        assert_eq!(infos[0].flags, "N");
    }

    #[test]
    fn search_infos_in_folder_returns_only_that_folder() {
        let dir = tempfile::tempdir().unwrap();
        let root = build_maildir(&dir);
        root.deliver(b"From: a@x\r\nSubject: Root mail\r\n\r\nbody").unwrap();

        let folder = crate::maildir::Maildir::new(dir.path().join("maildir").join("drafts").to_path_buf());
        folder.ensure_dirs().unwrap();
        folder.deliver(b"From: b@x\r\nSubject: Draft mail\r\n\r\ndraft body").unwrap();

        let q = query_from(&FindConfig::default());
        let root_infos = search_infos(&dir.path().join("maildir"), &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(root_infos.len(), 1);
        assert_eq!(root_infos[0].subject, "Root mail");

        let folder_infos = search_infos(&dir.path().join("maildir").join("drafts"), &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(folder_infos.len(), 1);
        assert_eq!(folder_infos[0].subject, "Draft mail");
    }

    #[test]
    fn search_infos_threading_and_no_thread() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        maildir
            .deliver(b"From: a@x\r\nSubject: Parent\r\nMessage-ID: <p@x>\r\n\r\nbody")
            .unwrap();
        maildir
            .deliver(b"From: b@x\r\nSubject: Re: Parent\r\nIn-Reply-To: <p@x>\r\n\r\nreply body")
            .unwrap();

        let q = query_from(&FindConfig::default());
        let infos = search_infos(&dir.path().join("maildir"), &q, &test_ctx(), &default_order(), false, usize::MAX).unwrap();
        assert_eq!(infos[0].subject, "Parent", "root first when threaded");
        assert_eq!(infos[0].depth, 0);
        assert_eq!(infos[1].depth, 1);

        let flat = search_infos(&dir.path().join("maildir"), &q, &test_ctx(), &default_order(), true, usize::MAX).unwrap();
        assert_eq!(flat[0].depth, 0);
        assert_eq!(flat[1].depth, 0);
    }

    #[test]
    fn paginate_applies_offset_and_limit() {
        let infos: Vec<list::EmailInfo> = (1..=5)
            .map(|n| list::EmailInfo {
                number: n,
                ..Default::default()
            })
            .collect();
        let page = paginate(infos, 1, 2);
        assert_eq!(page.len(), 2);
        assert_eq!(page[0].number, 2);
        assert_eq!(page[1].number, 3);
        assert!(paginate(Vec::new(), 0, 25).is_empty());
    }

    #[test]
    fn merge_config_cli_overrides_config() {
        let config = FindConfig {
            folder: Some("sent".to_string()),
            pattern: Some("invoice".to_string()),
            header: Some(vec!["Subject=cfg".to_string()]),
            body: Some("cfg-body".to_string()),
            since: Some("2026-01-01".to_string()),
            until: Some("2026-12-31".to_string()),
            limit: Some(5),
            offset: Some(1),
            format: Some("json".to_string()),
            table_fields: Some("number,subject".to_string()),
            flag_new: Some("X".to_string()),
            date_format: Some("%d".to_string()),
            order_by: Some("from:asc".to_string()),
            no_thread: Some(true),
            maildir_path: Some("/cfg/maildir".to_string()),
            ..Default::default()
        };
        let args = FindArgs {
            folder: Some("drafts".to_string()),
            pattern: Some("urgent".to_string()),
            header: vec!["Subject=cli".to_string()],
            body: Some("cli-body".to_string()),
            since: Some("2026-02-01".to_string()),
            until: Some("2026-11-30".to_string()),
            limit: Some(10),
            offset: Some(2),
            format: Some("tsv".to_string()),
            table_fields: Some("from,size".to_string()),
            flag_new: Some("A".to_string()),
            flag_attachment: Some("B".to_string()),
            flag_encrypted: Some("C".to_string()),
            flag_signed: Some("E".to_string()),
            flag_reply: Some("D".to_string()),
            flag_tagged: Some("F".to_string()),
            date_format: Some("%m".to_string()),
            order_by: Some("subject:desc".to_string()),
            no_thread: false,
            label: Some("important".to_string()),
            maildir_path: Some("/cli/maildir".to_string()),
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.folder.as_deref(), Some("drafts"));
        assert_eq!(merged.pattern.as_deref(), Some("urgent"));
        assert_eq!(merged.header, Some(vec!["Subject=cli".to_string()]));
        assert_eq!(merged.body.as_deref(), Some("cli-body"));
        assert_eq!(merged.since.as_deref(), Some("2026-02-01"));
        assert_eq!(merged.until.as_deref(), Some("2026-11-30"));
        assert_eq!(merged.limit, Some(10));
        assert_eq!(merged.offset, Some(2));
        assert_eq!(merged.format.as_deref(), Some("tsv"));
        assert_eq!(merged.table_fields.as_deref(), Some("from,size"));
        assert_eq!(merged.flag_new.as_deref(), Some("A"));
        assert_eq!(merged.flag_signed.as_deref(), Some("E"));
        assert_eq!(merged.flag_tagged.as_deref(), Some("F"));
        assert_eq!(merged.date_format.as_deref(), Some("%m"));
        assert_eq!(merged.order_by.as_deref(), Some("subject:desc"));
        assert_eq!(merged.no_thread, Some(true), "unset --no-thread keeps the config value");
        assert_eq!(merged.label.as_deref(), Some("important"));
        assert_eq!(merged.maildir_path.as_deref(), Some("/cli/maildir"));
    }

    #[test]
    fn run_propagates_query_errors() {
        let config = FindConfig {
            pattern: Some("[unclosed".to_string()),
            ..Default::default()
        };
        let res = run(config, FindArgs::default(), PathBuf::new());
        assert!(res.is_err());
        assert!(format!("{:?}", res).contains("invalid search pattern"));
    }

    #[test]
    fn read_header_block_stops_at_crlf_blank_line() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("msg");
        std::fs::write(&file, b"From: a@x\r\nSubject: S\r\n\r\nbody body body").unwrap();
        let block = read_header_block(&file).unwrap().unwrap();
        assert_eq!(block, b"From: a@x\r\nSubject: S\r\n");
        assert!(find_header_terminator(b"From: a@x\r\nSubject: S\r\n\r\nbody").is_some());
    }

    #[test]
    fn read_header_block_stops_at_lf_blank_line() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("msg");
        std::fs::write(&file, b"From: a@x\nSubject: S\n\nbody").unwrap();
        assert_eq!(
            read_header_block(&file).unwrap().unwrap(),
            b"From: a@x\nSubject: S\n"
        );
    }

    #[test]
    fn read_header_block_no_body_returns_whole_file() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("msg");
        std::fs::write(&file, b"From: a@x\r\nSubject: S\r\n").unwrap();
        assert_eq!(
            read_header_block(&file).unwrap().unwrap(),
            b"From: a@x\r\nSubject: S\r\n"
        );
    }

    #[test]
    fn read_header_block_empty_file_is_empty_block() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("msg");
        std::fs::write(&file, b"").unwrap();
        assert_eq!(read_header_block(&file).unwrap().unwrap(), b"");
    }

    #[test]
    fn read_header_block_cap_overflow_falls_back_to_full_read() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("msg");
        let mut raw = b"From: a@x\r\n".to_vec();
        raw.extend(std::iter::repeat_n(b"X-Pad: 0123456789\r\n", 6000).flatten());
        raw.extend_from_slice(b"\r\nbody");
        std::fs::write(&file, &raw).unwrap();
        assert!(read_header_block(&file).unwrap().is_none(), "cap exceeded must signal a full read");
    }

    #[test]
    fn search_infos_header_only_search_still_matches() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        maildir
            .deliver(b"From: alice@example.com\r\nSubject: Meeting\r\n\r\nPlease bring the quarterly report.")
            .unwrap();
        let q = query_from(&FindConfig {
            header: Some(vec!["Subject=^Meeting".to_string()]),
            ..Default::default()
        });
        let infos = search_infos(
            &dir.path().join("maildir"),
            &q,
            &test_ctx(),
            &default_order(),
            false,
            usize::MAX,
        )
        .unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].subject, "Meeting");
    }

    #[test]
    fn search_infos_header_only_flags_multipart_attachment_via_full_read() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        maildir.deliver(b"From: a@x\r\nSubject: Plain\r\n\r\na big body").unwrap();
        let raw = b"From: b@x\r\nSubject: With attachment\r\nContent-Type: multipart/mixed; boundary=B\r\n\r\n--B\r\nContent-Type: text/plain\r\n\r\nhello\r\n--B\r\nContent-Type: application/octet-stream\r\nContent-Disposition: attachment; filename=f.bin\r\n\r\nDATA\r\n--B--\r\n";
        maildir.deliver(raw).unwrap();
        let q = query_from(&FindConfig::default());
        let infos = search_infos(
            &dir.path().join("maildir"),
            &q,
            &test_ctx(),
            &default_order(),
            false,
            usize::MAX,
        )
        .unwrap();
        assert_eq!(infos.len(), 2);
        let with_attachment = infos.iter().find(|i| i.subject == "With attachment").unwrap();
        assert!(with_attachment.flags.contains('A'), "multipart attachment flag must be detected");
    }

    #[test]
    fn search_infos_header_only_falls_back_for_oversized_headers() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        let mut raw = b"From: a@x\r\nSubject: Big headers\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n".to_vec();
        raw.extend(std::iter::repeat_n(b"X-Pad: 0123456789\r\n", 6000).flatten());
        raw.extend_from_slice(b"\r\nbody");
        maildir.deliver(&raw).unwrap();
        let q = query_from(&FindConfig::default());
        let infos = search_infos(
            &dir.path().join("maildir"),
            &q,
            &test_ctx(),
            &default_order(),
            false,
            usize::MAX,
        )
        .unwrap();
        assert_eq!(infos.len(), 1);
        assert_eq!(infos[0].subject, "Big headers");
    }

    #[test]
    fn merge_top_k_keeps_best_candidates() {
        let mk = |subject: &str, raw_date: &str| list::EmailInfo {
            subject: subject.to_string(),
            raw_date: raw_date.to_string(),
            date_sort_key: Some(DateTime::parse_from_rfc2822(raw_date).unwrap().timestamp()),
            ..Default::default()
        };
        let items = vec![
            mk("oldest", "Thu, 01 Jan 2026 10:00:00 +0000"),
            mk("middle", "Wed, 29 Jul 2026 10:00:00 +0000"),
            mk("newest", "Thu, 30 Jul 2026 10:00:00 +0000"),
        ];
        let order = OrderBy { field: Field::Date, descending: true };

        let top = merge_top_k(vec![items.clone()], 2, &order);
        let mut subjects: Vec<&str> = top.iter().map(|i| i.subject.as_str()).collect();
        subjects.sort();
        assert_eq!(subjects, ["middle", "newest"]);
        assert!(!top.iter().any(|i| i.subject == "oldest"));

        assert_eq!(merge_top_k(vec![items.clone()], 10, &order).len(), 3);
        assert_eq!(merge_top_k(vec![items.clone()], usize::MAX, &order).len(), 3);
        assert!(merge_top_k(vec![items], 0, &order).is_empty());
    }

    #[test]
    fn search_infos_bounded_keep_returns_only_top_k() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        maildir
            .deliver(b"From: a@x\r\nSubject: Old\r\nDate: Thu, 01 Jan 2026 10:00:00 +0000\r\n\r\nb")
            .unwrap();
        maildir
            .deliver(b"From: a@x\r\nSubject: Mid\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nb")
            .unwrap();
        maildir
            .deliver(b"From: a@x\r\nSubject: New\r\nDate: Thu, 30 Jul 2026 10:00:00 +0000\r\n\r\nb")
            .unwrap();
        let q = query_from(&FindConfig::default());
        let infos = search_infos(
            &dir.path().join("maildir"),
            &q,
            &test_ctx(),
            &default_order(),
            true,
            2,
        )
        .unwrap();
        assert_eq!(infos.len(), 2);
        assert_eq!(infos[0].subject, "New");
        assert_eq!(infos[1].subject, "Mid");
    }

    #[test]
    fn search_infos_flags_signed_and_tagged() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = build_maildir(&dir);
        let signed = concat!(
            "From: a@x\r\n",
            "Subject: Signed\r\n",
            "Date: Wed, 29 Jul 2026 10:00:00 +0000\r\n",
            "Content-Type: multipart/signed; boundary=\"sb\";\r\n",
            " protocol=\"application/pgp-signature\"\r\n",
            "\r\n",
            "--sb\r\n",
            "Content-Type: text/plain\r\n",
            "\r\n",
            "hello\r\n",
            "--sb\r\n",
            "Content-Type: application/pgp-signature\r\n",
            "\r\n",
            "-----BEGIN PGP SIGNATURE-----\r\n",
            "abc\r\n",
            "-----END PGP SIGNATURE-----\r\n",
            "--sb--\r\n",
        );
        let path = maildir.deliver(signed.as_bytes()).unwrap();
        maildir.deliver(b"From: b@x\r\nSubject: Plain\r\nDate: Wed, 29 Jul 2026 09:00:00 +0000\r\n\r\nbody").unwrap();

        let mut store = crate::tags::TagStore::load(&dir.path().join("maildir"));
        store.add(&path, "important");
        store.save().unwrap();

        let mut q = query_from(&FindConfig::default());
        q.all_tagged = store.tagged_paths();
        let infos = search_infos(
            &dir.path().join("maildir"),
            &q,
            &test_ctx(),
            &default_order(),
            false,
            usize::MAX,
        )
        .unwrap();
        assert_eq!(infos.len(), 2);

        let signed_info = infos.iter().find(|i| i.subject == "Signed").unwrap();
        assert!(signed_info.flags.contains('S'), "signed flag must be set: {}", signed_info.flags);
        assert!(signed_info.flags.contains('T'), "tagged flag must be set: {}", signed_info.flags);

        let plain_info = infos.iter().find(|i| i.subject == "Plain").unwrap();
        assert!(!plain_info.flags.contains('S'), "plain message must not be signed");
        assert!(!plain_info.flags.contains('T'), "plain message must not be tagged");
    }
}
