//! Display and sort local Maildir emails in a formatted table.
//!
//! # Output Formats
//!
//! - **`table`** (default): Formatted table with headers, separators, auto-sized
//!   columns, and terminal fitting.
//! - **`table-raw`**: Data rows only, no headers or separators, same column sizing.
//! - **`json`**: JSON array of email objects (one per message).
//! - **`tsv`**: Tab-separated values, no headers, raw field values.
//!
//! # Sorting
//!
//! The `OrderBy` struct controls sort field and direction. `parse_order_by` parses
//! `"field:direction"` strings (e.g. `"date:desc"`, `"from:asc"`). Default is
//! `date:desc` (most recent first). Numeric fields (`date`, `size`) sort
//! numerically; all others sort lexicographically.
//!
//! # Display
//!
//! Table columns are auto-sized to content width, with optional fixed widths via
//! `field:N` syntax. Terminal fitting reduces non-essential columns (from, to,
//! subject, size) when the table exceeds terminal width.

use crate::config::ListConfig;
use crate::maildir::Maildir;
use chrono::{DateTime, FixedOffset};
use mailparse::MailHeader;
use serde::Serialize;
use std::cmp::Ordering;
use std::path::Path;
use std::path::PathBuf;
use unicode_width::UnicodeWidthChar;
use unicode_width::UnicodeWidthStr;

const SEP: &str = " | ";
const SEP_W: usize = 3;
const TRUNC: &str = "\u{2026}"; // horizontal ellipsis … (visual width 1)

fn visual_width(s: &str) -> usize {
    UnicodeWidthStr::width(s)
}

fn truncate_visual(s: &str, max_vis: usize) -> String {
    if visual_width(s) <= max_vis {
        return s.to_string();
    }
    let mut out = String::with_capacity(s.len());
    let mut vis = 0;
    for c in s.chars() {
        let cw = UnicodeWidthChar::width(c).unwrap_or(0);
        if vis + cw > max_vis {
            break;
        }
        out.push(c);
        vis += cw;
    }
    out
}

fn pad_visual(s: &str, w: usize, align_right: bool) -> String {
    let vis = visual_width(s);
    if vis >= w {
        return s.to_string();
    }
    let pad = " ".repeat(w - vis);
    if align_right {
        format!("{pad}{s}")
    } else {
        format!("{s}{pad}")
    }
}

fn display_trunc(s: &str, w: usize, align_right: bool) -> String {
    if visual_width(s) <= w {
        return pad_visual(s, w, align_right);
    }
    let ellipsis_vis = visual_width(TRUNC);
    if ellipsis_vis >= w {
        let v = truncate_visual(s, w);
        return pad_visual(&v, w, align_right);
    }
    let content = truncate_visual(s, w - ellipsis_vis);
    let mut out = String::with_capacity(s.len());
    out.push_str(&content);
    out.push_str(TRUNC);
    pad_visual(&out, w, align_right)
}

fn sanitize(s: &str) -> String {
    if s.contains('\n') || s.contains('\r') {
        s.replace(['\r', '\n'], " ")
    } else {
        s.to_string()
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub(crate) enum Field {
    Number,
    Flags,
    Date,
    From,
    To,
    Subject,
    Size,
}

pub(crate) struct Column {
    pub(crate) field: Field,
    pub(crate) fixed_width: Option<usize>,
}

impl Column {
    fn header(&self) -> &'static str {
        match self.field {
            Field::Number => "  #",
            Field::Flags => "F",
            Field::Date => "DATE",
            Field::From => "FROM",
            Field::To => "TO",
            Field::Subject => "SUBJECT",
            Field::Size => "SIZE",
        }
    }

    fn val(&self, info: &EmailInfo) -> String {
        self.field.format(info)
    }

    /// Precompute the sanitized display value for every row of a column, so
    /// width computation and rendering share one format call per cell.
    fn prepare(&self, infos: &[EmailInfo]) -> Vec<String> {
        infos.iter().map(|i| sanitize(&self.display_val(i))).collect()
    }

    fn display_val(&self, info: &EmailInfo) -> String {
        let base = self.field.format(info);
        if self.field == Field::Subject && info.depth > 0 {
            let prefix = "↳ ".repeat(info.depth);
            format!("{prefix}{base}")
        } else {
            base
        }
    }

    fn display_header(&self, w: usize) -> String {
        let raw = sanitize(self.header());
        let align_right = matches!(self.field, Field::Number | Field::Size);
        display_trunc(&raw, w, align_right)
    }
}

impl Field {
    fn is_essential(&self) -> bool {
        matches!(self, Field::Number | Field::Flags | Field::Date)
    }

    fn format(&self, info: &EmailInfo) -> String {
        match self {
            Field::Number => info.number.to_string(),
            Field::Flags => info.flags.clone(),
            Field::Date => info.date.clone(),
            Field::From => info.from.clone(),
            Field::To => info.to.clone(),
            Field::Subject => info.subject.clone(),
            Field::Size => {
                if info.size < 1024 {
                    format!("{}B", info.size)
                } else if info.size < 1024 * 1024 {
                    format!("{}KB", info.size / 1024)
                } else {
                    format!("{}MB", info.size / (1024 * 1024))
                }
            }
        }
    }
}

#[derive(Clone, Copy)]
pub(crate) struct OrderBy {
    pub(crate) field: Field,
    pub(crate) descending: bool,
}

pub(crate) fn parse_order_by(s: &str) -> Option<OrderBy> {
    let s = s.trim();
    if s.is_empty() {
        return None;
    }
    let (name, dir) = match s.split_once(':') {
        Some((n, d)) => (n.trim(), Some(d.trim())),
        None => (s, None),
    };
    let field = match name {
        "number" => Field::Number,
        "flags" => Field::Flags,
        "date" => Field::Date,
        "from" => Field::From,
        "to" => Field::To,
        "subject" => Field::Subject,
        "size" => Field::Size,
        _ => return None,
    };
    let descending = match dir {
        Some("desc") => true,
        Some("asc") => false,
        None => field == Field::Date,
        _ => return None,
    };
    Some(OrderBy { field, descending })
}

fn cmp_field(a: &EmailInfo, b: &EmailInfo, field: Field) -> Ordering {
    match field {
        Field::Number => a.number.cmp(&b.number),
        Field::Flags => a.flags.cmp(&b.flags),
        Field::Date => match (a.date_sort_key, b.date_sort_key) {
            (Some(x), Some(y)) => x.cmp(&y),
            _ => a.raw_date.cmp(&b.raw_date),
        },
        Field::From => a.from.cmp(&b.from),
        Field::To => a.to.cmp(&b.to),
        Field::Subject => a.subject.cmp(&b.subject),
        Field::Size => a.size.cmp(&b.size),
    }
}

/// Compare two email infos honoring both the sort field and its direction.
///
/// Returns `Ordering::Less` when `a` sorts before `b`. Exposed to `find`, which
/// reuses the same ordering for its bounded top-K selection.
pub(crate) fn cmp_infos(a: &EmailInfo, b: &EmailInfo, order_by: &OrderBy) -> Ordering {
    let ord = cmp_field(a, b, order_by.field);
    if order_by.descending {
        ord.reverse()
    } else {
        ord
    }
}

pub(crate) fn sort_infos(infos: &mut [EmailInfo], order_by: &OrderBy) {
    infos.sort_by(|a, b| cmp_infos(a, b, order_by));
}

pub(crate) fn thread_emails(infos: &mut Vec<EmailInfo>, order_by: &OrderBy) {
    let n = infos.len();
    if n == 0 {
        return;
    }

    let id_to_idx: std::collections::HashMap<&str, usize> = infos
        .iter()
        .enumerate()
        .filter(|(_, e)| !e.message_id.is_empty())
        .map(|(i, e)| (e.message_id.as_str(), i))
        .collect();

    let mut children: Vec<Vec<usize>> = vec![Vec::new(); n];
    for (i, info) in infos.iter().enumerate() {
        let parent_idx = if !info.in_reply_to.is_empty() {
            id_to_idx.get(info.in_reply_to.as_str()).copied()
        } else {
            None
        };
        let parent_idx = parent_idx.or_else(|| {
            info.references
                .iter()
                .rev()
                .find_map(|id| id_to_idx.get(id.as_str()).copied())
        });
        if let Some(p) = parent_idx {
            children[p].push(i);
        }
    }

    for child_list in children.iter_mut() {
        child_list.sort_by(|&a, &b| cmp_infos(&infos[a], &infos[b], order_by));
    }

    let has_parent: Vec<bool> = (0..n)
        .map(|i| {
            let info = &infos[i];
            if !info.in_reply_to.is_empty() && id_to_idx.contains_key(info.in_reply_to.as_str()) {
                return true;
            }
            info.references
                .iter()
                .rev()
                .any(|id| id_to_idx.contains_key(id.as_str()))
        })
        .collect();

    let mut depth = vec![0usize; n];
    let mut order: Vec<usize> = Vec::with_capacity(n);

    for (i, is_root) in has_parent.iter().enumerate().take(n) {
        if !is_root {
            flatten_thread(i, &children, &mut depth, &mut order);
        }
    }

    // Reorder in place by moving each message once instead of cloning every
    // `EmailInfo`, which keeps peak memory near 2x matches rather than one
    // extra full copy of every match's header strings.
    let mut taken: Vec<Option<EmailInfo>> = infos.drain(..).map(Some).collect();
    let mut result: Vec<EmailInfo> = Vec::with_capacity(n);
    for idx in order {
        let mut info = taken[idx]
            .take()
            .expect("each message appears exactly once in thread order");
        info.depth = depth[idx];
        result.push(info);
    }
    *infos = result;
}

fn flatten_thread(
    idx: usize,
    children: &[Vec<usize>],
    depth: &mut [usize],
    order: &mut Vec<usize>,
) {
    order.push(idx);

    for &child in &children[idx] {
        depth[child] = depth[idx] + 1;
        flatten_thread(child, children, depth, order);
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub(crate) enum OutputFormat {
    Table,
    Json,
    TableRaw,
    Tsv,
}

pub(crate) fn parse_output_format(s: &str) -> OutputFormat {
    match s.trim() {
        "json" => OutputFormat::Json,
        "table-raw" => OutputFormat::TableRaw,
        "tsv" => OutputFormat::Tsv,
        _ => OutputFormat::Table,
    }
}

pub(crate) fn parse_fields(format_str: &str) -> Vec<Column> {
    format_str
        .split(',')
        .filter_map(|s| {
            let s = s.trim();
            let (name, fixed_width) = match s.split_once(':') {
                Some((n, w)) => (n.trim(), w.trim().parse::<usize>().ok()),
                None => (s, None),
            };
            let field = match name {
                "number" => Some(Field::Number),
                "flags" => Some(Field::Flags),
                "date" => Some(Field::Date),
                "from" => Some(Field::From),
                "to" => Some(Field::To),
                "subject" => Some(Field::Subject),
                "size" => Some(Field::Size),
                _ => None,
            }?;
            Some(Column { field, fixed_width })
        })
        .collect()
}

#[derive(Clone, Default, Serialize)]
pub(crate) struct EmailInfo {
    pub(crate) number: usize,
    pub(crate) flags: String,
    pub(crate) date: String,
    #[serde(skip)]
    pub(crate) raw_date: String,
    /// Cached timestamp of `raw_date`, so sorting never re-parses the header.
    #[serde(skip)]
    pub(crate) date_sort_key: Option<i64>,
    pub(crate) from: String,
    pub(crate) to: String,
    pub(crate) subject: String,
    pub(crate) size: u64,
    #[serde(skip)]
    pub(crate) depth: usize,
    #[serde(skip)]
    pub(crate) message_id: String,
    #[serde(skip)]
    pub(crate) in_reply_to: String,
    #[serde(skip)]
    pub(crate) references: Vec<String>,
    #[serde(skip)]
    pub(crate) path: PathBuf,
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn flags_string(
    is_new: bool,
    has_attachments: bool,
    is_encrypted: bool,
    is_signed: bool,
    is_reply: bool,
    is_tagged: bool,
    new_char: &str,
    attach_char: &str,
    encrypt_char: &str,
    signed_char: &str,
    reply_char: &str,
    tagged_char: &str,
) -> String {
    let mut s = String::with_capacity(6);
    if is_new {
        s.push_str(new_char);
    }
    if has_attachments {
        s.push_str(attach_char);
    }
    if is_encrypted {
        s.push_str(encrypt_char);
    }
    if is_signed {
        s.push_str(signed_char);
    }
    if is_reply {
        s.push_str(reply_char);
    }
    if is_tagged {
        s.push_str(tagged_char);
    }
    s
}

pub(crate) fn is_new_message(path: &Path) -> bool {
    path.to_string_lossy().contains("/new/")
}

/// Detect attachment, encryption, and signature indicators in a single MIME
/// tree walk.
///
/// An attachment is signaled by a `Content-Disposition: attachment` header at
/// the top level or in any subpart; encryption by a top-level or nested
/// `application/*-encrypted` content type; a PGP/MIME signature by a
/// top-level or nested `application/pgp-signature` content type.
fn mime_flags(parsed: &mailparse::ParsedMail) -> (bool, bool, bool) {
    let mut has_attachments = parsed.headers.iter().any(|h| {
        h.get_key() == "Content-Disposition" && h.get_value().to_lowercase().contains("attachment")
    });
    let ctype = parsed.ctype.mimetype.to_lowercase();
    let mut has_encrypted = ctype.starts_with("application/") && ctype.ends_with("-encrypted");
    let mut has_signed = ctype == "application/pgp-signature";
    for sub in &parsed.subparts {
        let (attach, encrypted, signed) = mime_flags(sub);
        has_attachments |= attach;
        has_encrypted |= encrypted;
        has_signed |= signed;
    }
    (has_attachments, has_encrypted, has_signed)
}

/// Parse an RFC 2822 date header value, returning `None` for missing or
/// malformed values.
pub(crate) fn parse_date(raw: &str) -> Option<DateTime<FixedOffset>> {
    if raw.is_empty() {
        return None;
    }
    DateTime::parse_from_rfc2822(raw).ok()
}

pub(crate) fn header_value(headers: &[MailHeader], name: &str) -> Option<String> {
    headers
        .iter()
        .find(|h| h.get_key() == name)
        .map(|h| h.get_value())
}

fn terminal_width() -> usize {
    terminal_size::terminal_size()
        .map(|(w, _)| w.0 as usize)
        .unwrap_or(80)
}

fn total_table_visual_width(widths: &[usize]) -> usize {
    widths.iter().sum::<usize>() + widths.len().saturating_sub(1) * SEP_W
}

fn fit_to_terminal(cols: &[Column], widths: &mut [usize]) {
    let max_w = terminal_width();
    let mut total = total_table_visual_width(widths);
    if total <= max_w {
        return;
    }

    let auto_idxs: Vec<usize> = cols
        .iter()
        .enumerate()
        .filter(|(_, c)| c.fixed_width.is_none() && !c.field.is_essential())
        .map(|(i, _)| i)
        .collect();

    if auto_idxs.is_empty() {
        return;
    }

    for _ in 0..100 {
        total = total_table_visual_width(widths);
        if total <= max_w {
            return;
        }
        let deficit = total - max_w;

        let shrinkable: Vec<usize> = auto_idxs
            .iter()
            .copied()
            .filter(|&i| widths[i] > visual_width(cols[i].header()))
            .collect();

        if shrinkable.is_empty() {
            return;
        }

        let total_shrinkable: usize = shrinkable.iter().map(|&i| widths[i]).sum();
        let mut remaining = deficit;

        for &i in &shrinkable {
            if remaining == 0 {
                break;
            }
            let h_vis = visual_width(cols[i].header());
            let avail = widths[i].saturating_sub(h_vis);
            if avail == 0 {
                continue;
            }
            let share = (deficit * widths[i] + total_shrinkable / 2) / total_shrinkable;
            let cut = share.max(1).min(avail).min(remaining);
            widths[i] -= cut;
            remaining -= cut;
        }
    }
}

/// Command-line arguments for the list subcommand.
#[derive(Default)]
pub struct ListArgs {
    pub maildir_path: Option<String>,
    pub limit: Option<usize>,
    pub offset: Option<usize>,
    pub format: Option<String>,
    pub table_fields: Option<String>,
    pub flag_new: Option<String>,
    pub flag_attachment: Option<String>,
    pub flag_encrypted: Option<String>,
    pub flag_signed: Option<String>,
    pub flag_reply: Option<String>,
    pub flag_tagged: Option<String>,
    pub date_format: Option<String>,
    pub order_by: Option<String>,
    pub no_thread: bool,
}

impl From<ListArgs> for ListConfig {
    fn from(args: ListArgs) -> Self {
        ListConfig {
            maildir_path: args.maildir_path,
            limit: args.limit,
            offset: args.offset,
            format: args.format,
            table_fields: args.table_fields,
            flag_new: args.flag_new,
            flag_attachment: args.flag_attachment,
            flag_encrypted: args.flag_encrypted,
            flag_signed: args.flag_signed,
            flag_reply: args.flag_reply,
            flag_tagged: args.flag_tagged,
            date_format: args.date_format,
            order_by: args.order_by,
            no_thread: if args.no_thread { Some(true) } else { None },
        }
    }
}

fn merge_config(config: ListConfig, args: ListArgs) -> ListConfig {
    let args_cfg: ListConfig = args.into();
    ListConfig {
        maildir_path: args_cfg.maildir_path.or(config.maildir_path),
        limit: args_cfg.limit.or(config.limit),
        offset: args_cfg.offset.or(config.offset),
        format: args_cfg.format.or(config.format),
        table_fields: args_cfg.table_fields.or(config.table_fields),
        flag_new: args_cfg.flag_new.or(config.flag_new),
        flag_attachment: args_cfg.flag_attachment.or(config.flag_attachment),
        flag_encrypted: args_cfg.flag_encrypted.or(config.flag_encrypted),
        flag_signed: args_cfg.flag_signed.or(config.flag_signed),
        flag_reply: args_cfg.flag_reply.or(config.flag_reply),
        flag_tagged: args_cfg.flag_tagged.or(config.flag_tagged),
        date_format: args_cfg.date_format.or(config.date_format),
        order_by: args_cfg.order_by.or(config.order_by),
        no_thread: args_cfg.no_thread.or(config.no_thread),
    }
}

/// Display options shared by the `list`, `show`, and `find` commands.
///
/// Grouping the flag characters and date format into one struct keeps the
/// per-message builder signatures small while both commands stay in sync.
#[derive(Clone, Copy)]
pub(crate) struct DisplayCtx<'a> {
    pub(crate) flag_new: &'a str,
    pub(crate) flag_attachment: &'a str,
    pub(crate) flag_encrypted: &'a str,
    pub(crate) flag_signed: &'a str,
    pub(crate) flag_reply: &'a str,
    pub(crate) flag_tagged: &'a str,
    pub(crate) date_format: &'a str,
}

/// Build an [`EmailInfo`] from an already-parsed email message.
///
/// Shared by `list` and `find` so both commands produce identical flags, dates,
/// and headers for the same message. The file size is supplied by the caller,
/// which usually already holds the full message bytes. When `extract_thread_refs`
/// is false (threading disabled), the `Message-ID` and `References` headers are
/// skipped entirely; `In-Reply-To` is always read because it drives the reply flag.
pub(crate) fn email_info_from_parsed(
    parsed: &mailparse::ParsedMail,
    path: &Path,
    ctx: &DisplayCtx,
    size: u64,
    extract_thread_refs: bool,
    is_tagged: bool,
) -> EmailInfo {
    let raw_date = header_value(&parsed.headers, "Date").unwrap_or_default();
    let dt = parse_date(&raw_date);
    let date = dt
        .map(|d| d.format(ctx.date_format).to_string())
        .unwrap_or_else(|| raw_date.clone());
    let date_sort_key = dt.map(|d| d.timestamp());
    let in_reply_to = header_value(&parsed.headers, "In-Reply-To").unwrap_or_default();
    let (message_id, references) = if extract_thread_refs {
        let message_id = header_value(&parsed.headers, "Message-ID").unwrap_or_default();
        let references_raw = header_value(&parsed.headers, "References").unwrap_or_default();
        let references: Vec<String> = references_raw
            .split(|c: char| c.is_whitespace())
            .filter(|s| !s.is_empty())
            .map(|s| s.to_string())
            .collect();
        (message_id, references)
    } else {
        (String::new(), Vec::new())
    };
    let (has_attachments, has_encrypted, has_signed) = mime_flags(parsed);
    EmailInfo {
        number: 0,
        flags: flags_string(
            is_new_message(path),
            has_attachments,
            has_encrypted,
            has_signed,
            !in_reply_to.is_empty(),
            is_tagged,
            ctx.flag_new,
            ctx.flag_attachment,
            ctx.flag_encrypted,
            ctx.flag_signed,
            ctx.flag_reply,
            ctx.flag_tagged,
        ),
        date,
        raw_date,
        date_sort_key,
        from: header_value(&parsed.headers, "From").unwrap_or_default(),
        to: header_value(&parsed.headers, "To").unwrap_or_default(),
        subject: header_value(&parsed.headers, "Subject").unwrap_or_default(),
        size,
        depth: 0,
        message_id,
        in_reply_to,
        references,
        path: path.to_path_buf(),
    }
}

pub(crate) fn ordered_infos(
    maildir_path: &Path,
    ctx: &DisplayCtx,
    order_by: &OrderBy,
    no_thread: bool,
) -> anyhow::Result<Vec<EmailInfo>> {
    let maildir = Maildir::new(maildir_path.to_path_buf());
    let messages = maildir.list_messages()?;

    if messages.is_empty() {
        return Ok(Vec::new());
    }

    let tagged = crate::tags::TagStore::load(maildir_path).tagged_paths();
    let extract_thread_refs = !no_thread;
    let mut infos: Vec<EmailInfo> = messages
        .iter()
        .filter_map(|path| {
            let content = std::fs::read(path).ok()?;
            let parsed = mailparse::parse_mail(&content).ok()?;
            Some(email_info_from_parsed(
                &parsed,
                path,
                ctx,
                content.len() as u64,
                extract_thread_refs,
                tagged.contains(path),
            ))
        })
        .collect();

    sort_infos(&mut infos, order_by);
    if !no_thread {
        thread_emails(&mut infos, order_by);
    }
    Ok(infos)
}

/// Render a set of email infos in the requested output format.
///
/// Shared by `list` and `find` so both commands print identical tables.
pub(crate) fn render_emails(fields: &[Column], output_fmt: OutputFormat, infos: &[EmailInfo]) {
    match output_fmt {
        OutputFormat::Table => render_table(fields, infos),
        OutputFormat::TableRaw => render_table_raw(fields, infos),
        OutputFormat::Json => render_json(infos),
        OutputFormat::Tsv => render_tsv(fields, infos),
    }
}

/// List the emails in the local Maildir at `default_data_dir` (or the
/// configured `maildir_path`) and print them in the selected format, sorted
/// and threaded according to the merged config and CLI arguments.
pub fn run(config: ListConfig, args: ListArgs, default_data_dir: PathBuf) -> anyhow::Result<()> {
    let cfg = merge_config(config, args);

    let maildir_path = cfg
        .maildir_path
        .map(PathBuf::from)
        .unwrap_or(default_data_dir);

    let fields = match cfg.table_fields.as_deref() {
        Some(f) if !f.is_empty() => parse_fields(f),
        _ => parse_fields(DEFAULT_TABLE_FIELDS),
    };

    if fields.is_empty() {
        return Ok(());
    }

    let flag_new = cfg
        .flag_new
        .unwrap_or_else(|| "N".to_string());
    let flag_attachment = cfg
        .flag_attachment
        .unwrap_or_else(|| "A".to_string());
    let flag_encrypted = cfg
        .flag_encrypted
        .unwrap_or_else(|| "E".to_string());
    let flag_signed = cfg
        .flag_signed
        .unwrap_or_else(|| "S".to_string());
    let flag_reply = cfg
        .flag_reply
        .unwrap_or_else(|| "R".to_string());
    let flag_tagged = cfg
        .flag_tagged
        .unwrap_or_else(|| "T".to_string());
    let date_format = cfg
        .date_format
        .unwrap_or_else(|| DEFAULT_DATE_FORMAT.to_string());
    let order_by = cfg
        .order_by
        .as_deref()
        .and_then(parse_order_by)
        .unwrap_or(OrderBy { field: Field::Date, descending: true });

    let ctx = DisplayCtx {
        flag_new: &flag_new,
        flag_attachment: &flag_attachment,
        flag_encrypted: &flag_encrypted,
        flag_signed: &flag_signed,
        flag_reply: &flag_reply,
        flag_tagged: &flag_tagged,
        date_format: &date_format,
    };

    let mut infos = ordered_infos(
        &maildir_path,
        &ctx,
        &order_by,
        cfg.no_thread.unwrap_or(false),
    )?;

    if infos.is_empty() {
        return Ok(());
    }

    let offset = cfg.offset.unwrap_or(0);
    let limit = cfg.limit.unwrap_or(25);
    if offset > 0 {
        infos = infos.into_iter().skip(offset).collect();
    }
    infos.truncate(limit);
    for (i, info) in infos.iter_mut().enumerate() {
        info.number = offset + i + 1;
    }

    let output_fmt = cfg
        .format
        .as_deref()
        .map(parse_output_format)
        .unwrap_or(OutputFormat::Table);

    match output_fmt {
        OutputFormat::Table => render_table(&fields, &infos),
        OutputFormat::TableRaw => render_table_raw(&fields, &infos),
        OutputFormat::Json => render_json(&infos),
        OutputFormat::Tsv => render_tsv(&fields, &infos),
    }
    Ok(())
}

fn render_table(fields: &[Column], infos: &[EmailInfo]) {
    let prepared: Vec<Vec<String>> = fields.iter().map(|c| c.prepare(infos)).collect();
    let mut widths: Vec<usize> = fields
        .iter()
        .zip(&prepared)
        .map(|(col, cells)| {
            if let Some(fw) = col.fixed_width {
                return fw;
            }
            let data_max = cells.iter().map(|s| visual_width(s)).max().unwrap_or(0);
            visual_width(col.header()).max(data_max)
        })
        .collect();
    fit_to_terminal(fields, &mut widths);

    for (i, col) in fields.iter().enumerate() {
        if i > 0 {
            print!("{SEP}");
        }
        print!("{}", col.display_header(widths[i]));
    }
    println!();

    let mut sep_line = String::new();
    for (i, &w) in widths.iter().enumerate() {
        if i > 0 {
            sep_line.push_str(SEP);
        }
        for _ in 0..w {
            sep_line.push('-');
        }
    }
    println!("{sep_line}");

    for (row, _info) in infos.iter().enumerate() {
        for (i, col) in fields.iter().enumerate() {
            if i > 0 {
                print!("{SEP}");
            }
            let align_right = matches!(col.field, Field::Number | Field::Size);
            print!("{}", display_trunc(&prepared[i][row], widths[i], align_right));
        }
        println!();
    }
}

fn render_table_raw(fields: &[Column], infos: &[EmailInfo]) {
    let prepared: Vec<Vec<String>> = fields.iter().map(|c| c.prepare(infos)).collect();
    let mut widths: Vec<usize> = fields
        .iter()
        .zip(&prepared)
        .map(|(col, cells)| {
            if let Some(fw) = col.fixed_width {
                return fw;
            }
            let data_max = cells.iter().map(|s| visual_width(s)).max().unwrap_or(0);
            visual_width(col.header()).max(data_max)
        })
        .collect();
    fit_to_terminal(fields, &mut widths);

    for (row, _info) in infos.iter().enumerate() {
        for (i, col) in fields.iter().enumerate() {
            if i > 0 {
                print!("{SEP}");
            }
            let align_right = matches!(col.field, Field::Number | Field::Size);
            print!("{}", display_trunc(&prepared[i][row], widths[i], align_right));
        }
        println!();
    }
}

fn render_json(infos: &[EmailInfo]) {
    let json_str = serde_json::to_string_pretty(infos).unwrap_or_default();
    println!("{json_str}");
}

fn render_tsv(fields: &[Column], infos: &[EmailInfo]) {
    for info in infos {
        for (i, col) in fields.iter().enumerate() {
            if i > 0 {
                print!("\t");
            }
            let val = col.val(info);
            let escaped = val.replace('\t', " ").replace(['\n', '\r'], " ");
            print!("{escaped}");
        }
        println!();
    }
}

const DEFAULT_TABLE_FIELDS: &str = "number,flags,date,from,subject";
pub(crate) const DEFAULT_DATE_FORMAT: &str = "%Y-%m-%d %H:%M:%S";

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_truncate_visual_emoji_boundary() {
        let s = "Knock, Knock 👉🏾 test";
        let vw = visual_width(s);
        assert_eq!(vw, 20, "full visual width should include emoji (👉=2, 🏾=0)");

        let truncated = truncate_visual(s, 20);
        let t_vw = visual_width(&truncated);
        assert!(t_vw <= 20, "truncation at width 20 should not exceed 20, got {t_vw}");
        assert!(truncated.contains("👉🏾"), "emoji sequence should not be broken");

        let truncated = truncate_visual(s, 10);
        let t_vw = visual_width(&truncated);
        assert!(t_vw <= 10, "truncation at width 10 should not exceed 10, got {t_vw}");

        let truncated = truncate_visual(s, 14);
        let t_vw = visual_width(&truncated);
        assert!(t_vw <= 14, "truncation at width 14 should not exceed 14, got {t_vw}");
    }

    #[test]
    fn test_truncate_visual_various_emoji() {
        let subjects = [
            "💡 What are effective strategies for software developers",
            "ACTION REQUIRED: Log in to keep your monitors running 🚨",
            "Knock, Knock 👉🏾 new: Devops/SRE position at Belvo",
            "↳ Re: Knock, Knock 👉🏾 new: Devops/SRE position at Belvo",
        ];
        for subject in &subjects {
            for &width in &[20, 30, 40, 50, 60, 70] {
                let result = truncate_visual(subject, width);
                let vw = visual_width(&result);
                assert!(
                    vw <= width,
                    "truncation of '{subject}' at width {width} gave vw {vw} > {width}"
                );
            }
        }
    }

    #[test]
    fn test_pad_visual_emoji_aligns_correctly() {
        let s = "↳ Re: Knock, Knock 👉🏾 new: Devops";
        let vw = visual_width(s);
        let col_w = vw + 4;
        let padded = pad_visual(s, col_w, false);
        assert_eq!(visual_width(&padded), col_w, "padded string should equal column width");
        assert!(padded.ends_with("    "), "padded string should end with 4 spaces");

        let right_padded = pad_visual(s, col_w, true);
        assert_eq!(visual_width(&right_padded), col_w, "right-padded string should equal column width");
        assert!(right_padded.starts_with("    "), "right-padded string should start with 4 spaces");
    }

    #[test]
    fn test_emoji_does_not_overflow_column() {
        let s = "💡 Code improvement strategies";
        let vw = visual_width(s);
        let col_width = vw + 2;
        assert_eq!(visual_width(&truncate_visual(s, col_width)), vw);
        assert_eq!(visual_width(&pad_visual(s, col_width, false)), col_width);
    }

    fn email_info(size: u64) -> EmailInfo {
        EmailInfo {
            number: 1,
            flags: String::new(),
            date: String::new(),
            raw_date: String::new(),
            date_sort_key: None,
            from: String::new(),
            to: String::new(),
            subject: String::new(),
            size,
            depth: 0,
            message_id: String::new(),
            in_reply_to: String::new(),
            references: Vec::new(),
            path: PathBuf::new(),
        }
    }

    fn threaded_maildir() -> (tempfile::TempDir, PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        maildir.deliver(b"From: a@x.com\r\nSubject: Parent\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\nMessage-ID: <p@x>\r\n\r\nbody").unwrap();
        let reply = maildir.deliver(b"From: b@x.com\r\nSubject: Re: Parent\r\nDate: Wed, 29 Jul 2026 11:00:00 +0000\r\nIn-Reply-To: <p@x>\r\n\r\nbody").unwrap();
        let cur = reply.parent().unwrap().parent().unwrap().join("cur").join(reply.file_name().unwrap());
        std::fs::rename(&reply, &cur).unwrap();
        let path = dir.path().join("maildir");
        (dir, path)
    }

    #[test]
    fn parse_order_by_fields_and_directions() {
        assert_eq!(parse_order_by("number:asc").unwrap().field, Field::Number);
        assert_eq!(parse_order_by("flags:desc").unwrap().field, Field::Flags);
        assert_eq!(parse_order_by("date:asc").unwrap().field, Field::Date);
        assert_eq!(parse_order_by("from:desc").unwrap().field, Field::From);
        assert_eq!(parse_order_by("to:asc").unwrap().field, Field::To);
        assert_eq!(parse_order_by("subject:desc").unwrap().field, Field::Subject);
        assert_eq!(parse_order_by("size:asc").unwrap().field, Field::Size);
    }

    #[test]
    fn parse_order_by_direction_defaults() {
        assert!(parse_order_by("date").unwrap().descending, "date defaults to desc");
        assert!(!parse_order_by("subject").unwrap().descending, "subject defaults to asc");
        assert!(parse_order_by("date:desc").unwrap().descending);
        assert!(!parse_order_by("date:asc").unwrap().descending);
    }

    #[test]
    fn parse_order_by_invalid() {
        assert!(parse_order_by("bogus").is_none());
        assert!(parse_order_by("date:sideways").is_none());
        assert!(parse_order_by("").is_none());
        assert!(parse_order_by("  ").is_none());
    }

    #[test]
    fn parse_fields_names_and_widths() {
        let cols = parse_fields("number,subject:40,from");
        assert_eq!(cols.len(), 3);
        assert_eq!(cols[0].field, Field::Number);
        assert_eq!(cols[0].fixed_width, None);
        assert_eq!(cols[1].field, Field::Subject);
        assert_eq!(cols[1].fixed_width, Some(40));
        assert_eq!(cols[2].field, Field::From);
    }

    #[test]
    fn parse_fields_skips_unknown() {
        let cols = parse_fields("number,bogus,size");
        assert_eq!(cols.len(), 2);
        assert_eq!(cols[0].field, Field::Number);
        assert_eq!(cols[1].field, Field::Size);
        assert!(parse_fields("").is_empty());
        assert!(parse_fields("bogus").is_empty());
    }

    #[test]
    fn parse_output_format_variants() {
        assert_eq!(parse_output_format("json"), OutputFormat::Json);
        assert_eq!(parse_output_format("table-raw"), OutputFormat::TableRaw);
        assert_eq!(parse_output_format("tsv"), OutputFormat::Tsv);
        assert_eq!(parse_output_format("table"), OutputFormat::Table);
        assert_eq!(parse_output_format("bogus"), OutputFormat::Table);
        assert_eq!(parse_output_format("  json  "), OutputFormat::Json);
    }

    #[test]
    fn flags_string_uses_custom_chars() {
        assert_eq!(flags_string(true, true, true, true, true, true, "N", "A", "E", "S", "R", "T"), "NAESRT");
        assert_eq!(flags_string(true, true, true, true, true, true, "NEW", "ATT", "ENC", "SIG", "REP", "TAG"), "NEWATTENCSIGREPTAG");
        assert_eq!(flags_string(false, true, false, false, true, false, "N", "A", "E", "S", "R", "T"), "AR");
        assert_eq!(flags_string(true, false, false, false, false, false, "N", "A", "E", "S", "R", "T"), "N");
        assert_eq!(flags_string(false, false, false, false, false, false, "N", "A", "E", "S", "R", "T"), "");
    }

    #[test]
    fn parse_date_variants() {
        assert_eq!(parse_date("Wed, 29 Jul 2026 10:00:00 +0000").unwrap().format("%Y").to_string(), "2026");
        assert_eq!(parse_date("Wed, 29 Jul 2026 10:00:00 +0000").unwrap().format("%H:%M").to_string(), "10:00");
        assert!(parse_date("garbage date").is_none());
        assert!(parse_date("").is_none());
    }

    #[test]
    fn size_field_formats_human_readable() {
        assert_eq!(Field::Size.format(&email_info(512)), "512B");
        assert_eq!(Field::Size.format(&email_info(2048)), "2KB");
        assert_eq!(Field::Size.format(&email_info(3 * 1024 * 1024)), "3MB");
    }

    #[test]
    fn sort_infos_respects_field_and_direction() {
        let mut infos = vec![
            EmailInfo { from: "b@x".to_string(), number: 2, ..email_info(0) },
            EmailInfo { from: "a@x".to_string(), number: 1, ..email_info(0) },
        ];
        sort_infos(&mut infos, &parse_order_by("from:asc").unwrap());
        assert_eq!(infos[0].from, "a@x");
        sort_infos(&mut infos, &parse_order_by("from:desc").unwrap());
        assert_eq!(infos[0].from, "b@x");
        sort_infos(&mut infos, &parse_order_by("number:desc").unwrap());
        assert_eq!(infos[0].number, 2);
    }

    #[test]
    fn thread_emails_groups_replies_under_parent() {
        let mut infos = vec![
            EmailInfo { in_reply_to: "<p@x>".to_string(), subject: "Re: Parent".to_string(), ..email_info(0) },
            EmailInfo { message_id: "<p@x>".to_string(), subject: "Parent".to_string(), ..email_info(0) },
        ];
        thread_emails(&mut infos, &parse_order_by("date:desc").unwrap());
        assert_eq!(infos[0].subject, "Parent");
        assert_eq!(infos[0].depth, 0);
        assert_eq!(infos[1].subject, "Re: Parent");
        assert_eq!(infos[1].depth, 1);
    }

    #[test]
    fn ordered_infos_applies_flags_date_format_and_threading() {
        let (_dir, maildir_path) = threaded_maildir();
        let ob = OrderBy { field: Field::Date, descending: true };
        let infos = ordered_infos(
            &maildir_path,
            &DisplayCtx {
                flag_new: "N",
                flag_attachment: "A",
                flag_encrypted: "E",
                flag_signed: "S",
                flag_reply: "R",
                flag_tagged: "T",
                date_format: "%Y",
            },
            &ob,
            false,
        )
        .unwrap();

        assert_eq!(infos.len(), 2);
        assert_eq!(infos[0].subject, "Parent", "parent is the thread root and sorts first");
        assert_eq!(infos[0].flags, "N", "message in new/ carries the new flag");
        assert_eq!(infos[0].date, "2026", "custom date format applies");
        assert_eq!(infos[0].depth, 0);
        assert_eq!(infos[1].subject, "Re: Parent");
        assert_eq!(infos[1].flags, "R", "message in cur/ with In-Reply-To carries the reply flag");
        assert_eq!(infos[1].depth, 1);
    }

    #[test]
    fn ordered_infos_custom_flag_chars_apply() {
        let (_dir, maildir_path) = threaded_maildir();
        let ob = OrderBy { field: Field::Date, descending: true };
        let infos = ordered_infos(
            &maildir_path,
            &DisplayCtx {
                flag_new: "!",
                flag_attachment: "@",
                flag_encrypted: "#",
                flag_signed: "S",
                flag_reply: "$",
                flag_tagged: "T",
                date_format: "%Y",
            },
            &ob,
            false,
        )
        .unwrap();
        assert_eq!(infos[0].flags, "!");
        assert_eq!(infos[1].flags, "$");
    }

    #[test]
    fn ordered_infos_no_thread_flattens_thread() {
        let (_dir, maildir_path) = threaded_maildir();
        let ob = OrderBy { field: Field::Date, descending: true };
        let infos = ordered_infos(
            &maildir_path,
            &DisplayCtx {
                flag_new: "N",
                flag_attachment: "A",
                flag_encrypted: "E",
                flag_signed: "S",
                flag_reply: "R",
                flag_tagged: "T",
                date_format: "%Y",
            },
            &ob,
            true,
        )
        .unwrap();

        assert_eq!(infos[0].subject, "Re: Parent", "reply sorts first by date without threading");
        assert_eq!(infos[0].depth, 0);
        assert_eq!(infos[1].subject, "Parent");
        assert_eq!(infos[1].depth, 0);
    }

    #[test]
    fn flags_include_signed_for_pgp_signature_part() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        // A multipart/signed message: the second part is application/pgp-signature.
        let msg = concat!(
            "From: a@x.com\r\n",
            "Subject: Signed\r\n",
            "Date: Wed, 29 Jul 2026 10:00:00 +0000\r\n",
            "MIME-Version: 1.0\r\n",
            "Content-Type: multipart/signed; boundary=\"sigbound\";\r\n",
            " protocol=\"application/pgp-signature\"\r\n",
            "\r\n",
            "--sigbound\r\n",
            "Content-Type: text/plain\r\n",
            "\r\n",
            "hello\r\n",
            "--sigbound\r\n",
            "Content-Type: application/pgp-signature\r\n",
            "\r\n",
            "-----BEGIN PGP SIGNATURE-----\r\n",
            "abc\r\n",
            "-----END PGP SIGNATURE-----\r\n",
            "--sigbound--\r\n",
        );
        maildir.deliver(msg.as_bytes()).unwrap();

        let ob = OrderBy { field: Field::Date, descending: true };
        let ctx = DisplayCtx {
            flag_new: "N",
            flag_attachment: "A",
            flag_encrypted: "E",
            flag_signed: "S",
            flag_reply: "R",
            flag_tagged: "T",
            date_format: "%Y",
        };
        let infos = ordered_infos(&dir.path().join("maildir"), &ctx, &ob, false).unwrap();
        assert_eq!(infos.len(), 1);
        assert!(infos[0].flags.contains('S'), "signed flag must be set: {}", infos[0].flags);
        assert!(!infos[0].flags.contains('T'), "no tags yet: {}", infos[0].flags);
    }

    #[test]
    fn flags_include_tagged_when_message_has_label() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().join("maildir").to_path_buf());
        maildir.ensure_dirs().unwrap();
        let path = maildir
            .deliver(b"From: a@x.com\r\nSubject: Tagged\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nbody")
            .unwrap();

        let mut store = crate::tags::TagStore::load(&dir.path().join("maildir"));
        store.add(&path, "important");
        store.save().unwrap();

        let ob = OrderBy { field: Field::Date, descending: true };
        let ctx = DisplayCtx {
            flag_new: "N",
            flag_attachment: "A",
            flag_encrypted: "E",
            flag_signed: "S",
            flag_reply: "R",
            flag_tagged: "T",
            date_format: "%Y",
        };
        let infos = ordered_infos(&dir.path().join("maildir"), &ctx, &ob, false).unwrap();
        assert_eq!(infos.len(), 1);
        assert!(infos[0].flags.contains('T'), "tagged flag must be set: {}", infos[0].flags);
        assert!(!infos[0].flags.contains('S'), "not signed: {}", infos[0].flags);
    }

    #[test]
    fn merge_config_cli_overrides_config() {
        let config = ListConfig {
            limit: Some(5),
            offset: Some(1),
            format: Some("json".to_string()),
            table_fields: Some("number,subject".to_string()),
            flag_new: Some("X".to_string()),
            flag_attachment: Some("Y".to_string()),
            flag_encrypted: Some("Z".to_string()),
            flag_signed: Some("V".to_string()),
            flag_reply: Some("W".to_string()),
            flag_tagged: Some("U".to_string()),
            date_format: Some("%d".to_string()),
            order_by: Some("from:asc".to_string()),
            no_thread: Some(true),
            maildir_path: Some("/cfg/maildir".to_string()),
        };
        let args = ListArgs {
            limit: Some(10),
            offset: Some(2),
            format: Some("tsv".to_string()),
            table_fields: Some("from,size".to_string()),
            flag_new: Some("A".to_string()),
            flag_attachment: Some("B".to_string()),
            flag_encrypted: Some("C".to_string()),
            flag_signed: Some("E".to_string()),
            flag_reply: Some("D".to_string()),
            flag_tagged: Some("F".to_string()),
            date_format: Some("%m".to_string()),
            order_by: Some("subject:desc".to_string()),
            no_thread: false,
            maildir_path: Some("/cli/maildir".to_string()),
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.limit, Some(10));
        assert_eq!(merged.offset, Some(2));
        assert_eq!(merged.format.as_deref(), Some("tsv"));
        assert_eq!(merged.table_fields.as_deref(), Some("from,size"));
        assert_eq!(merged.flag_new.as_deref(), Some("A"));
        assert_eq!(merged.flag_attachment.as_deref(), Some("B"));
        assert_eq!(merged.flag_encrypted.as_deref(), Some("C"));
        assert_eq!(merged.flag_signed.as_deref(), Some("E"));
        assert_eq!(merged.flag_reply.as_deref(), Some("D"));
        assert_eq!(merged.flag_tagged.as_deref(), Some("F"));
        assert_eq!(merged.date_format.as_deref(), Some("%m"));
        assert_eq!(merged.order_by.as_deref(), Some("subject:desc"));
        assert_eq!(merged.no_thread, Some(true), "CLI did not set --no-thread, so config is preserved");
        assert_eq!(merged.maildir_path.as_deref(), Some("/cli/maildir"));
    }

    #[test]
    fn total_table_visual_width_sums_columns_and_separators() {
        assert_eq!(total_table_visual_width(&[10, 20]), 10 + 3 + 20);
        assert_eq!(total_table_visual_width(&[5]), 5);
        assert_eq!(total_table_visual_width(&[]), 0);
    }
}
