//! `fem` — CLI-based email management.
//!
//! # Subcommands
//!
//! - **`pull`**: Connect to IMAP4, fetch unseen emails, store to local Maildir.
//!   `--pre-hook BINARY` runs a binary or script before each message is stored:
//!   the raw message is fed to it on stdin and its stdout becomes the final
//!   message to store; empty output skips the message (with a notice, without
//!   failing), and a non-zero exit stops the pull with an error.
//!   `--post-hook BINARY` runs a binary or script after each stored message,
//!   receiving the message path as its sole argument; a non-zero exit aborts
//!   the pull. Supported config keys: `server`, `port`, `username`, `password`,
//!   `password_command`, `mailbox`, `ssl`, `all`, `pre_hook`, `post_hook`.
//!
//! - **`push`**: Send an email over SMTP. Reads a raw message from stdin, or
//!   sends drafts from the drafts directory with `--all-drafts` (every draft)
//!   or `--last-draft` (the most recently modified one). The envelope is derived
//!   from the message's `From`/`To`/`Cc`/`Bcc` headers; a `Bcc` header is kept in
//!   the envelope but stripped from the transmitted body. Drafts the server
//!   accepted are removed from the drafts directory. Encryption is selected with
//!   `--ssl` (implicit TLS, default, port 465), `--starttls` (STARTTLS upgrade,
//!   port 587; mutually exclusive with `--ssl`), or neither for plaintext.
//!   Supported config keys: `server`, `port`, `username`, `password`,
//!   `password_command`, `ssl`, `starttls`, `drafts_path`, `all_drafts`,
//!   `last_draft`.
//!
//!   Supported config keys: `maildir_path`, `limit`, `offset`, `format`, `table_fields`,
//!   `flag_new`, `flag_attachment`, `flag_encrypted`, `flag_signed`, `flag_reply`, `flag_tagged`,
//!   `date_format`, `order_by`, `no_thread`.
//!   The `--format` option accepts `table` (default), `json`, `table-raw`, or `tsv`.
//!
//!   The `--order-by` option accepts a `field:direction` string (e.g. `date:desc`,
//!   `from:asc`). Fields: `number`, `flags`, `date`, `from`, `to`, `subject`, `size`.
//!   Direction defaults to `asc` for most fields, `desc` for `date`. Default sort is
//!   `date:desc` (most recent first).
//!   The `--no-thread` flag disables reply threading, showing emails in strict global
//!   order without grouping replies under their parent messages.
//!   The `--flag-reply` option sets the character(s) for the reply indicator
//!   in the flags column (default: `R`). The `--flag-signed` option sets the
//!   indicator for messages carrying a `application/pgp-signature` MIME part
//!   (default: `S`), and `--flag-tagged` the indicator for messages tagged with
//!   `fem tag` (default: `T`).
//!
//! - **`compose`**: Create a new email draft. Prompts for recipient, sender, and subject
//!   (unless provided via CLI or config), opens `$EDITOR` to compose the body, and saves
//!   the draft to the drafts directory. Supported config keys: `maildir_path`, `to`, `from`, `subject`,
//!   `drafts_path`, `no_include_headers`, `recover_last_draft`,
//!   `pre_compose_hook`, `post_compose_hook`, `template`, `message`.
//!   When prompting for `To` or `From`, TAB autocompletion is available: the address
//!   list is built from the `From`/`To`/`Cc` headers of every message in the maildir
//!   (the `maildir_path`/`--maildir-path` setting, defaulting to the data directory)
//!   and cached under the cache directory to keep startup fast. Repeated TAB presses
//!   cycle through the matching contacts, inserting the display form
//!   `"Name" <email>` rather than a bare address.
//!   The `--template` option uses an EML file as the initial draft: its `To`, `From`,
//!   `Subject`, and `Message-ID` headers are replaced with the prompted/configured values
//!   (or a fresh `Message-ID` is added), while all other headers in the template are kept.
//!   With `--no-include-headers`, the template's headers are hidden from the editor and the
//!   automatic headers (`To`, `From`, `Subject`, `Date`, `Message-ID`) are added when
//!   saving, overriding any same-named headers typed during editing while keeping any
//!   other headers the user added. When using `--template`, exiting the editor without
//!   changes aborts composition: no post-compose hooks run and no draft is saved.
//!   The `--message` option takes the full message content directly from the command
//!   line, skipping the editor entirely. Headers in the message are mixed with the
//!   automatic ones: the automatic `To`/`From`/`Subject`/`Date`/`Message-ID` override
//!   same-named headers in the message, while any other message headers (e.g. `Cc`,
//!   `Reply-To`, `X-*`) are kept. A missing `To`/`From`/`Subject` is taken from the
//!   message headers before prompting. `--message` and `--template` are mutually
//!   exclusive. When mutually exclusive options are combined across the command line
//!   and the config file, the command-line option takes precedence and the conflicting
//!   config value is ignored.
//!
//! - **`show`**: Print a single email by its ID (as displayed in `fem list`) to stdout.
//!   Supported config keys: `maildir_path`, `order_by`, `no_thread`, `flag_new`,
//!   `flag_attachment`, `flag_encrypted`, `flag_reply`, `date_format`, `headers_show`, `headers_hide`,
//!   `multipart_handle`, `multipart_preference`, `no_multipart_preference`, `raw`,
//!   `no_color`, `force_color`, `color_header_key`, `color_header_value`,
//!   `color_part_separator`, `color_handler_info`, `color_handler_error`, `wrap`.
//!   `headers_show` and `headers_hide` are mutually exclusive; when the two options are
//!   split between the command line and the config file, the command-line option takes
//!   precedence and the conflicting config value is ignored.
//!
//! - **`cat`**: Read from stdin and write to stdout (like cat), used as the default
//!   handler for `text/plain` parts in `fem show`. Supported config keys:
//!   `hide_signature`, `collapse_citation`, `color_regex`, `no_color`, `force_color`.
//!
//! - **`find`**: Search local Maildir emails by header, body text, or date range.
//!   Accepts a positional `PATTERN` regex matched against the whole raw message,
//!   repeatable `--header NAME=REGEX` criteria, a `--body REGEX`, and inclusive
//!   `--since`/`--until` date bounds; `--folder` restricts the search to a single
//!   folder (a maildir under the data directory); `--label LABEL` matches only
//!   emails tagged with that label by `fem tag`. All criteria are AND-ed, and
//!   results are rendered like `fem list`. The scan is parallelized across CPU
//!   cores; header- and date-only searches read just the header block of each
//!   message, and with `--no-thread` only the best `offset + limit` matches are
//!   retained in memory. Supported config keys: `maildir_path`,
//!   `folder`, `pattern`, `header`, `body`, `since`, `until`, `limit`, `offset`,
//!   `format`, `table_fields`, `flag_new`, `flag_attachment`, `flag_encrypted`,
//!   `flag_signed`, `flag_reply`, `flag_tagged`, `date_format`, `order_by`,
//!   `no_thread`, `label`.
//!
//! - **`tag`**: Tag an email with a label by its ID (as displayed in `fem list`).
//!   The label is required (`--label LABEL`); the ID is resolved with the same
//!   ordering and threading rules as `fem list`/`fem show` (`--order-by`,
//!   `--no-thread`). Labels are stored in a JSON file (`tags`) at the Maildir
//!   root and can be searched with `fem find --label`. Re-tagging a message with
//!   the same label is a no-op. Supported config keys: `maildir_path`, `label`,
//!   `order_by`, `no_thread`.
//!
//! # Configuration
//!
//! TOML-based config at `$XDG_CONFIG_HOME/fem/fem.toml` (fallback `$HOME/.fem/fem.toml`).
//! CLI flags override config values. Data stored in `$XDG_DATA_HOME/fem/`.
//!
//! # Examples
//!
//! ```ignore
//! fem pull --server imap.example.com --username user@example.com
//! fem list --order-by from:asc --table-fields "number,from,subject"
//! fem list --order-by date:desc
//! fem show 1
//! fem show 3 --order-by date:asc --wrap 80
//! echo "body text" | fem cat --hide-signature
//! fem compose --to user@example.com --from me@example.com --subject "Hello"
//! fem compose --template reply.eml --to user@example.com
//! fem compose --message "To: user@example.com\nCc: other@example.com\n\nHello!"
//! fem push --server smtp.example.com --username user@example.com --port 587
//! fem push --all-drafts
//! fem push --last-draft
//! fem find --header "Subject=^Re:" --since 2026-01-01
//! fem find --body "invoice|quarterly report"
//! fem tag --label important 311
//! fem find --label important
//! ```
//!
//! # Multipart handlers
//!
//! `fem show` pipes multipart parts through external handlers. Handlers receive the
//! part on stdin and write the rendered output to stdout. Informational messages can
//! be written to file descriptor 3 (shown in green) and errors to stderr (shown in
//! bright red on success). See `contrib/` for PGP/MIME scripts:
//!
//! - `contrib/pgp-handler.sh` — decrypts `multipart/encrypted` emails via `gpg`.
//! - `contrib/pgp-signed-handler.sh` — verifies `multipart/signed` emails.
//! - `contrib/pgp-encrypt.sh` — compose `--post-compose-hook` that encrypts a draft
//!   with PGP/MIME (RFC 3156) before saving.
//!
//! Post-quantum PQP/MIME equivalents (via the `pqp` tool, see its README for key
//! setup; pqp must be on `PATH`):
//!
//! - `contrib/pqp-handler.sh` — decrypts `multipart/encrypted` emails via
//!   `pqp decrypt --no-passphrase`.
//! - `contrib/pqp-signed-handler.sh` — verifies `multipart/signed` emails via
//!   `pqp verify`.
//! - `contrib/pqp-encrypt.sh` — compose `--post-compose-hook` that encrypts a draft
//!   with PQP/MIME before saving.
//! - `contrib/pqp-sign.sh` — compose `--post-compose-hook` that signs a draft with
//!   PQP/MIME before saving.
//!
//! # License
//!
//! `fem` is released under the MIT License. See `COPYING` for the full text.

pub mod config;
pub mod list;
pub mod maildir;
pub mod contacts;
pub mod pull;
pub mod push;
pub mod compose;
pub mod show;
pub mod cat;
pub mod find;
pub mod tags;
pub mod tag;

/// Resolve a pair of mutually exclusive options after merging CLI arguments with
/// config values.
///
/// The CLI side takes precedence: when exactly one of the two options is present
/// on the command line, the other option's config value is dropped instead of
/// raising a conflict. An error is raised only when both options are given on
/// the command line (`--{name_a} and --{name_b} are mutually exclusive`) or when
/// both are set in the config file alone.
pub(crate) fn resolve_mutual_exclusion<T>(
    cli_a: bool,
    cli_b: bool,
    cfg_a: &mut Option<T>,
    cfg_b: &mut Option<T>,
    name_a: &str,
    name_b: &str,
) -> anyhow::Result<()> {
    if cli_a && cli_b {
        anyhow::bail!("--{name_a} and --{name_b} are mutually exclusive");
    }
    if cli_a {
        cfg_b.take();
    } else if cli_b {
        cfg_a.take();
    } else if cfg_a.is_some() && cfg_b.is_some() {
        anyhow::bail!("--{name_a} and --{name_b} are mutually exclusive (both set in config)");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::resolve_mutual_exclusion;

    #[test]
    fn cli_a_wins_over_config_b() {
        let mut a = Some("from-cli".to_string());
        let mut b = Some("from-config".to_string());
        resolve_mutual_exclusion(true, false, &mut a, &mut b, "a", "b").unwrap();
        assert_eq!(a.as_deref(), Some("from-cli"));
        assert!(b.is_none(), "config b must be dropped when cli a is set");
    }

    #[test]
    fn cli_b_wins_over_config_a() {
        let mut a = Some("from-config".to_string());
        let mut b = Some("from-cli".to_string());
        resolve_mutual_exclusion(false, true, &mut a, &mut b, "a", "b").unwrap();
        assert_eq!(b.as_deref(), Some("from-cli"));
        assert!(a.is_none(), "config a must be dropped when cli b is set");
    }

    #[test]
    fn both_cli_conflict_errors() {
        let mut a = Some("a".to_string());
        let mut b = Some("b".to_string());
        let res = resolve_mutual_exclusion(true, true, &mut a, &mut b, "a", "b");
        assert!(res.is_err());
        assert!(format!("{:?}", res).contains("mutually exclusive"));
    }

    #[test]
    fn both_config_conflict_errors() {
        let mut a = Some("a".to_string());
        let mut b = Some("b".to_string());
        let res = resolve_mutual_exclusion(false, false, &mut a, &mut b, "a", "b");
        assert!(res.is_err());
        assert!(format!("{:?}", res).contains("both set in config"));
    }

    #[test]
    fn neither_set_is_ok() {
        let mut a: Option<String> = None;
        let mut b: Option<String> = None;
        resolve_mutual_exclusion(false, false, &mut a, &mut b, "a", "b").unwrap();
    }
}
