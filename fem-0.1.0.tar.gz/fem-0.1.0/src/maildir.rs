//! Local Maildir mailbox storage.
//!
//! Wraps a directory tree in the [Maildir](https://cr.yp.to/proto/maildir.html)
//! layout (`new/`, `cur/`, `tmp/`). Messages are delivered to `new/` with an
//! optional IMAP UID embedded in the filename, listed back for reading, and
//! queried for the set of already-stored UIDs so `fem pull --all` can skip
//! messages that were fetched before.

use std::path::{Path, PathBuf};
use std::time::SystemTime;

/// Errors that can occur while operating on a Maildir mailbox.
#[derive(Debug, thiserror::Error)]
pub enum MaildirError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
}

/// Represents a local Maildir mailbox directory.
pub struct Maildir {
    path: PathBuf,
}

impl Maildir {
    /// Create a handle for the Maildir rooted at `path`.
    pub fn new(path: PathBuf) -> Self {
        Self { path }
    }

    /// Return the root directory of the Maildir.
    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Create the standard `new/`, `cur/`, and `tmp/` subdirectories.
    pub fn ensure_dirs(&self) -> Result<(), MaildirError> {
        std::fs::create_dir_all(self.path.join("new"))?;
        std::fs::create_dir_all(self.path.join("cur"))?;
        std::fs::create_dir_all(self.path.join("tmp"))?;
        Ok(())
    }

    /// Deliver a message to the `new/` subdirectory, returning its path.
    pub fn deliver(&self, message: &[u8]) -> Result<PathBuf, MaildirError> {
        self.deliver_with_uid(message, None)
    }

    /// Deliver a message to the `new/` subdirectory, embedding an optional IMAP
    /// UID in the filename so already-fetched messages can be recognized later.
    pub fn deliver_with_uid(&self, message: &[u8], uid: Option<u32>) -> Result<PathBuf, MaildirError> {
        let nanos = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let pid = std::process::id();
        let uid_prefix = match uid {
            Some(n) => format!("U={n}_"),
            None => String::new(),
        };
        let filename = format!("{uid_prefix}{nanos}.M{pid}P.localhost:2,");
        let path = self.path.join("new").join(&filename);
        std::fs::write(&path, message)?;
        Ok(path)
    }

    /// Collect the sorted, de-duplicated set of IMAP UIDs stored in the
    /// mailbox (embedded in filenames as `U=<uid>_`).
    pub fn existing_uids(&self) -> Result<Vec<u32>, MaildirError> {
        let mut uids = Vec::new();
        for subdir in &["new", "cur"] {
            let dir_path = self.path.join(subdir);
            if !dir_path.exists() {
                continue;
            }
            for entry in std::fs::read_dir(dir_path)? {
                let entry = entry?;
                if !entry.file_type().is_ok_and(|t| t.is_file()) {
                    continue;
                }
                let name = entry.file_name().to_string_lossy().to_string();
                if let Some(rest) = name.strip_prefix("U=") {
                    if let Some(uid_str) = rest.split('_').next() {
                        if let Ok(n) = uid_str.parse::<u32>() {
                            uids.push(n);
                        }
                    }
                }
            }
        }
        uids.sort();
        uids.dedup();
        Ok(uids)
    }

    /// List the paths of all messages in the `new/` and `cur/` subdirectories,
    /// sorted by filename.
    pub fn list_messages(&self) -> Result<Vec<PathBuf>, MaildirError> {
        let mut messages = Vec::new();
        for subdir in &["new", "cur"] {
            let dir_path = self.path.join(subdir);
            if !dir_path.exists() {
                continue;
            }
            let mut entries: Vec<_> = std::fs::read_dir(dir_path)?
                .filter_map(|e| e.ok())
                .filter(|e| e.file_type().is_ok_and(|t| t.is_file()))
                .map(|e| e.path())
                .collect();
            entries.sort();
            messages.extend(entries);
        }
        Ok(messages)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ensure_dirs_creates_subdirectories() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        assert!(dir.path().join("new").is_dir());
        assert!(dir.path().join("cur").is_dir());
        assert!(dir.path().join("tmp").is_dir());
    }

    #[test]
    fn test_deliver_creates_file_in_new() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        let content = b"From: test@example.com\nSubject: test\n\ntest body";
        let path = maildir.deliver(content).unwrap();

        assert!(path.exists());
        assert!(path.to_string_lossy().contains("/new/"));
        assert_eq!(std::fs::read(&path).unwrap(), content);
    }

    #[test]
    fn test_list_messages_returns_sorted() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        maildir.deliver(b"message 1").unwrap();
        maildir.deliver(b"message 2").unwrap();

        let msgs = maildir.list_messages().unwrap();
        assert_eq!(msgs.len(), 2);
    }

    #[test]
    fn test_list_messages_empty_maildir() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        // Don't create dirs — should handle missing gracefully
        let msgs = maildir.list_messages().unwrap();
        assert!(msgs.is_empty());
    }

    #[test]
    fn test_deliver_with_uid_and_check_existing() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        let content = b"From: test@example.com\nSubject: UID test\n\nbody";
        maildir.deliver_with_uid(content, Some(42)).unwrap();

        let uids = maildir.existing_uids().unwrap();
        assert_eq!(uids, vec![42]);
    }

    #[test]
    fn test_existing_uids_empty() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        // deliver without UID
        maildir.deliver(b"no uid").unwrap();

        let uids = maildir.existing_uids().unwrap();
        assert!(uids.is_empty());
    }

    #[test]
    fn test_existing_uids_dedup() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();

        // Same UID in both new/ and cur/
        maildir.deliver_with_uid(b"msg1", Some(1)).unwrap();
        let path = maildir.deliver_with_uid(b"msg2", Some(1)).unwrap();
        // Move one to cur/ by renaming
        let cur_path = path.parent().unwrap().parent().unwrap().join("cur").join(path.file_name().unwrap());
        std::fs::rename(&path, &cur_path).unwrap();

        let uids = maildir.existing_uids().unwrap();
        assert_eq!(uids, vec![1]);
    }
}
