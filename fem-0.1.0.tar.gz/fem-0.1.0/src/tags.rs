//! Persistent per-maildir tag store for email labeling.
//!
//! Tags associate a message file (by its absolute path) with a set of labels.
//! They are stored in a JSON file named `tags` at the Maildir root, so both
//! `fem tag` (which writes) and `fem find --label` (which reads) resolve the
//! same store from the same root directory.

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

/// In-memory view of a Maildir's tags, backed by a JSON file.
pub struct TagStore {
    /// Where the store is persisted (the `tags` file at the Maildir root).
    path: PathBuf,
    /// Message path -> sorted, de-duplicated labels.
    by_message: HashMap<PathBuf, Vec<String>>,
}

impl TagStore {
    /// Load the tag store for a Maildir root. A missing or corrupt file yields
    /// an empty store; the file is created on the next save.
    pub fn load(maildir_path: &Path) -> TagStore {
        let path = maildir_path.join("tags");
        let by_message = std::fs::read_to_string(&path)
            .ok()
            .and_then(|text| serde_json::from_str(&text).ok())
            .unwrap_or_default();
        TagStore { path, by_message }
    }

    /// Return the labels attached to a message, sorted.
    pub fn labels_for(&self, message_path: &Path) -> Vec<String> {
        self.by_message.get(message_path).cloned().unwrap_or_default()
    }

    /// Return the absolute paths of all messages carrying `label`.
    pub fn paths_with(&self, label: &str) -> HashSet<PathBuf> {
        self.by_message
            .iter()
            .filter(|(_, labels)| labels.iter().any(|l| l == label))
            .map(|(path, _)| path.clone())
            .collect()
    }

    /// Return the absolute paths of all messages that carry at least one label.
    pub fn tagged_paths(&self) -> HashSet<PathBuf> {
        self.by_message.keys().cloned().collect()
    }

    /// Add a label to a message (de-duplicated, kept sorted). Returns whether
    /// the label was newly added.
    pub fn add(&mut self, message_path: &Path, label: &str) -> bool {
        let labels = self.by_message.entry(message_path.to_path_buf()).or_default();
        if labels.iter().any(|l| l == label) {
            return false;
        }
        labels.push(label.to_string());
        labels.sort();
        true
    }

    /// Remove a label from a message. Drops the message entry when it has no
    /// labels left. Returns whether the label was present.
    pub fn remove(&mut self, message_path: &Path, label: &str) -> bool {
        let removed = self
            .by_message
            .get_mut(message_path)
            .map(|labels| {
                let before = labels.len();
                labels.retain(|l| l != label);
                labels.len() != before
            })
            .unwrap_or(false);
        if removed && self.by_message.get(message_path).is_some_and(|l| l.is_empty()) {
            self.by_message.remove(message_path);
        }
        removed
    }

    /// Persist the store to its JSON file, creating parent directories.
    pub fn save(&self) -> anyhow::Result<()> {
        if let Some(parent) = self.path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let text = serde_json::to_string_pretty(&self.by_message)?;
        std::fs::write(&self.path, text)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn add_and_labels_round_trip() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        let msg = store_path.join("new").join("1.eml");

        let mut store = TagStore::load(&store_path);
        assert!(store.add(&msg, "important"));
        assert!(!store.add(&msg, "important"), "duplicate add is a no-op");
        store.add(&msg, "work");

        assert_eq!(store.labels_for(&msg), vec!["important".to_string(), "work".to_string()]);
        assert!(store.save().is_ok());
        assert!(store_path.join("tags").exists());
    }

    #[test]
    fn save_and_reload_preserves_data() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        let msg = store_path.join("cur").join("2.eml");

        let mut store = TagStore::load(&store_path);
        store.add(&msg, "todo");
        store.save().unwrap();

        let reloaded = TagStore::load(&store_path);
        assert_eq!(reloaded.labels_for(&msg), vec!["todo".to_string()]);
    }

    #[test]
    fn paths_with_returns_matching_messages() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        let a = store_path.join("new").join("a.eml");
        let b = store_path.join("new").join("b.eml");

        let mut store = TagStore::load(&store_path);
        store.add(&a, "important");
        store.add(&b, "other");

        let paths = store.paths_with("important");
        assert_eq!(paths, HashSet::from([a.clone()]));
        assert!(store.paths_with("missing").is_empty());
    }

    #[test]
    fn tagged_paths_returns_all_labeled_messages() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        let a = store_path.join("new").join("a.eml");
        let b = store_path.join("new").join("b.eml");

        let mut store = TagStore::load(&store_path);
        store.add(&a, "important");
        store.add(&b, "other");

        let tagged = store.tagged_paths();
        assert_eq!(tagged, HashSet::from([a, b]));
    }

    #[test]
    fn remove_drops_label_and_entry() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        let msg = store_path.join("new").join("a.eml");

        let mut store = TagStore::load(&store_path);
        store.add(&msg, "important");
        assert!(store.remove(&msg, "important"));
        assert!(!store.remove(&msg, "important"), "second remove is a no-op");
        assert!(store.labels_for(&msg).is_empty());
    }

    #[test]
    fn missing_store_is_empty_and_does_not_crash() {
        let dir = tempfile::tempdir().unwrap();
        let store = TagStore::load(&dir.path().join("does-not-exist"));
        assert!(store.labels_for(&dir.path().join("nope")).is_empty());
        assert!(store.paths_with("anything").is_empty());
    }

    #[test]
    fn corrupt_store_is_ignored() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("maildir");
        std::fs::create_dir_all(&store_path).unwrap();
        std::fs::write(store_path.join("tags"), "this is not json {{{").unwrap();
        let store = TagStore::load(&store_path);
        assert!(store.labels_for(&store_path.join("x")).is_empty());
    }

    #[test]
    fn save_creates_parent_directories() {
        let dir = tempfile::tempdir().unwrap();
        let store_path = dir.path().join("nested").join("maildir");
        let msg = store_path.join("new").join("a.eml");

        let mut store = TagStore::load(&store_path);
        store.add(&msg, "important");
        store.save().unwrap();
        assert!(store_path.join("tags").exists());
    }
}
