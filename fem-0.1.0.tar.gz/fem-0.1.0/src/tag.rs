//! Tag an email by its ID (as displayed in `fem list`) with a label.
//!
//! Resolves the email ID to a message path using the same ordering and
//! threading rules as `fem list`/`fem show`, then records the label in the
//! Maildir's tag store (`<maildir>/tags`). Labels are searchable with
//! `fem find --label`.

use crate::config::TagConfig;
use crate::list::{self, Field, OrderBy};
use crate::tags::TagStore;
use std::path::{Path, PathBuf};

/// Command-line arguments for the tag subcommand.
#[derive(Default)]
pub struct TagArgs {
    /// Email ID (1-based, as shown in `fem list`).
    pub id: usize,
    /// Label to attach to the email (required).
    pub label: Option<String>,
    /// Path to Maildir root.
    pub maildir_path: Option<String>,
    /// Sort order: field:direction (default: date:desc).
    pub order_by: Option<String>,
    /// Disable reply threading.
    pub no_thread: bool,
}

impl From<TagArgs> for TagConfig {
    fn from(args: TagArgs) -> Self {
        TagConfig {
            maildir_path: args.maildir_path,
            label: args.label,
            order_by: args.order_by,
            no_thread: if args.no_thread { Some(true) } else { None },
        }
    }
}

fn merge_config(config: TagConfig, args: TagArgs) -> TagConfig {
    let args_cfg: TagConfig = args.into();
    TagConfig {
        maildir_path: args_cfg.maildir_path.or(config.maildir_path),
        label: args_cfg.label.or(config.label),
        order_by: args_cfg.order_by.or(config.order_by),
        no_thread: args_cfg.no_thread.or(config.no_thread),
    }
}

/// Resolve a 1-based email ID (as displayed by `fem list`) to its message
/// path, mirroring `show`'s ordering and threading defaults.
fn resolve_message_path(
    maildir_path: &Path,
    order_by: &OrderBy,
    no_thread: bool,
    id: usize,
) -> anyhow::Result<PathBuf> {
    if id == 0 {
        anyhow::bail!("email ID must be a positive integer (1-based)");
    }

    let flag_new = "N";
    let flag_attachment = "A";
    let flag_encrypted = "E";
    let flag_signed = "S";
    let flag_reply = "R";
    let flag_tagged = "T";
    let ctx = list::DisplayCtx {
        flag_new,
        flag_attachment,
        flag_encrypted,
        flag_signed,
        flag_reply,
        flag_tagged,
        date_format: list::DEFAULT_DATE_FORMAT,
    };

    let infos = list::ordered_infos(maildir_path, &ctx, order_by, no_thread)?;
    if infos.is_empty() {
        anyhow::bail!("no emails found in mailbox");
    }
    if id > infos.len() {
        anyhow::bail!(
            "email ID {id} is out of range (mailbox has {} emails)",
            infos.len()
        );
    }
    Ok(infos[id - 1].path.clone())
}

/// Tag the email with the given ID with `label` and persist the store.
///
/// Returns the path of the tagged message and whether the label was newly
/// added (it is a no-op when the message already carries it).
pub fn run(config: TagConfig, args: TagArgs, default_data_dir: PathBuf) -> anyhow::Result<(PathBuf, bool)> {
    let id = args.id;
    let cfg = merge_config(config, args);

    let label = cfg
        .label
        .ok_or_else(|| anyhow::anyhow!("label is required (use --label LABEL or set it in config)"))?;
    if label.trim().is_empty() {
        anyhow::bail!("label must not be empty");
    }

    let maildir_path = cfg
        .maildir_path
        .map(PathBuf::from)
        .unwrap_or(default_data_dir);

    let order_by = cfg
        .order_by
        .as_deref()
        .and_then(list::parse_order_by)
        .unwrap_or(OrderBy { field: Field::Date, descending: true });
    let no_thread = cfg.no_thread.unwrap_or(false);

    let path = resolve_message_path(&maildir_path, &order_by, no_thread, id)?;

    let mut store = TagStore::load(&maildir_path);
    let added = store.add(&path, &label);
    store.save()?;
    Ok((path, added))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::maildir::Maildir;

    fn maildir_with(dir: &tempfile::TempDir) -> Maildir {
        let maildir = Maildir::new(dir.path().join("maildir"));
        maildir.ensure_dirs().unwrap();
        maildir
    }

    fn msg(from: &str, subject: &str, date: &str) -> Vec<u8> {
        format!(
            "From: {from}\r\nSubject: {subject}\r\nDate: {date}\r\n\r\nbody"
        )
        .into_bytes()
    }

    #[test]
    fn run_tags_message_by_id() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir
            .deliver(&msg("a@x.com", "First", "Thu, 30 Jul 2026 10:00:00 +0000"))
            .unwrap();
        maildir
            .deliver(&msg("b@x.com", "Second", "Wed, 29 Jul 2026 10:00:00 +0000"))
            .unwrap();

        let res = run(
            TagConfig::default(),
            TagArgs { id: 1, label: Some("important".into()), ..Default::default() },
            dir.path().join("maildir"),
        )
        .unwrap();
        assert!(res.1, "label must be newly added");
        assert!(res.0.to_string_lossy().contains("/new/"));

        let store = TagStore::load(&dir.path().join("maildir"));
        assert_eq!(store.labels_for(&res.0), vec!["important".to_string()]);
    }

    #[test]
    fn run_is_idempotent() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir.deliver(&msg("a@x.com", "Only", "Thu, 30 Jul 2026 10:00:00 +0000")).unwrap();

        let args = TagArgs { id: 1, label: Some("work".into()), ..Default::default() };
        let (path, first) = run(TagConfig::default(), args, dir.path().join("maildir")).unwrap();
        assert!(first);
        let args = TagArgs { id: 1, label: Some("work".into()), ..Default::default() };
        let (_, second) = run(TagConfig::default(), args, dir.path().join("maildir")).unwrap();
        assert!(!second, "re-tagging the same label is a no-op");
        assert_eq!(TagStore::load(&dir.path().join("maildir")).labels_for(&path), vec!["work".to_string()]);
    }

    #[test]
    fn run_requires_label() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir.deliver(&msg("a@x.com", "Only", "Thu, 30 Jul 2026 10:00:00 +0000")).unwrap();

        let res = run(
            TagConfig::default(),
            TagArgs { id: 1, label: None, ..Default::default() },
            dir.path().join("maildir"),
        );
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("label is required"));
    }

    #[test]
    fn run_rejects_empty_label() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir.deliver(&msg("a@x.com", "Only", "Thu, 30 Jul 2026 10:00:00 +0000")).unwrap();

        let res = run(
            TagConfig::default(),
            TagArgs { id: 1, label: Some("   ".into()), ..Default::default() },
            dir.path().join("maildir"),
        );
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("must not be empty"));
    }

    #[test]
    fn run_rejects_out_of_range_id() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir.deliver(&msg("a@x.com", "Only", "Thu, 30 Jul 2026 10:00:00 +0000")).unwrap();

        let res = run(
            TagConfig::default(),
            TagArgs { id: 99, label: Some("important".into()), ..Default::default() },
            dir.path().join("maildir"),
        );
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("out of range"));
    }

    #[test]
    fn run_rejects_zero_id() {
        let dir = tempfile::tempdir().unwrap();
        let res = run(
            TagConfig::default(),
            TagArgs { id: 0, label: Some("important".into()), ..Default::default() },
            dir.path().join("maildir"),
        );
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("positive integer"));
    }

    #[test]
    fn run_with_no_thread_and_order_by() {
        let dir = tempfile::tempdir().unwrap();
        let maildir = maildir_with(&dir);
        maildir
            .deliver(&msg("a@x.com", "First", "Thu, 30 Jul 2026 10:00:00 +0000"))
            .unwrap();
        maildir
            .deliver(&msg("b@x.com", "Second", "Wed, 29 Jul 2026 10:00:00 +0000"))
            .unwrap();

        // With date:asc + no_thread, ID 1 is the oldest message (Second).
        let res = run(
            TagConfig::default(),
            TagArgs {
                id: 1,
                label: Some("oldest".into()),
                order_by: Some("date:asc".into()),
                no_thread: true,
                ..Default::default()
            },
            dir.path().join("maildir"),
        )
        .unwrap();
        let content = std::fs::read_to_string(&res.0).unwrap();
        assert!(content.contains("Subject: Second"), "{content}");
    }

    #[test]
    fn merge_config_cli_wins() {
        let config = TagConfig { maildir_path: Some("/cfg/maildir".into()), ..Default::default() };
        let args = TagArgs {
            maildir_path: Some("/cli/maildir".into()),
            order_by: Some("from:asc".into()),
            no_thread: true,
            ..Default::default()
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.maildir_path.as_deref(), Some("/cli/maildir"));
        assert_eq!(merged.order_by.as_deref(), Some("from:asc"));
        assert_eq!(merged.no_thread, Some(true));
    }
}
