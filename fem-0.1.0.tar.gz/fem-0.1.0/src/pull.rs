//! Pull emails from an IMAP4 server and store them locally in Maildir format.
//!
//! Connects to the server (over TLS), authenticates, selects a mailbox, and
//! fetches messages. By default only unseen messages are fetched; with
//! `--all` every message is fetched but those whose IMAP UID is already stored
//! are skipped. The password comes from an explicit value, a
//! `--password-command`, or an interactive prompt.
//!
//! The network path is untested: the session is abstracted behind the
//! `MailboxOps` trait, driven by an in-memory `MockSession` in tests.

use crate::config::PullConfig;
use crate::maildir::Maildir;
use futures::TryStreamExt;
use std::path::{Path, PathBuf};
use tokio::io::{AsyncRead, AsyncWrite};

/// Command-line arguments for the pull subcommand.
#[derive(Default)]
pub struct PullArgs {
    pub server: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    pub password: Option<String>,
    pub password_command: Option<String>,
    pub mailbox: Option<String>,
    pub ssl: Option<bool>,
    pub all: bool,
    pub pre_hook: Option<String>,
    pub post_hook: Option<String>,
}

impl From<PullArgs> for PullConfig {
    fn from(args: PullArgs) -> Self {
        PullConfig {
            server: args.server,
            port: args.port,
            username: args.username,
            password: args.password,
            password_command: args.password_command,
            mailbox: args.mailbox,
            ssl: args.ssl,
            all: if args.all { Some(true) } else { None },
            pre_hook: args.pre_hook,
            post_hook: args.post_hook,
        }
    }
}

fn merge_config(config: PullConfig, args: PullArgs) -> PullConfig {
    let args_cfg: PullConfig = args.into();
    PullConfig {
        server: args_cfg.server.or(config.server),
        port: args_cfg.port.or(config.port),
        username: args_cfg.username.or(config.username),
        password: args_cfg.password.or(config.password),
        password_command: args_cfg.password_command.or(config.password_command),
        mailbox: args_cfg.mailbox.or(config.mailbox),
        ssl: args_cfg.ssl.or(config.ssl),
        all: args_cfg.all.or(config.all),
        pre_hook: args_cfg.pre_hook.or(config.pre_hook),
        post_hook: args_cfg.post_hook.or(config.post_hook),
    }
}

/// A single message fetched from the IMAP server, with its UID when known.
#[derive(Debug, Clone)]
struct FetchedMessage {
    /// IMAP UID (0 when the server did not report one).
    uid: u32,
    /// Raw message body, when the server returned one.
    body: Option<Vec<u8>>,
}

/// Abstraction over an IMAP session, so the fetch/storage logic can be tested
/// against an in-memory mock instead of a real server.
#[allow(async_fn_in_trait)]
trait MailboxOps {
    /// Select the mailbox to operate on.
    async fn select(&mut self, mailbox: &str) -> anyhow::Result<()>;
    /// Search for unseen message sequence numbers.
    async fn search_unseen(&mut self) -> anyhow::Result<Vec<u32>>;
    /// Fetch every message in the mailbox (sequence set `1:*`) with its UID.
    async fn fetch_all(&mut self) -> anyhow::Result<Vec<FetchedMessage>>;
    /// Fetch the messages with the given sequence numbers.
    async fn fetch_ids(&mut self, ids: &[u32]) -> anyhow::Result<Vec<FetchedMessage>>;
}

impl<S> MailboxOps for async_imap::Session<S>
where
    S: AsyncRead + AsyncWrite + Unpin + std::fmt::Debug + Send,
{
    async fn select(&mut self, mailbox: &str) -> anyhow::Result<()> {
        async_imap::Session::select(self, mailbox).await?;
        Ok(())
    }

    async fn search_unseen(&mut self) -> anyhow::Result<Vec<u32>> {
        let ids = async_imap::Session::search(self, "UNSEEN").await?;
        let mut ids: Vec<u32> = ids.into_iter().collect();
        ids.sort_unstable();
        Ok(ids)
    }

    async fn fetch_all(&mut self) -> anyhow::Result<Vec<FetchedMessage>> {
        let stream = async_imap::Session::fetch(self, "1:*", "UID RFC822").await?;
        let mut out = Vec::new();
        let mut stream = stream;
        while let Some(fetch) = stream.try_next().await? {
            out.push(FetchedMessage {
                uid: fetch.uid.unwrap_or(0),
                body: fetch.body().map(|b| b.to_vec()),
            });
        }
        Ok(out)
    }

    async fn fetch_ids(&mut self, ids: &[u32]) -> anyhow::Result<Vec<FetchedMessage>> {
        let id_list: Vec<String> = ids.iter().map(|n| n.to_string()).collect();
        let stream = async_imap::Session::fetch(self, id_list.join(","), "RFC822").await?;
        let mut out = Vec::new();
        let mut stream = stream;
        while let Some(fetch) = stream.try_next().await? {
            out.push(FetchedMessage {
                uid: fetch.uid.unwrap_or(0),
                body: fetch.body().map(|b| b.to_vec()),
            });
        }
        Ok(out)
    }
}

/// Resolve a password: explicit password, `password_command` output, or an
/// interactive prompt. Shared by `pull` (IMAP) and `push` (SMTP).
pub(crate) fn resolve_password(
    password: &Option<String>,
    password_command: &Option<String>,
    service: &str,
    username: &str,
) -> anyhow::Result<String> {
    match password {
        Some(p) if !p.is_empty() => Ok(p.clone()),
        _ => match password_command {
            Some(cmd) if !cmd.is_empty() => run_password_command(cmd),
            _ => {
                eprint!("{service} password for {username}: ");
                Ok(rpassword::read_password()?)
            }
        },
    }
}

/// Run a password command and return the first line of its stdout.
pub(crate) fn run_password_command(cmd: &str) -> anyhow::Result<String> {
    let output = std::process::Command::new("sh")
        .arg("-c")
        .arg(cmd)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null())
        .output()
        .map_err(|e| anyhow::anyhow!("failed to run password command: {e}"))?;
    if !output.status.success() {
        anyhow::bail!("password command exited with error: {cmd}");
    }
    let pw = String::from_utf8_lossy(&output.stdout)
        .lines()
        .next()
        .unwrap_or("")
        .to_string();
    if pw.is_empty() {
        anyhow::bail!("password command produced no output: {cmd}");
    }
    Ok(pw)
}

/// Connect to an IMAP4 server, authenticate, and fetch messages into the local
/// Maildir at `data_dir`. With `--all` every message is fetched but those whose
/// UID is already stored are skipped; otherwise only unseen messages are
/// fetched.
pub async fn run(config: PullConfig, args: PullArgs, data_dir: PathBuf) -> anyhow::Result<()> {
    let cfg = merge_config(config, args);

    let server = cfg
        .server
        .clone()
        .ok_or_else(|| anyhow::anyhow!("server is required (set in config or use --server)"))?;
    let port = cfg.port.unwrap_or(993);
    let username = cfg
        .username
        .clone()
        .ok_or_else(|| anyhow::anyhow!("username is required (set in config or use --username)"))?;
    let mailbox = cfg.mailbox.clone().unwrap_or_else(|| "INBOX".to_string());

    let password = resolve_password(&cfg.password, &cfg.password_command, "IMAP", &username)?;

    let addr = format!("{server}:{port}");
    let tcp_stream = tokio::net::TcpStream::connect(&addr).await?;
    let tls = tokio_native_tls::TlsConnector::from(native_tls::TlsConnector::new()?);
    let tls_stream = tls.connect(&server, tcp_stream).await?;

    let client = async_imap::Client::new(tls_stream);

    let all = cfg.all.unwrap_or(false);
    let pre_hook = cfg.pre_hook.as_deref();
    let post_hook = cfg.post_hook.as_deref();
    let mut session = client.login(&username, &password).await.map_err(|e| e.0)?;
    let maildir = Maildir::new(data_dir);
    maildir.ensure_dirs()?;
    fetch_and_store(&mut session, &maildir, &mailbox, all, pre_hook, post_hook).await?;
    session.logout().await?;

    Ok(())
}

/// Run the post-hook binary with the stored message path as its sole argument.
///
/// A non-zero exit code is reported as an error so the pull stops.
fn run_post_hook(cmd: &str, message_path: &Path) -> anyhow::Result<()> {
    let status = std::process::Command::new(cmd)
        .arg(message_path)
        .status()
        .map_err(|e| anyhow::anyhow!("failed to run post-hook '{}': {}", cmd, e))?;
    if !status.success() {
        anyhow::bail!(
            "post-hook '{}' failed ({:?}) for {}",
            cmd,
            status.code(),
            message_path.display()
        );
    }
    Ok(())
}

/// Run the pre-hook binary, feeding the raw message on stdin and returning its
/// stdout as the final message to store.
///
/// Returns `Ok(None)` when the hook produces no output, meaning the message
/// should be skipped without failing. A non-zero exit code is reported as an
/// error so the pull stops and the message stays on the server.
fn run_pre_hook(cmd: &str, input: &[u8]) -> anyhow::Result<Option<Vec<u8>>> {
    let mut child = std::process::Command::new(cmd)
        .stdin(std::process::Stdio::piped())
        .stdout(std::process::Stdio::piped())
        .spawn()
        .map_err(|e| anyhow::anyhow!("failed to run pre-hook '{}': {}", cmd, e))?;
    {
        use std::io::Write;
        let stdin = child.stdin.as_mut().ok_or_else(|| {
            anyhow::anyhow!("pre-hook '{}' did not expose its stdin", cmd)
        })?;
        if let Err(e) = stdin.write_all(input) {
            if e.kind() != std::io::ErrorKind::BrokenPipe {
                return Err(e.into());
            }
        }
    }
    let output = child
        .wait_with_output()
        .map_err(|e| anyhow::anyhow!("failed to wait for pre-hook '{}': {}", cmd, e))?;
    if !output.status.success() {
        anyhow::bail!("pre-hook '{}' failed ({:?})", cmd, output.status.code());
    }
    if output.stdout.is_empty() {
        return Ok(None);
    }
    Ok(Some(output.stdout))
}

/// Deliver a single fetched message to the Maildir, applying the optional
/// pre-hook (the raw message on stdin; its stdout becomes the stored message;
/// no output skips it) and post-hook (the stored path as `$1`).
///
/// Returns `Ok(true)` when the message was stored, `Ok(false)` when the
/// pre-hook skipped it. A failing pre- or post-hook aborts with an error.
fn store_message(
    maildir: &Maildir,
    body: &[u8],
    uid: Option<u32>,
    pre_hook: Option<&str>,
    post_hook: Option<&str>,
) -> anyhow::Result<bool> {
    let final_body = match pre_hook {
        Some(hook) => match run_pre_hook(hook, body)? {
            Some(out) => out,
            None => {
                eprintln!("Skipped message by pre-hook '{hook}' (no output)");
                return Ok(false);
            }
        },
        None => body.to_vec(),
    };
    let path = match uid {
        Some(n) => maildir.deliver_with_uid(&final_body, Some(n))?,
        None => maildir.deliver(&final_body)?,
    };
    if let Some(hook) = post_hook {
        run_post_hook(hook, &path)?;
    }
    Ok(true)
}

/// Fetch messages from the selected mailbox and deliver them to the local
/// Maildir. With `all == false` only unseen messages are fetched; with `all ==
/// true` every message is fetched but those whose UID is already stored are
/// skipped. When `pre_hook` is set, it transforms each message before storage
/// (no output skips it without failing). When `post_hook` is set, it runs after
/// each delivered message and a non-zero exit aborts the fetch.
async fn fetch_and_store<S>(
    session: &mut S,
    maildir: &Maildir,
    mailbox: &str,
    all: bool,
    pre_hook: Option<&str>,
    post_hook: Option<&str>,
) -> anyhow::Result<()>
where
    S: MailboxOps,
{
    session.select(mailbox).await?;

    if all {
        let existing = maildir.existing_uids()?;
        let fetches = session.fetch_all().await?;

        let mut count = 0;
        for msg in &fetches {
            if msg.uid == 0 || existing.contains(&msg.uid) {
                continue;
            }
            if let Some(body) = &msg.body {
                if store_message(maildir, body, Some(msg.uid), pre_hook, post_hook)? {
                    count += 1;
                }
            }
        }
        eprintln!("Fetched {count} new message(s) from {mailbox} (skipped {})", fetches.len() - count);
    } else {
        let ids = session.search_unseen().await?;
        if ids.is_empty() {
            eprintln!("No unseen messages in {mailbox}");
            return Ok(());
        }

        let fetches = session.fetch_ids(&ids).await?;
        let mut count = 0;
        for msg in &fetches {
            if let Some(body) = &msg.body {
                if store_message(maildir, body, None, pre_hook, post_hook)? {
                    count += 1;
                }
            }
        }
        eprintln!("Fetched {count} message(s) from {mailbox}");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    fn maildir_path() -> (tempfile::TempDir, Maildir) {
        let dir = tempfile::tempdir().unwrap();
        let maildir = Maildir::new(dir.path().to_path_buf());
        maildir.ensure_dirs().unwrap();
        (dir, maildir)
    }

    /// In-memory IMAP session mock. Scripts the responses each operation returns
    /// and records the mailbox passed to `select`.
    #[derive(Default)]
    struct MockSession {
        select_calls: Vec<String>,
        unseen: Vec<u32>,
        by_id: HashMap<u32, String>,
        all_messages: Vec<FetchedMessage>,
    }

    impl MailboxOps for MockSession {
        async fn select(&mut self, mailbox: &str) -> anyhow::Result<()> {
            self.select_calls.push(mailbox.to_string());
            Ok(())
        }

        async fn search_unseen(&mut self) -> anyhow::Result<Vec<u32>> {
            Ok(self.unseen.clone())
        }

        async fn fetch_all(&mut self) -> anyhow::Result<Vec<FetchedMessage>> {
            Ok(self.all_messages.clone())
        }

        async fn fetch_ids(&mut self, ids: &[u32]) -> anyhow::Result<Vec<FetchedMessage>> {
            Ok(ids
                .iter()
                .filter_map(|id| {
                    self.by_id.get(id).map(|b| FetchedMessage {
                        uid: *id,
                        body: Some(b.as_bytes().to_vec()),
                    })
                })
                .collect())
        }
    }

    #[test]
    fn merge_config_cli_overrides_config() {
        let config = PullConfig {
            server: Some("cfg.example.com".to_string()),
            port: Some(143),
            username: Some("cfg-user".to_string()),
            password: Some("cfg-pass".to_string()),
            password_command: Some("echo cfg-cmd".to_string()),
            mailbox: Some("cfg-mailbox".to_string()),
            ssl: Some(false),
            all: Some(false),
            pre_hook: Some("/cfg/pre-hook.sh".to_string()),
            post_hook: Some("/cfg/hook.sh".to_string()),
        };
        let args = PullArgs {
            server: Some("cli.example.com".to_string()),
            port: Some(1143),
            username: Some("cli-user".to_string()),
            password: Some("cli-pass".to_string()),
            password_command: Some("echo cli-cmd".to_string()),
            mailbox: Some("cli-mailbox".to_string()),
            ssl: Some(true),
            all: true,
            pre_hook: Some("/cli/pre-hook.sh".to_string()),
            post_hook: Some("/cli/hook.sh".to_string()),
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.server.as_deref(), Some("cli.example.com"));
        assert_eq!(merged.port, Some(1143));
        assert_eq!(merged.username.as_deref(), Some("cli-user"));
        assert_eq!(merged.password.as_deref(), Some("cli-pass"));
        assert_eq!(merged.password_command.as_deref(), Some("echo cli-cmd"));
        assert_eq!(merged.mailbox.as_deref(), Some("cli-mailbox"));
        assert_eq!(merged.ssl, Some(true));
        assert_eq!(merged.all, Some(true));
        assert_eq!(merged.pre_hook.as_deref(), Some("/cli/pre-hook.sh"));
        assert_eq!(merged.post_hook.as_deref(), Some("/cli/hook.sh"));
    }

    #[test]
    fn merge_config_falls_back_to_config() {
        let config = PullConfig {
            server: Some("cfg.example.com".to_string()),
            port: Some(993),
            username: Some("user".to_string()),
            mailbox: Some("Archive".to_string()),
            all: Some(true),
            ..Default::default()
        };
        let merged = merge_config(config, PullArgs {
            server: None,
            port: None,
            username: None,
            password: None,
            password_command: None,
            mailbox: None,
            ssl: None,
            all: false,
            pre_hook: None,
            post_hook: None,
        });
        assert_eq!(merged.server.as_deref(), Some("cfg.example.com"));
        assert_eq!(merged.port, Some(993));
        assert_eq!(merged.mailbox.as_deref(), Some("Archive"));
        assert_eq!(merged.all, Some(true));
    }

    #[tokio::test]
    async fn run_requires_server() {
        let res = run(PullConfig::default(), PullArgs {
            server: None,
            username: Some("u".to_string()),
            ..Default::default()
        }, PathBuf::new()).await;
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("server is required"));
    }

    #[tokio::test]
    async fn run_requires_username() {
        let res = run(PullConfig::default(), PullArgs {
            server: Some("imap.example.com".to_string()),
            username: None,
            ..Default::default()
        }, PathBuf::new()).await;
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("username is required"));
    }

    #[test]
    fn resolve_password_prefers_explicit() {
        let cfg = PullConfig {
            password: Some("secret".to_string()),
            password_command: Some("echo never-used".to_string()),
            ..Default::default()
        };
        assert_eq!(resolve_password(&cfg.password, &cfg.password_command, "IMAP", "user").unwrap(), "secret");
    }

    #[test]
    fn resolve_password_runs_command() {
        let cfg = PullConfig {
            password: None,
            password_command: Some("printf 'from-cmd\\nextra\\n'".to_string()),
            ..Default::default()
        };
        assert_eq!(resolve_password(&cfg.password, &cfg.password_command, "IMAP", "user").unwrap(), "from-cmd");
    }

    #[test]
    fn run_password_command_failure_errors() {
        let res = run_password_command("exit 3");
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("password command exited with error"));
    }

    #[test]
    fn run_password_command_empty_output_errors() {
        let res = run_password_command("printf ''");
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("produced no output"));
    }

    #[tokio::test]
    async fn fetch_and_store_unseen_delivers_messages() {
        let (dir, maildir) = maildir_path();
        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", false, None, None).await.unwrap();

        assert_eq!(session.select_calls, vec!["INBOX"]);
        let delivered = maildir.list_messages().unwrap();
        assert_eq!(delivered.len(), 2, "both unseen messages must be stored");
        let content = std::fs::read(&delivered[0]).unwrap();
        assert!(content.starts_with(b"Subject: one"), "{:?}", content);
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_no_unseen_delivers_nothing() {
        let (dir, maildir) = maildir_path();
        let mut session = MockSession {
            unseen: vec![],
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", false, None, None).await.unwrap();

        assert!(maildir.list_messages().unwrap().is_empty());
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_all_skips_existing_uids() {
        let (dir, maildir) = maildir_path();
        maildir.deliver_with_uid(b"already stored", Some(10)).unwrap();

        let mut session = MockSession {
            all_messages: vec![
                FetchedMessage { uid: 11, body: Some(b"Subject: new\n\nnew message".to_vec()) },
                FetchedMessage { uid: 10, body: Some(b"already stored".to_vec()) },
            ],
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", true, None, None).await.unwrap();

        let stored = maildir.list_messages().unwrap();
        assert_eq!(stored.len(), 2, "existing + new = 2 files");
        let uids = maildir.existing_uids().unwrap();
        assert_eq!(uids, vec![10, 11], "new message was delivered with its UID 11");
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_all_skips_missing_uid() {
        let (dir, maildir) = maildir_path();
        let mut session = MockSession {
            all_messages: vec![FetchedMessage { uid: 0, body: Some(b"no uid".to_vec()) }],
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", true, None, None).await.unwrap();

        assert!(maildir.list_messages().unwrap().is_empty(), "uid 0 must be skipped");
        drop(dir);
    }

    fn write_executable(path: &std::path::Path, script: &str) {
        std::fs::write(path, script).unwrap();
        let mut perms = std::fs::metadata(path).unwrap().permissions();
        std::os::unix::fs::PermissionsExt::set_mode(&mut perms, 0o755);
        std::fs::set_permissions(path, perms).unwrap();
    }

    #[tokio::test]
    async fn fetch_and_store_runs_post_hook_per_message() {
        let (dir, maildir) = maildir_path();
        let log = dir.path().join("hooks.log");
        let hook = dir.path().join("hook.sh");
        write_executable(
            &hook,
            &format!("#!/bin/sh\necho \"$1\" >> \"{}\"\n", log.display()),
        );

        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", false, None, Some(hook.to_str().unwrap())).await.unwrap();

        let delivered = maildir.list_messages().unwrap();
        assert_eq!(delivered.len(), 2);
        let log = std::fs::read_to_string(&log).unwrap();
        let logged: Vec<&str> = log.lines().collect();
        assert_eq!(logged.len(), 2, "post-hook runs once per delivered message");
        for path in &delivered {
            assert!(logged.contains(&path.to_str().unwrap()), "hook received each message path");
        }
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_stops_on_post_hook_failure() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("hook.sh");
        write_executable(&hook, "#!/bin/sh\nexit 3\n");

        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        let res = fetch_and_store(&mut session, &maildir, "INBOX", false, None, Some(hook.to_str().unwrap())).await;
        assert!(res.is_err(), "post-hook failure must abort the pull");
        let err = res.unwrap_err().to_string();
        assert!(err.contains("post-hook"), "{err}");
        assert!(err.contains("Some(3)"), "{err}");
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_stops_immediately_on_post_hook_failure() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("hook.sh");
        write_executable(&hook, "#!/bin/sh\n[ \"$1\" != \"nonexistent\" ] || exit 0\nexit 1\n");

        let mut session = MockSession {
            unseen: vec![1, 2, 3],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
                (3, "Subject: three\n\nbody three".to_string()),
            ]),
            ..Default::default()
        };

        let res = fetch_and_store(&mut session, &maildir, "INBOX", false, None, Some(hook.to_str().unwrap())).await;
        assert!(res.is_err(), "a failing post-hook must stop further fetching");
        // The first message is stored; the failure aborts before the rest.
        let stored = maildir.list_messages().unwrap();
        assert!(stored.len() < 3, "pull must stop after the first hook failure");
        drop(dir);
    }

    #[test]
    fn merge_config_cli_overrides_config_post_hook() {
        let config = PullConfig {
            post_hook: Some("/cfg/hook.sh".to_string()),
            ..Default::default()
        };
        let args = PullArgs {
            post_hook: Some("/cli/hook.sh".to_string()),
            ..Default::default()
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.post_hook.as_deref(), Some("/cli/hook.sh"));

        let merged = merge_config(PullConfig::default(), PullArgs::default());
        assert_eq!(merged.post_hook, None);
    }

    #[test]
    fn merge_config_cli_overrides_config_pre_hook() {
        let config = PullConfig {
            pre_hook: Some("/cfg/pre-hook.sh".to_string()),
            ..Default::default()
        };
        let args = PullArgs {
            pre_hook: Some("/cli/pre-hook.sh".to_string()),
            ..Default::default()
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.pre_hook.as_deref(), Some("/cli/pre-hook.sh"));

        let merged = merge_config(PullConfig::default(), PullArgs::default());
        assert_eq!(merged.pre_hook, None);
    }

    #[test]
    fn run_pre_hook_transforms_content() {
        let (dir, _maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(
            &hook,
            "#!/bin/sh\nprintf 'X-PreHooked: yes\\n'; cat\n",
        );
        let out = run_pre_hook(hook.to_str().unwrap(), b"Subject: one\n\nbody").unwrap();
        let out = out.unwrap();
        assert!(out.starts_with(b"X-PreHooked: yes\nSubject: one"), "{:?}", out);
        assert!(out.ends_with(b"\nbody"), "{:?}", out);
        drop(dir);
    }

    #[test]
    fn run_pre_hook_empty_output_returns_none() {
        let (dir, _maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nexit 0\n");
        let out = run_pre_hook(hook.to_str().unwrap(), b"Subject: one\n\nbody").unwrap();
        assert!(out.is_none(), "empty stdout must skip the message");
        drop(dir);
    }

    #[test]
    fn run_pre_hook_failure_errors() {
        let (dir, _maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nprintf 'partial' >&2\nexit 7\n");
        let res = run_pre_hook(hook.to_str().unwrap(), b"Subject: one\n\nbody");
        assert!(res.is_err(), "a failing pre-hook must abort the pull");
        let err = res.unwrap_err().to_string();
        assert!(err.contains("pre-hook"), "{err}");
        assert!(err.contains("Some(7)"), "{err}");
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_runs_pre_hook_per_message() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nprintf 'X-Hook: yes\\n'; cat\n");

        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", false, Some(hook.to_str().unwrap()), None).await.unwrap();

        let delivered = maildir.list_messages().unwrap();
        assert_eq!(delivered.len(), 2, "both messages stored through the pre-hook");
        for path in &delivered {
            let content = std::fs::read(path).unwrap();
            assert!(content.starts_with(b"X-Hook: yes\n"), "{:?}", content);
        }
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_skips_message_when_pre_hook_has_no_output() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nexit 0\n");

        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        let res = fetch_and_store(&mut session, &maildir, "INBOX", false, Some(hook.to_str().unwrap()), None).await;
        assert!(res.is_ok(), "a silent pre-hook must skip, not fail: {:?}", res.err());
        assert!(
            maildir.list_messages().unwrap().is_empty(),
            "no message may be stored when the pre-hook produces no output"
        );
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_stops_on_pre_hook_failure_and_stores_nothing() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nexit 5\n");

        let mut session = MockSession {
            unseen: vec![1, 2],
            by_id: HashMap::from([
                (1, "Subject: one\n\nbody one".to_string()),
                (2, "Subject: two\n\nbody two".to_string()),
            ]),
            ..Default::default()
        };

        let res = fetch_and_store(&mut session, &maildir, "INBOX", false, Some(hook.to_str().unwrap()), None).await;
        assert!(res.is_err(), "a failing pre-hook must abort the pull");
        let err = res.unwrap_err().to_string();
        assert!(err.contains("pre-hook"), "{err}");
        assert!(err.contains("Some(5)"), "{err}");
        assert!(
            maildir.list_messages().unwrap().is_empty(),
            "nothing may be stored when the pre-hook fails"
        );
        drop(dir);
    }

    #[tokio::test]
    async fn fetch_and_store_all_skipped_by_pre_hook_keeps_uid_unrecorded() {
        let (dir, maildir) = maildir_path();
        let hook = dir.path().join("pre-hook.sh");
        write_executable(&hook, "#!/bin/sh\nexit 0\n");

        let mut session = MockSession {
            all_messages: vec![FetchedMessage { uid: 42, body: Some(b"Subject: skip\n\nbody".to_vec()) }],
            ..Default::default()
        };

        fetch_and_store(&mut session, &maildir, "INBOX", true, Some(hook.to_str().unwrap()), None).await.unwrap();

        assert!(
            maildir.existing_uids().unwrap().is_empty(),
            "a skipped message's UID must not be recorded so a later --all pull retries it"
        );
        drop(dir);
    }
}
