//! Compose a new email draft.
//!
//! Prompts for recipient, sender, and subject (unless provided via CLI options or
//! config), opens `$EDITOR` on a temporary file, and saves the finished draft to the
//! drafts directory. Supports `--no-include-headers`, `--recover-last-draft`,
//! `--pre-compose-hook`, `--post-compose-hook`, `--template`, and `--message`.

use crate::config::ComposeConfig;
use crate::contacts::{self, Contact};
use rustyline::completion::Completer;
use rustyline::hint::Hinter;
use rustyline::highlight::Highlighter;
use rustyline::validate::Validator;
use rustyline::{CompletionType, Config, Context, Editor, Helper};
use std::io::{IsTerminal, Write};
use std::path::{Path, PathBuf};

/// How headers are handled when the draft is saved after editing.
enum SaveHeaders {
    /// Use the edited content as-is (template already carries its headers).
    AsIs,
    /// Prepend the given header block if the edited content has no header separator.
    Prepend(String),
    /// Prepend the automatic headers, overriding same-named headers the user typed,
    /// while keeping any other headers the user added during editing.
    PrependOverride(Vec<(String, String)>),
}

/// Line-ending style for the final draft.
#[derive(Clone, Copy)]
enum LineEnding {
    Lf,
    Crlf,
}

/// Normalize all line endings in `s` to LF (for comfortable editing).
fn to_lf(s: &str) -> String {
    s.replace("\r\n", "\n")
}

/// Convert all LF line endings in `s` to CRLF (to match the original template).
fn to_crlf(s: &str) -> String {
    s.replace('\n', "\r\n")
}

/// Command-line arguments for the compose subcommand.
pub struct ComposeArgs {
    /// Maildir to scan for autocompletion contacts.
    pub maildir_path: Option<String>,
    /// Recipient email address.
    pub to: Option<String>,
    /// Sender email address.
    pub from: Option<String>,
    /// Email subject.
    pub subject: Option<String>,
    /// Directory for draft emails.
    pub drafts_path: Option<String>,
    /// Omit headers from the temporary editor file.
    pub no_include_headers: bool,
    /// Recover the last draft and continue editing.
    pub recover_last_draft: bool,
    /// Binaries to run before composing (receives temp eml path), repeatable.
    pub pre_compose_hook: Vec<String>,
    /// Binaries to run after composing and before saving (receives temp eml path), repeatable.
    pub post_compose_hook: Vec<String>,
    /// Path to an EML template file used as the initial draft.
    pub template: Option<String>,
    /// Full message content taken directly from the command line (no editor).
    pub message: Option<String>,
}

/// Merge CLI arguments over the loaded config; CLI flags win.
fn merge_config(config: ComposeConfig, args: ComposeArgs) -> ComposeConfig {
    ComposeConfig {
        maildir_path: args.maildir_path.or(config.maildir_path),
        to: args.to.or(config.to),
        from: args.from.or(config.from),
        subject: args.subject.or(config.subject),
        drafts_path: args.drafts_path.or(config.drafts_path),
        no_include_headers: if args.no_include_headers { Some(true) } else { config.no_include_headers },
        recover_last_draft: if args.recover_last_draft { Some(true) } else { config.recover_last_draft },
        pre_compose_hook: if args.pre_compose_hook.is_empty() { config.pre_compose_hook } else { Some(args.pre_compose_hook) },
        post_compose_hook: if args.post_compose_hook.is_empty() { config.post_compose_hook } else { Some(args.post_compose_hook) },
        template: args.template.or(config.template),
        message: args.message.or(config.message),
    }
}

/// Prompt the user for input on stderr and read a line from stdin.
fn prompt(msg: &str) -> String {
    let mut input = String::new();
    eprint!("{msg}: ");
    std::io::stdout().flush().ok();
    std::io::stdin().read_line(&mut input).ok();
    input.trim().to_string()
}

/// rustyline helper providing TAB autocompletion over a contact list.
struct ContactHelper {
    contacts: Vec<Contact>,
}

impl Helper for ContactHelper {}

impl Completer for ContactHelper {
    type Candidate = String;

    fn complete(
        &self,
        line: &str,
        pos: usize,
        _ctx: &Context<'_>,
    ) -> rustyline::Result<(usize, Vec<String>)> {
        let prefix = &line[..pos.min(line.len())];
        let candidates: Vec<String> = self
            .contacts
            .iter()
            .filter(|c| c.matches(prefix))
            .map(|c| c.formatted())
            .collect();
        Ok((0, candidates))
    }
}

impl Hinter for ContactHelper {
    type Hint = String;

    fn hint(&self, _line: &str, _pos: usize, _ctx: &Context<'_>) -> Option<String> {
        None
    }
}

impl Highlighter for ContactHelper {}

impl Validator for ContactHelper {}

/// Prompt for an address with TAB autocompletion when a contact list is
/// available and stdin is a terminal; otherwise fall back to a plain prompt.
fn prompt_address(msg: &str, contacts: &[Contact]) -> String {
    if contacts.is_empty() || !std::io::stdin().is_terminal() {
        return prompt(msg);
    }
    let config = Config::builder().completion_type(CompletionType::Circular).build();
    let mut editor = match Editor::<ContactHelper, rustyline::history::DefaultHistory>::with_config(config) {
        Ok(e) => e,
        Err(_) => return prompt(msg),
    };
    editor.set_helper(Some(ContactHelper { contacts: contacts.to_vec() }));
    let prompt_text = format!("{msg}: ");
    match editor.readline(&prompt_text) {
        Ok(line) => line.trim().to_string(),
        Err(rustyline::error::ReadlineError::Interrupted) => String::new(),
        Err(rustyline::error::ReadlineError::Eof) => String::new(),
        Err(_) => String::new(),
    }
}

/// Load the contact list from the configured maildir, using the cache under
/// the cache dir. A missing or unreadable maildir yields an empty list.
fn load_contacts(maildir_path: &Path, default_cache_dir: &Path) -> Vec<Contact> {
    let cache_file = default_cache_dir.join("contacts");
    contacts::load_or_scan(maildir_path, &cache_file)
}

/// Build the automatic header block for a fresh draft.
fn header_block(to: &str, from: &str, subject: &str, date_str: &str, msg_id: &str) -> String {
    format!("To: {to}\nFrom: {from}\nSubject: {subject}\nDate: {date_str}\nMessage-ID: <{msg_id}>\n\n")
}

/// Path to the most recently modified `.eml` file in `dir`.
fn last_draft(dir: &Path) -> Option<PathBuf> {
    let mut entries: Vec<_> = std::fs::read_dir(dir).ok()?
        .filter_map(|e| e.ok())
        .filter(|e| e.path().extension().map(|ext| ext == "eml").unwrap_or(false))
        .collect();
    entries.sort_by(|a, b| b.metadata().and_then(|m| m.modified()).ok()
        .cmp(&a.metadata().and_then(|m| m.modified()).ok()));
    entries.into_iter().next().map(|e| e.path())
}

/// Run a compose hook binary with the draft path as its sole argument.
fn run_hook(cmd: &str, draft_path: &Path) -> anyhow::Result<()> {
    let status = std::process::Command::new(cmd)
        .arg(draft_path.as_os_str())
        .status()
        .map_err(|e| anyhow::anyhow!("failed to run hook '{}': {}", cmd, e))?;
    if !status.success() {
        anyhow::bail!("hook '{}' failed ({:?})", cmd, status.code());
    }
    Ok(())
}

/// Returns true if `line` looks like a mail header (`Name:` with no leading space).
fn is_header_line(line: &str) -> bool {
    let line = line.trim_end_matches('\r');
    match line.find(':') {
        Some(i) if i > 0 => line[..i].chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_'),
        _ => false,
    }
}

/// Split raw message content into a header block and a body.
///
/// Parses the header block smartly: it runs from the first line until the first
/// blank line (LF or CRLF) or the first line that is neither a header nor a
/// continuation of one. Returns `(header_block, body)`; the header block has no
/// trailing separator and the body starts right where it was found (or is empty).
fn split_header_body(content: &str) -> (&str, &str) {
    let mut line_start: usize = 0;
    for line in content.split('\n') {
        let trimmed = line.trim_end_matches('\r');
        if trimmed.is_empty() {
            let header_end = line_start.saturating_sub(1);
            let body_start = line_start + line.len() + 1;
            return (&content[..header_end], &content[body_start..]);
        }
        let continuation = trimmed.starts_with(' ') || trimmed.starts_with('\t');
        if !is_header_line(trimmed) && !continuation {
            let header_end = line_start.saturating_sub(1);
            return (&content[..header_end], &content[line_start..]);
        }
        line_start += line.len() + 1;
    }
    (content, "")
}

/// Replace the given headers in `content`'s header block, keeping all other headers
/// (e.g. `Cc`, `Reply-To`, `X-*`) untouched.
///
/// The original `Date` header is preserved when it is not part of `overrides`. Any
/// of the overridden headers missing from `content` are appended after the existing
/// headers. The body is kept verbatim and always separated from the headers by a
/// blank line.
fn override_headers(content: &str, overrides: &[(&str, &str)]) -> String {
    let (header_text, body) = split_header_body(content);

    let mut remaining: Vec<(&str, &str)> = overrides.to_vec();
    let mut out: Vec<String> = Vec::new();
    let mut prev_replaced = false;

    for line in header_text.split('\n') {
        let line = line.trim_end_matches('\r');
        if line.is_empty() {
            continue;
        }
        if line.starts_with(' ') || line.starts_with('\t') {
            if !prev_replaced {
                out.push(line.to_string());
            }
            continue;
        }
        prev_replaced = false;
        if let Some(colon) = line.find(':') {
            let name = line[..colon].trim();
            if let Some(pos) = remaining.iter().position(|(n, _)| n.eq_ignore_ascii_case(name)) {
                let (_, value) = remaining.remove(pos);
                out.push(format!("{}: {}", name, value));
                prev_replaced = true;
                continue;
            }
        }
        out.push(line.to_string());
    }

    for (name, value) in remaining {
        out.push(format!("{}: {}", name, value));
    }

    let headers = out.join("\n");
    if body.is_empty() {
        format!("{headers}\n\n")
    } else {
        format!("{headers}\n\n{body}")
    }
}

/// Replace `To`, `From`, `Subject`, and `Message-ID` in a template's header block,
/// keeping all other headers (e.g. `Cc`, `Reply-To`, `X-*`) untouched.
///
/// The template's `Date` header is preserved as-is. Any of the overridden headers
/// missing from the template are appended after the existing headers. The body is
/// kept verbatim and always separated from the headers by a blank line.
fn set_headers(content: &str, to: &str, from: &str, subject: &str, msg_id: &str) -> String {
    let overrides: [(&str, &str); 4] = [
        ("To", to),
        ("From", from),
        ("Subject", subject),
        ("Message-ID", msg_id),
    ];
    override_headers(content, &overrides)
}

/// Extract the value of a header from a message's header block (case-insensitive).
///
/// Continuation lines are skipped; the value is the content after the colon on the
/// header's first line, trimmed. Returns `None` when the message has no header
/// block or the named header is absent.
fn header_value<'a>(content: &'a str, name: &str) -> Option<&'a str> {
    let (headers, _) = split_header_body(content);
    for line in headers.split('\n') {
        let line = line.trim_end_matches('\r');
        if line.starts_with(' ') || line.starts_with('\t') {
            continue;
        }
        if let Some(colon) = line.find(':') {
            if line[..colon].trim().eq_ignore_ascii_case(name) {
                return Some(line[colon + 1..].trim());
            }
        }
    }
    None
}

/// Return the body of a message, i.e. everything after the header block.
fn strip_headers(content: &str) -> String {
    split_header_body(content).1.to_string()
}

/// Split edited content into an optional header block and a trimmed body.
///
/// The leading block is treated as headers only when it is separated from the body
/// by a blank line and its first line looks like a header; otherwise the whole
/// content is treated as body text.
fn split_edited_headers(content: &str) -> (Option<String>, String) {
    if let Some(i) = content.find("\n\n") {
        let head = &content[..i];
        if is_header_line(head.lines().next().unwrap_or("")) {
            return (Some(head.to_string()), content[i + 2..].trim().to_string());
        }
    }
    (None, content.trim().to_string())
}

/// Build the final draft by prepending the automatic headers and keeping any other
/// headers the user added during editing. Automatic headers override same-named
/// ones typed by the user.
fn prepend_override(content: &str, auto: &[(String, String)]) -> String {
    let (headers_block, body) = split_edited_headers(content);
    let auto_names: Vec<&str> = auto.iter().map(|(n, _)| n.as_str()).collect();
    let mut out: Vec<String> = auto.iter().map(|(n, v)| format!("{}: {}", n, v)).collect();
    if let Some(block) = headers_block {
        let mut skip = false;
        for line in block.lines() {
            if line.starts_with(' ') || line.starts_with('\t') {
                if skip {
                    continue;
                }
                out.push(line.to_string());
                continue;
            }
            skip = false;
            if let Some(colon) = line.find(':') {
                let name = line[..colon].trim();
                if auto_names.iter().any(|n| n.eq_ignore_ascii_case(name)) {
                    skip = true;
                    continue;
                }
            }
            out.push(line.to_string());
        }
    }
    format!("{}\n\n{}", out.join("\n"), body)
}

/// Run the editor on `draft_path` and save the result according to `policy`.
///
/// If the editor leaves the file unchanged, the draft is aborted: no post hooks
/// run and nothing is saved. The unchanged baseline is the file content after the
/// pre-hooks (or `original` when it is given and `abort_if_unchanged` is false).
/// Discards the draft when the final body is empty. The final content is written
/// with `eol` line endings (e.g. CRLF when the template used them).
fn edit_and_save(draft_path: &Path, policy: SaveHeaders, eol: LineEnding, original: Option<&str>,
                 abort_if_unchanged: bool, pre_hooks: &[String], post_hooks: &[String]) -> anyhow::Result<()> {
    for cmd in pre_hooks {
        run_hook(cmd, draft_path)?;
    }

    let baseline: Option<String> = if abort_if_unchanged {
        std::fs::read_to_string(draft_path).ok()
    } else {
        original.map(str::to_string)
    };

    let editor = std::env::var("EDITOR").unwrap_or_else(|_| "vi".to_string());
    let status = std::process::Command::new("sh")
        .arg("-c")
        .arg(format!("{} {}", editor, draft_path.display()))
        .status()?;

    if !status.success() {
        std::fs::remove_file(draft_path)?;
        anyhow::bail!("editor exited with error ({:?}), draft discarded", status.code());
    }

    let content = std::fs::read_to_string(draft_path)?;

    if let Some(base) = baseline {
        if content == base {
            if abort_if_unchanged {
                std::fs::remove_file(draft_path)?;
                eprintln!("Draft unchanged, not saved");
            } else {
                eprintln!("Draft unchanged: {}", draft_path.display());
            }
            return Ok(());
        }
    }

    let final_content = match policy {
        SaveHeaders::AsIs => {
            let body = match content.find("\n\n") {
                Some(i) => content[i + 2..].trim(),
                None => content.trim(),
            };
            if body.is_empty() {
                std::fs::remove_file(draft_path)?;
                anyhow::bail!("draft is empty, discarded");
            }
            content
        }
        SaveHeaders::Prepend(block) => {
            let has_headers = content.contains("\n\n");
            let body = if has_headers {
                let header_end = content.find("\n\n").map(|i| i + 2).unwrap_or(0);
                content[header_end..].trim().to_string()
            } else {
                content.trim().to_string()
            };
            if body.is_empty() {
                std::fs::remove_file(draft_path)?;
                anyhow::bail!("draft is empty, discarded");
            }
            if has_headers {
                content
            } else {
                format!("{block}{body}\n")
            }
        }
        SaveHeaders::PrependOverride(auto) => {
            let (_, body) = split_edited_headers(&content);
            if body.is_empty() {
                std::fs::remove_file(draft_path)?;
                anyhow::bail!("draft is empty, discarded");
            }
            prepend_override(&content, &auto)
        }
    };

    let final_content = match eol {
        LineEnding::Lf => final_content,
        LineEnding::Crlf => to_crlf(&final_content),
    };

    std::fs::write(draft_path, &final_content)?;

    for cmd in post_hooks {
        run_hook(cmd, draft_path)?;
    }

    eprintln!("Draft saved: {}", draft_path.display());
    Ok(())
}

/// Compose a draft directly from a message string given on the command line.
///
/// No editor is launched. Headers present in the message are mixed with the
/// automatic ones: the automatic `To`/`From`/`Subject`/`Date`/`Message-ID`
/// override same-named headers in the message, while any other message headers
/// (e.g. `Cc`, `Reply-To`, `X-*`) are kept. A missing `To`/`From`/`Subject` is
/// taken from the message headers before prompting. Post-compose hooks still run
/// on the saved draft. Returns an error when the message body is empty.
fn compose_from_message(
    cfg: &ComposeConfig,
    message: &str,
    drafts_dir: &Path,
    contacts: &[Contact],
) -> anyhow::Result<()> {
    let message_lf = to_lf(message);
    let msg_to = header_value(&message_lf, "To");
    let msg_from = header_value(&message_lf, "From");
    let msg_subject = header_value(&message_lf, "Subject");

    let to = cfg.to.as_deref()
        .filter(|t| !t.trim().is_empty())
        .or(msg_to)
        .map(str::to_string)
        .unwrap_or_else(|| prompt_address("To", contacts));
    let from = cfg.from.as_deref()
        .filter(|f| !f.trim().is_empty())
        .or(msg_from)
        .map(str::to_string)
        .unwrap_or_else(|| prompt_address("From", contacts));
    let subject = cfg.subject.as_deref()
        .filter(|s| !s.trim().is_empty())
        .or(msg_subject)
        .map(str::to_string)
        .unwrap_or_else(|| prompt("Subject"));

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    let hostname = hostname();
    let msg_id = format!("{}.{}@{}", now, std::process::id(), hostname);
    let date_str = chrono::Local::now().format("%a, %d %b %Y %H:%M:%S %z").to_string();

    let auto_headers: Vec<(String, String)> = vec![
        ("To".to_string(), to),
        ("From".to_string(), from),
        ("Subject".to_string(), subject),
        ("Date".to_string(), date_str),
        ("Message-ID".to_string(), format!("<{msg_id}>")),
    ];
    let overrides: Vec<(&str, &str)> = auto_headers.iter().map(|(n, v)| (n.as_str(), v.as_str())).collect();

    let draft_path = drafts_dir.join(format!("{}.eml", now));
    let final_content = override_headers(&message_lf, &overrides);

    if split_header_body(&final_content).1.trim().is_empty() {
        anyhow::bail!("draft is empty, discarded");
    }

    std::fs::write(&draft_path, &final_content)?;
    for cmd in cfg.post_compose_hook.as_deref().unwrap_or_default() {
        run_hook(cmd, &draft_path)?;
    }

    eprintln!("Draft saved: {}", draft_path.display());
    Ok(())
}

/// Compose a new email draft and save it to the drafts directory.
pub fn run(config: ComposeConfig, args: ComposeArgs, default_data_dir: PathBuf) -> anyhow::Result<()> {
    let cli_message = args.message.is_some();
    let cli_template = args.template.is_some();

    let mut cfg = merge_config(config, args);
    crate::resolve_mutual_exclusion(
        cli_message,
        cli_template,
        &mut cfg.message,
        &mut cfg.template,
        "message",
        "template",
    )?;

    let drafts_dir = cfg
        .drafts_path
        .as_deref()
        .map(PathBuf::from)
        .unwrap_or_else(|| default_data_dir.join("drafts"));
    std::fs::create_dir_all(&drafts_dir)?;

    let maildir_path = cfg
        .maildir_path
        .as_deref()
        .map(PathBuf::from)
        .unwrap_or_else(|| default_data_dir.clone());
    let cache_dir = crate::config::cache_dir().unwrap_or_else(|_| default_data_dir.clone());

    // Contacts are only needed (and only used) when prompting interactively.
    let contacts: Vec<Contact> = if std::io::stdin().is_terminal() {
        load_contacts(&maildir_path, &cache_dir)
    } else {
        Vec::new()
    };

    if let Some(message) = &cfg.message {
        return compose_from_message(&cfg, message, &drafts_dir, &contacts);
    }

    if cfg.recover_last_draft.unwrap_or(false) {
        match last_draft(&drafts_dir) {
            Some(path) => {
                eprintln!("Recovering last draft: {}", path.display());
                let existing = std::fs::read_to_string(&path).ok();
                let hdr = existing.as_ref().and_then(|c|
                    c.find("\n\n").map(|i| c[..i + 2].to_string())
                );
                let pre = cfg.pre_compose_hook.as_deref().unwrap_or_default();
                let post = cfg.post_compose_hook.as_deref().unwrap_or_default();
                let policy = match hdr {
                    Some(h) => SaveHeaders::Prepend(h),
                    None => SaveHeaders::AsIs,
                };
                return edit_and_save(&path, policy, LineEnding::Lf, existing.as_deref(), false, pre, post);
            }
            None => anyhow::bail!("no drafts found in {}", drafts_dir.display()),
        }
    }

    let to = match cfg.to {
        Some(t) if !t.is_empty() => t,
        _ => prompt_address("To", &contacts),
    };
    let from = match cfg.from {
        Some(f) if !f.is_empty() => f,
        _ => prompt_address("From", &contacts),
    };
    let subject = match cfg.subject {
        Some(s) if !s.is_empty() => s,
        _ => prompt("Subject"),
    };

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    let hostname = hostname();
    let msg_id = format!("{}.{}@{}", now, std::process::id(), hostname);
    let date_str = chrono::Local::now().format("%a, %d %b %Y %H:%M:%S %z").to_string();

    let auto_headers: Vec<(String, String)> = vec![
        ("To".to_string(), to),
        ("From".to_string(), from),
        ("Subject".to_string(), subject),
        ("Date".to_string(), date_str),
        ("Message-ID".to_string(), format!("<{msg_id}>")),
    ];

    let no_hdr = cfg.no_include_headers.unwrap_or(false);
    let draft_path = drafts_dir.join(format!("{}.eml", now));
    let pre = cfg.pre_compose_hook.as_deref().unwrap_or_default();
    let post = cfg.post_compose_hook.as_deref().unwrap_or_default();

    let (initial, policy, eol) = match &cfg.template {
        Some(template) => {
            let tpl = std::fs::read_to_string(template)
                .map_err(|e| anyhow::anyhow!("failed to read template '{}': {}", template, e))?;
            let eol = if tpl.contains("\r\n") { LineEnding::Crlf } else { LineEnding::Lf };
            if no_hdr {
                let body = strip_headers(&tpl);
                let content = if body.is_empty() { "\n".to_string() } else { to_lf(&body) };
                (content, SaveHeaders::PrependOverride(auto_headers), eol)
            } else {
                let replaced = set_headers(&tpl, &auto_headers[0].1, &auto_headers[1].1,
                                           &auto_headers[2].1, &msg_id);
                (to_lf(&replaced), SaveHeaders::AsIs, eol)
            }
        }
        None => {
            let headers = header_block(&auto_headers[0].1, &auto_headers[1].1,
                                       &auto_headers[2].1, &auto_headers[3].1, &msg_id);
            if no_hdr {
                ("\n".to_string(), SaveHeaders::Prepend(headers), LineEnding::Lf)
            } else {
                (headers.clone(), SaveHeaders::Prepend(headers), LineEnding::Lf)
            }
        }
    };

    std::fs::write(&draft_path, &initial)?;
    let abort_if_unchanged = cfg.template.is_some();
    edit_and_save(&draft_path, policy, eol, None, abort_if_unchanged, pre, post)
}

/// Best-effort hostname of the current machine.
fn hostname() -> String {
    std::fs::read_to_string("/proc/sys/kernel/hostname")
        .ok()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "localhost".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_headers_replaces_and_keeps() {
        let tpl = "To: old@x.com\nCc: cc@x.com\nSubject: Old subject\nFrom: oldfrom@x.com\nDate: Wed, 1 Jan 2025 00:00:00 +0000\nMessage-ID: <old@x>\nX-Tag: keepme\n\nHello world\n";
        let out = set_headers(tpl, "new@y.com", "me@z.com", "New subject", "<new@y>");
        assert_eq!(
            out,
            "To: new@y.com\nCc: cc@x.com\nSubject: New subject\nFrom: me@z.com\nDate: Wed, 1 Jan 2025 00:00:00 +0000\nMessage-ID: <new@y>\nX-Tag: keepme\n\nHello world\n"
        );
    }

    #[test]
    fn set_headers_appends_missing_override() {
        let tpl = "Cc: cc@x.com\n\nbody\n";
        let out = set_headers(tpl, "t@x", "f@x", "s", "<id@x>");
        assert!(out.starts_with("Cc: cc@x.com\nTo: t@x\nFrom: f@x\nSubject: s\nMessage-ID: <id@x>\n\nbody\n"), "{out}");
    }

    #[test]
    fn set_headers_adds_separator_when_body_missing() {
        let tpl = "To: a@x\nFrom: b@x";
        let out = set_headers(tpl, "t@x", "f@x", "s", "<id@x>");
        assert!(out.ends_with("\n\n"), "{out}");
        assert!(out.contains("Message-ID: <id@x>"));
    }

    #[test]
    fn set_headers_body_only_template_prepends_headers() {
        let tpl = "Just a body template.\n";
        let out = set_headers(tpl, "t@x", "f@x", "s", "<id@x>");
        assert_eq!(
            out,
            "To: t@x\nFrom: f@x\nSubject: s\nMessage-ID: <id@x>\n\nJust a body template.\n"
        );
    }

    #[test]
    fn set_headers_no_separator_keeps_headers_in_block() {
        let tpl = "To: old@x.com\nFrom: oldfrom@x.com\nBody without separator\n";
        let out = set_headers(tpl, "new@y.com", "me@z.com", "New subject", "<new@y>");
        assert_eq!(
            out,
            "To: new@y.com\nFrom: me@z.com\nSubject: New subject\nMessage-ID: <new@y>\n\nBody without separator\n"
        );
    }

    #[test]
    fn set_headers_crlf_template_is_normalized() {
        let tpl = "To: old@x.com\r\nCc: cc@x.com\r\nSubject: Old\r\nFrom: oldfrom@x.com\r\n\r\nBody CRLF.\r\n";
        let out = set_headers(tpl, "new@y.com", "me@z.com", "New subject", "<new@y>");
        assert_eq!(
            out,
            "To: new@y.com\nCc: cc@x.com\nSubject: New subject\nFrom: me@z.com\nMessage-ID: <new@y>\n\nBody CRLF.\r\n"
        );
    }

    #[test]
    fn set_headers_keeps_folded_headers() {
        let tpl = "To: a@x\nList-Unsubscribe:\n <https://unsub.example>\nSubject: Old\nFrom: oldfrom@x.com\n\nbody\n";
        let out = set_headers(tpl, "t@x", "f@x", "New s", "<id@x>");
        assert_eq!(
            out,
            "To: t@x\nList-Unsubscribe:\n <https://unsub.example>\nSubject: New s\nFrom: f@x\nMessage-ID: <id@x>\n\nbody\n"
        );
    }

    #[test]
    fn split_header_body_variants() {
        assert_eq!(split_header_body("To: a\n\nbody"), ("To: a", "body"));
        assert_eq!(split_header_body("To: a\r\n\r\nbody"), ("To: a\r", "body"));
        assert_eq!(split_header_body("To: a\nbody no sep"), ("To: a", "body no sep"));
        assert_eq!(split_header_body("just body"), ("", "just body"));
        assert_eq!(split_header_body("To: a\nFrom: b"), ("To: a\nFrom: b", ""));
    }

    #[test]
    fn strip_headers_variants() {
        assert_eq!(strip_headers("To: a\n\nBody text\n"), "Body text\n");
        assert_eq!(strip_headers("To: a\r\n\r\nBody CRLF\r\n"), "Body CRLF\r\n");
        assert_eq!(strip_headers("To: a\nBody no sep"), "Body no sep");
        assert_eq!(strip_headers("just body"), "just body");
    }

    #[test]
    fn line_ending_normalization() {
        assert_eq!(to_lf("a\r\nb\r\nc"), "a\nb\nc");
        assert_eq!(to_lf("a\nb"), "a\nb");
        assert_eq!(to_crlf("a\nb"), "a\r\nb");
        assert_eq!(to_crlf(&to_lf("a\r\nb\r\n")), "a\r\nb\r\n");
    }

    #[test]
    fn strip_headers_keeps_body() {
        assert_eq!(strip_headers("To: a\n\nBody text\n"), "Body text\n");
        assert_eq!(strip_headers("just body"), "just body");
    }

    #[test]
    fn split_edited_headers_detects_user_headers() {
        assert_eq!(split_edited_headers("Hello world"), (None, "Hello world".to_string()));
        assert_eq!(
            split_edited_headers("Cc: x@y\n\nBody"),
            (Some("Cc: x@y".to_string()), "Body".to_string())
        );
        assert_eq!(
            split_edited_headers("To: someone\n\nBody"),
            (Some("To: someone".to_string()), "Body".to_string())
        );
    }

    #[test]
    fn is_header_line_validation() {
        assert!(is_header_line("Cc: x"));
        assert!(is_header_line("X-Tag: y"));
        assert!(!is_header_line("Hello world"));
        assert!(!is_header_line(": no name"));
        assert!(!is_header_line(""));
    }

    #[test]
    fn prepend_override_overrides_and_keeps() {
        let auto: Vec<(String, String)> = vec![
            ("To".to_string(), "t@x".to_string()),
            ("From".to_string(), "f@x".to_string()),
        ];
        let content = "To: wrong@x\nCc: keep@x\n\nBody\n";
        let out = prepend_override(content, &auto);
        assert_eq!(out, "To: t@x\nFrom: f@x\nCc: keep@x\n\nBody");
    }

    #[test]
    fn prepend_override_plain_body() {
        let auto: Vec<(String, String)> = vec![("To".to_string(), "t@x".to_string())];
        assert_eq!(prepend_override("just body", &auto), "To: t@x\n\njust body");
    }

    /// Serializes tests that mutate process-global environment variables.
    static ENV_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    /// Acquire the environment test lock, ignoring poisoning from a panicking test.
    fn env_guard() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK.lock().unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    fn write_executable(path: &std::path::Path, script: &str) {
        std::fs::write(path, script).unwrap();
        let mut perms = std::fs::metadata(path).unwrap().permissions();
        std::os::unix::fs::PermissionsExt::set_mode(&mut perms, 0o755);
        std::fs::set_permissions(path, perms).unwrap();
    }

    fn compose_with_editor(drafts: &std::path::Path, tpl: &std::path::Path,
                           post_hooks: Vec<String>) {
        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: post_hooks,
            template: Some(tpl.to_str().unwrap().to_string()),
            message: None,
        };
        let res = run(ComposeConfig::default(), args, std::path::PathBuf::new());
        assert!(res.is_ok(), "run failed: {:?}", res);
    }

    fn compose_with_message(drafts: &std::path::Path, message: &str,
                            post_hooks: Vec<String>) -> PathBuf {
        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: post_hooks,
            template: None,
            message: Some(message.to_string()),
        };
        let res = run(ComposeConfig::default(), args, std::path::PathBuf::new());
        assert!(res.is_ok(), "run failed: {:?}", res);
        let entries: Vec<_> = std::fs::read_dir(drafts).unwrap().collect();
        assert_eq!(entries.len(), 1, "one draft must be saved");
        entries[0].as_ref().unwrap().path()
    }

    #[test]
    fn template_unchanged_editor_aborts_without_saving() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "To: a@x\nSubject: S\nFrom: b@x\n\nbody\n").unwrap();

        let editor = dir.join("editor.sh");
        write_executable(&editor, "#!/bin/sh\n:");
        let marker = dir.join("post-ran");
        let post = dir.join("post.sh");
        write_executable(&post, "#!/bin/sh\ntouch \"$POST_MARKER\"\n");
        std::env::set_var("EDITOR", editor.to_str().unwrap());
        std::env::set_var("POST_MARKER", marker.to_str().unwrap());

        compose_with_editor(&drafts, &tpl, vec![post.to_str().unwrap().to_string()]);

        assert!(!marker.exists(), "post hook must not run when draft is unchanged");
        assert_eq!(std::fs::read_dir(&drafts).unwrap().count(), 0, "draft must not be saved");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn template_changed_editor_saves_and_runs_post_hook() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "To: a@x\nSubject: S\nFrom: b@x\n\nbody\n").unwrap();

        let editor = dir.join("editor.sh");
        write_executable(&editor, "#!/bin/sh\necho appended >> \"$1\"\n");
        let marker = dir.join("post-ran");
        let post = dir.join("post.sh");
        write_executable(&post, "#!/bin/sh\ntouch \"$POST_MARKER\"\n");
        std::env::set_var("EDITOR", editor.to_str().unwrap());
        std::env::set_var("POST_MARKER", marker.to_str().unwrap());

        compose_with_editor(&drafts, &tpl, vec![post.to_str().unwrap().to_string()]);

        assert!(marker.exists(), "post hook must run when the draft changed");
        let saved: Vec<_> = std::fs::read_dir(&drafts).unwrap().collect();
        assert_eq!(saved.len(), 1, "one draft must be saved");
        let content = std::fs::read_to_string(saved[0].as_ref().unwrap().path()).unwrap();
        assert!(content.contains("appended"), "saved draft must contain the edit: {content}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn override_headers_replaces_keeps_and_appends() {
        let content = "Cc: keep@x\nTo: wrong@x\nSubject: Old\n\nBody\n";
        let overrides: [(&str, &str); 3] = [("To", "t@x"), ("Subject", "New"), ("From", "f@x")];
        assert_eq!(
            override_headers(content, &overrides),
            "Cc: keep@x\nTo: t@x\nSubject: New\nFrom: f@x\n\nBody\n"
        );
    }

    #[test]
    fn header_value_extraction() {
        let msg = "To: t@x\nCc: c@x\nSubject: Hi\n\nBody\n";
        assert_eq!(header_value(msg, "to"), Some("t@x"));
        assert_eq!(header_value(msg, "Subject"), Some("Hi"));
        assert_eq!(header_value(msg, "From"), None);
        assert_eq!(header_value("just body", "To"), None);
    }

    #[test]
    fn message_with_headers_mixes_and_overrides() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();

        let saved = compose_with_message(&drafts,
            "To: wrong@x\nCc: keep@x\nDate: Wed, 1 Jan 2025 00:00:00 +0000\n\nHello body\n",
            vec![]);

        let content = std::fs::read_to_string(&saved).unwrap();
        assert!(content.starts_with("To: t@x\nCc: keep@x\n"), "{content}");
        assert!(content.contains("From: f@x\n"), "{content}");
        assert!(content.contains("Subject: s\n"), "{content}");
        assert!(content.contains("\nMessage-ID: <"), "{content}");
        assert!(content.contains("\n\nHello body\n"), "{content}");
        assert!(!content.contains("wrong@x"), "automatic To must override the message: {content}");
        assert!(!content.contains("2025"), "automatic Date must override the message: {content}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_plain_body_prepends_all_headers() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();

        let saved = compose_with_message(&drafts, "Hello body\n", vec![]);

        let content = std::fs::read_to_string(&saved).unwrap();
        assert!(content.starts_with("To: t@x\nFrom: f@x\nSubject: s\nDate: "), "{content}");
        assert!(content.contains("\n\nHello body\n"), "{content}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_keeps_headers_without_separator() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();

        let saved = compose_with_message(&drafts, "To: wrong@x\nReply-To: reply@x\nBody no sep\n", vec![]);

        let content = std::fs::read_to_string(&saved).unwrap();
        assert!(content.starts_with("To: t@x\nReply-To: reply@x\nFrom: f@x\nSubject: s\n"), "{content}");
        assert!(content.contains("\n\nBody no sep\n"), "{content}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_empty_body_errors() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();

        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: None,
            message: Some("To: a@x\n\n".to_string()),
        };
        let res = run(ComposeConfig::default(), args, std::path::PathBuf::new());
        assert!(res.is_err(), "empty message body must error");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_runs_post_hooks() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();

        let marker = dir.join("post-ran");
        let post = dir.join("post.sh");
        write_executable(&post, "#!/bin/sh\ntouch \"$POST_MARKER\"\n");
        std::env::set_var("POST_MARKER", marker.to_str().unwrap());

        let saved = compose_with_message(&drafts, "Hello body\n",
                                        vec![post.to_str().unwrap().to_string()]);
        assert!(marker.exists(), "post hook must run for --message");
        assert!(std::fs::read_to_string(&saved).unwrap().contains("Hello body\n"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_and_template_conflict_errors() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "body\n").unwrap();

        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: Some(tpl.to_str().unwrap().to_string()),
            message: Some("body\n".to_string()),
        };
        let res = run(ComposeConfig::default(), args, std::path::PathBuf::new());
        assert!(res.is_err(), "--message and --template must be mutually exclusive");
        assert!(format!("{:?}", res).contains("mutually exclusive"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_cli_wins_over_template_config() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "To: t@x\nFrom: f@x\nSubject: s\n\nbody\n").unwrap();

        let config = ComposeConfig {
            template: Some(tpl.to_str().unwrap().to_string()),
            ..Default::default()
        };
        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: None,
            message: Some("cli body\n".to_string()),
        };
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_ok(), "CLI --message must win over config template: {res:?}");
        let entries: Vec<_> = std::fs::read_dir(&drafts).unwrap().collect();
        assert_eq!(entries.len(), 1, "message draft must be saved, template ignored");
        let saved = std::fs::read_to_string(entries[0].as_ref().unwrap().path()).unwrap();
        assert!(saved.contains("cli body\n"), "message body must be used: {saved:?}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn template_cli_wins_over_message_config() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "To: t@x\nFrom: f@x\nSubject: s\n\nbody\n").unwrap();

        let config = ComposeConfig {
            message: Some("config message\n".to_string()),
            ..Default::default()
        };
        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: Some(tpl.to_str().unwrap().to_string()),
            message: None,
        };
        let editor = dir.join("editor.sh");
        write_executable(&editor, "#!/bin/sh\necho appended >> \"$1\"\n");
        std::env::set_var("EDITOR", editor.to_str().unwrap());
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_ok(), "CLI --template must win over config message: {res:?}");
        let entries: Vec<_> = std::fs::read_dir(&drafts).unwrap().collect();
        assert_eq!(entries.len(), 1, "template draft must be saved, config message ignored");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn message_and_template_conflict_config_errors() {
        let _guard = env_guard();
        let dir = std::env::temp_dir().join(format!("fem-compose-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let drafts = dir.join("drafts");
        let tpl = dir.join("tpl.eml");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(&tpl, "body\n").unwrap();

        let config = ComposeConfig {
            template: Some(tpl.to_str().unwrap().to_string()),
            message: Some("body\n".to_string()),
            ..Default::default()
        };
        let args = ComposeArgs {
            maildir_path: None,
            to: Some("t@x".to_string()),
            from: Some("f@x".to_string()),
            subject: Some("s".to_string()),
            drafts_path: Some(drafts.to_str().unwrap().to_string()),
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: None,
            message: None,
        };
        let res = run(config, args, std::path::PathBuf::new());
        assert!(res.is_err(), "both set in config must stay mutually exclusive");
        assert!(format!("{:?}", res).contains("mutually exclusive"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn contact_helper_completes_by_name_and_email() {
        let helper = ContactHelper {
            contacts: vec![
                Contact { name: "Pepe Poco".into(), email: "pepepoco@gmail.com".into() },
                Contact { name: "Anna".into(), email: "anna@example.com".into() },
            ],
        };
        let history = rustyline::history::DefaultHistory::new();
        let ctx = rustyline::Context::new(&history);
        let (start, candidates) = helper.complete("pepe", 4, &ctx).unwrap();
        assert_eq!(start, 0);
        assert_eq!(candidates, vec!["\"Pepe Poco\" <pepepoco@gmail.com>"]);
        let (_, candidates) = helper.complete("ann", 3, &ctx).unwrap();
        assert_eq!(candidates, vec!["Anna <anna@example.com>"]);
        let (_, candidates) = helper.complete("zzz", 3, &ctx).unwrap();
        assert!(candidates.is_empty());
    }

    #[test]
    fn merge_config_maildir_path_cli_wins() {
        let config = ComposeConfig { maildir_path: Some("/cfg/maildir".into()), ..Default::default() };
        let args = ComposeArgs {
            maildir_path: Some("/cli/maildir".into()),
            to: None,
            from: None,
            subject: None,
            drafts_path: None,
            no_include_headers: false,
            recover_last_draft: false,
            pre_compose_hook: vec![],
            post_compose_hook: vec![],
            template: None,
            message: None,
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.maildir_path.as_deref(), Some("/cli/maildir"));
    }

    #[test]
    fn prompt_address_falls_back_when_contacts_empty() {
        // Non-interactive stdin: must not invoke rustyline, just read a line.
        // Simulate piped input by reading from stdin when it's not a terminal.
        if std::io::stdin().is_terminal() {
            return;
        }
        let result = prompt_address("To", &[]);
        assert_eq!(result, "");
    }
}
