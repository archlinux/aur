//! Send an email message over SMTP.
//!
//! Reads a raw email message from stdin (or from the drafts directory with
//! `--all-drafts`/`--last-draft`), connects to an SMTP server, and submits the
//! message. The envelope (sender and recipients) is derived from the message's
//! `From`/`To`/`Cc`/`Bcc` headers; a `Bcc` header is kept in the envelope but
//! stripped from the transmitted body so recipients do not see each other.
//!
//! Drafts that are confirmed as sent (the server accepted them) are removed
//! from the drafts directory; drafts that fail to send are left in place.

use crate::config::PushConfig;
use crate::contacts;
use crate::list;
use lettre::address::{Address, Envelope};
use lettre::transport::smtp::authentication::Credentials;
use lettre::transport::smtp::AsyncSmtpTransport;
use lettre::{AsyncTransport, Tokio1Executor};
use std::path::{Path, PathBuf};

/// Command-line arguments for the push subcommand.
#[derive(Default)]
pub struct PushArgs {
    /// SMTP server hostname.
    pub server: Option<String>,
    /// SMTP server port.
    pub port: Option<u16>,
    /// Username for SMTP authentication.
    pub username: Option<String>,
    /// Password for SMTP authentication (prompts if omitted).
    pub password: Option<String>,
    /// Command to get the SMTP password (reads first line of stdout).
    pub password_command: Option<String>,
    /// Use TLS (default: true).
    pub ssl: Option<bool>,
    /// Use STARTTLS to upgrade a plaintext connection (mutually exclusive with --ssl).
    pub starttls: Option<bool>,
    /// Directory containing draft emails.
    pub drafts_path: Option<String>,
    /// Send every draft in the drafts directory.
    pub all_drafts: bool,
    /// Send only the most recently modified draft.
    pub last_draft: bool,
}

impl From<PushArgs> for PushConfig {
    fn from(args: PushArgs) -> Self {
        PushConfig {
            server: args.server,
            port: args.port,
            username: args.username,
            password: args.password,
            password_command: args.password_command,
            ssl: args.ssl,
            starttls: args.starttls,
            drafts_path: args.drafts_path,
            all_drafts: if args.all_drafts { Some(true) } else { None },
            last_draft: if args.last_draft { Some(true) } else { None },
        }
    }
}

fn merge_config(config: PushConfig, args: PushArgs) -> PushConfig {
    let args_cfg: PushConfig = args.into();
    PushConfig {
        server: args_cfg.server.or(config.server),
        port: args_cfg.port.or(config.port),
        username: args_cfg.username.or(config.username),
        password: args_cfg.password.or(config.password),
        password_command: args_cfg.password_command.or(config.password_command),
        ssl: args_cfg.ssl.or(config.ssl),
        starttls: args_cfg.starttls.or(config.starttls),
        drafts_path: args_cfg.drafts_path.or(config.drafts_path),
        all_drafts: args_cfg.all_drafts.or(config.all_drafts),
        last_draft: args_cfg.last_draft.or(config.last_draft),
    }
}

/// Abstraction over an SMTP transport, so the send logic can be tested against
/// an in-memory mock instead of a real server.
#[allow(async_fn_in_trait)]
trait SmtpSender {
    /// Submit a raw message with the given envelope.
    async fn send_raw(&self, envelope: &Envelope, message: &[u8]) -> anyhow::Result<()>;
}

impl SmtpSender for AsyncSmtpTransport<Tokio1Executor> {
    async fn send_raw(&self, envelope: &Envelope, message: &[u8]) -> anyhow::Result<()> {
        AsyncTransport::send_raw(self, envelope, message).await?;
        Ok(())
    }
}

/// Parse the envelope addresses out of a raw message.
///
/// The sender comes from the `From` header and the recipients from the `To`,
/// `Cc`, and `Bcc` headers. Returns an error when there is no recipient.
fn envelope_from_message(message: &[u8]) -> anyhow::Result<Envelope> {
    let parsed = mailparse::parse_mail(message)
        .map_err(|e| anyhow::anyhow!("failed to parse message: {e}"))?;

    let from = list::header_value(&parsed.headers, "From")
        .and_then(|v| contacts::parse_addresses(&v).into_iter().next())
        .map(|c| c.email.parse::<Address>())
        .transpose()?;

    let mut to: Vec<Address> = Vec::new();
    for header in ["To", "Cc", "Bcc"] {
        if let Some(value) = list::header_value(&parsed.headers, header) {
            for contact in contacts::parse_addresses(&value) {
                to.push(contact.email.parse::<Address>()?);
            }
        }
    }

    Envelope::new(from, to).map_err(|e| anyhow::anyhow!("invalid message envelope: {e}"))
}

/// Remove the `Bcc` header (including any continuation lines) from a raw
/// message, leaving everything else byte-for-byte intact.
fn strip_bcc_header(message: &[u8]) -> Vec<u8> {
    let text = String::from_utf8_lossy(message);
    let mut out = String::new();
    let mut in_headers = true;
    let mut skipping = false;
    for line in text.split_inclusive('\n') {
        if !in_headers {
            out.push_str(line);
            continue;
        }
        let trimmed = line.trim_end_matches('\n').trim_end_matches('\r');
        if trimmed.is_empty() {
            in_headers = false;
            out.push_str(line);
            continue;
        }
        let continuation = trimmed.starts_with(' ') || trimmed.starts_with('\t');
        if continuation {
            if !skipping {
                out.push_str(line);
            }
            continue;
        }
        let is_bcc = trimmed
            .split_once(':')
            .map(|(key, _)| key.trim().eq_ignore_ascii_case("bcc"))
            .unwrap_or(false);
        skipping = is_bcc;
        if !is_bcc {
            out.push_str(line);
        }
    }
    out.into_bytes()
}

/// Send a single raw message: build the envelope, strip the `Bcc` header, and
/// submit it. Returns the transmitted body so callers can inspect it in tests.
async fn push_message<S>(sender: &S, message: &[u8]) -> anyhow::Result<Vec<u8>>
where
    S: SmtpSender,
{
    let envelope = envelope_from_message(message)?;
    let body = strip_bcc_header(message);
    sender.send_raw(&envelope, &body).await?;
    Ok(body)
}

/// Return the `.eml` files in `dir`, most recently modified first.
fn draft_files(dir: &Path) -> Vec<PathBuf> {
    let mut entries: Vec<_> = std::fs::read_dir(dir)
        .into_iter()
        .flatten()
        .filter_map(|e| e.ok())
        .filter(|e| e.path().extension().map(|ext| ext == "eml").unwrap_or(false))
        .collect();
    entries.sort_by(|a, b| {
        b.metadata()
            .and_then(|m| m.modified())
            .ok()
            .cmp(&a.metadata().and_then(|m| m.modified()).ok())
    });
    entries.into_iter().map(|e| e.path()).collect()
}

/// The most recently modified `.eml` file in `dir`, if any.
fn last_draft(dir: &Path) -> Option<PathBuf> {
    draft_files(dir).into_iter().next()
}

/// Send drafts from `dir` and remove the ones the server accepted. With
/// `all == true` every draft is sent; otherwise only the most recent one.
async fn push_drafts<S>(sender: &S, dir: &Path, all: bool) -> anyhow::Result<()>
where
    S: SmtpSender,
{
    let files = if all { draft_files(dir) } else { last_draft(dir).into_iter().collect() };
    if files.is_empty() {
        anyhow::bail!("no drafts found in {}", dir.display());
    }
    for path in &files {
        let raw = std::fs::read(path)
            .map_err(|e| anyhow::anyhow!("failed to read draft {}: {e}", path.display()))?;
        push_message(sender, &raw)
            .await
            .map_err(|e| anyhow::anyhow!("failed to send {}: {e:#}", path.display()))?;
        // Only remove the draft after the server confirmed the send.
        std::fs::remove_file(path)
            .map_err(|e| anyhow::anyhow!("failed to remove sent draft {}: {e}", path.display()))?;
        eprintln!("Sent and removed draft: {}", path.display());
    }
    Ok(())
}

/// Connect to an SMTP server and send the given raw messages.
pub async fn run(config: PushConfig, args: PushArgs, data_dir: PathBuf) -> anyhow::Result<()> {
    let cli_all = args.all_drafts;
    let cli_last = args.last_draft;
    let cli_ssl = args.ssl == Some(true);
    let cli_starttls = args.starttls == Some(true);
    let mut cfg = merge_config(config, args);
    crate::resolve_mutual_exclusion(
        cli_all,
        cli_last,
        &mut cfg.all_drafts,
        &mut cfg.last_draft,
        "all-drafts",
        "last-draft",
    )?;
    crate::resolve_mutual_exclusion(
        cli_ssl,
        cli_starttls,
        &mut cfg.ssl,
        &mut cfg.starttls,
        "ssl",
        "starttls",
    )?;

    let server = cfg
        .server
        .clone()
        .ok_or_else(|| anyhow::anyhow!("server is required (set in config or use --server)"))?;
    let username = cfg
        .username
        .clone()
        .ok_or_else(|| anyhow::anyhow!("username is required (set in config or use --username)"))?;
    let password = crate::pull::resolve_password(&cfg.password, &cfg.password_command, "SMTP", &username)?;

    let ssl = cfg.ssl.unwrap_or(true);
    let starttls = cfg.starttls.unwrap_or(false);
    let port = cfg.port.unwrap_or(if starttls {
        587
    } else if ssl {
        465
    } else {
        25
    });

    let builder = if starttls {
        AsyncSmtpTransport::<Tokio1Executor>::starttls_relay(&server)?.port(port)
    } else if ssl {
        AsyncSmtpTransport::<Tokio1Executor>::relay(&server)?.port(port)
    } else {
        AsyncSmtpTransport::<Tokio1Executor>::builder_dangerous(&server).port(port)
    };
    let transport = builder.credentials(Credentials::new(username, password)).build();

    let drafts_dir = cfg
        .drafts_path
        .as_deref()
        .map(PathBuf::from)
        .unwrap_or_else(|| data_dir.join("drafts"));

    if cfg.all_drafts.unwrap_or(false) {
        push_drafts(&transport, &drafts_dir, true).await?;
        return Ok(());
    }
    if cfg.last_draft.unwrap_or(false) {
        push_drafts(&transport, &drafts_dir, false).await?;
        return Ok(());
    }

    let mut raw = Vec::new();
    std::io::Read::read_to_end(&mut std::io::stdin(), &mut raw)?;
    if raw.is_empty() {
        anyhow::bail!("no message received on stdin");
    }
    push_message(&transport, &raw).await?;
    eprintln!("Message sent via {server}:{port}");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, Mutex};

    /// A recorded submission: the envelope and the transmitted body.
    type SentRecord = (Envelope, Vec<u8>);

    /// In-memory SMTP sender mock: records every envelope + body submitted.
    #[derive(Default, Clone)]
    struct MockSender {
        sent: Arc<Mutex<Vec<SentRecord>>>,
    }

    #[allow(async_fn_in_trait)]
    impl SmtpSender for MockSender {
        async fn send_raw(&self, envelope: &Envelope, message: &[u8]) -> anyhow::Result<()> {
            self.sent.lock().unwrap().push((envelope.clone(), message.to_vec()));
            Ok(())
        }
    }

    fn raw_message() -> Vec<u8> {
        b"From: Alice <alice@example.com>\r\nTo: Bob <bob@example.com>\r\nCc: carol@example.com\r\nSubject: Hi\r\n\r\nhello".to_vec()
    }

    #[test]
    fn merge_config_cli_overrides_config() {
        let config = PushConfig {
            server: Some("cfg.example.com".to_string()),
            port: Some(25),
            username: Some("cfg-user".to_string()),
            password: Some("cfg-pass".to_string()),
            password_command: Some("echo cfg-cmd".to_string()),
            ssl: Some(false),
            starttls: Some(true),
            drafts_path: Some("/cfg/drafts".to_string()),
            all_drafts: Some(true),
            ..Default::default()
        };
        let args = PushArgs {
            server: Some("cli.example.com".to_string()),
            port: Some(465),
            username: Some("cli-user".to_string()),
            password: Some("cli-pass".to_string()),
            password_command: Some("echo cli-cmd".to_string()),
            ssl: Some(true),
            starttls: Some(false),
            drafts_path: Some("/cli/drafts".to_string()),
            all_drafts: false,
            last_draft: true,
        };
        let merged = merge_config(config, args);
        assert_eq!(merged.server.as_deref(), Some("cli.example.com"));
        assert_eq!(merged.port, Some(465));
        assert_eq!(merged.username.as_deref(), Some("cli-user"));
        assert_eq!(merged.password.as_deref(), Some("cli-pass"));
        assert_eq!(merged.password_command.as_deref(), Some("echo cli-cmd"));
        assert_eq!(merged.ssl, Some(true));
        assert_eq!(merged.starttls, Some(false));
        assert_eq!(merged.drafts_path.as_deref(), Some("/cli/drafts"));
        // merge_config keeps both flags; mutual exclusion is enforced in run().
        assert_eq!(merged.all_drafts, Some(true));
        assert_eq!(merged.last_draft, Some(true));
    }

    #[test]
    fn merge_config_falls_back_to_config() {
        let config = PushConfig {
            server: Some("cfg.example.com".to_string()),
            port: Some(587),
            username: Some("user".to_string()),
            all_drafts: Some(true),
            ..Default::default()
        };
        let merged = merge_config(config, PushArgs::default());
        assert_eq!(merged.server.as_deref(), Some("cfg.example.com"));
        assert_eq!(merged.port, Some(587));
        assert_eq!(merged.all_drafts, Some(true));
    }

    #[test]
    fn envelope_uses_from_to_cc() {
        let env = envelope_from_message(&raw_message()).unwrap();
        assert_eq!(env.from().unwrap().to_string(), "alice@example.com");
        let to: Vec<String> = env.to().iter().map(|a| a.to_string()).collect();
        assert_eq!(to, vec!["bob@example.com", "carol@example.com"]);
    }

    #[test]
    fn envelope_includes_bcc_recipient() {
        let msg = b"From: a@example.com\r\nTo: b@example.com\r\nBcc: secret@example.com\r\n\r\nhi";
        let env = envelope_from_message(msg).unwrap();
        let to: Vec<String> = env.to().iter().map(|a| a.to_string()).collect();
        assert_eq!(to, vec!["b@example.com", "secret@example.com"]);
    }

    #[test]
    fn envelope_requires_recipient() {
        let msg = b"From: a@example.com\r\nSubject: x\r\n\r\nhi";
        assert!(envelope_from_message(msg).is_err());
    }

    #[test]
    fn envelope_requires_valid_addresses() {
        let msg = b"From: a@example.com\r\nTo: not-an-email\r\n\r\nhi";
        assert!(envelope_from_message(msg).is_err());
    }

    #[test]
    fn strip_bcc_removes_header_but_keeps_body() {
        let msg = b"From: a@example.com\r\nTo: b@example.com\r\nBcc: secret@example.com\r\n\r\nhello body";
        let stripped = strip_bcc_header(msg);
        let text = String::from_utf8(stripped).unwrap();
        assert!(!text.contains("Bcc:"), "{text}");
        assert!(text.contains("To: b@example.com"));
        assert!(text.ends_with("\r\n\r\nhello body"));
    }

    #[test]
    fn strip_bcc_handles_continuation_lines() {
        let msg = b"From: a@example.com\r\nBcc:\r\n secret@example.com,\r\n other@example.com\r\nTo: b@example.com\r\n\r\nhi";
        let stripped = strip_bcc_header(msg);
        let text = String::from_utf8(stripped).unwrap();
        assert!(!text.contains("Bcc"), "{text}");
        assert!(!text.contains("secret@example.com"), "{text}");
        assert!(text.contains("To: b@example.com"));
    }

    #[test]
    fn strip_bcc_ignores_bcc_in_body() {
        let msg = b"From: a@example.com\r\nTo: b@example.com\r\n\r\nBcc: not-a-header@example.com";
        let stripped = strip_bcc_header(msg);
        assert!(String::from_utf8(stripped).unwrap().contains("not-a-header@example.com"));
    }

    #[test]
    fn strip_bcc_leaves_non_bcc_messages_unchanged() {
        let msg = raw_message();
        assert_eq!(strip_bcc_header(&msg), msg);
    }

    #[tokio::test]
    async fn push_message_sends_envelope_and_stripped_body() {
        let sender = MockSender::default();
        let body = push_message(&sender, &raw_message()).await.unwrap();
        let sent = sender.sent.lock().unwrap();
        assert_eq!(sent.len(), 1);
        assert_eq!(sent[0].0.from().unwrap().to_string(), "alice@example.com");
        assert_eq!(body, raw_message(), "no Bcc present, body passes through");
    }

    #[tokio::test]
    async fn push_message_strips_bcc_from_submitted_body() {
        let sender = MockSender::default();
        let msg = b"From: a@example.com\r\nTo: b@example.com\r\nBcc: secret@example.com\r\n\r\nhi";
        let body = push_message(&sender, msg).await.unwrap();
        let sent = sender.sent.lock().unwrap();
        assert_eq!(sent.len(), 1);
        assert!(!String::from_utf8(body.clone()).unwrap().contains("Bcc"));
        assert_eq!(sent[0].1, body);
    }

    #[tokio::test]
    async fn push_message_fails_on_unparseable_message() {
        let sender = MockSender::default();
        assert!(push_message(&sender, b"garbage not an email").await.is_err());
        assert!(sender.sent.lock().unwrap().is_empty());
    }

    #[tokio::test]
    async fn push_all_drafts_sends_and_removes() {
        let dir = tempfile::tempdir().unwrap();
        let drafts = dir.path().join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();
        std::fs::write(drafts.join("1.eml"), b"From: a@example.com\r\nTo: one@example.com\r\n\r\n1").unwrap();
        std::fs::write(drafts.join("2.eml"), b"From: a@example.com\r\nTo: two@example.com\r\n\r\n2").unwrap();

        let sender = MockSender::default();
        push_drafts(&sender, &drafts, true).await.unwrap();

        assert_eq!(sender.sent.lock().unwrap().len(), 2);
        assert_eq!(std::fs::read_dir(&drafts).unwrap().count(), 0, "sent drafts removed");
    }

    #[tokio::test]
    async fn push_last_draft_sends_only_most_recent() {
        let dir = tempfile::tempdir().unwrap();
        let drafts = dir.path().join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();
        let old = drafts.join("1.eml");
        std::fs::write(&old, b"From: a@example.com\r\nTo: one@example.com\r\n\r\nold").unwrap();
        let new = drafts.join("2.eml");
        std::fs::write(&new, b"From: a@example.com\r\nTo: two@example.com\r\n\r\nnew").unwrap();
        // Make 2.eml clearly newer.
        let mtime = std::time::SystemTime::now() + std::time::Duration::from_secs(10);
        let _ = std::fs::FileTimes::new().set_modified(mtime);
        let f = std::fs::File::options().write(true).open(&new).unwrap();
        f.set_times(std::fs::FileTimes::new().set_modified(mtime)).unwrap();

        let sender = MockSender::default();
        push_drafts(&sender, &drafts, false).await.unwrap();

        let sent = sender.sent.lock().unwrap();
        assert_eq!(sent.len(), 1);
        assert_eq!(sent[0].0.to()[0].to_string(), "two@example.com");
        assert!(old.exists(), "only the last draft is removed");
        assert!(!new.exists(), "the sent last draft is removed");
    }

    #[tokio::test]
    async fn push_drafts_no_drafts_errors() {
        let dir = tempfile::tempdir().unwrap();
        let drafts = dir.path().join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();
        let sender = MockSender::default();
        assert!(push_drafts(&sender, &drafts, true).await.is_err());
    }

    #[tokio::test]
    async fn push_drafts_keeps_draft_on_send_failure() {
        let dir = tempfile::tempdir().unwrap();
        let drafts = dir.path().join("drafts");
        std::fs::create_dir_all(&drafts).unwrap();
        let path = drafts.join("1.eml");
        std::fs::write(&path, b"garbage").unwrap();

        struct FailingSender;
        #[allow(async_fn_in_trait)]
        impl SmtpSender for FailingSender {
            async fn send_raw(&self, _envelope: &Envelope, _message: &[u8]) -> anyhow::Result<()> {
                anyhow::bail!("server rejected");
            }
        }

        assert!(push_drafts(&FailingSender, &drafts, true).await.is_err());
        assert!(path.exists(), "failed draft must not be removed");
    }

    #[tokio::test]
    async fn run_all_drafts_and_last_draft_conflict() {
        let res = run(
            PushConfig::default(),
            PushArgs { server: Some("s".into()), username: Some("u".into()), all_drafts: true, last_draft: true, ..Default::default() },
            PathBuf::new(),
        )
        .await;
        assert!(res.is_err());
        assert!(format!("{:?}", res).contains("mutually exclusive"));
    }

    #[tokio::test]
    async fn run_ssl_and_starttls_conflict() {
        let res = run(
            PushConfig::default(),
            PushArgs { server: Some("s".into()), username: Some("u".into()), ssl: Some(true), starttls: Some(true), ..Default::default() },
            PathBuf::new(),
        )
        .await;
        assert!(res.is_err());
        assert!(format!("{:?}", res).contains("mutually exclusive"));
    }

    #[tokio::test]
    async fn run_requires_server() {
        let res = run(PushConfig::default(), PushArgs { username: Some("u".into()), ..Default::default() }, PathBuf::new()).await;
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("server is required"));
    }

    #[tokio::test]
    async fn run_requires_username() {
        let res = run(PushConfig::default(), PushArgs { server: Some("s".into()), ..Default::default() }, PathBuf::new()).await;
        assert!(res.is_err());
        assert!(res.unwrap_err().to_string().contains("username is required"));
    }
}
