//! TOML configuration loading and per-subcommand settings.
//!
//! The config file lives at `$XDG_CONFIG_HOME/fem/fem.toml` (falling back to
//! `$HOME/.fem/fem.toml`) and has one section per subcommand (`[pull]`,
//! `[push]`, `[list]`, `[show]`, `[cat]`, `[compose]`, `[find]`). Every config
//! key maps to a CLI option in its subcommand; command-line flags always win.
//! Also provides the XDG data directory (Maildir root and drafts) and cache
//! directory (contact autocompletion cache) helpers.

use serde::Deserialize;
use std::collections::HashMap;
use std::path::PathBuf;

fn config_file_path() -> Option<PathBuf> {
    if let Some(config_dir) = dirs::config_dir() {
        let path = config_dir.join("fem").join("fem.toml");
        if path.exists() {
            return Some(path);
        }
    }
    let home = dirs::home_dir()?;
    let path = home.join(".fem").join("fem.toml");
    if path.exists() {
        return Some(path);
    }
    None
}

/// Resolve the XDG data directory: `$XDG_DATA_HOME/fem`, falling back to
/// `$HOME/.fem`. This is the Maildir root and the default drafts location.
pub fn data_dir() -> anyhow::Result<PathBuf> {
    if let Some(data_dir) = dirs::data_dir() {
        let path = data_dir.join("fem");
        return Ok(path);
    }
    if let Some(home) = dirs::home_dir() {
        return Ok(home.join(".fem"));
    }
    anyhow::bail!("could not determine data directory: set XDG_DATA_HOME or ensure HOME is set");
}

/// Resolve the XDG cache directory: `$XDG_CACHE_HOME/fem`, falling back to
/// `$HOME/.cache/fem`. Used for derived data such as the contact cache.
pub fn cache_dir() -> anyhow::Result<PathBuf> {
    if let Some(cache_dir) = dirs::cache_dir() {
        return Ok(cache_dir.join("fem"));
    }
    if let Some(home) = dirs::home_dir() {
        return Ok(home.join(".cache").join("fem"));
    }
    anyhow::bail!("could not determine cache directory: set XDG_CACHE_HOME or ensure HOME is set");
}

/// The top-level configuration, with one section per subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct Config {
    #[serde(default)]
    pub pull: PullConfig,
    #[serde(default)]
    pub push: PushConfig,
    #[serde(default)]
    pub list: ListConfig,
    #[serde(default)]
    pub show: ShowConfig,
    #[serde(default)]
    pub cat: CatConfig,
    #[serde(default)]
    pub compose: ComposeConfig,
    #[serde(default)]
    pub find: FindConfig,
    #[serde(default)]
    pub tag: TagConfig,
}

/// Settings for the `pull` (IMAP) subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct PullConfig {
    pub server: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    pub password: Option<String>,
    /// Command to run to get the IMAP password (reads first line of stdout)
    pub password_command: Option<String>,
    pub mailbox: Option<String>,
    pub ssl: Option<bool>,
    /// Fetch all emails, not just unseen ones (default: false)
    pub all: Option<bool>,
    /// Binary/script to run before each message is stored. The raw message is
    /// fed to it on stdin and its stdout becomes the final message to store; no
    /// output skips the message, and a non-zero exit stops the pull
    pub pre_hook: Option<String>,
    /// Binary/script to run after each message is stored (receives the message
    /// path as `$1`; a non-zero exit stops the pull)
    pub post_hook: Option<String>,
}

/// Settings for the `push` (SMTP) subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct PushConfig {
    pub server: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    pub password: Option<String>,
    /// Command to run to get the SMTP password (reads first line of stdout)
    pub password_command: Option<String>,
    /// Use implicit SSL/TLS (default: true)
    pub ssl: Option<bool>,
    /// Use STARTTLS to upgrade the connection (mutually exclusive with ssl)
    pub starttls: Option<bool>,
    /// Directory containing draft emails
    pub drafts_path: Option<String>,
    /// Send every draft in the drafts directory (default: false)
    pub all_drafts: Option<bool>,
    /// Send only the most recently modified draft (default: false)
    pub last_draft: Option<bool>,
}

/// Settings for the `list` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct ListConfig {
    pub maildir_path: Option<String>,
    /// Maximum number of emails to display (default: 25)
    pub limit: Option<usize>,
    /// Number of emails to skip before displaying (default: 0)
    pub offset: Option<usize>,
    /// Output format: table, json, table-raw, tsv (default: table)
    pub format: Option<String>,
    /// Comma-separated list of fields to display.
    /// Valid fields: number, flags, date, from, to, subject, size
    pub table_fields: Option<String>,
    /// Character(s) for the new/unread flag (default: N)
    pub flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    pub flag_attachment: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    pub flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    pub flag_signed: Option<String>,
    /// Character(s) for the reply flag (default: R)
    pub flag_reply: Option<String>,
    /// Character(s) for the tag flag (default: T)
    pub flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    pub date_format: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    pub order_by: Option<String>,
    /// Disable reply threading (default: false)
    pub no_thread: Option<bool>,
}

/// Settings for the `show` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct ShowConfig {
    pub maildir_path: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    pub order_by: Option<String>,
    /// Disable reply threading (default: false)
    pub no_thread: Option<bool>,
    /// Character(s) for the new/unread flag (default: N)
    pub flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    pub flag_attachment: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    pub flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    pub flag_signed: Option<String>,
    /// Character(s) for the reply flag (default: R)
    pub flag_reply: Option<String>,
    /// Character(s) for the tag flag (default: T)
    pub flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    pub date_format: Option<String>,
    /// Comma-separated headers to show (default: From,To,Subject,List-Unsubscribe,Date)
    pub headers_show: Option<String>,
    /// Comma-separated headers to hide (mutually exclusive with headers_show)
    pub headers_hide: Option<String>,
    /// Show raw email without any processing
    pub raw: Option<bool>,
    /// Multipart type preference pairs (comma-separated): preferred,fallback
    pub multipart_preference: Option<Vec<String>>,
    /// Disable multipart type preference, show all parts
    pub no_multipart_preference: Option<bool>,
    /// Disable colored output
    pub no_color: Option<bool>,
    /// Force colored output even when piped
    pub force_color: Option<bool>,
    /// Color spec for header keys (bgcolor,fgcolor,modifier)
    pub color_header_key: Option<String>,
    /// Color spec for header values (bgcolor,fgcolor,modifier)
    pub color_header_value: Option<String>,
    /// Color spec for part separators (bgcolor,fgcolor,modifier)
    pub color_part_separator: Option<String>,
    /// Color spec for handler info messages (bgcolor,fgcolor,modifier)
    pub color_handler_info: Option<String>,
    /// Color spec for handler stderr messages on success (bgcolor,fgcolor,modifier)
    pub color_handler_error: Option<String>,
    /// Multipart MIME type handlers: maps content-type to shell command
    #[serde(default)]
    pub multipart_handle: Option<HashMap<String, String>>,
    /// Wrap output width (0 = no wrap, default: 100)
    pub wrap: Option<usize>,
}

/// Settings for the `cat` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct CatConfig {
    /// Remove the email signature from output (from the --  delimiter)
    pub hide_signature: Option<bool>,
    /// Collapse consecutive citation lines (> ...) into a single marker
    pub collapse_citation: Option<bool>,
    /// Color regex pairs (flat: spec1,re1,spec2,re2,...)
    pub color_regex: Option<Vec<String>>,
    /// Disable colored output
    pub no_color: Option<bool>,
    /// Force colored output even when piped
    pub force_color: Option<bool>,
}

/// Settings for the `find` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct FindConfig {
    pub maildir_path: Option<String>,
    /// Sub-folder to search (a maildir under the data directory)
    pub folder: Option<String>,
    /// Regex matched against the whole raw message (corresponds to the PATTERN argument)
    pub pattern: Option<String>,
    /// Header criteria (NAME=REGEX, repeatable)
    pub header: Option<Vec<String>>,
    /// Regex matched against the decoded text body
    pub body: Option<String>,
    /// Only emails on or after this date (inclusive)
    pub since: Option<String>,
    /// Only emails on or before this date (inclusive)
    pub until: Option<String>,
    /// Maximum number of emails to display (default: 25)
    pub limit: Option<usize>,
    /// Number of emails to skip before displaying (default: 0)
    pub offset: Option<usize>,
    /// Output format: table, json, table-raw, tsv (default: table)
    pub format: Option<String>,
    /// Comma-separated list of fields to display
    pub table_fields: Option<String>,
    /// Character(s) for the new/unread flag (default: N)
    pub flag_new: Option<String>,
    /// Character(s) for the attachment flag (default: A)
    pub flag_attachment: Option<String>,
    /// Character(s) for the encrypted flag (default: E)
    pub flag_encrypted: Option<String>,
    /// Character(s) for the PGP/MIME signature flag (default: S)
    pub flag_signed: Option<String>,
    /// Character(s) for the reply flag (default: R)
    pub flag_reply: Option<String>,
    /// Character(s) for the tag flag (default: T)
    pub flag_tagged: Option<String>,
    /// Date/time format string (chrono strftime syntax, default: %Y-%m-%d %H:%M:%S)
    pub date_format: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    pub order_by: Option<String>,
    /// Disable reply threading (default: false)
    pub no_thread: Option<bool>,
    /// Only match emails carrying this label (as set by `fem tag`)
    pub label: Option<String>,
}

/// Settings for the `tag` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct TagConfig {
    pub maildir_path: Option<String>,
    /// Label to attach to the email (required unless given on the CLI)
    pub label: Option<String>,
    /// Sort order: field:direction (e.g. date:desc, from:asc). Default: date:desc
    pub order_by: Option<String>,
    /// Disable reply threading (default: false)
    pub no_thread: Option<bool>,
}

/// Settings for the `compose` subcommand.
#[derive(Debug, Default, Deserialize)]
pub struct ComposeConfig {
    /// Maildir to scan for autocompletion contacts (defaults to data dir)
    pub maildir_path: Option<String>,
    /// Default recipient email address
    pub to: Option<String>,
    /// Default sender email address
    pub from: Option<String>,
    /// Default subject line
    pub subject: Option<String>,
    /// Directory for draft emails
    pub drafts_path: Option<String>,
    /// Omit headers from the temporary editor file
    pub no_include_headers: Option<bool>,
    /// Recover the last draft and continue editing
    pub recover_last_draft: Option<bool>,
    /// Binaries to run before composing (receives temp eml path), repeatable
    pub pre_compose_hook: Option<Vec<String>>,
    /// Binaries to run after composing and before saving (receives temp eml path), repeatable
    pub post_compose_hook: Option<Vec<String>>,
    /// Path to an EML template file used as the initial draft. Its To/From/Subject
    /// and Message-ID headers are replaced; other headers are kept
    pub template: Option<String>,
    /// Full message content taken directly from the command line (no editor).
    /// Headers in the message are mixed with the automatic ones. Mutually
    /// exclusive with template; if one of the two is given on the command
    /// line it takes precedence and the config value is ignored
    pub message: Option<String>,
}

/// Load the configuration from the first existing config file location.
///
/// Returns `Config::default()` when no config file is present.
pub fn load_config() -> anyhow::Result<Config> {
    let path = config_file_path();
    match path {
        Some(p) => {
            let content = std::fs::read_to_string(&p)?;
            Ok(toml::from_str(&content)?)
        }
        None => Ok(Config::default()),
    }
}
