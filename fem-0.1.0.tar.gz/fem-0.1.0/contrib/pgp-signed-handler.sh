#!/bin/bash
set -ue
# PGP/MIME signed message handler for fem show
# Processes multipart/signed content from stdin by extracting the signed
# content and detached signature, then verifying with gpg --verify.
#
# For multipart/signed, the signed data includes the MIME headers of part 1
# (Content-Type, Content-Transfer-Encoding, etc.), not just the body.
# Per RFC 3156 §4, the entire part 1 (headers + body) is signed.
#
# The signed content is always output on stdout for further handler
# processing (e.g., fem cat for rendering). Verification status is reported
# on fd 3 (success) or stderr (failure/error). Even if verification fails,
# content is still passed through.
#
# Exit codes: always 0 (content pass-through; status is informational)
#
# Usage in fem.toml:
#   [show.multipart_handle]
#   multipart/signed = "contrib/pgp-signed-handler.sh"

tmp=$(mktemp /tmp/fem-pgp-signed.XXXXXXXX)
tmp_content=$(mktemp /tmp/fem-pgp-content.XXXXXXXX)
tmp_sig=$(mktemp /tmp/fem-pgp-sig.XXXXXXXX)
trap 'rm -f "$tmp" "$tmp_content" "$tmp_sig"' EXIT
cat > "$tmp"

boundary=$(head -1 "$tmp" | tr -d '\r\n' | sed 's/^--//')
if [ -z "$boundary" ]; then
    echo "Error: couldn't detect MIME boundary" >&2
    exit 1
fi

# Extract signed content (part 1): all content between first and second
# boundaries, including MIME headers (RFC 3156 §4).
awk -v b="$boundary" '
BEGIN { ORS = "" }
$0 == "--"b || $0 == "--"b"\r" || $0 == "--"b"--" || $0 == "--"b"--\r" { part++; next }
part == 1 {
    sub(/\r$/, "")
    printf "%s", $0
    printf "%s", "\n"
}
' "$tmp" > "$tmp_content"

# Extract signature (part 2): body only (skip MIME headers)
awk -v b="$boundary" '
BEGIN { ORS = "" }
$0 == "--"b || $0 == "--"b"\r" { part++; next }
$0 == "--"b"--" || $0 == "--"b"--\r" { exit }
part == 2 {
    sub(/\r$/, "")
    if (!body) {
        if ($0 == "") { body = 1 }
        next
    }
    printf "%s", $0
    printf "%s", "\n"
}
' "$tmp" > "$tmp_sig"

# Run gpg once, capture output and exit code
set +e
gpg_out=$(gpg --verify "$tmp_sig" "$tmp_content" 2>&1)
gpg_rc=$?
set -e

if [ $gpg_rc -eq 0 ]; then
    echo "[Ok] PGP signature verified" >&3
    echo "$gpg_out" | grep -E 'Good|using|key' | sed 's/^gpg: //' | \
        while IFS= read -r line; do echo "  $line" >&3; done
elif echo "$gpg_out" | grep -qi "bad signature"; then
    echo "[Bad] PGP signature BAD — content may have been modified" >&2
    echo "$gpg_out" | grep -iE 'BAD|using|key' | sed 's/^gpg: //' | \
        while IFS= read -r line; do echo "  $line" >&2; done
else
    echo "$gpg_out" | grep -v '^$' | sed 's/^gpg: //' | \
        while IFS= read -r line; do echo "[?] $line" >&2; done
fi

# Signed content to stdout (always pass through)
cat "$tmp_content"
exit 0
