#!/bin/bash
set -ue
# PQP/MIME sign handler for fem compose --post-compose-hook
# Signs an email draft using pqp, producing a multipart/signed message
# per RFC 3156 but with application/pqp-* MIME subpart types.
#
# Usage:
#   fem compose --from me@example.com --post-compose-hook contrib/pqp-sign.sh
#
# The script reads From: from the EML headers to determine the signing key.
# The key search id is the email address of the From field; if the header
# also carries a display name ("Name <email>"), only the <email> part is used.
# Requires the pqp binary and the sender's secret key in the keyring.
#
# The signed content (part 1) includes the MIME headers per RFC 3156 §4, so
# the same header block that was signed is embedded in the multipart body.
# pqp always hashes with SHA3-256, so the micalg parameter is fixed.
# pqp cannot prompt for a passphrase without a TTY, so the secret key must
# be created with --no-passphrase (the --no-passphrase flag is passed to
# pqp sign to use the empty passphrase).

eml="$1"
if [ ! -f "$eml" ]; then
    echo "Error: file not found: $eml" >&2
    exit 1
fi

sender=$(grep -m1 '^From: ' "$eml" | sed 's/^From: //' | sed 's/.*<\(.*\)>.*/\1/' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
if [ -z "$sender" ]; then
    echo "Error: could not parse sender from From: header" >&2
    exit 1
fi

header_end=$(awk '/^$/ { print NR; exit }' "$eml")
if [ -z "$header_end" ]; then
    echo "Error: no blank line separating headers and body" >&2
    exit 1
fi

headers=$(sed -n "1,$((header_end - 1))p" "$eml")
body=$(sed -n "$((header_end + 1)),\$p" "$eml")

boundary="fem-pqp-signed-$$-$(date +%s)"
content_type="text/plain; charset=utf-8"
ct_line=$(echo "$headers" | grep -m1 '^Content-Type:' || true)
if [ -n "$ct_line" ]; then
    content_type=$(echo "$ct_line" | sed 's/^Content-Type:[[:space:]]*//i')
fi

tmp_sig=$(mktemp /tmp/fem-pqp-sign.XXXXXXXX)
tmp_signed=$(mktemp /tmp/fem-pqp-signed-content.XXXXXXXX)
trap 'rm -f "$tmp_sig" "$tmp_signed"' EXIT

# The signed content is the MIME part 1: its Content-Type header, a blank
# line, then the body. Detached-sign it with the sender's key, selected by
# the From: email address.
rm -f "$tmp_signed"
printf '%s\n\n%s\n' "Content-Type: $content_type" "$body" > "$tmp_signed"
rm -f "$tmp_sig"
set +e
pqp_out=$(pqp sign --no-passphrase -u "$sender" -o "$tmp_sig" "$tmp_signed" 2>&1)
pqp_rc=$?
set -e

if [ $pqp_rc -ne 0 ] || [ ! -s "$tmp_sig" ]; then
    echo "Error: pqp signing failed for sender: $sender" >&2
    echo "$pqp_out" | grep -v '^$' | sed 's/^/  /' >&2
    exit 1
fi

headers=$(echo "$headers" | grep -vi '^Content-Type:' || true)

{
    echo "$headers"
    echo "Content-Type: multipart/signed; protocol=\"application/pqp-signature\"; micalg=\"pqp-sha3-256\"; boundary=\"$boundary\""
    echo ""
    echo "--$boundary"
    cat "$tmp_signed"
    echo "--$boundary"
    echo "Content-Type: application/pqp-signature; name=\"signature.pqp\""
    echo "Content-Description: PQP digital signature"
    echo "Content-Disposition: attachment; filename=\"signature.pqp\""
    echo ""
    cat "$tmp_sig"
    echo ""
    echo "--$boundary--"
} > "$eml"
