#!/bin/bash
set -u
# PGP/MIME handler for fem show
# Processes multipart/encrypted content from stdin by extracting the PGP
# payload and piping it to gpg --decrypt.
#
# Output:
#   stdout — the decrypted MIME message (reprocessed by fem show handlers)
#   fd 3 — informational messages (decryption status, key info, signature)
#   stderr — error messages (gpg warnings/errors on success)
#
# On decryption failure, error messages go to stderr and non-zero exit.
#
# Usage in fem.toml:
#   [show.multipart_handle]
#   multipart/encrypted = "contrib/pgp-handler.sh"

tmp=$(mktemp /tmp/fem-pgp.XXXXXXXX)
tmp_out=$(mktemp /tmp/fem-pgp-out.XXXXXXXX)
tmp_err=$(mktemp /tmp/fem-pgp-err.XXXXXXXX)
trap 'rm -f "$tmp" "$tmp_out" "$tmp_err"' EXIT
cat > "$tmp"

boundary=$(head -1 "$tmp" | tr -d '\r\n' | sed 's/^--//')
if [ -z "$boundary" ]; then
    echo "Error: couldn't detect MIME boundary" >&2
    exit 1
fi

awk -v b="$boundary" '
  { sub(/\r$/, "") }
  $0 == "--"b || $0 == "--"b"--" { part++; body = 0; next }
  part == 2 {
    if ($0 ~ /^[A-Za-z-]+: / || $0 ~ /^Content-/) { next }
    if (!body && $0 ~ /^[[:space:]]*$/) { body = 1; next }
    if (body) print
  }
' "$tmp" | gpg --decrypt > "$tmp_out" 2> "$tmp_err" || true

rc=$?
err=$(cat "$tmp_err")
if [ $rc -ne 0 ]; then
    echo "$err" >&2
    exit $rc
fi

# Status messages to fd 3
echo "[decryption ok]" >&3
while IFS= read -r line; do
    clean=$(echo "$line" | sed 's/^gpg: //')
    echo " $clean" >&3
done <<< "$(echo "$err" | grep -iF 'encrypted')"
# Good sig status → fd 3, bad/unknown sig status → stderr
while IFS= read -r line; do
    clean=$(echo "$line" | sed 's/^gpg: //')
    echo "[sig] $clean" >&3
done <<< "$(echo "$err" | grep -iE 'signature|Good' | grep -viE 'BAD|Can.t check|No public key')"
while IFS= read -r line; do
    clean=$(echo "$line" | sed 's/^gpg: //')
    echo "[sig] $clean" >&2
done <<< "$(echo "$err" | grep -iE 'BAD|Can.t check|No public key')"

# Decrypted content to stdout
cat "$tmp_out"
