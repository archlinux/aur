#!/bin/bash
set -ue
# PGP/MIME encrypt handler for fem compose --post-compose-hook
# Encrypts an email body using GPG and the recipient's public key,
# producing a multipart/encrypted message per RFC 3156.
#
# Usage:
#   fem compose --to user@example.com --post-compose-hook contrib/pgp-encrypt.sh
#
# The script reads To: from the EML headers to determine the recipient key.
# Requires gpg and the recipient's public key in your keyring.

eml="$1"
if [ ! -f "$eml" ]; then
    echo "Error: file not found: $eml" >&2
    exit 1
fi

recipient=$(grep -m1 '^To: ' "$eml" | sed 's/^To: //' | sed 's/.*<\(.*\)>.*/\1/' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
if [ -z "$recipient" ]; then
    echo "Error: could not parse recipient from To: header" >&2
    exit 1
fi

header_end=$(awk '/^$/ { print NR; exit }' "$eml")
if [ -z "$header_end" ]; then
    echo "Error: no blank line separating headers and body" >&2
    exit 1
fi

headers=$(sed -n "1,$((header_end - 1))p" "$eml")
body=$(sed -n "$((header_end + 1)),\$p" "$eml")

boundary="fem-pgp-encrypted-$$-$(date +%s)"
content_type="text/plain; charset=utf-8"
ct_line=$(echo "$headers" | grep -m1 '^Content-Type:' || true)
if [ -n "$ct_line" ]; then
    content_type=$(echo "$ct_line" | sed 's/^Content-Type:[[:space:]]*//i')
fi

tmp_enc=$(mktemp /tmp/fem-pgp-enc.XXXXXXXX)
trap 'rm -f "$tmp_enc"' EXIT

rm -f "$tmp_enc"
set +e
gpg_out=$(printf '%s\n\n%s\n' "Content-Type: $content_type" "$body" | \
    gpg --batch --yes --encrypt --armor --recipient "$recipient" --trust-model always \
        -o "$tmp_enc" 2>&1)
gpg_rc=$?
set -e

if [ $gpg_rc -ne 0 ] || [ ! -s "$tmp_enc" ]; then
    echo "Error: GPG encryption failed for recipient: $recipient" >&2
    echo "$gpg_out" | grep -v '^$' | sed 's/^/  /' >&2
    exit 1
fi

headers=$(echo "$headers" | grep -vi '^Content-Type:' || true)

{
    echo "$headers"
    echo "Content-Type: multipart/encrypted; protocol=\"application/pgp-encrypted\"; boundary=\"$boundary\""
    echo ""
    echo "--$boundary"
    echo "Content-Type: application/pgp-encrypted"
    echo "Content-Description: PGP/MIME version identification"
    echo ""
    echo "Version: 1"
    echo ""
    echo "--$boundary"
    echo "Content-Type: application/octet-stream; name=\"encrypted.asc\""
    echo "Content-Description: OpenPGP encrypted message"
    echo "Content-Disposition: inline; filename=\"encrypted.asc\""
    echo ""
    cat "$tmp_enc"
    echo ""
    echo "--$boundary--"
} > "$eml"
