#!/bin/bash
set -u
# PQP/MIME handler for fem show
# Processes multipart/encrypted content from stdin by extracting the PQP
# payload and piping it to pqp decrypt.
#
# Output:
#   stdout — the decrypted MIME message (reprocessed by fem show handlers)
#   fd 3 — informational messages (decryption status)
#   stderr — error messages (pqp warnings/errors)
#
# On decryption failure, error messages go to stderr and non-zero exit.
#
# Usage in fem.toml:
#   [show.multipart_handle]
#   multipart/encrypted = "contrib/pqp-handler.sh"
#
# Requires the pqp binary and the recipient's secret key in the keyring.
# pqp cannot prompt for a passphrase without a TTY, so the secret key must
# be created with --no-passphrase (the --no-passphrase flag is passed to
# pqp decrypt to use the empty passphrase).

tmp=$(mktemp /tmp/fem-pqp.XXXXXXXX)
tmp_out=$(mktemp /tmp/fem-pqp-out.XXXXXXXX)
tmp_err=$(mktemp /tmp/fem-pqp-err.XXXXXXXX)
trap 'rm -f "$tmp" "$tmp_out" "$tmp_err"' EXIT
cat > "$tmp"

boundary=$(head -1 "$tmp" | tr -d '\r\n' | sed 's/^--//')
if [ -z "$boundary" ]; then
    echo "Error: couldn't detect MIME boundary" >&2
    exit 1
fi

# Extract the PQP payload (part 2 body, after its MIME headers) and decrypt.
# pqp writes status to stdout and the decrypted bytes to -o, so stdout is
# discarded and the file is re-read below.
awk -v b="$boundary" '
  { sub(/\r$/, "") }
  $0 == "--"b || $0 == "--"b"--" { part++; body = 0; next }
  part == 2 {
    if ($0 ~ /^[A-Za-z-]+: / || $0 ~ /^Content-/) { next }
    if (!body && $0 ~ /^[[:space:]]*$/) { body = 1; next }
    if (body) printf "%s", $0
  }
' "$tmp" | pqp decrypt --no-passphrase -o "$tmp_out" >/dev/null 2> "$tmp_err"

rc=$?
err=$(cat "$tmp_err")
if [ $rc -ne 0 ]; then
    echo "$err" >&2
    exit $rc
fi

# Status messages to fd 3
echo "[decryption ok]" >&3
while IFS= read -r line; do
    [ -n "$line" ] && echo " $line" >&3
done <<< "$(echo "$err" | grep -v '^$')"

# Decrypted content to stdout
cat "$tmp_out"
