#!/bin/bash
set -ue
# PGP/MIME sign handler for fem compose --post-compose-hook
# Signs an email draft using GPG, producing a multipart/signed message
# per RFC 3156.
#
# Usage:
#   fem compose --from me@example.com --post-compose-hook contrib/pgp-sign.sh
#
# The script reads From: from the EML headers to determine the signing key.
# The key search id is the email address of the From field; if the header
# also carries a display name ("Name <email>"), only the <email> part is used.
# Requires gpg and the sender's secret key in your keyring.
#
# The signed content (part 1) includes the MIME headers per RFC 3156 §4, so
# the same header block that was signed is embedded in the multipart body.

eml="$1"
if [ ! -f "$eml" ]; then
    echo "Error: file not found: $eml" >&2
    exit 1
fi

sender=$(grep -m1 '^From: ' "$eml" | sed 's/^From: //' | sed 's/.*<\(.*\)>.*/\1/' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
if [ -z "$sender" ]; then
    echo "Error: could not parse sender from From: header" >&2
    exit 1
fi

header_end=$(awk '/^$/ { print NR; exit }' "$eml")
if [ -z "$header_end" ]; then
    echo "Error: no blank line separating headers and body" >&2
    exit 1
fi

headers=$(sed -n "1,$((header_end - 1))p" "$eml")
body=$(sed -n "$((header_end + 1)),\$p" "$eml")

boundary="fem-pgp-signed-$$-$(date +%s)"
content_type="text/plain; charset=utf-8"
ct_line=$(echo "$headers" | grep -m1 '^Content-Type:' || true)
if [ -n "$ct_line" ]; then
    content_type=$(echo "$ct_line" | sed 's/^Content-Type:[[:space:]]*//i')
fi

tmp_sig=$(mktemp /tmp/fem-pgp-sign.XXXXXXXX)
tmp_signed=$(mktemp /tmp/fem-pgp-signed-content.XXXXXXXX)
trap 'rm -f "$tmp_sig" "$tmp_signed"' EXIT

# The signed content is the MIME part 1: its Content-Type header, a blank
# line, then the body. Detached-sign it with the sender's key, selected by
# the From: email address.
rm -f "$tmp_signed"
printf '%s\n\n%s\n' "Content-Type: $content_type" "$body" > "$tmp_signed"
rm -f "$tmp_sig"
set +e
gpg_out=$(gpg --batch --yes --detach-sign --armor --local-user "$sender" \
    -o "$tmp_sig" "$tmp_signed" 2>&1)
gpg_rc=$?
set -e

if [ $gpg_rc -ne 0 ] || [ ! -s "$tmp_sig" ]; then
    echo "Error: GPG signing failed for sender: $sender" >&2
    echo "$gpg_out" | grep -v '^$' | sed 's/^/  /' >&2
    exit 1
fi

# The digest algorithm used for the signature, for the micalg parameter.
micalg=$(grep -m1 '^Hash:' "$tmp_sig" | sed 's/^Hash:[[:space:]]*//i' | tr '[:upper:]' '[:lower:]' || true)
case "$micalg" in
    sha512) micalg="pgp-sha512" ;;
    sha384) micalg="pgp-sha384" ;;
    sha256) micalg="pgp-sha256" ;;
    sha224) micalg="pgp-sha224" ;;
    sha1)   micalg="pgp-sha1" ;;
    ripemd160) micalg="pgp-ripemd160" ;;
    md5)    micalg="pgp-md5" ;;
    *)      micalg="pgp-sha256" ;;
esac

headers=$(echo "$headers" | grep -vi '^Content-Type:' || true)

{
    echo "$headers"
    echo "Content-Type: multipart/signed; protocol=\"application/pgp-signature\"; micalg=\"$micalg\"; boundary=\"$boundary\""
    echo ""
    echo "--$boundary"
    cat "$tmp_signed"
    echo "--$boundary"
    echo "Content-Type: application/pgp-signature; name=\"signature.asc\""
    echo "Content-Description: OpenPGP digital signature"
    echo "Content-Disposition: attachment; filename=\"signature.asc\""
    echo ""
    cat "$tmp_sig"
    echo "--$boundary--"
} > "$eml"
