#[test]
fn test_maildir_roundtrip() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");

    let msg = b"From: alice@example.com\nSubject: Hello\n\nTest body";

    // Deliver
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(msg).unwrap();

    // List
    let msgs = maildir.list_messages().unwrap();
    assert_eq!(msgs.len(), 1);

    // Verify content
    let content = std::fs::read(&msgs[0]).unwrap();
    assert_eq!(content, msg);
}

#[test]
fn test_config_data_dir_resolves() {
    let result = fem::config::data_dir();
    assert!(result.is_ok());
    let path = result.unwrap();
    assert!(path.to_string_lossy().contains("fem"));
}

#[test]
fn test_list_multiple_emails() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");

    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    maildir.deliver(b"From: a@x.com\nSubject: First\n\nBody 1").unwrap();
    maildir.deliver(b"From: b@x.com\nSubject: Second\n\nBody 2").unwrap();

    let msgs = maildir.list_messages().unwrap();
    assert_eq!(msgs.len(), 2);
}

#[test]
fn test_order_by_subject_asc() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    maildir.deliver(b"From: b@x.com\nSubject: Bravo\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: Alpha\nDate: Wed, 29 Jul 2026 11:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        order_by: Some("subject:asc".to_string()),
        ..Default::default()
    };
    let args = ListArgs {
        order_by: None,
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_order_by_date_desc_default() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    maildir.deliver(b"From: old@x.com\nSubject: Old\nDate: Wed, 28 Jul 2026 10:00:00 +0000\n\nBody").unwrap();
    maildir.deliver(b"From: new@x.com\nSubject: New\nDate: Wed, 29 Jul 2026 11:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig::default();
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_order_by_from_desc() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    maildir.deliver(b"From: alice@x.com\nSubject: A\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();
    maildir.deliver(b"From: bob@x.com\nSubject: B\nDate: Wed, 29 Jul 2026 11:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        order_by: Some("from:desc".to_string()),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_format_json() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: JSON test\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        format: Some("json".to_string()),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_format_table_raw() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: Raw\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        format: Some("table-raw".to_string()),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_format_tsv() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: TSV\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        format: Some("tsv".to_string()),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_format_default_is_table() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: Default\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig::default();
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_limit_default_shows_all_when_under_25() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: A\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();
    maildir.deliver(b"From: b@x.com\nSubject: B\nDate: Wed, 28 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig::default();
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_limit_1_shows_only_one() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: A\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody 1").unwrap();
    maildir.deliver(b"From: b@x.com\nSubject: B\nDate: Wed, 28 Jul 2026 10:00:00 +0000\n\nBody 2").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        limit: Some(1),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_offset_skips_first_email() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: First\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();
    maildir.deliver(b"From: b@x.com\nSubject: Second\nDate: Wed, 29 Jul 2026 11:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        offset: Some(1),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_offset_beyond_all_returns_empty() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();
    maildir.deliver(b"From: a@x.com\nSubject: Only\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nBody").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        offset: Some(5),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_order_by_size_asc() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    maildir.deliver(b"From: big@x.com\nSubject: Big\nDate: Wed, 29 Jul 2026 10:00:00 +0000\n\nLarge body content here for testing").unwrap();
    maildir.deliver(b"From: small@x.com\nSubject: Small\nDate: Wed, 29 Jul 2026 11:00:00 +0000\n\nHi").unwrap();

    use fem::list::{ListArgs, run};
    use fem::config::ListConfig;
    let cfg = ListConfig {
        order_by: Some("size:asc".to_string()),
        table_fields: Some("number,size,from".to_string()),
        ..Default::default()
    };
    let args = ListArgs::default();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run(cfg, args, maildir_path.clone()).unwrap();
    }));
    assert!(result.is_ok());
}

// ---------------------------------------------------------------------------
// fem-show integration tests
// ---------------------------------------------------------------------------

fn setup_show_maildir(dir: &tempfile::TempDir) -> std::path::PathBuf {
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    // Simple email (ID 1)
    maildir.deliver(b"From: alice@x.com\r\nTo: bob@x.com\r\nSubject: Simple\r\nDate: Wed, 29 Jul 2026 10:00:00 +0000\r\n\r\nHello world\r\n").unwrap();

    // Multipart email (ID 2)
    maildir.deliver(b"From: multi@x.com\r\nTo: bob@x.com\r\nSubject: Multi\r\nDate: Wed, 29 Jul 2026 11:00:00 +0000\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"==B==\"\r\n\r\n--==B==\r\nContent-Type: text/plain\r\n\r\nPlain part\r\n--==B==\r\nContent-Type: text/html\r\n\r\n<h1>HTML part</h1>\r\n--==B===--\r\n").unwrap();

    maildir_path
}

#[test]
fn test_show_simple() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        maildir_path: None,
        order_by: None,
        no_thread: false,
        flag_new: None,
        flag_attachment: None,
        flag_encrypted: None,
        flag_signed: None,
        flag_reply: None,
        flag_tagged: None,
        date_format: None,
        headers_show: None,
        headers_hide: None,
        multipart_handle: vec![],
        raw: false,
        multipart_preference: vec![],
        no_multipart_preference: false,
        no_color: false,
        force_color: false,
        color_header_key: None,
        color_header_value: None,
        color_part_separator: None,
        color_handler_info: None,
        color_handler_error: None,
        wrap: None,
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_headers_show() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        headers_show: Some("From,Subject".to_string()),
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_headers_hide() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        headers_hide: Some("To".to_string()),
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_raw() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        raw: true,
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_no_multipart_preference() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 2,
        no_multipart_preference: true,
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_out_of_range() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = setup_show_maildir(&dir);
    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 999,
        ..Default::default()
    };
    let result = fem::show::run(ShowConfig::default(), args, maildir_path);
    assert!(result.is_err());
}

#[test]
fn test_show_multipart_handler() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    // multipart/encrypted email
    maildir.deliver(b"From: pgp@x.com\r\nTo: bob@x.com\r\nSubject: Encrypted\r\nDate: Wed, 29 Jul 2026 12:00:00 +0000\r\nMIME-Version: 1.0\r\nContent-Type: multipart/encrypted; boundary=\"==B==\"\r\n\r\n--==B==\r\nContent-Type: application/pgp-encrypted\r\n\r\nVersion: 1\r\n--==B==\r\nContent-Type: application/octet-stream\r\n\r\n-----BEGIN PGP MESSAGE-----\r\ndGVzdA==\r\n-----END PGP MESSAGE-----\r\n--==B===--\r\n").unwrap();

    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        multipart_handle: vec!["multipart/encrypted=true".to_string()],
        no_multipart_preference: true,
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}

#[test]
fn test_show_multipart_handler_without_handler() {
    let dir = tempfile::tempdir().unwrap();
    let maildir_path = dir.path().join("maildir");
    let maildir = fem::maildir::Maildir::new(maildir_path.clone());
    maildir.ensure_dirs().unwrap();

    // multipart/encrypted email without handler (should use compound separator)
    maildir.deliver(b"From: pgp@x.com\r\nTo: bob@x.com\r\nSubject: Encrypted\r\nDate: Wed, 29 Jul 2026 12:00:00 +0000\r\nMIME-Version: 1.0\r\nContent-Type: multipart/encrypted; boundary=\"==B==\"\r\n\r\n--==B==\r\nContent-Type: application/pgp-encrypted\r\n\r\nVersion: 1\r\n--==B==\r\nContent-Type: application/octet-stream\r\n\r\n-----BEGIN PGP MESSAGE-----\r\ndGVzdA==\r\n-----END PGP MESSAGE-----\r\n--==B===--\r\n").unwrap();

    use fem::show::ShowArgs;
    use fem::config::ShowConfig;
    let args = ShowArgs {
        id: 1,
        no_multipart_preference: true,
        ..Default::default()
    };
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        fem::show::run(ShowConfig::default(), args, maildir_path).unwrap();
    }));
    assert!(result.is_ok());
}
