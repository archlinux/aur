#[test]
fn test_emoji_subject_widths() {
    let subjects = [
        "Knock, Knock 👉🏾 new: Devops/SRE position at Belvo - check it out",
        "Re: Knock, Knock 👉🏾 new: Devops/SRE position at Belvo - check it out",
        "💡 What are effective strategies for software developers to i",
        "ACTION REQUIRED: Log in to keep your monitors running 🚨",
        "Today’s must reads: Tenéis 30 días para pagarnos",
        "Trading schedule changes due to the US Labor Day 2023",
    ];
    for s in &subjects {
        let w = unicode_width::UnicodeWidthStr::width(*s);
        let chars = s.chars().count();
        let bytes = s.len();
        println!("{:80} chars={:3} bytes={:3} width={}", s, chars, bytes, w);
    }
}
