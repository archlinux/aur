# fuck
there was no package called "fuck" in the AUR so I decided to make one 👍
# install
`yay -S fuck` or `paru -S fuck`
