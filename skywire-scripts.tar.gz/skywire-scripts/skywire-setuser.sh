#!/bin/bash
#set user in the skywire systemd services
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi

if [ -z $1 ]; then
ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
else
ISO_USER=$1
fi

echo -e "[Unit]
Description=Skywire service
After=network.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/skywire-mainnet
RemainAfterExit=yes
ExecStop=/usr/bin/skywire-halt
User=$ISO_USER

[Install]
WantedBy=multi-user.target " > skywire.service


if [ ! -d "/usr/lib/systemd/system" ]; then
  mv skywire.service /etc/systemd/system/skywire.service
else
  mv skywire.service /usr/lib/systemd/system/skywire.service
fi
