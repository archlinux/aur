#!/bin/bash
#set user in the skywire systemd services
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi

if [ -z $1 ]; then
ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
else
ISO_USER=$1
fi

cd ~/

echo -e "[[Unit]
Description=Skywire visor service
After=network.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/skywire-visor-nohup
RemainAfterExit=yes
ExecStop=/usr/bin/skywire-halt
User=$ISO_USER

[Install]
WantedBy=multi-user.target " > skywire-visor.service

echo -e "[[Unit]
Description=Skywire hypervisor service
After=network.target
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/skywire-hypervisor-nohup
RemainAfterExit=yes
ExecStop=/usr/bin/skywire-halt
User=$ISO_USER

[Install]
WantedBy=multi-user.target " > skywire-hypervisor.service


if [ ! -d "/usr/lib/systemd/system" ]; then
  mv skywire-visor.service /etc/systemd/system/skywire-visor.service
  mv skywire-hypervisor.service /etc/systemd/system/skywire-hypervisor.service
else
  mv skywire-visor.service /usr/lib/systemd/system/skywire-visor.service
  mv skywire-hypervisor.service /usr/lib/systemd/system/skywire-hypervisor.service
fi
systemctl daemon-reload
