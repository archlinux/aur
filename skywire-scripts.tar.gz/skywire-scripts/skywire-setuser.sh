#!/bin/bash
#set user in the skywire systemd services
if [[ $EUID -ne 0 ]]; then
   echo "You must be root to do this." 1>&2
   exit 100
fi

if [ -z $1 ]; then
ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
else
ISO_USER=$1
fi
sudo sed -i 's/User=.*/User='"${ISO_USER}"'/' /usr/lib/systemd/system/skywire-hypervisor.service && sed -i 's/Group=.*/Group=users/' /usr/lib/systemd/system/skywire-hypervisor.service
sudo sed -i 's/User=.*/User='"${ISO_USER}"'/' /usr/lib/systemd/system/skywire-visor.service && sed -i 's/Group=.*/Group=users/' /usr/lib/systemd/system/skywire-visor.service
sudo systemctl daemon-reload
