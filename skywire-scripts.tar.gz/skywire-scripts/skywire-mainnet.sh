#!/bin/bash
#
if [[ $EUID -eq 0 ]]; then
   echo "This script cannot be run as root" 1>&2
   exit 100
fi

[ ! -d ~/apps ] && ln -s /usr/lib/skycoin/go/bin ~/apps

[ ! -d ~/static/skywire-manager-src ] && ln -s /usr/lib/skycoin/skywire-mainnet/static ~/static

if [ ! -f ~/skywire-config.json ]; then
skywire-mainnet-config
fi

if [ ! -f hypervisor-config.json ]; then
  nohup skywire-visor  > /dev/null 2>&1 &
else
  nohup skywire-visor  > /dev/null 2>&1 &
  nohup skywire-hypervisor  > /dev/null 2>&1 &
fi
