#!/bin/bash
#set user in the skywire systemd services
if [[ $EUID -eq 0 ]]; then
   echo "Cannot do this as root" 1>&2
   exit 100
fi
#if [ -z $1 ]; then
#ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
#else
#ISO_USER=$1
#fi
local _skyconfpath="/opt/skywire/skywire.json"
local _visconfpath="/opt/skywire/skywire-visor.json"

cp -b $_skyconfpath ~/skywire.json && skywire-cli visor gen-config --is-hypervisor -r -p -o skywire.json && sudo mv skywire.json $_skyconfpath
[[ -f $_visconfpath ]] && cp -b $_visconfpath ~/skywire-visor.json && skywire-cli visor gen-config --hypervisor-pks $(cat /opt/skywire/hypervisorkey.txt) -r -o skywire-visor.json && sudo mv skywire-visor.json $_visconfpath
sudo sed -i 's/User=.*/User='"${USER}"'/' /usr/lib/systemd/system/skywire.service && sed -i 's/Group=.*/Group=users/' /usr/lib/systemd/system/skywire.service
sudo sed -i 's/User=.*/User='"${USER}"'/' /usr/lib/systemd/system/skywire-visor.service && sed -i 's/Group=.*/Group=users/' /usr/lib/systemd/system/skywire-visor.service
sudo systemctl daemon-reload
[[ -f $_visconfpath ]] && sudo systemctl enable skywire-visor.service || sudo systemctl enable skywire.service
