#!/usr/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_msg3() {
(( QUIET )) && return
local mesg=$1; shift
printf "${BLUE}  -->${ALL_OFF}${BOLD} ${mesg}${ALL_OFF}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_warnmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Warning:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}

_msg2 "Configuring skywire"

#halt any running instance
systemctl disable --now skywire.service 2> /dev/null
systemctl disable --now skywire-visor.service 2> /dev/null
#disable old instances / instances not provided by the package
systemctl disable --now skywire-hypervisor.service 2> /dev/null

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear in a subdirectory of install dir
cd /opt/skywire/  || _errmsg2 "the path /opt/skywire was not found"

#try to reuse existing configuration
if [[ ! -f /opt/skywire/skywire.json ]]; then
  if [[ -f /etc/skywire-config.json ]]; then
    _warnmsg1 "Importing existing skybian configuration from /etc/skywire-config.json"
    cp -b  /etc/skywire-config.json /opt/skywire/skywire.json
  fi
fi
##generate hypervisor configuration##
_msg3 "Generating skywire config with command:"
echo "cd /opt/skywire && skywire-cli config gen -rip"
#again we take precautions by not generating the config file in-place, but moving it there in the next step
if [[ $(skywire-cli config gen -rip /opt/skywire/skywire.json) ]]; then
_msg2 "${_blue}Skywire${_nc} configuration updated!

config path: /opt/skywire/skywire.json"
else
_errmsg2 "Skywire is not installed or installation not detected! Could not generate configuration file!"
echo "this should never happen."
exit 100
fi

#generate tls keys
#skywire-tls-gen

if [[ ! -f /opt/skywire/skywire-visor.json ]] ; then #start hypervisor if visor config does not exist
_msg3 "Enabling skywire systemd service:

systemctl enable --now skywire.service"
systemctl enable --now skywire.service 2> /dev/null
echo
_msg2 "Starting now on:
${_red}http://127.0.0.1:8000${_nc}"
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo
_msg2 "Access hypervisor UI from local network here:
${_yellow}http://${_lanip}:8000${_nc}"
_pubkey=$(cat /opt/skywire/skywire.json | grep pk\")
_pubkey=${_pubkey#*: }
_pubkey=${_pubkey//,/}
_pubkey=${_pubkey//\"/}
#_pubkey=$(skywire-cli visor pk)
echo
_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
echo
_msg2 "run the following commands on OTHER NODES to set this one as their hypervisor:"

echo -e "${_cyan}cd /opt/skywire

sudo cp skywire.json skywire-visor.json

sudo skywire-cli config gen \
--hypervisor-pks ${_yellow}${_pubkey}${_cyan} \
-pro skywire-visor.json

sudo systemctl disable --now skywire.service
sudo systemctl enable --now skywire-visor.service${_nc}"
#hypervisorkey-autoconfig  #regenerate the visor config
else
  #The visor config exists
  _msg3 "Enabling skywire-visor systemd service:

  systemctl enable --now skywire-visor.service"
systemctl enable --now skywire-visor.service 2> /dev/null
echo
_msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
_pubkey=${_pubkey//,/}
_pubkey=${_pubkey//\"/}
echo
_msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
fi
echo
_msg2 "Visit ${_blue}https://whitelist.skycoin.com/${_nc} to register your public key."
_msg2 "View the uptime tracker: ${_blue}http://ut.skywire.skycoin.com/uptimes${_nc}"
_msg2 "join our community on telegram: ${_blue}https://t.me/skywire https://t.me/Skycoin${_nc}"
