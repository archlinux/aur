#!/usr/bin/bash
#/opt/skywire/scripts/skywire-autoconfig
#skywire autoconfiguration script for archlinux
#
#set NOAUTOCONFIG=true to avoid running the script in the postinstall
if [[ $NOAUTOCONFIG == true ]]; then
  #unset the env
  NOAUTOCONFIG=''
  echo "autoconfiguration disabled. to configure and start skywire run: skywire-autoconfig"
  exit 0
fi
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
#halt any running instance
[[ -f /usr/lib/systemd/system/skywire.service ]] && systemctl disable --now skywire.service 2> /dev/null
[[ -f /usr/lib/systemd/system/skywire-visor.service ]] && systemctl disable --now skywire-visor.service 2> /dev/null
[[ -f /usr/lib/systemd/system/skywire-autoconfig.service ]] && systemctl disable skywire-autoconfig.service 2> /dev/null
[[ -f /usr/lib/systemd/system/skywire-autoconfig-remote.service ]] && systemctl disable skywire-autoconfig-remote.service 2> /dev/null
[[ -f /usr/lib/systemd/system/skywire-hypervisor.service ]] && systemctl disable --now skywire-hypervisor.service 2> /dev/null
#make the logging of this script colorful
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'
_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan} ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}
_msg3() {
(( QUIET )) && return
local mesg=$1; shift
printf "${_blue} -->${_nc}${BOLD} ${mesg}${_nc}\n" "$@"
}
_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}
_warnmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Warning:${_bold} ${mesg}${_nc}\n" "$@"
}
_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}
_welcome(){
  _msg2 "register your public key:"
  _msg2 "${_blue}https://whitelist.skycoin.com/${_nc}"
  _msg2 "track uptime:"
  _msg2 "${_blue}http://ut.skywire.skycoin.com/uptimes${_nc}"
  _msg2 "support:"
  _msg2 "${_blue}https://t.me/skywire${_nc}"
}
_config_hypervisor() {
  #try to reuse existing configuration
  if [[ ! -f /opt/skywire/skywire.json ]]; then
    if [[ -f /etc/skywire-config.json ]]; then
      _warnmsg1 "Importing configuration from /etc/skywire-config.json"
      cp -b  /etc/skywire-config.json /opt/skywire/skywire.json
    fi
  fi
  ##generate hypervisor configuration##
  _msg3 "Generating skywire config with command:"
  echo "  skywire-cli config gen -bipr --enable-auth --public-rpc"
  if [[ $(skywire-cli config gen -bipr --enable-auth --public-rpc) ]]; then
    _msg2 "${_blue}Skywire${_nc} configuration updated!"
    if [[ -f /opt/skywire/skywire.json ]]; then
      echo "config path: /opt/skywire/skywire.json"
    else
      _errmsg2 "expected config file not found at /opt/skywire/skywire.json"
      exit 100
    fi
  else
    _errmsg2 "Skywire is not installed or installation not detected! Could not generate configuration file!"
    echo "this should never happen."
    exit 100
  fi
}
_config_visor() {
  _msg2 "Creating visor configutation with specified hypervisor public key:
  ${1}"
  if [[ $(skywire-cli config gen --hypervisor-pks ${1} -bpr) ]]; then
    _msg2 "visor configuration created"
  fi
  _msg3 "Enabling skywire-visor systemd service:
  systemctl enable --now skywire-visor.service"
  systemctl enable --now skywire-visor.service 2> /dev/null
  _msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
  _pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire-visor.json | tail -n1)
  _msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
  _welcome
}
_config_tips() {
  _msg2 "execute the following command on OTHER NODES to set this one as their hypervisor:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}${_pubkey}${_nc}"
  _msg2 "or by ip address:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}\$(skywire-cli --rpc ${_lanip}:3435 visor pk)${_nc}"
  _msg2 "to see this text again run: ${_cyan}skywire-autoconfig${_nc}"
}
_msg2 "Configuring skywire"
#update the hypervisor config file or create it
_config_hypervisor
#script takes public key as argument to configure remote hypervisor
if [[ -z $1 ]] ; then #no pk as argument
  if [[ ! -f /opt/skywire/skywire-visor.json ]]; then #no visor config
  ####>>start hypervisor if visor config does not exist<<####
  _msg3 "Enabling skywire systemd service.."
  systemctl enable --now skywire.service 2> /dev/null
  _pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
  _msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
  _msg2 "Starting now on:
    ${_red}http://127.0.0.1:8000${_nc}"
_msg2 "Use the vpn:
${_red}http://127.0.0.1:8000/#/vpn/${_pubkey}/${_nc}"
_lanip="$(ip addr show | grep -w inet | grep -v 127.0.0.1 | awk '{ print $2}' | cut -d "/" -f 1)"
_msg2 "Access hypervisor UI from local network here:
    ${_yellow}http://${_lanip}:8000${_nc}"
_welcome
_config_tips
else
  #The visor config exists
if [[ $(skywire-cli config gen -bprxo /opt/skywire/skywire-visor.json) ]] ; then
  _msg2 "${_blue}Skywire visor${_nc} configuration updated!"
fi
  _msg3 "Enabling skywire-visor systemd service:
  systemctl enable --now skywire-visor.service"
systemctl enable --now skywire-visor.service 2> /dev/null
_msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
_pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire-visor.json | tail -n1)
_msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
_welcome
fi
else #[[ ! -z $1 ]]
_config_visor
fi
