#!/usr/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}

_msg2 "Configuring skywire"

#halt any running instance
systemctl disable --now skywire.service
systemctl disable --now skywire-visor.service

#config generation writes in the current dir;
#so we want to make anything spawned by the process appear in a subdirectory of install dir
cd /opt/skywire/  || _errmsg2 "the path /opt/skywire was not found"

#try to reuse old config
[[ -f /opt/skywire/skywire.json ]] && cp -b /opt/skywire/skywire.json /opt/skywire/skywire.json.gen

##generate hypervisor configuration##
if [[ $(skywire-cli visor gen-config --is-hypervisor -p -r -o /opt/skywire/skywire.json.gen) ]]; then
_msg2 "${_blue}Skywire${_nc} configuration updated!"
else
_errmsg2 "skywire not installed or installation not detected! Could not generate configuration file!"
echo "this should never happen"
exit 100
fi

#move it to it's location
mv /opt/skywire/skywire.json.gen /opt/skywire/skywire.json

#generate tls keys
skywire-tls-gen

if [[ -f /opt/skywire/hypervisorkey.txt ]]; then
if [[ ! -f /opt/skywire/skywire-visor.json ]] ; then #no visor config, it was reset
hypervisorkey-autoconfig  #regenerate the visor config
else  #config exists
systemctl enable --now skywire-visor.service
echo
_msg2 "${_blue}Skywire${_nc} starting in visor-only mode"
_hvk=$(cat /opt/skywire/hypervisor.txt)
[[ -z ${_hvk} ]] && _errmsg1 "hypervisorkey package installed but no key was found!" || _msg2 "hypervisors: ${_purple}${_hvk}${_nc}"
_pubkey=$(cat /opt/skywire/skywire-visor.json | grep pk\")
_pubkey=${_pubkey#*: }
echo
_msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
echo
fi
else #hypervisorkey not installed
#start as hypervisor
systemctl enable --now skywire.service
echo
_msg2 "${_blue}Skywire${_nc} has been configured!"
echo
_msg2 "starting now on:
${_red}https://127.0.0.1:8000${_nc}"
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo
_msg2 "Access from local network at:
${_yellow}https://${_lanip}:8000${_nc}"
_pubkey=$(cat /opt/skywire/skywire.json | grep pk\")
_pubkey=${_pubkey#*: }
echo
_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
echo
_msg2 "run ${_cyan}keypkg-gen${_nc} to generate the distributable public key package"
fi
#if pacman -Qe skywire-save > /dev/null 2>&1; then
if [[ -f /opt/skywire/skywire-save.txt ]]; then
echo
_msg2 "persisted configuration detected"
else
_msg2 "run ${_cyan}skywire-save${_nc} to back up the current configuration!"
fi
_msg2 "Visit ${_blue}https://whitelist.skycoin.com/${_nc} to register your public key."
