#!/bin/bash
#/opt/skywire/scripts/skywire-autoconfig
#skywire autoconfiguration script for debian & archlinux packages
#
#set NOAUTOCONFIG=true to avoid running the script in the postinstall
if [[ ${NOAUTOCONFIG} == true ]]; then
  #unset the env
  NOAUTOCONFIG=''
  echo "autoconfiguration disabled. to configure and start skywire run: skywire-autoconfig"
  exit 0
fi
#root portion of the configuration
if [[ $EUID -eq 0 ]]; then
	if [[ $DMSGPTYTERM -ne "1" ]]; then
		#halt any running instance
		systemctl is-active --quiet skywire && systemctl disable --now skywire 2> /dev/null
		systemctl is-active --quiet skywire-user && systemctl disable --now skywire-user 2> /dev/null
		systemctl is-active --quiet skywire-visor && systemctl disable --now skywire-visor 2> /dev/null
		systemctl is-active --quiet skywire-hypervisor && systemctl disable --now skywire-hypervisor 2> /dev/null
		systemctl is-active --quiet skywire-autoconfig && systemctl disable skywire-autoconfig 2> /dev/null
	fi
else
	if [[ $DMSGPTYTERM -ne "1" ]]; then
		#halt any running instance with sudo
		echo "halting any running services"
		systemctl is-active --quiet skywire && sudo systemctl disable --now skywire 2> /dev/null
		systemctl is-active --quiet skywire-user && sudo systemctl disable --now skywire-user 2> /dev/null
		systemctl is-active --quiet skywire-visor && sudo systemctl disable --now skywire-visor 2> /dev/null
		systemctl is-active --quiet skywire-hypervisor && sudo systemctl disable --now skywire-hypervisor 2> /dev/null
		systemctl is-active --quiet skywire-autoconfig && sudo systemctl disable skywire-autoconfig 2> /dev/null
		fi
	fi
#make the logging of this script colorful
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'
_1=${1}
_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan} ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}
_msg3() {
(( QUIET )) && return
local mesg=$1; shift
printf "${_blue} -->${_nc}${BOLD} ${mesg}${_nc}\n" "$@"
}
_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Error:${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}
_warnmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> Warning:${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}
_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}>>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}
_welcome(){
	if [[ "$XDG_CURRENT_DESKTOP" != "" ]]; then
		_msg2 "register your public key:"
		_msg2 "${_blue}https://whitelist.skycoin.com/${_nc}"
		_msg2 "track uptime:"
		_msg2 "${_blue}http://ut.skywire.skycoin.com/uptimes${_nc}"
	fi
	_msg2 "support:"
	_msg2 "${_blue}https://t.me/skywire${_nc}"
}
_config_gen_user() {
	#check for argument (public key or "0")
	if [[ ! -z ${_1} ]]; then
		#config exists
		if [[ -f /opt/skywire/skywire.json ]] ; then
			#obtain pubkey from config
			_pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
			#ensure argument != pubkey
			if [[ ${_1} == *${_pubkey}* ]]; then
				_errmsg1 "The public key(s) supplied include the current visor public key.
    Enter a different public key to set a remote hypervisor."
				exit 100
				#test:
				#	skywire-autoconfig $(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
			fi
		fi
		# 0 as argument drops any remote hypervisors which were set in the configuration
		# triggers the creation of the local hyperisor configuration
		# and removes any existing symlink to the service
		if [[ ${_1} == "0" ]]; then
			_retain_hv=""
			unset _1
			_is_hypervisor="-i"
		fi
		# create the flag to set the remote hypervisor(s)
		if [[ ! -z ${_1} ]]; then
			_hvpks="--hvpks ${_1}"	#shorthand flag: -j
		fi
	fi
	#create by default the local hypervisor config for the user
		_is_hypervisor="-i"
	##generate (hyper)visor configuration##
	_msg3 "Generating skywire config with command:"
	# show config gen command used
    echo "  skywire-cli config gen -bur ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks}"
    skywire-cli config gen -bur ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks} >> /dev/null 2>&1
    if [[ ${?} != 0 ]]; then
      #print the error!
      skywire-cli config gen -bur ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks}
      _err=$?
      _errmsg2 "error generating skywire config"
      exit ${_err}
    fi
	#logging check
	if [[ -f /opt/skywire/skywire.json ]]; then
		_msg2 "${_blue}Skywire${_nc} configuration updated!"
		echo "config path: $HOME/skywire-config.json"
	else
		_errmsg2 "expected config file not found at $HOME/skywire-config.json"
		exit 100
	fi
}
_config_gen() {
	#check for argument
	if [[ ! -z ${_1} ]]; then
		#config exists
		if [[ -f /opt/skywire/skywire.json ]] ; then
			#obtain pubkey from config
			_pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
			#ensure argument != pubkey
			if [[ ${_1} == *${_pubkey}* ]]; then
				_errmsg1 "The public keys supplied include the current visor public key.
    Enter a different public key to set a remote hypervisor."
				exit 100
				#test:
				#	skywire-autoconfig $(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
			fi
		fi
		# 0 as argument drops any remote hypervisors which were set in the configuration
		# triggers the creation of the local hyperisor configuration
		# and removes any existing symlink to the service
		if [[ ${_1} == "0" ]]; then
			_retain_hv=""
			unset _1
			_is_hypervisor="-i"
			if [[ -f /opt/skywire/skywire-visor.json ]] ; then
				rm /opt/skywire/skywire-visor.json
			fi
		fi
		# create the flag to set the remote hypervisor(s)
		if [[ ! -z ${_1} ]]; then
			_hvpks="--hvpks ${_1}"	#shorthand flag: -j
			if [[ ! -f /opt/skywire/skywire-visor.json ]] ; then
				#symlink indicates which systemd service to enable later in the script
				ln -s /opt/skywire/skywire.json /opt/skywire/skywire-visor.json
			fi
		fi
	fi
	#create by default the local hypervisor config if no config exists ; and retain any hypervisor config which exists
	if [[ (! -f /opt/skywire/skywire-visor.json) || ($(cat /opt/skywire/skywire.json | grep -Po '"hypervisor":')  == "") ]] ; then  #local hypervisor config
		_is_hypervisor="-i"
	fi
	##generate (hyper)visor configuration##
	_msg3 "Generating skywire config with command:"
	# show config gen command used
    echo "  skywire-cli config gen -bpr ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks}"
    skywire-cli config gen -bpr ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks} >> /dev/null 2>&1
    if [[ ${?} != 0 ]]; then
      #print the error!
      skywire-cli config gen -bpr ${_retain_hv} ${_is_hypervisor} ${_public_rpc} ${_vpn_server} ${_test_env} ${_hvpks}
      _err=$?
      _errmsg2 "error generating skywire config"
      exit ${_err}
    fi
	#logging check
	if [[ -f /opt/skywire/skywire.json ]]; then
		_msg2 "${_blue}Skywire${_nc} configuration updated!"
		echo "config path: /opt/skywire/skywire.json"
	else
		_errmsg2 "expected config file not found at /opt/skywire/skywire.json"
		exit 100
	fi
}

_config_tips() {
  _msg2 "run the following command on OTHER NODES to set this one as the hypervisor:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}${_pubkey}${_nc}"
  if [[ ! -z ${_public_rpc} ]]; then
  _msg2 "or by ip address:"
  echo -e "${_cyan}skywire-autoconfig ${_yellow}\$(skywire-cli --rpc ${_lanip}:3435 visor pk)${_nc}"
  fi
  _msg2 "to see this text again run: ${_cyan}skywire-autoconfig${_nc}"
}
#only use public rpc flag with env PUBLICRPC=1
if [[ ( ${PUBLICRPC} == "1") ]]; then
  _public_rpc="--publicrpc "
fi
#enable VPN server automatically with env VPNSERVER=1
if [[ ${VPNSERVER} == "1" ]]; then
  _vpn_server="--servevpn "
fi
_retain_hv="-x"
#use test deployment instead of production with env TESTENV=1
if [[ ${TESTENV} == "1" ]]; then
	_test_env="--testenv"
fi
if [[ "${SYSTEMDCHILD}" != "1" ]]; then
	_now="--now"
fi

#check for root
if [[ $EUID -eq 0 ]]; then
	#root portion of the config
	_msg2 "Configuring skywire"
	setcap 'cap_net_admin+pe' /opt/skywire/apps/vpn-client
	setcap 'cap_net_admin+pe' /opt/skywire/apps/vpn-server
	#attempt to import config if none exists - i.e. import skybian config or restore config
	if [[ ! -f /opt/skywire/skywire.json ]]; then
		if [[ -f /etc/skywire-config.json ]]; then
	  	_warnmsg1 "Importing configuration from /etc/skywire-config.json"
	  	cp -b  /etc/skywire-config.json /opt/skywire/skywire.json
		fi
  		if [[ -f /opt/skywire/skywire.json ]]; then
  			#if [[ $(cat /opt/skywire/skywire.json | grep -Po '"hypervisors": [\[][\]]')  != "" ]]; then #remote hypervisors
			if [[ $(skywire-cli visor hvpk -p) != *"[]"* ]]; then
				if [[ ! -f /opt/skywire/skywire-visor.json ]]; then
					ln -sf /opt/skywire/skywire.json /opt/skywire/skywire-visor.json
				fi
			fi
		fi
	fi
	#config generation
	_config_gen
 		#don't start the service as root if the config exists in the user space
		if [[ $(echo /home/*/skywire-config.json) != "/home/*/skywire-config.json"  ]]; then
			_msg3 "Not starting as root; config exists in home folder."
			_msg3 "Run ${_cyan}skywire-autoconfig${_nc} without sudo"
			_msg3 "to update your user config and start skywire"
			exit 0
		fi
		#check for symlink to config
		if [[ ! -f /opt/skywire/skywire-visor.json ]]; then
		_msg3 "Enabling skywire systemd service..
    systemctl enable ${_now} skywire.service"
		systemctl enable ${_now} skywire.service 2> /dev/null
		if [[ $DMSGPTYTERM -eq "1" ]]; then
			_msg3 "Restarting skywire systemd service - terminal going down"
			systemctl restart skywire 2> /dev/null
		fi
		_pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire.json | tail -n1)
		#_vpnurl=$(skywire-cli visor vpn url)
		_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
		#No point in printing out links to localhost if a desktop isnt running
		if [[ "$XDG_CURRENT_DESKTOP" != "" ]]; then
			_msg2 "Starting now on:
${_red}http://127.0.0.1:8000${_nc}"
			_msg2 "Use the vpn:
${_red}http://127.0.0.1:8000/#/vpn/${_pubkey}/${_nc}"
		fi
		_lanip="$(ip addr show | grep -w inet | grep -v 127.0.0.1 | awk '{ print $2}' | cut -d "/" -f 1)"
		_msg2 "Access hypervisor UI from local network here:
    ${_yellow}http://${_lanip}:8000${_nc}"
		_welcome
		_config_tips
	else    	#/opt/skywire/skywire-visor.json exists
    	_msg3 "Enabling skywire-visor systemd service:
	      systemctl enable ${_now} skywire-visor"
      	systemctl enable ${_now} skywire-visor 2> /dev/null
		if [[ $DMSGPTYTERM -eq "1" ]]; then
			_msg3 "Restarting skywire-visor systemd service - terminal going down"
			systemctl restart skywire-visor 2> /dev/null
		fi
      	_msg2 "${_blue}Skywire${_nc} starting in visor mode"
      	_pubkey=$(skywire-cli visor pk -i /opt/skywire/skywire-visor.json | tail -n1)
	    _msg2 "Visor Public Key: ${_green}${_pubkey}${_nc}"
	    _welcome
	fi
fi
# User portion of the config
if [[ $EUID -ne 0 ]]; then
	#check if default config exists in $HOME
	if [[ ! -f $HOME/skywire-config.json ]]; then
		#expect the root config to be there ; use it as the basis for the user's config
		if [[ ! -f /opt/skywire/skywire.json ]]; then
			_errmsg2 "default config not found! running skywire-autoconfig as root first: sudo skywire-autoconfig"
			sudo skywire-autoconfig
		fi
		if [[ ! -f $HOME/skywire-config.json ]]; then
			cp -b /opt/skywire/skywire.json $HOME/skywire-config.json
		fi
	fi

	#config generation
	_config_gen_user
	#service configuration for .deb based distros ; service file in /etc/systemd/system/
	if [[ -f /etc/systemd/system/skywire-user.service ]]; then
		_msg2 "configuring skywire-user.service to run as $USER"
		sudo sed -i 's/User=.*/User='"${USER}"'/' /etc/systemd/system/skywire-user.service && sudo sed -i 's/Group=.*/Group=users/' /etc/systemd/system/skywire-user.service
		sudo systemctl daemon-reload
		_msg3 "Enabling skywire-user systemd service..
sudo systemctl enable ${_now} skywire-user.service"
		sudo systemctl enable ${_now} skywire-user.service 2> /dev/null
	fi
	#service configuration for arch based distros ; service file in /etc/systemd/system/
	if [[ -f /usr/lib/systemd/system/skywire-user.service ]]; then
		_msg2 "configuring skywire-user.service to run as $USER"
		sudo sed -i 's/User=.*/User='"${USER}"'/' /usr/lib/systemd/system/skywire-user.service && sudo sed -i 's/Group=.*/Group=users/' /usr/lib/systemd/system/skywire-user.service
		sudo systemctl daemon-reload
		_msg3 "Enabling skywire-user systemd service..
sudo systemctl enable ${_now} skywire-user.service"
		sudo systemctl enable ${_now} skywire-user.service 2> /dev/null
	fi
	_pubkey=$(skywire-cli visor pk -i $HOME/skywire-config.json | tail -n1)
	#_vpnurl=$(skywire-cli visor vpn url -p)
	_msg2 "Visor Public Key:
${_green}${_pubkey}${_nc}"
	if [[ "$XDG_CURRENT_DESKTOP" != "" ]]; then
		_msg2 "Starting now on:
${_red}http://127.0.0.1:8000${_nc}"
		_msg2 "Use the vpn:
${_red}http://127.0.0.1:8000/#/vpn/${_pubkey}/${_nc}"
	fi
	_lanip="$(ip addr show | grep -w inet | grep -v 127.0.0.1 | awk '{ print $2}' | cut -d "/" -f 1)"
	_msg2 "Access hypervisor UI from local network here:
${_yellow}http://${_lanip}:8000${_nc}"
	_welcome
	_config_tips
fi
