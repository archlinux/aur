#!/usr/bin/bash
#disallow root as it can't create packages
#set -x
if [[ $EUID -eq 0 ]]; then
   echo "Can't do this as root" 1>&2
   exit 100
fi

#add some color to output for readability.
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'
_bold='\033[1m'

_msg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_cyan}  ->${_nc}${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg1() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}  >>> Error:${_bold} ${mesg}${_nc}\n" "$@"
}

_errmsg2() {
	(( QUIET )) && return
	local mesg=$1; shift
	printf "${_red}   >>> FATAL:${_bold} ${mesg}${_nc}\n" "$@"
}
#envs
_package="hypervisorkey"
_yaycache=$HOME/.cache/yay
_pacmancache=/var/cache/pacman/pkg
_syncrepos=/var/lib/pacman/sync
_skycache=/opt/skywire/skycache #repo and cache package path.
_skycachedb=${_skycache}/skycache.db.tar.gz


_usage() {
	echo ""
  echo -e "Usage: ${_cyan}${0}${_nc}"
  echo -e "generate the hypervisorkey package,
add it and skywire to the skycache repository, host on LAN."
echo ""
	echo -e "${_cyan}$0 <-a|add> <pkgname> ...${_nc}"
	echo "add a package to the skycache"
  echo ""
  echo -e "${_cyan}$0 <-c|clean>${_nc}"
	echo "reset the skycache"
  echo ""
  echo -e "${_cyan}$0 <-m|mirror-only>${_nc}"
	echo "only mirror pacman's cache"
  echo ""
  echo -e "${_cyan}$0 <-h|--h|help>${_nc}"
  echo "show this help text"
  echo ""
  exit 1
}

_check_installed(){
if pacman -Qe ${_package} > /dev/null 2>&1 ; then
  if ls ${_pacmancache}/${_package}-*.pkg.tar.* > /dev/null 2>&1; then
    _msg2 "detected hypervisorkey in package cache."
  else
_errmsg2 "could not find the installed hypervisorkey package."
echo -e "Please run ${_cyan}keypkg-gen add /path/to/hypervisorkey-1-1-any.pkg.tar.zst${_nc}"
exit 100
fi
fi
}

_build_hvk(){
#ensure build dir path
[[ ! -d "${_yaycache}" ]] && mkdir -p ${_yaycache}
[[ -d "${_yaycache}/${_package}" ]] && rm -rf ${_yaycache}/${_package}

#copy build dir from its installed location
cp -r /opt/skywire/${_package} ${_yaycache}/${_package}
cd ${_yaycache}/${_package}/

#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat /opt/skywire/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
[[ -z ${_hvisorkey} ]] && _errmsg2 "hypervisor key could not be parsed from config file" && exit 100
echo ${_hvisorkey} > hypervisorkey.txt

#OPTIONALLY prompt the user here to add more keys; skipped for automation
echo -e "${_purple}hypervisor key:"
cat hypervisorkey.txt
echo -e ${_nc}

#create the hypervisorkey package
if [[ $(makepkg) ]] ; then
  _msg2 "package was created"
else
  _errmsg2 "error creating package, exiting"
  exit 100
fi
}

_prompt_host() {
_msg2 "${_green}Include built package in skycache repository and host on LAN? [y/n]${_nc}"
#ask to set up repo
read -p "" -n 1 -r
[[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
}


_add_pkg() {
	local _pkgname="$1"
	[[ -z ${_pkgname} ]] && usage

if [[ ${_pkgname} == *".pkg.tar."* ]]; then   #describes a package
if [[ -f $_pkgname ]]; then   #found at path specified
sudo cp -b ${_pkgname} /opt/skywire/skycache/
fi
else
if ls ${_yaycache}/${_pkgname}/${_pkgname}-*.pkg.tar.* > /dev/null 2>&1; then
sudo cp -b ${_yaycache}/${_pkgname}/${_pkgname}-*.pkg.tar.* /opt/skywie/skycache/
fi
fi
}

_add_pkg_update() {
  for _pkgname in "$@"
  	do
  		_add_pkg $_pkgname
  	done
_update_skycache
_symlink_syncdbs
_hostskycache
exit
}

#explicitly stating the path after unfortunate incident
_clean_skycache() {
sudo rm /opt/skywire/skycache/*
}

_check_skywire_install_source() {
#hypervisorkey depends on it
##TODO: make this more flexible or ask which package if multiple are found

#can't use the existance of the package in pacman cache as it gets symlinked there
#if ls /var/cache/pacman/pkg/skywire-*.pkg.tar.* > /dev/null 2>&1; then

#check for the uncommented repository
if cat /etc/pacman.conf | grep skycoin | grep -v \# > /dev/null 2>&1; then
  #check for the corresponding repodb - further evidence of its use
  if ls /var/lib/pacman/sync/*skycoin* > /dev/null 2>&1; then
    #skywire is probably installed from a repository
    #it will be mirrored with everything else since it already exists in pacman cache
    _msg2 "skywire detected in pacman cache"
  fi
else  #check to see if it's actually installed from another skycache instance
  if cat /etc/pacman.conf | grep skycache | grep -v \# > /dev/null 2>&1; then
    #check for the corresponding repodb - further evidence of its use
    if ls /var/lib/pacman/sync/*skycoin* > /dev/null 2>&1; then
      #skywire is probably installed from skycache repository.
      #it will be mirrored with everything else since it already exists in pacman cache
      _msg2 "skywire detected in pacman cache"
    fi
  else
    #add skywire to this repo if built from AUR ;
    if ls ${_yaycache}/skywire/skywire-*.pkg.tar.* > /dev/null 2>&1; then
      #skywire is installed from AUR
      _msg2 "copying skywire from yay cache to skycache"
      sudo cp -b ${_yaycache}/skywire/skywire-*.pkg.tar.* /opt/skywire/skycache/
    else # a big else - what if they just installed this from a USB and didn't build it.
      _errmsg1 "Can't find built skywire package."
      echo -e "please place built skywire package in ${_yaycache}/skywire/"
      echo "then run ${_cyan}keypkg-gen${_nc} again to include it in the locally hosted package repository"
fi
fi
fi
}

_update_skycache() {
sudo repo-add -n ${_skycachedb} ${_skycache}/*.pkg.tar.*
sudo ln -f /opt/skywire/skycache/* /var/cache/pacman/pkg/
}

_symlink_syncdbs() {
sudo pacman -Syy
sudo ln -f /var/lib/pacman/sync/* /var/cache/pacman/pkg/
}


_info_config_skycache() {
  _lanip=$(ifconfig | grep inet | head -n 1)
  _lanip=${_lanip##*inet }
  _lanip=${_lanip%% *}
echo
echo -e "${_yellow}# To install packages from the skycache${_nc}"
echo -e "${_yellow}# On the remote system add this to /etc/pacman.conf${_nc}"
echo
echo -e "${_green}[skycache]
SigLevel = Never
Server = http://${_lanip}:8079${_nc}"
echo
}

_info_config_mirrorlist() {
  _lanip=$(ifconfig | grep inet | head -n 1)
  _lanip=${_lanip##*inet }
  _lanip=${_lanip%% *}
  echo
  echo -e "${_yellow}# To install all other packages from the system cache${_nc}"
  echo -e "${_yellow}#On the remote system, Add this to /etc/pacman.d/mirrorlist${_nc}"
  echo
  echo -e "${_green}Server = http://${_lanip}:8079${_nc}"
  echo
}

_info_config_update() {
  echo
  echo -e "${_yellow}# use the configured mirror or repository to install the hypervisorkey${_nc}"
  echo -e "${_yellow}#On the remote system, run:${_nc}"
  echo
  echo -e "${_green}sudo pacman -Sy${_nc}"
  echo -e "${_green}sudo pacman -Syy${_nc}"
  echo -e "${_green}sudo pacman -S hypervisorkey${_nc}"
  echo
}

#starts mirroring
_hostskycache(){
  #instruct user on configuration
_info_config_skycache
_info_config_mirrorlist
_info_config_update
echo "Starting skycache service"
sudo systemctl enable --now skycache
}

_default_run() {
_check_installed
_build_hvk
_prompt_host
_clean_skycache
_add_pkg ${_yaycache}/${_package}/${_package}-*-any.pkg.tar.*
_check_skywire_install_source
_update_skycache
_symlink_syncdbs
_hostskycache
exit
}

_mirror_only() {
  _check_installed
  _symlink_syncdbs
  _info_config_mirrorlist
  _info_config_update
  echo "Starting skycache service"
  sudo systemctl enable --now skycache
  exit
}

[[ -z $1 ]] && _default_run

case "$1" in
	-a|add)
		_add_pkg_update "${@:2}"
		;;
  -c|clean)
		_clean_skycache
		;;
  -m|mirror-only)
		_mirror_only
		;;
	-h|help)
		_usage
		;;
	*)
    _usage

esac
