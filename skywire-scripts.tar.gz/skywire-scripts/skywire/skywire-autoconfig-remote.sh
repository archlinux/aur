#!/bin/bash
#root portion of the configuration
if [[ $EUID -ne 0 ]]; then
   echo -e "Root permissions required" 1>&2
   exit 100
fi
_remoteip=""
if [[ -z $1 ]]; then
_remoteip="$(ip route show | grep -i 'default via'| awk '{print $3 }' | sed 's/\.[^.]*$//').117:3435"
[[ "${_remoteip}" == ".2:3435" ]] && echo "gateway not found" && exit 1
else
  _remoteip="${1}:3435"
fi
#debug
# [[ "192.168.0.1" == *.*.*.* ]] && echo "no"
[[ "${_remoteip}" != *.*.*.* ]] && echo "bad ip address format" && exit 1
[[ $(skywire-cli --rpc ${_remoteip} visor pk) == *"FATAL"*]] && echo "no reply from remote visor rpc" && exit 1
_remotepk=$(skywire-cli --rpc ${_remoteip} visor pk)
echo "skywire-autoconfig ${_remotepk}"
skywire-autoconfig ${_remotepk}
