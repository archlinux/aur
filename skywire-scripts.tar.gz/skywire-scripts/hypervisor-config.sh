#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 100
fi

skywire-hypervisor gen-config -ro /etc/hypervisor-config.json
hvisorkey=$(head -n 2 /etc/hypervisor-config.json)
hvisorkey=${hvisorkey#*'{'}
echo $hvisorkey > ~/hypervisorinfo.txt
skywire-cli visor gen-config -ro /etc/skywire-config.json
hvisorip=$(cat /etc/hypervisor-config.json | grep local_address)
hvisorip=${hvisorip%'"'*}
hvisorip=${hvisorip##*'"'}
hvisorip=${hvisorip%:*}
echo $hvisorip >> ~/hypervisorinfo.txt
###################### DETERMINE HOST OS #############################
DEBIANCHECK=$(cat /etc/os-release | grep Debian)
ARMBIANCHECK=$(cat /etc/os-release | grep Armbian)
RASPBIANCHECK=$(cat /etc/os-release | grep Raspbian)
ARCHCHECK=$(cat /etc/os-release | grep arch)
if [ ! -z "$DEBIANCHECK" ] && [ ! -z "$ARMBIANCHECK" ] && [ ! -z "$RASPBIANCHECK" ]; then
  packagename=hypervisorconfig
  packageversion=1
  packagearchitecture=(amd64 arm64 armhf armel)
  debpkgdir="${packagename}-${packageversion}"
  mkdir -p $debpkgdir/DEBIAN $debpkgdir/usr/lib/skycoin/skywire/hypervisorconfig
  echo "Package: $packagename" > $debpkgdir/DEBIAN/control
  echo "Version: $packageversion" >> $debpkgdir/DEBIAN/control
  echo "Priority: optional" >> $debpkgdir/DEBIAN/control
  echo "Section: web" >> $debpkgdir/DEBIAN/control
  echo "Architecture: $packagearchitecture" >> $debpkgdir/DEBIAN/control
  echo "Maintainer: Hypervisor" >> $debpkgdir/DEBIAN/control
  echo "Description: Hypervisor configuration" >> $debpkgdir/DEBIAN/control
  cp -b ~/hypervisorinfo.txt $debpkgdir/usr/lib/skycoin/skywire/hypervisorconfig/hypervisorinfo.txt
  #build the debian package
  dpkg-deb --build $debpkgdir
  rm -rf $debpkgdir
  # skyupdate provides the following script
  #create-deb-repo
fi
if [ ! -z "$ARCHCHECK" ]; then
  ISO_USER="$(cat /etc/passwd | grep "/home" |cut -d: -f1 |head -1)"
  rm -rf /home/$ISO_USER/.cache/yay/hypervisorconfig/
  su -c "mkdir -p ~/.cache/yay/hypervisorconfig" $ISO_USER
  su -c "cp -b /usr/lib/skycoin/skywire/hypervisorconfig/PKGBUILD ~/.cache/yay/hypervisorconfig/PKGBUILD" $ISO_USER
  cp -b ~/hypervisorinfo.txt /home/$ISO_USER/.cache/yay/hypervisorconfig/hypervisorinfo.txt
  su -c "cd ~/.cache/yay/hypervisorconfig/ && makepkg -f" $ISO_USER
  cd ~/
#sudo systemctl start readonly-cache.service
fi



#create new visor-config.json from pared info
if [[ $(cat /etc/skywire-config.json | grep '"hypervisors": \[\],') = *'"hypervisors": [],'* ]]; then
  [ ! -f /etc/skywire-config.json.bak ] && cp /etc/skywire-config.json /etc/skywire-config.json.bak
  head -n 59 /etc/skywire-config.json > ~/skywire-config-0.json
  echo -e	'"hypervisors": [{' >> ~/skywire-config-0.json
  echo -e "$hvisorkey"  >> ~/skywire-config-0.json
if [ -f /etc/hypervisor-config.json ]; then
  echo -e	'"address":"127.0.0.1:8000"' >> ~/skywire-config-0.json
else
  #hvisorip="127.0.0.1" &&   echo	'"address":"$hvisorip:8080"'
  echo '"'address'"':'"'$hvisorip:8000'"' >> ~/skywire-config-0.json
fi
  echo -e	"}]," >> ~/skywire-config-0.json
  tail -n 10 /etc/skywire-config.json >> ~/skywire-config-0.json
  mv ~/skywire-config-0.json /etc/skywire-config.json
  echo "Skywire configured successfully"
else
  echo "Skywire configuration detected, no changes made"
  echo "To recover visor configuration: skywire-config reset"
  echo "To remove all configuration files: skywire-config purge"
fi
