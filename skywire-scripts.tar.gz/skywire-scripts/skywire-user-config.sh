#!/bin/bash

if [[ $EUID -eq 0 ]]; then
   echo "This script cannot be run as root" 1>&2
   exit 100
fi

cd ~/
[[ $1 == "reset" ]] && [ ! -f ~/skywire-config.json.bak ] && mv ~/skywire-config.json.bak ~/skywire-config.json && exit
[[ $1 == "purge" ]] && rm ~/skywire-config.json ~/hypervisor-config.json && exit

# detect visor-config.json
  if [ ! -f ~/skywire-config.json ]; then
#check if the hypervisorinfo.txt file exists
    if [ -f /usr/lib/skycoin/skywire-mainnet/hypervisorconfig/hypervisorinfo.txt ]; then
# create skywire-config.json and set hvisor ip nd key vars
    skywire-cli visor gen-config -rt
    hvisorkey=$(head -n 1 /usr/lib/skycoin/skywire-mainnet/hypervisorconfig/hypervisorinfo.txt)
    hvisorip=$(tail -n 1 /usr/lib/skycoin/skywire-mainnet/hypervisorconfig/hypervisorinfo.txt)
else
  # hypervisorinfo.txt is not provided, set up hypervisor
#generate configs if needed and parse hvisorkey and ip
[ ! -f ~/hypervisor-config.json ] && skywire-hypervisor gen-config -rt
hvisorkey=$(head -n 2 ~/hypervisor-config.json)
hvisorkey=${hvisorkey#*'{'}
echo $hvisorkey > ~/hypervisorinfo.txt
skywire-cli visor gen-config -rt
hvisorip=$(cat ~/skywire-config.json | grep local_address)
hvisorip=${hvisorip%'"'*}
hvisorip=${hvisorip##*'"'}
hvisorip=${hvisorip%:*}
echo $hvisorip >> ~/hypervisorinfo.txt
###################### DETERMINE HOST OS #############################
DEBIANCHECK=$(cat /etc/os-release | grep Debian)
ARMBIANCHECK=$(cat /etc/os-release | grep Armbian)
RASPBIANCHECK=$(cat /etc/os-release | grep Raspbian)
ARCHCHECK=$(cat /etc/os-release | grep arch)
if [ ! -z "$DEBIANCHECK" ] && [ ! -z "$ARMBIANCHECK" ] && [ ! -z "$RASPBIANCHECK" ]; then
  packagename=hypervisorconfig
  packageversion=1
  packagearchitecture=(amd64 arm64 armhf armel)
  debpkgdir="${packagename}-${packageversion}"
  mkdir -p $debpkgdir/DEBIAN $debpkgdir/usr/lib/skycoin/skywire-mainnet/hypervisorconfig
  echo "Package: $packagename" > $debpkgdir/DEBIAN/control
  echo "Version: $packageversion" >> $debpkgdir/DEBIAN/control
  echo "Priority: optional" >> $debpkgdir/DEBIAN/control
  echo "Section: web" >> $debpkgdir/DEBIAN/control
  echo "Architecture: $packagearchitecture" >> $debpkgdir/DEBIAN/control
  echo "Maintainer: Hypervisor" >> $debpkgdir/DEBIAN/control
  echo "Description: Hypervisor configuration" >> $debpkgdir/DEBIAN/control
  cp -b ~/hypervisorinfo.txt $debpkgdir/usr/lib/skycoin/skywire-mainnet/hypervisorconfig/hypervisorinfo.txt
  #build the debian package
  dpkg-deb --build $debpkgdir
  rm -rf $debpkgdir
  # skyupdate provides the following script
  #create-deb-repo
fi
if [ ! -z "$ARCHCHECK" ]; then
  rm -rf ~/.cache/yay/hypervisorconfig/
  mkdir -p ~/.cache/yay/hypervisorconfig
  cp -b /usr/lib/skycoin/skywire-mainnet/hypervisorconfig/PKGBUILD ~/.cache/yay/hypervisorconfig/PKGBUILD
  cp -b ~/hypervisorinfo.txt ~/.cache/yay/hypervisorconfig/hypervisorinfo.txt
  cd ~/.cache/yay/hypervisorconfig/
  makepkg -f
  cd ~/
  #sudo systemctl start readonly-cache.service
fi
fi
fi


#create new visor-config.json from pared info
if [[ $(cat ~/skywire-config.json | grep '"hypervisors": \[\],') = *'"hypervisors": [],'* ]]; then
  [ ! -f ~/skywire-config.json.bak ] && cp ~/skywire-config.json ~/skywire-config.json.bak
  head -n 59 ~/skywire-config.json > ~/skywire-config-0.json
  echo -e	'"hypervisors": [{' >> ~/skywire-config-0.json
  echo -e "$hvisorkey"  >> ~/skywire-config-0.json
if [ -f ~/hypervisor-config.json ]; then
  echo -e	'"address":"127.0.0.1:8000"' >> ~/skywire-config-0.json
else
  #hvisorip="127.0.0.1" &&   echo	'"address":"$hvisorip:8080"'
  echo '"'address'"':'"'$hvisorip:8000'"' >> ~/skywire-config-0.json
fi
  echo -e	"}]," >> ~/skywire-config-0.json
  tail -n 10 ~/skywire-config.json >> ~/skywire-config-0.json
  mv ~/skywire-config-0.json ~/skywire-config.json
  echo "Skywire configured successfully"
else
  echo "Skywire configuration detected, no changes made"
  echo "To recover visor configuration: skywire-mainnet-config reset"
  echo "To remove all configuration files: skywire-mainnet-config purge"
fi
