#!/bin/bash
cd ~/
[ ! -d ~/static/skywire-manager-src ] && ln -s /usr/lib/skycoin/skywire-mainnet/static ~/static
if [ ! -f ~/hypervisor-config.json ]; then
exit
else
  nohup skywire-hypervisor  > /dev/null 2>&1 &
fi
