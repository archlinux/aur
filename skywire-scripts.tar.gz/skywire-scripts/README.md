package and satellite package config file management script flow overview

####skywire.PKGBUILD
    skywire.install > `skywire-autoconfig`
        `keypkg-gen` > `makepkg -p hypervisorkey.PKGBUILD` > `skycache`
        `skywire-save` > `makepkg -ip skywire-save.PKGBUILD` > `tar skywire-save.tar.gz skywire-save 1-1-any.pkg.tar.zst`
        `skywire-restore`
        `skywire-reset`

#####  hypervisorkey.PKGBUILD
    hypervisorkey.install > `hypervisorkey-autoconfig`

#####  skywire-save.PKGBUILD
    skywire-save.install


####skywire.PKGBUILD base scripts
certificate.cnf
generate.sh
skywire.service
skywire-visor.service
skywire-halt.sh
skywire-setuser.sh
