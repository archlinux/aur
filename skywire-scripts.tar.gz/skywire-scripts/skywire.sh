#!/bin/bash
#script requires skywire mainnet binaries

if [[ $EUID -eq 0 ]]; then
   echo "This script cannot be run as root" 1>&2
   exit 100
fi


cd ~/

auto_configure() {
# detect visor-config.json
if [ ! -f /etc/skywire-visor.json ]; then
  #check if the hypervisorinfo.txt file exists
  if [ -f /usr/lib/skycoin/skywire/hypervisor.txt ]; then
    # create skywire-config.json and set hvisor key
    visorconfig_gen
    hvisorkey=$(cat /usr/lib/skycoin/skywire/hypervisor.txt)
    set_hvisorkey
    visor_up
  else
    # hypervisor.txt is not provided, set up hypervisor
    #generate configs if needed and parse hvisorkey and ip
    [ ! -f /etc/skywire-hypervisor.json ] && hvisorconfig_gen
    visorconfig_gen
    hvisorconfig_package
    hvisor_up
    visor_up
  fi
fi
}

visorconfig_gen() {
  skywire-cli visor gen-config -ro /etc/skywire-visor.json && sudo mv ~/skywire-visor.json /etc/skywire-visor.json
}

hvisorconfig_gen() {
  skywire-hypervisor gen-config -ro ~/skywire-hypervisor.json && sudo mv ~/skywire-hypervisor.json /etc/skywire-hypervisor.json
  hvisorkey=$(cat /etc/skywire-hypervisor.json | grep "public_key" | awk '{print substr($2,2,66)}')
}

hvisorconfig_package() {
  #Create the package with the hypervisor key text file
  rm -rf ~/.cache/yay/hypervisorconfig/
  mkdir -p ~/.cache/yay/hypervisorconfig
  cp -b /usr/lib/skycoin/skywire/hypervisorconfig/PKGBUILD ~/.cache/yay/hypervisorconfig/PKGBUILD
  echo $hvisorkey > ~/.cache/yay/hypervisorconfig/hypervisor.txt
  cd ~/.cache/yay/hypervisorconfig/
  makepkg -f
  cd ~/
}

set_hvisorkey() {
  sudo sed -i 's/"hypervisors".*/"hypervisors": [{"public_key": "'"${hvisorkey}"'"}],/' /etc/skywire-visor.json
}

hvisor_up() {
  sudo systemctl enable skywire-hypervisor
  sudo systemctl start skywire-hypervisor
}

visor_up() {
  sudo systemctl enable skywire-visor
  sudo systemctl start skywire-visor
}



case "$1" in

  "--hypervisor")
  hvisorconfig_gen
  visorconfig_gen
  hvisorconfig_package
  hvisor_up
    ;;
  "--visor")
  visorconfig_gen
  hvisorkey=$(cat /usr/lib/skycoin/skywire/hypervisor.txt)
  set_hvisorkey
  visor_up
    ;;
  *)
  auto_configure
    ;;
esac
