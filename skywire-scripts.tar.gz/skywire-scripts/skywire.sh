#!/bin/bash
#script requires skywire mainnet binaries

if [[ $EUID -eq 0 ]]; then
   echo "This script cannot be run as root" 1>&2
   exit 100
fi

if pacman -Qi hypervisorconfig > /dev/null ; then
echo "hypervisorconfig package is installed, please remove this package and reinstall skywire before running this script"
exit
else
#Create the package with the hypervisor key text file
  rm -rf ~/.cache/yay/hypervisorconfig/
  mkdir -p ~/.cache/yay/hypervisorconfig
  cp -b /usr/lib/skycoin/skywire/hypervisorconfig/PKGBUILD ~/.cache/yay/hypervisorconfig/PKGBUILD
  hvisorkey=$(cat /etc/skywire-hypervisor.json | grep "public_key" | awk '{print substr($2,2,66)}')
  echo $hvisorkey > ~/.cache/yay/hypervisorconfig/hypervisor.txt
  cd ~/.cache/yay/hypervisorconfig/
  makepkg -f
  cd ~/
  echo "please run or start the readonly-cache service and install the hypervisorconfig package on the nodes"
fi
