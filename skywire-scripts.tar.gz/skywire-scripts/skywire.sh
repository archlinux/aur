#!/bin/bash
#script requires skywire mainnet binaries

if [[ $EUID -eq 0 ]]; then
   echo "This script cannot be run as root" 1>&2
   exit 100
fi

cd ~/
# detect visor-config.json
if [ ! -f /etc/skywire-visor.json ]; then
  #check if the hypervisorinfo.txt file exists
  if [ -f /usr/lib/skycoin/skywire/hypervisor.txt ]; then
    # create skywire-config.json and set hvisor key
    sudo skywire-cli visor gen-config -rto /etc/skywire-visor.json
    hvisorkey=$(cat /usr/lib/skycoin/skywire/hypervisor.txt)
  else
    # hypervisor.txt is not provided, set up hypervisor
    #generate configs if needed and parse hvisorkey and ip
    [ ! -f /etc/skywire-hypervisor.json ] && skywire-hypervisor gen-config -rto /etc/skywire-hypervisor.json
    hvisorkey=$(cat /etc/skywire-hypervisor.json | grep "public_key" | awk '{print substr($2,2,66)}')
    sudo skywire-cli visor gen-config -rto /etc/skywire-visor.json
    #Create the package with the hypervisor key text file
    rm -rf ~/.cache/yay/hypervisorconfig/
    mkdir -p ~/.cache/yay/hypervisorconfig
    cp -b /usr/lib/skycoin/skywire/hypervisorconfig/PKGBUILD ~/.cache/yay/hypervisorconfig/PKGBUILD
    echo $hvisorkey > ~/.cache/yay/hypervisorconfig/hypervisor.txt
    cd ~/.cache/yay/hypervisorconfig/
    makepkg -f
    cd ~/
    #sudo systemctl start readonly-cache.service
  fi
fi

#create new visor-config.json from pared info
[[ $(cat ~/skywire-config.json | grep '"hypervisors": \[\],') = *'"hypervisors": [],'* ]] && sudo sed -i 's/"hypervisors".*/"hypervisors": [{"public_key": "'"${hvisorkey}"'"}],/' /etc/skywire-visor.json
