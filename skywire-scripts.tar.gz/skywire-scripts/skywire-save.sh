#!/usr/bin/bash
#disallow root as it can't create packages
if [[ $EUID -eq 0 ]]; then
   echo -e "Can't do this as root" 1>&2
   exit 100
fi
_nc='\033[0m'
_red='\033[0;31m'
_package="skywire-save"
_config="skywire.json"
_config2="skywire-visor.json"
_configpath="/opt/skywire"
_yaycache="${HOME}/.cache/yay"
_errmsg="${_red}a saved configuration is installed, why do you want to make the same thing again?${_nc}"
#check that the hypervisorkey package was not installed - avoid unintended misconfiguration
pacman -Qi ${_package} > /dev/null 2>&1 && echo -e $_errmsg 1>&2 && exit 100
#ensure build dir path
[[ ! -d ${_yaycache} ]] && mkdir -p ${_yaycache}
[[ -d ${_yaycache}/${_package} ]] && rm -rf ${_yaycache}/${_package}
#copy build dir from its installed location
cp -rb ${_configpath}/${_package} ${_yaycache}/${_package}
cd ${_yaycache}/${_package}

sudo systemctl stop skywire.service
sudo systemctl stop skywire-visor.service

#back up configuration files
if [[ ! -f ${_configpath}/${_config} ]] ; then #no primary config file found
#check for backup config and use that or error
[[ -f ${_configpath}/${_config}.bak ]] && cp -b ${_configpath}/${_config}.bak ${_yaycache}/${_package}/${_config} || echo "Error ${_configpath}/${_config} not found! Please run skywire-autoconfig as root to create the configs first!" && exit
else #config file exists
cp -b ${_configpath}/${_config} ${_yaycache}/${_package}/${_config} && sudo mv ${_configpath}/${_config} ${_configpath}/${_config}.bak
fi
if [[ ! -f ${_configpath}/${_config2} ]] ; then #no secondary config found
[[ -f ${_configpath}/${_config2}.bak ]] && cp -b ${_configpath}/${_config2} ${_yaycache}/${_package}/${_config2} || echo #echo so script doesn't error
else #secondary config exists
cp -b ${_configpath}/${_config2} ${_yaycache}/${_package}/${_config2} && sudo mv ${_configpath}/${_config2} ${_configpath}/${_config2}.bak
fi

if [[ -f ${_configpath}/users.db ]] ; then #check for users.db - that is the password file for the hypervisor UI
sudo cp -b ${_configpath}/users.db ${_yaycache}/${_package}/users.db
sudo chmod 755 ${_yaycache}/${_package}/users.db
sudo mv ${_configpath}/users.db ${_configpath}/users.db.bak
else #check for backup of this file
if [[ -f ${_configpath}/users.db.bak ]] ; then
  sudo cp -b ${_configpath}/users.db.bak ${_yaycache}/${_package}/users.db
  sudo chmod 755 ${_yaycache}/${_package}/users.db
fi
fi
#create the skywire-save package and install it to complete the configuration process
makepkg -if
#now compress it so it is not readibly installable to avoid it being picked up by readonly-cache!
[[ ! -f "skywire-save-1-1-any.pkg.tar.zst" ]] && [[ ! -f "skywire-save-1-1-any.pkg.tar.xz" ]] && echo "Something went wrong" && exit
[[ -f "skywire-save-1-1-any.pkg.tar.zst" ]] && tar -czvf skywire-save.tar.gz skywire-save-1-1-any.pkg.tar.zst && rm skywire-save-1-1-any.pkg.tar.zst
[[ -f "skywire-save-1-1-any.pkg.tar.xz" ]] && tar -czvf skywire-save.tar.gz skywire-save-1-1-any.pkg.tar.xz  && rm skywire-save-1-1-any.pkg.tar.xz
#remove the users.db
rm -rf ~/.cache/yay/${_package}/users.db
