#!/bin/bash
#[[ -d /opt/skywire ]] && rm -rf /opt/skywire
