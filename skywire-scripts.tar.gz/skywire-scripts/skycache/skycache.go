/**/
package main

import (
	"flag"
	"log"
	"net/http"
	"os"
)

func main() {
	if os.Geteuid() != 0 {
		log.Fatal("you must be root to do this")
	}

	port := flag.String("p", "8079", "port to serve on")
	directory := flag.String("d", "/var/cache/pacman/pkg/", "the directory of static file to host")
	flag.Parse()

	http.Handle("/", http.FileServer(http.Dir(*directory)))

	log.Printf("Serving %s on HTTP port: %s\n", *directory, *port)
	log.Fatal(http.ListenAndServe(":"+*port, nil))
}
