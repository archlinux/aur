#!/usr/bin/bash
#disallow root as it can't create packages
set -e
if [[ $EUID -eq 0 ]]; then
   echo "Can't do this as root" 1>&2
   exit 100
fi

#add some color to output for readability.
_nc='\033[0m'
_red='\033[0;31m'
_green='\033[0;32m'
_yellow='\033[0;33m'
_blue='\033[1;34m'
_purple='\033[0;35m'
_cyan='\033[0;36m'

_package="hypervisorkey"
_errmsg="hypervisorkey package is installed, the node has been configured as a visor. Please uninstall the foreign key to cotinue as this package is designed to connect other visors to the current running hypervisor instance which was disabled when you installed the hypervisorkey package."
#check that the hypervisorkey package was not installed - avoid unintended misconfiguration
pacman -Qe ${_package} > /dev/null 2>&1 && echo ${_red}${_errmsg}${_nc} 1>&2 && exit 100

_yaycache=$HOME/.cache/yay
#ensure build dir path
[[ ! -d "${_yaycache}" ]] && mkdir -p ${_yaycache}
[[ -d "${_yaycache}/${_package}" ]] && rm -rf ${_yaycache}/${_package}

#copy build dir from its installed location
cp -r /opt/skywire/${_package} ${_yaycache}/${_package}
cd ${_yaycache}/${_package}/

#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat /opt/skywire/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
[[ -z ${_hvisorkey} ]] && echo -e "${_red}FATAL: hypervisor key could not be parsed from config file" && exit 100
echo ${_hvisorkey} > hypervisorkey.txt

#OPTIONALLY prompt the user here to add more keys; skipped for automation
echo -e "${_purple}hypervisor key:"
cat hypervisorkey.txt
echo -e ${_nc}
#create the hypervisorkey package
if [[ $(makepkg) ]] ; then
  echo "package was created"
else
  echo -e "${_red}   >>>FATAL: error creating package, exiting${_nc}"
  exit 100
fi

echo -e "${_green}Include built package in skycache repository and host on LAN? [y/n]${_nc}"
#ask to set up repo
read -p "" -n 1 -r
[[ ! $REPLY =~ ^[Yy]$ ]] && exit 1

_skycache=/opt/skywire/skycache #repo and cache package path.
_skycachedb=${_skycache}/skycache.db.tar.gz

#remove any existing package of the hypervisorkey or skywire
if [[ -f ${_skycachedb} ]]; then
  sudo repo-remove ${_skycachedb} ${_package} skywire && echo #echo so script does not fail!
fi

#copy the hypervisorkey package to the skycache
sudo cp -b ${_yaycache}/${_package}/${_package}-*-any.pkg.tar.* ${_skycache}/

#attempt to do the same for skywire ; as hypervisorkey depends on it
##TODO: make this more flexible or ask which package if multiple are found

#can't use the existance of the package in pacman cache as it gets symlinked there
#if ls /var/cache/pacman/pkg/skywire-*.pkg.tar.* > /dev/null 2>&1; then

#check for the uncommented repository
if cat /etc/pacman.conf | grep skycoin | grep -v \# > /dev/null 2>&1; then
  #check for the corresponding repodb - further evidence of its use
  if ls /var/lib/pacman/sync/*skycoin* > /dev/null 2>&1; then
    #skywire is probably installed from a repository
    #it will be mirrored with everything else since it already exists in pacman cache
    echo "skywire detected in pacman cache"
  fi
else  #check to see if it's actually installed from another skycache instance
  if cat /etc/pacman.conf | grep skycache | grep -v \# > /dev/null 2>&1; then
    #check for the corresponding repodb - further evidence of its use
    if ls /var/lib/pacman/sync/*skycoin* > /dev/null 2>&1; then
      #skywire is probably installed from skycache repository.
      #it will be mirrored with everything else since it already exists in pacman cache
      echo "skywire detected in pacman cache"
    fi
  else
    #add skywire to this repo if built from AUR ;
    if ls $HOME/.cache/yay/skywire/skywire-*.pkg.tar.* > /dev/null 2>&1; then
      #skywire is installed from AUR
      echo "copying skywire from yay cache to skycache"
      sudo cp -b ${_yaycache}/skywire/skywire-*.pkg.tar.* ${_skycache}/
    else # a big else - what if they just installed this from a USB and didn't build it.
      echo -e "${_red} >>ERROR: Can't find built skywire package.${_nc}"
      echo -e "please place built skywire package in ${_yaycache}/skywire/"
      echo "then run ${_cyan}keypkg-gen${_nc} again to include it in the locally hosted package repository"
fi
fi
fi

sudo repo-add -n ${_skycachedb} ${_skycache}/*.pkg.tar.*
sudo pacman -Syy
sudo ln -f /var/lib/pacman/sync/* /var/cache/pacman/pkg/
sudo ln -f /opt/skywire/skycache/* /var/cache/pacman/pkg/
#starts mirroring
#instruct user on configuration
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo
echo -e "${_yellow}#On the remote system, add this to /etc/pacman.conf${_nc}"
echo
echo -e "${_green}[skycache]
SigLevel = Never
Server = http://${_lanip}:8079${_nc}"
echo
echo -e "${_yellow}#On the remote system, Add this to /etc/pacman.d/mirrorlist${_nc}"
echo
echo -e "${_green}Server = http://${_lanip}:8079${_nc}"
echo
echo -e "${_yellow}#Then, on the remote system, run:${_nc}"
echo
echo -e "${_green}sudo pacman -Sy
sudo pacman -Syy
sudo pacman -S hypervisorkey${_nc}"
echo
echo "Starting skycache service"
sudo systemctl enable --now skycache
