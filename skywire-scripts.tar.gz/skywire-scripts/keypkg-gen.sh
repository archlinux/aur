#!/usr/bin/bash
#disallow root as it can't create packages
if [[ $EUID -eq 0 ]]; then
   echo "Can't do this as root" 1>&2
   exit 100
fi

_package="hypervisorkey"
_errmsg="hypervisorkey package is installed, the node has been configured as a visor. Please uninstall the foreign key to cotinue as this package is designed to connect other visors to the current running hypervisor instance which was disabled when you installed the hypervisorkey package."
#check that the hypervisorkey package was not installed - avoid unintended misconfiguration
pacman -Qi ${_package} > /dev/null 2>&1 && echo $_errmsg 1>&2 && exit 100
#ensure build dir path
[[ ! -d "~/.cache/yay/" ]] && mkdir -p ~/.cache/yay/
[[ -d "~/.cache/yay/${_package}" ]] && rm -rf ~/.cache/yay/${_package}
#copy build dir from its installed location
rm -rf ~/.cache/yay/${_package}
cp -r /opt/skywire/${_package} ~/.cache/yay/${_package}
cd ~/.cache/yay/${_package}/
#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat /opt/skywire/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
echo ${_hvisorkey} > hypervisorkey.txt
echo -e "hypervisor key :"
cat hypervisorkey.txt
#OPTIONALLY prompt the user here to add more keys; skipped for automation
#create the hypervisorkey package
if [[ $(makepkg) ]] ; then
  echo "package was created"
else
  echo "error occured, exiting"
  exit
fi
echo
#ask to set up repo
read -p "Include built package in sky-local repository and host on LAN? [y/n]" -n 1 -r
echo
[[ ! $REPLY =~ ^[Yy]$ ]] && exit 1

#use readonly-cache to set up a mirror and local package repo for nodes which contains the created package
#add selected packages in yay's cache to a custom local repo and symlink them to pacman's cache
if [[ ! -f /opt/skywire/sky-local/sky-local.db.tar.gz ]] ; then
sudo repo-add -n /opt/skywire/sky-local/sky-local.db.tar.gz $HOME/.cache/yay/hypervisorkey/hypervisorkey-*-any.pkg.tar.*
sudo ln -f $HOME/.cache/yay/hypervisorkey/hypervisorkey-*-any.pkg.tar.* /var/cache/pacman/pkg/
#add skywire to this repo if built from AUR ; it will be mirrored with everything else if it already exists in pacman's cache
[[ -f $HOME/.cache/yay/skywire/skywire*.pkg.tar.* ]] && sudo repo-add -n /opt/skywire/sky-local/sky-local.db.tar.gz $HOME/.cache/yay/skywire/skywire*.pkg.tar.*
else #repo exists; remove packages first
sudo repo-remove /opt/skywire/sky-local/sky-local.db.tar.gz hypervisorkey skywire
#then and add them back
sudo repo-add -n /opt/skywire/sky-local/sky-local.db.tar.gz $HOME/.cache/yay/hypervisorkey/hypervisorkey-*-any.pkg.tar.*
sudo ln -f $HOME/.cache/yay/hypervisorkey/hypervisorkey-*-any.pkg.tar.* /var/cache/pacman/pkg/
#add skywire to this repo if built from AUR ; it will be mirrored with everything else if it already exists in pacman's cache
[[ -f $HOME/.cache/yay/skywire/skywire*.pkg.tar.* ]] && sudo repo-add -n /opt/skywire/sky-local/sky-local.db.tar.gz $HOME/.cache/yay/skywire/skywire*.pkg.tar.*
fi

sudo pacman -Syy
sudo ln -f /var/lib/pacman/sync/* /var/cache/pacman/pkg/
sudo ln -f /opt/skywire/sky-local/* /var/cache/pacman/pkg/
#starts mirroring
#instruct user on configuration
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo "#On the remote system, add this to /etc/pacman.conf

[sky-local]
SigLevel = Never
Server = http://${_lanip}:8079

#On the remote system, Add this to /etc/pacman.d/mirrorlist

Server = http://${_lanip}:8079
"
echo "Starting readonly-cache service"

sudo systemctl enable --now readonly-cache
