#!/usr/bin/bash
#disallow root as it can't create packages
if [[ $EUID -eq 0 ]]; then
   echo "Can't do this as root" 1>&2
   exit 100
fi
#check that the hypervisorkey package was not installed - avoid unintended misconfiguration
pacman -Qi hypervisorconfig > /dev/null 2>&1 && echo "hypervisorkey package is installed, the node has been configured as a visor. Please uninstall it to do this." 1>&2 && exit 100
#create build dir path
mkdir -p ~/.cache/yay/
rm -rf ~/.cache/yay/hypervisorkey
#copy build dir from its installed location
cp -rb /opt/skywire/hypervisorkey ~/.cache/yay/hypervisorkey
cd ~/.cache/yay/hypervisorkey/
#get the hypervisor key from the configuration file and store it in hypervisorkey.txt
_hvisorkey=$(cat /opt/skywire/skywire.json |  grep '"pk":')
_hvisorkey=${_hvisorkey##*\"pk\": \"}
_hvisorkey=${_hvisorkey%\"*}
echo ${_hvisorkey} > hypervisorkey.txt
#OPTIONALLY prompt the user here to add more keys; skipped for automation
#create the hypervisorkey package
makepkg

#ask to set up repo
read -p "Include built package in aur-local repository and host on LAN? [y/n]" -n 1 -r
echo
[[ ! $REPLY =~ ^[Yy]$ ]] && exit 1

#use readonly-cache to set up a mirror and local package repo for nodes which contains the created package
cd ~/
sudo aur-local
#starts mirroring
#instruct user on configuration
_lanip=$(ifconfig | grep inet | head -n 1)
_lanip=${_lanip##*inet }
_lanip=${_lanip%% *}
echo "#On the remote system, add this to /etc/pacman.conf

[aur-local]
SigLevel = PackageRequired
Server = http://${_lanip}:8079

#On the remote system, Add this to /etc/pacman.d/mirrorlist

Server = http://${_lanip}:8079
"
sudo systemctl enable --now readonly-cache
