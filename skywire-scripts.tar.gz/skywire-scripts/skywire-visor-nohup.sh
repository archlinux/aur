#!/bin/bash
cd ~/
[ ! -d ~/apps ] && ln -s /usr/lib/skycoin/go/bin ~/apps
if [ ! -f ~/skywire-config.json ]; then
  exit
else
  nohup skywire-visor  > /dev/null 2>&1 &
fi
