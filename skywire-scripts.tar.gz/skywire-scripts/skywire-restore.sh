#!/usr/bin/bash
#disallow root as it can't create packages
if [[ $EUID -eq 0 ]]; then
   echo "Can't do this as root" 1>&2
   exit 100
fi

[[ -z $1 ]] && echo "please specify a path to the archived configuration" && exit
[[ ! -f $1 ]]  && echo "file not found" && exit
[[ $1 != *".tar.gz" ]]  && echo "expected archive format not specified" && exit
tar -xf $1
if [[ -f "skywire-save-1-1-any.pkg.tar.zst" ]] ; then
  sudo pacman -U skywire-save-1-1-any.pkg.tar.zst
  rm skywire-save-1-1-any.pkg.tar.zst
else
if [[ -f "skywire-save-1-1-any.pkg.tar.xz" ]] ; then
  sudo pacman -U skywire-save-1-1-any.pkg.tar.xz
  rm skywire-save-1-1-any.pkg.tar.xz
fi
fi
