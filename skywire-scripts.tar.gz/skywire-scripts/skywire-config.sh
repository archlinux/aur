#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 100
fi

    if [ -f /usr/lib/skycoin/skywire/hypervisorconfig/hypervisorinfo.txt ]; then
      skywire-cli visor gen-config -ro /etc/skywire-config.json
# create skywire-config.json and set hvisor ip nd key vars
    hvisorkey=$(head -n 1 /usr/lib/skycoin/skywire/hypervisorconfig/hypervisorinfo.txt)
    hvisorip=$(tail -n 1 /usr/lib/skycoin/skywire/hypervisorconfig/hypervisorinfo.txt)
    if [[ $(cat /etc/skywire-config.json | grep '"hypervisors": \[\],') = *'"hypervisors": [],'* ]]; then
      [ ! -f /etc/skywire-config.json.bak ] && cp /etc/skywire-config.json /etc/skywire-config.json.bak
      head -n 59 /etc/skywire-config.json > ~/skywire-config-0.json
      echo -e	'"hypervisors": [{' >> ~/skywire-config-0.json
      echo -e "$hvisorkey"  >> ~/skywire-config-0.json
    if [ -f /etc/hypervisor-config.json ]; then
      echo -e	'"address":"127.0.0.1:8000"' >> ~/skywire-config-0.json
    else
      #hvisorip="127.0.0.1" &&   echo	'"address":"$hvisorip:8080"'
      echo '"'address'"':'"'$hvisorip:8000'"' >> ~/skywire-config-0.json
    fi
      echo -e	"}]," >> ~/skywire-config-0.json
      tail -n 10 /etc/skywire-config.json >> ~/skywire-config-0.json
      mv ~/skywire-config-0.json /etc/skywire-config.json
      echo "Skywire configured successfully"
    else
      echo "Skywire configuration detected, no changes made"
    fi
else
echo "please install hypervisorconfig package"
fi
