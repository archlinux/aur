#!/bin/bash
#script requires skywire mainnet binaries
#assumes localhost is hypervisor
sudo killall skywire-hypervisor skywire-visor skychat setup-node skysocks skysocks-client
