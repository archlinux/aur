#!/bin/bash
#script requires skywire mainnet binaries
#assumes localhost is hypervisor
sudo killall skywire-hypervisor skywire-visor skywire-skychat skychat setup-node skywire-setup-node skysocks skywire-skysocks skysocks-client skywire-skysocks-client skywire-helloworld helloworld
