#ifndef ZFFVER
#define ZFFVER

void version_output ()
{
    printf ("Zff Version 6.0.1 Beta\nMade by ohzff 5+1 <https://github.com/ohzff/Zff-Reload>.\n");
    printf ("\nEnvironment information:\n");
    printf ("Zff version              6.0.14\n");
    printf ("Data path                %susr\n", DATAPATH);
}

#endif