#include "system_test.hpp"


#if defined (SYSLINUX) || defined (SYSUNIX) || defined (SYSMAC)

#define SYS

#endif