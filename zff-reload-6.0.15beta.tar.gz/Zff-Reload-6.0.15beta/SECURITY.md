# Security Policy

## Supported Versions

The following form tells you which version is protected. People use this supported version are welcomed to open issues to feedback bugs.

| Version | Supported          |
| ------- | ------------------ |
| **>= 6.0.8-beta**   | :white_check_mark: Developing now... |
| <= 6.0.7-beta| :x: Bugs fixed in the latest version. |
| [5.5.36 (ohzff/Zff)](https://github.com/ohzff/Zff/releases/tag/5.5.36)   | :white_check_mark: Zff version 5 |
| < 5.5.36   | :x: Out-dated |
