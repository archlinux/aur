# bashtuner
A guitar tuner written in bash.
To extend, add new tunings to the array. More are coming soon. I may also add other instruments such as the mandolin

Want to support my work? Check out my  [Liberapay page](https://liberapay.com/stormdragon2976), or my membership options on [Patreon](https://patreon.com/stormdragon2976).
