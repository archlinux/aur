# Contributing to the Tempus Themes project

See the [CONTRIBUTING.md included with the Tempus Themes Generator](https://github.com/protesilaos/tempus-themes-generator/blob/master/CONTRIBUTING.md).

Thank you for your interest!
