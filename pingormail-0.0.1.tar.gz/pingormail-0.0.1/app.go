package main

import (
	"crypto/tls"
	"fmt"
	"github.com/jordan-wright/email"
	"github.com/op/go-logging"
	"github.com/spf13/viper"
	"net/smtp"
	"os"
	"os/exec"
	"strings"
	"time"
)

func main() {
	// confPath := "cfg/"
	// confFilename := "pingormail_sample"
	// logFilename := "error.log"

	confPath := "/etc/pingormail/"
	confFilename := "pingormail"
	logFilename := "/var/log/pingormail/error.log"

	fd := initLogging(&logFilename)
	defer fd.Close()

	loadConfig(&confPath, &confFilename)

	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "-t":
			// On teste l'envoie de email
			str := "fictive.ip.org"
			retry := viper.GetInt("default.retry")
			sendMail(&str, &retry)
		default:
			// Fonction help
			argSplitted := strings.Split(os.Args[0], "/")
			nameApp := argSplitted[len(argSplitted)-1]
			fmt.Printf("Usage: %s <option>\n<option>:\n  -t\tsend a false email in order to test sends\n", nameApp)
		}
	} else {
		startApp()
	}
}

func isGood(out string) bool {
	outSplitted := strings.Split(out, "\n")

	for _, line := range outSplitted {
		if strings.Contains(line, " 0% packet loss") {
			return true
		}
	}

	return false
}

func sendMail(ip *string, maxRetry *int) {
	log := logging.MustGetLogger("log")

	host := viper.GetString("email.smtp")
	login := viper.GetString("email.login")
	password := viper.GetString("email.password")
	hostport := host + ":" + viper.GetString("email.port")
	from := viper.GetString("email.from")
	to := viper.GetStringSlice("email.sendTo")
	who := viper.GetString("location")

	// TLS config
	tlsconfig := &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         host,
	}

	e := email.NewEmail()
	e.From = from
	e.To = to
	e.Subject = "Machine introuvable"
	e.Text = []byte(fmt.Sprintf("Je suis %s. Après %d tests, je n'arrive pas à pinger \"%s\" !", who, *maxRetry, *ip))
	if err := e.SendWithTLS(hostport, smtp.PlainAuth("", login, password, host), tlsconfig); err != nil {
		log.Warningf("Impossible d'envoyer un email pour l'adresse \"%s\": %v", err)
	} else {
		log.Debugf("Email envoyée pour l'adresse \"%s\"", *ip)
	}
}

func testaddr(ipList *[]string, maxRetry *int) {
	log := logging.MustGetLogger("log")

	for _, ip := range *ipList {
		log.Debugf("Ping: %s", ip)
		loop := true
		counter := 0

		for loop {
			log.Debugf("Test %d de l'adresse %s", counter+1, ip)
			out, _ := exec.Command("/bin/sh", "-c", fmt.Sprintf("ping -c 1 %s", ip)).Output()
			if isGood(string(out)) {
				log.Debug("Ok")
				loop = false
			} else {
				counter++
				if counter >= *maxRetry {
					loop = false
					log.Debug("Fail")
					sendMail(&ip, maxRetry)
				} else {
					log.Debug("Fail")
				}
			}
		}
	}
}

func startApp() {
	log := logging.MustGetLogger("log")

	ipList := viper.GetStringSlice("default.addr")
	maxRetry := viper.GetInt("default.retry")
	waitingTime := viper.GetInt("default.waiting")

	log.Debugf("Liste d'ip: %s", ipList)
	log.Debugf("Nombre d'essais avant d'envoyer un mail: %d", maxRetry)
	log.Debugf("Temps d'attente entre 2 tests: %d", waitingTime)

	if waitingTime == 0 {
		log.Warning("Waiting time must be over 0 !")
		return
	}

	for {
		testaddr(&ipList, &maxRetry)
		time.Sleep(time.Duration(waitingTime) * time.Second)
	}
}
