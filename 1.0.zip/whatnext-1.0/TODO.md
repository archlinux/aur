# Implement Hooked system

## Trigger

Create a email trigger

Send status through email every morning.

Create notifications as well

## Variable reward

Give motivational quotes sometimes
