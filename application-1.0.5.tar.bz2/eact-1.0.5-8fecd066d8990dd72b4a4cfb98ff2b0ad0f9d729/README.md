# Electron Automated Compiling Toolkit

A toolkit for building your electron applications with Electron-packager and electron-build for non DRM and DRM applications and then zip them up ready for you to be distrobuted.

## Documentation

This script requires you to run it inside the electron folder and requires a package.json file so it can install the dependancies of your application. You will need to to install and have electron-packager and electron-builder in your package.json file beforehand. 

Once you have ran eact, eact will create folder a folder outside of the application called temp_output which is where the compiled and packaged applications will be stored.

## Important Note:
The build script will be named based on your folder name so make sure the folder name and the electron application name match exactly otherwise you will run into build and packaging issues with a mismatched name.

If you are unsure on what the build name is then do the following inside the electron folder.

```
npm i electron-packager
./node_modules/.bin/electron-packager .
```

And make sure the folder is the same name as the folder it created for the compiled app.

## All Commands
```
-e    Compiles your application using Electron
-w    Compiles your application using Electron Widevine for DRM content
-c    Cleans application folder by removing package-lock.json, node_modules folder, and dist folder
-v    Version
```

[Releases](https://gitlab.com/libelectron/eact/-/releases)


 ### Electron Automated Compiling Toolkit is avaliale on the AUR.
  
  [Click here](https://aur.archlinux.org/packages/eact)


&nbsp;&nbsp;&nbsp;&nbsp;

### Author

* Corey Bruce