#!/bin/bash 

cd /usr/lib/cloudflare-le/

for d in `./domains_to_renew.sh | sort | uniq`; do
	./pause_domain.sh $d;
done;