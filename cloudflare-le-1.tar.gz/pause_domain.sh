#!/bin/bash 

# apt-get install jq

source /etc/cloudflare-le/cloudflare.conf

CLOUDFLARE_ZONE_ID=`curl -X GET "https://api.cloudflare.com/client/v4/zones?name=${1}&status=active&page=1&per_page=20&order=status&direction=desc&match=all" \
-H "X-Auth-Email: ${CLOUDFLARE_USER}" \
-H "X-Auth-Key: ${CLOUDFLARE_KEY}" \
-H "Content-Type: application/json" 2> /dev/null | jq -r ".result[0].id"`

RESULT=`curl -X PATCH "https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}" \
-H "X-Auth-Email: ${CLOUDFLARE_USER}" \
-H "X-Auth-Key: ${CLOUDFLARE_KEY}" \
-H "Content-Type: application/json" \
--data '{"paused":true}' 2> /dev/null | jq -r ".success, .errors, .messages"`

echo $RESULT