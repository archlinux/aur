#!/bin/bash

source /etc/cloudflare-le/cloudflare.conf

for f in ${CLOUDFLARE_DOMAINS[@]}; do
	echo $f
done