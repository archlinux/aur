Name:           sshf
Version:        1.0.0
Release:        1%{?dist}
Summary:        SSH Host Manager TUI (Rust)
License:        MIT
URL:            https://github.com/Rooterts/sshf
Source0:        %{name}-%{version}.tar.gz
BuildRequires:  rust cargo
Requires:       openssl zlib

%description
SSH Host Manager TUI for managing SSH hosts with a modern interface.

%prep
%setup -q

%build
cargo build --release --locked

%install
install -Dm755 target/release/sshf %{buildroot}/usr/bin/sshf
install -Dm644 README.md %{buildroot}/usr/share/doc/sshf/README.md
install -Dm644 LICENSE %{buildroot}/usr/share/licenses/sshf/LICENSE

%files
/usr/bin/sshf
/usr/share/doc/sshf/README.md
/usr/share/licenses/sshf/LICENSE

%changelog
* Mon May 19 2025 Adrian Perez Perez <ap393409@gmail.com> - 1.0.0-1
- Initial package
