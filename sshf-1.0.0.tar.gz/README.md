# sshf

SSH Host Manager TUI / Gestor de hosts SSH con TUI

---

## Instalación rápida / Quick install

### Arch Linux (AUR)
```zsh
git clone https://github.com/Rooterts/sshf.git
cd sshf
makepkg -si
```

### Debian/Ubuntu (.deb)
```zsh
git clone https://github.com/Rooterts/sshf.git
cd sshf
sudo apt install cargo rustc debhelper
# Empaquetar y generar .deb
cp debian.control debian/control
cp debian.rules debian/rules
cp debian.install debian/install
chmod +x debian/rules
cargo build --release
dpkg-buildpackage -us -uc -b
sudo dpkg -i ../sshf_1.0.0_amd64.deb
```

### Fedora (.rpm)
```zsh
git clone https://github.com/Rooterts/sshf.git
cd sshf
sudo dnf install cargo rustc rpm-build
# Empaquetar y generar .rpm
cargo build --release
rpmbuild -bb sshf.spec
sudo rpm -i ~/rpmbuild/RPMS/x86_64/sshf-1.0.0-1.x86_64.rpm
```

### macOS (Homebrew)
```zsh
brew tap Rooterts/sshf
brew install sshf
```

### Windows (Scoop)
```powershell
scoop bucket add sshf https://github.com/Rooterts/sshf
scoop install sshf
```

### Universal (cualquier sistema con Rust)
```zsh
cargo install --git https://github.com/Rooterts/sshf
```

---

## English

**sshf** is a terminal user interface (TUI) tool to manage, search, and connect to SSH hosts defined in your `~/.ssh/config`. It supports adding new hosts, creating temporary shell aliases, automatic shell integration (zsh, bash, fish), light/dark themes, and multi-language support (en/es).

### Features
- Search and connect to SSH hosts from `~/.ssh/config`
- Add new hosts from the TUI
- Create temporary aliases for hosts (with shell integration)
- Automatic integration with zsh, bash, and fish
- Light/dark themes and multi-language (en/es)

### Usage
```
sshf                # Open the TUI interface
sshf install        # Install automatic shell integration
sshf user@host      # Connect directly using sshf as a wrapper
sshf --help         # Show help (in your configured language)
```

### Configuration
Edit `~/.config/sshf/config.toml` to set language and theme:
```
lang = "en"   # or "es"
theme = "dark" # or "light"
```

### Note
After creating a temporary alias, run `source ~/.zshrc` (or the equivalent for your shell) to activate it in your current terminal. Automatic reload only affects subshells.

---

## Español

**sshf** es una herramienta TUI para gestionar, buscar y conectar a hosts SSH definidos en tu `~/.ssh/config`. Permite agregar hosts, crear alias temporales, integración automática con la shell (zsh, bash, fish), temas claro/oscuro y soporte multilenguaje (es/en).

### Funcionalidades
- Buscar y conectar a hosts SSH desde `~/.ssh/config`
- Agregar nuevos hosts desde la TUI
- Crear alias temporales para hosts (con integración en la shell)
- Integración automática con zsh, bash y fish
- Temas claro/oscuro y soporte multilenguaje (es/en)

### Uso
```
sshf                # Abre la interfaz TUI
sshf install        # Instala la integración automática con la shell
sshf usuario@host   # Conecta directamente usando sshf como wrapper
sshf --help         # Muestra la ayuda (en tu idioma configurado)
```

### Configuración
Edita `~/.config/sshf/config.toml` para idioma y tema:
```
lang = "es"   # o "en"
theme = "dark" # o "light"
```

### Nota
Tras crear un alias temporal, ejecuta `source ~/.zshrc` (o el equivalente para tu shell) para activarlo en tu terminal actual. La recarga automática solo afecta a subshells.

---

## License
MIT
