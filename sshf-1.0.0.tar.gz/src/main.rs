// sshf: SSH Host Manager TUI
// Gestor de hosts SSH con TUI, integración de shell y alias temporales.
// SSH Host manager with TUI, shell integration and temporary alias support.

use std::{
    env,
    fs::{self, OpenOptions},
    io::{self, BufRead, BufReader, Write},
    path::Path,
    process::{Command, exit},
    time::Duration,
    collections::HashMap,
};

use crossterm::{
    event::{self, DisableMouseCapture, EnableMouseCapture, Event, KeyCode},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use tui::{
    backend::CrosstermBackend,
    widgets::{Block, Borders, List, ListItem, ListState},
    style::{Style, Modifier, Color},
    Terminal,
};

// =====================
// User configuration
// Configuración de usuario
// =====================
#[derive(Debug, Clone)]
struct UserConfig {
    lang: String,   // Idioma / Language
    theme: Theme,   // Tema visual / Theme
}

impl Default for UserConfig {
    fn default() -> Self {
        UserConfig {
            lang: detect_language(),
            theme: Theme::default(),
        }
    }
}

// Detect system language (es/en)
// Detecta el idioma del sistema (es/en)
fn detect_language() -> String {
    if let Ok(lang) = env::var("LANG") {
        if lang.starts_with("es") {
            return "es".to_string();
        } else if lang.starts_with("en") {
            return "en".to_string();
        }
    }
    "en".to_string()
}

// Load user config from ~/.config/sshf/config.toml
// Carga la configuración de usuario desde ~/.config/sshf/config.toml
fn load_user_config() -> UserConfig {
    let home = env::var("HOME").unwrap_or_default();
    let config_path = Path::new(&home).join(".config/sshf/config.toml");
    if config_path.exists() {
        if let Ok(content) = fs::read_to_string(&config_path) {
            let mut lang = detect_language();
            let mut theme = Theme::default();
            for line in content.lines() {
                let line = line.trim();
                if line.starts_with("lang = ") {
                    lang = line[7..].replace('"', "").trim().to_string();
                } else if line.starts_with("theme = ") {
                    let t = line[8..].replace('"', "").trim().to_string();
                    if t == "dark" {
                        theme = Theme {
                            border_color: Color::White,
                            highlight_color: Color::Yellow,
                            highlight_bg: Color::Black,
                            title_color: Color::Cyan,
                        };
                    } else if t == "light" {
                        theme = Theme {
                            border_color: Color::Blue,
                            highlight_color: Color::Black,
                            highlight_bg: Color::White,
                            title_color: Color::Blue,
                        };
                    }
                }
            }
            return UserConfig { lang, theme };
        }
    }
    UserConfig::default()
}

// --- Traducción de mensajes ---
fn tr<'a>(key: &'a str, lang: &str) -> &'a str {
    let mut dict = HashMap::new();
    dict.insert(("select_host", "es"), "Selecciona un host (q para salir)");
    dict.insert(("add_host", "es"), "[+] Agregar nuevo host");
    dict.insert(("no_hosts", "es"), "No hay hosts guardados en ~/.ssh/config");
    dict.insert(("add_host_prompt", "es"), "Agregar nuevo host SSH");
    dict.insert(("user_host", "es"), "Usuario@host o IP: ");
    dict.insert(("alias_prompt", "es"), "Nombre para el host (ENTER para usar el valor por defecto): ");
    dict.insert(("saved", "es"), "Host guardado como");
    dict.insert(("alias_shell", "es"), "¿Deseas crear un alias temporal para este host en tu shell? (s/n): ");
    dict.insert(("select_host", "en"), "Select a host (q to quit)");
    dict.insert(("add_host", "en"), "[+] Add new host");
    dict.insert(("no_hosts", "en"), "No hosts found in ~/.ssh/config");
    dict.insert(("add_host_prompt", "en"), "Add new SSH host");
    dict.insert(("user_host", "en"), "User@host or IP: ");
    dict.insert(("alias_prompt", "en"), "Alias for the host (ENTER to use default): ");
    dict.insert(("saved", "en"), "Host saved as");
    dict.insert(("alias_shell", "en"), "Do you want to create a shell alias for this host? (y/n): ");
    dict.get(&(key, lang)).copied().unwrap_or(key)
}

// --- Integración con la shell ---
fn install_integration() -> io::Result<()> {
    let shell = env::var("SHELL").unwrap_or_default();
    let home = env::var("HOME").unwrap_or_default();
    let (rc_file, func, reload_cmd) = if shell.contains("zsh") {
        (".zshrc", r#"
ssh() {
    if command -v sshf >/dev/null 2>&1; then
        sshf "$@"
    else
        command ssh "$@"
    fi
}
"#, "source ~/.zshrc")
    } else if shell.contains("bash") {
        (".bashrc", r#"
ssh() {
    if command -v sshf >/dev/null 2>&1; then
        sshf "$@"
    else
        command ssh "$@"
    fi
}
"#, "source ~/.bashrc")
    } else if shell.contains("fish") {
        (".config/fish/functions/ssh.fish", r#"
function ssh
    if type -q sshf
        sshf $argv
    else
        command ssh $argv
    end
end
"#, "source ~/.config/fish/functions/ssh.fish")
    } else {
        println!("Shell no soportada para integración automática.");
        return Ok(());
    };
    let rc_path = Path::new(&home).join(rc_file);
    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&rc_path)?;
    writeln!(file, "\n# Integración automática de sshf\n{}", func)?;
    println!("Integración añadida a {}.", rc_path.display());
    println!("Por favor, recarga tu shell con: {} o abre una nueva terminal.", reload_cmd);
    Ok(())
}

fn ensure_shell_integration() -> io::Result<()> {
    let shell = env::var("SHELL").unwrap_or_default();
    let home = env::var("HOME").unwrap_or_default();
    let (rc_file, marker) = if shell.contains("zsh") {
        (".zshrc", "# Integración automática de sshf")
    } else if shell.contains("bash") {
        (".bashrc", "# Integración automática de sshf")
    } else if shell.contains("fish") {
        (".config/fish/functions/ssh.fish", "# Integración automática de sshf")
    } else {
        return Ok(());
    };
    let rc_path = Path::new(&home).join(rc_file);
    if rc_path.exists() {
        if let Ok(content) = fs::read_to_string(&rc_path) {
            if content.contains(marker) {
                return Ok(()); // Ya está integrado
            }
        }
    }
    install_integration()
}

// --- Lógica del wrapper SSH ---
fn ssh_wrapper(args: Vec<String>) -> io::Result<()> {
    if args.is_empty() {
        eprintln!("Uso: sshf usuario@host [opciones]");
        exit(1);
    }
    let ssh_target = &args[0];
    let home = env::var("HOME").expect("No se pudo obtener $HOME");
    let ssh_config_path = Path::new(&home).join(".ssh").join("config");
    let mut exists = false;
    if ssh_config_path.exists() {
        let file = fs::File::open(&ssh_config_path)?;
        let reader = BufReader::new(file);
        for line in reader.lines() {
            let line = line?;
            if line.trim_start().starts_with("Host ") {
                let alias = line.trim_start()[5..].trim();
                if alias == ssh_target {
                    exists = true;
                    break;
                }
            }
            if line.trim_start().starts_with("HostName ") && line.contains(ssh_target.split('@').last().unwrap()) {
                exists = true;
                break;
            }
        }
    }
    if !exists {
        println!("El host '{}' no está guardado en ~/.ssh/config.", ssh_target);
        print!("¿Quieres guardarlo? (s/n): ");
        io::stdout().flush()?;
        let mut resp = String::new();
        io::stdin().read_line(&mut resp)?;
        if resp.trim().to_lowercase() == "s" {
            print!("Nombre para el host (ENTER para usar '{}'): ", ssh_target);
            io::stdout().flush()?;
            let mut alias = String::new();
            io::stdin().read_line(&mut alias)?;
            let alias = if alias.trim().is_empty() {
                ssh_target.clone()
            } else {
                alias.trim().to_string()
            };
            let (user, host) = if let Some((u, h)) = ssh_target.split_once('@') {
                (u, h)
            } else {
                ("", ssh_target.as_str())
            };
            let mut file = OpenOptions::new()
                .create(true)
                .append(true)
                .open(&ssh_config_path)?;
            writeln!(file, "\nHost {}", alias)?;
            writeln!(file, "    HostName {}", host)?;
            if !user.is_empty() {
                writeln!(file, "    User {}", user)?;
            }
            println!("Host guardado como '{}'.", alias);
            let mut new_args = args.clone();
            new_args[0] = alias;
            return exec_ssh(new_args);
        }
    }
    exec_ssh(args)
}

fn exec_ssh(args: Vec<String>) -> io::Result<()> {
    let status = Command::new("ssh")
        .args(&args)
        .status()?;
    exit(status.code().unwrap_or(1));
}

// --- Temas y estilos personalizados para la TUI ---
#[derive(Debug, Clone)]
struct Theme {
    border_color: Color,
    highlight_color: Color,
    highlight_bg: Color,
    title_color: Color,
}

impl Default for Theme {
    fn default() -> Self {
        Theme {
            border_color: Color::Blue,
            highlight_color: Color::Yellow,
            highlight_bg: Color::Black,
            title_color: Color::Cyan,
        }
    }
}

// --- TUI principal mejorada ---
fn tui_main() -> Result<(), Box<dyn std::error::Error>> {
    ensure_shell_integration()?;
    let config = load_user_config();
    let theme = config.theme.clone();
    let lang = config.lang.as_str();
    let home = env::var("HOME")?;
    let ssh_config_path = Path::new(&home).join(".ssh").join("config");
    let mut hosts = Vec::new();
    if ssh_config_path.exists() {
        let file = fs::File::open(&ssh_config_path)?;
        let reader = BufReader::new(file);
        for line in reader.lines() {
            let line = line?;
            if line.trim_start().starts_with("Host ") {
                let alias = line.trim_start()[5..].trim().to_string();
                if alias != "*" {
                    hosts.push(alias);
                }
            }
        }
    }
    hosts.push(tr("add_host", lang).to_string());
    if hosts.len() == 1 {
        println!("{}", tr("no_hosts", lang));
        return Ok(());
    }
    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;
    let mut input = String::new();
    let mut selected = 0usize;
    let mut list_state = ListState::default();
    list_state.select(Some(selected));
    // Estado para modal de agregar host
    let mut show_add_modal = false;
    let mut add_host_input = String::new();
    let mut add_alias_input = String::new();
    let mut add_step = 0; // 0: user@host, 1: alias
    let mut info_message = String::new();
    let mut show_info = false;
    // Estado para modal de alias temporal
    let mut show_alias_modal = false;
    let mut alias_result_message = String::new();
    let mut alias_input = String::new();
    loop {
        // Filtrar hosts según el input
        let filtered_hosts: Vec<String> = hosts.iter()
            .filter(|h| h.to_lowercase().contains(&input.to_lowercase()) || h == &&tr("add_host", lang))
            .cloned().collect();
        if selected >= filtered_hosts.len() { selected = 0; }
        list_state.select(Some(selected));
        terminal.draw(|f| {
            let size = f.size();
            // Layout principal
            use tui::text::{Span, Spans};
            let block = Block::default()
                .title(Spans::from(vec![Span::styled(
                    tr("select_host", lang),
                    Style::default().fg(theme.title_color).add_modifier(Modifier::BOLD),
                )]))
                .borders(Borders::ALL)
                .border_style(Style::default().fg(theme.border_color));
            // Barra de búsqueda con texto visible y alineado
            let search_label = "[ / ] Buscar: ";
            let search_bar = Block::default()
                .title("")
                .borders(Borders::BOTTOM)
                .border_style(Style::default().fg(theme.border_color));
            let search_text = format!("{}{}", search_label, input);
            let search_paragraph = tui::widgets::Paragraph::new(search_text.clone())
                .block(search_bar)
                .style(Style::default().fg(Color::White));
            // Lista de hosts
            let items: Vec<ListItem> = filtered_hosts
                .iter()
                .map(|h| ListItem::new(h.clone()))
                .collect();
            let list = List::new(items)
                .block(block)
                .highlight_style(
                    Style::default()
                        .fg(theme.highlight_color)
                        .bg(theme.highlight_bg)
                        .add_modifier(Modifier::BOLD | Modifier::REVERSED),
                )
                .highlight_symbol("» ");
            // Layouts
            let chunks = tui::layout::Layout::default()
                .direction(tui::layout::Direction::Vertical)
                .margin(2)
                .constraints([
                    tui::layout::Constraint::Length(3),
                    tui::layout::Constraint::Min(5),
                    tui::layout::Constraint::Length(2),
                ])
                .split(size);
            // Barra de búsqueda con texto
            f.render_widget(search_paragraph, chunks[0]);
            // El cursor va justo después del texto ingresado
            f.set_cursor(
                chunks[0].x + search_label.len() as u16 + input.len() as u16,
                chunks[0].y + 1,
            );
            // Lista de hosts
            f.render_stateful_widget(list, chunks[1], &mut list_state);
            // Menú de ayuda/información
            let help = format!(
                "[↑/↓] Navegar  [Enter] Conectar  [Ctrl+A] Alias  [Esc] Salir  [/] Buscar  [Enter en '+'] Agregar host"
            );
            let help_block = Block::default()
                .borders(Borders::NONE)
                .title("")
                .style(Style::default().fg(Color::DarkGray));
            f.render_widget(tui::widgets::Paragraph::new(help).block(help_block), chunks[2]);
            // Modal para agregar host
            if show_add_modal {
                let modal_area = tui::layout::Rect {
                    x: size.width / 2 - 30,
                    y: size.height / 2 - 5,
                    width: 60,
                    height: 7,
                };
                let modal_block = Block::default()
                    .title(tr("add_host_prompt", lang))
                    .borders(Borders::ALL)
                    .border_style(Style::default().fg(Color::Magenta));
                let (label, value) = if add_step == 0 {
                    (tr("user_host", lang), &add_host_input)
                } else {
                    (tr("alias_prompt", lang), &add_alias_input)
                };
                let content = format!("{}\n> {}", label, value);
                f.render_widget(tui::widgets::Paragraph::new(content).block(modal_block), modal_area);
                // Cursor en el modal
                f.set_cursor(
                    modal_area.x + 2 + label.len() as u16 + 2 + value.len() as u16,
                    modal_area.y + 1,
                );
            }
            // Modal para crear alias temporal (ahora pide el nombre del alias)
            if show_alias_modal {
                let modal_area = tui::layout::Rect {
                    x: size.width / 2 - 30,
                    y: size.height / 2 - 5,
                    width: 60,
                    height: 7,
                };
                let modal_block = Block::default()
                    .title("Nombre del alias temporal")
                    .borders(Borders::ALL)
                    .border_style(Style::default().fg(Color::Magenta));
                let prompt = "Alias: ";
                let content = format!("{}{}", prompt, alias_input);
                f.render_widget(tui::widgets::Paragraph::new(content).block(modal_block), modal_area);
                f.set_cursor(
                    modal_area.x + prompt.len() as u16 + alias_input.len() as u16 + 1,
                    modal_area.y + 1,
                );
            }
            // Mensaje informativo
            if show_info {
                let info_area = tui::layout::Rect {
                    x: size.width / 2 - 25,
                    y: size.height / 2 + 5,
                    width: 50,
                    height: 3,
                };
                let info_block = Block::default()
                    .borders(Borders::ALL)
                    .border_style(Style::default().fg(Color::Green));
                f.render_widget(tui::widgets::Paragraph::new(info_message.clone()).block(info_block), info_area);
            }
            // Mensaje de resultado de alias
            if !alias_result_message.is_empty() {
                // Área más grande y centrada, con wrap
                let info_area = tui::layout::Rect {
                    x: size.width / 2 - 35,
                    y: size.height / 2 - 4,
                    width: 70,
                    height: 7,
                };
                let info_block = Block::default()
                    .borders(Borders::ALL)
                    .border_style(Style::default().fg(Color::Green));
                f.render_widget(
                    tui::widgets::Paragraph::new(alias_result_message.clone())
                        .block(info_block)
                        .wrap(tui::widgets::Wrap { trim: true }),
                    info_area,
                );
            }
        })?;
        if event::poll(Duration::from_millis(200))? {
            if let Event::Key(key) = event::read()? {
                if show_add_modal {
                    match key.code {
                        KeyCode::Esc => {
                            show_add_modal = false;
                            add_host_input.clear();
                            add_alias_input.clear();
                            add_step = 0;
                        }
                        KeyCode::Enter => {
                            if add_step == 0 {
                                if !add_host_input.trim().is_empty() {
                                    add_step = 1;
                                }
                            } else {
                                // Guardar host
                                let target = add_host_input.trim();
                                let alias = if add_alias_input.trim().is_empty() {
                                    target.to_string()
                                } else {
                                    add_alias_input.trim().to_string()
                                };
                                let (user, host) = if let Some((u, h)) = target.split_once('@') {
                                    (u, h)
                                } else {
                                    ("", target)
                                };
                                let mut file = OpenOptions::new()
                                    .create(true)
                                    .append(true)
                                    .open(&ssh_config_path)?;
                                writeln!(file, "\nHost {}", alias)?;
                                writeln!(file, "    HostName {}", host)?;
                                if !user.is_empty() {
                                    writeln!(file, "    User {}", user)?;
                                }
                                info_message = format!("{} '{}'.", tr("saved", lang), alias);
                                show_info = true;
                                show_add_modal = false;
                                add_host_input.clear();
                                add_alias_input.clear();
                                add_step = 0;
                                // Refrescar hosts
                                hosts.clear();
                                if ssh_config_path.exists() {
                                    let file = fs::File::open(&ssh_config_path)?;
                                    let reader = BufReader::new(file);
                                    for line in reader.lines() {
                                        let line = line?;
                                        if line.trim_start().starts_with("Host ") {
                                            let alias = line.trim_start()[5..].trim().to_string();
                                            if alias != "*" {
                                                hosts.push(alias);
                                            }
                                        }
                                    }
                                }
                                hosts.push(tr("add_host", lang).to_string());
                                input.clear();
                                selected = 0;
                            }
                        }
                        KeyCode::Backspace => {
                            if add_step == 0 {
                                add_host_input.pop();
                            } else {
                                add_alias_input.pop();
                            }
                        }
                        KeyCode::Char(c) => {
                            if add_step == 0 {
                                add_host_input.push(c);
                            } else {
                                add_alias_input.push(c);
                            }
                        }
                        _ => {}
                    }
                } else if show_alias_modal {
                    match key.code {
                        KeyCode::Esc => {
                            show_alias_modal = false;
                            alias_input.clear();
                        }
                        KeyCode::Enter => {
                            let alias_name = alias_input.trim().to_string();
                            if !alias_name.is_empty() {
                                // Crear alias temporal en shell
                                let shell = env::var("SHELL").unwrap_or_default();
                                let home = env::var("HOME").unwrap_or_default();
                                let filtered_hosts: Vec<String> = hosts.iter()
                                    .filter(|h| h.to_lowercase().contains(&input.to_lowercase()) || h == &&tr("add_host", lang))
                                    .cloned().collect();
                                let alias_host = &filtered_hosts[selected];
                                // El alias ejecuta 'ssh <alias_host>'
                                let ssh_cmd = format!("ssh {}", alias_host);
                                let (rc_file, alias_cmd, reload_cmd) = if shell.contains("zsh") {
                                    (".zshrc", format!("alias {}='{}'", alias_name, ssh_cmd), "source ~/.zshrc")
                                } else if shell.contains("bash") {
                                    (".bashrc", format!("alias {}='{}'", alias_name, ssh_cmd), "source ~/.bashrc")
                                } else if shell.contains("fish") {
                                    (".config/fish/config.fish", format!("alias {} '{}'", alias_name, ssh_cmd), "source ~/.config/fish/config.fish")
                                } else {
                                    (".bashrc", format!("alias {}='{}'", alias_name, ssh_cmd), "")
                                };
                                let rc_path = Path::new(&home).join(rc_file);
                                if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(&rc_path) {
                                    let _ = writeln!(file, "\n# Alias automático de sshf\n{}", alias_cmd);
                                    // Ejecutar comando de recarga automáticamente
                                    if !reload_cmd.is_empty() {
                                        #[allow(unused_must_use)]
                                        {
                                            std::process::Command::new(shell.clone())
                                                .arg("-c")
                                                .arg(reload_cmd)
                                                .output();
                                        }
                                    }
                                    alias_result_message = if reload_cmd.is_empty() {
                                        if lang == "es" {
                                            format!("Alias añadido a {}: {}\n\nNOTA: Para usar el alias en tu terminal actual, ejecuta manualmente el comando de recarga de tu shell o abre una nueva terminal.", rc_path.display(), alias_cmd)
                                        } else {
                                            format!("Alias added to {}: {}\n\nNOTE: To use the alias in your current terminal, run the reload command for your shell manually or open a new terminal.", rc_path.display(), alias_cmd)
                                        }
                                    } else {
                                        if lang == "es" {
                                            format!("Alias añadido a {}: {}\n\nIMPORTANTE: Para que el alias esté disponible en tu terminal actual, ejecuta manualmente:\n  {}\nO abre una nueva terminal.\n\n(La recarga automática solo afecta a subshells, no a la terminal actual)", rc_path.display(), alias_cmd, reload_cmd)
                                        } else {
                                            format!("Alias added to {}: {}\n\nIMPORTANT: To make the alias available in your current terminal, run:\n  {}\nOr open a new terminal.\n\n(Automatic reload only affects subshells, not your current terminal)", rc_path.display(), alias_cmd, reload_cmd)
                                        }
                                    };
                                } else {
                                    alias_result_message = format!("Error al escribir el alias '{}'.", alias_name);
                                }
                            } else {
                                alias_result_message = if lang == "es" { "Alias cancelado".to_string() } else { "Alias cancelled".to_string() };
                            }
                            show_alias_modal = false;
                            alias_input.clear();
                        }
                        KeyCode::Backspace => {
                            alias_input.pop();
                        }
                        KeyCode::Char(c) => {
                            if alias_input.len() < 32 { alias_input.push(c); }
                        }
                        _ => {}
                    }
                } else if !alias_result_message.is_empty() {
                    // Cerrar mensaje de alias con cualquier tecla
                    alias_result_message.clear();
                } else if show_info {
                    // Cerrar mensaje informativo con cualquier tecla
                    show_info = false;
                } else {
                    // --- PRIORIDAD: Ctrl+A antes que escritura ---
                    match key.code {
                        KeyCode::Char('a') if key.modifiers == crossterm::event::KeyModifiers::CONTROL => {
                            // Mostrar modal de alias en TUI
                            if !hosts.is_empty() && hosts[selected] != tr("add_host", lang) {
                                show_alias_modal = true;
                                alias_input.clear();
                            }
                        }
                        KeyCode::Char('/') => {
                            // Enfocar barra de búsqueda (ya está por defecto)
                        }
                        KeyCode::Char(c) => {
                            input.push(c);
                            selected = 0;
                        }
                        KeyCode::Backspace => {
                            input.pop();
                            selected = 0;
                        }
                        KeyCode::Down => {
                            if selected + 1 < filtered_hosts.len() {
                                selected += 1;
                            }
                        }
                        KeyCode::Up => {
                            if selected > 0 {
                                selected -= 1;
                            }
                        }
                        KeyCode::Enter => {
                            if filtered_hosts[selected] == tr("add_host", lang) {
                                show_add_modal = true;
                                add_host_input.clear();
                                add_alias_input.clear();
                                add_step = 0;
                            } else {
                                disable_raw_mode()?;
                                execute!(
                                    terminal.backend_mut(),
                                    LeaveAlternateScreen,
                                    DisableMouseCapture
                                )?;
                                terminal.show_cursor()?;
                                let alias = &filtered_hosts[selected];
                                let status = Command::new("ssh")
                                    .arg(alias)
                                    .status()?;
                                exit(status.code().unwrap_or(1));
                            }
                        }
                        KeyCode::Esc => {
                            break;
                        }
                        _ => {}
                    }
                }
            }
        }
    }
    disable_raw_mode()?;
    execute!(
        terminal.backend_mut(),
        LeaveAlternateScreen,
        DisableMouseCapture
    )?;
    terminal.show_cursor()?;
    Ok(())
}

// --- Mostrar ayuda ---
fn print_help(lang: &str) {
    if lang == "es" {
        println!(r#"
sshf - Gestor de hosts SSH con TUI

USO:
  sshf                # Abre la interfaz TUI
  sshf install        # Instala la integración automática con la shell
  sshf usuario@host   # Conecta directamente usando sshf como wrapper
  sshf --help         # Muestra esta ayuda

FUNCIONALIDADES:
- Buscar y conectar a hosts SSH definidos en ~/.ssh/config
- Agregar nuevos hosts desde la TUI
- Crear alias temporales para hosts
- Integración automática con zsh, bash y fish
- Temas claro/oscuro y soporte multilenguaje (es/en)
- Alias temporales: tras crearlos, ejecuta 'source ~/.zshrc' (o equivalente) para activarlos en tu terminal actual

CONFIGURACIÓN:
Edita ~/.config/sshf/config.toml para idioma y tema:
lang = "es"   # o "en"
theme = "dark" # o "light"
"#);
    } else {
        println!(r#"
sshf - SSH host manager with TUI

USAGE:
  sshf                # Open the TUI interface
  sshf install        # Install automatic shell integration
  sshf user@host      # Connect directly using sshf as a wrapper
  sshf --help         # Show this help

FEATURES:
- Search and connect to SSH hosts defined in ~/.ssh/config
- Add new hosts from the TUI
- Create temporary aliases for hosts
- Automatic integration with zsh, bash and fish
- Light/dark themes and multi-language support (es/en)
- Temporary aliases: after creation, run 'source ~/.zshrc' (or equivalent) to activate in your current terminal

CONFIGURATION:
Edit ~/.config/sshf/config.toml for language and theme:
lang = "en"   # or "es"
theme = "dark" # or "light"
"#);
    }
}

// --- main ---
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().collect();
    // Show help if --help is present
    if args.iter().any(|a| a == "--help" || a == "-h") {
        let config = load_user_config();
        let lang = config.lang.as_str();
        print_help(lang);
        return Ok(());
    }
    if args.len() > 1 && args[1] == "install" {
        return Ok(install_integration()?);
    }
    let args: Vec<String> = args.into_iter().skip(1).collect();
    if args.is_empty() {
        return tui_main();
    } else {
        return Ok(ssh_wrapper(args)?);
    }
}
