class Sshf < Formula
  desc "SSH Host Manager TUI (Rust)"
  homepage "https://github.com/Rooterts/sshf"
  url "https://github.com/Rooterts/sshf/archive/refs/tags/v1.0.0.tar.gz"
  sha256 "SKIP"
  license "MIT"

  depends_on "rust" => :build

  def install
    system "cargo", "install", *std_cargo_args
  end

  test do
    system "sshf", "--help"
  end
end
