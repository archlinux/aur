#!/bin/bash
#
# Zeta Package Manager 安装脚本
# 作者: Zeta <3380089537@qq.com>
#

set -e

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 配置
ZPM_NAME="Zeta Package Manager"
ZPM_VERSION="1.0.0"
ZPM_AUTHOR="Zeta <3380089537@qq.com>"

# 安装路径
PREFIX="${PREFIX:-/usr}"
BIN_DIR="${PREFIX}/bin"
LIB_DIR="${PREFIX}/lib/zpm"
CONFIG_DIR="/etc/zpm"

# 用户目录
USER_HOME="${HOME}"
USER_CONFIG="${USER_HOME}/.zpm"

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}  ${ZPM_NAME} 安装程序${NC}"
echo -e "${CYAN}  版本: ${ZPM_VERSION}${NC}"
echo -e "${CYAN}  作者: ${ZPM_AUTHOR}${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# 检查 root 权限
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${YELLOW}警告: 未以 root 身份运行，将安装到用户目录${NC}"
        PREFIX="${USER_HOME}/.local"
        BIN_DIR="${PREFIX}/bin"
        LIB_DIR="${PREFIX}/lib/zpm"
        CONFIG_DIR="${USER_CONFIG}/config"
        return 1
    fi
    return 0
}

# 检查依赖
check_dependencies() {
    echo -e "${CYAN}检查依赖...${NC}"

    local deps=("bash" "curl" "jq" "git" "tar" "gzip" "python3")
    local missing=()

    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            missing+=("$dep")
        fi
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        echo -e "${YELLOW}缺少以下依赖: ${missing[*]}${NC}"
        echo -e "${YELLOW}请使用 pacman 安装: sudo pacman -S ${missing[*]}${NC}"
        exit 1
    fi

    echo -e "${GREEN}所有依赖已满足${NC}"
}

# 创建目录
create_directories() {
    echo -e "${CYAN}创建目录...${NC}"

    local dirs=("$BIN_DIR" "$LIB_DIR" "$LIB_DIR/sh" "$LIB_DIR/python" "$CONFIG_DIR")

    for dir in "${dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir" || {
                echo -e "${RED}无法创建目录: $dir${NC}"
                exit 1
            }
            echo "  创建: $dir"
        fi
    done

    # 创建用户目录
    if [[ ! -d "$USER_CONFIG" ]]; then
        mkdir -p "$USER_CONFIG"/{cache,build,config,logs}
        echo "  创建: $USER_CONFIG"
    fi
}

# 安装文件
install_files() {
    echo -e "${CYAN}安装文件...${NC}"

    # 安装主程序
    if [[ -f "bin/zpm" ]]; then
        cp "bin/zpm" "$BIN_DIR/"
        chmod +x "$BIN_DIR/zpm"
        echo "  安装: $BIN_DIR/zpm"
    else
        echo -e "${RED}找不到主程序: bin/zpm${NC}"
        exit 1
    fi

    # 安装 Shell 模块
    if [[ -d "lib/sh" ]]; then
        for file in lib/sh/*.sh; do
            if [[ -f "$file" ]]; then
                cp "$file" "$LIB_DIR/sh/"
                echo "  安装: $LIB_DIR/sh/$(basename "$file")"
            fi
        done
    fi

    # 安装 Python 模块
    if [[ -d "lib/python" ]]; then
        for file in lib/python/*.py; do
            if [[ -f "$file" ]]; then
                cp "$file" "$LIB_DIR/python/"
                chmod +x "$LIB_DIR/python/$(basename "$file")"
                echo "  安装: $LIB_DIR/python/$(basename "$file")"
            fi
        done
    fi

    # 安装配置文件
    if [[ -f "config/zpm.conf" ]]; then
        if [[ ! -f "$CONFIG_DIR/zpm.conf" ]]; then
            cp "config/zpm.conf" "$CONFIG_DIR/"
            echo "  安装: $CONFIG_DIR/zpm.conf"
        else
            echo "  保留: $CONFIG_DIR/zpm.conf (已存在)"
        fi
    fi
}

# 创建用户配置
create_user_config() {
    echo -e "${CYAN}创建用户配置...${NC}"

    local user_config_file="${USER_CONFIG}/config/zpm.conf"

    if [[ ! -f "$user_config_file" ]]; then
        mkdir -p "${USER_CONFIG}/config"
        cat > "$user_config_file" << EOF
# ZPM 用户配置文件
# 作者: Zeta <3380089537@qq.com>

[general]
noconfirm = no
verbose = no
debug = no

[aur]
check_updates = yes

[deb]
auto_map_deps = yes
install_method = convert
EOF
        echo "  创建: $user_config_file"
    fi
}

# 添加到 PATH
add_to_path() {
    if [[ "$PREFIX" == "${USER_HOME}/.local" ]]; then
        echo -e "${CYAN}检查 PATH...${NC}"

        local shell_rc=""
        case "$SHELL" in
            */bash)
                shell_rc="${USER_HOME}/.bashrc"
                ;;
            */zsh)
                shell_rc="${USER_HOME}/.zshrc"
                ;;
            */fish)
                shell_rc="${USER_HOME}/.config/fish/config.fish"
                ;;
            *)
                shell_rc="${USER_HOME}/.bashrc"
                ;;
        esac

        if [[ -n "$shell_rc" && -f "$shell_rc" ]]; then
            if ! grep -q "${BIN_DIR}" "$shell_rc" 2>/dev/null; then
                echo "" >> "$shell_rc"
                echo "# ZPM 路径" >> "$shell_rc"
                echo 'export PATH="${HOME}/.local/bin:${PATH}"' >> "$shell_rc"
                echo "  添加到 PATH: $shell_rc"
                echo -e "${YELLOW}请运行 'source $shell_rc' 或重新登录以应用更改${NC}"
            fi
        fi
    fi
}

# 显示帮助
show_help() {
    echo ""
    echo -e "${GREEN}安装完成!${NC}"
    echo ""
    echo "使用方法:"
    echo "  zpm --help          显示帮助"
    echo "  zpm install <包名>   安装包"
    echo "  zpm aur search <关键词>  搜索 AUR"
    echo "  zpm apt search <关键词>  搜索 APT 源"
    echo ""
    echo "更多信息请查看文档:"
    echo "  docs/README.md"
    echo ""
}

# 主函数
main() {
    # 检查是否在正确的目录
    if [[ ! -f "bin/zpm" ]]; then
        echo -e "${RED}错误: 请在 ZPM 源码目录中运行此脚本${NC}"
        exit 1
    fi

    # 检查 root
    check_root

    # 检查依赖
    check_dependencies

    # 创建目录
    create_directories

    # 安装文件
    install_files

    # 创建用户配置
    create_user_config

    # 添加到 PATH
    add_to_path

    # 显示帮助
    show_help
}

# 运行
main "$@"
