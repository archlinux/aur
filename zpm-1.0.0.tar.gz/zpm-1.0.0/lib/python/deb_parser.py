#!/usr/bin/env python3
#
# Debian 包解析工具
# 用于解析 control 文件和转换依赖
#

import sys
import json
import re
from typing import Dict, List, Optional


class DebControlParser:
    """解析 Debian control 文件"""

    @staticmethod
    def parse_file(filepath: str) -> Dict[str, str]:
        """解析 control 文件"""
        data = {}
        current_key = None
        current_value = []

        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.rstrip('\n')

                    # 空行表示结束
                    if not line.strip():
                        if current_key:
                            data[current_key] = '\n'.join(current_value)
                        break

                    # 继续前一行的值
                    if line.startswith(' ') or line.startswith('\t'):
                        if current_key:
                            current_value.append(line.strip())
                        continue

                    # 保存前一个键值对
                    if current_key:
                        data[current_key] = '\n'.join(current_value)

                    # 解析新键值对
                    if ':' in line:
                        key, value = line.split(':', 1)
                        current_key = key.strip()
                        current_value = [value.strip()]

            # 保存最后一个键值对
            if current_key:
                data[current_key] = '\n'.join(current_value)
        except Exception as e:
            print(f"Error parsing control file: {e}", file=sys.stderr)
            return {}

        return data


class DependencyConverter:
    """转换 Debian 依赖到 Arch 依赖"""

    # Debian 到 Arch 的包名映射
    PACKAGE_MAP = {
        # 基础系统
        'libc6': 'glibc',
        'libc6-dev': 'glibc',
        'libgcc1': 'gcc-libs',
        'libgcc-s1': 'gcc-libs',
        'libstdc++6': 'gcc-libs',
        'zlib1g': 'zlib',
        'zlib1g-dev': 'zlib',
        'libssl1.1': 'openssl',
        'libssl1.0.0': 'openssl',
        'libssl3': 'openssl',
        'libssl-dev': 'openssl',

        # Python
        'python3': 'python',
        'python3-minimal': 'python',
        'python3-dev': 'python',
        'python3-pip': 'python-pip',
        'python3-setuptools': 'python-setuptools',
        'python3-wheel': 'python-wheel',
        'python3-venv': 'python-virtualenv',
        'python3-virtualenv': 'python-virtualenv',
        'python3-six': 'python-six',
        'python3-requests': 'python-requests',
        'python3-urllib3': 'python-urllib3',
        'python3-chardet': 'python-chardet',
        'python3-certifi': 'python-certifi',
        'python3-idna': 'python-idna',
        'python3-pkg-resources': 'python-setuptools',
        'python3-numpy': 'python-numpy',
        'python3-pil': 'python-pillow',
        'python3-cairo': 'python-cairo',
        'python3-gi': 'python-gobject',
        'python3-dbus': 'python-dbus',
        'python3-psutil': 'python-psutil',
        'python3-yaml': 'python-yaml',
        'python3-lxml': 'python-lxml',
        'python3-cryptography': 'python-cryptography',
        'python3-openssl': 'python-pyopenssl',
        'python3-jwt': 'python-pyjwt',
        'python3-dateutil': 'python-dateutil',
        'python3-click': 'python-click',
        'python3-markupsafe': 'python-markupsafe',
        'python3-jinja2': 'python-jinja2',
        'python3-itsdangerous': 'python-itsdangerous',
        'python3-werkzeug': 'python-werkzeug',
        'python3-flask': 'python-flask',
        'python3-django': 'python-django',
        'python3-pandas': 'python-pandas',
        'python3-matplotlib': 'python-matplotlib',
        'python3-scipy': 'python-scipy',
        'python3-opengl': 'python-opengl',
        'python3-sip': 'python-sip',
        'python3-pyqt5': 'python-pyqt5',
        'python3-pyqt6': 'python-pyqt6',

        # 图形库
        'libgtk-3-0': 'gtk3',
        'libgtk-3-dev': 'gtk3',
        'libgtk-4-1': 'gtk4',
        'libgtk-4-dev': 'gtk4',
        'libqt5core5a': 'qt5-base',
        'libqt5gui5': 'qt5-base',
        'libqt5widgets5': 'qt5-base',
        'libqt5network5': 'qt5-base',
        'libqt5dbus5': 'qt5-base',
        'libqt5sql5': 'qt5-base',
        'libqt5xml5': 'qt5-base',
        'libqt5svg5': 'qt5-svg',
        'libqt5webkit5': 'qt5-webkit',
        'libqt5x11extras5': 'qt5-x11extras',
        'libqt5waylandclient5': 'qt5-wayland',
        'libqt6core6': 'qt6-base',
        'libqt6gui6': 'qt6-base',
        'libqt6widgets6': 'qt6-base',
        'libqt6network6': 'qt6-base',
        'libqt6dbus6': 'qt6-base',
        'libqt6svg6': 'qt6-svg',
        'qtbase5-dev': 'qt5-base',
        'qtbase5-dev-tools': 'qt5-base',
        'qt6-base-dev': 'qt6-base',
        'libgl1': 'mesa',
        'libgl1-mesa-glx': 'mesa',
        'libgl1-mesa-dri': 'mesa',
        'libglu1-mesa': 'glu',
        'libegl1': 'mesa',
        'libegl1-mesa': 'mesa',
        'libgles2': 'mesa',
        'libgles2-mesa': 'mesa',
        'libgbm1': 'mesa',
        'libdrm2': 'libdrm',
        'libglvnd0': 'libglvnd',
        'libopengl0': 'libglvnd',
        'libglew2.2': 'glew',
        'libglew2.1': 'glew',

        # X11
        'libx11-6': 'libx11',
        'libx11-dev': 'libx11',
        'libx11-xcb1': 'libx11',
        'libxext6': 'libxext',
        'libxext-dev': 'libxext',
        'libxrender1': 'libxrender',
        'libxrender-dev': 'libxrender',
        'libxtst6': 'libxtst',
        'libxi6': 'libxi',
        'libxfixes3': 'libxfixes',
        'libxrandr2': 'libxrandr',
        'libxinerama1': 'libxinerama',
        'libxcursor1': 'libxcursor',
        'libxcomposite1': 'libxcomposite',
        'libxdamage1': 'libxdamage',
        'libxkbcommon0': 'libxkbcommon',
        'libxkbcommon-x11-0': 'libxkbcommon-x11',
        'libxss1': 'libxss',
        'libxxf86vm1': 'libxxf86vm',
        'libxmu6': 'libxmu',
        'libxpm4': 'libxpm',
        'libxaw7': 'libxaw',
        'libxft2': 'libxft',
        'libfontenc1': 'libfontenc',
        'libice6': 'libice',
        'libsm6': 'libsm',
        'libxt6': 'libxt',
        'x11-common': 'xorg-common',
        'x11-xkb-utils': 'xorg-xkb-utils',
        'x11-utils': 'xorg-xprop',
        'x11-xserver-utils': 'xorg-xrandr',
        'xserver-common': 'xorg-server-common',

        # 字体
        'fontconfig-config': 'fontconfig',
        'libfontconfig1': 'fontconfig',
        'libfontconfig1-dev': 'fontconfig',
        'libfreetype6': 'freetype2',
        'libfreetype6-dev': 'freetype2',
        'fonts-dejavu-core': 'ttf-dejavu',
        'fonts-liberation': 'ttf-liberation',
        'fonts-noto-core': 'noto-fonts',
        'fonts-noto-cjk': 'noto-fonts-cjk',
        'fonts-noto-color-emoji': 'noto-fonts-emoji',

        # 图像
        'libpng16-16': 'libpng',
        'libpng-dev': 'libpng',
        'libjpeg8': 'libjpeg-turbo',
        'libjpeg62-turbo': 'libjpeg-turbo',
        'libjpeg-dev': 'libjpeg-turbo',
        'libtiff5': 'libtiff',
        'libtiff6': 'libtiff',
        'libtiff-dev': 'libtiff',
        'libwebp6': 'libwebp',
        'libwebp7': 'libwebp',
        'libwebpdemux2': 'libwebp',
        'libwebpmux3': 'libwebp',
        'libgif7': 'giflib',
        'libopenjp2-7': 'openjpeg2',
        'libraw20': 'libraw',
        'libheif1': 'libheif',
        'libavif13': 'libavif',
        'libjxl0.7': 'libjxl',

        # 压缩
        'libbz2-1.0': 'bzip2',
        'libbz2-dev': 'bzip2',
        'liblzma5': 'xz',
        'liblzma-dev': 'xz',
        'libzstd1': 'zstd',
        'libzstd-dev': 'zstd',
        'libarchive13': 'libarchive',
        'libarchive-dev': 'libarchive',

        # 网络
        'libcurl4': 'curl',
        'libcurl3-gnutls': 'curl',
        'libcurl4-openssl-dev': 'curl',
        'wget': 'wget',
        'ca-certificates': 'ca-certificates-utils',
        'libgnutls30': 'gnutls',
        'libgnutls28-dev': 'gnutls',
        'libnettle8': 'nettle',
        'libnettle-dev': 'nettle',
        'libhogweed6': 'nettle',
        'libidn2-0': 'libidn2',
        'libpsl5': 'libpsl',
        'libnghttp2-14': 'nghttp2',
        'librtmp1': 'rtmpdump',
        'libssh2-1': 'libssh2',
        'libldap-2.4-2': 'libldap',
        'libldap-2.5-0': 'libldap',
        'libkrb5-3': 'krb5',
        'libk5crypto3': 'krb5',
        'libcom-err2': 'e2fsprogs',
        'libkeyutils1': 'keyutils',
        'libsasl2-2': 'libsasl',
        'libgsasl7': 'gsasl',

        # 数据库
        'libsqlite3-0': 'sqlite',
        'libsqlite3-dev': 'sqlite',
        'libmysqlclient21': 'mariadb-libs',
        'libmysqlclient-dev': 'mariadb-libs',
        'libpq5': 'postgresql-libs',
        'libpq-dev': 'postgresql-libs',
        'libmongoc-1.0-0': 'mongo-c-driver',
        'libbson-1.0-0': 'mongo-c-driver',
        'libredis0': 'hiredis',

        # 其他常用库
        'libpcre3': 'pcre',
        'libpcre3-dev': 'pcre',
        'libpcre2-8-0': 'pcre2',
        'libpcre2-dev': 'pcre2',
        'libicu70': 'icu',
        'libicu72': 'icu',
        'libicu-dev': 'icu',
        'libxml2': 'libxml2',
        'libxml2-dev': 'libxml2',
        'libxslt1.1': 'libxslt',
        'libxslt1-dev': 'libxslt',
        'libffi8': 'libffi',
        'libffi7': 'libffi',
        'libffi-dev': 'libffi',
        'libexpat1': 'expat',
        'libexpat1-dev': 'expat',
        'libuuid1': 'util-linux-libs',
        'uuid-dev': 'util-linux-libs',
        'libblkid1': 'util-linux-libs',
        'libmount1': 'util-linux-libs',
        'libdevmapper1.02.1': 'device-mapper',
        'libjson-c5': 'json-c',
        'libjson-glib-1.0-0': 'json-glib',
        'libgpg-error0': 'libgpg-error',
        'libgcrypt20': 'libgcrypt',
        'libassuan0': 'libassuan',
        'libksba8': 'libksba',
        'libnpth0': 'npth',
        'libnpth0-dev': 'npth',
        'libsecret-1-0': 'libsecret',
        'libgirepository-1.0-1': 'gobject-introspection-runtime',
        'gir1.2-glib-2.0': 'gobject-introspection-runtime',
        'libapparmor1': 'apparmor',
        'libselinux1': 'libselinux',
        'libsepol2': 'libsepol',
        'libsemanage2': 'libsemanage',
        'libaudit1': 'audit',
        'libauparse0': 'audit',
        'libpam0g': 'pam',
        'libpam-runtime': 'pam',
        'libsystemd0': 'systemd-libs',
        'libudev1': 'systemd-libs',
        'libelogind0': 'elogind',
        'libeudev1': 'eudev',
        'libkmod2': 'kmod',
        'libcap2': 'libcap',
        'libcap-ng0': 'libcap-ng',
        'libip4tc2': 'iptables',
        'libip6tc2': 'iptables',
        'libxtables12': 'iptables',
        'libnftables1': 'nftables',
        'libmnl0': 'libmnl',
        'libnetfilter-conntrack3': 'libnetfilter_conntrack',
        'libnfnetlink0': 'libnfnetlink',
        'libnetfilter-queue1': 'libnetfilter_queue',
        'libnetfilter-acct1': 'libnetfilter_acct',
        'libnetfilter-log1': 'libnetfilter_log',
        'libnl-3-200': 'libnl',
        'libnl-route-3-200': 'libnl',
        'libpcap0.8': 'libpcap',
        'libdbus-1-3': 'dbus',
        'libdbus-glib-1-2': 'dbus-glib',
        'libpolkit-gobject-1-0': 'polkit',
        'libpolkit-agent-1-0': 'polkit',
        'libgudev-1.0-0': 'libgudev',
        'libwacom9': 'libwacom',
        'libevdev2': 'libevdev',
        'libinput10': 'libinput',
        'libmtdev1': 'mtdev',
        'libts0': 'tslib',
        'libfribidi0': 'fribidi',
        'libthai0': 'libthai',
        'libdatrie1': 'libdatrie',
        'libgraphite2-3': 'graphite',
        'libharfbuzz0b': 'harfbuzz',
        'libraqm0': 'libraqm',
        'libcolord2': 'colord',
        'liblcms2-2': 'lcms2',
        'libmng2': 'libmng',
        'libopenexr25': 'openexr',
        'libimath-3-1-29': 'imath',
        'libdeflate0': 'libdeflate',
        'libjbig0': 'jbigkit',

        # 音频/视频
        'libasound2': 'alsa-lib',
        'libasound2-dev': 'alsa-lib',
        'libpulse0': 'libpulse',
        'libpulse-dev': 'libpulse',
        'libvorbis0a': 'libvorbis',
        'libvorbis-dev': 'libvorbis',
        'libogg0': 'libogg',
        'libogg-dev': 'libogg',
        'libflac8': 'flac',
        'libflac-dev': 'flac',
        'libopus0': 'opus',
        'libopus-dev': 'opus',
        'libvpx7': 'libvpx',
        'libvpx8': 'libvpx',
        'libtheora0': 'libtheora',
        'libspeex1': 'speex',
        'libspeexdsp1': 'speexdsp',
        'libsamplerate0': 'libsamplerate',
        'libjack0': 'jack2',
        'libjack-jackd2-0': 'jack2',
        'libportaudio2': 'portaudio',
        'libsndfile1': 'libsndfile',
        'libmodplug1': 'libmodplug',
        'libmpg123-0': 'mpg123',
        'libmp3lame0': 'lame',
        'libfaad2': 'faad2',
        'libxvidcore4': 'xvidcore',
        'libx264-164': 'x264',
        'libx265-199': 'x265',
        'libaom3': 'aom',
        'libdav1d6': 'dav1d',
        'libsvtav1enc1': 'svt-av1',
        'librav1e0': 'rav1e',
        'libsnappy1v5': 'snappy',
        'libgstreamer1.0-0': 'gstreamer',
        'libgstreamer-plugins-base1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-plugins-good1.0-0': 'gst-plugins-good',
        'libgstreamer-plugins-bad1.0-0': 'gst-plugins-bad-libs',
        'libgstreamer-gl1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-video1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-audio1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-tag1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-pbutils1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-allocators1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-app1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-fft1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-mpegts1.0-0': 'gst-plugins-bad-libs',
        'libgstreamer-rtsp1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-sdp1.0-0': 'gst-plugins-base-libs',
        'libgstreamer-webrtc1.0-0': 'gst-plugins-bad-libs',
        'libnice10': 'libnice',
        'libsrtp2-1': 'libsrtp',
        'libwebrtc-audio-processing1': 'webrtc-audio-processing',
        'libspa-0.2-modules': 'pipewire',
        'libpipewire-0.3-0': 'pipewire',
        'libwireplumber-0.4-0': 'wireplumber',

        # 系统工具
        'lsb-release': 'lsb-release',
        'xdg-utils': 'xdg-utils',
        'hicolor-icon-theme': 'hicolor-icon-theme',
        'shared-mime-info': 'shared-mime-info',
        'desktop-file-utils': 'desktop-file-utils',
        'gtk-update-icon-cache': 'gtk-update-icon-cache',
        'update-mime-database': 'shared-mime-info',
        'update-desktop-database': 'desktop-file-utils',

        # 开发工具
        'build-essential': 'base-devel',
        'gcc': 'gcc',
        'g++': 'gcc',
        'make': 'make',
        'cmake': 'cmake',
        'ninja-build': 'ninja',
        'meson': 'meson',
        'pkg-config': 'pkgconf',
        'pkgconf': 'pkgconf',
        'autoconf': 'autoconf',
        'automake': 'automake',
        'libtool': 'libtool',
        'm4': 'm4',
        'bison': 'bison',
        'flex': 'flex',
        'gperf': 'gperf',
        'intltool': 'intltool',
        'gettext': 'gettext',
        'libgettextpo0': 'gettext',
        'po-debconf': 'gettext',
        'dh-autoreconf': 'autoconf',
        'debhelper': 'base-devel',

        # 其他常用工具
        'file': 'file',
        'findutils': 'findutils',
        'grep': 'grep',
        'sed': 'sed',
        'gawk': 'gawk',
        'coreutils': 'coreutils',
        'util-linux': 'util-linux',
        'binutils': 'binutils',
        'diffutils': 'diffutils',
        'patch': 'patch',
        'tar': 'tar',
        'gzip': 'gzip',
        'bzip2': 'bzip2',
        'xz-utils': 'xz',
        'unzip': 'unzip',
        'zip': 'zip',
        'p7zip-full': 'p7zip',
        'arj': 'arj',
        'lhasa': 'lha',
        'rpm': 'rpm-tools',
        'cpio': 'cpio',

        # 文本处理
        'libicu-dev': 'icu',
        'libxml2-utils': 'libxml2',
        'xsltproc': 'libxslt',
        'docbook-xml': 'docbook-xml',
        'docbook-xsl': 'docbook-xsl',
        'sgml-base': 'sgml-common',
        'xml-core': 'libxml2',

        # 图像处理工具
        'imagemagick': 'imagemagick',
        'libmagickcore-6.q16-6': 'imagemagick',
        'libmagickwand-6.q16-6': 'imagemagick',
        'ghostscript': 'ghostscript',
        'libgs9': 'ghostscript',
        'poppler-utils': 'poppler-glib',
        'libpoppler-glib8': 'poppler-glib',
        'libpoppler-cpp0v5': 'poppler-glib',
        'libcairo2': 'cairo',
        'libcairo-gobject2': 'cairo',
        'libcairo-script-interpreter2': 'cairo',
        'libpango-1.0-0': 'pango',
        'libpangocairo-1.0-0': 'pango',
        'libpangoft2-1.0-0': 'pango',
        'libpangoxft-1.0-0': 'pango',
        'librsvg2-2': 'librsvg',
        'librsvg2-common': 'librsvg',
        'libpixman-1-0': 'pixman',
        'libgdk-pixbuf-2.0-0': 'gdk-pixbuf2',
        'libgdk-pixbuf-xlib-2.0-0': 'gdk-pixbuf-xlib',
        'gir1.2-gdkpixbuf-2.0': 'gdk-pixbuf2',
        'libatk1.0-0': 'atk',
        'libatk-bridge2.0-0': 'at-spi2-core',
        'libatspi2.0-0': 'at-spi2-core',
        'gir1.2-atk-1.0': 'atk',
        'gir1.2-atspi-2.0': 'at-spi2-core',

        # 网络工具
        'openssl': 'openssl',
        'libssl3': 'openssl',
        'libssl-dev': 'openssl',
        'ca-certificates': 'ca-certificates-utils',
        'netbase': 'iana-etc',
        'net-tools': 'net-tools',
        'iproute2': 'iproute2',
        'iputils-ping': 'iputils',
        'traceroute': 'traceroute',
        'dnsutils': 'bind-tools',
        'whois': 'whois',
        'curl': 'curl',
        'wget': 'wget',
        'rsync': 'rsync',
        'openssh-client': 'openssh',
        'openssh-server': 'openssh',
        'ssh': 'openssh',

        # 压缩工具
        'zlib1g': 'zlib',
        'zlib1g-dev': 'zlib',
        'libzstd1': 'zstd',
        'libzstd-dev': 'zstd',
        'liblz4-1': 'lz4',
        'liblz4-dev': 'lz4',
        'liblzo2-2': 'lzo',
        'liblzo2-dev': 'lzo',

        # 数学库
        'libgmp10': 'gmp',
        'libgmp-dev': 'gmp',
        'libmpfr6': 'mpfr',
        'libmpfr-dev': 'mpfr',
        'libmpc3': 'mpc',
        'libmpc-dev': 'mpc',

        # 线程和并行
        'libgomp1': 'gcc-libs',
        'libomp5-14': 'openmp',
        'libtbb2': 'tbb',
        'libtbb-dev': 'tbb',

        # 虚拟化和容器
        'libvirt0': 'libvirt',
        'libvirt-dev': 'libvirt',
        'lxc': 'lxc',
        'lxc-dev': 'lxc',

        # 硬件相关
        'libusb-1.0-0': 'libusb',
        'libusb-1.0-0-dev': 'libusb',
        'libusb-0.1-4': 'libusb-compat',
        'libpci3': 'pciutils',
        'libpciaccess0': 'libpciaccess',
        'libdrm2': 'libdrm',
        'libdrm-intel1': 'libdrm',
        'libdrm-radeon1': 'libdrm',
        'libdrm-nouveau2': 'libdrm',
        'libdrm-amdgpu1': 'libdrm',
        'libvulkan1': 'vulkan-icd-loader',
        'mesa-vulkan-drivers': 'vulkan-intel',
        'libglx-mesa0': 'mesa',
        'libgl1-mesa-dri': 'mesa',
        'libwayland-client0': 'wayland',
        'libwayland-server0': 'wayland',
        'libwayland-cursor0': 'wayland',
        'libwayland-egl1': 'wayland',
        'libwayland-bin': 'wayland',
        'wayland-protocols': 'wayland-protocols',
        'libxkbcommon0': 'libxkbcommon',
        'libxkbcommon-x11-0': 'libxkbcommon-x11',

        # 安全相关
        'libapparmor1': 'apparmor',
        'libapparmor-dev': 'apparmor',
        'libselinux1': 'libselinux',
        'libselinux1-dev': 'libselinux',
        'libsepol2': 'libsepol',
        'libsemanage2': 'libsemanage',
        'libsemanage-common': 'libsemanage',
        'libaudit1': 'audit',
        'libaudit-dev': 'audit',
        'libauparse0': 'audit',
        'libauparse-dev': 'audit',
        'libpam0g': 'pam',
        'libpam0g-dev': 'pam',
        'libcap2': 'libcap',
        'libcap2-bin': 'libcap',
        'libcap-dev': 'libcap',
        'libcap-ng0': 'libcap-ng',
        'libcap-ng-dev': 'libcap-ng',

        # 国际化
        'locales': 'glibc',
        'locales-all': 'glibc',
        'language-pack-en': 'glibc',
        'language-pack-zh-hans': 'glibc',
        'language-pack-zh-hant': 'glibc',
        'fonts-arphic-uming': 'ttf-arphic-uming',
        'fonts-arphic-ukai': 'ttf-arphic-ukai',
        'fonts-wqy-zenhei': 'ttf-wqy-zenhei',
        'fonts-wqy-microhei': 'ttf-wqy-microhei',

        # 文档
        'man-db': 'man-db',
        'manpages': 'man-pages',
        'manpages-dev': 'man-pages',
        'info': 'texinfo',
        'install-info': 'texinfo',
        'texinfo': 'texinfo',

        # 日志
        'rsyslog': 'rsyslog',
        'liblogging-stdlog0': 'liblogging',
        'liblognorm5': 'liblognorm',
        'libestr0': 'libestr',

        # 时间和时区
        'tzdata': 'tzdata',
        'libdatetime-perl': 'perl-datetime',
        'libdatetime-timezone-perl': 'perl-datetime-timezone',
        'libdatetime-locale-perl': 'perl-datetime-locale',

        # 其他
        'ucf': 'base-devel',
        'debconf': 'base-devel',
        'debconf-2.0': 'base-devel',
        'dpkg': 'dpkg',
        'libdpkg-perl': 'dpkg',
        'apt': 'pacman',
        'apt-utils': 'pacman-contrib',
        'apt-transport-https': 'pacman',
        'libapt-pkg6.0': 'libapt-pkg',
        'libapt-inst2.0': 'libapt-pkg',
    }

    @classmethod
    def convert_package_name(cls, deb_name: str) -> Optional[str]:
        """转换包名"""
        if not deb_name:
            return None

        # 移除版本限制
        clean_name = re.split(r'[\(\[=<>]', deb_name)[0].strip()

        if not clean_name:
            return None

        # 查找映射
        if clean_name in cls.PACKAGE_MAP:
            return cls.PACKAGE_MAP[clean_name]

        # 尝试一些通用规则
        # libxxx -> 移除 lib 前缀
        if clean_name.startswith('lib') and len(clean_name) > 3:
            return clean_name[3:]

        return clean_name

    @classmethod
    def convert_dependencies(cls, deb_deps: str) -> List[str]:
        """转换依赖字符串"""
        if not deb_deps:
            return []

        arch_deps = []
        seen = set()

        # 分割依赖
        for dep in deb_deps.split(','):
            dep = dep.strip()
            if not dep:
                continue

            # 转换包名
            arch_dep = cls.convert_package_name(dep)
            if arch_dep and arch_dep not in seen:
                arch_deps.append(f'"{arch_dep}"')
                seen.add(arch_dep)

        return arch_deps


def parse_control_command(filepath: str) -> str:
    """解析 control 文件命令"""
    try:
        parser = DebControlParser()
        data = parser.parse_file(filepath)
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


def convert_deps_command(deps: str) -> str:
    """转换依赖命令"""
    try:
        converter = DependencyConverter()
        result = converter.convert_dependencies(deps)
        return ' '.join(result)
    except Exception as e:
        # 返回空字符串而不是错误信息
        return ''


def main():
    if len(sys.argv) < 2:
        print("用法: deb_parser.py <command> [args...]", file=sys.stderr)
        print("命令:", file=sys.stderr)
        print("  parse-control <file>     解析 control 文件", file=sys.stderr)
        print("  convert-deps <deps>      转换依赖", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]

    if command == 'parse-control':
        if len(sys.argv) < 3:
            print("错误: 需要指定 control 文件路径", file=sys.stderr)
            sys.exit(1)
        print(parse_control_command(sys.argv[2]))

    elif command == 'convert-deps':
        if len(sys.argv) < 3:
            # 如果没有提供依赖参数，返回空字符串
            print('')
        else:
            print(convert_deps_command(sys.argv[2]))

    else:
        print(f"错误: 未知命令 {command}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
