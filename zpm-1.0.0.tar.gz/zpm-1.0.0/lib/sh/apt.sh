#!/bin/bash
#
# APT 源管理模块
# 从 APT 源下载 deb 包并转换为 Arch 软件包
#

APT_CACHE_DIR="${ZPM_CACHE}/apt"
APT_SOURCES_LIST="/etc/apt/sources.list.d/zpm.sources"
APT_CONFIG="${ZPM_CONFIG}/apt.conf"

# 默认 APT 源
DEFAULT_APT_SOURCES=(
    "deb http://deb.debian.org/debian stable main contrib non-free"
    "deb http://deb.debian.org/debian stable-updates main contrib non-free"
    "deb http://security.debian.org/debian-security stable-security main contrib non-free"
    "deb http://archive.ubuntu.com/ubuntu jammy main restricted universe multiverse"
    "deb http://archive.ubuntu.com/ubuntu jammy-updates main restricted universe multiverse"
)

# 初始化 APT 配置
apt_init() {
    [[ -d "$APT_CACHE_DIR" ]] || mkdir -p "$APT_CACHE_DIR"
    [[ -d "${ZPM_CONFIG}" ]] || mkdir -p "${ZPM_CONFIG}"

    # 创建默认配置
    if [[ ! -f "$APT_CONFIG" ]]; then
        cat > "$APT_CONFIG" << 'EOF'
# ZPM APT 配置
# 格式: [源名称] [源URL] [发行版] [组件]

debian-stable http://deb.debian.org/debian stable main contrib non-free
debian-security http://security.debian.org/debian-security stable-security main contrib non-free
ubuntu-jammy http://archive.ubuntu.com/ubuntu jammy main restricted universe multiverse
EOF
    fi
}

# 解析 APT 源配置
apt_parse_sources() {
    local sources=()
    while IFS= read -r line; do
        # 跳过注释和空行
        [[ "$line" =~ ^#.*$ ]] && continue
        [[ -z "$line" ]] && continue

        # 解析 deb 行
        if [[ "$line" =~ ^deb[[:space:]]+([^[:space:]]+)[[:space:]]+([^[:space:]]+)[[:space:]]+(.+)$ ]]; then
            local url="${BASH_REMATCH[1]}"
            local distro="${BASH_REMATCH[2]}"
            local components="${BASH_REMATCH[3]}"
            sources+=("$url|$distro|$components")
        fi
    done < "$APT_CONFIG"

    echo "${sources[@]}"
}

# 获取包列表
apt_fetch_packages() {
    local source_url="$1"
    local distro="$2"
    local component="$3"

    log_debug "获取包列表: $source_url $distro $component"

    local packages_url="${source_url}/dists/${distro}/${component}/binary-amd64/Packages.gz"
    local packages_file="${APT_CACHE_DIR}/Packages_${distro}_${component}.gz"

    # 下载 Packages.gz
    if [[ ! -f "$packages_file" ]] || [[ "$(find "$packages_file" -mtime +1)" ]]; then
        log_info "更新包列表: $distro/$component"
        curl -sL "$packages_url" -o "$packages_file" 2>/dev/null || {
            log_warn "无法下载包列表: $packages_url"
            return 1
        }
    fi

    # 解压并解析
    zcat "$packages_file" 2>/dev/null
}

# 简化搜索 - 仅返回包名和版本（用于 install 时的源选择）
apt_search_simple() {
    local query="$1"
    local sources
    sources=$(apt_parse_sources)

    local results=()
    local found=()
    local IFS=' '

    for source in $sources; do
        local url distro components
        url="${source%%|*}"
        distro="${source#*|}"
        distro="${distro%%|*}"
        components="${source##*|}"

        for component in $components; do
            local packages
            packages=$(apt_fetch_packages "$url" "$distro" "$component" 2>/dev/null)

            if [[ -n "$packages" ]]; then
                # 精确匹配
                local exact_match
                exact_match=$(echo "$packages" | awk -v pkg="$query" '
                    /^Package: / { p = $2 }
                    /^Version: / { v = $2 }
                    /^$/ {
                        if (p == pkg && !(p in seen)) {
                            print p "|" v
                            seen[p] = 1
                        }
                        p = ""; v = ""
                    }
                ')
                if [[ -n "$exact_match" ]]; then
                    found+=("$exact_match")
                fi

                # 部分匹配（限制数量）
                local partial_matches
                partial_matches=$(echo "$packages" | awk -v q="$query" '
                    /^Package: / { p = $2 }
                    /^Version: / { v = $2 }
                    /^$/ {
                        if (p ~ q && p != q && !(p in seen)) {
                            print p "|" v
                            seen[p] = 1
                        }
                        p = ""; v = ""
                    }
                ' | head -3)
                while IFS= read -r line; do
                    [[ -n "$line" ]] && found+=("$line")
                done <<< "$partial_matches"
            fi
        done
    done

    # 去重并输出
    local unique=()
    for item in "${found[@]}"; do
        local pkg_name="${item%%|*}"
        local is_dup=false
        for u in "${unique[@]}"; do
            if [[ "${u%%|*}" == "$pkg_name" ]]; then
                is_dup=true
                break
            fi
        done
        if [[ "$is_dup" == false ]]; then
            unique+=("$item")
            echo "$item"
        fi
    done
}

# 从 APT 源搜索包
apt_search() {
    local query="$1"
    local sources
    sources=$(apt_parse_sources)

    log_info "在 APT 源中搜索: $query"

    local results=()
    local IFS=' '

    for source in $sources; do
        local url distro components
        url="${source%%|*}"
        distro="${source#*|}"
        distro="${distro%%|*}"
        components="${source##*|}"

        for component in $components; do
            log_debug "搜索: $url $distro $component"

            local packages
            packages=$(apt_fetch_packages "$url" "$distro" "$component")

            if [[ -n "$packages" ]]; then
                # 解析包信息
                local matches
                matches=$(echo "$packages" | awk -v query="$query" '
                    /^Package: / { pkg = $2 }
                    /^Version: / { ver = $2 }
                    /^Description: / { desc = substr($0, 14) }
                    /^$/ {
                        if (pkg ~ query || desc ~ query) {
                            printf "%s|%s|%s|%s|%s\n", url, distro, component, pkg, ver, desc
                        }
                        pkg = ""; ver = ""; desc = ""
                    }
                ' url="$url" distro="$distro" component="$component")

                if [[ -n "$matches" ]]; then
                    results+=("$matches")
                fi
            fi
        done
    done

    if [[ ${#results[@]} -eq 0 ]]; then
        log_warn "未找到匹配的包"
        return 0
    fi

    echo -e "\n${BOLD}APT 搜索结果:${NC}\n"
    echo -e "${CYAN}$(printf '%-4s %-30s %-20s %-15s' '序号' '包名' '版本' '源')${NC}"
    echo "$(printf '%-4s %-30s %-20s %-15s' '----' '------------------------------' '--------------------' '---------------')"

    local count=0
    for result in "${results[@]}"; do
        while IFS='|' read -r url distro component pkg ver desc; do
            ((count++))
            printf '%-4d %-30s %-20s %-15s\n' "$count" "$pkg" "$ver" "$distro"
        done <<< "$result"
    done

    echo ""
    log_info "找到 $count 个结果"
}

# 获取包下载 URL
apt_get_download_url() {
    local pkgname="$1"
    local sources
    sources=$(apt_parse_sources)

    local IFS=' '
    for source in $sources; do
        local url distro components
        url="${source%%|*}"
        distro="${source#*|}"
        distro="${distro%%|*}"
        components="${source##*|}"

        for component in $components; do
            local packages
            packages=$(apt_fetch_packages "$url" "$distro" "$component")

            if [[ -n "$packages" ]]; then
                local match
                match=$(echo "$packages" | awk -v pkg="$pkgname" '
                    /^Package: / { p = $2 }
                    /^Filename: / { f = $2 }
                    /^$/ {
                        if (p == pkg && f != "") {
                            print f
                            exit
                        }
                        p = ""; f = ""
                    }
                ')

                if [[ -n "$match" ]]; then
                    echo "${url}/${match}"
                    return 0
                fi
            fi
        done
    done

    return 1
}

# 从 APT 源下载 deb 包
apt_download() {
    local pkgname="$1"

    log_info "从 APT 源下载: $pkgname"

    local download_url
    download_url=$(apt_get_download_url "$pkgname")

    if [[ -z "$download_url" ]]; then
        log_error "无法在 APT 源中找到包: $pkgname"
        return 1
    fi

    log_info "下载地址: $download_url"

    local deb_file="${APT_CACHE_DIR}/$(basename "$download_url")"

    # 下载包
    curl -L --progress-bar "$download_url" -o "$deb_file" || {
        log_error "下载失败"
        return 1
    }

    log_info "已下载: $deb_file"
    echo "$deb_file"
}

# 从 APT 源安装包到 Arch
apt_install() {
    local pkgname="$1"

    log_info "准备从 APT 源安装: $pkgname"

    # 检查是否已安装
    if pacman -Q "$pkgname" &>/dev/null; then
        log_info "包 '$pkgname' 已安装"
        if [[ "$ZPM_NEEDED" == true ]]; then
            return 0
        fi
    fi

    # 下载 deb 包
    local deb_file
    deb_file=$(apt_download "$pkgname")

    if [[ -z "$deb_file" ]]; then
        return 1
    fi

    # 转换为 Arch 包并安装
    source "${ZPM_LIB}/sh/deb.sh"
    convert_and_install_deb "$deb_file"
}

# 更新 APT 源列表
apt_update() {
    log_info "更新 APT 源列表..."

    apt_init

    local sources
    sources=$(apt_parse_sources)
    local IFS=' '

    for source in $sources; do
        local url distro components
        url="${source%%|*}"
        distro="${source#*|}"
        distro="${distro%%|*}"
        components="${source##*|}"

        for component in $components; do
            log_info "更新: $distro/$component"
            apt_fetch_packages "$url" "$distro" "$component" > /dev/null
        done
    done

    log_info "APT 源列表更新完成"
}

# 添加 APT 源
apt_add_source() {
    local name="$1"
    local url="$2"
    local distro="$3"
    shift 3
    local components="$*"

    log_info "添加 APT 源: $name"

    echo "${name} ${url} ${distro} ${components}" >> "$APT_CONFIG"

    log_info "已添加源: $name"
}

# 列出 APT 源
apt_list_sources() {
    log_info "已配置的 APT 源:"

    if [[ ! -f "$APT_CONFIG" ]]; then
        log_warn "没有配置 APT 源"
        return 0
    fi

    echo ""
    cat "$APT_CONFIG" | grep -v '^#' | grep -v '^$'
    echo ""
}

# 处理 APT 命令
handle_apt_command() {
    apt_init

    local subcommand="${1:-help}"
    shift || true

    case "$subcommand" in
        search|s)
            apt_search "$1"
            ;;
        install|in)
            apt_install "$1"
            ;;
        download|dl)
            apt_download "$1"
            ;;
        update|up)
            apt_update
            ;;
        add)
            apt_add_source "$1" "$2" "$3" "${@:4}"
            ;;
        list|l)
            apt_list_sources
            ;;
        help|h|--help)
            cat << 'EOF'
APT 命令用法:
    zpm apt search [关键词]     从 APT 源搜索包
    zpm apt install [包名]      从 APT 源下载并安装包到 Arch
    zpm apt download [包名]     从 APT 源下载 deb 包
    zpm apt update              更新 APT 源列表
    zpm apt add [名称] [URL] [发行版] [组件...]  添加 APT 源
    zpm apt list                列出已配置的 APT 源

说明:
    从 APT 源安装的包会自动转换为 Arch 格式 (pkg.tar.zst)
    转换后的包保留原始依赖信息，但会尝试映射到 Arch 的等效包
EOF
            ;;
        *)
            log_error "未知的 APT 命令: $subcommand"
            handle_apt_command help
            return 1
            ;;
    esac
}
