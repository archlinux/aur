#!/bin/bash
#
# 本地构建模块
# 支持 PKGBUILD 本地源码构建
#

BUILD_DIR="${ZPM_BUILD}/local"

# 初始化构建目录
init_build_dirs() {
    [[ -d "$BUILD_DIR" ]] || mkdir -p "$BUILD_DIR"
}

# 验证 PKGBUILD
validate_pkgbuild() {
    local pkgbuild_dir="$1"
    local pkgbuild_file="${pkgbuild_dir}/PKGBUILD"

    if [[ ! -f "$pkgbuild_file" ]]; then
        log_error "未找到 PKGBUILD 文件: $pkgbuild_file"
        return 1
    fi

    log_debug "验证 PKGBUILD"

    # 检查必需的变量
    local required_vars=("pkgname" "pkgver" "pkgrel" "arch")
    for var in "${required_vars[@]}"; do
        if ! grep -q "^${var}=" "$pkgbuild_file"; then
            log_warn "PKGBUILD 缺少变量: $var"
        fi
    done

    # 检查 package 函数或 build 函数
    if ! grep -q "^package()" "$pkgbuild_file" && ! grep -q "^build()" "$pkgbuild_file"; then
        log_warn "PKGBUILD 缺少 package() 或 build() 函数"
    fi

    return 0
}

# 解析 PKGBUILD
parse_pkgbuild() {
    local pkgbuild_file="$1"

    log_debug "解析 PKGBUILD: $pkgbuild_file"

    # 使用 bash 解析
    (
        source "$pkgbuild_file" 2>/dev/null
        echo "pkgname=${pkgname}"
        echo "pkgver=${pkgver}"
        echo "pkgrel=${pkgrel}"
        echo "pkgdesc=${pkgdesc}"
        echo "arch=${arch[*]}"
        echo "url=${url}"
        echo "license=${license[*]}"
        echo "depends=${depends[*]}"
        echo "makedepends=${makedepends[*]}"
        echo "optdepends=${optdepends[*]}"
        echo "provides=${provides[*]}"
        echo "conflicts=${conflicts[*]}"
        echo "source=${source[*]}"
    )
}

# 显示 PKGBUILD 信息
show_pkgbuild_info() {
    local pkgbuild_file="$1"

    if [[ ! -f "$pkgbuild_file" ]]; then
        log_error "文件不存在: $pkgbuild_file"
        return 1
    fi

    log_info "PKGBUILD 信息:"

    local info
    info=$(parse_pkgbuild "$pkgbuild_file")

    echo -e "\n${BOLD}包信息:${NC}\n"

    while IFS='=' read -r key value; do
        case "$key" in
            pkgname) echo -e "${GREEN}包名:${NC}        $value" ;;
            pkgver) echo -e "${GREEN}版本:${NC}        $value" ;;
            pkgrel) echo -e "${GREEN}发布号:${NC}      $value" ;;
            pkgdesc) echo -e "${GREEN}描述:${NC}        $value" ;;
            arch) echo -e "${GREEN}架构:${NC}        $value" ;;
            url) echo -e "${GREEN}URL:${NC}         $value" ;;
            license) echo -e "${GREEN}许可证:${NC}      $value" ;;
            depends) echo -e "${GREEN}依赖:${NC}        $value" ;;
            makedepends) echo -e "${GREEN}构建依赖:${NC}    $value" ;;
            optdepends) echo -e "${GREEN}可选依赖:${NC}    $value" ;;
            provides) echo -e "${GREEN}提供:${NC}        $value" ;;
            conflicts) echo -e "${GREEN}冲突:${NC}        $value" ;;
        esac
    done <<< "$info"

    echo ""
}

# 安装构建依赖
install_build_deps() {
    local pkgbuild_file="$1"

    log_info "检查构建依赖..."

    local makedeps
    makedeps=$(source "$pkgbuild_file" 2>/dev/null && echo "${makedepends[@]}")

    if [[ -z "$makedeps" ]]; then
        log_info "没有构建依赖"
        return 0
    fi

    log_info "构建依赖: $makedeps"

    local deps_to_install=()
    for dep in $makedeps; do
        # 移除版本限制
        dep=$(echo "$dep" | sed 's/[>=<].*$//')

        if ! pacman -Q "$dep" &>/dev/null; then
            deps_to_install+=("$dep")
        fi
    done

    if [[ ${#deps_to_install[@]} -gt 0 ]]; then
        log_info "安装构建依赖: ${deps_to_install[*]}"

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否安装这些依赖? [Y/n] " confirm
            [[ "$confirm" =~ ^[Nn]$ ]] && return 1
        fi

        sudo pacman -S --noconfirm "${deps_to_install[@]}" || {
            log_error "安装构建依赖失败"
            return 1
        }
    else
        log_info "所有构建依赖已满足"
    fi
}

# 下载源码
download_sources() {
    local pkgbuild_dir="$1"

    log_info "下载源码..."

    # 使用子 shell 避免改变工作目录
    (
        cd "$pkgbuild_dir" || exit 1

        # 使用 makepkg 下载源码
        makepkg --nobuild --noextract --noconfirm 2>&1 | tee -a "${ZPM_LOGS}/download.log" || {
            log_error "下载源码失败"
            exit 1
        }

        log_info "源码下载完成"
    )
}

# 构建包
build_package() {
    local target="$1"

    init_build_dirs

    local pkgbuild_dir
    local pkgbuild_file

    # 判断是目录还是文件
    if [[ -d "$target" ]]; then
        pkgbuild_dir="$target"
        pkgbuild_file="${target}/PKGBUILD"
    elif [[ -f "$target" && "$(basename "$target")" == "PKGBUILD" ]]; then
        pkgbuild_dir="$(dirname "$target")"
        pkgbuild_file="$target"
    else
        log_error "无效的 PKGBUILD 路径: $target"
        return 1
    fi

    # 验证 PKGBUILD
    validate_pkgbuild "$pkgbuild_dir" || return 1

    # 显示信息
    show_pkgbuild_info "$pkgbuild_file"

    # 确认构建
    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        read -rp "是否开始构建? [Y/n] " confirm
        [[ "$confirm" =~ ^[Nn]$ ]] && return 1
    fi

    # 安装构建依赖
    install_build_deps "$pkgbuild_file" || return 1

    # 创建构建目录
    local build_id="$(basename "$pkgbuild_dir")_$(date +%s)"
    local build_work_dir="${BUILD_DIR}/${build_id}"

    # 复制 PKGBUILD 到构建目录
    [[ -d "$build_work_dir" ]] && rm -rf "$build_work_dir"
    mkdir -p "$build_work_dir"
    cp -r "${pkgbuild_dir}"/* "$build_work_dir/"

    log_info "构建目录: $build_work_dir"

    # 下载源码
    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        read -rp "是否下载/准备源码? [Y/n] " confirm
        if [[ ! "$confirm" =~ ^[Nn]$ ]]; then
            download_sources "$build_work_dir"
        fi
    fi

    # 开始构建
    log_info "开始构建..."

    local makepkg_opts="-sf"
    [[ "$ZPM_NOCONFIRM" == true ]] && makepkg_opts="${makepkg_opts} --noconfirm"
    [[ "$ZPM_VERBOSE" == true ]] && makepkg_opts="${makepkg_opts} --verbose"

    # 使用子 shell 避免改变工作目录
    (
        cd "$build_work_dir" || exit 1

        makepkg $makepkg_opts 2>&1 | tee "${ZPM_LOGS}/build-${build_id}.log" || {
            log_error "构建失败，查看日志: ${ZPM_LOGS}/build-${build_id}.log"
            exit 1
        }

        # 查找构建好的包
        local pkg_files
        pkg_files=$(ls -t ./*.pkg.tar.zst 2>/dev/null)

        if [[ -z "$pkg_files" ]]; then
            log_error "未找到构建好的包文件"
            exit 1
        fi

        echo ""
        log_info "构建完成!"
        echo -e "${GREEN}生成的包:${NC}"
        for pkg in $pkg_files; do
            echo "  - $pkg"
            ls -lh "$pkg" | awk '{print "    大小:", $5, "修改时间:", $6, $7, $8}'
        done

        # 询问是否安装
        local first_pkg
        first_pkg=$(echo "$pkg_files" | head -1)

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否安装构建好的包? [Y/n] " install_confirm
            if [[ ! "$install_confirm" =~ ^[Nn]$ ]]; then
                sudo pacman -U --noconfirm "$first_pkg" || {
                    log_error "安装失败"
                    exit 1
                }
                log_info "安装完成"
            fi
        fi

        echo "$first_pkg"
    )
}

# 清理构建目录
clean_build_dirs() {
    log_info "清理构建目录..."

    if [[ -d "$BUILD_DIR" ]]; then
        local count
        count=$(find "$BUILD_DIR" -maxdepth 1 -type d | wc -l)
        rm -rf "${BUILD_DIR:?}"/*
        log_info "已清理 $count 个构建目录"
    fi
}

# 处理构建命令
handle_build_command() {
    local subcommand="${1:-build}"
    shift || true

    case "$subcommand" in
        build|b)
            build_package "$1"
            ;;
        info|i)
            show_pkgbuild_info "$1"
            ;;
        clean|c)
            clean_build_dirs
            ;;
        help|h|--help)
            cat << 'EOF'
构建命令用法:
    zpm build [PKGBUILD路径]    构建本地 PKGBUILD
    zpm build info [路径]       显示 PKGBUILD 信息
    zpm build clean             清理构建目录

说明:
    支持从目录或 PKGBUILD 文件构建
    自动安装构建依赖
    构建完成后可选择安装
EOF
            ;;
        *)
            if [[ -e "$subcommand" ]]; then
                build_package "$subcommand"
            else
                log_error "未知的构建命令: $subcommand"
                handle_build_command help
                return 1
            fi
            ;;
    esac
}
