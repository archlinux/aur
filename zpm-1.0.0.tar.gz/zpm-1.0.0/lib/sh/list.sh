#!/bin/bash
#
# 包列表模块
# 列出已安装的包
#

# 列出已安装的包
list_packages() {
    local filter="${1:-}"

    log_info "已安装的包:"

    if [[ -n "$filter" ]]; then
        pacman -Q | grep -i "$filter"
    else
        # 分类显示
        echo -e "\n${BOLD}官方仓库包:${NC}\n"
        pacman -Qn 2>/dev/null | head -20
        local native_count
        native_count=$(pacman -Qn 2>/dev/null | wc -l)
        echo "... 共 $native_count 个"

        echo -e "\n${BOLD}AUR 包:${NC}\n"
        pacman -Qm 2>/dev/null || echo "无"

        echo -e "\n${BOLD}统计:${NC}"
        echo "  总包数: $(pacman -Q 2>/dev/null | wc -l)"
        echo "  官方仓库: $native_count"
        echo "  AUR: $(pacman -Qm 2>/dev/null | wc -l)"
    fi
}
