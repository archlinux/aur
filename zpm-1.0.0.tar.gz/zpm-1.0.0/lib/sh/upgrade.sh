#!/bin/bash
#
# 包升级模块
# 处理系统升级和包更新
#

# 升级所有包
upgrade_packages() {
    log_info "检查系统更新..."

    # 同步数据库
    sudo pacman -Sy || {
        log_error "同步数据库失败"
        return 1
    }

    # 检查更新
    local updates
    updates=$(pacman -Qu 2>/dev/null)

    if [[ -z "$updates" ]]; then
        log_info "系统已是最新"
    else
        local count
        count=$(echo "$updates" | wc -l)
        log_info "发现 $count 个可更新包"

        echo -e "\n${CYAN}$(printf '%-30s %-20s -> %-20s' '包名' '当前版本' '新版本')${NC}"
        echo "$(printf '%-30s %-20s -> %-20s' '------------------------------' '--------------------' '--------------------')"

        echo "$updates" | while read -r line; do
            local pkg cur_ver new_ver
            pkg=$(echo "$line" | awk '{print $1}')
            cur_ver=$(echo "$line" | awk '{print $2}')
            new_ver=$(echo "$line" | awk '{print $4}')
            printf '%-30s %-20s -> %-20s\n' "$pkg" "$cur_ver" "$new_ver"
        done

        echo ""

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否升级? [Y/n] " confirm
            [[ "$confirm" =~ ^[Nn]$ ]] && return 0
        fi

        # 执行升级
        sudo pacman -Su --noconfirm || {
            log_error "升级失败"
            return 1
        }

        log_info "系统升级完成"
    fi

    # 检查 AUR 更新
    log_info "检查 AUR 更新..."
    source "${ZPM_LIB}/sh/aur.sh"
    aur_update
}

# 升级特定包
upgrade_package() {
    local pkgname="$1"

    log_info "升级: $pkgname"

    if ! pacman -Q "$pkgname" &>/dev/null; then
        log_error "包 '$pkgname' 未安装"
        return 1
    fi

    # 检查是否在官方仓库
    if pacman -Si "$pkgname" &>/dev/null; then
        sudo pacman -S --noconfirm "$pkgname"
        return $?
    fi

    # 否则从 AUR 更新
    source "${ZPM_LIB}/sh/aur.sh"
    aur_install "$pkgname"
}
