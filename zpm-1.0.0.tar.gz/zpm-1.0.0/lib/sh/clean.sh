#!/bin/bash
#
# 清理模块
# 清理缓存和临时文件
#

# 清理缓存
clean_cache() {
    log_info "清理缓存..."

    local total_size=0

    # 清理 ZPM 缓存
    if [[ -d "$ZPM_CACHE" ]]; then
        local cache_size
        cache_size=$(du -sb "$ZPM_CACHE" 2>/dev/null | awk '{print $1}')
        total_size=$((total_size + cache_size))
        rm -rf "${ZPM_CACHE:?}"/*
        log_info "已清理 ZPM 缓存"
    fi

    # 清理构建目录
    if [[ -d "$ZPM_BUILD" ]]; then
        local build_size
        build_size=$(du -sb "$ZPM_BUILD" 2>/dev/null | awk '{print $1}')
        total_size=$((total_size + build_size))
        rm -rf "${ZPM_BUILD:?}"/*
        log_info "已清理构建目录"
    fi

    # 清理旧日志
    if [[ -d "$ZPM_LOGS" ]]; then
        find "$ZPM_LOGS" -name "*.log" -mtime +30 -delete 2>/dev/null
        log_info "已清理旧日志"
    fi

    # 清理 pacman 缓存
    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        read -rp "是否清理 pacman 缓存? [y/N] " confirm
        if [[ "$confirm" =~ ^[Yy]$ ]]; then
            sudo pacman -Sc --noconfirm
        fi
    fi

    local human_size
    human_size=$(numfmt --to=iec-i --suffix=B "$total_size" 2>/dev/null || echo "${total_size} bytes")
    log_info "清理完成，释放空间: $human_size"
}
