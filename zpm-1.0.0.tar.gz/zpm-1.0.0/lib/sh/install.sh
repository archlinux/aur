#!/bin/bash
#
# 包安装模块
# 处理包的安装逻辑，支持多源选择和优先级
#

# 搜索包在所有源中
search_package_all_sources() {
    local query="$1"
    local -a results=()

    log_debug "在所有源中搜索: $query" >&2

    # 1. 检查官方仓库
    if pacman -Si "$query" &>/dev/null; then
        local version
        version=$(pacman -Si "$query" 2>/dev/null | grep '^Version' | awk '{print $3}')
        local repo
        repo=$(pacman -Si "$query" 2>/dev/null | grep '^Repository' | awk '{print $3}')
        results+=("official|${query}|${version}|${repo}")
    fi

    # 2. 在官方仓库中搜索匹配
    local official_matches
    official_matches=$(pacman -Ss "^${query}$" 2>/dev/null | head -5)
    if [[ -n "$official_matches" ]]; then
        while IFS= read -r line; do
            if [[ "$line" =~ ^([^/]+)/([^[:space:]]+)[[:space:]]+(.+)$ ]]; then
                local repo="${BASH_REMATCH[1]}"
                local pkg="${BASH_REMATCH[2]}"
                local ver_desc="${BASH_REMATCH[3]}"
                local ver
                ver=$(echo "$ver_desc" | awk '{print $1}')
                # 避免重复
                local already_added=false
                for existing in "${results[@]}"; do
                    if [[ "$existing" == official*"|${pkg}|"* ]]; then
                        already_added=true
                        break
                    fi
                done
                if [[ "$already_added" == false && "$pkg" != "$query" ]]; then
                    results+=("official|${pkg}|${ver}|${repo}")
                fi
            fi
        done <<< "$official_matches"
    fi

    # 3. 检查 AUR
    local aur_response
    aur_response=$(curl -s "https://aur.archlinux.org/rpc/v5/search/${query}?by=name")
    local aur_count
    aur_count=$(echo "$aur_response" | jq -r '.resultcount // 0')

    if [[ "$aur_count" -gt 0 ]]; then
        # 精确匹配优先
        local exact_match
        exact_match=$(echo "$aur_response" | jq -r ".results[] | select(.Name == \"$query\") | \"aur|\\(.Name)|\\(.Version)|AUR\"")
        if [[ -n "$exact_match" ]]; then
            results+=("$exact_match")
        fi

        # 其他匹配
        local other_matches
        other_matches=$(echo "$aur_response" | jq -r ".results[] | select(.Name != \"$query\") | \"aur|\\(.Name)|\\(.Version)|AUR\"" | head -4)
        while IFS= read -r line; do
            [[ -n "$line" ]] && results+=("$line")
        done <<< "$other_matches"
    fi

    # 4. 检查 APT 源
    if [[ -f "${ZPM_CONFIG}/apt.conf" ]]; then
        source "${ZPM_LIB}/sh/apt.sh" 2>/dev/null || true
        local apt_matches
        apt_matches=$(apt_search_simple "$query" 2>/dev/null)
        if [[ -n "$apt_matches" ]]; then
            while IFS='|' read -r pkg_name pkg_version; do
                [[ -n "$pkg_name" ]] && results+=("apt|${pkg_name}|${pkg_version}|APT")
            done <<< "$apt_matches"
        fi
    fi

    # 5. 检查已安装的包
    if pacman -Q "$query" &>/dev/null; then
        local installed_version
        installed_version=$(pacman -Q "$query" | awk '{print $2}')
        # 如果已经在结果中，标记为已安装
        for i in "${!results[@]}"; do
            if [[ "${results[$i]}" == *"|${query}|"* ]]; then
                results[$i]="${results[$i]}|installed"
                break
            fi
        done
    fi

    printf '%s\n' "${results[@]}"
}

# 显示包选择菜单
select_package() {
    local -a packages=("$@")

    # 调试输出到 stderr
    if [[ "$ZPM_DEBUG" == true ]]; then
        log_debug "select_package 接收到 ${#packages[@]} 个参数"
        for i in "${!packages[@]}"; do
            log_debug "  [$i] ${packages[$i]}"
        done
    fi

    if [[ ${#packages[@]} -eq 0 ]]; then
        return 1
    fi

    # 只有一个包，直接返回
    if [[ ${#packages[@]} -eq 1 ]]; then
        echo "${packages[0]}"
        return 0
    fi

    # 菜单输出到 stderr，避免污染 stdout
    echo -e "\n${BOLD}找到多个匹配的包:${NC}\n" >&2
    echo -e "${CYAN}$(printf '%-4s %-10s %-30s %-20s %-15s %s' '序号' '源' '包名' '版本' '仓库' '状态')${NC}" >&2
    echo "$(printf '%-4s %-10s %-30s %-20s %-15s %s' '----' '----------' '------------------------------' '--------------------' '---------------' '----------')" >&2

    local count=0
    for pkg in "${packages[@]}"; do
        ((count++))
        local source_type pkg_name version repo status
        source_type="${pkg%%|*}"
        local rest="${pkg#*|}"
        pkg_name="${rest%%|*}"
        rest="${rest#*|}"
        version="${rest%%|*}"
        rest="${rest#*|}"
        repo="${rest%%|*}"
        status="${rest#*|}"

        [[ "$status" == "$repo" ]] && status=""

        local source_color source_reset
        case "$source_type" in
            official) source_color="${GREEN}"; source_reset="${NC}" ;;
            aur) source_color="${MAGENTA}"; source_reset="${NC}" ;;
            apt) source_color="${YELLOW}"; source_reset="${NC}" ;;
            *) source_color=""; source_reset="" ;;
        esac

        # 打印包信息（输出到 stderr）
        printf '%-4d ' "$count" >&2
        printf '%b' "$source_color" >&2
        printf '%-10s ' "$source_type" >&2
        printf '%b' "$source_reset" >&2
        printf '%-30s %-20s %-15s %s\n' "$pkg_name" "$version" "$repo" "${status:+[已安装]}" >&2
    done

    echo "" >&2

    if [[ "$ZPM_NOCONFIRM" == true ]]; then
        # 自动选择第一个（官方源优先）
        echo "${packages[0]}"
        return 0
    fi

    read -rp "请选择要安装的包 [1-${count}] (默认: 1): " choice
    choice=${choice:-1}

    if [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "$count" ]]; then
        echo "${packages[$((choice-1))]}"
        return 0
    else
        log_error "无效的选择"
        return 1
    fi
}

# 安装包（通用）
install_package() {
    local pkgname="$1"

    log_info "搜索包: $pkgname"

    # 搜索所有源
    local search_results
    search_results=$(search_package_all_sources "$pkgname")

    if [[ -z "$search_results" ]]; then
        log_error "找不到包: $pkgname"
        return 1
    fi

    # 调试输出
    if [[ "$ZPM_DEBUG" == true ]]; then
        log_debug "搜索结果:"
        echo "$search_results" | while read -r line; do
            log_debug "  $line"
        done
    fi

    # 转换为数组
    local -a packages=()
    while IFS= read -r line; do
        [[ -n "$line" ]] && packages+=("$line")
    done <<< "$search_results"

    # 调试输出
    if [[ "$ZPM_DEBUG" == true ]]; then
        log_debug "找到 ${#packages[@]} 个包"
        for i in "${!packages[@]}"; do
            log_debug "  [$i] ${packages[$i]}"
        done
    fi

    # 让用户选择
    local selected
    selected=$(select_package "${packages[@]}")

    if [[ -z "$selected" ]]; then
        return 1
    fi

    # 调试输出
    if [[ "$ZPM_DEBUG" == true ]]; then
        log_debug "选择的原始值: '$selected'"
    fi

    # 解析选择
    local source_type pkg_name
    source_type="${selected%%|*}"
    pkg_name="${selected#*|}"
    pkg_name="${pkg_name%%|*}"

    log_info "选择了: $pkg_name (来源: $source_type)"

    # 根据来源安装
    case "$source_type" in
        official)
            install_official "$pkg_name"
            ;;
        aur)
            install_from_aur "$pkg_name"
            ;;
        apt)
            install_from_apt "$pkg_name"
            ;;
        *)
            log_error "未知的包来源: $source_type"
            return 1
            ;;
    esac
}

# 从官方仓库安装
install_official() {
    local pkgname="$1"

    # 检查是否已安装
    if pacman -Q "$pkgname" &>/dev/null; then
        local installed_version
        installed_version=$(pacman -Q "$pkgname" | awk '{print $2}')
        log_info "包 '$pkgname' 已安装 (版本: $installed_version)"

        if [[ "$ZPM_NEEDED" == true ]]; then
            log_info "跳过安装 (--needed)"
            return 0
        fi

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否重新安装? [y/N] " confirm
            [[ "$confirm" =~ ^[Yy]$ ]] || return 0
        fi
    fi

    log_info "从官方仓库安装: $pkgname"

    # 构建安装选项
    local pacman_opts="-S"
    [[ "$ZPM_NOCONFIRM" == true ]] && pacman_opts="${pacman_opts} --noconfirm"
    [[ "$ZPM_NEEDED" == true ]] && pacman_opts="${pacman_opts} --needed"
    [[ "$ZPM_ASDEPS" == true ]] && pacman_opts="${pacman_opts} --asdeps"

    # 执行安装
    if ! sudo pacman $pacman_opts "$pkgname"; then
        log_error "安装失败: $pkgname"
        return 1
    fi

    log_info "安装完成: $pkgname"
}

# 从 AUR 安装
install_from_aur() {
    local pkgname="$1"

    # 检查是否已安装
    if pacman -Q "$pkgname" &>/dev/null; then
        local installed_version
        installed_version=$(pacman -Q "$pkgname" | awk '{print $2}')
        log_info "包 '$pkgname' 已安装 (版本: $installed_version)"

        if [[ "$ZPM_NEEDED" == true ]]; then
            log_info "跳过安装 (--needed)"
            return 0
        fi

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否重新构建? [y/N] " confirm
            [[ "$confirm" =~ ^[Yy]$ ]] || return 0
        fi
    fi

    log_info "从 AUR 安装: $pkgname"
    source "${ZPM_LIB}/sh/aur.sh"
    aur_install "$pkgname"
}

# 从 APT 源安装
install_from_apt() {
    local pkgname="$1"

    log_info "从 APT 源安装: $pkgname"
    source "${ZPM_LIB}/sh/apt.sh"
    apt_install "$pkgname"
}

# 批量安装
install_packages() {
    local packages=("$@")

    if [[ ${#packages[@]} -eq 0 ]]; then
        log_error "请指定要安装的包"
        return 1
    fi

    log_info "准备安装 ${#packages[@]} 个包"

    local failed=()
    local success=()

    for pkg in "${packages[@]}"; do
        if install_package "$pkg"; then
            success+=("$pkg")
        else
            failed+=("$pkg")
        fi
    done

    # 显示结果
    echo ""
    if [[ ${#success[@]} -gt 0 ]]; then
        log_info "成功安装: ${success[*]}"
    fi
    if [[ ${#failed[@]} -gt 0 ]]; then
        log_error "安装失败: ${failed[*]}"
        return 1
    fi

    return 0
}

# 处理安装命令
handle_install_command() {
    local subcommand="${1:-help}"
    shift || true

    case "$subcommand" in
        official|o)
            install_official "$1"
            ;;
        aur|a)
            install_from_aur "$1"
            ;;
        apt|ap)
            install_from_apt "$1"
            ;;
        local|l)
            install_local_package "$1"
            ;;
        help|h|--help)
            cat << 'EOF'
安装命令用法:
    zpm install official [包名]   从官方仓库安装
    zpm install aur [包名]        从 AUR 安装
    zpm install apt [包名]        从 APT 源安装
    zpm install local [文件]      安装本地包

说明:
    直接使用 zpm -S [包名] 会自动搜索所有源并选择
EOF
            ;;
        *)
            # 默认行为：作为包名直接安装
            install_packages "$subcommand" "$@"
            ;;
    esac
}

# 安装本地包
install_local_package() {
    local file="$1"

    if [[ ! -f "$file" ]]; then
        log_error "文件不存在: $file"
        return 1
    fi

    case "$file" in
        *.pkg.tar.zst|*.pkg.tar.xz)
            log_info "安装本地包: $file"
            sudo pacman -U --noconfirm "$file"
            ;;
        *.deb)
            log_info "安装 deb 包: $file"
            source "${ZPM_LIB}/sh/deb.sh"
            install_deb "$file"
            ;;
        PKGBUILD)
            log_info "从 PKGBUILD 构建安装"
            source "${ZPM_LIB}/sh/build.sh"
            build_package "$(dirname "$file")"
            ;;
        *)
            log_error "不支持的文件类型: $file"
            return 1
            ;;
    esac
}
