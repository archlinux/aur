#!/bin/bash
#
# 软件源管理模块
# 支持 Pacman 软件源读取和管理
#

REPO_CACHE_DIR="${ZPM_CACHE}/repo"
PACMAN_CONF="/etc/pacman.conf"
ZPM_REPO_CONF="${ZPM_CONFIG}/repos.conf"

# 初始化目录
init_repo_dirs() {
    [[ -d "$REPO_CACHE_DIR" ]] || mkdir -p "$REPO_CACHE_DIR"
}

# 读取 pacman.conf 中的软件源
read_pacman_repos() {
    log_debug "读取 pacman 软件源配置"

    if [[ ! -f "$PACMAN_CONF" ]]; then
        log_warn "未找到 pacman.conf"
        return 1
    fi

    local repos=()
    local current_repo=""

    while IFS= read -r line; do
        # 跳过注释和空行
        [[ "$line" =~ ^[[:space:]]*# ]] && continue
        [[ -z "$line" ]] && continue

        # 检测仓库节
        if [[ "$line" =~ ^\[([^\]]+)\]$ ]]; then
            current_repo="${BASH_REMATCH[1]}"
            # 跳过 options 节
            [[ "$current_repo" == "options" ]] && current_repo=""
            continue
        fi

        # 解析 Include
        if [[ "$line" =~ ^[Ii]nclude[[:space:]]*=[[:space:]]*(.+)$ ]]; then
            local include_file="${BASH_REMATCH[1]}"
            # 处理通配符
            for f in $include_file; do
                if [[ -f "$f" ]]; then
                    log_debug "包含文件: $f"
                fi
            done
            continue
        fi

        # 解析 Server
        if [[ -n "$current_repo" && "$line" =~ ^[Ss]erver[[:space:]]*=[[:space:]]*(.+)$ ]]; then
            local server="${BASH_REMATCH[1]}"
            # 替换变量
            server=$(echo "$server" | sed "s|\$repo|$current_repo|g; s|\$arch|$(uname -m)|g")
            repos+=("${current_repo}|${server}")
        fi
    done < "$PACMAN_CONF"

    if [[ ${#repos[@]} -gt 0 ]]; then
        printf '%s\n' "${repos[@]}"
    fi
}

# 列出所有软件源
list_repos() {
    init_repo_dirs

    echo -e "\n${BOLD}Pacman 软件源:${NC}\n"

    local repos
    repos=$(read_pacman_repos)

    if [[ -z "$repos" ]]; then
        log_warn "未找到软件源"
    else
        echo -e "${CYAN}$(printf '%-20s %s' '仓库名称' '服务器地址')${NC}"
        echo "$(printf '%-20s %s' '--------------------' '--------------------------------------------------')"

        while IFS='|' read -r name server; do
            printf '%-20s %s\n' "$name" "$server"
        done <<< "$repos"
    fi

    echo ""

    # 显示 ZPM 额外配置的源
    if [[ -f "$ZPM_REPO_CONF" ]]; then
        echo -e "${BOLD}ZPM 额外软件源:${NC}\n"
        cat "$ZPM_REPO_CONF" | grep -v '^#' | grep -v '^$'
        echo ""
    fi
}

# 获取软件源数据库
get_repo_db() {
    local repo_name="$1"
    local server_url="$2"

    log_debug "获取软件源数据库: $repo_name"

    local db_file="${REPO_CACHE_DIR}/${repo_name}.db.tar.gz"
    local db_url="${server_url}/${repo_name}.db.tar.gz"

    # 下载数据库
    if [[ ! -f "$db_file" ]] || [[ "$(find "$db_file" -mtime +1)" ]]; then
        log_info "更新软件源数据库: $repo_name"
        curl -sL "$db_url" -o "$db_file" 2>/dev/null || {
            log_warn "无法下载数据库: $db_url"
            return 1
        }
    fi

    echo "$db_file"
}

# 从软件源搜索包
search_repo_packages() {
    local query="$1"

    log_info "在软件源中搜索: $query"

    local repos
    repos=$(read_pacman_repos)

    local results=()

    while IFS='|' read -r repo_name server_url; do
        log_debug "搜索仓库: $repo_name"

        local db_file
        db_file=$(get_repo_db "$repo_name" "$server_url")

        if [[ -n "$db_file" && -f "$db_file" ]]; then
            # 解压并搜索
            local temp_dir="${REPO_CACHE_DIR}/temp_${repo_name}_$$"
            [[ -d "$temp_dir" ]] && rm -rf "$temp_dir"
            mkdir -p "$temp_dir"

            tar -xzf "$db_file" -C "$temp_dir" 2>/dev/null || continue

            # 搜索包
            for pkg_dir in "$temp_dir"/*/; do
                if [[ -f "${pkg_dir}/desc" ]]; then
                    local pkg_name pkg_version pkg_desc
                    pkg_name=$(grep -A1 '^%NAME%$' "${pkg_dir}/desc" 2>/dev/null | tail -1)
                    pkg_version=$(grep -A1 '^%VERSION%$' "${pkg_dir}/desc" 2>/dev/null | tail -1)
                    pkg_desc=$(grep -A1 '^%DESC%$' "${pkg_dir}/desc" 2>/dev/null | tail -1)

                    if [[ "$pkg_name" == *"$query"* || "$pkg_desc" == *"$query"* ]]; then
                        results+=("${repo_name}|${pkg_name}|${pkg_version}|${pkg_desc}")
                    fi
                fi
            done

            rm -rf "$temp_dir"
        fi
    done <<< "$repos"

    if [[ ${#results[@]} -eq 0 ]]; then
        log_warn "未找到匹配的包"
        return 0
    fi

    echo -e "\n${BOLD}软件源搜索结果:${NC}\n"
    echo -e "${CYAN}$(printf '%-4s %-15s %-30s %-20s' '序号' '仓库' '包名' '版本')${NC}"
    echo "$(printf '%-4s %-15s %-30s %-20s' '----' '---------------' '------------------------------' '--------------------')"

    local count=0
    for result in "${results[@]}"; do
        ((count++))
        local repo name version desc
        repo="${result%%|*}"
        local rest="${result#*|}"
        name="${rest%%|*}"
        rest="${rest#*|}"
        version="${rest%%|*}"
        desc="${rest#*|}"

        printf '%-4d %-15s %-30s %-20s\n' "$count" "$repo" "$name" "$version"
    done

    echo ""
    log_info "找到 $count 个结果"
}

# 获取包信息
get_package_info_from_repo() {
    local pkgname="$1"

    local repos
    repos=$(read_pacman_repos)

    while IFS='|' read -r repo_name server_url; do
        local db_file
        db_file=$(get_repo_db "$repo_name" "$server_url")

        if [[ -n "$db_file" && -f "$db_file" ]]; then
            local temp_dir="${REPO_CACHE_DIR}/temp_info_$$"
            [[ -d "$temp_dir" ]] && rm -rf "$temp_dir"
            mkdir -p "$temp_dir"

            tar -xzf "$db_file" -C "$temp_dir" 2>/dev/null || continue

            if [[ -d "${temp_dir}/${pkgname}" ]]; then
                local desc_file="${temp_dir}/${pkgname}/desc"
                if [[ -f "$desc_file" ]]; then
                    cat "$desc_file"
                    rm -rf "$temp_dir"
                    return 0
                fi
            fi

            rm -rf "$temp_dir"
        fi
    done <<< "$repos"

    return 1
}

# 更新所有软件源
update_repos() {
    log_info "更新软件源..."

    # 更新 pacman 数据库
    sudo pacman -Sy || {
        log_error "更新 pacman 软件源失败"
        return 1
    }

    # 更新 ZPM 缓存的数据库
    init_repo_dirs

    local repos
    repos=$(read_pacman_repos)

    while IFS='|' read -r repo_name server_url; do
        log_info "更新: $repo_name"
        get_repo_db "$repo_name" "$server_url" > /dev/null
    done <<< "$repos"

    log_info "软件源更新完成"
}

# 添加自定义软件源
add_repo() {
    local name="$1"
    local server="$2"

    log_info "添加软件源: $name"

    if [[ ! -f "$ZPM_REPO_CONF" ]]; then
        cat > "$ZPM_REPO_CONF" << 'EOF'
# ZPM 额外软件源配置
# 格式: [仓库名称] [服务器地址]
EOF
    fi

    echo "${name} ${server}" >> "$ZPM_REPO_CONF"
    log_info "已添加软件源: $name"
}

# 移除自定义软件源
remove_repo() {
    local name="$1"

    log_info "移除软件源: $name"

    if [[ -f "$ZPM_REPO_CONF" ]]; then
        sed -i "/^${name}[[:space:]]/d" "$ZPM_REPO_CONF"
        log_info "已移除软件源: $name"
    else
        log_warn "未找到软件源配置"
    fi
}

# 处理软件源命令
handle_repo_command() {
    local subcommand="${1:-list}"
    shift || true

    case "$subcommand" in
        list|l)
            list_repos
            ;;
        update|up|sync)
            update_repos
            ;;
        search|s)
            search_repo_packages "$1"
            ;;
        info|i)
            get_package_info_from_repo "$1"
            ;;
        add|a)
            add_repo "$1" "$2"
            ;;
        remove|r)
            remove_repo "$1"
            ;;
        help|h|--help)
            cat << 'EOF'
软件源命令用法:
    zpm repo list               列出所有软件源
    zpm repo update             更新所有软件源
    zpm repo search [关键词]    在软件源中搜索包
    zpm repo info [包名]        获取软件源中的包信息
    zpm repo add [名称] [地址]  添加自定义软件源
    zpm repo remove [名称]      移除自定义软件源

说明:
    软件源配置读取自 /etc/pacman.conf
    额外的软件源配置保存在 ~/.zpm/config/repos.conf
EOF
            ;;
        *)
            log_error "未知的软件源命令: $subcommand"
            handle_repo_command help
            return 1
            ;;
    esac
}
