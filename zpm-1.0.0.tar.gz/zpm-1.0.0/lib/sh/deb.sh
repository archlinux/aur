#!/bin/bash
#
# Debian 包转换模块
# 将 .deb 包转换为 Arch Linux 的 pkg.tar.zst 格式
#

DEB_CACHE_DIR="${ZPM_CACHE}/deb"
DEB_BUILD_DIR="${ZPM_BUILD}/deb"

# 初始化目录
init_deb_dirs() {
    [[ -d "$DEB_CACHE_DIR" ]] || mkdir -p "$DEB_CACHE_DIR"
    [[ -d "$DEB_BUILD_DIR" ]] || mkdir -p "$DEB_BUILD_DIR"
}

# 提取 deb 包内容
extract_deb() {
    local deb_file="$1"
    local extract_dir="$2"

    # 转换为绝对路径
    if [[ ! "$deb_file" =~ ^/ ]]; then
        deb_file="$(pwd)/$deb_file"
    fi

    log_debug "提取 deb 包: $deb_file 到 $extract_dir"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    [[ -d "$extract_dir" ]] && rm -rf "$extract_dir"
    mkdir -p "$extract_dir"

    # 解压 deb 包 (ar 格式)
    (
        cd "$extract_dir" || exit 1
        ar x "$deb_file" || {
            log_error "无法解压 deb 包 (ar 格式)"
            exit 1
        }

        # 解压 data.tar.*
        local data_tar
        data_tar=$(ls data.tar.* 2>/dev/null | head -1)
        if [[ -n "$data_tar" ]]; then
            mkdir -p data
            tar -xf "$data_tar" -C data || {
                log_error "无法解压 data.tar"
                exit 1
            }
        fi

        # 解压 control.tar.*
        local control_tar
        control_tar=$(ls control.tar.* 2>/dev/null | head -1)
        if [[ -n "$control_tar" ]]; then
            mkdir -p control
            tar -xf "$control_tar" -C control || {
                log_error "无法解压 control.tar"
                exit 1
            }
        fi
    )
}

# 解析 control 文件
parse_control() {
    local control_file="$1"

    if [[ ! -f "$control_file" ]]; then
        log_error "未找到 control 文件: $control_file"
        return 1
    fi

    # 使用 Python 解析
    python3 "${ZPM_LIB}/python/deb_parser.py" parse-control "$control_file"
}

# 获取 deb 包信息
get_deb_info() {
    local deb_file="$1"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    init_deb_dirs

    local extract_dir="${DEB_CACHE_DIR}/extract_$(basename "$deb_file" .deb)"
    extract_deb "$deb_file" "$extract_dir"

    local control_file="${extract_dir}/control/control"
    if [[ -f "$control_file" ]]; then
        parse_control "$control_file"
    else
        log_error "未找到 control 文件"
        return 1
    fi
}

# 显示 deb 包信息
show_deb_info() {
    local deb_file="$1"

    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    log_info "正在读取包信息: $(basename "$deb_file")"

    local info
    info=$(get_deb_info "$deb_file")

    if [[ -z "$info" ]]; then
        return 1
    fi

    # 解析 JSON 输出
    echo -e "\n${BOLD}Debian 包信息:${NC}\n"

    local pkg_name pkg_version pkg_arch pkg_maintainer pkg_description
    pkg_name=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Package', 'N/A'))")
    pkg_version=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Version', 'N/A'))")
    pkg_arch=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Architecture', 'N/A'))")
    pkg_maintainer=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Maintainer', 'N/A'))")
    pkg_description=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Description', 'N/A'))")

    echo -e "${GREEN}包名:${NC}        $pkg_name"
    echo -e "${GREEN}版本:${NC}        $pkg_version"
    echo -e "${GREEN}架构:${NC}        $pkg_arch"
    echo -e "${GREEN}维护者:${NC}      $pkg_maintainer"
    echo -e "${GREEN}描述:${NC}        $pkg_description"

    # 依赖信息
    local depends
    depends=$(echo "$info" | python3 -c "import sys,json; d=json.load(sys.stdin).get('Depends', ''); print(d if d else '无')")
    echo -e "${GREEN}依赖:${NC}        $depends"

    # 其他字段
    local recommends suggests conflicts
    recommends=$(echo "$info" | python3 -c "import sys,json; d=json.load(sys.stdin).get('Recommends', ''); print(d if d else '无')")
    suggests=$(echo "$info" | python3 -c "import sys,json; d=json.load(sys.stdin).get('Suggests', ''); print(d if d else '无')")
    conflicts=$(echo "$info" | python3 -c "import sys,json; d=json.load(sys.stdin).get('Conflicts', ''); print(d if d else '无')")

    echo -e "${GREEN}推荐:${NC}        $recommends"
    echo -e "${GREEN}建议:${NC}        $suggests"
    echo -e "${GREEN}冲突:${NC}        $conflicts"
    echo ""
}

# 转换依赖为 Arch 格式
convert_deps() {
    local deb_deps="$1"

    # 使用 Python 进行依赖转换
    python3 "${ZPM_LIB}/python/deb_parser.py" convert-deps "$deb_deps"
}

# 创建 PKGBUILD 从 deb 包
create_pkgbuild_from_deb() {
    local deb_file="$1"
    local build_dir="$2"

    log_info "为 deb 包创建 PKGBUILD"

    local info
    info=$(get_deb_info "$deb_file")

    if [[ -z "$info" ]]; then
        log_error "无法获取 deb 包信息"
        return 1
    fi

    local pkg_name pkg_version pkg_arch pkg_description pkg_maintainer
    pkg_name=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Package', 'unknown'))")
    pkg_version=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Version', '1.0'))")
    pkg_arch=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Architecture', 'amd64'))")
    pkg_description=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Description', 'Converted from deb'))")
    pkg_maintainer=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Maintainer', 'Unknown'))")

    # 转换架构
    case "$pkg_arch" in
        amd64) pkg_arch="x86_64" ;;
        i386) pkg_arch="i686" ;;
        arm64) pkg_arch="aarch64" ;;
        armhf) pkg_arch="armv7h" ;;
        all) pkg_arch="any" ;;
    esac

    # 获取并转换依赖
    local deb_deps
    deb_deps=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Depends', ''))")
    local arch_deps
    arch_deps=$(convert_deps "$deb_deps")

    # 创建 PKGBUILD
    cat > "${build_dir}/PKGBUILD" << EOF
# 由 ZPM 自动从 Debian 包转换生成
# 原始维护者: $pkg_maintainer
# 转换日期: $(date '+%Y-%m-%d %H:%M:%S')

pkgname=${pkg_name}
pkgver=${pkg_version%%-*}
pkgrel=1
pkgdesc="${pkg_description}"
arch=('${pkg_arch}')
url=""
license=('unknown')
depends=(${arch_deps})
source=("$(basename "$deb_file")")
noextract=("$(basename "$deb_file")")
md5sums=('SKIP')

package() {
    cd "\${srcdir}"
    
    # 提取 deb 包
    ar x "$(basename "$deb_file")"
    
    # 解压数据
    local data_tar=\$(ls data.tar.* | head -1)
    tar -xf "\${data_tar}" -C "\${pkgdir}"
    
    # 修复权限
    find "\${pkgdir}" -type d -exec chmod 755 {} \;
    find "\${pkgdir}" -type f -exec chmod 644 {} \;
    
    # 修复特殊目录权限
    [[ -d "\${pkgdir}/usr/bin" ]] && chmod 755 "\${pkgdir}/usr/bin"/* 2>/dev/null || true
    [[ -d "\${pkgdir}/bin" ]] && chmod 755 "\${pkgdir}/bin"/* 2>/dev/null || true
    [[ -d "\${pkgdir}/usr/sbin" ]] && chmod 755 "\${pkgdir}/usr/sbin"/* 2>/dev/null || true
    [[ -d "\${pkgdir}/sbin" ]] && chmod 755 "\${pkgdir}/sbin"/* 2>/dev/null || true
}
EOF

    log_info "已创建 PKGBUILD: ${build_dir}/PKGBUILD"
}

# 询问并安装依赖（带包名映射询问）
install_deb_dependency() {
    local dep="$1"
    local original_dep="$dep"

    # 去除版本号
    dep=$(echo "$dep" | sed 's/[>=<].*$//')

    # 检查是否已安装
    if pacman -Q "$dep" &>/dev/null; then
        log_info "依赖已安装: $dep"
        return 0
    fi

    # 尝试安装
    log_info "尝试安装依赖: $dep"
    if sudo pacman -S --noconfirm "$dep" 2>/dev/null; then
        return 0
    fi

    # 安装失败，询问用户
    log_warn "官方仓库未找到: $dep"

    if [[ "$ZPM_NOCONFIRM" == true ]]; then
        log_info "跳过依赖: $dep (noconfirm 模式)"
        return 0
    fi

    # 确保在交互式终端中运行
    if [[ ! -t 0 ]]; then
        log_info "非交互式环境，跳过依赖: $dep"
        return 0
    fi

    echo -e "\n${YELLOW}依赖 '$dep' 在 Arch 官方仓库中未找到。${NC}"
    echo -e "${CYAN}选项:${NC}"
    echo "  1) 跳过此依赖 (继续构建)"
    echo "  2) 输入 Arch 系统中的对应包名"
    echo "  3) 从 AUR 安装"

    local choice=""
    read -rp "请选择 [1-3] (默认: 1): " choice 2>/dev/null || choice="1"

    case "$choice" in
        2)
            local arch_pkg=""
            read -rp "请输入 Arch 包名: " arch_pkg 2>/dev/null || arch_pkg=""
            if [[ -n "$arch_pkg" ]]; then
                log_info "尝试安装: $arch_pkg"
                if sudo pacman -S --noconfirm "$arch_pkg" 2>/dev/null; then
                    log_info "成功安装: $arch_pkg"
                    return 0
                else
                    log_warn "无法安装: $arch_pkg"
                    return 0
                fi
            else
                log_info "未输入包名，跳过依赖: $dep"
                return 0
            fi
            ;;
        3)
            log_info "尝试从 AUR 安装: $dep"
            source "${ZPM_LIB}/sh/aur.sh" 2>/dev/null || {
                log_warn "无法加载 AUR 模块"
                return 0
            }
            if type aur_install &>/dev/null && aur_install "$dep" 2>/dev/null; then
                return 0
            else
                log_warn "AUR 安装失败: $dep"
                return 0
            fi
            ;;
        *)
            log_info "跳过依赖: $dep"
            return 0
            ;;
    esac
}

# 转换 deb 包为 Arch 包
convert_deb() {
    local deb_file="$1"
    local output_dir="${2:-$PWD}"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    init_deb_dirs

    log_info "转换 deb 包: $(basename "$deb_file")"

    # 获取包信息
    local info
    info=$(get_deb_info "$deb_file")

    if [[ -z "$info" ]]; then
        log_error "无法获取包信息，转换失败"
        return 1
    fi

    local pkg_name
    pkg_name=$(echo "$info" | python3 -c "import sys,json; print(json.load(sys.stdin).get('Package', 'unknown'))")

    local build_dir="${DEB_BUILD_DIR}/${pkg_name}_$(date +%s)"
    [[ -d "$build_dir" ]] && rm -rf "$build_dir"
    mkdir -p "$build_dir"

    # 复制 deb 文件到构建目录
    cp "$deb_file" "$build_dir/"

    # 创建 PKGBUILD
    create_pkgbuild_from_deb "$deb_file" "$build_dir" || return 1

    # 安装依赖（带询问功能）
    log_info "安装依赖..."
    local all_deps
    all_deps=$(
        cd "$build_dir" || exit 1
        source PKGBUILD 2>/dev/null && echo "${depends[@]}"
    )

    if [[ -n "$all_deps" ]]; then
        echo -e "\n${BOLD}处理依赖:${NC}\n"
        for dep in $all_deps; do
            install_deb_dependency "$dep" || true
        done
    fi

    # 构建包
    (
        cd "$build_dir" || exit 1

        log_info "开始构建 Arch 包..."
        if ! makepkg -sf --noconfirm 2>&1 | tee "${ZPM_LOGS}/deb-build-${pkg_name}.log"; then
            log_error "构建失败"
            exit 1
        fi

        # 获取构建好的包
        local pkg_file
        pkg_file=$(ls -t ./*.pkg.tar.zst 2>/dev/null | head -1)

        if [[ -z "$pkg_file" ]]; then
            log_error "未找到构建好的包"
            exit 1
        fi

        # 移动到输出目录
        mv "$pkg_file" "$output_dir/"
        local output_file="${output_dir}/$(basename "$pkg_file")"

        log_info "转换完成: $output_file"
        echo "$output_file"
    )
}

# 转换并安装 deb 包
convert_and_install_deb() {
    local deb_file="$1"

    log_info "转换并安装 deb 包: $(basename "$deb_file")"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    # 转换
    local pkg_file
    pkg_file=$(convert_deb "$deb_file" "$DEB_CACHE_DIR")

    if [[ -z "$pkg_file" ]]; then
        log_error "转换失败"
        return 1
    fi

    # 安装
    log_info "安装转换后的包..."
    if ! sudo pacman -U --noconfirm "$pkg_file"; then
        log_error "安装失败"
        return 1
    fi

    log_info "安装完成"
}

# 直接安装 deb 包（不转换，仅提取）
install_deb_direct() {
    local deb_file="$1"

    log_info "直接安装 deb 包: $(basename "$deb_file")"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    init_deb_dirs

    local extract_dir="${DEB_CACHE_DIR}/install_$(basename "$deb_file" .deb)_$(date +%s)"
    extract_deb "$deb_file" "$extract_dir"

    if [[ ! -d "${extract_dir}/data" ]]; then
        log_error "未找到数据目录: ${extract_dir}/data"
        return 1
    fi

    log_info "复制文件到系统..."

    # 复制文件到根目录
    if ! sudo cp -r "${extract_dir}/data"/* / 2>/dev/null; then
        log_error "复制文件失败"
        return 1
    fi

    # 执行 postinst 脚本
    if [[ -f "${extract_dir}/control/postinst" ]]; then
        log_info "执行安装后脚本..."
        sudo bash "${extract_dir}/control/postinst" configure || log_warn "postinst 脚本执行失败"
    fi

    log_info "安装完成"
}

# 安装 deb 包
install_deb() {
    local deb_file="$1"

    # 检查文件是否存在
    if [[ ! -f "$deb_file" ]]; then
        log_error "文件不存在: $deb_file"
        return 1
    fi

    # 询问转换或直接安装
    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        echo -e "\n${YELLOW}选择安装方式:${NC}"
        echo "  1) 转换为 Arch 包并安装 (推荐)"
        echo "  2) 直接提取安装"
        read -rp "请选择 [1/2]: " choice
    else
        choice=1
    fi

    case "$choice" in
        2)
            install_deb_direct "$deb_file"
            ;;
        *)
            convert_and_install_deb "$deb_file"
            ;;
    esac
}

# 处理 deb 命令
handle_deb_command() {
    local subcommand="${1:-help}"
    shift || true

    case "$subcommand" in
        info|i)
            show_deb_info "$1"
            ;;
        convert|c)
            convert_deb "$1" "$2"
            ;;
        install|in)
            install_deb "$1"
            ;;
        extract|x)
            init_deb_dirs
            local extract_dir="${DEB_CACHE_DIR}/extract_$(basename "$1" .deb)"
            extract_deb "$1" "$extract_dir"
            log_info "已提取到: $extract_dir"
            ;;
        help|h|--help)
            cat << 'EOF'
Debian 包命令用法:
    zpm deb info [文件.deb]     显示 deb 包信息
    zpm deb convert [文件.deb] [输出目录]  转换为 Arch 包
    zpm deb install [文件.deb]  安装 deb 包
    zpm deb extract [文件.deb]  提取 deb 包内容

说明:
    convert - 将 deb 包转换为 Arch 的 pkg.tar.zst 格式
    install - 自动转换并安装，或直接提取安装
EOF
            ;;
        *)
            log_error "未知的 deb 命令: $subcommand"
            handle_deb_command help
            return 1
            ;;
    esac
}
