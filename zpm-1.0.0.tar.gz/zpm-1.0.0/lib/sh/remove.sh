#!/bin/bash
#
# 包移除模块
# 处理包的卸载逻辑
#

# 移除包
remove_package() {
    local pkgname="$1"
    local opts="${2:-}"

    log_info "准备移除: $pkgname"

    # 检查包是否已安装
    if ! pacman -Q "$pkgname" &>/dev/null; then
        log_warn "包 '$pkgname' 未安装"
        return 1
    fi

    # 检查依赖
    local deps
    deps=$(pacman -Qi "$pkgname" 2>/dev/null | grep "Required By" | cut -d: -f2 | tr -d ' ')

    if [[ -n "$deps" && "$deps" != "None" ]]; then
        log_warn "以下包依赖于 '$pkgname': $deps"
        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否继续移除? [y/N] " confirm
            [[ "$confirm" =~ ^[Yy]$ ]] || return 1
        fi
    fi

    # 构建移除选项
    local remove_opts="-R"
    [[ "$ZPM_NOCONFIRM" == true ]] && remove_opts="${remove_opts} --noconfirm"

    # 递归移除未使用的依赖
    if [[ "$opts" == *"--recursive"* || "$opts" == *"-s"* ]]; then
        remove_opts="${remove_opts}s"
    fi

    # 移除包
    sudo pacman $remove_opts "$pkgname" || {
        log_error "移除失败: $pkgname"
        return 1
    }

    log_info "已移除: $pkgname"
}

# 批量移除
remove_packages() {
    local packages=("$@")

    if [[ ${#packages[@]} -eq 0 ]]; then
        log_error "请指定要移除的包"
        return 1
    fi

    log_info "准备移除 ${#packages[@]} 个包"

    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        echo -e "\n${YELLOW}将要移除以下包:${NC}"
        printf '  %s\n' "${packages[@]}"
        read -rp "\n是否继续? [y/N] " confirm
        [[ "$confirm" =~ ^[Yy]$ ]] || return 1
    fi

    local failed=()
    local success=()

    for pkg in "${packages[@]}"; do
        if remove_package "$pkg"; then
            success+=("$pkg")
        else
            failed+=("$pkg")
        fi
    done

    echo ""
    log_info "移除完成: ${#success[@]} 成功, ${#failed[@]} 失败"

    if [[ ${#failed[@]} -gt 0 ]]; then
        log_error "失败的包: ${failed[*]}"
        return 1
    fi
}
