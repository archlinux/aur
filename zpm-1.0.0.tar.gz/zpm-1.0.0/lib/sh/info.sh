#!/bin/bash
#
# 包信息模块
# 显示包的详细信息
#

# 显示包信息
show_package_info() {
    local pkgname="$1"

    log_info "获取包信息: $pkgname"

    # 检查是否已安装
    if pacman -Q "$pkgname" &>/dev/null; then
        echo -e "\n${BOLD}已安装包信息:${NC}\n"
        pacman -Qi "$pkgname"
    fi

    # 检查官方仓库
    if pacman -Si "$pkgname" &>/dev/null; then
        echo -e "\n${BOLD}仓库包信息:${NC}\n"
        pacman -Si "$pkgname"
        return 0
    fi

    # 检查 AUR
    local aur_response
    aur_response=$(curl -s "https://aur.archlinux.org/rpc/v5/info?arg[]=${pkgname}")
    local resultcount
    resultcount=$(echo "$aur_response" | jq -r '.resultcount // 0')

    if [[ "$resultcount" -gt 0 ]]; then
        source "${ZPM_LIB}/sh/aur.sh"
        aur_info "$pkgname"
        return 0
    fi

    log_error "找不到包: $pkgname"
    return 1
}
