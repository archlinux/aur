#!/bin/bash
#
# AUR 管理模块
# 提供完整的 AUR 包管理功能
#

AUR_BASE_URL="https://aur.archlinux.org"
AUR_RPC_URL="${AUR_BASE_URL}/rpc/v5"
AUR_GIT_URL="${AUR_BASE_URL}"

# 从 AUR 搜索包
aur_search() {
    local query="$1"
    local search_type="${2:-search}"

    log_info "正在 AUR 中搜索: $query"

    local encoded_query
    encoded_query=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$query'))" 2>/dev/null || echo "$query")

    local response
    response=$(curl -s "${AUR_RPC_URL}?v=5&type=${search_type}&arg=${encoded_query}")

    if [[ -z "$response" ]]; then
        log_error "无法连接到 AUR"
        return 1
    fi

    # 检查是否有错误
    if echo "$response" | jq -e 'has("error")' &>/dev/null; then
        local error_msg
        error_msg=$(echo "$response" | jq -r '.error // "未知错误"')
        log_error "AUR 查询失败: $error_msg"
        return 1
    fi

    local resultcount
    resultcount=$(echo "$response" | jq -r '.resultcount // 0')

    if [[ "$resultcount" -eq 0 ]]; then
        log_warn "未找到匹配的包"
        return 0
    fi

    echo -e "\n${BOLD}AUR 搜索结果:${NC}\n"
    echo -e "${CYAN}$(printf '%-4s %-30s %-15s %-10s %s' '序号' '包名' '版本' '票数' '描述')${NC}"
    echo "$(printf '%-4s %-30s %-15s %-10s %s' '----' '------------------------------' '---------------' '----------' '--------------------------------')"

    echo "$response" | jq -r '.results[] | [.Name, .Version, .NumVotes, .Description] | @tsv' | \
    awk -F'\t' -v cyan="$CYAN" -v green="$GREEN" -v yellow="$YELLOW" -v nc="$NC" '{
        printf "%s%-4d%s %-30s %-15s %s%-10s%s %s\n", cyan, NR, nc, $1, $2, yellow, $3, nc, $4
    }'

    echo ""
    log_info "找到 $resultcount 个结果"
}

# 获取 AUR 包信息
aur_info() {
    local pkgname="$1"

    log_info "正在获取 AUR 包信息: $pkgname"

    local response
    response=$(curl -s "${AUR_RPC_URL}?v=5&type=info&arg[]=${pkgname}")

    if [[ -z "$response" ]]; then
        log_error "无法连接到 AUR"
        return 1
    fi

    # 检查是否有错误
    if echo "$response" | jq -e 'has("error")' &>/dev/null; then
        local error_msg
        error_msg=$(echo "$response" | jq -r '.error // "未知错误"')
        log_error "AUR 查询失败: $error_msg"
        return 1
    fi

    local resultcount
    resultcount=$(echo "$response" | jq -r '.resultcount // 0')

    if [[ "$resultcount" -eq 0 ]]; then
        log_error "包 '$pkgname' 不在 AUR 中"
        return 1
    fi

    local result
    result=$(echo "$response" | jq -r '.results[0]')

    echo -e "\n${BOLD}AUR 包信息:${NC}\n"
    echo -e "${GREEN}包名:${NC}        $(echo "$result" | jq -r '.Name')"
    echo -e "${GREEN}版本:${NC}        $(echo "$result" | jq -r '.Version')"
    echo -e "${GREEN}描述:${NC}        $(echo "$result" | jq -r '.Description // "N/A"')"
    echo -e "${GREEN}上游 URL:${NC}    $(echo "$result" | jq -r '.URL // "N/A"')"
    echo -e "${GREEN}许可证:${NC}      $(echo "$result" | jq -r '.License | if type == "array" then join(", ") else . // "N/A" end')"
    echo -e "${GREEN}维护者:${NC}      $(echo "$result" | jq -r '.Maintainer // "孤儿包"')"
    echo -e "${GREEN}票数:${NC}        $(echo "$result" | jq -r '.NumVotes')"
    echo -e "${GREEN}流行度:${NC}      $(echo "$result" | jq -r '.Popularity')"
    echo -e "${GREEN}首次提交:${NC}    $(echo "$result" | jq -r '.FirstSubmitted | if . then strftime("%Y-%m-%d %H:%M:%S") else "N/A" end')"
    echo -e "${GREEN}最后修改:${NC}    $(echo "$result" | jq -r '.LastModified | if . then strftime("%Y-%m-%d %H:%M:%S") else "N/A" end')"
    echo -e "${GREEN}依赖:${NC}        $(echo "$result" | jq -r '.Depends | if type == "array" then join(", ") else . // "无" end')"
    echo -e "${GREEN}构建依赖:${NC}    $(echo "$result" | jq -r '.MakeDepends | if type == "array" then join(", ") else . // "无" end')"
    echo -e "${GREEN}可选依赖:${NC}    $(echo "$result" | jq -r '.OptDepends | if type == "array" then join(", ") else . // "无" end')"
    echo -e "${GREEN}冲突:${NC}        $(echo "$result" | jq -r '.Conflicts | if type == "array" then join(", ") else . // "无" end')"
    echo -e "${GREEN}提供:${NC}        $(echo "$result" | jq -r '.Provides | if type == "array" then join(", ") else . // "无" end')"
    echo ""
}

# 克隆 AUR 仓库
aur_clone() {
    local pkgname="$1"
    local clone_dir="${2:-$PWD}"

    log_info "正在克隆 AUR 仓库: $pkgname" >&2

    local git_url="${AUR_GIT_URL}/${pkgname}.git"
    local target_dir="${clone_dir}/${pkgname}"

    if [[ -d "$target_dir" ]]; then
        log_warn "目录已存在: $target_dir" >&2
        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否删除并重新克隆? [y/N] " confirm
            [[ "$confirm" =~ ^[Yy]$ ]] || return 1
            rm -rf "$target_dir"
        else
            rm -rf "$target_dir"
        fi
    fi

    git clone "$git_url" "$target_dir" >&2 || {
        log_error "克隆失败: $git_url" >&2
        return 1
    }

    log_info "已克隆到: $target_dir" >&2
}

# 下载 AUR 包源码
aur_download() {
    local pkgname="$1"
    local build_dir="${ZPM_BUILD}/aur/${pkgname}"

    log_info "正在下载 AUR 包: $pkgname" >&2

    # 清理旧目录
    [[ -d "$build_dir" ]] && rm -rf "$build_dir"
    mkdir -p "$build_dir"

    # 克隆仓库
    aur_clone "$pkgname" "$build_dir" >&2 || return 1

    # 只输出目录路径到 stdout
    echo "$build_dir/${pkgname}"
}

# 解析 AUR 依赖
aur_resolve_deps() {
    local pkgname="$1"
    local -n deps_array=$2

    log_debug "解析 AUR 依赖: $pkgname"

    local response
    response=$(curl -s "${AUR_RPC_URL}?v=5&type=info&arg[]=${pkgname}")

    # 检查响应是否有效
    if [[ -z "$response" ]]; then
        log_warn "无法获取 $pkgname 的依赖信息"
        return 0
    fi

    # 检查是否有错误
    if echo "$response" | jq -e 'has("error")' &>/dev/null; then
        log_warn "查询 $pkgname 失败"
        return 0
    fi

    # 检查结果是否存在
    local resultcount
    resultcount=$(echo "$response" | jq -r '.resultcount // 0')
    if [[ "$resultcount" -eq 0 ]]; then
        log_warn "$pkgname 在 AUR 中未找到"
        return 0
    fi

    local deps
    deps=$(echo "$response" | jq -r '.results[0].Depends // [] | .[]' 2>/dev/null)

    local makedeps
    makedeps=$(echo "$response" | jq -r '.results[0].MakeDepends // [] | .[]' 2>/dev/null)

    local all_deps="$deps $makedeps"

    for dep in $all_deps; do
        # 移除版本限制
        dep=$(echo "$dep" | sed 's/[>=<].*$//')

        # 检查是否已安装
        if pacman -Q "$dep" &>/dev/null; then
            log_debug "依赖已安装: $dep"
            continue
        fi

        # 检查是否在官方仓库
        if pacman -Si "$dep" &>/dev/null; then
            log_debug "依赖在官方仓库: $dep"
            deps_array+=("repo:$dep")
            continue
        fi

        # 检查是否在 AUR
        local aur_response
        aur_response=$(curl -s "${AUR_RPC_URL}?v=5&type=info&arg[]=${dep}")

        # 检查响应是否有效
        if [[ -z "$aur_response" ]]; then
            log_debug "无法检查依赖: $dep"
            continue
        fi

        # 检查是否有错误
        if echo "$aur_response" | jq -e 'has("error")' &>/dev/null; then
            log_debug "查询依赖失败: $dep"
            continue
        fi

        local resultcount
        resultcount=$(echo "$aur_response" | jq -r '.resultcount // 0')

        if [[ "$resultcount" -gt 0 ]]; then
            log_debug "依赖在 AUR: $dep"
            deps_array+=("aur:$dep")
            # 递归解析依赖
            aur_resolve_deps "$dep" deps_array
        fi
    done
}

# 构建 AUR 包
aur_build() {
    local pkgdir="$1"
    local install_after_build="${2:-true}"

    log_info "正在构建 AUR 包: $(basename "$pkgdir")"

    # 检查 PKGBUILD
    if [[ ! -f "${pkgdir}/PKGBUILD" ]]; then
        log_error "未找到 PKGBUILD 文件: ${pkgdir}/PKGBUILD"
        return 1
    fi

    # 显示 PKGBUILD 信息
    echo -e "\n${CYAN}PKGBUILD 内容:${NC}\n"
    head -50 "${pkgdir}/PKGBUILD"
    echo ""

    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        read -rp "是否继续构建? [Y/n] " confirm
        [[ "$confirm" =~ ^[Nn]$ ]] && return 1
    fi

    # 安装依赖
    log_info "安装依赖..."
    
    # 获取所有依赖
    local all_deps
    all_deps=$(
        cd "$pkgdir" || exit 1
        source PKGBUILD 2>/dev/null && echo "${depends[@]} ${makedepends[@]}"
    )
    
    for dep in $all_deps; do
        dep=$(echo "$dep" | sed 's/[>=<].*$//')
        if ! pacman -Q "$dep" &>/dev/null; then
            log_info "安装依赖: $dep"
            if ! sudo pacman -S --noconfirm "$dep" 2>/dev/null; then
                # 如果官方仓库没有，尝试 AUR
                log_warn "官方仓库未找到: $dep，尝试 AUR..."
                local aur_check
                aur_check=$(curl -s "${AUR_RPC_URL}?v=5&type=info&arg[]=${dep}")
                local aur_count
                aur_count=$(echo "$aur_check" | jq -r '.resultcount // 0')
                if [[ "$aur_count" -gt 0 ]]; then
                    log_info "从 AUR 安装依赖: $dep"
                    # 递归安装 AUR 依赖
                    aur_install "$dep" || log_warn "无法从 AUR 安装: $dep"
                else
                    log_warn "无法找到依赖: $dep，继续尝试构建..."
                fi
            fi
        fi
    done

    # 构建包
    log_info "开始构建..."
    (
        cd "$pkgdir" || exit 1
        
        if [[ "$ZPM_VERBOSE" == true ]]; then
            if ! makepkg -sf --noconfirm; then
                log_error "构建失败"
                exit 1
            fi
        else
            if ! makepkg -sf --noconfirm 2>&1 | tee "${ZPM_LOGS}/build-$(basename "$pkgdir").log"; then
                log_error "构建失败，查看日志: ${ZPM_LOGS}/build-$(basename "$pkgdir").log"
                exit 1
            fi
        fi

        # 查找构建好的包
        local pkg_file
        pkg_file=$(ls -t ./*.pkg.tar.zst 2>/dev/null | head -1)

        if [[ -z "$pkg_file" ]]; then
            log_error "未找到构建好的包文件"
            exit 1
        fi

        log_info "构建完成: $pkg_file"

        # 安装包
        if [[ "$install_after_build" == true ]]; then
            log_info "正在安装..."
            if ! sudo pacman -U --noconfirm "$pkg_file"; then
                log_error "安装失败"
                exit 1
            fi
            log_info "安装完成"
        fi

        echo "$pkg_file"
    )
}

# 安装 AUR 包
aur_install() {
    local pkgname="$1"

    log_info "准备安装 AUR 包: $pkgname"

    # 检查是否已安装
    if pacman -Q "$pkgname" &>/dev/null; then
        local installed_version
        installed_version=$(pacman -Q "$pkgname" | awk '{print $2}')
        log_info "包 '$pkgname' 已安装 (版本: $installed_version)"

        if [[ "$ZPM_NEEDED" == true ]]; then
            log_info "跳过安装 (--needed)"
            return 0
        fi

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否重新构建? [y/N] " confirm
            [[ "$confirm" =~ ^[Yy]$ ]] || return 0
        fi
    fi

    # 解析依赖
    log_info "解析依赖..."
    local deps=()
    aur_resolve_deps "$pkgname" deps

    if [[ ${#deps[@]} -gt 0 ]]; then
        log_info "需要安装以下依赖:"
        printf '  %s\n' "${deps[@]}"

        if [[ "$ZPM_NOCONFIRM" != true ]]; then
            read -rp "是否继续? [Y/n] " confirm
            [[ "$confirm" =~ ^[Nn]$ ]] && return 1
        fi

        # 安装依赖
        for dep in "${deps[@]}"; do
            local dep_type="${dep%%:*}"
            local dep_name="${dep#*:}"

            if [[ "$dep_type" == "repo" ]]; then
                log_info "从官方仓库安装依赖: $dep_name"
                sudo pacman -S --noconfirm "$dep_name" || log_warn "无法安装依赖: $dep_name"
            elif [[ "$dep_type" == "aur" ]]; then
                log_info "从 AUR 安装依赖: $dep_name"
                aur_install "$dep_name" || log_warn "无法安装 AUR 依赖: $dep_name"
            fi
        done
    fi

    # 下载并构建
    log_info "下载 AUR 包源码..."
    local build_dir
    build_dir=$(aur_download "$pkgname")
    if [[ -z "$build_dir" ]]; then
        log_error "下载失败"
        return 1
    fi

    log_info "构建目录: $build_dir"

    # 构建并安装
    if ! aur_build "$build_dir" true; then
        log_error "构建失败"
        return 1
    fi
    
    log_info "AUR 包 '$pkgname' 安装成功"
}

# 更新所有 AUR 包
aur_update() {
    log_info "检查 AUR 包更新..."

    # 获取所有已安装的 AUR 包
    local aur_packages
    aur_packages=$(pacman -Qm 2>/dev/null)

    if [[ -z "$aur_packages" ]]; then
        log_info "没有安装 AUR 包"
        return 0
    fi

    local updates_available=()

    while IFS= read -r line; do
        local pkgname version
        pkgname=$(echo "$line" | awk '{print $1}')
        version=$(echo "$line" | awk '{print $2}')

        log_debug "检查: $pkgname (当前版本: $version)"

        local response
        response=$(curl -s "${AUR_RPC_URL}?v=5&type=info&arg[]=${pkgname}")

        # 检查响应是否有效
        if [[ -z "$response" ]]; then
            log_warn "无法获取 $pkgname 的信息"
            continue
        fi

        # 检查是否有错误
        if echo "$response" | jq -e 'has("error")' &>/dev/null; then
            local error_msg
            error_msg=$(echo "$response" | jq -r '.error // "未知错误"')
            log_warn "查询 $pkgname 失败: $error_msg"
            continue
        fi

        # 检查结果是否存在
        local resultcount
        resultcount=$(echo "$response" | jq -r '.resultcount // 0')
        if [[ "$resultcount" -eq 0 ]]; then
            log_warn "$pkgname 在 AUR 中未找到"
            continue
        fi

        local aur_version
        aur_version=$(echo "$response" | jq -r '.results[0].Version // empty')

        if [[ -n "$aur_version" && "$aur_version" != "$version" ]]; then
            log_info "发现更新: $pkgname ($version -> $aur_version)"
            updates_available+=("$pkgname")
        fi
    done <<< "$aur_packages"

    if [[ ${#updates_available[@]} -eq 0 ]]; then
        log_info "所有 AUR 包都是最新的"
        return 0
    fi

    log_info "发现 ${#updates_available[@]} 个可更新包"

    if [[ "$ZPM_NOCONFIRM" != true ]]; then
        read -rp "是否更新所有包? [Y/n] " confirm
        [[ "$confirm" =~ ^[Nn]$ ]] && return 0
    fi

    for pkg in "${updates_available[@]}"; do
        aur_install "$pkg"
    done
}

# 列出已安装的 AUR 包
aur_list() {
    log_info "已安装的 AUR 包:"

    local aur_packages
    aur_packages=$(pacman -Qm 2>/dev/null)

    if [[ -z "$aur_packages" ]]; then
        log_info "没有安装 AUR 包"
        return 0
    fi

    echo -e "\n${CYAN}$(printf '%-30s %-15s' '包名' '版本')${NC}"
    echo "$(printf '%-30s %-15s' '------------------------------' '---------------')"

    while IFS= read -r line; do
        local pkgname version
        pkgname=$(echo "$line" | awk '{print $1}')
        version=$(echo "$line" | awk '{print $2}')
        printf '%-30s %-15s\n' "$pkgname" "$version"
    done <<< "$aur_packages"

    echo ""
    log_info "总计: $(echo "$aur_packages" | wc -l) 个包"
}

# 处理 AUR 命令
handle_aur_command() {
    local subcommand="${1:-help}"
    shift || true

    case "$subcommand" in
        search|s)
            aur_search "$1"
            ;;
        info|i)
            aur_info "$1"
            ;;
        install|in)
            aur_install "$1"
            ;;
        update|up)
            aur_update
            ;;
        list|l)
            aur_list
            ;;
        help|h|--help)
            cat << 'EOF'
AUR 命令用法:
    zpm aur search [关键词]     在 AUR 中搜索包
    zpm aur info [包名]         显示 AUR 包详细信息
    zpm aur install [包名]      从 AUR 安装包
    zpm aur update              更新所有 AUR 包
    zpm aur list                列出已安装的 AUR 包

说明:
    AUR (Arch User Repository) 是 Arch Linux 用户社区维护的软件包仓库
    安装 AUR 包需要构建，可能需要较长时间
EOF
            ;;
        *)
            log_error "未知的 AUR 命令: $subcommand"
            handle_aur_command help
            return 1
            ;;
    esac
}
