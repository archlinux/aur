#!/bin/bash
#
# 包搜索模块
# 在多个源中搜索包
#

# 搜索包
search_packages() {
    local query="$1"

    log_info "搜索: $query"

    # 在官方仓库搜索
    echo -e "\n${BOLD}官方仓库结果:${NC}\n"
    pacman -Ss "$query" 2>/dev/null | head -20 || echo "无结果"

    # 在 AUR 搜索
    echo -e "\n${BOLD}AUR 结果:${NC}"
    source "${ZPM_LIB}/sh/aur.sh"
    aur_search "$query"

    # 在 APT 源搜索（如果配置了）
    if [[ -f "${ZPM_CONFIG}/apt.conf" ]]; then
        echo -e "\n${BOLD}APT 源结果:${NC}"
        source "${ZPM_LIB}/sh/apt.sh"
        apt_search "$query" 2>/dev/null || true
    fi
}
