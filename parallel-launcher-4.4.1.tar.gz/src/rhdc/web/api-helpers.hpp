#include <functional>
#include <sstream>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QByteArray>
#include "src/rhdc/web/api.hpp"
#include "src/core/json.hpp"

namespace ApiUtil {
	typedef const QByteArray &(*HttpMethodFactory)(void);
}

namespace HttpMethod {
	extern const ApiUtil::HttpMethodFactory Get;
	extern const ApiUtil::HttpMethodFactory Post;
	extern const ApiUtil::HttpMethodFactory Put;
	extern const ApiUtil::HttpMethodFactory Patch;
	extern const ApiUtil::HttpMethodFactory Delete;
	extern const ApiUtil::HttpMethodFactory Head;
}

namespace ApiUtil {

	struct __Identity {
		string username;
		string userId;
		QByteArray authToken;
	};

	extern QNetworkAccessManager *web();
	extern __Identity &identity() noexcept;

	extern bool isOnline();

	extern string urlEncode( const string &str );

	QNetworkRequest makeRequest( const string &url, bool sendsJson );
	extern int getStatusCode( QNetworkReply *response );
	extern Json readJson( QNetworkReply *response ) noexcept;
	extern void onResponse(
		QNetworkReply *response,
		const std::function<void(void)> &onSuccess,
		const std::function<void(ApiErrorType)> &onFailure
	);

	inline QNetworkReply *send( HttpMethodFactory verb, const string &url ) {
		return web()->sendCustomRequest(
			makeRequest( url, false ),
			verb(),
			QByteArray()
		);
	}

	template<typename T> inline QNetworkReply *send( HttpMethodFactory verb, const string &url, const T &body ) {
		std::ostringstream stream;
		JsonWriter jw( &stream, false );
		JsonSerializer::serialize<T>( jw, body );
		return web()->sendCustomRequest(
			makeRequest( url, true ),
			verb(),
			QByteArray( stream.str().c_str() )
		);
	}

}
