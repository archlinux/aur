#!/usr/bin/ash
#
#  Written for the NinjaOS by the development team.
#  licensed under the GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
#
#                  +Ninja Boot'n'Nuke (nban)+
#  Inspired by Darik's Boot'n'Nuke, but implemented soley as an Arch Linux
#  mkinitcpio script.
#
#  Nban in turn, is the core of the "Ninja Shiruken", with the addition of a
#  syslinux bootloader, is a single use(read self wiping) nban flash drive,
#  which can be quickly spawned by Ninja OS.

# you can test this with mkinitcpio -p nban in ninja os, and then booting with
# initrd=nban.img at the kernel command line. Careful, this will wipe all data
# from all attached storage media.

FILL_SRC=/dev/zero
RAND_SRC=/dev/urandom
pids=""


## As adapted from self destruct.
nuke_dev() {
    # Erase a block device. $1 is the device name, $2 is the type, either disk
    # or flash. This is used for wipe_part_headers() see bellow
    echo "Disk ${1}($(get_size ${1})):		Starting..."
    #wipe the partition headers first. Give us the same results as self destruct
    wipe_part_headers ${1} ${2}
    dd if="${FILL_SRC}" of=${1} bs=128k 2> /dev/null
    fdisk_final ${1}
    sync
    echo "Disk ${1}:			Done"
}

wipe_part_headers() {
    # This script wipes partition headers and the boot sector with random as
    # defined in $RAND_SRC. The $1 is the name of the parent block device. $2
    # is the type of device, either "disk" or "flash". This is done because of
    # a discrepency between how the two name partitions.
    case $2 in
      disk)
        parts="$(ls ${1}? 2> /dev/null)"
        ;;
      flash)
        parts="$(ls ${1}p? 2> /dev/null)"
        ;;
    esac

    for part in $parts;do
        dd if="${RAND_SRC}" bs=128k count=1 of=${part} 2> /dev/null
        sync
    done
    dd if="${RAND_SRC}" bs=512 count=1 of=${BOOTDEV} 2> /dev/null
    sync
}

ssd_secure_erase() {
    # lets get parameters
    local disk=${1}
    local password="p4ssw0rd"
    local rtime=$(hdparm -I ${disk}|grep SECURITY\ ERASE\ UNIT| cut -d \  -f 1)
    local etime=$(hdparm -I ${disk}|grep SECURITY\ ERASE\ UNIT| cut -d \  -f 6)
    local check=$(check_security_wipe ${disk})
    echo "Attemping ATA Secure Erase of ${disk}"
    case $check in
      FROZEN)
        echo "SSD is frozen, not scrubing back-up information, unfreeze, and retry"
        return 1
        ;;
      UNSUPPORTED)
        echo "Secure erase command is not supported!"
        return 1
        ;;
      *)
        # sets a temporary password, which will be overwritten anyway in the wipe
        sudo hdparm --user-master u --security-set-pass "${password}" ${disk}

        # do the wipe
        echo "Using ATA Secure Erase on: ${disk}"
        echo "This should take around ${etime}, be patient"
        hdparm --user-master u --security-erase-enhanced "${password}" ${disk}
        ;;
    esac
}
check_security_wipe(){
    # check if we can wipe the disk. $1 is the disk name. This script returns
    # either "OK", "UNSUPPORTED", or "FROZEN".
    local disk=${1}
    local frozen=$(hdparm -I ${disk} | grep -i "frozen")
    local support=$(hdparm -I ${disk} 2> /dev/null |grep "SECURITY ERASE UNIT")
    if [ "${frozen}" != "	not	frozen" ];then
      echo "FROZEN"
    elif [ "${support}" != "SECURITY ERASE UNIT" ];then
      echo "UNSUPPORTED"
    else
      echo "OK"
    fi
}

get_size() {
    # takes $1 as a block device and returns the size from fdisk.
    dev_size=$(fdisk -l ${1} |head -1 |cut -f 3-4 -d " "|cut -d "," -f 1 )
    if [ "${dev_size}x" = "x" ];then
        echo 0
      else
        echo "${dev_size}"
    fi
}
fdisk_final() {
fdisk ${1} &> /dev/null << EOF
n
p
1


w
EOF
mkfs.vfat ${1}1
}

# Trap escapes, so this cannot be interupted. This really isn't needed as we don't
# have the keyboard drivers in nban anyway
# alternate trap is to reboot on interrupt
trap "echo &> /dev/null" 1 2 9 15 17 19 23
# trap "wait 2;reboot -f" 1 2 9 15 17 19 23

# wait 2 seconds to give all devices time to initialize
sleep 2
# After Disks have been initalized get names of all disks
DISKS="$(ls /dev/sd? 2> /dev/null) $(ls /dev/ses? 2> /dev/null)"
FLASH="$(ls /dev/mmcblk? 2> /dev/null)"
set ${DISKS} ${FLASH}
NUMDEVS=${#}

#tell the user what we are doing.
echo "Found ${NUMDEVS} device(s): ${DISKS} ${FLASH}"
echo " "

#Now scrub the devices, in the background spawning a new shell for every device(work in parallel)
for DEVICE in ${DISKS} ;do
    ( nuke_dev $DEVICE disk ) &
    pids="$pids $!"
done

for DEVICE in ${FLASH};do
    ( nuke_dev $DEVICE flash ) &
    pids="$pids $!"
done

#Wait for all the wipes to be done
wait ${pids}
echo "Complete! Rebooting"
sleep 1

# when we are all done reboot
reboot -f &
#backstop to prevent a return to shell pending reboot.
while true ;do
    sleep 2
done

