
if __name__ == "__main__":
    from .yah3c import main
    main()

