#include "src/ui/core-installer.hpp"

#include <QMessageBox>
#include <QDateTime>
#include <QCoreApplication>
#include <cassert>
#include <thread>
#include "src/polyfill/base-directory.hpp"
#include "src/ui/download-dialog.hpp"
#include "src/ui/core-finder-dialog.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/time.hpp"
#include "src/core/zip.hpp"

static const char *s_unknownCorePathMsg = ""
	"Parallel Launcher cannot determine where to install this emulator core because "
	"the core directory is missing from your RetroArch config file, or a RetroArch "
	"configuration file cannot be found. If you have not yet run RetroArch, you may "
	"need to run it once to force this config file to be created.";


static string installCoreSync( const CoreBuild &coreBuild ) {
	const fs::path tempPath = BaseDir::temp() / "core.zip";
	fs::create_directories( BaseDir::temp() );

	if( !DownloadDialog::download( "Downloading core...", coreBuild.downloadLink, tempPath ) ) {
		QMessageBox::critical( nullptr, "Download Failed", "Failed to download emulator core" );
		return "";
	}

	if( !Zip::unzip( tempPath, RetroArch::getCorePath() ) ) {
		QMessageBox::critical( nullptr, "Installation Failed", "Failed to install emulator core" );
		return "";
	}

	std::error_code err;
	fs::remove( tempPath, err );

	QMessageBox::information( nullptr, "Installation Successful", "Core installed successfully." );
	return coreBuild.commit.hash;
}

bool CoreInstaller::requireCore( EmulatorCore core ) {
	if( core == EmulatorCore::UseDefault ) {
		core = FileController::loadAppSettings().defaultEmulator;
	}

	if( RetroArch::isEmulatorCoreInstalled( core ) ) {
		return true;
	}

	assert( core == EmulatorCore::ParallelN64 || core == EmulatorCore::Mupen64plusNext );

	if( QMessageBox::question( nullptr, "Install Emulator Core?", "This emulator core is not installed. Would you like to install it now?" ) != QMessageBox::Yes ) {
		return false;
	}

	const fs::path corePath = RetroArch::getCorePath();
	if( corePath.empty() ) {
		QMessageBox::critical( nullptr, "Unknown Core Directory", s_unknownCorePathMsg );
		return false;
	}

	CoreFinderDialog coreFinder( core );
	coreFinder.exec();

	const std::optional<CoreBuild> &coreBuild = coreFinder.coreBuild();
	if( coreBuild.has_value() ) {
		return !installCoreSync( coreBuild.value() ).empty();
	}

	return false;
}

static void checkForUpdates(
	const InstalledVersionsInfo &currentVersionInfo,
	EmulatorCore core,
	std::function<void(string)> then
) {
	const string currentCommit = (core == EmulatorCore::ParallelN64) ? currentVersionInfo.parallelVersion.commit : currentVersionInfo.mupenVersion.commit;

	if( !RetroArch::isEmulatorCoreInstalled( core ) ) {
		then( currentCommit );
		return;
	}

	const char *updateMessage;
	string branch;
	if( core == EmulatorCore::ParallelN64 ) {
		if( currentVersionInfo.parallelVersion.lock ) {
			then( currentCommit );
			return;
		}
		updateMessage = "An update is available for ParallelN64. Would you like to install it now?";
		branch = "master";
	} else {
		if( currentVersionInfo.mupenVersion.lock ) {
			then( currentCommit );
			return;
		}
		updateMessage = "An update is available for Mupen64Plus-Next. Would you like to install it now?";
		branch = FileController::loadAppSettings().mupenDevBranch ? "develop" : "master";
	}

	CoreBuilds::getLastKnownGood(
		core,
		branch,
		currentCommit,
		[=](const CoreBuild &build) {
			if( QMessageBox::question( nullptr, "Core Update Available", updateMessage ) == QMessageBox::Yes ) {
				const string commit = installCoreSync( build );
				if( !commit.empty() ) {
					InstalledVersionsInfo versions = FileController::loadInstalledVersions();
					if( core == EmulatorCore::ParallelN64 ) {
						versions.parallelVersion.commit = commit;
					} else {
						versions.mupenVersion.commit = commit;
					}
					FileController::saveInstalledVersions( versions );
					then( commit );
					return;
				}
			}
			then( currentCommit );
		},
		[=](){ then( currentCommit ); }
	);
}

void CoreInstaller::checkForUpdatesAsync() {
	const InstalledVersionsInfo versions = FileController::loadInstalledVersions();
	checkForUpdates(
		versions,
		EmulatorCore::ParallelN64,
		[=](string parallelVersion) {
			QMetaObject::invokeMethod( QCoreApplication::instance(), [=]() {
				checkForUpdates(
					versions,
					EmulatorCore::Mupen64plusNext,
					[=](string mupenVersion){
						InstalledVersionsInfo updatedVersions = versions;
						updatedVersions.parallelVersion.commit = parallelVersion;
						updatedVersions.mupenVersion.commit = mupenVersion;
						updatedVersions.lastUpdateCheck = Time::now();
						FileController::saveInstalledVersions( updatedVersions );
					}
				);
			}, Qt::QueuedConnection );
		}
	);
}

void CoreInstaller::checkForUpdatesSync( InstalledVersionsInfo &versions ) {
	bool done = false;
	checkForUpdates(
		versions,
		EmulatorCore::ParallelN64,
		[&](string commit) {
			versions.parallelVersion.commit = commit;
			QMetaObject::invokeMethod( QCoreApplication::instance(), [&]() {
				checkForUpdates(
					versions,
					EmulatorCore::Mupen64plusNext,
					[&](string commit){
						versions.mupenVersion.commit = commit;
						versions.lastUpdateCheck = Time::now();
						done = true;
					}
				);
			}, Qt::QueuedConnection );
		}
	);

	while( !done ) {
		QCoreApplication::processEvents( QEventLoop::ExcludeUserInputEvents );
		std::this_thread::yield();
	}
}
