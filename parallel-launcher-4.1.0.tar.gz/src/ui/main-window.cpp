#include "src/ui/main-window.hpp"
#include "ui_main-window.h"

#include <QCoreApplication>
#include <QMessageBox>
#include <QCheckBox>
#include <QMenu>
#include "src/ui/icons.hpp"
#include "src/ui/rom-list-model.hpp"
#include "src/ui/rom-source-dialog.hpp"
#include "src/ui/settings-dialog.hpp"
#include "src/ui/controller-select-dialog.hpp"
#include "src/ui/keyboard-config-dialog.hpp"
#include "src/ui/save-file-editor-dialog.hpp"
#include "src/ui/save-slot-editor-dialog.hpp"
#include "src/ui/core-installer.hpp"
#include "src/ui/toast.hpp"
#include "src/ui/play.hpp"
#include "src/ui/flow-layout.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/rom-finder.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/rom.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/bps.hpp"
#include "src/core/version.hpp"
#include "src/core/time.hpp"
#include "src/input/gamepad-controller.hpp"
#include "src/db/data-provider.hpp"
#include "src/rhdc/core/credentials.hpp"
#include "src/rhdc/core/sync.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/rhdc/ui/rhdc-login-dialog.hpp"

MainWindow::MainWindow() :
	QMainWindow( nullptr ),
	m_ui( new Ui::MainWindow ),
	m_showAllPlugins( false ),
	m_settings( FileController::loadAppSettings() ),
	m_exists( new bool( true ) )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );
	ToastMessageManager::setWindow( this );

	m_ui->titleLabel->setText( QString(
		( "Parallel Launcher v"s + CurrentVersion::Application.toString() ).c_str()
	));

	m_ui->pluginAngrylionRadio->setVisible( false );
	m_ui->pluginGlidenRadio->setVisible( false );
	m_ui->pluginRiceRadio->setVisible( false );
	m_ui->pluginWarningLabel->setVisible( false );

	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginParallelRadio, (int)GfxPlugin::ParaLLEl );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlideRadio, (int)GfxPlugin::Glide64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginAngrylionRadio, (int)GfxPlugin::Angrylion );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlidenRadio, (int)GfxPlugin::GlideN64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginRiceRadio, (int)GfxPlugin::Rice );

	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginParallelRadio2, (int)GfxPlugin::ParaLLEl );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginAngrylionRadio2, (int)GfxPlugin::Angrylion );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginGlidenRadio2, (int)GfxPlugin::GlideN64 );

	m_ui->controllerConfigButton->setIcon( Icon::gamepad() );
	m_ui->menuButton->setIcon( Icon::menu() );
	m_ui->refreshButton->setIcon( Icon::refresh() );
	m_ui->playSingleplayerButton->setIcon( Icon::play() );
	m_ui->playMultiplayerButton->setIcon( Icon::group() );

	const UiState uiState = FileController::loadUiState();
	m_ui->romList->refetchAll();
	m_ui->romList->restoreTreeState( uiState.romList );
	m_ui->romView->setCurrentIndex( m_ui->romList->hasRoms() ? 1 : 0 );
		
	m_ui->actionSettings->setIcon( Icon::configure() );
	m_ui->actionManageSources->setIcon( Icon::search() );
	m_ui->actionConfigureControllers->setIcon( Icon::gamepad() );
	m_ui->actionConfigureKeyboard->setIcon( Icon::keyboard() );
	m_ui->rhdcLoginAction->setIcon( Icon::login() );
	m_ui->rhdcLogoutAction->setIcon( Icon::logout() );
	m_ui->rhdcDisableAction->setIcon( Icon::cancel() );

	m_ui->menuButton->addAction( m_ui->actionSettings );
	m_ui->menuButton->addAction( m_ui->actionManageSources );
	m_ui->menuButton->addAction( m_ui->actionConfigureControllers );
	m_ui->menuButton->addAction( m_ui->actionConfigureKeyboard );
	m_ui->menuButton->addAction( m_ui->rhdcLoginAction );
	m_ui->menuButton->addAction( m_ui->rhdcLogoutAction );
	m_ui->menuButton->addAction( m_ui->rhdcDisableAction );

	FlowLayout *checkboxLayout = new FlowLayout( m_ui->checkboxContainer, QSize( 16, 6 ) );
	m_ui->checkboxContainer->setLayout( checkboxLayout );
	checkboxLayout->addWidget( m_ui->overclockCpuCheckbox );
	checkboxLayout->addWidget( m_ui->overclockViCheckbox );
	checkboxLayout->addWidget( m_ui->widescreenCheckbox );
	checkboxLayout->addWidget( m_ui->upscaleTexRectsCheckbox );
	checkboxLayout->addWidget( m_ui->emulateFramebufferCheckbox );
	checkboxLayout->addWidget( m_ui->accurateDepthCompareCheckbox );
	checkboxLayout->setContentsMargins( 6, 0, 6, 0 );

	resize( uiState.windowWidth, uiState.windowHeight );

	if( uiState.showAllPlugins ) {
		morePluginsToggled();
	}

	connect( m_ui->refreshButton, SIGNAL(clicked()), this, SLOT(refreshRomList()) );
	connect( m_ui->romList->selectionModel(), SIGNAL(currentChanged(const QModelIndex&, const QModelIndex&)), this, SLOT(romSelectionChanged()) );
	connect( m_ui->parallelPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(parallelPluginChanged(int,bool)) );
	connect( m_ui->mupenPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(mupenPluginChanged(int,bool)) );
	connect( m_ui->romList, SIGNAL(editSave(fs::path)), this, SLOT(editSave(fs::path)) );
	connect( m_ui->romList, SIGNAL(launchRom()), this, SLOT(playSingleplayer()) );

	reloadSettings();
	romSelectionChanged();

	refreshRomList();
	updateRhdcActions();
	updatePluginSettingVisibility();
}

MainWindow::~MainWindow() {
	m_ui->romList->model()->deleteLater();
	delete m_ui;
}

void MainWindow::reloadSettings() {
	m_settings = FileController::loadAppSettings();

	m_ui->romList->setColumnHidden( 0, false );
	m_ui->romList->setColumnHidden( 1, !Flags::has( m_settings.visibleColumns, RomInfoColumn::InternalName ) );
	m_ui->romList->setColumnHidden( 2, !Flags::has( m_settings.visibleColumns, RomInfoColumn::Path ) );
	m_ui->romList->setColumnHidden( 3, !Flags::has( m_settings.visibleColumns, RomInfoColumn::LastPlayed ) );
	m_ui->romList->setColumnHidden( 4, !Flags::has( m_settings.visibleColumns, RomInfoColumn::PlayTime ) );
}

void MainWindow::refreshRomList() {
	m_romSearch.cancel();
	m_ui->searchIndicator->setVisible( true );
	std::shared_ptr<bool> windowExists = m_exists;
	m_romSearch = RomFinder::scanAsync( [this,windowExists](RomFinder::SearchResults result){
		if( !*windowExists || result == RomFinder::SearchResults::Cancelled ) return;
		if( result == RomFinder::SearchResults::Updated ) {
			this->m_ui->romList->refetchAll();
			this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
		}

		RHDC::sync( [this,windowExists](RHDC::RequiredAction action) {
			this->m_ui->searchIndicator->setVisible( false );
			updateRhdcActions();
			switch( action ) {
				case RHDC::RequiredAction::RefetchAll:
					this->m_ui->romList->refetchAll();
					this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
					break;
				case RHDC::RequiredAction::RefetchRhdc:
					this->m_ui->romList->refetchRhdc();
					break;
				default: break;
			}
		});
	});
}

void MainWindow::romSelectionChanged() {
	const RomInfo *rom = m_ui->romList->tryGetSelectedRom().info;
	const bool romSelected = (rom != nullptr);

	m_ui->overclockCpuCheckbox->setEnabled( romSelected );
	m_ui->overclockViCheckbox->setEnabled( romSelected );
	m_ui->widescreenCheckbox->setEnabled( romSelected );
	m_ui->pluginGroup->setEnabled( romSelected );
	m_ui->mupenPluginGroup->setEnabled( romSelected );
	m_ui->playSingleplayerButton->setEnabled( romSelected );
	m_ui->playMultiplayerButton->setEnabled( romSelected );
	m_ui->inputModeSelect->setEnabled( romSelected );
	m_ui->upscaleTexRectsCheckbox->setEnabled( romSelected );
	m_ui->emulateFramebufferCheckbox->setEnabled( romSelected );
	m_ui->accurateDepthCompareCheckbox->setEnabled( romSelected );

	if( romSelected ) {
		const EmulatorCore emulatorCore = (rom->emulator == EmulatorCore::UseDefault) ? m_settings.defaultEmulator : rom->emulator;
		const GfxPlugin parallelPlugin = (rom->parallelPlugin == GfxPlugin::UseDefault) ? m_settings.defaultParallelPlugin : rom->parallelPlugin;
		const GfxPlugin mupenPlugin = (rom->mupenPlugin == GfxPlugin::UseDefault) ? m_settings.defaultMupenPlugin : rom->mupenPlugin;
		m_ui->overclockCpuCheckbox->setChecked( rom->overclockCPU );
		m_ui->overclockViCheckbox->setChecked( rom->overclockVI );
		m_ui->widescreenCheckbox->setChecked( rom->widescreen );
		m_ui->parallelPluginRadioGroup->button( (int)parallelPlugin )->setChecked( true );
		m_ui->mupenPluginRadioGroup->button( (int)mupenPlugin )->setChecked( true );
		m_ui->emulatorTabs->setCurrentIndex( (int)emulatorCore - 1 );
		m_ui->inputModeSelect->setSelected( rom->inputModeId );
		m_ui->upscaleTexRectsCheckbox->setChecked( rom->parallelTexRectUpscaling );
		m_ui->emulateFramebufferCheckbox->setChecked( rom->glidenFramebufferEmulation );
		m_ui->accurateDepthCompareCheckbox->setChecked( rom->glidenCorrectDepthCompare );

		m_ui->pluginWarningLabel->setVisible(
			emulatorCore == EmulatorCore::ParallelN64 &&
			parallelPlugin == GfxPlugin::GlideN64
		);
	}

	overclockCpuToggled();
	overclockViToggled();
	updatePluginSettingVisibility();
}

void MainWindow::overclockCpuToggled() {
	const bool optimizationsDisabled = m_ui->overclockCpuCheckbox->isEnabled() && !m_ui->overclockCpuCheckbox->isChecked();
	m_ui->performanceWarningLabel->setVisible( optimizationsDisabled );

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockCPU = m_ui->overclockCpuCheckbox->isChecked();
	DataProvider::updateRomCpuOverclocking( romInfo->sha1, romInfo->overclockCPU );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::overclockViToggled() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockVI = m_ui->overclockViCheckbox->isChecked();
	DataProvider::updateRomViOverclocking( romInfo->sha1, romInfo->overclockVI );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::widescreenToggled() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->widescreen = m_ui->widescreenCheckbox->isChecked();
	DataProvider::updateRomWidescreen( romInfo->sha1, romInfo->widescreen );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::parallelPluginChanged( int pluginId, bool checked ) {
	if( !checked ) return;
	const GfxPlugin plugin = (GfxPlugin)pluginId;

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->parallelPlugin == plugin ) return;

	romInfo->parallelPlugin = plugin;
	DataProvider::updateRomParallelPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );

	m_ui->pluginWarningLabel->setVisible( plugin == GfxPlugin::GlideN64 );
	updatePluginSettingVisibility();
}

void MainWindow::mupenPluginChanged( int pluginId, bool checked ) {
	if( !checked ) return;
	const GfxPlugin plugin = (GfxPlugin)pluginId;

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->mupenPlugin == plugin ) return;

	romInfo->mupenPlugin = plugin;
	DataProvider::updateRomMupenPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
	updatePluginSettingVisibility();
}

void MainWindow::inputModeChanged() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->inputModeId = m_ui->inputModeSelect->getSelected().id;
	DataProvider::updateRomInputMode( romInfo->sha1, romInfo->inputModeId );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::emulatorChanged() {
	const EmulatorCore emulator = (EmulatorCore)(m_ui->emulatorTabs->currentIndex() + 1);
	assert( emulator == EmulatorCore::ParallelN64 || emulator == EmulatorCore::Mupen64plusNext );

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->emulator = emulator;
	DataProvider::updateRomEmulator( romInfo->sha1, emulator );
	m_ui->romList->updateRomInfo( *romInfo, false, false );

	m_ui->pluginWarningLabel->setVisible(
		emulator == EmulatorCore::ParallelN64 &&
		m_ui->pluginGlidenRadio->isChecked()
	);
	updatePluginSettingVisibility();
}

void MainWindow::morePluginsToggled() {
	m_showAllPlugins = !m_showAllPlugins;
	m_ui->pluginAngrylionRadio->setVisible( m_showAllPlugins );
	m_ui->pluginGlidenRadio->setVisible( m_showAllPlugins );
	m_ui->pluginRiceRadio->setVisible( m_showAllPlugins );
	m_ui->showMorePluginsLinks->setText( m_showAllPlugins ?
		"<a href=\"#\">Show Fewer Plugins</a>" :
		"<a href=\"#\">Show More Plugins</a>"
	);
}

void MainWindow::play( bool multiplayer ) {
	const RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.info == nullptr ) return;

	const string sha1 = rom.file->sha1;
	const QRect winGeo = geometry();
	hide();

	Game::play(
		*rom.file,
		*rom.info,
		multiplayer,
		[this,sha1,winGeo](int64) {
			this->setGeometry( winGeo );
			this->show();
			QTimer::singleShot( 50, [this,winGeo](){ this->setGeometry( winGeo ); } );
			this->m_ui->romList->refetchAll();
		}
	);
}

void MainWindow::playSingleplayer() {
	play( false );
}

void MainWindow::playMultiplayer() {
	play( true );
}

void MainWindow::configureController() {
	ControllerSelectDialog dialog;
	dialog.exec();
}

void MainWindow::configureKeyboard() {
	KeyboardConfigDialog dialog;
	dialog.exec();
}

void MainWindow::editSettings() {
	SettingsDialog *dialog = new SettingsDialog();
	dialog->exec();
	delete dialog;
	reloadSettings();
	m_ui->romList->refetchAll();
	romSelectionChanged();
}

void MainWindow::manageRomSources() {
	RomSourceDialog *dialog = new RomSourceDialog();
	dialog->exec();
	delete dialog;
	m_ui->romList->refetchAll();
	refreshRomList();
}

void MainWindow::closeEvent( QCloseEvent *event ) {
	const UiState uiState = {
		m_ui->romList->saveTreeState(),
		width(),
		height(),
		m_ui->pluginRiceRadio->isVisible()
	};

	FileController::saveUiState( uiState );
	QMainWindow::closeEvent( event );
	QCoreApplication::quit();
}

void MainWindow::editSave( fs::path saveFilePath ) {
	SaveFileEditorDialog dialog( saveFilePath );
	if( dialog.exec() == QDialog::Accepted ) {
		SaveSlotEditorDialog dialog2( saveFilePath, dialog.getSaveSlot() );
		dialog2.exec();
	}
}

void MainWindow::updateRhdcActions() {
	const bool integrationEnabled = RhdcCredentials::exists() || DataProvider::hasRhdcData();
	const bool loggedIn = RhdcApi::isAuthenticated();

	m_ui->rhdcLoginAction->setText( integrationEnabled ? "Login to romhacking.com" : "Enable romhacking.com integration" );
	m_ui->rhdcLoginAction->setIcon( integrationEnabled ? Icon::login() : Icon::plugin() );
	m_ui->rhdcLoginAction->setVisible( !loggedIn );
	m_ui->rhdcLogoutAction->setVisible( loggedIn );
	m_ui->rhdcDisableAction->setVisible( integrationEnabled );
}

void MainWindow::rhdcLogin() {
	RhdcLoginDialog dialog;
	if( dialog.exec() == QDialog::Accepted ) {
		m_ui->searchIndicator->setVisible( true );
		updateRhdcActions();

		std::shared_ptr<bool> windowExists = m_exists;
		RHDC::sync( [this,windowExists](RHDC::RequiredAction action) {
			if( !*windowExists ) return;
			this->m_ui->searchIndicator->setVisible( false );
			switch( action ) {
				case RHDC::RequiredAction::RefetchAll:
					this->m_ui->romList->refetchAll();
					break;
				case RHDC::RequiredAction::RefetchRhdc:
					this->m_ui->romList->refetchRhdc();
					break;
				default: break;
			}
		});
	}
}

void MainWindow::rhdcLogout() {
	RhdcApi::logout();
	RhdcCredentials::forget();
	updateRhdcActions();
}

void MainWindow::rhdcDisable() {
	if( QMessageBox::question( this, "Confirm Disable", "Are you sure you want to disable romhacking.com integration?" ) == QMessageBox::Yes ) {
		m_romSearch.cancel();
		m_ui->searchIndicator->setVisible( false );
		RhdcApi::logout();
		RhdcCredentials::forget();
		DataProvider::clearAllRhdcData();
		updateRhdcActions();
	}
}

void MainWindow::updatePluginSettingVisibility() {
	m_ui->upscaleTexRectsCheckbox->setVisible(
		( m_ui->emulatorTabs->currentIndex() == 0 && m_ui->parallelPluginRadioGroup->checkedId() == (int)GfxPlugin::ParaLLEl ) ||
		( m_ui->emulatorTabs->currentIndex() == 1 && m_ui->mupenPluginRadioGroup->checkedId() == (int)GfxPlugin::ParaLLEl )
	);

	const bool gliden64 = (
		m_ui->emulatorTabs->currentIndex() == 1 &&
		m_ui->mupenPluginRadioGroup->checkedId() == (int)GfxPlugin::GlideN64
	);

	m_ui->emulateFramebufferCheckbox->setVisible( gliden64 );
	m_ui->accurateDepthCompareCheckbox->setVisible( gliden64 );
}

void MainWindow::upscaleTexRectChanged() {
	RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.info == nullptr ) return;

	DataProvider::setRomParallelTexRectUpscaling( rom.info->sha1, m_ui->upscaleTexRectsCheckbox->isChecked() );
	rom.info->parallelTexRectUpscaling = m_ui->upscaleTexRectsCheckbox->isChecked();
}

void MainWindow::emulateFramebufferChanged() {
	RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.info == nullptr ) return;

	DataProvider::setRomGlidenFrameBufferEmulation( rom.info->sha1, m_ui->emulateFramebufferCheckbox->isChecked() );
	rom.info->glidenFramebufferEmulation = m_ui->emulateFramebufferCheckbox->isChecked();
}

void MainWindow::accurateDepthCompareChanged() {
	RomReference rom = m_ui->romList->tryGetSelectedRom();
	if( rom.info == nullptr ) return;

	DataProvider::setRomGlidenAccurateDepthCompare( rom.info->sha1, m_ui->accurateDepthCompareCheckbox->isChecked() );
	rom.info->glidenCorrectDepthCompare = m_ui->accurateDepthCompareCheckbox->isChecked();
}
