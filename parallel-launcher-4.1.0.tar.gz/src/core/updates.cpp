#include "src/core/updates.hpp"

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QDateTime>
#include <QCoreApplication>
#include <QMetaObject>
#include <sstream>
#include <queue>
#include <cassert>
#include "src/core/file-controller.hpp"
#include "src/core/numeric-string.hpp"
#include "src/core/logging.hpp"
#include "src/core/time.hpp"
#include "src/ui/core-installer.hpp"
#ifdef _WIN32
#include "src/windows-updater/retroarch-updater.hpp"
#else
#include "src/flatpak/flatpak-progress-dialog.hpp"
#endif

#if QT_VERSION >= QT_VERSION_CHECK( 5, 15, 0 )
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::errorOccurred )
#else
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::error )
#endif

const InstalledVersionsInfo InstalledVersionsInfo::Default {
#ifdef _WIN32
	/* retroArchVersion */ RetroArchVersion{ Version{ 0, 0, 0 }, false },
#else
	/* retroArchCommit */ RetroArchVersion{ "", false },
#endif
	/* parallelVersion */ CoreVersion{ "", false },
	/* mupenVersion */ CoreVersion{ "", false },
	/* lastUpdateCheck */ 0
};

static constexpr char P_COMMIT[] = "commit";
static constexpr char P_LOCK[] = "lock";

template<> void JsonSerializer::serialize<CoreVersion>( JsonWriter &jw, const CoreVersion &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_COMMIT, obj.commit );
	jw.writeProperty( P_LOCK, obj.lock );
	jw.writeObjectEnd();
}

template<> CoreVersion JsonSerializer::parse<CoreVersion>( const Json &json ) {
	return CoreVersion {
		json[P_COMMIT].getOrDefault<string>( "" ),
		json[P_LOCK].getOrDefault<bool>( false )
	};
}

#ifdef _WIN32
static constexpr char P_VERSION[] = "version";

template<> void JsonSerializer::serialize<RetroArchVersion>( JsonWriter &jw, const RetroArchVersion &obj ) {
	jw.writeObjectStart();
	jw.writePropertyName( P_VERSION );
	serialize( jw, obj.version );
	jw.writeProperty( P_LOCK, obj.lock );
	jw.writeObjectEnd();
}

template<> RetroArchVersion JsonSerializer::parse<RetroArchVersion>( const Json &json ) {
	Version version = Version{ 0, 0, 0 };
	if( json[P_VERSION].exists() ) {
		version = parse<Version>( json[P_VERSION] );
	}

	return RetroArchVersion {
		version,
		json[P_LOCK].getOrDefault<bool>( false )
	};
}
#endif

static constexpr char P_RETROARCH[] = "retroarch";
static constexpr char P_PARALLEL[] = "parallel";
static constexpr char P_MUPEN[] = "mupen";
static constexpr char P_LAST_CHECKED[] = "last_checked";

template<> void JsonSerializer::serialize<InstalledVersionsInfo>( JsonWriter &jw, const InstalledVersionsInfo &obj ) {
	jw.writeObjectStart();
	jw.writePropertyName( P_RETROARCH );
	serialize( jw, obj.retroArchVersion );
	jw.writePropertyName( P_PARALLEL );
	serialize( jw, obj.parallelVersion );
	jw.writePropertyName( P_MUPEN );
	serialize( jw, obj.mupenVersion );
	jw.writeProperty( P_LAST_CHECKED, obj.lastUpdateCheck );
	jw.writeObjectEnd();
}

template<> InstalledVersionsInfo JsonSerializer::parse<InstalledVersionsInfo>( const Json &json ) {
	return InstalledVersionsInfo {
		parse<RetroArchVersion>( json[P_RETROARCH] ),
		parse<CoreVersion>( json[P_PARALLEL] ),
		parse<CoreVersion>( json[P_MUPEN] ),
		json[P_LAST_CHECKED].get<int64>()
	};
}

static void headAsync(
	QNetworkAccessManager *web,
	const string &url,
	const std::function<void(void)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	QNetworkReply *response = web->head( QNetworkRequest( QUrl( url.c_str() ) ) );
	logDebug( "HEAD "s + url );

	QObject::connect( response, ON_NETWORK_ERROR, web, [=](QNetworkReply::NetworkError error) {
		(void)error;
		response->deleteLater();
		onFailure();
	}, Qt::QueuedConnection );

	QObject::connect( response, &QNetworkReply::finished, web, [=](){
		if( response->error() != QNetworkReply::NoError ) return;
		bool hasStatusCode = false;
		const int statusCode = response->attribute( QNetworkRequest::HttpStatusCodeAttribute ).toInt( &hasStatusCode );
		response->deleteLater();

		if( hasStatusCode && statusCode == 200 ) {
			onSuccess();
		} else {
			onFailure();
		}
	}, Qt::QueuedConnection );
}

static void getAsync(
	QNetworkAccessManager *web,
	const string &url,
	const std::function<void(const Json&)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	QNetworkReply *response = web->get( QNetworkRequest( QUrl( url.c_str() ) ) );
	logDebug( "GET "s + url );

	QObject::connect( response, ON_NETWORK_ERROR, web, [=](QNetworkReply::NetworkError error) {
		(void)error;
		response->deleteLater();
		onFailure();
	}, Qt::QueuedConnection );

	QObject::connect( response, &QNetworkReply::finished, web, [=](){
		if( response->error() != QNetworkReply::NoError ) return;
		const string responseBody = response->readAll().toStdString();
		response->deleteLater();

		std::stringstream jsonStream( responseBody );
		Json jsonBody;
		try {
			jsonBody = Json::parse( jsonStream );
		} catch( ... ) {
			onFailure();
			return;
		}

		onSuccess( jsonBody );
	}, Qt::QueuedConnection );
}

static inline const string &getBaseUrl( EmulatorCore core ) {
	assert( core == EmulatorCore::ParallelN64 || core == EmulatorCore::Mupen64plusNext );

	static const string parallelBase = "https://git.libretro.com/api/v4/projects/114/";
	static const string mupenBase = "https://git.libretro.com/api/v4/projects/8/";

	return (core == EmulatorCore::ParallelN64) ? parallelBase : mupenBase;
}

#ifdef _WIN32
	#ifdef _WIN64
		static const string PARALLEL_BUILD_NAME = "libretro-build-windows-x64";
		static const string MUPEN_BUILD_NAME = "libretro-build-windows-x64-mingw";
	#else
		static const string PARALLEL_BUILD_NAME = "libretro-build-windows-i686";
		static const string MUPEN_BUILD_NAME = "libretro-build-windows-i686-mingw";
	#endif
#else
	#ifdef _LP64
		static const string PARALLEL_BUILD_NAME = "libretro-build-linux-x64";
		static const string MUPEN_BUILD_NAME = "libretro-build-linux-x64";
	#else
		static const string PARALLEL_BUILD_NAME = "libretro-build-linux-i686";
		static const string MUPEN_BUILD_NAME = "libretro-build-linux-i686";
	#endif
#endif

static void getBuildFromAnyPipelineAsync(
	QNetworkAccessManager *web,
	const string &baseUrl,
	const string &buildName,
	std::queue<int> *pipelines,
	const std::function<void(const string&)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	if( pipelines->empty() ) {
		delete pipelines;
		onFailure();
		return;
	}

	getAsync(
		web,
		baseUrl + "pipelines/"s + Number::toString( pipelines->front() ) + "/jobs",
		[=](const Json &body) {
			try {
				for( const Json &job : body.array() ) {
					if( job["name"].get<string>() == buildName ) {
						const int jobId = job["id"].get<int>();
						const string downloadLink = baseUrl + "jobs/"s + Number::toString( jobId ) + "/artifacts";
						headAsync(
							web,
							downloadLink,
							[=]() {
								delete pipelines;
								onSuccess( downloadLink );
							},
							[=]() {
								pipelines->pop();
								getBuildFromAnyPipelineAsync( web, baseUrl, buildName, pipelines, onSuccess, onFailure );
							}
						);
						return;
					}
				}

				pipelines->pop();
				getBuildFromAnyPipelineAsync( web, baseUrl, buildName, pipelines, onSuccess, onFailure );
			} catch( ... ) {
				pipelines->pop();
				getBuildFromAnyPipelineAsync( web, baseUrl, buildName, pipelines, onSuccess, onFailure );
			}
		},
		[=]() {
			pipelines->pop();
			getBuildFromAnyPipelineAsync( web, baseUrl, buildName, pipelines, onSuccess, onFailure );
		}
	);
}

static void getDownloadLink(
	QNetworkAccessManager *web,
	const string &baseUrl,
	const string &commitHash,
	const string &targetBuildName,
	const std::function<void(const string&)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	getAsync(
		web,
		baseUrl + "pipelines?scope=finished&status=success&sha="s + commitHash,
		[=](const Json &body) {
			try {
				std::queue<int> *builds = new std::queue<int>();
				for( const Json &buildJson : body.array() ) {
					builds->push( buildJson["id"].get<int>() );
				}
				getBuildFromAnyPipelineAsync( web, baseUrl, targetBuildName, builds, onSuccess, onFailure );
			} catch( ... ) {
				onFailure();
			}
		},
		onFailure
	);
}

static void getLKG(
	QNetworkAccessManager *web,
	const string &baseUrl,
	std::queue<CommitInfo> *commits,
	const string &targetBuildName,
	const std::function<void(const CoreBuild&)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	if( commits->empty() ) {
		onFailure();
		return;
	}

	getDownloadLink(
		web,
		baseUrl,
		commits->front().hash,
		targetBuildName,
		[=](const string &downloadLink) {
			onSuccess({
				std::move( commits->front() ),
				downloadLink
			});
		},
		[=]() {
			commits->pop();
			getLKG( web, baseUrl, commits, targetBuildName, onSuccess, onFailure );
		}
	);
}

void CoreBuilds::getLastKnownGood(
	EmulatorCore core,
	const string &branch,
	const string &laterThan,
	const std::function<void(const CoreBuild&)> &onSuccess,
	const std::function<void(void)> &onFailure
) {
	const string &baseUrl = getBaseUrl( core );
	const string &targetBuildName = (core == EmulatorCore::ParallelN64) ? PARALLEL_BUILD_NAME : MUPEN_BUILD_NAME;

	QNetworkAccessManager *web = new QNetworkAccessManager();
	getAsync(
		web,
		baseUrl + "repository/commits?ref_name="s + branch + "&first_parent=1",
		[=](const Json &body) {
			std::queue<CommitInfo> *commits = new std::queue<CommitInfo>();
			try {
				for( const Json &json : body.array() ) {
					string commitHash = json["id"].get<string>();
					if( commitHash == laterThan ) break;
					commits->push({
						std::move( commitHash ),
						json["title"].get<string>(),
						json["created_at"].get<string>()
					});
				}
			} catch( ... ) {
				web->deleteLater();
				onFailure();
			}

			getLKG(
				web,
				baseUrl,
				commits,
				targetBuildName,
				[=](const CoreBuild &lkg) {
					delete commits;
					web->deleteLater();
					onSuccess( lkg );
				},
				[=]() {
					delete commits;
					web->deleteLater();
					onFailure();
				}
			);
		},
		[=]() {
			web->deleteLater();
			onFailure();
		}
	);
}

static inline bool checkSchedule(
	const InstalledVersionsInfo &installedVersions
) {
	const QDate now = QDateTime::currentDateTime().date();
	const QDate lastUpdate = QDateTime::fromSecsSinceEpoch( installedVersions.lastUpdateCheck ).date();

	if( now.year() != lastUpdate.year() ) {
		return true;
	}

	switch( FileController::loadAppSettings().coreUpdateInterval ) {
		case CoreUpdateInterval::EveryLaunch:
			return true;
		case CoreUpdateInterval::Daily:
			return now.dayOfYear() != lastUpdate.dayOfYear();
		case CoreUpdateInterval::Weekly:
			return now.weekNumber() != lastUpdate.weekNumber();
		case CoreUpdateInterval::Monthly:
			return now.month() != lastUpdate.month();
		default:
			return false;
	}
}

#ifdef _WIN32
void RetroUpdater::checkForUpdates(
	bool waitForCoreUpdates,
	[[maybe_unused]] bool forceRuntimeUpdate,
	bool forceUpdate
) {
	InstalledVersionsInfo installedVersions = FileController::loadInstalledVersions();
	if( forceUpdate || checkSchedule( installedVersions ) ) {
		if( !installedVersions.retroArchVersion.lock ) {
			WindowsRetroArchUpdater::update();
		}

		if( waitForCoreUpdates ) {
			CoreInstaller::checkForUpdatesSync( installedVersions );
			FileController::saveInstalledVersions( installedVersions );
		} else {
			CoreInstaller::checkForUpdatesAsync();
		}
	}
}
#else
void RetroUpdater::checkForUpdates(
	bool waitForCoreUpdates,
	bool forceRuntimeUpdate,
	bool forceUpdate
) {
	InstalledVersionsInfo installedVersions = FileController::loadInstalledVersions();
	if( forceUpdate || checkSchedule( installedVersions ) ) {
		if( !installedVersions.retroArchVersion.lock ) {
			FlatpakProgressDialog::run(
				Flatpak::updateAll,
				"Updating RetroArch",
				"Checking for RetroArch updates",
				"RetroArch updated successfully.",
				"Failed to update RetroArch.",
				"An update for RetroArch is available. Would you like to install it now?"
			);
		}

		if( waitForCoreUpdates ) {
			CoreInstaller::checkForUpdatesSync( installedVersions );
			FileController::saveInstalledVersions( installedVersions );
		} else {
			CoreInstaller::checkForUpdatesAsync();
		}
	} else if( forceRuntimeUpdate ) {
		FlatpakProgressDialog::run(
			Flatpak::updateRuntimes,
			"Updating Runtimes",
			"Checking for runtime updates",
			"Flatpak runtimes updated successfully.",
			"Failed to update Flatpak runtimes."
		);
	}
}
#endif
