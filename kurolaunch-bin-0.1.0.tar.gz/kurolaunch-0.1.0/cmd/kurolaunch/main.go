package main

import (
	"log"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/kiroku67/kurolaunch/internal/tui"
)

func main() {
	p := tea.NewProgram(tui.NewInitModel(), tea.WithAltScreen())
	if _, err := p.Run(); err != nil {
		log.Fatal(err)
	}
}
