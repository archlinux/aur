package tui

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type GenerateInput struct {
	ProductName  string
	RepoOwner    string
	RepoName     string
	HostRepo     string
	TemplateRepo string
}

type errMsg struct{ err error }

func (e errMsg) Error() string { return e.err.Error() }

type doneMsg struct{}

func runGenerate(in GenerateInput) error {
	tmpDir, err := os.MkdirTemp("", "kurolaunch-*")
	if err != nil {
		return fmt.Errorf("create temp dir: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	if err := runCmd("git", "clone",
		fmt.Sprintf("https://github.com/%s.git", in.TemplateRepo),
		filepath.Join(tmpDir, "launcher"),
	); err != nil {
		return fmt.Errorf("clone template: %w", err)
	}

	vars := map[string]string{
		"{{PRODUCT_NAME}}":       in.ProductName,
		"{{PRODUCT_NAME_LOWER}}": strings.ToLower(in.ProductName),
		"{{REPO_OWNER}}":         in.RepoOwner,
		"{{REPO_NAME}}":          in.RepoName,
		"{{HOST_REPO}}":          in.HostRepo,
	}

	root := filepath.Join(tmpDir, "launcher")
	if err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			return nil
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		content := string(data)
		for k, v := range vars {
			content = strings.ReplaceAll(content, k, v)
		}
		return os.WriteFile(path, []byte(content), info.Mode())
	}); err != nil {
		return fmt.Errorf("replace vars: %w", err)
	}

	outputDir := in.ProductName + "-launcher"
	if err := runCmd("mv", filepath.Join(tmpDir, "launcher"), filepath.Join(tmpDir, outputDir)); err != nil {
		return fmt.Errorf("rename output: %w", err)
	}

	fmt.Printf("\nProject created at: %s/%s\n", tmpDir, outputDir)
	fmt.Println("Next steps:")
	fmt.Printf("  cd %s/%s\n", tmpDir, outputDir)
	fmt.Println("  git init && git add . && git commit -m 'init: launcher project'")
	fmt.Printf("  gh repo create %s/%s --private --source . --push\n", in.RepoOwner, in.RepoName)
	fmt.Printf("  gh repo create %s/%s --private --source host --push\n", in.RepoOwner, in.HostRepo)

	return nil
}

func runCmd(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}
