package tui

import (
	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type step int

const (
	stepProductName step = iota
	stepRepoOwner
	stepRepoName
	stepHostRepo
	stepTemplateRepo
	stepConfirm
	stepDone
)

type InitModel struct {
	step           step
	inputs         []textinput.Model
	err            error
	width, height  int
	status         string
	done           bool
}

func NewInitModel() *InitModel {
	m := &InitModel{
		step:   stepProductName,
		inputs: make([]textinput.Model, 5),
	}
	for i := range m.inputs {
		ti := textinput.New()
		ti.CharLimit = 64
		m.inputs[i] = ti
	}
	m.inputs[0].Placeholder = "My Amazing Launcher"
	m.inputs[0].Focus()
	m.inputs[1].Placeholder = "kiroku67"
	m.inputs[2].Placeholder = "my-amazing-launcher"
	m.inputs[3].Placeholder = "my-amazing-launcher-dist"
	m.inputs[4].Placeholder = "kiroku67/launcher-base"
	m.inputs[4].SetValue("kiroku67/launcher-base")
	return m
}

func (m *InitModel) Init() tea.Cmd {
	return textinput.Blink
}

func (m *InitModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if m.done {
		return m, tea.Quit
	}

	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
	case tea.KeyMsg:
		switch msg.String() {
		case "ctrl+c", "esc":
			return m, tea.Quit
		case "enter":
			return m, m.advanceStep()
		case "tab", "shift+tab", "up", "down":
			if m.step == stepConfirm || m.step == stepDone {
				return m, nil
			}
			return m, m.navigateInput(msg.String())
		}
	}

	cmd := m.updateCurrentInput(msg)
	return m, cmd
}

func (m *InitModel) advanceStep() tea.Cmd {
	switch m.step {
	case stepProductName:
		if m.inputs[0].Value() == "" {
			return nil
		}
		m.step++
		m.inputs[1].Focus()
	case stepRepoOwner:
		if m.inputs[1].Value() == "" {
			return nil
		}
		m.step++
		m.inputs[2].Focus()
	case stepRepoName:
		if m.inputs[2].Value() == "" {
			return nil
		}
		m.step++
		m.inputs[3].Focus()
	case stepHostRepo:
		if m.inputs[3].Value() == "" {
			return nil
		}
		m.step++
		m.inputs[4].Focus()
	case stepTemplateRepo:
		if m.inputs[4].Value() == "" {
			return nil
		}
		m.step = stepConfirm
		return m.generate()
	case stepConfirm:
		return tea.Quit
	}
	return nil
}

func (m *InitModel) navigateInput(key string) tea.Cmd {
	inputs := []step{stepProductName, stepRepoOwner, stepRepoName, stepHostRepo, stepTemplateRepo}
	curIdx := -1
	for i, s := range inputs {
		if s == m.step {
			curIdx = i
			break
		}
	}
	if curIdx < 0 {
		return nil
	}
	switch key {
	case "up", "shift+tab":
		curIdx = (curIdx - 1 + len(inputs)) % len(inputs)
	case "down", "tab":
		curIdx = (curIdx + 1) % len(inputs)
	}
	for i := range m.inputs {
		m.inputs[i].Blur()
	}
	m.inputs[curIdx].Focus()
	m.step = inputs[curIdx]
	return nil
}

func (m *InitModel) updateCurrentInput(msg tea.Msg) tea.Cmd {
	var cmd tea.Cmd
	switch m.step {
	case stepProductName:
		m.inputs[0], cmd = m.inputs[0].Update(msg)
	case stepRepoOwner:
		m.inputs[1], cmd = m.inputs[1].Update(msg)
	case stepRepoName:
		m.inputs[2], cmd = m.inputs[2].Update(msg)
	case stepHostRepo:
		m.inputs[3], cmd = m.inputs[3].Update(msg)
	case stepTemplateRepo:
		m.inputs[4], cmd = m.inputs[4].Update(msg)
	}
	return cmd
}

func (m *InitModel) generate() tea.Cmd {
	return func() tea.Msg {
		err := runGenerate(GenerateInput{
			ProductName:  m.inputs[0].Value(),
			RepoOwner:    m.inputs[1].Value(),
			RepoName:     m.inputs[2].Value(),
			HostRepo:     m.inputs[3].Value(),
			TemplateRepo: m.inputs[4].Value(),
		})
		if err != nil {
			return errMsg{err: err}
		}
		return doneMsg{}
	}
}

func (m *InitModel) View() string {
	if m.done {
		return lipgloss.NewStyle().Padding(1).Render(m.status)
	}
	return m.renderForm()
}

func (m *InitModel) renderForm() string {
	var s string
	title := lipgloss.NewStyle().
		Bold(true).
		Padding(0, 1).
		Render("KuroLauncher Generator")

	s += title + "\n\n"

	labels := []struct {
		label, desc string
	}{
		{"Product Name", "Name of your launcher (e.g. MyServer Launcher)"},
		{"Repo Owner", "GitHub owner for the launcher repo"},
		{"Repo Name", "GitHub repo name for the launcher itself"},
		{"Host Repo", "GitHub repo name for distribution hosting"},
		{"Template Repo", "Source template (org/repo)"},
	}

	for i, ti := range m.inputs {
		prefix := "  "
		if step(i) == m.step {
			prefix = "> "
		}
		s += prefix + lipgloss.NewStyle().Bold(true).Render(labels[i].label) + "\n"
		s += "  " + labels[i].desc + "\n"
		s += "  " + ti.View() + "\n\n"
	}

	if m.err != nil {
		s += lipgloss.NewStyle().Foreground(lipgloss.Color("9")).Render("Error: "+m.err.Error()) + "\n"
	}

	s += lipgloss.NewStyle().Faint(true).Render("tab/up/down: navigate  enter: next  esc: quit")
	return s
}
