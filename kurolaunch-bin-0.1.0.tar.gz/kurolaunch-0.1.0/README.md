# KuroLauncher

CLI generator for scaffolding Minecraft Helios Launcher projects.

## Install

### AUR (Arch Linux)

yay -S kurolaunch-bin

### Manual

go install github.com/kiroku67/kurolaunch/cmd/kurolaunch@latest

## Usage

kurolaunch
