// -----------------------------------------------------------------------------
// hidtcl.c
//
// Tcl extension that wraps hidapi for use from Tcl/Tk.
//
// Each function follows the Tcl_ObjCmdProc signature and returns TCL_OK
// or TCL_ERROR, setting an appropriate Tcl result.
//
// -----------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <stdint.h>
#include <tcl.h>
#include "hidapi.h"

#ifdef _WIN32
#include <windows.h>
#endif

// =============================================================================
// Conversion between UTF-8 and wchar_t
// Becomes obsolete when switching to Tcl 9
// =============================================================================

// -----------------------------------------------------------------------------
// Convert UTF-8 to wchar_t*
//
// Returns a newly allocated wide string.
// The caller MUST free the result using free().
// Returns NULL on error or memory failure.
// -----------------------------------------------------------------------------

static wchar_t *Hid_Utf8ToWide(const char *utf8Str) {
    if (!utf8Str) return NULL;

    wchar_t *wideStr = NULL;

#ifdef _WIN32
    // --- Windows Implementation (UTF-8 -> UTF-16) ---
    int num_chars = MultiByteToWideChar(CP_UTF8, 0, utf8Str, -1, NULL, 0);
    if (num_chars > 0) {
        wideStr = (wchar_t *)malloc(num_chars * sizeof(wchar_t));
        if (wideStr) {
            MultiByteToWideChar(CP_UTF8, 0, utf8Str, -1, wideStr, num_chars);
        }
    }
#else
    // --- POSIX Implementation (UTF-8 -> wchar_t/UTF-32) ---
    // Note: Depends on setlocale(LC_CTYPE, "") being set correctly in the app.
    size_t len = mbstowcs(NULL, utf8Str, 0);
    if (len != (size_t)-1) {
        wideStr = (wchar_t *)malloc((len + 1) * sizeof(wchar_t));
        if (wideStr) {
            mbstowcs(wideStr, utf8Str, len + 1);
        }
    }
#endif

    return wideStr;
}

// -----------------------------------------------------------------------------
// Helper: Convert wchar_t* to UTF-8
//
// Returns a newly allocated char string.
// The caller MUST free the result using free().
// Returns NULL on error or memory failure.
// -----------------------------------------------------------------------------
static char *Hid_WideToUtf8(const wchar_t *wideStr) {
    if (!wideStr) return NULL;

    char *utf8Str = NULL;

#ifdef _WIN32
    // --- Windows Implementation (UTF-16 -> UTF-8) ---
    int bufSize = WideCharToMultiByte(CP_UTF8, 0, wideStr, -1, NULL, 0, NULL, NULL);
    if (bufSize > 0) {
        utf8Str = (char *)malloc(bufSize);
        if (utf8Str) {
            WideCharToMultiByte(CP_UTF8, 0, wideStr, -1, utf8Str, bufSize, NULL, NULL);
        }
    }
#else
    // --- POSIX Implementation (wchar_t -> UTF-8) ---
    size_t len = wcstombs(NULL, wideStr, 0);
    if (len != (size_t)-1) {
        utf8Str = (char *)malloc(len + 1);
        if (utf8Str) {
            wcstombs(utf8Str, wideStr, len + 1);
        }
    }
#endif

    return utf8Str;
}

// =============================================================================
//
// DeviceID management
//
// =============================================================================

// -----------------------------------------------------------------------------
// Structure for managing deviceIDs.
// “initialised” prevents multiple initialisation.
// -----------------------------------------------------------------------------
typedef struct {
    int initialized;
    int counter;          // Für hid1, hid2, ...
    Tcl_HashTable table;  // Mapping: String -> hid_device*
} HidManager;

// Struct for each handle entry in the hash table
typedef struct {
    hid_device *dev;
    int refCount;    // Counter how often this pointer is currently used
} DeviceData;

static HidManager hidMgr = {0, 0};

// Mutex for thread safety when accessing the global hash table
TCL_DECLARE_MUTEX(hidtclMutex)

// -----------------------------------------------------------------------------
// Exit Handler
// Called when the Tcl interpreter or process terminates.
// Closes all open devices to prevent resource leaks.
// -----------------------------------------------------------------------------
static void Hid_ExitHandler(ClientData clientData) {
    (void)clientData;

    Tcl_MutexLock(&hidtclMutex);

    if (hidMgr.initialized) {
        Tcl_HashEntry *entryPtr;
        Tcl_HashSearch search;

        for (entryPtr = Tcl_FirstHashEntry(&hidMgr.table, &search);
             entryPtr != NULL;
             entryPtr = Tcl_NextHashEntry(&search)) {

            DeviceData *deviceData = (DeviceData *)Tcl_GetHashValue(entryPtr);
            // === HIDAPI call ===
            if (deviceData) { hid_close(deviceData->dev); }
        }

        Tcl_DeleteHashTable(&hidMgr.table);
        hidMgr.initialized = 0;
    }

    Tcl_MutexUnlock(&hidtclMutex);
}

// -----------------------------------------------------------------------------
//  Initilisation
//  Is called in Hidtcl_Init
// -----------------------------------------------------------------------------
static void Hid_InitManager(void) {
    Tcl_MutexLock(&hidtclMutex);

    if (!hidMgr.initialized) {
        // === HIDAPI call ===
        hid_init();

        Tcl_InitHashTable(&hidMgr.table, TCL_STRING_KEYS);
        hidMgr.counter = 1;

        // Register the exit handler that will empty the handle table
        Tcl_CreateExitHandler(Hid_ExitHandler, NULL);

        hidMgr.initialized = 1;
    }

    Tcl_MutexUnlock(&hidtclMutex);
}

// -----------------------------------------------------------------------------
//  Register a new deviceID
// -----------------------------------------------------------------------------
static void Hid_RegisterDevice(hid_device *dev, char *deviceID) {

    DeviceData *deviceData = (DeviceData *)malloc(sizeof(DeviceData));
    if (!deviceData) {
      deviceID = "";
      return;
    }

    deviceData->dev = dev;
    deviceData->refCount = 1;

    Tcl_MutexLock(&hidtclMutex);

    // Generate unique handle names: hid1, hid2, etc.
    sprintf(deviceID, "hid%d", hidMgr.counter++);

    int newEntry;
    Tcl_HashEntry *entryPtr = Tcl_CreateHashEntry(&hidMgr.table, deviceID, &newEntry);
    Tcl_SetHashValue(entryPtr, deviceData);

    Tcl_MutexUnlock(&hidtclMutex);
}


// -----------------------------------------------------------------------------
//  Get device pointer for a deviceID
// -----------------------------------------------------------------------------
static hid_device *Hid_GetDevice(const char *deviceID) {
    hid_device *dev = NULL;

    Tcl_MutexLock(&hidtclMutex);

    if (hidMgr.initialized) {
        Tcl_HashEntry *entryPtr = Tcl_FindHashEntry(&hidMgr.table, deviceID);
        if (entryPtr) {
            DeviceData *deviceData = (DeviceData *)Tcl_GetHashValue(entryPtr);
            if (deviceData) {
                deviceData->refCount++;
                dev = deviceData->dev;
            }
        }
    }

    Tcl_MutexUnlock(&hidtclMutex);

    return dev;
}

// -----------------------------------------------------------------------------
//  Delete a deviceID and close the device if no further reference
// -----------------------------------------------------------------------------
static int Hid_UnrefDevice(const char *deviceID)
{
    int found = 0;

    Tcl_MutexLock(&hidtclMutex);

    if (hidMgr.initialized) {
        Tcl_HashEntry *entryPtr = Tcl_FindHashEntry(&hidMgr.table, deviceID);
        if (entryPtr) {
            found = 1;
            DeviceData *deviceData = (DeviceData *)Tcl_GetHashValue(entryPtr);
            deviceData->refCount--;
            if (deviceData->refCount <= 0) {
                if (deviceData->dev) { hid_close(deviceData->dev); }
                free(deviceData);
                Tcl_DeleteHashEntry(entryPtr);
            }
        }
    }

    Tcl_MutexUnlock(&hidtclMutex);

    return found;
}

// =============================================================================
//
// hidtcl API functions
//
// =============================================================================

// -----------------------------------------------------------------------------
//  ::hidtcl::init
// -----------------------------------------------------------------------------
static int Hid_InitCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 1) {
        Tcl_WrongNumArgs(interp, 1, objv, "");
        return TCL_ERROR;
    }

    // Initialise the handle manager which initialises the hidapi lib
    Hid_InitManager();

    Tcl_SetObjResult(interp, Tcl_NewStringObj("HIDAPI initialised", -1));
    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::exit
// -----------------------------------------------------------------------------
static int Hid_ExitCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 1) {
        Tcl_WrongNumArgs(interp, 1, objv, "");
        return TCL_ERROR;
    }

    // Lock mutex to prevent race conditions with operations in other threads
    Tcl_MutexLock(&hidtclMutex);

    if (hidMgr.initialized) {
        Tcl_HashEntry *entryPtr;
        Tcl_HashSearch search;

        // Close all entries in the hash map before calling hid_exit()
        for (entryPtr = Tcl_FirstHashEntry(&hidMgr.table, &search);
             entryPtr != NULL;
             entryPtr = Tcl_NextHashEntry(&search)) {

            DeviceData *deviceData = (DeviceData *)Tcl_GetHashValue(entryPtr);
            // === HIDAPI call ===
            if (deviceData) { hid_close(deviceData->dev); }
        }
        Tcl_DeleteHashTable(&hidMgr.table);

        // === HIDAPI call ===
        hid_exit();

        // De-register exit handler and reset handle manager
        Tcl_DeleteExitHandler(Hid_ExitHandler, NULL);
        hidMgr.initialized = 0;
        hidMgr.counter = 1;

        Tcl_MutexUnlock(&hidtclMutex);
        Tcl_SetObjResult(interp, Tcl_NewStringObj("HIDAPI exited", -1));
    } else {
        Tcl_MutexUnlock(&hidtclMutex);
        Tcl_SetObjResult(interp, Tcl_NewStringObj("HIDAPI was not initialised", -1));
    }

    return TCL_OK;
}

// -----------------------------------------------------------------------------
// ::hidtcl::enumerate vendor_Id product_Id
// -----------------------------------------------------------------------------
static int Hid_EnumerateCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    // Ensure the handle manager is initialized
    Hid_InitManager();

    if (objc != 3) {
        Tcl_WrongNumArgs(interp, 1, objv, "vendor_id product_id");
        return TCL_ERROR;
    }

    int vendorId, productId;
    if (Tcl_GetIntFromObj(interp, objv[1], &vendorId) != TCL_OK) return TCL_ERROR;
    if (Tcl_GetIntFromObj(interp, objv[2], &productId) != TCL_OK) return TCL_ERROR;

    if (vendorId < 0 || vendorId > 0xFFFF) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("vendor_ID out of range [0, 65535]", -1));
        return TCL_ERROR;
    }
    if (productId < 0 || productId > 0xFFFF) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("product_ID out of range [0, 65535]", -1));
        return TCL_ERROR;
    }

    // === HIDAPI call ===
    struct hid_device_info *devs = hid_enumerate((unsigned short)vendorId, (unsigned short)productId);
    struct hid_device_info *cur = devs;
    Tcl_Obj *listObj = Tcl_NewListObj(0, NULL);

    while (cur) {
        Tcl_Obj *dict = Tcl_NewDictObj();
        char *strattr = NULL;

        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("path", -1), Tcl_NewStringObj(cur->path ? cur->path : "", -1));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("vendor_id", -1), Tcl_NewIntObj(cur->vendor_id));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("product_id", -1), Tcl_NewIntObj(cur->product_id));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("release_number", -1), Tcl_NewIntObj(cur->release_number));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("usage_page", -1), Tcl_NewIntObj(cur->usage_page));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("usage", -1), Tcl_NewIntObj(cur->usage));
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("interface_number", -1), Tcl_NewIntObj(cur->interface_number));

        if (cur->serial_number) { strattr = Hid_WideToUtf8(cur->serial_number); }
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("serial_number", -1),
                       Tcl_NewStringObj(strattr ? strattr : "", -1));
        if (strattr) {
          free(strattr);
          strattr = NULL;
        }

        if (cur->manufacturer_string) { strattr = Hid_WideToUtf8(cur->manufacturer_string); }
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("manufacturer_string", -1),
                       Tcl_NewStringObj(strattr ? strattr : "", -1));
        if (strattr) {
          free(strattr);
          strattr = NULL;
        }

        if (cur->product_string) { strattr = Hid_WideToUtf8(cur->product_string); }
        Tcl_DictObjPut(interp, dict, Tcl_NewStringObj("product_string", -1),
                       Tcl_NewStringObj(strattr ? strattr : "", -1));
        if (strattr) {
          free(strattr);
          strattr = NULL;
        }

        Tcl_ListObjAppendElement(interp, listObj, dict);
        cur = cur->next;
    }

    hid_free_enumeration(devs);

    Tcl_SetObjResult(interp, listObj);
    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::open vendor_Id product_Id
// -----------------------------------------------------------------------------
static int Hid_OpenCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    // Ensure the handle manager is initialized
    Hid_InitManager();

    if (objc < 3 || objc > 4) {
        Tcl_WrongNumArgs(interp, 1, objv, "vendor_id product_id ?serial_number?");
        return TCL_ERROR;
    }

    int vendorId, productId;
    if (Tcl_GetIntFromObj(interp, objv[1], &vendorId) != TCL_OK) return TCL_ERROR;
    if (Tcl_GetIntFromObj(interp, objv[2], &productId) != TCL_OK) return TCL_ERROR;

    if (vendorId < 0 || vendorId > 0xFFFF) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("vendor_id out of range [0, 65535]", -1));
        return TCL_ERROR;
    }
    if (productId < 0 || productId > 0xFFFF) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("product_id out of range [0, 65535]", -1));
        return TCL_ERROR;
    }

    // Cast to unsigned short as required by HIDAPI
    unsigned short vid = (unsigned short)vendorId;
    unsigned short pid = (unsigned short)productId;

    // Convert serial number if provided
    wchar_t *serial_w = NULL;
    if (objc == 4) {
        char *serial_utf8 = Tcl_GetString(objv[3]);
        serial_w = Hid_Utf8ToWide(serial_utf8);
        if (*serial_utf8 != '\0' && !serial_w) {
             Tcl_SetObjResult(interp, Tcl_NewStringObj("invalid value for serial_number", -1));
             return TCL_ERROR;
        }
    }

    // === HIDAPI call ===
    hid_device *dev = hid_open(vid, pid, serial_w);

    free(serial_w);

    if (!dev) {
        char *errmsg = Hid_WideToUtf8(hid_error(NULL));
        char *resultMsg = errmsg;
        if (resultMsg == NULL) { resultMsg = "unknown HIDAPI error"; }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(resultMsg, -1));
        free(errmsg);
        return TCL_ERROR;
    }

    // Register the device
    char deviceID[32];
    Hid_RegisterDevice(dev, deviceID);

    if (strlen(deviceID) == 0) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("failed to create device handle", -1));
        return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewStringObj(deviceID, -1));
    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::open_path path
//  'path' must be taken over unchanged from ::hidtcl::enumerate
// -----------------------------------------------------------------------------
static int Hid_OpenPathCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    // Ensure the handle manager is initialized
    Hid_InitManager();

    if (objc != 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "path");
        return TCL_ERROR;
    }

    const char *path = Tcl_GetString(objv[1]);
    // === HIDAPI call ===
    hid_device *dev = hid_open_path(path);

    if (!dev) {
        char *errmsg = Hid_WideToUtf8(hid_error(NULL));
        char *resultMsg = errmsg;
        if (resultMsg == NULL) { resultMsg = "unknown HIDAPI error"; }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(resultMsg, -1));
       free(errmsg);
        return TCL_ERROR;
    }

    // Register the device
    char deviceID[32];
    Hid_RegisterDevice(dev, deviceID);

    if (strlen(deviceID) == 0) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("failed to create device handle", -1));
        return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewStringObj(deviceID, -1));
    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::write deviceID data
//  Writes the raw bytes of the Tcl string 'data' to the device.
//  Returns the number of bytes written (or error).
// -----------------------------------------------------------------------------
static int Hid_WriteCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 3) {
        Tcl_WrongNumArgs(interp, 1, objv, "deviceID data");
        return TCL_ERROR;
    }

    // Get the device by name
    char *deviceID = Tcl_GetString(objv[1]);
    hid_device *dev = Hid_GetDevice(deviceID);
    if (dev == NULL) {
        Tcl_SetObjResult(interp,
            Tcl_ObjPrintf("can not find device named \"%s\"", deviceID));
        return TCL_ERROR;
    }

    int length;
    const unsigned char* data = Tcl_GetByteArrayFromObj(objv[2], &length);

    // === HIDAPI call ===
    int res = hid_write(dev, (const unsigned char *)data, length);
    Hid_UnrefDevice(deviceID);

    if (res < 0) {
        char *errmsg = Hid_WideToUtf8(hid_error(NULL));
        char *resultMsg = errmsg;
        if (resultMsg == NULL) { resultMsg = "unknown write error"; }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(resultMsg, -1));
        free(errmsg);
        return TCL_ERROR;
    } else if (res >= 0 && res != length) {
        Tcl_SetObjResult(interp, Tcl_NewStringObj("incomplete write", -1));
        return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewIntObj(res));

    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::read_timeout deviceID length timeout_ms
//  Synchronously read up to 'length' bytes, waiting up to timeout_ms milliseconds.
//  Returns a binary Tcl string with the bytes read, or an empty string on timeout.
// -----------------------------------------------------------------------------
static int Hid_ReadTimeoutCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 4) {
        Tcl_WrongNumArgs(interp, 1, objv, "deviceID length timeout_ms");
        return TCL_ERROR;
    }

    // Get the device by name
    char *deviceID = Tcl_GetString(objv[1]);
    hid_device *dev = Hid_GetDevice(deviceID);
    if (dev == NULL) {
        Tcl_SetObjResult(interp,
            Tcl_ObjPrintf("can not find device named \"%s\"", deviceID));
        return TCL_ERROR;
    }

    int length, timeout;
    if (Tcl_GetIntFromObj(interp, objv[2], &length) != TCL_OK) {
        Hid_UnrefDevice(deviceID);
        return TCL_ERROR;
    }
    if (Tcl_GetIntFromObj(interp, objv[3], &timeout) != TCL_OK) {
        Hid_UnrefDevice(deviceID);
        return TCL_ERROR;
    }

    if (length <= 0) {
        Hid_UnrefDevice(deviceID);
        Tcl_SetObjResult(interp, Tcl_NewStringObj("length must be > 0", -1));
        return TCL_ERROR;
    }

    unsigned char *buf = malloc((size_t)length);
    if (!buf) {
        Hid_UnrefDevice(deviceID);
        Tcl_SetObjResult(interp, Tcl_NewStringObj("read buffer not allocated", -1));
        return TCL_ERROR;
    }

    // === HIDAPI call ===
    int res = hid_read_timeout(dev, buf, (size_t)length, timeout);
    Hid_UnrefDevice(deviceID);

    if (res < 0) {
        free(buf);
        char *errmsg = Hid_WideToUtf8(hid_error(NULL));
        char *resultMsg = errmsg;
        if (resultMsg == NULL) { resultMsg = "unknown read error"; }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(resultMsg, -1));
        free(errmsg);
        return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewByteArrayObj(buf, res));
    free(buf);

    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::read deviceID length
//  Synchronously read up to 'length' bytes
//  Returns a binary Tcl string with the bytes read, or an empty string on timeout.
// -----------------------------------------------------------------------------
static int Hid_ReadCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 3) {
        Tcl_WrongNumArgs(interp, 1, objv, "deviceID length");
        return TCL_ERROR;
    }

    // Get the device by name
    char *deviceID = Tcl_GetString(objv[1]);
    hid_device *dev = Hid_GetDevice(deviceID);
    if (dev == NULL) {
        Tcl_SetObjResult(interp,
            Tcl_ObjPrintf("can not find device named \"%s\"", deviceID));
        return TCL_ERROR;
    }

    int length;
    if (Tcl_GetIntFromObj(interp, objv[2], &length) != TCL_OK) {
        Hid_UnrefDevice(deviceID);
        return TCL_ERROR;
    }
    if (length <= 0) {
        Hid_UnrefDevice(deviceID);
        Tcl_SetObjResult(interp, Tcl_NewStringObj("length must be > 0", -1));
        return TCL_ERROR;
    }

    unsigned char *buf = malloc((size_t)length);
    if (!buf) {
       Hid_UnrefDevice(deviceID);
       Tcl_SetObjResult(interp, Tcl_NewStringObj("read buffer not allocated", -1));
       return TCL_ERROR;
    }

    // === HIDAPI call ===
    int res = hid_read(dev, buf, length);
    Hid_UnrefDevice(deviceID);

    if (res < 0) {
        free(buf);
        char *errmsg = Hid_WideToUtf8(hid_error(NULL));
        char *resultMsg = errmsg;
        if (resultMsg == NULL) { resultMsg = "unknown read error"; }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(resultMsg, -1));
        free(errmsg);
        return TCL_ERROR;
    }

    Tcl_SetObjResult(interp, Tcl_NewByteArrayObj(buf, res));
    free(buf);

    return TCL_OK;
}

// -----------------------------------------------------------------------------
// ::hidtcl::close deviceID
// -----------------------------------------------------------------------------
static int Hid_CloseCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "deviceID");
        return TCL_ERROR;
    }

    char *deviceID = Tcl_GetString(objv[1]);

    if (!Hid_UnrefDevice(deviceID)) {
        Tcl_SetObjResult(interp,
            Tcl_ObjPrintf("can not find device named \"%s\"", deviceID));
        return TCL_ERROR;
    }

    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::version
// -----------------------------------------------------------------------------
static int Hid_VersionCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 1) {
        Tcl_WrongNumArgs(interp, 1, objv, "");
        return TCL_ERROR;
    }

    Tcl_Obj *apiver = Tcl_NewDictObj();
    Tcl_DictObjPut(interp, apiver, Tcl_NewStringObj("major", -1), Tcl_NewIntObj(HID_API_VERSION_MAJOR));
    Tcl_DictObjPut(interp, apiver, Tcl_NewStringObj("minor", -1), Tcl_NewIntObj(HID_API_VERSION_MINOR));
    Tcl_DictObjPut(interp, apiver, Tcl_NewStringObj("patch", -1), Tcl_NewIntObj(HID_API_VERSION_PATCH));

    Tcl_SetObjResult(interp, apiver);
    return TCL_OK;
}

// -----------------------------------------------------------------------------
//  ::hidtcl::version_str
// -----------------------------------------------------------------------------
static int Hid_VersionStrCmd(ClientData cdata, Tcl_Interp *interp, int objc, Tcl_Obj *const objv[])
{
    (void)cdata;

    if (objc != 1) {
        Tcl_WrongNumArgs(interp, 1, objv, "");
        return TCL_ERROR;
    }

    const char *verstr = hid_version_str();
    if (verstr == NULL) { verstr = "unknown HID version"; }

    Tcl_SetObjResult(interp, Tcl_NewStringObj(verstr, -1));
    return TCL_OK;
}

// -----------------------------------------------------------------------------
// Init-Funktion
// -----------------------------------------------------------------------------
#ifdef _WIN32
__declspec(dllexport)
#endif
int Hidtcl_Init(Tcl_Interp *interp)
{

    if (Tcl_InitStubs(interp, "8.6", 0) == NULL)
        return TCL_ERROR;

    // Initialise deviceID management
    Hid_InitManager();

    // Ensure namespace exists
    Tcl_Namespace *nsPtr = Tcl_CreateNamespace(interp, "hidtcl", NULL, NULL);
    if (!nsPtr) return TCL_ERROR;

    Tcl_CreateObjCommand(interp, "::hidtcl::init", Hid_InitCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::exit", Hid_ExitCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::open", Hid_OpenCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::open_path", Hid_OpenPathCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::close", Hid_CloseCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::write", Hid_WriteCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::read_timeout", Hid_ReadTimeoutCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::read", Hid_ReadCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::enumerate", Hid_EnumerateCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::version", Hid_VersionCmd, NULL, NULL);
    Tcl_CreateObjCommand(interp, "::hidtcl::version_str", Hid_VersionStrCmd, NULL, NULL);

    // Provide the package
    if (Tcl_PkgProvide(interp, "hidtcl", "1.0") != TCL_OK)
        return TCL_ERROR;

    return TCL_OK;
}

// On some platforms the initialisation function has a different name:
// we alias Tcl package name to the C function expected by Tcl loader.
///
int Hidtcl_SafeInit(Tcl_Interp *interp)
{
    // same initialisation for safe interpreters (no special sandboxing here)
    return Hidtcl_Init(interp);
}
