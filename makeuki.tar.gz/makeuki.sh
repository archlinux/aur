#!/bin/bash
CONFIG="/etc/makeuki/makeuki.conf"
PID=$$
trap "exit 1" TERM
function die(){
    echo "$1"
    echo 
    kill -s TERM $PID
}
function conf(){
    for _ in once;do
    [ -f $CONFIG ] || break
    cat $CONFIG | jq ".$1" | tr -d '"'
    return
    done
    die "Config file not found"
}
function conf2(){
    for _ in once;do
    [ -f $CONFIG ] || break
    return $(cat $CONFIG | jq ".$1" | tr -d '"' | grep -q true)
    done
    die "Config file not found"
}
function main(){
    [ -f $CONFIG ] || die "Config file not found"
    oldpwd=$(pwd)
    mkdir -p $(conf "workdir")
    cd $(conf "workdir")

    #gather resources
    echo ---gathering resources...
    echo $(conf 'command_line|join(" ")') > cmdline.txt
    if conf2 "intel_microcode"; then
        [ -f /boot/intel-ucode.img ] &&  mv -fv /boot/intel-ucode.img ./
        [ -f intel-ucode.img ]       ||  pacman -Sy intel-ucode --noconfirm || die "Error downloading intel microcode"
    fi
    if conf2 "amd_microcode"; then
        [ -f /boot/amd-ucode.img ]   &&  mv -fv /boot/amd-ucode.img ./
        [ -f amd-ucode.img ]         ||  pacman -Sy amd-ucode --noconfirm   || die "Error downloading amd microcode"
    fi
    makeuki -k >/dev/null || die "Kernel package is missing."
    [ -f initrd-2.img ]     ||  mkinitcpio -p makeuki || die "Failed to make initramfs."
    
    #make initrd
    echo ---making combined initrd...
    cat $(conf2 "intel_microcode" && echo "intel-ucode.img") $(conf2 "amd_microcode" && echo "amd-ucode.img") initrd-2.img> initrd.img || die "Error making combined initrd."
    echo ---making unified kernel image...
    objcopy \
        --add-section .osrel=/usr/lib/os-release --change-section-vma .osrel=0x20000 \
        --add-section .cmdline=cmdline.txt --change-section-vma .cmdline=0x30000 \
        --add-section .splash=$(conf "splash") --change-section-vma .splash=0x40000 \
        --add-section .linux=/usr/lib/modules/$(makeuki -k)/vmlinuz --change-section-vma .linux=0x2000000 \
        --add-section .initrd=initrd.img --change-section-vma .initrd=0x3000000 \
        "/usr/lib/systemd/boot/efi/linuxx64.efi.stub" "linux.efi" || die "Failed to make kernel image"
        
    if conf2 "secure_boot"; then
        echo signing kernel image...
        sbsign --key $(conf "sb_private_key") --cert $(conf "sb_cert_key") linux.efi --output linux.efi || die "Error signing kernel image"
    fi
    echo copying kernel image to $(conf "output_file")...
    cp -fv linux.efi $(conf "output_file") || die "Failed to write output file. Copy $(readlink -f linux.efi) to desired location."
    echo ---cleaning...
    makeuki -c
    echo ---done.
    cd $oldpwd
}

if [ "$(id -u)" != "0" ]; then
    exec sudo "$0" "$@"
fi
case $1 in
    -h|--help)
        cat <<EOF
$(pacman -Q makeuki --color never)
usage: ${0##*/} [options]
  Options:
   -b, --build          Builds the unified kernel image. Probably the option you want.
   -p, --path           Echoes the path of ${0##*/}'s workdir specified in makeuki.conf.
   -k, --kernel         Echoes the most recent installed version of the kernel specified in makeuki.conf.
   -c, --clean          Cleans build files from workdir.
EOF
        exit
        ;;
    -p|--path)
        echo $(conf "workdir")
        exit
        ;;
        
    -k|--kernel)
        pacman -Ql $(conf "kernel") >/dev/null || die "Kernel package is missing."
        echo $(pacman -Ql $(conf "kernel") | grep -Eom1 '(\w*[.])+(\w*-)+(\w*)?')
        exit
        ;;
    -b|--build)
        main
        exit
        ;;
    -c|--clean)
        rm -v cmdline.txt
        rm -v initrd*
        if conf2 "intel_microcode" || conf2 "amd_microcode";then
            rm  -v *ucode.img
        fi
        exit
        ;;
    esac
