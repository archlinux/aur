#!/bin/bash
CONFIG="/etc/makeuki/makeuki.conf"
PID=$$
trap "exit 1" TERM
function die(){
    echo "$1"
    echo 
    kill -s TERM $PID
}
function conf(){
    for _ in once;do
    [ -f $CONFIG ] || break
    cat $CONFIG | jq ".$1" | tr -d '"'
    return
    done
    die "Config file not found"
}
function conf2(){
    for _ in once;do
    [ -f $CONFIG ] || break
    return $(cat $CONFIG | jq ".$1" | tr -d '"' | grep -q true)
    done
    die "Config file not found"
}
function main(){
    [ -f $CONFIG ] || die "Config file not found"
    oldpwd=$(pwd)
    mkdir -p $(conf "workdir")
    cd $(conf "workdir")

    #gather resources
    echo ---gathering resources...
    echo $(conf 'command_line|join(" ")') > cmdline.txt
    makeuki -k >/dev/null || die "Kernel package is missing."
    case $1 in
        --rebuild)
        rm -v $(conf "workdir")/include/mkinitcpio-out.img
        ;;
    esac
        
    [ -f ./include/mkinitcpio-out.img ] && echo "Using prebuilt initramfs."  ||  mkinitcpio -p makeuki || die "Failed to make initramfs."

    #make initrd
    echo ---making combined initrd...
    for f in ./include/*;do
        echo "     including $f"
    done
    cat ./include/* > initrd.img || die "Error making combined initrd."
    echo ---making unified kernel image...
    objcopy -v \
        --add-section .osrel=/usr/lib/os-release --change-section-vma .osrel=0x20000 \
        --add-section .cmdline=cmdline.txt --change-section-vma .cmdline=0x30000 \
        --add-section .splash=$(conf "splash") --change-section-vma .splash=0x40000 \
        --add-section .linux=/usr/lib/modules/$(makeuki -k)/vmlinuz --change-section-vma .linux=0x2000000 \
        --add-section .initrd=initrd.img --change-section-vma .initrd=0x3000000 \
        "/usr/lib/systemd/boot/efi/linuxx64.efi.stub" "linux.efi" || die "Failed to make kernel image"
        
    if conf2 "secure_boot"; then
        echo ---signing kernel image...
        sbsign --key $(conf "sb_private_key") --cert $(conf "sb_cert_key") linux.efi --output linux.efi >/dev/null|| die "Error signing kernel image"
    fi
    echo ---copying kernel image to $(conf "output_file")...
    cp -fv linux.efi $(conf "output_file") || echo "Failed to write output file. Copy $(readlink -f linux.efi) to desired location."
    rm cmdline.txt
    echo ---done.
    cd $oldpwd
}

if [ "$(id -u)" != "0" ]; then
    exec sudo "$0" "$@"
fi


case $1 in
    -p|--path)
        echo $(conf "workdir")
        exit
        ;;
        
    -k|--kernel)
        pacman -Ql $(conf "kernel") >/dev/null || die "Kernel package is missing."
        echo $(pacman -Ql $(conf "kernel") | grep -Eom1 '(\w*[.])+(\w*-)+(\w*)?')
        exit
        ;;
    -b|--build)
        main $2
        exit
        ;;
    -h|--help|*)
        cat <<EOF
$(pacman -Q makeuki --color never)
usage: ${0##*/} [options]
  Options:
   -b, --build          Builds the unified kernel image. Probably the option you want.
        Add --rebuild to rebuild the initramfs from the previous build
        Put .img files you want to include in the initramfs (such as microcode) into $(makeuki -p)include/
   -p, --path           Echoes the path of ${0##*/}'s workdir specified in makeuki.conf.
   -k, --kernel         Echoes the most recent installed version of the kernel specified in makeuki.conf.
   -h, --help           Displays this help message.
EOF
        exit
        ;;
    esac