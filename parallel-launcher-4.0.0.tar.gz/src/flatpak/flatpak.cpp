#include "src/flatpak/flatpak.hpp"

#include "src/polyfill/base-directory.hpp"
#include "src/polyfill/process.hpp"
#include "src/core/file-controller.hpp"
#include <fstream>
#include <thread>

extern "C" {
#include <flatpak/flatpak.h>
}

static const char s_retroRef[] = R"EOF([Flatpak Ref]
Name=org.libretro.RetroArch
Branch=stable
Title=org.libretro.RetroArch from flathub
IsRuntime=false
Url=https://dl.flathub.org/repo/
SuggestRemoteName=flathub
RuntimeRepo=https://dl.flathub.org/repo/flathub.flatpakrepo
)EOF";

static const char s_flathubRef[] = R"EOF([Flatpak Repo]
Title=Flathub
Url=https://dl.flathub.org/repo/
Homepage=https://flathub.org/
Comment=Central repository of Flatpak applications
Description=Central repository of Flatpak applications
Icon=https://dl.flathub.org/repo/logo.svg
)EOF";

#include "src/flatpak/flatpak-gpg.cpp.inc"

static bool addFlathubRemote( FlatpakInstallation *fpInstall ) {
	FlatpakRemote *remote = flatpak_installation_get_remote_by_name( fpInstall, "flathub", nullptr, nullptr );
	if( remote != nullptr ) {
		g_object_unref( remote );
		return true;
	}

	GBytes *remoteInfo = g_bytes_new_static( s_flathubRef, sizeof( s_flathubRef ) );
	remote = flatpak_remote_new_from_file( "flathub", remoteInfo, nullptr );

	GBytes *gpgKey = g_bytes_new_static( s_gpgKey, sizeof( s_gpgKey ) );
	flatpak_remote_set_gpg_key( remote, gpgKey );
	flatpak_remote_set_gpg_verify( remote, true );

	if( remote != nullptr ) {
		const bool success = flatpak_installation_add_remote( fpInstall, remote, true, nullptr, nullptr );
		g_object_unref( remote );
		return success;
	}

	return false;
}

bool Flatpak::hasInstallation() {
	FlatpakInstallation *fpInstall = flatpak_installation_new_system_with_id( "parallel-launcher", nullptr, nullptr );
	if( fpInstall == nullptr ) return false;

	g_object_unref( fpInstall );
	return true;
}

bool Flatpak::createInstallation() {
	const fs::path installDir = BaseDir::data() / "retroarch";
	const fs::path tempConfigPath = BaseDir::homeTemp() / "parallel-launcher.conf";
	fs::create_directories( installDir );

	std::ofstream config( tempConfigPath, std::ios_base::out | std::ios_base::trunc );
	config << "[Installation \"parallel-launcher\"]" << std::endl;
	config << "Path=" << installDir.string() << std::endl;
	config << "DisplayName=parallel-launcher" << std::endl;
	config << "StorageType=harddisk" << std::endl;
	config << std::flush;

	const int exitCode = AsyncProcess(
		"pkexec",
		{ "install", "-D", tempConfigPath.string(), "/etc/flatpak/installations.d/parallel-launcher.conf" }
	).join();

	fs::remove( tempConfigPath );
	return exitCode == 0L;
}

static FlatpakInstalledRef *getRetroArchRef(
	FlatpakInstallation *fpInstall,
	GCancellable *cancellationToken
) {
	GPtrArray *apps = flatpak_installation_list_installed_refs_by_kind( fpInstall, FLATPAK_REF_KIND_APP, cancellationToken, nullptr );
	if( apps == nullptr ) return nullptr;

	for( guint i = 0; i < apps->len; i++ ) {
		FlatpakInstalledRef *ref = (FlatpakInstalledRef*)g_ptr_array_index( apps, i );
		const char *appName = flatpak_installed_ref_get_appdata_name( ref );
		if( appName == nullptr || string( appName ) != "RetroArch" ) continue;

		g_object_ref( ref );
		g_ptr_array_unref( apps );
		return ref;
	}

	return nullptr;
}

bool Flatpak::isRetroArchInstalled() {
	FlatpakInstallation *fpInstall = flatpak_installation_new_system_with_id( "parallel-launcher", nullptr, nullptr );
	if( fpInstall == nullptr ) return false;

	FlatpakInstalledRef *retroRef = getRetroArchRef( fpInstall, nullptr );
	if( retroRef == nullptr ) {
		g_object_unref( fpInstall );
		return false;
	}

	g_object_unref( retroRef );
	g_object_unref( fpInstall );
	return true;
}

static void s_noop() {}

static void installWorker(
	Flatpak::AsyncCallbacks *callbacks,
	FlatpakInstallation *fpInstall,
	FlatpakTransaction *transaction,
	GCancellable *cancellationToken
) {
	const bool result = flatpak_transaction_run( transaction, cancellationToken, nullptr );
	g_object_unref( transaction );
	g_object_unref( fpInstall );
	if( g_cancellable_is_cancelled( cancellationToken ) ) {
		callbacks->onFinished( Flatpak::OperationResult::Cancelled );
	} else {
		callbacks->onFinished( result ? Flatpak::OperationResult::Success : Flatpak::OperationResult::Failure );
	}
	g_object_unref( cancellationToken );
	delete callbacks;
}

static bool transactionReady(
	FlatpakTransaction *fpInstall,
	gpointer callback
) {
	GList *operations = flatpak_transaction_get_operations( fpInstall );
	static_cast<Flatpak::AsyncCallbacks*>( callback )->onReady( (int)g_list_length( operations ) );
	return true;
}

static void transactionOperationProgress(
	FlatpakTransactionProgress *progress,
	gpointer callback
) {
	static_cast<Flatpak::AsyncCallbacks*>( callback )->onOperationProgress(
		flatpak_transaction_progress_get_status( progress ),
		flatpak_transaction_progress_get_progress( progress )
	);
}

static void transactionOperationStart(
	[[maybe_unused]] FlatpakTransaction *fpInstall,
	FlatpakTransactionOperation *operation,
	FlatpakTransactionProgress *progress,
	gpointer callback
) {
	Flatpak::OperationType operationType;
	switch( flatpak_transaction_operation_get_operation_type( operation ) ) {
		case FLATPAK_TRANSACTION_OPERATION_INSTALL:
		case FLATPAK_TRANSACTION_OPERATION_INSTALL_BUNDLE:
			operationType = Flatpak::OperationType::Install; break;
		case FLATPAK_TRANSACTION_OPERATION_UPDATE:
			operationType = Flatpak::OperationType::Update; break;
		case FLATPAK_TRANSACTION_OPERATION_UNINSTALL:
			operationType = Flatpak::OperationType::Remove; break;
		default:
			operationType = (Flatpak::OperationType)-1;
	}

	static_cast<Flatpak::AsyncCallbacks*>( callback )->onOperationStart(
		flatpak_transaction_operation_get_ref( operation ),
		flatpak_transaction_progress_get_status( progress ),
		operationType
	);

	g_signal_connect( progress, "changed", G_CALLBACK(transactionOperationProgress), callback );
}

static void transactionOperationDone(
	[[maybe_unused]] FlatpakTransaction *fpInstall,
	[[maybe_unused]] FlatpakTransactionOperation *operation,
	[[maybe_unused]] gchar *commit,
	[[maybe_unused]] gint result,
	gpointer callback
) {
	static_cast<Flatpak::AsyncCallbacks*>( callback )->onOperationFinished();
}

static bool transactionOperationError(
	[[maybe_unused]] FlatpakTransaction *fpInstall,
	[[maybe_unused]] FlatpakTransactionOperation *operation,
	GError *error,
	[[maybe_unused]] gint details,
	gpointer callback
) {
	static_cast<Flatpak::AsyncCallbacks*>( callback )->onOperationError( error->message );
	return false;
}

Flatpak::CancelFunc Flatpak::installRetroArchAsync( const AsyncCallbacks &operation ) {
	FlatpakInstallation *fpInstall = flatpak_installation_new_system_with_id( "parallel-launcher", nullptr, nullptr );
	if( fpInstall == nullptr ) {
		operation.onFinished( OperationResult::Failure );
		return s_noop;
	}

	if( !addFlathubRemote( fpInstall ) ) {
		g_object_unref( fpInstall );
		operation.onFinished( OperationResult::Failure );
		return s_noop;
	}

	FlatpakTransaction *transaction = flatpak_transaction_new_for_installation( fpInstall, nullptr, nullptr );
	if( transaction == nullptr ) {
		g_object_unref( fpInstall );
		operation.onFinished( OperationResult::Failure );
		return s_noop;
	}

	GBytes *ref = g_bytes_new_static( s_retroRef, sizeof( s_retroRef ) );
	GError *error = nullptr;
	if( !flatpak_transaction_add_install_flatpakref( transaction, ref, &error ) ) {
		g_object_unref( transaction );
		g_object_unref( fpInstall );
		operation.onFinished( OperationResult::Failure );
		return s_noop;
	}

	AsyncCallbacks *callbacks = new AsyncCallbacks;
	*callbacks = operation;
	g_signal_connect( transaction, "ready", G_CALLBACK(transactionReady), callbacks );
	g_signal_connect( transaction, "new-operation", G_CALLBACK(transactionOperationStart), callbacks );
	g_signal_connect( transaction, "operation-done", G_CALLBACK(transactionOperationDone), callbacks );
	g_signal_connect( transaction, "operation-error", G_CALLBACK(transactionOperationError), callbacks );

	GCancellable *cancellationToken = g_cancellable_new();
	std::thread( installWorker, callbacks, fpInstall, transaction, cancellationToken ).detach();
	return [cancellationToken](){ g_cancellable_cancel( cancellationToken ); };
}

static void runUpdateTransaction(
	FlatpakInstallation *fpInstall,
	FlatpakTransaction *transaction,
	GCancellable *cancellationToken,
	Flatpak::AsyncCallbacks *callbacks
) {
	g_signal_connect( transaction, "ready", G_CALLBACK(transactionReady), callbacks );
	g_signal_connect( transaction, "new-operation", G_CALLBACK(transactionOperationStart), callbacks );
	g_signal_connect( transaction, "operation-done", G_CALLBACK(transactionOperationDone), callbacks );
	g_signal_connect( transaction, "operation-error", G_CALLBACK(transactionOperationError), callbacks );

	const bool result = flatpak_transaction_run( transaction, cancellationToken, nullptr );
	g_object_unref( transaction );
	g_object_unref( fpInstall );
	if( g_cancellable_is_cancelled( cancellationToken ) ) {
		callbacks->onFinished( Flatpak::OperationResult::Cancelled );
	} else {
		callbacks->onFinished( result ? Flatpak::OperationResult::Success : Flatpak::OperationResult::Failure );
	}
}

static void updateWorker(
	FlatpakInstallation *fpInstall,
	GCancellable *cancellationToken,
	Flatpak::AsyncCallbacks *callbacks,
	bool runtimesOnly
) {
	GPtrArray *refs = flatpak_installation_list_installed_refs_for_update( fpInstall, cancellationToken, nullptr );
	if( refs == nullptr ) {
		g_object_unref( fpInstall );
		callbacks->onFinished( Flatpak::OperationResult::Failure );
		return;
	}

	if( refs->len == 0 ) {
		g_object_unref( fpInstall );
		callbacks->onFinished( Flatpak::OperationResult::Cancelled );
		return;
	}

	FlatpakTransaction *transaction = flatpak_transaction_new_for_installation( fpInstall, cancellationToken, nullptr );
	if( transaction == nullptr ) {
		g_object_unref( fpInstall );
		callbacks->onFinished( Flatpak::OperationResult::Failure );
		return;
	}

	bool anyOperations = false;
	for( guint i = 0; i < refs->len; i++ ) {
		FlatpakRef *ref = (FlatpakRef*)g_ptr_array_index( refs, i );
		if( runtimesOnly && flatpak_ref_get_kind( ref ) != FLATPAK_REF_KIND_RUNTIME ) {
			continue;
		}
		anyOperations = true;

		if( !flatpak_transaction_add_update( transaction, flatpak_ref_format_ref( ref ), nullptr, nullptr, nullptr ) ) {
			g_ptr_array_unref( refs );
			g_object_unref( transaction );
			g_object_unref( fpInstall );
			callbacks->onFinished( Flatpak::OperationResult::Failure );
			return;
		}
	}

	g_ptr_array_unref( refs );
	if( anyOperations && callbacks->getConfirmation() ) {
		runUpdateTransaction( fpInstall, transaction, cancellationToken, callbacks );
	} else {
		g_object_unref( transaction );
		g_object_unref( fpInstall );
		callbacks->onFinished( Flatpak::OperationResult::Cancelled );
		return;
	}

}

static Flatpak::CancelFunc runUpdate( const Flatpak::AsyncCallbacks &operation, bool runtimesOnly ) {
	FlatpakInstallation *fpInstall = flatpak_installation_new_system_with_id( "parallel-launcher", nullptr, nullptr );
	if( fpInstall == nullptr ) {
		operation.onFinished( Flatpak::OperationResult::Failure );
		return s_noop;
	}

	if( !addFlathubRemote( fpInstall ) ) {
		g_object_unref( fpInstall );
		operation.onFinished( Flatpak::OperationResult::Failure );
		return s_noop;
	}

	Flatpak::AsyncCallbacks *callbacks = new Flatpak::AsyncCallbacks;
	*callbacks = operation;

	GCancellable *cancellationToken = g_cancellable_new();
	std::thread( updateWorker, fpInstall, cancellationToken, callbacks, runtimesOnly ).detach();
	return [cancellationToken](){ g_cancellable_cancel( cancellationToken ); };
}

Flatpak::CancelFunc Flatpak::updateRuntimes( const AsyncCallbacks &operation ) {
	return runUpdate( operation, true );
}

Flatpak::CancelFunc Flatpak::updateAll( const AsyncCallbacks &operation ) {
	return runUpdate( operation, false );
}
