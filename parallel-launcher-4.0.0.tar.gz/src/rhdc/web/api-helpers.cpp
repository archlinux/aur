#include "src/rhdc/web/api-helpers.hpp"

#include <cstdio>
#include "src/core/numeric-string.hpp"
#include "src/core/version.hpp"
#include "src/core/logging.hpp"

using namespace ApiUtil;

#define DECLARE_VERB( verb, verbString ) \
static const QByteArray &s_##verb() { \
	static const QByteArray s_verb = QByteArray( verbString ); \
	return s_verb; \
} \
const HttpMethodFactory HttpMethod::verb = s_##verb;

DECLARE_VERB( Get, "GET" )
DECLARE_VERB( Post, "POST" )
DECLARE_VERB( Put, "PUT" )
DECLARE_VERB( Patch, "PATCH" )
DECLARE_VERB( Delete, "DELETE" )
DECLARE_VERB( Head, "HEAD" )

#undef DECLARE_VERB

QNetworkAccessManager *ApiUtil::web() {
	static QNetworkAccessManager *s_web = new QNetworkAccessManager();
	return s_web;
}

__Identity &ApiUtil::identity() noexcept {
	static __Identity s_identity = { "", "", QByteArray() };
	return s_identity;
}

inline bool isUrlSafe( char c ) {
	return
		(c >= '0' && c <= '9') ||
		(c >= 'a' && c <= 'z') ||
		(c >= 'A' && c <= 'Z') ||
		c == '-' || c == '.' || c == '_' || c == '~';
}

string ApiUtil::urlEncode( const string &str ) {
	string safeString;
	for( char c : str ) {
		if( isUrlSafe( c) ) {
			safeString += c;
		} else {
			char code[4];
			std::sprintf( code, "%%%02x", (uint)(ubyte)c );
			code[3] = '\0';
			safeString += code;
		}
	}
	return safeString;
}

QNetworkRequest ApiUtil::makeRequest( const string &url, bool sendsJson ) {
	static const QVariant s_userAgent = QVariant::fromValue<QString>(
		("ParallelLauncher/"s + CurrentVersion::Application.toString()).c_str()
	);

	QNetworkRequest request( QUrl( url.c_str() ) );
	request.setHeader( QNetworkRequest::UserAgentHeader, s_userAgent );

	if( sendsJson ) {
		static const QVariant s_contentType = QVariant::fromValue<QString>( "application/json" );
		request.setHeader( QNetworkRequest::ContentTypeHeader, s_contentType );
	}

	if( !identity().authToken.isNull() ) {
		static const QByteArray s_headerName = QByteArray( "Authorization" );
		request.setRawHeader( s_headerName, identity().authToken );
	}

	return request;
}

int ApiUtil::getStatusCode( QNetworkReply *response ) {
	bool hasStatusCode;
	const int statusCode = response->attribute( QNetworkRequest::HttpStatusCodeAttribute ).toInt( &hasStatusCode );
	return hasStatusCode ? statusCode : 0;
}

Json ApiUtil::readJson( QNetworkReply *response ) noexcept {
	try {
		std::istringstream stream( response->readAll().data() );
		return Json::parse( stream );
	} catch( ... ) {
		return Json();
	}
}

void ApiUtil::onResponse(
	QNetworkReply *response,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	QObject::connect( response, &QNetworkReply::finished, response->manager(), [=]() {
		ApiErrorType errorType;
		bool good = false;

		const HttpStatusCode statusCode = (HttpStatusCode)getStatusCode( response );
		logDebug( Number::toString( (int)statusCode ) + ' ' + response->url().toString().toStdString() );

		switch( statusCode ) {
			case HttpStatusCode::OK:
			case HttpStatusCode::Created:
			case HttpStatusCode::Accepted:
			case HttpStatusCode::NoContent:
				good = true;
				break;
			case HttpStatusCode::Unauthorized:
			case HttpStatusCode::Forbidden:
				errorType = ApiErrorType::NotAuthorized;
				break;
			case HttpStatusCode::NotFound:
			case HttpStatusCode::Gone:
				errorType = ApiErrorType::NotFound;
				break;
			case HttpStatusCode::TooManyRequests:
			case HttpStatusCode::InternalServerError:
			case HttpStatusCode::BadGateway:
			case HttpStatusCode::ServiceUnavailable:
			case HttpStatusCode::GatewayTimeout:
			case HttpStatusCode::None:
				errorType = ApiErrorType::ServerDown;
				break;
			default:
				errorType = ApiErrorType::UnknownError;
		}

		good ? onSuccess() : onFailure( errorType );
		response->deleteLater();
	}, Qt::QueuedConnection );
}
