#include "src/rhdc/core/plugin-detect.hpp"

#include <fstream>
#include <ios>
#include "src/core/version.hpp"

#ifdef _WIN32
static inline uint ntohl( uint word ) {
	# if __BYTE_ORDER == __LITTLE_ENDIAN
		return _byteswap_ulong( word );
	#else
		return word;
	#endif
}

static inline ushort ntohs( ushort halfword ) {
	# if __BYTE_ORDER == __LITTLE_ENDIAN
		return _byteswap_ushort( halfword );
	#else
		return word;
	#endif
}

static inline uint htonl( uint word ) { return ntohl( word ); }
static inline uint htons( ushort halfword ) { return ntohs( halfword ); }
#else
#include <netinet/in.h>
#endif

enum class Tool {
	DecompProbably,
	BowsersBlueprints,
	BowsersBlueprintsOld,
	RomManager,
	SM64Editor
};

static constexpr uint BBP_SIGNATURE = 0x4242503A;
static constexpr uint SME_SIGNATURE = 0x170C0007;
static constexpr uint RM_SIGNATURE = 0x00AED760;

static inline Tool guessTool( std::ifstream &rom ) {
	uint bbpSignature = 0;
	rom.seekg( -8, std::ios_base::end );
	rom.read( (char*)&bbpSignature, 4 );

	/* Bowser's Blueprints */
	if( BBP_SIGNATURE == htonl( bbpSignature ) ) {
		uint metadataAddr = 0;
		rom.read( (char*)&metadataAddr, 4 );
		rom.seekg( (size_t)ntohl( metadataAddr ) + 6 );

		ushort versionData[3] = { 0, 0, 0 };
		rom.read( (char*)versionData, 6 );

		const Version bbpRomVersion = {
			ntohs( versionData[0] ),
			ntohs( versionData[1] ),
			ntohs( versionData[2] )
		};

		if( bbpRomVersion >= Version{ 0, 4, 1 } ) {
			return Tool::BowsersBlueprints;
		} else {
			return Tool::BowsersBlueprintsOld;
		}
	}

	/* Rom Manager */
	rom.seekg( 0x269EC4 );
	uint rmSignature = 0;
	rom.read( (char*)&rmSignature, 4 );
	if( RM_SIGNATURE == ntohl( rmSignature ) ) {
		return Tool::RomManager;
	}

	/* SM64 Editor */
	rom.seekg( 0x405CC8 );
	uint smeSignature = 0;
	rom.read( (char*)&smeSignature, 4 );
	if( SME_SIGNATURE == ntohl( smeSignature ) ) {
		return Tool::SM64Editor;
	}

	return Tool::DecompProbably;
}

AutoPlugin AutoPlugin::guess( const fs::path &romPath, bool preferHle ) {
	std::ifstream romFile( romPath, std::ios_base::in | std::ios_base::binary );
	switch( guessTool( romFile ) ) {
		case Tool::BowsersBlueprintsOld:
		case Tool::SM64Editor:
			return preferHle ? AutoPlugin{
				EmulatorCore::Mupen64plusNext,
				GfxPlugin::ParaLLEl,
				GfxPlugin::GlideN64
			} : AutoPlugin{
				EmulatorCore::ParallelN64,
				GfxPlugin::ParaLLEl,
				GfxPlugin::ParaLLEl
			};
		case Tool::RomManager:
			return AutoPlugin{
				EmulatorCore::Mupen64plusNext,
				GfxPlugin::Glide64,
				GfxPlugin::GlideN64
			};
		case Tool::DecompProbably:
		case Tool::BowsersBlueprints:
		default:
			return AutoPlugin{
				EmulatorCore::ParallelN64,
				GfxPlugin::Glide64,
				GfxPlugin::GlideN64
			};
	}
}
