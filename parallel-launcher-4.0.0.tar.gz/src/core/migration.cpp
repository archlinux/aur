#include "src/core/migration.hpp"

#include <fstream>
#include <thread>
#include <memory>
#include <unordered_map>
#include <QProgressDialog>
#include <QProgressBar>
#include <QCloseEvent>
#include "src/polyfill/base-directory.hpp"
#include "src/polyfill/sha1.hpp"
#include "src/db/sqlite.hpp"
#include "src/db/data-provider.hpp"
#include "src/db/transaction.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/json.hpp"
#include "src/core/qthread.hpp"
#include "src/core/special-groups.hpp"
#ifdef _WIN32
#include "src/polyfill/windows/unicode.hpp"
#endif

class StubbornProgressDialog : public QProgressDialog {

	private:
	bool *m_migrationFinished;

	public:
	StubbornProgressDialog( bool *migrationStatus ) :
		QProgressDialog( nullptr ),
		m_migrationFinished( migrationStatus )
	{
		setModal( true );
		setWindowModality( Qt::ApplicationModal );
		setLabelText( "Computing ROM Checksums..." );
		setCancelButton( nullptr );
		setAutoClose( false );

		QProgressBar *progressBar = new QProgressBar();
		progressBar->setOrientation( Qt::Horizontal );
		progressBar->setFormat( "%v/%m" );
		progressBar->setTextVisible( true );

		setBar( progressBar );
		setRange( 0, 0 );
	}

	virtual ~StubbornProgressDialog() {}

	protected:
	virtual void closeEvent( QCloseEvent *event ) override {
		if( *m_migrationFinished ) {
			QProgressDialog::closeEvent( event );
		} else {
			event->ignore();
		}
	}

};

static inline string removeNewlines( const string &str ) {
	string safeString;
	safeString.reserve( str.size() );
	for( char c : str ) {
		if( c != '\n' ) safeString += c;
	}
	return safeString;
}

static inline void processRom(
	const Json &json,
	HashMap<string,RomInfo> &romInfoTable,
	std::vector<RomFile> &romFiles,
	[[maybe_unused]] bool fixEncoding
) {
	string romName = json["name"].getOrDefault<string>( "" );
	if( romName.empty() ) return;

	string romPathString = json["file_path"].getOrDefault<string>( "" );
	if( romPathString.empty() ) return;

#ifdef _WIN32
	if( fixEncoding ) {
		romPathString = Unicode::latinToUtf8( romPathString );
	}
#endif

	const fs::path romPath = fs::to_path( romPathString );
	if( !fs::existsSafe( romPath ) ) return;

	Uuid inputModeId;
	if( !Uuid::tryParse( json["input_mode"].getOrDefault<string>( "" ), inputModeId ) ) {
		inputModeId = DefaultInputModes::Normal.id;
	}

	std::set<string> groups;
	if( json["tags"].isArray() ) {
		for( const Json &group : json["tags"].array() ) {
			string groupName = removeNewlines( group.getOrDefault<string>( "" ) );
			if( groupName.empty() ) continue;
			if( groupName == "Favourites" ) groupName = SpecialGroups::Favourites;
			if( groupName == "Automatically Added" ) groupName = SpecialGroups::AutomaticallyAdded;
			groups.insert( std::move( groupName ) );
		}
	}

	const int64 lastPlayed = json["last_played"].getOrDefault<int64>( 0 );
	const int64 playTime = json["play_time"].getOrDefault<int64>( 0 );

	string sha1 = Sha1::compute( romPath );
	if( romInfoTable.count( sha1 ) > 0 ) {
		RomInfo &romInfo = romInfoTable[sha1];
		if( romInfo.lastPlayed < lastPlayed ) romInfo.lastPlayed = lastPlayed;
		romInfo.playTime += playTime;
		romInfo.groups.insert( groups.begin(), groups.end() );
	} else {
		romInfoTable[sha1] = RomInfo{
			sha1,
			std::move( romName ),
			RomUtil::getInternalName( romPath ),
			json["emulator_core"].getOrDefault<EmulatorCore>( EmulatorCore::ParallelN64 ),
			json["gfx_plugin"].getOrDefault<GfxPlugin>( GfxPlugin::UseDefault ),
			json["gfx_plugin_mupen"].getOrDefault<GfxPlugin>( GfxPlugin::UseDefault ),
			lastPlayed,
			playTime,
			std::move( groups ),
			json["overclock_cpu"].getOrDefault<bool>( true ),
			json["overclock_vi"].getOrDefault<bool>( false ),
			RomUtil::getCrc32( romPath ),
			std::move( inputModeId ),
			json["widescreen"].getOrDefault( false )
		};
	}

	romFiles.push_back({
		romPath,
		RomUtil::getLastModified( romPath ),
		sha1
	});
}

static inline void migrateRomsToSqlite( bool fixEncoding ) {
	const fs::path filePath = BaseDir::data() / "roms.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream romListFile( filePath );
	const Json romListJson = Json::parse( romListFile );
	romListFile.close();

	if( !romListJson.isArray() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &romList = romListJson.array();
	if( romList.empty() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	bool migrationFinished = false;
	std::shared_ptr<bool> dialogExists = std::shared_ptr<bool>( new bool( true ) );
	StubbornProgressDialog dialog( &migrationFinished );
	dialog.setRange( 0, (int)romList.size() );

	HashMap<string,RomInfo> romInfoTable;
	std::vector<RomFile> romFiles;
	romFiles.reserve( romList.size() );

	std::thread migrationWorker( [&](){
		int romsProcessed = 0;
		for( const Json &rom : romList ) {
			QtThread::safeAsync( [dialogExists,romsProcessed,&dialog](){
				if( !*dialogExists ) return;
				dialog.setValue( romsProcessed );
			});

			processRom( rom, romInfoTable, romFiles, fixEncoding );
			romsProcessed++;
		}

		QtThread::safeAsync( [dialogExists,&dialog](){
			if( !*dialogExists ) return;
			dialog.setLabelText( "Moving rom information to the database..." );
			dialog.setRange( 0, 0 );
			dialog.setValue( 0 );
		});

		SqlTransaction transaction;
		foreach_cvalue( romInfo, romInfoTable ) {
			DataProvider::addRomInfo( romInfo );
		}
		for( const RomFile &romFile : romFiles ) {
			DataProvider::addRomFile( romFile );
		}
		transaction.commit();

		QtThread::safeAsync( [dialogExists,&migrationFinished,&dialog](){
			if( !*dialogExists ) return;
			migrationFinished = true;
			dialog.close();
		});
	});

	dialog.exec();

	*dialogExists = false;
	migrationWorker.join();

	std::error_code err;
	fs::remove( filePath, err );
}

static inline void migrateGroupsToSqlite() {
	const fs::path filePath = BaseDir::data() / "groups.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream groupsFile( filePath );
	const Json groupListJson = Json::parse( groupsFile );
	groupsFile.close();

	if( !groupListJson.isArray() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &groups = groupListJson.array();
	if( groups.empty() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	SqlTransaction transaction;
	for( const Json &group : groups ) {
		const string groupName = group.getOrDefault<string>( "" );
		if( groupName.empty() || groupName == "Favourites" ) continue;
		DataProvider::addGroup( groupName );
	}
	DataProvider::addGroup( SpecialGroups::Favourites );
	transaction.commit();


	std::error_code err;
	fs::remove( filePath, err );
}

static inline void migrateManualRomPaths() {
	const fs::path filePath = BaseDir::data() / "sources2.json";
	if( !fs::isRegularFileSafe( filePath ) ) return;

	std::ifstream pathsFile( filePath );
	const Json pathListJson = Json::parse( pathsFile );
	pathsFile.close();

	if( !pathListJson.isArray() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	const JArray &romPaths = pathListJson.array();
	if( romPaths.empty() ) {
		std::error_code err;
		fs::remove( filePath, err );
	}

	SqlTransaction transaction;
	for( const Json &romPath : romPaths ) {
		const fs::path path = fs::to_path( romPath.getOrDefault<string>( "" ) );
		if( path.empty() || !fs::existsSafe( path ) ) continue;
		DataProvider::addManualRomPath( path );
	}
	transaction.commit();

	std::error_code err;
	fs::remove( filePath, err );
}

static inline void removeNullTerminators() {
	SqlBatch( R"#(
UPDATE ROMS SET
sha1 = substr( sha1, 0 ),
name = substr( name, 0 ),
internal_name = substr( internal_name, 0 );

UPDATE ROM_PATHS SET
path = substr( path, 0 ),
sha1 = substr( sha1, 0 );

UPDATE ROM_GROUPS SET
sha1 = substr( sha1, 0 ),
group_name = substr( group_name, 0 );

UPDATE PERSISTENT_GROUPS SET
name = substr( name, 0 );

UPDATE MANUAL_ROM_PATHS SET
path = substr( path, 0 );
)#"
	).execNonQuery();
}

static inline void clearRomNameField() {
	SqlCommand cmd( R"#(
UPDATE ROMS
SET name = ?1
)#"
	);
	cmd.addParameter( "", DATA_COPY );
	cmd.execNonQuery();
}

static inline void cleanupOrphanedData() {
	SqlCommand( R"#(
DELETE FROM ROM_GROUPS
WHERE sha1 NOT IN( SELECT sha1 FROM ROMS )
)#"
	).execNonQuery();
}

void Migration::run() {
	AppSettings settings = FileController::loadAppSettings();

	if( settings.migrationState < 2 ) {
		RetroArch::migrateSaves();
	}

	if( settings.migrationState < 3 ) {
		migrateRomsToSqlite( settings.migrationState < 1 );
		migrateGroupsToSqlite();
		migrateManualRomPaths();
	}

	if( settings.migrationState < 4 ) {
		removeNullTerminators();
		clearRomNameField();
	}

	if( settings.migrationState < 5 ) {
		cleanupOrphanedData();
	}

	settings.migrationState = 4;
	FileController::saveAppSettings( settings );
}
