#include "src/core/logging.hpp"

#include "src/core/time.hpp"
#include "src/db/data-provider.hpp"

#ifdef DEBUG
#include <iostream>

void Logs::write( LogLevel level, string &&message ) noexcept {
	string msg = message;
	switch( level ) {
		case LogLevel::Debug:
			std::cout << "[DEBUG] " << msg << std::endl << std::flush; break;
		case LogLevel::Info:
			std::cout << "[INFO] " << msg << std::endl << std::flush; break;
		case LogLevel::Warn:
			std::cout << "[WARN] " << msg << std::endl << std::flush; break;
		case LogLevel::Error:
			std::cerr << "[ERROR] " << msg << std::endl << std::flush; break;
		case LogLevel::Fatal:
			std::cerr << "[FATAL] " << msg << std::endl << std::flush; break;
	}

	DataProvider::addLogEntry({
		level,
		Time::nowMs(),
		std::move( msg )
	});
}
#else
void Logs::write( LogLevel level, string &&message ) noexcept {
	DataProvider::addLogEntry({
		level,
		Time::nowMs(),
		message
	});
}
#endif

std::vector<LogEntry> Logs::fetch() {
	return DataProvider::fetchLogs();
}
