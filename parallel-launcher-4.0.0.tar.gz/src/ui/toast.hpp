#ifndef SRC_UI_TOAST_HPP_
#define SRC_UI_TOAST_HPP_

#include <string>
#include <QMainWindow>

enum class ToastType {
	Info,
	Warn,
	Error
};

namespace ToastMessageManager {

	extern void setWindow( QMainWindow *window );

	extern void display( ToastType type, const char *message );

	inline void display( ToastType type, const std::string &message ) {
		display( type, message.c_str() );
	}

};




#endif /* SRC_UI_TOAST_HPP_ */
