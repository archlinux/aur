#ifndef SRC_DB_DATA_PROVIDER_HPP_
#define SRC_DB_DATA_PROVIDER_HPP_

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>
#include "src/rhdc/core/hack.hpp"
#include "src/core/logging.hpp"
#include "src/core/rom.hpp"
#include "src/types.hpp"

namespace DataProvider {

	extern void addRomInfo( const RomInfo &romInfo ) noexcept;
	extern void addRomFile( const RomFile &romFile );

	extern void addGroup( const string &groupName ) noexcept;
	extern void deleteGroup( const string &groupName ) noexcept;
	extern void renameGroup( const string &oldName, const string &newName ) noexcept;

	extern void updateRomEmulator( const string &sha1, EmulatorCore core ) noexcept;
	extern void updateRomParallelPlugin( const string &sha1, GfxPlugin plugin ) noexcept;
	extern void updateRomMupenPlugin( const string &sha1, GfxPlugin plugin ) noexcept;
	extern void updateRomCpuOverclocking( const string &sha1, bool overclock ) noexcept;
	extern void updateRomViOverclocking( const string &sha1, bool overclock ) noexcept;
	extern void updateRomWidescreen( const string &sha1, bool widescreen ) noexcept;
	extern void updateRomInputMode( const string &sha1, const Uuid &inputModeId ) noexcept;
	extern void updatePlayTime( const string &sha1, int64 lastPlayed, int64 playTime ) noexcept;
	extern void renameRom( const string &sha1, const string &name ) noexcept;

	extern bool tryFetchRomByHash( const string &sha1, bool includeGroups, RomInfo *romInfo ) noexcept;
	extern bool tryFetchRomByPath( const fs::path &filePath, bool includeGroups, RomInfo *romInfo, RomFile *romFile = nullptr );
	extern bool tryFetchRomFile( const fs::path &filePath, RomFile *romFile );

	extern bool tryFetchRomPathWithCrc32( uint crc32, fs::path &filePath );
	extern bool tryFetchRomPathWithSha1( const string &sha1, fs::path &filePath );

	extern int countRomFilesWithSha1( const string &sha1 ) noexcept;
	extern int countRomsInGroup( const string &groupName ) noexcept;

	extern bool romWithSha1Exists( const string &sha1 ) noexcept;
	extern bool romWithPathExists( const fs::path &filePath );

	extern std::set<string> fetchPersistentGroups();
	extern std::vector<string> fetchAllGroups();
	extern std::vector<RomFile> fetchRomFiles();
	extern HashMap<string,RomInfo> fetchAllRomInfo();
	extern HashSet<string> fetchAllKnownChecksums();

	extern std::vector<fs::path> fetchManualRomPaths();
	extern void addManualRomPath( const fs::path &path );
	extern void deleteManualRomPath( const fs::path &path );
	extern void deleteAllManualRomPaths() noexcept;

	extern void updateRomFile( const RomFile &romFile ) noexcept;

	extern void cloneRomInfo(
		const string &oldSha1,
		const string &newSha1,
		const string &internalName,
		uint crc32
	) noexcept;

	extern void deleteRomPath( const fs::path &filePath );
	extern void deleteRomInfo( const string &sha1 ) noexcept;

	extern void addToGroup( const string &sha1, const string &groupName ) noexcept;
	extern void removeFromGroup( const string &sha1, const string &groupName ) noexcept;

	/* rhdc */

	extern void addOrUpdateRhdcHack( const RhdcHackInfo &hack ) noexcept;
	extern void addRhdcHackVersion( const string &hackId, const string &sha1 ) noexcept;

	extern void clearRhdcHacks() noexcept;

	extern void updateRhdcProgress( const string &hackId, const RhdcHackProgress &progress ) noexcept;
	extern void updateRhdcHackRating( const string &hackId, ubyte quality, ubyte difficulty ) noexcept;
	extern void updateRhdcStarProgress( const string &hackId, ushort stars, bool completed ) noexcept;
	extern void suggestRhdcHackPlayTime( const string &hackId, int64 playTime ) noexcept;

	extern HashMap<string,BasicRhdcHack> fetchFollowedRhdcHacks();
	extern HashMap<string,string> fetchAllRhdcHackVersions();
	extern HashMap<string,StarpowerExt> fetchAllStarpower();

	extern bool tryFetchRhdcHackByChecksum( const string &sha1, RhdcHack *hack ) noexcept;

	extern std::set<string> fetchGroupsForRhdcHack( const string &hackId );
	extern void addRhdcHackToGroup( const string &hackId, const string &groupName ) noexcept;

	extern bool hasRhdcData() noexcept;
	extern void clearAllRhdcData() noexcept;

	/* logging */

	extern void addLogEntry( const LogEntry &logEntry ) noexcept;
	extern std::vector<LogEntry> fetchLogs();

}



#endif /* SRC_DB_DATA_PROVIDER_HPP_ */
