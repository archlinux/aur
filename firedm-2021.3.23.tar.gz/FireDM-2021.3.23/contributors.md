I would like to thank everyone who contributed in this project in any
way, with code, bug reports, or ideas.

If you think your name should be included in this list or want to modify
your name please make an issue, pull request, or send an email to
info.pyidm@gmail.com

---

Developers who contributed with code:

- @Aboghazala
- @shin-illua
- @ryneeverett
- @bertaga

---

People who contributed with Testing, ideas, and bug reports:
- Toni (@Ton1A)
- @smaragdus
- @hongyi-zhao

