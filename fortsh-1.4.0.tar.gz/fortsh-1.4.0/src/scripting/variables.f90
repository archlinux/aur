! ==============================================================================
! Module: variables
! Purpose: Shell variable management and assignment  
! ==============================================================================
module variables
  use shell_types
  use system_interface
  use iso_fortran_env, only: output_unit, error_unit
  implicit none

contains

  subroutine set_shell_variable(shell, name, value)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: name, value
    integer :: i, empty_slot
    
    
    empty_slot = -1
    
    ! Check if variable already exists
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name)) then
        shell%variables(i)%value = value
        return
      end if
    end do
    
    ! Find empty slot  
    do i = 1, size(shell%variables)
      ! Check for empty name (null character or spaces)
      if (shell%variables(i)%name(1:1) == char(0) .or. trim(shell%variables(i)%name) == '') then
        empty_slot = i
        exit
      end if
    end do
    
    ! Add new variable
    if (empty_slot > 0) then
      shell%variables(empty_slot)%name = name
      shell%variables(empty_slot)%value = value
      shell%num_variables = shell%num_variables + 1
    end if
  end subroutine

  function get_shell_variable(shell, name) result(value)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    character(len=1024) :: value
    integer :: i
    
    value = ''
    
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name)) then
        value = shell%variables(i)%value
        return
      end if
    end do
  end function

  function is_assignment(input_line) result(is_assign)
    character(len=*), intent(in) :: input_line
    logical :: is_assign
    integer :: eq_pos
    
    eq_pos = index(input_line, '=')
    is_assign = (eq_pos > 1 .and. eq_pos < len_trim(input_line))
  end function

  subroutine handle_assignment(shell, input_line)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: input_line
    integer :: eq_pos
    character(len=256) :: var_name, var_value
    character(len=:), allocatable :: expanded_value
    
    eq_pos = index(input_line, '=')
    if (eq_pos > 1) then
      var_name = input_line(:eq_pos-1)
      var_value = input_line(eq_pos+1:)
      
      ! Check for array assignment: var=(value1 value2 value3)
      if (len_trim(var_value) > 2 .and. var_value(1:1) == '(' .and. &
          var_value(len_trim(var_value):len_trim(var_value)) == ')') then
        call handle_array_assignment(shell, trim(var_name), var_value)
      else
        ! Simple variable expansion during assignment
        call simple_expand_variables(var_value, expanded_value, shell)
        call set_shell_variable(shell, trim(var_name), expanded_value)
      end if
      shell%last_exit_status = 0
    else
      shell%last_exit_status = 1
    end if
  end subroutine

  subroutine handle_array_assignment(shell, var_name, array_expr)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: var_name, array_expr
    character(len=1024) :: values(100)
    integer :: count, i, start_pos, pos
    character(len=1024) :: content
    logical :: in_quotes
    
    ! Remove parentheses
    content = array_expr(2:len_trim(array_expr)-1)
    
    count = 0
    pos = 1
    start_pos = 1
    in_quotes = .false.
    
    ! Parse space-separated values, respecting quotes
    do while (pos <= len_trim(content))
      if (content(pos:pos) == '"' .or. content(pos:pos) == "'") then
        in_quotes = .not. in_quotes
      else if (content(pos:pos) == ' ' .and. .not. in_quotes) then
        if (pos > start_pos) then
          count = count + 1
          if (count <= 100) then
            values(count) = content(start_pos:pos-1)
            ! Remove quotes if present
            if (len_trim(values(count)) >= 2) then
              if ((values(count)(1:1) == '"' .and. values(count)(len_trim(values(count)):len_trim(values(count))) == '"') .or. &
                  (values(count)(1:1) == "'" .and. values(count)(len_trim(values(count)):len_trim(values(count))) == "'")) then
                values(count) = values(count)(2:len_trim(values(count))-1)
              end if
            end if
          end if
        end if
        start_pos = pos + 1
      end if
      pos = pos + 1
    end do
    
    ! Handle last value
    if (start_pos <= len_trim(content)) then
      count = count + 1
      if (count <= 100) then
        values(count) = content(start_pos:)
        ! Remove quotes if present
        if (len_trim(values(count)) >= 2) then
          if ((values(count)(1:1) == '"' .and. values(count)(len_trim(values(count)):len_trim(values(count))) == '"') .or. &
              (values(count)(1:1) == "'" .and. values(count)(len_trim(values(count)):len_trim(values(count))) == "'")) then
            values(count) = values(count)(2:len_trim(values(count))-1)
          end if
        end if
      end if
    end if
    
    if (count > 0) then
      call set_array_variable(shell, var_name, values, count)
    end if
  end subroutine

  subroutine simple_expand_variables(input, expanded, shell)
    character(len=*), intent(in) :: input
    character(len=:), allocatable, intent(out) :: expanded
    type(shell_state_t), intent(in) :: shell
    
    character(len=1024) :: result
    integer :: i, j, var_start
    character(len=256) :: var_name
    character(len=1024) :: var_value
    character(len=:), allocatable :: env_value
    
    result = ''
    i = 1
    j = 1
    
    do while (i <= len_trim(input))
      if (input(i:i) == '$' .and. i < len_trim(input)) then
        i = i + 1
        var_start = i
        
        ! Extract variable name  
        do while (i <= len_trim(input))
          if (.not. (is_alnum(input(i:i)) .or. input(i:i) == '_')) exit
          i = i + 1
        end do
        
        var_name = input(var_start:i-1)
        
        ! Check shell variables first
        var_value = get_shell_variable(shell, trim(var_name))
        if (len_trim(var_value) > 0) then
          result(j:j+len_trim(var_value)-1) = trim(var_value)
          j = j + len_trim(var_value)
        else
          ! Fall back to environment variables
          env_value = get_environment_var(trim(var_name))
          if (allocated(env_value) .and. len(env_value) > 0) then
            result(j:j+len(env_value)-1) = env_value
            j = j + len(env_value)
          end if
        end if
      else
        result(j:j) = input(i:i)
        i = i + 1
        j = j + 1
      end if
    end do
    
    expanded = trim(result)
    
  contains
    function is_alnum(ch) result(res)
      character, intent(in) :: ch
      logical :: res
      res = (ch >= 'a' .and. ch <= 'z') .or. &
            (ch >= 'A' .and. ch <= 'Z') .or. &
            (ch >= '0' .and. ch <= '9')
    end function
  end subroutine

  subroutine add_function(shell, name, body_lines, body_count)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: name
    character(len=*), intent(in) :: body_lines(:)
    integer, intent(in) :: body_count
    integer :: i, j
    
    ! Find empty slot or replace existing function
    do i = 1, size(shell%functions)
      if (trim(shell%functions(i)%name) == trim(name) .or. len_trim(shell%functions(i)%name) == 0) then
        shell%functions(i)%name = name
        shell%functions(i)%body_lines = body_count
        
        if (allocated(shell%functions(i)%body)) deallocate(shell%functions(i)%body)
        allocate(shell%functions(i)%body(body_count))
        
        do j = 1, body_count
          shell%functions(i)%body(j) = body_lines(j)
        end do
        
        shell%num_functions = max(shell%num_functions, i)
        return
      end if
    end do
  end subroutine

  function is_function(shell, name) result(found)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    logical :: found
    integer :: i
    
    found = .false.
    do i = 1, shell%num_functions
      if (trim(shell%functions(i)%name) == trim(name)) then
        found = .true.
        return
      end if
    end do
  end function

  function get_function_body(shell, name) result(body)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    character(len=1024), allocatable :: body(:)
    integer :: i
    
    do i = 1, shell%num_functions
      if (trim(shell%functions(i)%name) == trim(name)) then
        if (allocated(shell%functions(i)%body)) then
          allocate(body(shell%functions(i)%body_lines))
          body = shell%functions(i)%body(1:shell%functions(i)%body_lines)
        end if
        return
      end if
    end do
  end function

  ! Array variable functions
  subroutine set_array_variable(shell, name, values, count)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: name
    character(len=*), intent(in) :: values(:)
    integer, intent(in) :: count
    integer :: i, empty_slot
    
    empty_slot = -1
    
    ! Check if variable already exists
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name)) then
        if (allocated(shell%variables(i)%array_values)) deallocate(shell%variables(i)%array_values)
        allocate(shell%variables(i)%array_values(count))
        shell%variables(i)%array_values(1:count) = values(1:count)
        shell%variables(i)%array_size = count
        shell%variables(i)%is_array = .true.
        return
      end if
    end do
    
    ! Find empty slot
    do i = 1, size(shell%variables)
      if (shell%variables(i)%name(1:1) == char(0) .or. trim(shell%variables(i)%name) == '') then
        empty_slot = i
        exit
      end if
    end do
    
    ! Add new array variable
    if (empty_slot > 0) then
      shell%variables(empty_slot)%name = name
      shell%variables(empty_slot)%is_array = .true.
      shell%variables(empty_slot)%array_size = count
      if (allocated(shell%variables(empty_slot)%array_values)) deallocate(shell%variables(empty_slot)%array_values)
      allocate(shell%variables(empty_slot)%array_values(count))
      shell%variables(empty_slot)%array_values(1:count) = values(1:count)
      shell%num_variables = shell%num_variables + 1
    end if
  end subroutine

  function get_array_element(shell, name, index) result(value)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    integer, intent(in) :: index
    character(len=1024) :: value
    integer :: i
    
    value = ''
    
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name) .and. shell%variables(i)%is_array) then
        if (index >= 1 .and. index <= shell%variables(i)%array_size) then
          value = shell%variables(i)%array_values(index)
        end if
        return
      end if
    end do
  end function

  function get_array_all_elements(shell, name) result(result_str)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    character(len=4096) :: result_str
    integer :: i, j
    
    result_str = ''
    
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name) .and. shell%variables(i)%is_array) then
        do j = 1, shell%variables(i)%array_size
          if (j > 1) result_str = trim(result_str) // ' '
          result_str = trim(result_str) // trim(shell%variables(i)%array_values(j))
        end do
        return
      end if
    end do
  end function

  function get_array_size(shell, name) result(size)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    integer :: size
    integer :: i
    
    size = 0
    
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name) .and. shell%variables(i)%is_array) then
        size = shell%variables(i)%array_size
        return
      end if
    end do
  end function

  subroutine declare_associative_array(shell, name)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: name
    
    integer :: i, empty_slot
    
    empty_slot = -1
    
    ! Check if variable already exists
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name)) then
        ! Convert to associative array
        shell%variables(i)%is_assoc_array = .true.
        shell%variables(i)%is_array = .false.
        if (.not. allocated(shell%variables(i)%assoc_entries)) then
          allocate(shell%variables(i)%assoc_entries(50))  ! Initial size
        end if
        shell%variables(i)%assoc_size = 0
        return
      end if
    end do
    
    ! Find empty slot  
    do i = 1, size(shell%variables)
      if (shell%variables(i)%name(1:1) == char(0) .or. trim(shell%variables(i)%name) == '') then
        empty_slot = i
        exit
      end if
    end do
    
    ! Add new associative array variable
    if (empty_slot > 0) then
      shell%variables(empty_slot)%name = name
      shell%variables(empty_slot)%value = ''
      shell%variables(empty_slot)%is_assoc_array = .true.
      shell%variables(empty_slot)%is_array = .false.
      allocate(shell%variables(empty_slot)%assoc_entries(50))
      shell%variables(empty_slot)%assoc_size = 0
      shell%num_variables = shell%num_variables + 1
    else
      write(error_unit, '(a)') 'declare: too many variables defined'
    end if
  end subroutine

  subroutine set_assoc_array_value(shell, array_name, key, value)
    type(shell_state_t), intent(inout) :: shell
    character(len=*), intent(in) :: array_name, key, value
    
    integer :: i, j
    
    ! Find the associative array variable
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(array_name) .and. &
          shell%variables(i)%is_assoc_array) then
        
        ! Check if key already exists
        do j = 1, shell%variables(i)%assoc_size
          if (trim(shell%variables(i)%assoc_entries(j)%key) == trim(key)) then
            shell%variables(i)%assoc_entries(j)%value = value
            return
          end if
        end do
        
        ! Add new key-value pair
        if (shell%variables(i)%assoc_size < size(shell%variables(i)%assoc_entries)) then
          shell%variables(i)%assoc_size = shell%variables(i)%assoc_size + 1
          shell%variables(i)%assoc_entries(shell%variables(i)%assoc_size)%key = key
          shell%variables(i)%assoc_entries(shell%variables(i)%assoc_size)%value = value
        else
          write(error_unit, '(a)') 'associative array: too many entries'
        end if
        return
      end if
    end do
    
    write(error_unit, '(a)') 'associative array: ' // trim(array_name) // ' not declared'
  end subroutine

  function get_assoc_array_value(shell, array_name, key) result(value)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: array_name, key
    character(len=1024) :: value
    
    integer :: i, j
    
    value = ''
    
    ! Find the associative array variable
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(array_name) .and. &
          shell%variables(i)%is_assoc_array) then
        
        ! Find the key
        do j = 1, shell%variables(i)%assoc_size
          if (trim(shell%variables(i)%assoc_entries(j)%key) == trim(key)) then
            value = shell%variables(i)%assoc_entries(j)%value
            return
          end if
        end do
        return  ! Key not found, return empty string
      end if
    end do
  end function

  subroutine get_assoc_array_keys(shell, array_name, keys, num_keys)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: array_name
    character(len=256), intent(out) :: keys(:)
    integer, intent(out) :: num_keys
    
    integer :: i, j
    
    num_keys = 0
    
    ! Find the associative array variable
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(array_name) .and. &
          shell%variables(i)%is_assoc_array) then
        
        num_keys = min(shell%variables(i)%assoc_size, size(keys))
        do j = 1, num_keys
          keys(j) = shell%variables(i)%assoc_entries(j)%key
        end do
        return
      end if
    end do
  end subroutine

  function is_associative_array(shell, name) result(is_assoc)
    type(shell_state_t), intent(in) :: shell
    character(len=*), intent(in) :: name
    logical :: is_assoc
    
    integer :: i
    
    is_assoc = .false.
    do i = 1, shell%num_variables
      if (trim(shell%variables(i)%name) == trim(name)) then
        is_assoc = shell%variables(i)%is_assoc_array
        return
      end if
    end do
  end function

end module variables