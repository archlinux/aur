/*! © Andrea Giammarchi @WebReflection */

/* jshint esversion: 6, strict: true, node: true */

// partially populated at runtime on bootstrap

(function (exports) {'use strict';

  exports.JSGTK = true;

}(this));
