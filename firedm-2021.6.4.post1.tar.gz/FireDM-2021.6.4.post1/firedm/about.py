about_notes = """FireDM is an open source multi-connections download manager, it downloads
general files, support downloading videos, and playlists from youtube, 
and other media websites.

Developed in Python, based on "LibCurl", and "youtube_dl"
  
This application is free to use, in a hope to be useful for someone,

Conditions and usage restrictions:
------------------------------------------------------------------------
  - The following contents are not allowed to be downloaded using this
    application: 
       - DRM "Digital rights management", protected videos / streams 
         or Copyright materials. 
       - Porn videos/streams or any pornography materials
       - Illegal contents or any material that encourage/promote violence
         or criminal/illegal behaviours.
  
  - This application is provided "AS IS" without any warranty, it is 
    under no circumstances the FireDM author could be held liable for any 
    claim, or damages or responsible for any misuse of this application.
------------------------------------------------------------------------

your feedback is most welcomed on:
https://github.com/firedm/FireDM
email: info.pyidm@gmail.com

Author,
Mahmoud Elshahat
2019-2021"""