### ToDo List and plans for this project

- snap or flatpack for linux.
- browser integration.

