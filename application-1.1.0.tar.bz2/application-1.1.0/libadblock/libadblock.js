const fs = require("fs");
const { createRequire } = require("module");
const path = require("path");

const LIBADBLOCK_VERSION = require("./package.json").version;
const STORAGE_SCHEMA_VERSION = 1;
const STORAGE_DIR_NAME = "libadblock";
const ENGINE_CACHE_FILE = "adblock-engine.bin";
const METADATA_FILE = "metadata.json";
const REFRESH_LOCK_FILE = "refresh.lock";
const LIBADBLOCK_PRELOAD_FILE = "libadblock-preload.js";
const RESOURCES_DIR_NAME = "resources";
const TWITCH_ADBLOCK_RESOURCE_FILE = "twitch-videoad.js";
const COSMETIC_FILTER_STATE = Symbol.for("libadblock.cosmeticFilterState");
const TWITCH_ADBLOCK_FILTER_LIST = "! libadblock Twitch video ad scriptlet\ntwitch.tv##+js(twitch-videoad)";
const REFRESH_LOCK_TTL_MS = 10 * 60 * 1000;
const FILTERLIST_REFRESH_INTERVAL_MS = 6 * 60 * 60 * 1000;
const REMOTE_FILTER_LISTS = Object.freeze([]);
const FILTER_FILE_NAMES = Object.freeze({
  remoteFilterLists: "filterlists.txt",
  browserBlocklist: "browserblocklist.txt",
  browserWhitelist: "browserwhitelist.txt",
  browserCosmeticFilters: "browsercosmeticfilters.txt",
  trackerBlocklist: "trackerblocklist.txt",
  trackerStrictBlocklist: "trackerstrictblocklist.txt",
  popupBlocklist: "popupblocklist.txt",
  popupWhitelist: "popupwhitelist.txt",
  drmSites: "drmsites.txt",
  userAgentOverrides: "useragentoverrides.txt"
});
const FILTER_REMOTE_URLS = Object.freeze(Object.fromEntries(
  Object.entries(FILTER_FILE_NAMES).map(([key, fileName]) => [
    key,
    `https://gitlab.com/linuxbombay/libelectron/libadblock/filters/-/raw/main/${fileName}`
  ])
));
function isFileOlderThan(filePath, maxAgeMs) {
  try {
    return Date.now() - fs.statSync(filePath).mtimeMs > maxAgeMs;
  } catch {
    return true;
  }
}

function isAnyFileNewerThan(filePaths, targetFile) {
  if (!Array.isArray(filePaths) || !filePaths.length) return false;

  try {
    const targetMtime = fs.statSync(targetFile).mtimeMs;
    return filePaths.some((filePath) => {
      try {
        return fs.statSync(filePath).mtimeMs > targetMtime;
      } catch {
        return false;
      }
    });
  } catch {
    return false;
  }
}

function getDefaultAppDataPath(app) {
  try {
    if (app?.getPath) return app.getPath("appData");
  } catch {}

  if (process.platform === "win32") {
    return process.env.APPDATA || path.join(process.env.USERPROFILE || process.cwd(), "AppData", "Roaming");
  }

  if (process.platform === "darwin") {
    return path.join(process.env.HOME || process.cwd(), "Library", "Application Support");
  }

  return process.env.XDG_CONFIG_HOME || path.join(process.env.HOME || process.cwd(), ".config");
}

function getDefaultFilterlistDir(app) {
  return path.join(getDefaultAppDataPath(app), STORAGE_DIR_NAME);
}

function readJsonFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) return null;
    const parsed = JSON.parse(fs.readFileSync(filePath, "utf8"));
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function writeJsonFile(filePath, value) {
  try {
    const tempFile = `${filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(value, null, 2), {
      mode: 0o600
    });
    fs.renameSync(tempFile, filePath);
  } catch {}
}

function getFilterSetVersion(remoteFilterLists = REMOTE_FILTER_LISTS) {
  const lists = Array.isArray(remoteFilterLists) ? remoteFilterLists : REMOTE_FILTER_LISTS;
  return lists.join("\n");
}

function getDataUrlText(value) {
  const url = String(value || "");
  if (!url.startsWith("data:")) return null;

  const commaIndex = url.indexOf(",");
  if (commaIndex === -1) return "";

  const metadata = url.slice(5, commaIndex).toLowerCase();
  const body = url.slice(commaIndex + 1);
  if (metadata.split(";").includes("base64")) {
    return Buffer.from(body, "base64").toString("utf8");
  }

  return decodeURIComponent(body.replace(/\+/g, "%20"));
}

function createFetchWithDataUrlSupport(fetchImpl) {
  return async (url, requestOptions) => {
    const dataUrlText = getDataUrlText(url);
    if (dataUrlText !== null) {
      return {
        ok: true,
        status: 200,
        text: async () => dataUrlText
      };
    }

    return fetchImpl(url, requestOptions);
  };
}

function getBundledResourcePath(fileName) {
  return path.join(__dirname, RESOURCES_DIR_NAME, fileName);
}

function getBundledRemoteFilterListsFile() {
  return path.join(__dirname, FILTER_FILE_NAMES.remoteFilterLists);
}

function getBundledTextResource(fileName) {
  try {
    return fs.readFileSync(getBundledResourcePath(fileName), "utf8");
  } catch {
    return "";
  }
}

function extractUboResourceScript(resourceText) {
  const text = String(resourceText || "").trim();
  const firstNewline = text.indexOf("\n");
  return (firstNewline === -1 ? text : text.slice(firstNewline + 1)).trim();
}

function extractUboScriptletBody(resourceText) {
  const body = extractUboResourceScript(resourceText);
  const match = body.match(/^\((function\s*\([^)]*\)\s*\{[\s\S]*\})\)\s*\(\s*\)\s*;?$/);
  return match ? match[1] : "";
}

function getTwitchAdblockSource() {
  return extractUboResourceScript(getBundledTextResource(TWITCH_ADBLOCK_RESOURCE_FILE));
}

function createResourceFetch(fetchImpl, options = {}) {
  const { enableTwitchAdBlocking = true } = options;
  const fetchWithDataUrlSupport = createFetchWithDataUrlSupport(fetchImpl);

  return async (url, requestOptions) => {
    const response = await fetchWithDataUrlSupport(url, requestOptions);
    if (!enableTwitchAdBlocking || !String(url || "").endsWith("/ublock-origin/resources.json")) return response;

    const originalResourcesText = await response.text();

    try {
      const resources = JSON.parse(originalResourcesText);
      const body = extractUboScriptletBody(getBundledTextResource(TWITCH_ADBLOCK_RESOURCE_FILE));
      if (!body) throw new Error("empty Twitch scriptlet");

      const scriptlets = Array.isArray(resources.scriptlets) ? resources.scriptlets : [];
      resources.scriptlets = scriptlets.filter((scriptlet) => scriptlet?.name !== "twitch-videoad" && !scriptlet?.aliases?.includes?.("twitch-videoad"));
      resources.scriptlets.push({
        name: "twitch-videoad",
        aliases: ["twitch-videoad.js"],
        body,
        dependencies: [],
        executionWorld: "MAIN",
        requiresTrust: false
      });

      const text = JSON.stringify(resources);
      return {
        ok: true,
        status: 200,
        text: async () => text
      };
    } catch {
      return {
        ok: true,
        status: 200,
        text: async () => originalResourcesText
      };
    }
  };
}

function getChromeDetailsFromUserAgent(userAgent) {
  const chromeVersion = String(String(userAgent || "").match(/\bChrome\/([^\s]+)/i)?.[1] || "").trim();
  const chromeMajor = String(chromeVersion.split(".")[0] || "").trim();
  return { chromeVersion, chromeMajor };
}

function getClientHintPlatformFromUserAgent(userAgent) {
  const value = String(userAgent || "");
  if (/Windows NT/i.test(value)) return "Windows";
  if (/Mac OS X|Macintosh/i.test(value)) return "macOS";
  if (/Android/i.test(value)) return "Android";
  if (/Linux/i.test(value)) return "Linux";
  return "";
}

function readChromeVersionFromUserAgentOverrides(filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return "";

    for (const line of fs.readFileSync(filePath, "utf8").split(/\r?\n/)) {
      const trimmed = line.trim();
      const extensionPrefix = "! libelectron-chrome-version:";
      if (!trimmed.toLowerCase().startsWith(extensionPrefix)) continue;

      const version = trimmed.slice(extensionPrefix.length).trim();
      if (/^\d+(?:\.\d+){0,3}$/.test(version)) return version;
    }
  } catch {}

  return "";
}

function resolveBuiltInUserAgentOverrideValue(value, options = {}) {
  const normalizedValue = String(value || "").trim();
  if (normalizedValue !== "PHOENIX_WINDOWS") return "";

  const chromeVersion = options.chromeVersion || readChromeVersionFromUserAgentOverrides(options.filePath) || "151.0.0.0";
  return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeVersion} Safari/537.36`;
}

function resolveUserAgentOverrideValue(value, options = {}) {
  return resolveBuiltInUserAgentOverrideValue(value, options) || String(value || "").replaceAll("$chromeversion", options.chromeVersion || readChromeVersionFromUserAgentOverrides(options.filePath) || "151.0.0.0");
}

function createLibadblockPreloadSource(options = {}) {
  const { enableTwitchAdBlocking = true, enableYoutubeAdBlocking = true, youtubeDisabledSites = [], userAgentOverrideRules = [] } = options;
  const twitchSource = JSON.stringify(`${enableTwitchAdBlocking ? getTwitchAdblockSource() : ""}\n//# sourceURL=libadblock-twitch.js`);
  const disabledSites = JSON.stringify(Array.isArray(youtubeDisabledSites) ? youtubeDisabledSites : []);
  const userAgentOverrides = JSON.stringify((Array.isArray(userAgentOverrideRules) ? userAgentOverrideRules : []).map((rule) => {
    const host = String(rule?.host || "").trim().toLowerCase();
    const userAgent = String(rule?.userAgent || "").trim();
    if (!host || !userAgent) return null;
    const { chromeVersion, chromeMajor } = getChromeDetailsFromUserAgent(userAgent);
    return { host, userAgent, chromeVersion, chromeMajor, platform: getClientHintPlatformFromUserAgent(userAgent) };
  }).filter(Boolean));
  const youtubeSource = JSON.stringify(`(() => {
      if (!location.hostname.endsWith("youtube.com")) return;

      const comparableHost = location.hostname.split(".").filter(Boolean).slice(-2).join(".");
      if (globalThis.__libadblockDisabledSites?.includes?.(comparableHost)) return;
      if (globalThis.__libadblockYouTubeMainWorldLoaded) return;
      globalThis.__libadblockYouTubeMainWorldLoaded = true;

      const nativeJsonParse = JSON.parse;
      const AD_KEYS = new Set(["adBreakHeartbeatParams", "adPlacements", "adSlots", "playerAds"]);
      const PLAYER_RESPONSE_URL_RE = /(?:\/youtubei\/v1\/player|\/get_video_info)/;
      const isPlayerResponseUrl = (value) => {
        try {
          const url = typeof value === "string" ? value : value?.url || String(value || "");
          return PLAYER_RESPONSE_URL_RE.test(url);
        } catch {
          return false;
        }
      };
      const stripAdsDeep = (obj) => {
        const seen = new WeakSet();
        const visit = (value) => {
          if (!value || typeof value !== "object" || seen.has(value)) return;
          seen.add(value);
          if (value.playerResponse && typeof value.playerResponse === "string") {
            try {
              const playerResponse = nativeJsonParse(value.playerResponse);
              visit(playerResponse);
              value.playerResponse = JSON.stringify(playerResponse);
            } catch {}
          } else if (value.playerResponse && typeof value.playerResponse === "object") {
            visit(value.playerResponse);
          }
          if (value.playerConfig && typeof value.playerConfig === "object") {
            delete value.playerConfig.adBreaks;
            delete value.playerConfig.adCueRanges;
          }
          for (const key of Object.keys(value)) {
            if (AD_KEYS.has(key)) {
              delete value[key];
              continue;
            }
            visit(value[key]);
          }
        };
        visit(obj);
        return obj;
      };
      try {
        const descriptor = Object.getOwnPropertyDescriptor(window, "ytInitialPlayerResponse");
        if (!descriptor || descriptor.configurable) {
          Object.defineProperty(window, "ytInitialPlayerResponse", {
            configurable: true,
            get() { return this.__libadblockYtInitialPlayerResponse; },
            set(value) {
              try { stripAdsDeep(value); } catch {}
              this.__libadblockYtInitialPlayerResponse = value;
            }
          });
        }
      } catch {}
      const sanitizeResponseText = (text) => {
        if (typeof text !== "string" || !text.trim()) return null;
        if (!["\\\"adPlacements\\\"", "\\\"adSlots\\\"", "\\\"playerAds\\\"", "\\\"adBreakHeartbeatParams\\\""].some((marker) => text.includes(marker))) return null;
        const xssiPrefix = text.startsWith(")]}'") ? text.match(/^\)\]\}'\s*\n?/u)?.[0] || "" : "";
        const jsonText = xssiPrefix ? text.slice(xssiPrefix.length) : text;
        try {
          const json = nativeJsonParse(jsonText);
          stripAdsDeep(json);
          return xssiPrefix + JSON.stringify(json);
        } catch {
          return null;
        }
      };
      const realFetch = window.fetch;
      if (typeof realFetch === "function") {
        window.fetch = async function (...args) {
          const response = await realFetch.apply(this, args);
          try {
            const request = args[0];
            const url = typeof request === "string" ? request : request?.url || "";
            if (!isPlayerResponseUrl(url)) return response;
            const contentType = response.headers?.get?.("content-type") || "";
            if (contentType && !/json|javascript|text/i.test(contentType)) return response;
            const text = await response.clone().text();
            const sanitized = sanitizeResponseText(text);
            if (!sanitized || sanitized === text) return response;
            const headers = new Headers(response.headers);
            headers.set("content-type", "application/json; charset=utf-8");
            headers.delete("content-length");
            return new Response(sanitized, { status: response.status, statusText: response.statusText, headers });
          } catch {
            return response;
          }
        };
      }
      const realOpen = XMLHttpRequest.prototype.open;
      const realSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this.__libadblockYtUrl = url;
        return realOpen.call(this, method, url, ...rest);
      };
      XMLHttpRequest.prototype.send = function (...args) {
        if (isPlayerResponseUrl(this.__libadblockYtUrl)) {
          this.addEventListener("readystatechange", () => {
            if (this.readyState !== 4 || this.responseType && this.responseType !== "text") return;
            try {
              const text = this.responseText;
              const sanitized = sanitizeResponseText(text);
              if (!sanitized || sanitized === text) return;
              Object.defineProperty(this, "responseText", { configurable: true, value: sanitized });
              Object.defineProperty(this, "response", { configurable: true, value: sanitized });
            } catch {}
          });
        }
        return realSend.apply(this, args);
      };
    })();`);
  return `(() => {
  const injectMainWorld = (source) => {
    try {
      const electron = typeof require === "function" ? require("electron") : null;
      if (electron?.webFrame?.executeJavaScript) {
        electron.webFrame.executeJavaScript(source, false);
        return;
      }
    } catch {}
    try {
      const inject = () => {
        const script = document.createElement("script");
        script.textContent = source;
        (document.documentElement || document.head || document.body).appendChild(script);
        script.remove();
      };
      if (document.documentElement || document.head || document.body) inject();
      else window.addEventListener("DOMContentLoaded", inject, { once: true, capture: true });
    } catch {}
  };

  if (${enableTwitchAdBlocking ? "true" : "false"} && /(^|\\.)twitch\\.tv$/.test(location.hostname) && !window.__libadblockTwitchAdblockInjected) {
    window.__libadblockTwitchAdblockInjected = true;
    injectMainWorld(${twitchSource});
  }

  if (${enableYoutubeAdBlocking ? "true" : "false"} && /(^|\\.)youtube\\.com$/.test(location.hostname) && !window.__libadblockYouTubeAdblockInjected) {
    window.__libadblockYouTubeAdblockInjected = true;
    window.__libadblockDisabledSites = ${disabledSites};
    injectMainWorld(${youtubeSource});
  }

  const userAgentOverrides = ${userAgentOverrides};
  const hostname = String(location.hostname || "").toLowerCase();
  const userAgentOverride = Array.isArray(userAgentOverrides)
    ? userAgentOverrides.find((rule) => hostname === rule.host || hostname.endsWith("." + rule.host))
    : null;
  if (userAgentOverride && userAgentOverride.userAgent && !window.__libadblockUserAgentOverrideInjected) {
    window.__libadblockUserAgentOverrideInjected = true;
    injectMainWorld("(() => {" +
      "const userAgent = " + JSON.stringify(userAgentOverride.userAgent) + ";" +
      "const chromeVersion = " + JSON.stringify(userAgentOverride.chromeVersion || "") + ";" +
      "const chromeMajor = " + JSON.stringify(userAgentOverride.chromeMajor || "") + ";" +
      "const platform = " + JSON.stringify(userAgentOverride.platform || "") + ";" +
      "const brands = [{brand:'Not/A)Brand',version:'8'},{brand:'Chromium',version:chromeMajor},{brand:'Google Chrome',version:chromeMajor}];" +
      "const fullVersionList = [{brand:'Not/A)Brand',version:'8.0.0.0'},{brand:'Chromium',version:chromeVersion},{brand:'Google Chrome',version:chromeVersion}];" +
      "const userAgentData = {brands,mobile:false,platform,getHighEntropyValues:async(hints=[])=>{const result={};const requested=Array.isArray(hints)?hints:[];for(const hint of requested){if(hint==='brands')result.brands=brands;if(hint==='mobile')result.mobile=false;if(hint==='platform')result.platform=platform;if(hint==='platformVersion')result.platformVersion='0.0.0';if(hint==='architecture')result.architecture='x86';if(hint==='bitness')result.bitness='64';if(hint==='model')result.model='';if(hint==='uaFullVersion')result.uaFullVersion=chromeVersion;if(hint==='fullVersionList')result.fullVersionList=fullVersionList;if(hint==='wow64')result.wow64=false;}return result;},toJSON:()=>({brands,mobile:false,platform})};" +
      "try{Object.defineProperty(Navigator.prototype,'userAgent',{configurable:true,get:()=>userAgent});}catch{}" +
      "try{Object.defineProperty(Navigator.prototype,'userAgentData',{configurable:true,get:()=>userAgentData});}catch{}" +
      "})();");
  }
})();
`;
}

async function installLibadblockPreload(options = {}) {
  const {
    app,
    session,
    fetchImpl = fetch,
    filterlistDir,
    enableTwitchAdBlocking = true,
    enableYoutubeAdBlocking = true,
    disabledSites = [],
    resolveUserAgentOverrideValue: resolveUserAgentOverrideValueOption,
    logger
  } = options;

  const log = getLogger(logger);

  const supportsRegisterPreloadScript = typeof session?.registerPreloadScript === "function";
  const supportsSetPreloads = typeof session?.setPreloads === "function";
  if (!supportsRegisterPreloadScript && !supportsSetPreloads) {
    log.warn?.("libadblock preload unavailable: this Electron session does not support session preloads.");
    return null;
  }

  try {
    const resolvedFilterlistDir = filterlistDir || getDefaultFilterlistDir(app);
    const bundledFiltersDir = options.bundledFiltersDir || getDefaultBundledFiltersDir();
    ensureDirectory(resolvedFilterlistDir);
    const preloadFile = path.join(resolvedFilterlistDir, LIBADBLOCK_PRELOAD_FILE);
    const userAgentOverrideRules = readUserAgentOverrideRulesFromFiles([
      path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.userAgentOverrides),
      path.join(bundledFiltersDir, FILTER_FILE_NAMES.userAgentOverrides)
    ], {
      resolveValue: typeof resolveUserAgentOverrideValueOption === "function" ? resolveUserAgentOverrideValueOption : undefined
    });
    fs.writeFileSync(preloadFile, createLibadblockPreloadSource({
      enableTwitchAdBlocking,
      enableYoutubeAdBlocking,
      youtubeDisabledSites: enableYoutubeAdBlocking ? disabledSites : [],
      userAgentOverrideRules
    }), {
      mode: 0o600
    });

    let preloadScriptId = null;
    if (supportsRegisterPreloadScript) {
      preloadScriptId = session.registerPreloadScript({
        type: "frame",
        filePath: preloadFile
      });
    } else {
      const existingPreloads = typeof session.getPreloads === "function" ? session.getPreloads() : [];
      if (!existingPreloads.includes(preloadFile)) {
        session.setPreloads([...existingPreloads, preloadFile]);
      }
      preloadScriptId = preloadFile;
    }

    return { id: preloadScriptId, filePath: preloadFile };
  } catch (error) {
    log.warn?.("Failed to install libadblock preload:", error?.message || error);
    return null;
  }
}

function getStorageMetadata(metadataFile) {
  const metadata = readJsonFile(metadataFile) || {};
  return {
    schemaVersion: Number(metadata.schemaVersion || 0),
    libadblockVersion: String(metadata.libadblockVersion || ""),
    filterSetVersion: String(metadata.filterSetVersion || ""),
    cacheUpdatedAt: Number(metadata.cacheUpdatedAt || 0),
    refreshedAt: Number(metadata.refreshedAt || 0)
  };
}

function getDefaultBundledFiltersDir() {
  const packageFiltersDir = path.join(__dirname, "filters");
  if (fs.existsSync(packageFiltersDir)) return packageFiltersDir;

  const siblingFiltersDir = path.join(__dirname, "..", "filters");
  if (fs.existsSync(siblingFiltersDir)) return siblingFiltersDir;

  return packageFiltersDir;
}

function writeStorageMetadata(metadataFile, metadata) {
  writeJsonFile(metadataFile, {
    schemaVersion: STORAGE_SCHEMA_VERSION,
    libadblockVersion: LIBADBLOCK_VERSION,
    ...metadata,
    updatedAt: Date.now()
  });
}

function metadataMatchesCurrentFilters(metadata, remoteFilterLists) {
  return metadata.schemaVersion === STORAGE_SCHEMA_VERSION &&
    metadata.libadblockVersion === LIBADBLOCK_VERSION &&
    metadata.filterSetVersion === getFilterSetVersion(remoteFilterLists);
}

function lockIsStale(lockFile) {
  return isFileOlderThan(lockFile, REFRESH_LOCK_TTL_MS);
}

function acquireRefreshLock(lockFile) {
  try {
    if (fs.existsSync(lockFile) && lockIsStale(lockFile)) {
      fs.unlinkSync(lockFile);
    }

    const fd = fs.openSync(lockFile, "wx", 0o600);
    fs.writeFileSync(fd, JSON.stringify({
      pid: process.pid,
      createdAt: Date.now(),
      libadblockVersion: LIBADBLOCK_VERSION
    }));
    fs.closeSync(fd);
    return true;
  } catch {
    return false;
  }
}

function releaseRefreshLock(lockFile) {
  try {
    fs.unlinkSync(lockFile);
  } catch {}
}

function getCosmeticFiltersDataUrlFromFile(cosmeticFiltersFile) {
  try {
    if (!cosmeticFiltersFile) return "";
    if (!fs.existsSync(cosmeticFiltersFile)) return "";

    const text = String(fs.readFileSync(cosmeticFiltersFile, "utf8") || "").trim();
    if (!text) return "";

    const encoded = Buffer.from(text, "utf8").toString("base64");
    return `data:text/plain;base64,${encoded}`;
  } catch {
    return "";
  }
}

function getDomainNetworkRulesFromFiles(sourceFiles = [], options = {}) {
  try {
    const sourcePaths = (Array.isArray(sourceFiles) ? sourceFiles : [sourceFiles])
      .filter((sourceFile) => sourceFile && fs.existsSync(sourceFile));
    if (!sourcePaths.length) return "";

    const domains = loadDomainSetFromFilterFiles(sourcePaths);
    const rules = new Set();
    const prefix = options.allow ? "@@||" : "||";
    const ruleOptions = Array.isArray(options.ruleOptions) && options.ruleOptions.length
      ? `$${options.ruleOptions.join(",")}`
      : "";
    for (const domain of domains) {
      rules.add(`${prefix}${domain}^${ruleOptions}`);
    }
    for (const rule of domains.urlRules || []) {
      rules.add(`${prefix}${rule.host}${rule.pathPrefix}*${ruleOptions}`);
    }
    return Array.from(rules).join("\n");
  } catch {
    return "";
  }
}

function getLocalNetworkFiltersDataUrlFromSpecs(specs = []) {
  const sections = [];
  for (const spec of specs) {
    const rules = getDomainNetworkRulesFromFiles(spec.files, spec);
    if (rules) sections.push(`! ${spec.title}\n${rules}`);
  }
  if (!sections.length) return "";

  const text = sections.join("\n");
  const encoded = Buffer.from(text, "utf8").toString("base64");
  return `data:text/plain;base64,${encoded}`;
}

function getLogger(logger) {
  if (logger && typeof logger === "object") return logger;
  return console;
}

function createAdblockStats() {
  return {
    blockedCount: 0,
    blockedByType: Object.create(null),
    lastBlockedUrl: "",
    lastBlockedAt: 0
  };
}

function recordBlockedRequest(stats, event = {}) {
  const resourceType = String(event.resourceType || "request");
  stats.blockedCount += 1;
  stats.blockedByType[resourceType] = (stats.blockedByType[resourceType] || 0) + 1;
  stats.lastBlockedUrl = String(event.url || "");
  stats.lastBlockedAt = Date.now();

  return {
    total: stats.blockedCount,
    resourceType,
    typeCount: stats.blockedByType[resourceType],
    url: stats.lastBlockedUrl,
    time: stats.lastBlockedAt
  };
}

function shouldLogBlockedUrls() {
  return Array.isArray(process.argv) && process.argv.includes("--adlog");
}

function logBlockedRequest(log, record, options = {}) {
  if (options.logBlockedUrls) {
    log.log?.(`Adblock: blocked ${record.resourceType} (${record.total} total)\n  URL: ${record.url}`);
    return;
  }

  if (process.stdout?.isTTY && typeof process.stdout.write === "function") {
    process.stdout.write(`\rAdblock: blocked ${record.total} requests`);
    return;
  }

  const interval = Math.max(1, Number(options.logBlockedSummaryInterval) || 25);
  if (record.total === 1 || record.total % interval === 0) {
    log.log?.(`Adblock: blocked ${record.total} requests`);
  }
}

function refreshAdblockCacheInBackground(options = {}) {
  const {
    ElectronBlocker,
    fetchImpl,
    filterLists,
    remoteFilterLists,
    cacheFile,
    adblockCaching,
    metadataFile,
    lockFile,
    filterSetVersion,
    loadEngineCosmeticFilters = false,
    logger
  } = options;

  const log = getLogger(logger);

  setTimeout(async () => {
    if (!acquireRefreshLock(lockFile)) {
      return;
    }

    try {
      await fs.promises.unlink(cacheFile).catch(() => {});
      await ElectronBlocker.fromLists(
        fetchImpl,
        filterLists,
        {
          enableCompression: true,
          loadCosmeticFilters: loadEngineCosmeticFilters
        },
        adblockCaching
      );
      writeStorageMetadata(metadataFile, {
        filterSetVersion,
        cacheUpdatedAt: Date.now(),
        refreshedAt: Date.now()
      });
    } catch (error) {
      try {
        await ElectronBlocker.fromLists(
          fetchImpl,
          remoteFilterLists,
          {
            enableCompression: true,
            loadCosmeticFilters: loadEngineCosmeticFilters
          },
          adblockCaching
        );
        writeStorageMetadata(metadataFile, {
          filterSetVersion,
          cacheUpdatedAt: Date.now(),
          refreshedAt: Date.now()
        });
      } catch (fallbackError) {
        log.warn?.("Failed to refresh adblock cache in background:", fallbackError?.message || fallbackError);
      }
    } finally {
      releaseRefreshLock(lockFile);
    }
  }, 0);
}

function loadElectronBlocker(options = {}) {
  if (options.ElectronBlocker) return options.ElectronBlocker;

  const candidates = [
    __filename,
    options.app?.getAppPath ? path.join(options.app.getAppPath(), "package.json") : "",
    options.app?.getAppPath ? path.join(options.app.getAppPath(), "main.js") : "",
    process.mainModule?.filename || "",
    process.argv?.[1] || ""
  ].filter(Boolean);

  for (const candidate of candidates) {
    try {
      const scopedRequire = createRequire(candidate);
      const loaded = scopedRequire("@ghostery/adblocker-electron");
      if (loaded?.ElectronBlocker) return loaded.ElectronBlocker;
    } catch {}
  }

  throw new Error("Cannot find module '@ghostery/adblocker-electron'. Install it in the host Electron app, install libadblock dependencies, or pass ElectronBlocker to libadblock.");
}

function getFilterBaseName(fileName) {
  return path.parse(String(fileName || "")).name;
}

function createFilterPaths(options = {}) {
  const app = options.app;
  const filterlistDir = options.filterlistDir || path.join(app.getPath("userData"), "filterlists");
  const bundledFiltersDir = options.bundledFiltersDir || getDefaultBundledFiltersDir();
  const file = (name) => path.join(filterlistDir, name);
  const bundled = (name) => path.join(bundledFiltersDir, name);
  const meta = (name) => path.join(filterlistDir, `${getFilterBaseName(name)}-meta.json`);

  return {
    filterlistDir,
    bundledFiltersDir,
    files: {
      remoteFilterLists: file(FILTER_FILE_NAMES.remoteFilterLists),
      browserBlocklist: file(FILTER_FILE_NAMES.browserBlocklist),
      browserWhitelist: file(FILTER_FILE_NAMES.browserWhitelist),
      browserCosmeticFilters: file(FILTER_FILE_NAMES.browserCosmeticFilters),
      trackerBlocklist: file(FILTER_FILE_NAMES.trackerBlocklist),
      trackerStrictBlocklist: file(FILTER_FILE_NAMES.trackerStrictBlocklist),
      popupBlocklist: file(FILTER_FILE_NAMES.popupBlocklist),
      popupWhitelist: file(FILTER_FILE_NAMES.popupWhitelist),
      drmSites: file(FILTER_FILE_NAMES.drmSites),
      userAgentOverrides: file(FILTER_FILE_NAMES.userAgentOverrides)
    },
    metaFiles: {
      remoteFilterLists: meta(FILTER_FILE_NAMES.remoteFilterLists),
      browserBlocklist: meta(FILTER_FILE_NAMES.browserBlocklist),
      browserWhitelist: meta(FILTER_FILE_NAMES.browserWhitelist),
      browserCosmeticFilters: meta(FILTER_FILE_NAMES.browserCosmeticFilters),
      trackerBlocklist: meta(FILTER_FILE_NAMES.trackerBlocklist),
      trackerStrictBlocklist: meta(FILTER_FILE_NAMES.trackerStrictBlocklist),
      popupBlocklist: meta(FILTER_FILE_NAMES.popupBlocklist),
      popupWhitelist: meta(FILTER_FILE_NAMES.popupWhitelist),
      drmSites: meta(FILTER_FILE_NAMES.drmSites),
      userAgentOverrides: meta(FILTER_FILE_NAMES.userAgentOverrides)
    },
    bundledFiles: {
      remoteFilterLists: bundled(FILTER_FILE_NAMES.remoteFilterLists),
      browserBlocklist: bundled(FILTER_FILE_NAMES.browserBlocklist),
      browserWhitelist: bundled(FILTER_FILE_NAMES.browserWhitelist),
      browserCosmeticFilters: bundled(FILTER_FILE_NAMES.browserCosmeticFilters),
      trackerBlocklist: bundled(FILTER_FILE_NAMES.trackerBlocklist),
      trackerStrictBlocklist: bundled(FILTER_FILE_NAMES.trackerStrictBlocklist),
      popupBlocklist: bundled(FILTER_FILE_NAMES.popupBlocklist),
      popupWhitelist: bundled(FILTER_FILE_NAMES.popupWhitelist),
      drmSites: bundled(FILTER_FILE_NAMES.drmSites),
      userAgentOverrides: bundled(FILTER_FILE_NAMES.userAgentOverrides)
    },
    urls: FILTER_REMOTE_URLS
  };
}

function ensureDirectory(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, {
      recursive: true
    });
  }
}

function normalizeListContent(value) {
  return String(value || "")
    .replace(/\r\n/g, "\n")
    .trim();
}

function parseRemoteFilterListsText(value) {
  const urls = [];
  const seen = new Set();

  for (const rawLine of String(value || "").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("!") || line.startsWith("#") || line.startsWith("[")) continue;

    try {
      const parsed = new URL(line);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:" && parsed.protocol !== "data:") continue;
    } catch {
      continue;
    }

    if (!seen.has(line)) {
      seen.add(line);
      urls.push(line);
    }
  }

  return urls;
}

function isAdblockEngineFilterListUrl(value) {
  try {
    const pathname = new URL(String(value || "")).pathname.toLowerCase();
    return !pathname.endsWith(`/${FILTER_FILE_NAMES.drmSites.toLowerCase()}`);
  } catch {
    return true;
  }
}

function filterAdblockEngineFilterLists(urls = []) {
  return (Array.isArray(urls) ? urls : []).filter(isAdblockEngineFilterListUrl);
}

function readRemoteFilterListsFile(filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return [];
    return filterAdblockEngineFilterLists(parseRemoteFilterListsText(fs.readFileSync(filePath, "utf8")));
  } catch {
    return [];
  }
}

async function resolveRemoteFilterLists(options = {}) {
  const { app, remoteFilterLists, filterlistDir, bundledFiltersDir, fetchImpl = fetch, logger } = options;
  if (Array.isArray(remoteFilterLists)) return filterAdblockEngineFilterLists(remoteFilterLists.slice().filter(Boolean));

  const log = getLogger(logger);
  const paths = createFilterPaths({ app, filterlistDir, bundledFiltersDir });
  const localLists = readRemoteFilterListsFile(paths.files.remoteFilterLists);
  if (localLists.length) return localLists;

  const packagedLists = readRemoteFilterListsFile(getBundledRemoteFilterListsFile());
  if (packagedLists.length) return packagedLists;

  const bundledLists = readRemoteFilterListsFile(paths.bundledFiles.remoteFilterLists);
  if (bundledLists.length) return bundledLists;

  try {
    const res = await fetchImpl(FILTER_REMOTE_URLS.remoteFilterLists);
    if (res.ok) {
      const remoteLists = filterAdblockEngineFilterLists(parseRemoteFilterListsText(await res.text()));
      if (remoteLists.length) return remoteLists;
    }
  } catch (error) {
    log.warn?.("Failed to fetch libadblock filter subscription list:", error?.message || error);
  }

  return [];
}

function ensureBundledFilterSeededToUserConfig(options = {}) {
  const { localFile, bundledFile, filterlistDir, logger } = options;
  const log = getLogger(logger);

  try {
    if (filterlistDir) ensureDirectory(filterlistDir);
    if (!fs.existsSync(bundledFile)) return false;

    const bundledText = fs.readFileSync(bundledFile, "utf8");
    const bundledLines = bundledText.split(/\r?\n/);

    if (!fs.existsSync(localFile)) {
      fs.writeFileSync(localFile, bundledText, {
        mode: 0o600
      });
      return true;
    }

    const localText = fs.readFileSync(localFile, "utf8");
    const existingLines = new Set(localText.split(/\r?\n/).map((line) => String(line || "").trim()));
    const missingLines = bundledLines.filter((line) => {
      const normalized = String(line || "").trim();
      return normalized && !existingLines.has(normalized);
    });

    if (!missingLines.length) return false;

    const separator = localText.endsWith("\n") || !localText ? "" : "\n";
    fs.appendFileSync(localFile, `${separator}\n! Bundled libadblock defaults\n${missingLines.join("\n")}\n`, {
      mode: 0o600
    });
    return true;
  } catch (error) {
    log.warn?.("Failed to seed bundled filter file:", error?.message || error);
    return false;
  }
}

async function updateRemoteFilterFile(options = {}) {
  const { localFile, metaFile, remoteUrl, fetchImpl = fetch, filterlistDir, cacheMaxAgeMs = FILTERLIST_REFRESH_INTERVAL_MS, force = false } = options;
  try {
    if (filterlistDir) ensureDirectory(filterlistDir);

    const existingRaw = fs.existsSync(localFile) ? fs.readFileSync(localFile, "utf8") : "";
    const existingNormalized = normalizeListContent(existingRaw);
    const meta = readJsonFile(metaFile);
    const checkedAt = Number(meta?.checkedAt || 0);
    const checkedRecently = checkedAt > 0 && Date.now() - checkedAt <= cacheMaxAgeMs;
    if (!force && existingRaw && checkedRecently) {
      return { ok: true, updated: false, skipped: true, reason: "fresh" };
    }

    const headers = {};
    if (meta?.etag) headers["If-None-Match"] = String(meta.etag);
    if (meta?.lastModified) headers["If-Modified-Since"] = String(meta.lastModified);

    const res = await fetchImpl(remoteUrl, { headers });
    if (res.status === 304) {
      writeJsonFile(metaFile, {
        etag: meta?.etag || "",
        lastModified: meta?.lastModified || "",
        checkedAt: Date.now()
      });
      return { ok: true, updated: false };
    }

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const text = await res.text();
    const normalizedRemote = normalizeListContent(text);
    const updated = normalizedRemote !== existingNormalized;
    if (updated) {
      fs.writeFileSync(localFile, text, { mode: 0o600 });
    }

    writeJsonFile(metaFile, {
      etag: res.headers.get("etag") || "",
      lastModified: res.headers.get("last-modified") || "",
      checkedAt: Date.now()
    });

    return { ok: true, updated };
  } catch (error) {
    return {
      ok: false,
      updated: false,
      error: error?.message || String(error)
    };
  }
}

async function updateRemoteFilterFiles(options = {}) {
  const paths = createFilterPaths(options);
  const fetchImpl = options.fetchImpl || fetch;
  const cacheMaxAgeMs = Number.isFinite(options.cacheMaxAgeMs) && options.cacheMaxAgeMs > 0
    ? options.cacheMaxAgeMs
    : FILTERLIST_REFRESH_INTERVAL_MS;
  const results = {};

  await Promise.all(Object.keys(FILTER_REMOTE_URLS).map(async (key) => {
    results[key] = await updateRemoteFilterFile({
      localFile: paths.files[key],
      metaFile: paths.metaFiles[key],
      remoteUrl: paths.urls[key],
      fetchImpl,
      cacheMaxAgeMs,
      force: options.force === true,
      filterlistDir: paths.filterlistDir
    });
  }));

  return results;
}

function normalizeFilterHostname(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^www\./, "")
    .replace(/\.$/, "");
}

function loadDomainSetFromFilterFiles(sourcePaths = []) {
  const domains = new Set();
  const urlRules = [];
  for (const sourcePath of sourcePaths) {
    if (!sourcePath || !fs.existsSync(sourcePath)) continue;
    const lines = fs.readFileSync(sourcePath, "utf8").split(/\r?\n/);
    for (const rawLine of lines) {
      const line = String(rawLine || "").trim();
      if (!line || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) continue;
      if (line.includes("##") || line.includes("#@#") || line.includes("#?#") || line.includes("#$#")) continue;
      if (line.startsWith("/") && line.endsWith("/")) continue;
      let candidate = line
        .replace(/^@@/, "")
        .replace(/^\|\|/, "")
        .replace(/^\*\./, "")
        .replace(/^\./, "")
        .replace(/^\|/, "")
        .replace(/\|$/, "")
        .replace(/\$.*/, "")
        .replace(/\^.*$/, "");
      if (candidate.includes("*") && !candidate.endsWith("*")) continue;
      if (candidate.includes("://")) {
        try {
          const parsed = new URL(candidate);
          candidate = `${parsed.hostname || ""}${parsed.pathname && parsed.pathname !== "/" ? parsed.pathname : ""}`;
        } catch {
          candidate = "";
        }
      }
      let pathPrefix = "";
      if (candidate.includes("/")) {
        const slashIndex = candidate.indexOf("/");
        pathPrefix = candidate.slice(slashIndex).replace(/\*+$/, "");
        candidate = candidate.slice(0, slashIndex);
      }
      const normalized = normalizeFilterHostname(candidate);
      if (!normalized) continue;
      if (pathPrefix) urlRules.push({ host: normalized, pathPrefix });
      else domains.add(normalized);
    }
  }
  Object.defineProperty(domains, "urlRules", {
    value: urlRules,
    enumerable: false
  });
  return domains;
}

function hostMatchesDomainSet(hostname, domains) {
  const normalizedHost = normalizeFilterHostname(hostname);
  if (!normalizedHost || !domains?.size) return false;
  if (domains.has(normalizedHost)) return true;
  for (const domain of domains) {
    if (normalizedHost.endsWith(`.${domain}`)) return true;
  }
  return false;
}

function urlMatchesDomainSetRules(value, domains) {
  const rules = domains?.urlRules;
  if (!Array.isArray(rules) || !rules.length) return false;

  try {
    const parsed = new URL(String(value || ""));
    const hostname = normalizeFilterHostname(parsed.hostname);
    const pathname = parsed.pathname.toLowerCase();
    return rules.some((rule) => {
      if (!hostMatchesDomainSet(hostname, new Set([rule.host]))) return false;
      return pathname.startsWith(String(rule.pathPrefix || "").toLowerCase());
    });
  } catch {
    return false;
  }
}

function getHostnameFromUrl(value) {
  try {
    return new URL(String(value || "")).hostname || "";
  } catch {
    return "";
  }
}

function getComparableHostname(value) {
  const normalized = normalizeFilterHostname(value);
  const parts = normalized.split(".").filter(Boolean);
  if (parts.length <= 2) return normalized;
  return parts.slice(-2).join(".");
}

function isThirdPartyRequestHost(requestHost, initiatorHost) {
  const requestComparable = getComparableHostname(requestHost);
  const initiatorComparable = getComparableHostname(initiatorHost);
  if (!requestComparable || !initiatorComparable) return false;
  return requestComparable !== initiatorComparable;
}

function shouldBlockByLightweightTrackerRules(details, options = {}) {
  const requestHost = getHostnameFromUrl(details?.url);
  if (!requestHost) return false;
  if (urlMatchesDomainSetRules(details?.url, options.strictTrackerDomains)) return true;
  if (hostMatchesDomainSet(requestHost, options.strictTrackerDomains)) return true;
  if (!options.resourceTypes?.has?.(String(details?.resourceType || ""))) return false;
  if (!hostMatchesDomainSet(requestHost, options.trackerDomains)) return false;
  const initiatorHost = getHostnameFromUrl(details?.initiator || details?.referrer || details?.documentURL || "");
  if (!initiatorHost) return true;
  return isThirdPartyRequestHost(requestHost, initiatorHost);
}

function shouldBlockByAdScriptPath(details, patterns = []) {
  if (String(details?.resourceType || "") !== "script") return false;
  try {
    const pathname = new URL(details.url).pathname.toLowerCase();
    return patterns.some(pattern => pathname === pattern || pathname.endsWith(pattern));
  } catch {
    return false;
  }
}

function parseCosmeticRuleLine(rawLine) {
  const line = String(rawLine || "").trim();
  if (!line || line.startsWith("!") || line.startsWith("#")) return null;
  const hideSplit = line.split("##");
  if (hideSplit.length !== 2) return null;
  const domainPart = String(hideSplit[0] || "").trim().toLowerCase();
  const rawRule = String(hideSplit[1] || "").trim();
  if (!domainPart || !rawRule) return null;
  let selector = rawRule;
  let declarations = "";
  const styleMatch = rawRule.match(/^(.*?):style\((.*)\)$/i);
  if (styleMatch) {
    selector = String(styleMatch[1] || "").trim();
    declarations = String(styleMatch[2] || "").trim();
  }
  if (!selector) return null;
  const domains = domainPart.split(",").map((entry) => String(entry || "").trim().toLowerCase()).filter(Boolean).filter((entry) => !entry.includes("/")).filter((entry) => !entry.startsWith("~"));
  if (!domains.length) return null;
  return { domains, selector, declarations };
}

function loadCosmeticRulesFromFile(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return [];
  return fs.readFileSync(filePath, "utf8").split(/\r?\n/).map((line) => parseCosmeticRuleLine(line)).filter(Boolean);
}

function cosmeticRuleMatchesHost(hostname, ruleDomain) {
  const host = getComparableHostname(hostname);
  const domain = getComparableHostname(ruleDomain);
  if (!host || !domain) return false;
  return host === domain || host.endsWith(`.${domain}`);
}

function getCosmeticCssForUrl(rules = [], targetUrl = "") {
  let hostname = "";
  try {
    const parsed = new URL(String(targetUrl || ""));
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
    hostname = parsed.hostname;
  } catch {
    return "";
  }
  const hideSelectors = new Set();
  const styleRules = [];
  for (const rule of rules) {
    if (!Array.isArray(rule?.domains) || !rule.selector) continue;
    if (!rule.domains.some((domain) => cosmeticRuleMatchesHost(hostname, domain))) continue;
    const declarations = String(rule.declarations || "").trim();
    if (declarations) styleRules.push(`${rule.selector}{${declarations}}`);
    else hideSelectors.add(rule.selector);
  }
  const hideCss = Array.from(hideSelectors).map((selector) => `${selector}{display:none !important;visibility:hidden !important;height:0 !important;min-height:0 !important;margin:0 !important;padding:0 !important;}`).join("\n");
  return [hideCss, ...styleRules].filter(Boolean).join("\n");
}

function loadCosmeticRulesForInjection(options = {}) {
  const { filterlistDir, bundledFiltersDir } = options;
  const localFile = filterlistDir ? path.join(filterlistDir, FILTER_FILE_NAMES.browserCosmeticFilters) : "";
  const bundledFile = bundledFiltersDir ? path.join(bundledFiltersDir, FILTER_FILE_NAMES.browserCosmeticFilters) : "";
  const sourceFile = fs.existsSync(localFile) ? localFile : bundledFile;
  return loadCosmeticRulesFromFile(sourceFile);
}

function isCosmeticFilteringDisabledForUrl(targetUrl = "", disabledSites = []) {
  if (!Array.isArray(disabledSites) || !disabledSites.length) return false;

  try {
    const hostname = new URL(String(targetUrl || "")).hostname;
    const comparableHost = getComparableHostname(hostname);
    return disabledSites.some((site) => getComparableHostname(site) === comparableHost);
  } catch {
    return false;
  }
}

function installCosmeticFilterInjection(options = {}) {
  const {
    app,
    filterlistDir,
    bundledFiltersDir,
    disabledSites = [],
    logger
  } = options;

  if (!app || typeof app.on !== "function") return null;

  const log = getLogger(logger);
  const state = app[COSMETIC_FILTER_STATE] || {
    cssKeys: new WeakMap(),
    hookedWebContents: new WeakSet(),
    installed: false,
    rules: []
  };

  state.rules = loadCosmeticRulesForInjection({ filterlistDir, bundledFiltersDir });
  state.disabledSites = Array.isArray(disabledSites) ? disabledSites.slice() : [];
  app[COSMETIC_FILTER_STATE] = state;

  const applyToWebContents = async (webContents, targetUrl = "") => {
    if (!webContents || webContents.isDestroyed?.()) return;

    const url = String(targetUrl || webContents.getURL?.() || "");
    const previousKey = state.cssKeys.get(webContents);
    if (previousKey) {
      try {
        await webContents.removeInsertedCSS(previousKey);
      } catch {}
      state.cssKeys.delete(webContents);
    }

    if (isCosmeticFilteringDisabledForUrl(url, state.disabledSites)) return;

    const cssText = getCosmeticCssForUrl(state.rules, url);

    if (!cssText || webContents.isDestroyed?.()) return;

    try {
      const cssKey = await webContents.insertCSS(cssText, { cssOrigin: "user" });
      state.cssKeys.set(webContents, cssKey);
    } catch (error) {
      log.warn?.("Failed to apply libadblock cosmetic filters:", error?.message || error);
    }
  };

  const hookWebContents = (_event, webContents) => {
    if (!webContents) return;
    if (state.hookedWebContents.has(webContents)) {
      applyToWebContents(webContents).catch(() => {});
      return;
    }
    state.hookedWebContents.add(webContents);

    webContents.on?.("dom-ready", () => applyToWebContents(webContents).catch(() => {}));
    webContents.on?.("did-finish-load", () => applyToWebContents(webContents).catch(() => {}));
    webContents.on?.("did-navigate", (_event, url) => applyToWebContents(webContents, url).catch(() => {}));
    webContents.on?.("did-navigate-in-page", (_event, url) => applyToWebContents(webContents, url).catch(() => {}));
    webContents.once?.("destroyed", () => state.cssKeys.delete(webContents));

    applyToWebContents(webContents).catch(() => {});
  };

  if (!state.installed) {
    app.on("web-contents-created", hookWebContents);
    state.installed = true;
  }

  try {
    const electron = require("electron");
    for (const webContents of electron.webContents?.getAllWebContents?.() || []) {
      hookWebContents({}, webContents);
    }
  } catch {}

  return state;
}

function readUserAgentOverrideRules(options = {}) {
  const { filePath } = options;
  const chromeVersion = readChromeVersionFromUserAgentOverrides(filePath);
  const resolveValue = typeof options.resolveValue === "function"
    ? options.resolveValue
    : (value) => resolveUserAgentOverrideValue(value, { ...options, chromeVersion });
  if (!filePath || !fs.existsSync(filePath)) return [];
  return fs.readFileSync(filePath, "utf8").split("\n").map((line) => {
    const trimmed = line.trim();
    const extensionPrefix = "! libelectron-user-agent:";
    if (trimmed.toLowerCase().startsWith(extensionPrefix)) {
      return trimmed.slice(extensionPrefix.length).trim();
    }
    return trimmed;
  }).filter((line) => line && !line.startsWith("#") && !line.startsWith("!") && !line.startsWith("[")).map((line) => {
    const separatorIndex = line.indexOf("|");
    if (separatorIndex <= 0) return null;
    const host = line.slice(0, separatorIndex).trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "");
    const userAgent = String(resolveValue(line.slice(separatorIndex + 1)) || "").trim();
    if (!host || !userAgent) return null;
    return { host, userAgent };
  }).filter(Boolean);
}

function readUserAgentOverrideRulesFromFiles(filePaths = [], options = {}) {
  for (const filePath of filePaths) {
    const rules = readUserAgentOverrideRules({
      ...options,
      filePath
    });
    if (rules.length) return rules;
  }

  return [];
}

async function createAdblockEngine(options = {}) {
  const {
    app,
    fetchImpl = fetch,
    filterlistDir,
    cacheFile,
    bundledFiltersDir = getDefaultBundledFiltersDir(),
    includeBundledCosmeticFilters = true,
    enableCosmeticFiltering = true,
    loadEngineCosmeticFilters = false,
    enableTwitchAdBlocking = true,
    cacheMaxAgeMs = FILTERLIST_REFRESH_INTERVAL_MS,
    cacheInvalidationFiles = [__filename, getBundledResourcePath(TWITCH_ADBLOCK_RESOURCE_FILE)],
    updateRemoteFilters = true,
    refreshStaleCacheInBackground = true,
    remoteFilterLists,
    disabledSites = [],
    onRequestBlocked,
    logBlockedRequests = true,
    logBlockedUrls = shouldLogBlockedUrls(),
    logBlockedSummaryInterval = 25,
    logger
  } = options;

  if (!app && !filterlistDir && !cacheFile) {
    throw new Error("createAdblockEngine requires app, filterlistDir, or cacheFile.");
  }

  const log = getLogger(logger);
  const resolvedFetchImpl = createResourceFetch(fetchImpl, {
    enableTwitchAdBlocking
  });
  const ElectronBlocker = loadElectronBlocker(options);
  const resolvedFilterlistDir = filterlistDir || getDefaultFilterlistDir(app);
  if (updateRemoteFilters) {
    const results = await updateRemoteFilterFiles({
      app,
      fetchImpl,
      filterlistDir: resolvedFilterlistDir,
      bundledFiltersDir,
      cacheMaxAgeMs
    });
    const failed = Object.entries(results).filter(([, result]) => !result?.ok);
    if (failed.length) {
      log.warn?.(`Failed to update ${failed.length} libadblock filter file(s): ${failed.map(([key]) => key).join(", ")}`);
    }
  }
  const resolvedCacheFile = cacheFile || path.join(resolvedFilterlistDir, ENGINE_CACHE_FILE);
  const localCosmeticFiltersFile = path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.browserCosmeticFilters);
  const bundledCosmeticFiltersFile = path.join(bundledFiltersDir, FILTER_FILE_NAMES.browserCosmeticFilters);
  const localCosmeticDataUrl = includeBundledCosmeticFilters
    ? getCosmeticFiltersDataUrlFromFile(localCosmeticFiltersFile) || getCosmeticFiltersDataUrlFromFile(bundledCosmeticFiltersFile)
    : "";
  const localNetworkDataUrl = getLocalNetworkFiltersDataUrlFromSpecs([
    {
      title: "libadblock browser whitelist",
      files: [path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.browserWhitelist), path.join(bundledFiltersDir, FILTER_FILE_NAMES.browserWhitelist)],
      allow: true,
      ruleOptions: ["document"]
    },
    {
      title: "libadblock browser blocklist",
      files: [path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.browserBlocklist), path.join(bundledFiltersDir, FILTER_FILE_NAMES.browserBlocklist)],
      ruleOptions: ["document"]
    },
    {
      title: "libadblock tracker blocklist",
      files: [path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.trackerBlocklist), path.join(bundledFiltersDir, FILTER_FILE_NAMES.trackerBlocklist)],
      ruleOptions: ["third-party"]
    },
    {
      title: "libadblock strict tracker blocklist",
      files: [path.join(resolvedFilterlistDir, FILTER_FILE_NAMES.trackerStrictBlocklist), path.join(bundledFiltersDir, FILTER_FILE_NAMES.trackerStrictBlocklist)]
    }
  ]);
  const resolvedRemoteFilterLists = await resolveRemoteFilterLists({
    app,
    remoteFilterLists,
    filterlistDir: resolvedFilterlistDir,
    bundledFiltersDir,
    fetchImpl: resolvedFetchImpl,
    logger: log
  });
  if (enableCosmeticFiltering) {
    installCosmeticFilterInjection({
      app,
      filterlistDir: resolvedFilterlistDir,
      bundledFiltersDir,
      disabledSites,
      logger: log
    });
  }
  const metadataFile = path.join(resolvedFilterlistDir, METADATA_FILE);
  const lockFile = path.join(resolvedFilterlistDir, REFRESH_LOCK_FILE);
  const hadCacheAtStartup = fs.existsSync(resolvedCacheFile);
  const cacheIsStale = isFileOlderThan(resolvedCacheFile, cacheMaxAgeMs);
  const cacheInvalidatedBySource = isAnyFileNewerThan(cacheInvalidationFiles, resolvedCacheFile);
  const filterSetSources = [
    ...resolvedRemoteFilterLists,
    localCosmeticDataUrl,
    localNetworkDataUrl,
    enableTwitchAdBlocking ? TWITCH_ADBLOCK_FILTER_LIST : "",
    enableTwitchAdBlocking ? getTwitchAdblockSource() : ""
  ].filter(Boolean);
  const filterSetVersion = getFilterSetVersion(filterSetSources);
  const metadata = getStorageMetadata(metadataFile);
  const metadataIsCurrent = metadataMatchesCurrentFilters(metadata, filterSetSources);
  const cacheMetadataInvalid = hadCacheAtStartup && !metadataIsCurrent;
  const shouldRefreshStaleCacheInBackground = hadCacheAtStartup && !cacheInvalidatedBySource && refreshStaleCacheInBackground && cacheIsStale && !cacheMetadataInvalid;

  await fs.promises.mkdir(resolvedFilterlistDir, {
    recursive: true
  });

  if (hadCacheAtStartup && (cacheInvalidatedBySource || cacheMetadataInvalid || (cacheIsStale && !refreshStaleCacheInBackground))) {
    try {
      await fs.promises.unlink(resolvedCacheFile);
    } catch {}
  }

  const filterLists = resolvedRemoteFilterLists.slice();
  const fallbackFilterLists = resolvedRemoteFilterLists.slice();
  const remoteListCount = filterLists.length;

  if (includeBundledCosmeticFilters) {
    if (localCosmeticDataUrl) {
      filterLists.push(localCosmeticDataUrl);
    }
  }

  if (localNetworkDataUrl) {
    filterLists.push(localNetworkDataUrl);
    fallbackFilterLists.push(localNetworkDataUrl);
  }

  if (enableTwitchAdBlocking) {
    filterLists.push(`data:text/plain;charset=utf-8,${encodeURIComponent(TWITCH_ADBLOCK_FILTER_LIST)}`);
    fallbackFilterLists.push(`data:text/plain;charset=utf-8,${encodeURIComponent(TWITCH_ADBLOCK_FILTER_LIST)}`);
  }

  const adblockCaching = {
    path: resolvedCacheFile,
    read: async (cachePath) => fs.promises.readFile(cachePath),
    write: async (cachePath, buffer) => {
      const tempFile = `${cachePath}.${process.pid}.tmp`;
      await fs.promises.writeFile(tempFile, buffer, {
        mode: 0o600
      });
      await fs.promises.rename(tempFile, cachePath);
      writeStorageMetadata(metadataFile, {
        filterSetVersion,
        cacheUpdatedAt: Date.now(),
        refreshedAt: Date.now()
      });
    }
  };

  let blocker = null;
  try {
    blocker = await ElectronBlocker.fromLists(
      resolvedFetchImpl,
      filterLists,
      {
        enableCompression: true,
        loadCosmeticFilters: loadEngineCosmeticFilters
      },
      adblockCaching
    );
  } catch (error) {
    blocker = await ElectronBlocker.fromLists(
      resolvedFetchImpl,
      fallbackFilterLists,
      {
        enableCompression: true,
        loadCosmeticFilters: loadEngineCosmeticFilters
      },
      adblockCaching
    );
  }

  if (shouldRefreshStaleCacheInBackground) {
    refreshAdblockCacheInBackground({
      ElectronBlocker,
      fetchImpl: resolvedFetchImpl,
      filterLists,
      remoteFilterLists: fallbackFilterLists,
      cacheFile: resolvedCacheFile,
      adblockCaching,
      metadataFile,
      lockFile,
      filterSetVersion,
      loadEngineCosmeticFilters,
      logger: log
    });
  }

  const stats = createAdblockStats();
  blocker.libadblockStats = stats;
  blocker.getLibadblockStats = () => ({
    blockedCount: stats.blockedCount,
    blockedByType: {
      ...stats.blockedByType
    },
    lastBlockedUrl: stats.lastBlockedUrl,
    lastBlockedAt: stats.lastBlockedAt
  });

  blocker.on("request-blocked", (event) => {
    const record = recordBlockedRequest(stats, event);
    if (logBlockedRequests) {
      logBlockedRequest(log, record, {
        logBlockedUrls,
        logBlockedSummaryInterval
      });
    }
    if (typeof onRequestBlocked === "function") {
      onRequestBlocked(event, record);
    }
  });

  return blocker;
}

async function installAdblock(options = {}) {
  const { app, session, autoEnableSession = true } = options;
  if (!app || !session) {
    throw new Error("installAdblock requires app and session.");
  }

  const preloadPromise = installLibadblockPreload(options);
  const blocker = await createAdblockEngine(options);
  blocker.libadblockPreload = await preloadPromise;
  if (autoEnableSession) {
    blocker.enableBlockingInSession(session);
  }

  return blocker;
}

module.exports = {
  FILTERLIST_REFRESH_INTERVAL_MS,
  FILTER_FILE_NAMES,
  FILTER_REMOTE_URLS,
  LIBADBLOCK_VERSION,
  REMOTE_FILTER_LISTS,
  createAdblockEngine,
  createFilterPaths,
  ensureBundledFilterSeededToUserConfig,
  ensureDirectory,
  getCosmeticCssForUrl,
  getDefaultFilterlistDir,
  getTwitchAdblockSource,
  hostMatchesDomainSet,
  installCosmeticFilterInjection,
  filterAdblockEngineFilterLists,
  isAdblockEngineFilterListUrl,
  urlMatchesDomainSetRules,
  installAdblock,
  installLibadblockPreload,
  isFileOlderThan,
  loadCosmeticRulesFromFile,
  loadDomainSetFromFilterFiles,
  readUserAgentOverrideRules,
  readUserAgentOverrideRulesFromFiles,
  readChromeVersionFromUserAgentOverrides,
  resolveUserAgentOverrideValue,
  shouldBlockByAdScriptPath,
  shouldBlockByLightweightTrackerRules,
  updateRemoteFilterFiles,
  updateRemoteFilterFile
};
