# LibAdblock

LibAdblock is a adblocker for electron apps powered by adblocker-electron
&nbsp;&nbsp;&nbsp;&nbsp;

## How to use

At the top of your main proccess you will have the following

```
const { app, session } = require('electron');
//LibAdblock
const { installAdblock } = require('./libadblock/libadblock');
```

`libadblock` also resolves LibElectron User-Agent override tokens used by its preload rules. Existing rules such as `PHOENIX_WINDOWS` are converted to a Windows desktop Chrome-compatible User-Agent instead of being injected literally.

```txt
! libelectron-user-agent: watch.foxtel.com.au|PHOENIX_WINDOWS
```

 ### Author
  * Corey Bruce
