# Libsplash

Lib splash is a splashscreen used for electron apps that also handles redirecting and offline handling if the server is down or the user is offline

&nbsp;&nbsp;&nbsp;&nbsp;

## How to use

At the top of your main proccess you will have the following

```
const { app, BrowserWindow, BrowserView, shell, session, ipcMain, net } = require('electron');
const path = require('path');
const https = require('https');
//LibSplash
const { installLibSplash } = require('./libsplash/libsplash');
const splashIcon = 'tiktok.svg';
const { version } = require('./package.json');
const packageInfo = require('./package.json');

const libSplash = installLibSplash({
  app,
  ipcMain,
  net,
  packageInfo,
  splashIcon,
  BrowserView,
  pingPartition: 'libsplash-ping',
  pingRequestHeaders: {
    'User-Agent': customUserAgent,
  },
  readinessPromises: [adblockReadyPromise, userAgentReadyPromise],
  pingTimeoutMs: typeof DEFAULT_PING_TIMEOUT_MS !== 'undefined' ? DEFAULT_PING_TIMEOUT_MS : undefined,
});
```

`pingRequestHeaders` is optional. Use it when a server or CDN expects the same request headers as the app window, for example a browser-like `User-Agent`. Libsplash does not set any app-specific headers by default.

`pingSession` and `pingPartition` are optional. Use one of them when app-level session handlers, such as adblockers or request filters, should not affect splash health checks. If installing libsplash before `app.whenReady()`, prefer `pingPartition` so the Electron session can be created lazily when the ping runs.

For overlay mode, create your normal app window first and then show libsplash as an embedded overlay inside that window. Libsplash will keep showing until it can connect to a `ServerUrls` entry, waits for optional readiness promises such as libadblock or libuseragent filter updates, loads the app URL behind the overlay, then removes itself. This avoids creating a second app window in desktop shells such as GNOME.

```
const mainWindow = new BrowserWindow({ ... });
mainWindow.show();

libSplash.show(mainWindow);
```

`libSplash.show(mainWindow)` displays libsplash as a `BrowserView` overlay inside the existing app window, like Phoenix overlays. It does not create a child `BrowserWindow`.

You will need to create or update your preload.js to have the following

```
const { contextBridge, ipcRenderer } = require('electron')

if (window.location.protocol === 'file:' && window.location.pathname.endsWith('/libsplash/libsplash.html')) {
  contextBridge.exposeInMainWorld('appSplash', {
    getConfig: () => ipcRenderer.invoke('app:get-splash-config'),
    pingUrl: (url, timeoutMs) => ipcRenderer.invoke('app:ping-url', url, timeoutMs),
    resolveUrl: (url, timeoutMs) => ipcRenderer.invoke('app:resolve-url', url, timeoutMs),
    openUrl: (url) => ipcRenderer.invoke('app:open-url', url),
  })
}
```

`pingUrl` is kept for backward compatibility and still returns only a number or `null`. New overlay clients should expose `resolveUrl` and `openUrl`.

Apps with old `main.js` and old preload code can use this newer `libsplash` without changes. They will keep the original full-window splash behavior using `mainWindow.loadFile(path.join('libsplash', 'libsplash.html'))` and redirect through `pingUrl`. Overlay mode, redirect-aware loading behind the splash, and readiness waiting require `libSplash.show(mainWindow)`, `resolveUrl`, `openUrl`, and optional `readinessPromises` integration.

When an app requires a shared/new `libsplash.js` from outside its app folder, `installLibSplash` will try to sync the newer `libsplash` assets into the app's local `libsplash/` folder. This is best-effort and ignored if the source and app folders are the same or the app folder is read-only. Pass `syncAssets: false` to disable it.

You can as a developer override the ping time in your main.js but I would be careful to not do anything lower then 15 seconds as it could cause DDOSing and a lot of unneeded traffic 

```
const DEFAULT_PING_TIMEOUT_MS = 15000;
```

 ### Author
  * Corey Bruce
