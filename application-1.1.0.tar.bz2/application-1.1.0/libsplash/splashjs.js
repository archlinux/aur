/* == splashjs == */

const CHECK_INTERVAL_MS = 30000;
const REDIRECT_DELAY_MS = 1500;
const MANAGED_OPEN_REDIRECT_DELAY_MS = 0;
const MIN_VISIBLE_MS = 2000;
const STATUS_CHECK_DELAY_MS = 550;
const PING_TIMEOUT_MS = 15000;

async function loadJson(file) {
  const response = await fetch(file, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Failed to load ${file}`);
  return response.json();
}

async function loadSplashConfig() {
  if (window.appSplash) {
    return window.appSplash.getConfig();
  }

  const [packageInfo, serverHost] = await Promise.all([
    loadJson('../package.json'),
    loadJson('../serverhost.json'),
  ]);

  return {
    name: packageInfo.name,
    version: packageInfo.version,
    serverUrls: serverHost.ServerUrls,
  };
}

async function pingServer(url) {
  if (window.appSplash?.resolveUrl) {
    return window.appSplash.resolveUrl(url);
  }

  if (window.appSplash) {
    return window.appSplash.pingUrl(url);
  }

  const start = performance.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), PING_TIMEOUT_MS);

  try {
    const response = await fetch(url, { method: 'HEAD', cache: 'no-store', signal: controller.signal });
    return response.ok ? performance.now() - start : null;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function normalizePingResult(result, fallbackUrl) {
  if (typeof result === 'number') {
    return { timeMs: result, url: fallbackUrl };
  }

  if (result && typeof result === 'object' && typeof result.timeMs === 'number') {
    return { timeMs: result.timeMs, url: result.url || fallbackUrl };
  }

  return null;
}

function hasManagedOpen() {
  return Boolean(window.appSplash?.openUrl);
}

async function openAppUrl(url) {
  if (window.appSplash?.openUrl) {
    return window.appSplash.openUrl(url);
  }

  window.location.replace(url);
  return true;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForMinimumVisible(startedAt) {
  const remainingMs = MIN_VISIBLE_MS - (performance.now() - startedAt);
  if (remainingMs > 0) {
    await wait(remainingMs);
  }
}

function playOfflineSound() {
  const audio = document.getElementById('offlineerror');
  if (audio) {
    audio.play().catch((err) => {
      console.warn('Autoplay blocked or failed:', err);
    });
  }
}

function setAppName(name) {
  const appName = name || 'Application';
  document.title = appName;

  const offlineAppName = document.getElementById('offline-app-name');
  if (offlineAppName) offlineAppName.textContent = appName;
}

function setAppIcon(icon) {
  const logo = document.querySelector('.logo');
  if (logo && icon) logo.style.backgroundImage = `url(${JSON.stringify(icon)})`;
}

function setStatus(statusPill, statusText, spinner, state, text) {
  if (statusPill) {
    statusPill.classList.remove('green', 'yellow', 'red');
    statusPill.classList.add(state);
  }

  if (statusText) statusText.textContent = text;
  if (spinner) spinner.style.display = state === 'yellow' ? 'inline-block' : 'none';
}

function showOffline(offlineOverlay) {
  if (!offlineOverlay) return;

  const wasHidden = offlineOverlay.style.display === 'none';
  offlineOverlay.style.display = 'flex';

  if (wasHidden) playOfflineSound();
}

document.addEventListener('DOMContentLoaded', async () => {
  const splashStartedAt = performance.now();
  const statusPill = document.getElementById('status-pill');
  const statusText = document.getElementById('status-text');
  const spinner = document.getElementById('spinner');
  const offlineOverlay = document.getElementById('offline-overlay');
  let isChecking = false;

  try {
    const config = await loadSplashConfig();
    const urls = config.serverUrls;

    setAppName(config.name);
    setAppIcon(config.icon);

    if (!Array.isArray(urls) || urls.length === 0) {
      throw new Error('No ServerUrls found in serverhost.json.');
    }

    async function checkStatus() {
      if (isChecking) return;
      isChecking = true;

      try {
        setStatus(statusPill, statusText, spinner, 'yellow', 'Checking status...');
        await wait(STATUS_CHECK_DELAY_MS);

        for (const url of urls) {
          const ping = normalizePingResult(await pingServer(url), url);
          if (ping) {
            setStatus(statusPill, statusText, spinner, 'green', `Online (${ping.timeMs.toFixed(1)} ms), redirecting...`);
            if (hasManagedOpen()) {
              setTimeout(async () => {
                await waitForMinimumVisible(splashStartedAt);
                openAppUrl(ping.url).catch(() => window.location.replace(ping.url));
              }, MANAGED_OPEN_REDIRECT_DELAY_MS);
            } else {
              setTimeout(() => {
                window.location.replace(url);
              }, REDIRECT_DELAY_MS);
            }
            return;
          }
        }

        setStatus(statusPill, statusText, spinner, 'red', 'Offline');
        showOffline(offlineOverlay);
      } finally {
        isChecking = false;
      }
    }

    await checkStatus();
    setInterval(checkStatus, CHECK_INTERVAL_MS);
  } catch (err) {
    console.error('Fatal splash error:', err);
    setStatus(statusPill, statusText, spinner, 'red', 'Offline');
    showOffline(offlineOverlay);
  }
});
