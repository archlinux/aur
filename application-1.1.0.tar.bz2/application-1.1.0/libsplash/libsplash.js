const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

const DEFAULT_PING_TIMEOUT_MS = 15000;
const DEFAULT_READY_TIMEOUT_MS = 60000;
const DEFAULT_OPEN_TIMEOUT_MS = 10000;
const LIBSPLASH_OVERLAY_MODE = 'browser-view-overlay';
const LIBSPLASH_ASSET_FILES = Object.freeze([
  'error.mp3',
  'libsplash.html',
  'libsplash.js',
  'package.json',
  'README.md',
  'splashjs.js',
  'styles.css',
]);
const overlayHosts = new Map();

function toPromiseArray(value) {
  if (typeof value === 'function') return toPromiseArray(value());
  if (!value) return [];
  return (Array.isArray(value) ? value : [value]).filter(Boolean);
}

function getBrowserWindowFromEvent(event) {
  try {
    const { BrowserWindow } = require('electron');
    return BrowserWindow.fromWebContents(event.sender);
  } catch {
    return null;
  }
}

function getSplashHostFromEvent(event) {
  const embeddedHost = overlayHosts.get(event.sender?.id);
  if (embeddedHost) return embeddedHost;

  const splashWindow = getBrowserWindowFromEvent(event);
  if (!splashWindow) return null;

  return {
    splashWindow,
    parentWindow: splashWindow.getParentWindow?.(),
  };
}

function closeSplashHost(host) {
  if (!host) return;

  if (host.splashView && host.parentWindow && !host.parentWindow.isDestroyed?.()) {
    const webContentsId = host.splashView.webContents?.id;
    try {
      host.parentWindow.removeBrowserView(host.splashView);
    } catch {}
    try {
      if (!host.splashView.webContents?.isDestroyed?.()) host.splashView.webContents.destroy();
    } catch {}
    overlayHosts.delete(webContentsId);
    return;
  }

  if (host.splashWindow && !host.splashWindow.isDestroyed?.()) {
    host.splashWindow.close();
  }
}

function waitForWebContentsReady(webContents, timeoutMs = DEFAULT_OPEN_TIMEOUT_MS) {
  return new Promise((resolve) => {
    if (!webContents || webContents.isDestroyed?.()) {
      resolve();
      return;
    }

    const cleanup = () => {
      if (timeout) clearTimeout(timeout);
      webContents.removeListener?.('dom-ready', finish);
      webContents.removeListener?.('did-fail-load', finish);
      webContents.removeListener?.('destroyed', finish);
    };
    const finish = () => {
      cleanup();
      resolve();
    };

    const timeout = setTimeout(finish, timeoutMs);
    webContents.once?.('dom-ready', finish);
    webContents.once?.('did-fail-load', finish);
    webContents.once?.('destroyed', finish);
  });
}

async function waitForReadiness(promises, timeoutMs) {
  const pending = toPromiseArray(promises);
  if (!pending.length) return;

  const effectiveTimeoutMs = Number.isFinite(timeoutMs) && timeoutMs > 0
    ? timeoutMs
    : DEFAULT_READY_TIMEOUT_MS;
  let timeout;
  try {
    await Promise.race([
      Promise.allSettled(pending),
      new Promise((resolve) => {
        timeout = setTimeout(resolve, effectiveTimeoutMs);
      }),
    ]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

function syncLibSplashAssets(app, options = {}) {
  const sourceDir = options.sourceDir || __dirname;
  const targetDir = path.join(app.getAppPath(), 'libsplash');

  try {
    if (fs.realpathSync(sourceDir) === fs.realpathSync(targetDir)) {
      return { synced: false, reason: 'same-directory' };
    }
  } catch {}

  if (path.resolve(sourceDir) === path.resolve(targetDir)) {
    return { synced: false, reason: 'same-directory' };
  }

  try {
    fs.mkdirSync(targetDir, { recursive: true });
    for (const fileName of LIBSPLASH_ASSET_FILES) {
      const sourceFile = path.join(sourceDir, fileName);
      const targetFile = path.join(targetDir, fileName);
      if (fs.existsSync(sourceFile)) {
        fs.copyFileSync(sourceFile, targetFile);
      }
    }

    return { synced: true, targetDir };
  } catch (error) {
    return { synced: false, reason: error?.message || String(error) };
  }
}

function installLibSplash({ app, ipcMain, net, packageInfo, splashIcon, BrowserView, pingTimeoutMs, pingRequestHeaders, pingSession, pingPartition, readyTimeoutMs, readinessPromises, onReadyToShow, syncAssets = true, syncAssetsSourceDir } = {}) {
  if (!app || !ipcMain || !net || !packageInfo || !splashIcon) {
    throw new Error('installLibSplash requires app, ipcMain, net, packageInfo, and splashIcon.');
  }

  const syncResult = syncAssets ? syncLibSplashAssets(app, { sourceDir: syncAssetsSourceDir }) : null;

  const defaultPingTimeoutMs = Number.isFinite(pingTimeoutMs) && pingTimeoutMs > 0
    ? pingTimeoutMs
    : DEFAULT_PING_TIMEOUT_MS;
  let serverUrls = [];
  let allowedServerUrls = new Set();
  let pendingReadinessPromises = toPromiseArray(readinessPromises);

  function setReadinessPromises(promises) {
    pendingReadinessPromises = toPromiseArray(promises);
  }

  async function loadServerUrls() {
    const serverHostPath = path.join(app.getAppPath(), 'serverhost.json');
    const serverHost = JSON.parse(await fs.promises.readFile(serverHostPath, 'utf8'));

    serverUrls = Array.isArray(serverHost.ServerUrls) ? serverHost.ServerUrls : [];
    allowedServerUrls = new Set(serverUrls);

    return serverUrls;
  }

  function isAllowedPingUrl(url) {
    try {
      const parsedUrl = new URL(url);
      return (parsedUrl.protocol === 'http:' || parsedUrl.protocol === 'https:') && allowedServerUrls.has(url);
    } catch {
      return false;
    }
  }

  function assertSplashSender(event) {
    const splashUrl = pathToFileURL(path.join(app.getAppPath(), 'libsplash', 'libsplash.html')).toString();

    if (event.senderFrame?.url !== splashUrl) {
      throw new Error('appSplash is only available to libsplash.html');
    }
  }

  ipcMain.handle('app:get-splash-config', async (event) => {
    assertSplashSender(event);

    const currentServerUrls = await loadServerUrls();

    return {
      name: packageInfo.name,
      version: packageInfo.version,
      icon: pathToFileURL(path.join(app.getAppPath(), splashIcon)).toString(),
      pingTimeoutMs: defaultPingTimeoutMs,
      serverUrls: currentServerUrls,
    };
  });

  ipcMain.handle('app:ping-url', (event, url, timeoutMs) => {
    assertSplashSender(event);

    if (!isAllowedPingUrl(url)) {
      return null;
    }

    return pingUrl(url, timeoutMs).then((result) => result?.timeMs ?? null);
  });

  function pingUrl(url, timeoutMs) {
    const effectivePingTimeoutMs = Number.isFinite(timeoutMs) && timeoutMs > 0
      ? timeoutMs
      : defaultPingTimeoutMs;

    return new Promise((resolve) => {
      const startedAt = Date.now();
      let request;
      let settled = false;
      let timeout;
      const finish = (result) => {
        if (settled) return;
        settled = true;
        if (timeout) clearTimeout(timeout);
        resolve(result);
      };

      try {
        const requestOptions = { method: 'GET', url };
        if (pingSession) requestOptions.session = pingSession;
        if (!requestOptions.session && pingPartition) {
          try {
            requestOptions.session = require('electron').session.fromPartition(pingPartition);
          } catch {}
        }
        request = net.request(requestOptions);
      } catch {
        finish(null);
        return;
      }

      if (pingRequestHeaders && typeof pingRequestHeaders === 'object') {
        for (const [name, value] of Object.entries(pingRequestHeaders)) {
          if (typeof value !== 'string') continue;
          try {
            request.setHeader(name, value);
          } catch {}
        }
      }

      timeout = setTimeout(() => {
        request.abort();
        finish(null);
      }, effectivePingTimeoutMs);

      request.on('redirect', (statusCode, method, redirectUrl) => {
        try {
          const parsedRedirectUrl = new URL(redirectUrl);
          if ((statusCode >= 300 && statusCode < 400) && (parsedRedirectUrl.protocol === 'http:' || parsedRedirectUrl.protocol === 'https:')) {
            finish({ timeMs: Date.now() - startedAt, url: redirectUrl });
            request.abort();
          }
        } catch {
          finish(null);
        }
      });

      request.on('response', (response) => {
        finish(response.statusCode >= 200 && response.statusCode < 400 ? { timeMs: Date.now() - startedAt, url } : null);
        response.on?.('error', () => {});
        response.resume?.();
      });

      request.on('error', () => {
        finish(null);
      });

      request.end();
    });
  }

  ipcMain.handle('app:resolve-url', (event, url, timeoutMs) => {
    assertSplashSender(event);

    if (!isAllowedPingUrl(url)) {
      return null;
    }

    return pingUrl(url, timeoutMs);
  });

  ipcMain.handle('app:open-url', async (event, url) => {
    assertSplashSender(event);

    const targetUrl = String(url || '');
    if (!targetUrl) return false;

    await waitForReadiness(pendingReadinessPromises, readyTimeoutMs);

    const splashHost = getSplashHostFromEvent(event);

    if (typeof onReadyToShow === 'function') {
      await onReadyToShow(targetUrl, event);
    } else {
      const parentWindow = splashHost?.parentWindow;
      if (parentWindow && !parentWindow.isDestroyed?.()) {
        const ready = waitForWebContentsReady(parentWindow.webContents);
        await parentWindow.loadURL(targetUrl).catch(() => {});
        await ready;
      }
    }

    closeSplashHost(splashHost);

    return true;
  });

  return {
    syncResult,
    setReadinessPromises,
    show: (parentWindow, overlayOptions = {}) => createLibSplashOverlay({
      app,
      BrowserView: overlayOptions.BrowserView || BrowserView,
      parentWindow,
      ...overlayOptions,
    }),
    createOverlay: (parentWindow, overlayOptions = {}) => createLibSplashOverlay({
      app,
      BrowserView: overlayOptions.BrowserView || BrowserView,
      parentWindow,
      ...overlayOptions,
    }),
  };
}

function createLibSplashOverlay({ app, BrowserView, parentWindow, width, height, backgroundColor = '#2C2C2C' } = {}) {
  if (!app || !parentWindow) {
    throw new Error('createLibSplashOverlay requires app and parentWindow.');
  }

  const ViewClass = BrowserView || (() => {
    try {
      return require('electron').BrowserView;
    } catch {
      return null;
    }
  })();

  if (!ViewClass) {
    throw new Error('createLibSplashOverlay requires Electron BrowserView support.');
  }

  if (ViewClass.name === 'BrowserWindow') {
    throw new Error('createLibSplashOverlay requires BrowserView, not BrowserWindow. Prefer installLibSplash(...).show(parentWindow).');
  }

  const splashFile = path.join(app.getAppPath(), 'libsplash', 'libsplash.html');

  const splashView = new ViewClass({
    webPreferences: {
      contextIsolation: true,
      preload: path.join(app.getAppPath(), 'preload.js'),
    },
  });
  splashView.setBackgroundColor?.(backgroundColor);
  const getSplashWebContents = () => splashView.webContents || splashView.getWebContents?.();

  const updateSplashScale = (viewWidth, viewHeight) => {
    const webContents = getSplashWebContents();
    if (!webContents || webContents.isDestroyed?.()) return;
    const usableWidth = Number(viewWidth) || 0;
    const usableHeight = Number(viewHeight) || 0;
    if (!usableWidth || !usableHeight) return;

    const scale = Math.min(1, usableWidth * 0.7 / 340, usableHeight * 0.72 / 446);
    webContents.executeJavaScript(`(() => {
      document.documentElement.style.setProperty('--splash-scale', ${JSON.stringify(String(scale))});
      window.dispatchEvent(new Event('resize'));
    })();`, true).catch(() => {});
  };

  const syncBounds = () => {
    const webContents = getSplashWebContents();
    if (webContents?.isDestroyed?.() || parentWindow.isDestroyed?.()) return;
    const [contentWidth, contentHeight] = parentWindow.getContentSize?.() || [];
    const bounds = parentWindow.getContentBounds?.() || parentWindow.getBounds();
    const nextWidth = width || contentWidth || bounds.width;
    const nextHeight = height || contentHeight || bounds.height;
    splashView.setBounds({
      x: 0,
      y: 0,
      width: nextWidth,
      height: nextHeight,
    });
    updateSplashScale(nextWidth, nextHeight);
  };
  const syncBoundsSoon = () => {
    syncBounds();
    setTimeout(syncBounds, 0);
    setTimeout(syncBounds, 100);
    setTimeout(syncBounds, 300);
  };
  const syncBoundsTimer = setInterval(syncBounds, 500);

  const cleanup = () => {
    clearInterval(syncBoundsTimer);
    parentWindow.removeListener('show', syncBoundsSoon);
    parentWindow.removeListener('resize', syncBoundsSoon);
    parentWindow.removeListener('restore', syncBoundsSoon);
    parentWindow.removeListener('maximize', syncBoundsSoon);
    parentWindow.removeListener('unmaximize', syncBoundsSoon);
    parentWindow.removeListener('enter-full-screen', syncBoundsSoon);
    parentWindow.removeListener('leave-full-screen', syncBoundsSoon);
    const webContents = getSplashWebContents();
    webContents?.removeListener?.('did-finish-load', syncBoundsSoon);
    overlayHosts.delete(webContents?.id);
  };

  parentWindow.addBrowserView(splashView);
  parentWindow.setTopBrowserView(splashView);
  splashView.setAutoResize?.({ width: true, height: true });
  parentWindow.on('show', syncBoundsSoon);
  parentWindow.on('resize', syncBoundsSoon);
  parentWindow.on('restore', syncBoundsSoon);
  parentWindow.on('maximize', syncBoundsSoon);
  parentWindow.on('unmaximize', syncBoundsSoon);
  parentWindow.on('enter-full-screen', syncBoundsSoon);
  parentWindow.on('leave-full-screen', syncBoundsSoon);
  parentWindow.once('closed', cleanup);
  const webContents = getSplashWebContents();
  webContents?.once?.('destroyed', cleanup);
  webContents?.on?.('did-finish-load', syncBoundsSoon);

  if (webContents) overlayHosts.set(webContents.id, { splashView, parentWindow });
  syncBoundsSoon();
  webContents?.loadFile(splashFile);

  return splashView;
}

module.exports = {
  LIBSPLASH_OVERLAY_MODE,
  installLibSplash,
  createLibSplashOverlay,
  syncLibSplashAssets,
};
