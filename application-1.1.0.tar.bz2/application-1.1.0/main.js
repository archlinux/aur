const { app, components, BrowserWindow, BrowserView, shell, session, ipcMain, net } = require('electron');
const path = require('path');
const https = require('https');
//LibAdblock
const { installAdblock, resolveUserAgentOverrideValue } = require('./libadblock/libadblock');
let adblockReadyPromise = Promise.resolve();

const DEFAULT_PING_TIMEOUT_MS = 15000;
const customUserAgent = resolveUserAgentOverrideValue('PHOENIX_WINDOWS');

//LibSplash
const { installLibSplash, createLibSplashOverlay } = require('./libsplash/libsplash');
const splashIcon = 'foxtelgo.svg';
const { version } = require('./package.json');
const packageInfo = require('./package.json');
const libSplash = installLibSplash({
  app,
  ipcMain,
  net,
  packageInfo,
  splashIcon,
  BrowserView,
  pingPartition: 'libsplash-ping',
  pingRequestHeaders: {
    'User-Agent': customUserAgent,
  },
  readinessPromises: () => [adblockReadyPromise],
  pingTimeoutMs: typeof DEFAULT_PING_TIMEOUT_MS !== 'undefined' ? DEFAULT_PING_TIMEOUT_MS : undefined,
});

const appName = packageInfo.productName || packageInfo.name;
const appId = (packageInfo.build && packageInfo.build.appId)
  || `com.${appName.toLowerCase().replace(/[^a-z0-9]+/g, '')}.app`;
const startupWmClass = appName.replace(/\s+/g, '');
const desktopBaseName = (packageInfo.name || appName).toLowerCase().replace(/\s+/g, '');
const desktopFileName = `${desktopBaseName}.desktop`;

app.setName(appName);

if (process.platform === 'win32') {
  app.setAppUserModelId(appId);
}

if (process.platform === 'linux') {
  app.setDesktopName(desktopFileName);
  app.commandLine.appendSwitch('class', startupWmClass);
}

// Dynamically import electron-context-menu (default export)
import('electron-context-menu').then((contextMenuModule) => {
  const contextMenu = contextMenuModule.default;

  contextMenu({
    prepend: (defaultActions, parameters, browserWindow) => [
      //{
        //label: 'Save Image',
        // Only show it when right-clicking images
        //visible: parameters.mediaType === 'image'
      //},
      {
        label: 'Search Google for “{selection}”',
        // Only show it when right-clicking text
        visible: parameters.selectionText.trim().length > 0,
        click: () => {
          shell.openExternal(`https://google.com/search?q=${encodeURIComponent(parameters.selectionText)}`);
        }
      }
    ]
  });
});



function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1360,
    height: 765,
    icon: __dirname + '/icon.png',
    backgroundColor: '#2C2C2C',
    webPreferences: {
      contextIsolation: true,
      preload: path.join(app.getAppPath(), 'preload.js'),
    }
  });

  mainWindow.maximize();
  mainWindow.setMenuBarVisibility(false);
  mainWindow.setMenu(null);

  if (typeof libSplash.show === 'function') {
    libSplash.show(mainWindow);
  } else {
    createLibSplashOverlay({ app, BrowserView, parentWindow: mainWindow });
  }
  mainWindow.show();
}

app.whenReady().then(async () => {
  await components.whenReady();
  console.log('components ready:', components.status());

  createWindow();

  try {
    await installAdblock({
      app,
      session: session.defaultSession,
      resolveUserAgentOverrideValue: (value) => resolveUserAgentTemplate(value, { app }),
    });
  } catch (error) {
    console.warn('Adblock: failed to initialize:', error?.message || error);
  }
});

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.


// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On macOS it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', function () {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (BrowserWindow.getAllWindows().length === 0) createWindow()
})
