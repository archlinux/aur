// All of the Node.js APIs are available in the preload process.
// It has the same sandbox as a Chrome extension.
const { contextBridge, ipcRenderer } = require('electron')

if (window.location.protocol === 'file:' && window.location.pathname.endsWith('/libsplash/libsplash.html')) {
  contextBridge.exposeInMainWorld('appSplash', {
    getConfig: () => ipcRenderer.invoke('app:get-splash-config'),
    pingUrl: (url, timeoutMs) => ipcRenderer.invoke('app:ping-url', url, timeoutMs),
    resolveUrl: (url, timeoutMs) => ipcRenderer.invoke('app:resolve-url', url, timeoutMs),
    openUrl: (url) => ipcRenderer.invoke('app:open-url', url),
  })
}

window.addEventListener('DOMContentLoaded', () => {
  const replaceText = (selector, text) => {
    const element = document.getElementById(selector)
    if (element) element.innerText = text
  }

  for (const type of ['chrome', 'node', 'electron']) {
    replaceText(`${type}-version`, process.versions[type])
  }
})
