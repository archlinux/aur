# Changelog

## 0.1.1 (2020-09-19)

Fixes the search input not being URL encoded, for example `x y!f` wouldn't appropriately URL encode the space character between `x` and `y`.

## 0.1.0 (2020-09-17)

bangin's initial release!

