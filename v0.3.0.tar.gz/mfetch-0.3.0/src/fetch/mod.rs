pub mod dmi;
pub mod mem;
pub mod spd;
