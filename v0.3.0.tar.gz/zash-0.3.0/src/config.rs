// This file is currently not used
 
pub struct Config {
    // Completion
    CompletionType: String,
    EditMode: String,
    OutputStream: String,
    Validator: bool,

    // History
    IgnoreSpaces: bool,
    HistoryPath: String,

    // Shell
    Prompt: String
}

