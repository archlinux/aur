#include "src/types.hpp"

#if defined(DEBUG) && !defined(_WIN32)
#include "src/core/traceable-exception.hpp"
#include <execinfo.h>
#include <exception>
#include <iostream>
#include <csignal>
#include <cstdlib>
#endif

#include <QGuiApplication>
#include <QApplication>
#include <QMessageBox>
#include <set>
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/ui/direct-play.hpp"
#include "src/ui/main-window.hpp"
#include "src/ui/ui-fixes.hpp"
#ifdef _WIN32
#include <QInputDialog>
#include "src/windows-updater/windows-updater.hpp"
#include "src/polyfill/windows/unicode.hpp"

static const char *const m_msgInstallRetroArch = ""
	"RetroArch does not appear to be installed. You can install it by going to "
	"https://www.retroarch.com/ and clicking 'Get RetroArch' then 'Download Stable'.";
#else
#include "src/polyfill/base-directory.hpp"

static const char *const m_msgInstallRetroArch = ""
	"RetroArch does not appear to be installed. You can install it by going to "
	"https://www.retroarch.com/ and clicking 'Get RetroArch' then 'Download Stable'. "
	"If you are using a custom build of RetroArch, ensure that the folder containing "
	"your RetroArch binary is in your $PATH variable.";
#endif

static int runMainWindow( QApplication &app ) {
	QGuiApplication::setQuitOnLastWindowClosed( false );
	MainWindow mainWindow;
	mainWindow.show();
	return app.exec();
}

#if defined(DEBUG) && !defined(_WIN32)
extern "C" void onSegfault( [[maybe_unused]] int signal ) {
	void *trace[32];
	int frames = backtrace( trace, 32 );
	backtrace_symbols_fd( trace, frames, 2 );
	std::cerr << "Segmentation Fault" << std::endl << std::flush;
	std::_Exit( EXIT_FAILURE );
}

static void onTerminate() {
	const std::exception_ptr ep = std::current_exception();
	if( !ep ) return;

	try {
		std::rethrow_exception( ep );
	} catch( const std::exception &exception ) {
		std::cerr << "Uncaught Exception: " << std::endl << exception.what() << std::endl;
		const TraceableException *traceableException = dynamic_cast<const TraceableException*>( &exception );
		if( traceableException != nullptr ) {
			traceableException->printBacktrace();
		}
		std::cerr << std::flush;
	} catch( ... ) {
		std::cerr << "Uncaught Exception: (non-std::exception)" << std::endl << std::flush;
	}

	std::abort();
}
#endif

static fs::path tryGetRomPath( int argc, [[maybe_unused]] char **argv ) {
	if( argc < 2 ) return fs::path();

#ifdef _WIN32
	const string romArg = Unicode::argvUtf8().at( 1 );
	const fs::path romPath = fs::to_path( romArg.c_str() );
#else
	const fs::path romPath = fs::path( argv[1] );
#endif

	static const std::set<string> s_allowedExtensions = std::set<string>{
		".z64", ".n64", ".v64",
		".Z64", ".N64", ".V64",
		".bps", ".BPS", ".Bps"
	};

	try {
		if( !fs::is_regular_file( romPath ) ) {
			return fs::path();
		}

		if( s_allowedExtensions.count( romPath.extension().u8string() ) <= 0 ) {
			return fs::path();
		}

		if( romPath.is_relative() ) {
			return fs::current_path() / romPath;
		}

		return romPath;

	} catch( ... ) {}

	return fs::path();
}

int main( int argc, char **argv ) {
#if defined(DEBUG) && !defined(_WIN32)
	std::signal( SIGSEGV, onSegfault );
	std::set_terminate( onTerminate );
#endif

	AppSettings settings = FileController::loadAppSettings();
	if( settings.migrationState < 1 ) {
#ifdef _WIN32
		FileController::fixFileEncodings();
#endif

		std::vector<ROM> romList = FileController::loadRomList();
		for( ROM &rom : romList ) {
			rom.fileVersion = 0;
		}
		FileController::saveRomList( romList );

		settings.migrationState = 1;
		FileController::saveAppSettings( settings );
	}

	QApplication app( argc, argv );
	applyUiFixes( app );

#ifdef _WIN32
	while( !RetroArch::isRetroArchInstalled() ) {
		const QString installDir = QInputDialog::getText( nullptr, "RetroArch Not Installed", m_msgInstallRetroArch, QLineEdit::Normal, settings.retroInstallDir.u8string().c_str() );
		if( installDir.isNull() ) {
			return 0;
		} else if( !installDir.isEmpty() ) {
			settings.retroInstallDir = fs::to_path( installDir.toStdString() );
			FileController::saveAppSettings( settings );
		}
	}
#else
	if( !RetroArch::isRetroArchInstalled() ) {
		QMessageBox::critical( nullptr, "RetroArch Not Installed", m_msgInstallRetroArch );
		return 0;
	}
#endif

	ushort major, minor;
	if( RetroArch::tryGetVersion( major, minor ) ) {
		if( major < 1 || (major == 1 && minor < 9) ) {
			QMessageBox::warning( nullptr, "Old RetroArch Version", "You are using an old version of RetroArch. Please upgrade to version 1.9.0 or later." );
		}
	} else {
		QMessageBox::warning( nullptr, "Unknown RetroArch Version", "Unable to determine RetroArch version. If you are using a version of RetroArch older than 1.9.0, some features may not work correctly." );
	}

#ifdef _WIN32
	WindowsUpdater::checkForUpdates();
#endif

	const fs::path romPath = (argc >= 2) ? tryGetRomPath( argc, argv ) : fs::path();
	const int exitCode = romPath.empty() ? runMainWindow( app ) : DirectPlay::start( app, romPath );

#ifndef _WIN32
	std::error_code err;
	fs::remove_all( BaseDir::homeTemp(), err );
#endif

	return exitCode;

}
