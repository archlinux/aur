use Astra;

sub pypi_valid{
	return Astra::getConfig 'setup.py';
}

sub pypi{
	my $file=pypi_valid;
	my ($name,$ver)=`python $file --name --version 2> /dev/null`;
	return unless $name&&$ver;
	map {chomp;} ($name,$ver);

	my @items=('(',$name,'#',$ver,')');
	foreach($Astra::align_left?@items:reverse @items){
		Astra::tput length>1?11:63;
		Astra::echo $_;
	}
}

1;
