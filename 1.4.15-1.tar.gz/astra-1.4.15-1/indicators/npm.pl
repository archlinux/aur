use Astra;

sub npm_valid{
	return Astra::getConfig 'package.json';
}

sub npm{
	my %data,my $file=npm_valid;
	open(my $fh,'<',$file) or return;
	while(keys %data<2&&(my $line=<$fh>)){
		chomp $line;
		$data{'name'}=$1 if $line=~/"name"\s*:\s*"([^"]+)"/;
		$data{'ver'}=$1 if $line=~/"version"\s*:\s*"([^"]+)"/;
	}

	Astra::tput 125;
	Astra::echo "($data{'name'}\@$data{'ver'})";
}

1;
