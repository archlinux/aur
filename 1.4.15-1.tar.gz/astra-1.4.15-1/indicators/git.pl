use Astra;

my $status=`git status -sb 2>&1`;
sub git_valid{
	return index($status,'Not a git repository')==-1;
}

sub git{
	my $text;
	if($status=~tr/\n//>1){
		Astra::tput 9;
	}elsif($status=~/ahead|behind/){
		Astra::tput 11;
	}else{
		Astra::tput 2;
	}

	$status=~/## (?:Initial commit on |)(.+?)(?=\.{3}|\n)/;
	$text.=$1;

	$tag=`git describe --tags --exact-match 2> /dev/null`;
	chomp $tag;
	$text.='#'.$tag if $tag!~/^\s*$/;

	$text.='~'.$1 if $status=~/behind ([0-9]+)/;
	$text.='+'.$1 if $status=~/ahead ([0-9]+)/;

	Astra::echo '('.$text.')';
}

1;
