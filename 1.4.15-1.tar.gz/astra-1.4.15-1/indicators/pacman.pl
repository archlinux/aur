use Astra;

sub pacman_valid{
	return Astra::getConfig 'PKGBUILD';
}

sub pacman{
	my $file=pacman_valid;
	open(my $fh,'<',$file) or return;

	(my $data=do {local $/;<$fh>})=~/pkgname=['"]?([^'"\n]+)['"]?\n/;
	my $name=$1;
	my $ver=join "-",map {/pkg(?:ver|rel)=([\d.]+)/} split("\n",$data);

	Astra::tput 6;
	Astra::echo "($name\@$ver)";
}

1;
