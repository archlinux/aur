# start package
package Astra;

use Cwd qw(cwd);
use strict;

my $cols,my $left_align,my %opts;

# search for file recursively
sub getConfig{
	my ($file,$depth,$dir)=@_;
	$depth||=-1;
	$dir||=cwd;
	chomp $dir;

	my $path="$dir/$file";
	return $path if -f $path;

	$dir=~s/(?<!^)\/?[^\/]*$//;
	return 0 if $dir eq '/'||!--$depth;
	return getConfig($file,$depth,$dir);
}

# tput wrapper
sub tput{
	return if $opts{'plain'};
	system 'tput sgr0'&&return if !length @_;

	foreach(@_){
		if($_ eq 'i'){
			system 'tput sitm';
		}elsif($_ eq 'b'){
			system 'tput bold';
		}elsif($_=~/\d+/){
			system 'tput setaf '.$_;
		}
	}
}

# right-aligned printing
sub echo{
	my $str=join ' ',@_;
	return unless (my $len=length $str);

	if($Astra::left_align){
		print $str;
	}else{
		printf "%${Astra::cols}s\r",$str;
		$Astra::cols-=$len;
	}
}

1;
