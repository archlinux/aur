# Astra
Version control and package manager identifiers for bash

![Astra demo](http://i.imgur.com/QEm2U2a.png?1)

## Installation
Clone this repository, `cd` in, and run make as root

```
git clone https://github.com/inoriy/astra
cd astra && sudo make
```

## Usage
For cli usage, see `astra --help` or `man 1 astra`.

To include astra in your bash prompt, add it in an escaped command substitution (`\$()`, so it executes every time the variable is invoked) at the beginning of your `PS1` variable (found in `~/.bashrc`, for the un-initiated).

```sh
# prompt outputs e.g. "inori@stardew ~/github/astra $ ... (master+1)"
export PS1="\$(astra git)\u@\h \w \$ "
```

## Contributing
To contribute patches or new indicators (see `man 3 astra` for API documentation), submit a [pull request](https://github.com/inoriy/astra/pulls).
