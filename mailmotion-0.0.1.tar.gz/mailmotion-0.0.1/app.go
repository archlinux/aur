package main

import (
	"time"
	// "github.com/spf13/viper"
	// "github.com/op/go-logging"
)

func findPicture() []string {

	return []string{}
}

func startApp() {
	// Remove picture before starting
	pictureList := findPicture()
	_ = pictureList
	
	for {
		time.Sleep(time.Second)
	}
}

func main() {
	// confPath := "cfg/"
	// confFilename := "mailmotion_sample"
	// logFilename := "error.log"

	confPath := "/etc/mailmotion/"
	confFilename := "mailmotion"
	logFilename := "/var/log/mailmotion/error.log"

	fd := initLogging(&logFilename)
	defer fd.Close()

	loadConfig(&confPath, &confFilename)
	startApp()
}