package main

import (
	"time"
	// "github.com/spf13/viper"
	// "github.com/op/go-logging"
)

func findPicture() []string {

	return []string{}
}

func startApp() {
	// Remove picture before starting
	pictureList := findPicture()
	_ = pictureList
	
	for {
		time.Sleep(time.Second)
	}
}

func main() {
	confPath := ""
	confFilename := ""
	logFilename := ""

	fd := initLogging(&logFilename)
	defer fd.Close()

	loadConfig(&confPath, &confFilename)
	startApp()
}