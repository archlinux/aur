import os
import sys
import subprocess
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QFileDialog, QLabel

class PackageCreator(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Display-Functions Package Creator')
        self.setGeometry(100, 100, 400, 200)

        layout = QVBoxLayout()

        self.label = QLabel('Select the folder containing your application files:', self)
        layout.addWidget(self.label)

        self.select_button = QPushButton('Select Folder', self)
        self.select_button.clicked.connect(self.select_folder)
        layout.addWidget(self.select_button)

        self.create_button = QPushButton('Create Package', self)
        self.create_button.clicked.connect(self.create_package)
        self.create_button.setEnabled(False)
        layout.addWidget(self.create_button)

        self.setLayout(layout)

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Select Folder')
        if folder:
            self.folder = folder
            self.create_button.setEnabled(True)

    def create_package(self):
        pkgname = 'display-functions-claudemods'
        pkgver = '1.0'
        pkgrel = '1'
        pkgdesc = 'function for displays on plasma 6'
        arch = 'any'
        url = 'https://github.com/claudemods/Display-Functions/releases/download/new/display-functions.tar.gz'
        license = 'GPL'
        depends = 'python python-pyqt6 qt6-base qt6-declarative'
        maintainer = 'claudemods'
        contributor = 'empty'

        pkgbuild_content = f"""
# Maintainer: {maintainer}
# Contributor: {contributor}
pkgname={pkgname}
pkgver={pkgver}
pkgrel={pkgrel}
epoch=
pkgdesc="{pkgdesc}"
arch=('{arch}')
url="{url}"
license=('{license}')
groups=()
depends=({depends})
makedepends=()
checkdepends=()
optdepends=()
provides=()
conflicts=()
replaces=()
backup=()
options=()
install=
changelog=first version
source=("$pkgname-$pkgver.tar.gz")
noextract=()
sha256sums=('SKIP')
validpgpkeys=()

package() {{
	install -Dm755 Display-Functions.py "$pkgdir/usr/bin/Display-Functions"
	install -Dm644 main.qml "$pkgdir/usr/share/Display-Functions/main.qml"
	install -Dm644 Display-Functions.desktop "$pkgdir/usr/share/applications/Display-Functions.desktop"
	install -Dm644 Display-Functions.png "$pkgdir/usr/share/icons/hicolor/256x256/apps/Display-Functions.png"
}}
"""

        pkgbuild_path = os.path.join(self.folder, 'PKGBUILD')
        with open(pkgbuild_path, 'w') as f:
            f.write(pkgbuild_content)

        tarball_path = os.path.join(self.folder, f'{pkgname}-{pkgver}.tar.gz')
        subprocess.run(['tar', '-czvf', tarball_path, '-C', self.folder, '.'])

        os.chdir(self.folder)
        subprocess.run(['makepkg', '--printsrcinfo'], stdout=open('.SRCINFO', 'w'))
        subprocess.run(['makepkg'])

        self.label.setText('Package created successfully!')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = PackageCreator()
    ex.show()
    sys.exit(app.exec())
