#!/bin/sh

mkdir /usr/share/gnome-background-properties 2> /dev/null
cp usr/share/gnome-background-properties/deepin-backgrounds.xml /usr/share/gnome-background-properties/
