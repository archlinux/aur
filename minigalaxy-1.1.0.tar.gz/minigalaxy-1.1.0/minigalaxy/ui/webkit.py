import gi

gi.require_version('WebKit2', '4.0')
from gi.repository import WebKit2  # noqa: E402,F401
