""" MiniGalaxy gui windows """
# Flake8 thinks these imports are unused
from minigalaxy.ui.window import Window             # noqa: F401
from minigalaxy.ui.preferences import Preferences   # noqa: F401
from minigalaxy.ui.gametile import GameTile         # noqa: F401
