""" MiniGalaxy packages """
