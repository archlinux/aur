#ifndef SRC_CORE_ROM_HPP_
#define SRC_CORE_ROM_HPP_

#include <chrono>
#include <vector>
#include <set>
#include <unordered_map>
#include "src/core/filesystem.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/json.hpp"
#include "src/core/async.hpp"

struct ROM {
	string name;
	fs::path path;
	EmulatorCore emulator;
	GfxPlugin parallelPlugin;
	GfxPlugin mupenPlugin;
	int64 lastPlayed;
	int64 playTime;
	std::set<string> tags;
	string notes;
	bool overclockCPU;
	bool overclockVI;
};

struct RomSource {
	fs::path folder;
	bool recursive;
	bool ignoreHidden;
	bool followSymlinks;
	ubyte maxDepth;
	std::set<string> autoTags;
};

namespace JsonSerializer {
	template<> void serialize<ROM>( JsonWriter &jw, const ROM &obj );
	template<> ROM parse<ROM>( const Json &json );

	template<> void serialize<RomSource>( JsonWriter &jw, const RomSource &obj );
	template<> RomSource parse<RomSource>( const Json &json );
}

namespace RomFinder {
	std::vector<ROM> scan(
		const std::vector<ROM> &currentRomList,
		const std::vector<RomSource> &sources,
		CancellationToken &cancellationToken
	);
}

#endif /* SRC_CORE_ROM_HPP_ */
