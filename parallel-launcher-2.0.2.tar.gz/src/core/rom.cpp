#include "src/core/rom.hpp"

#include <unordered_map>
#include "src/polyfill/file-search.hpp"

static constexpr char P_NAME[] = "name";
static constexpr char P_PATH[] = "file_path";
static constexpr char P_EMULATOR[] = "emulator_core";
static constexpr char P_PARALLEL_PLUGIN[] = "gfx_plugin";
static constexpr char P_MUPEN_PLUGIN[] = "gfx_plugin_mupen";
static constexpr char P_LAST_PLAYED[] = "last_played";
static constexpr char P_PLAY_TIME[] = "play_time";
static constexpr char P_TAGS[] = "tags";
static constexpr char P_NOTES[] = "notes";
static constexpr char P_OVERCLOCK_CPU[] = "overclock_cpu";
static constexpr char P_OVERCLOCK_VI[] = "overclock_vi";
static constexpr char P_FOLDER[] = "folder_path";
static constexpr char P_RECURSIVE[] = "recursive";
static constexpr char P_IGNORE_HIDDEN[] = "ignore_hidden";
static constexpr char P_FOLLOW_SYMLINKS[] = "follow_symlinks";
static constexpr char P_MAX_DEPTH[] = "max_depth";

template<> void JsonSerializer::serialize<ROM>( JsonWriter &jw, const ROM &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_NAME, obj.name );
	jw.writeProperty( P_PATH, obj.path.string() );
	jw.writeProperty( P_EMULATOR, obj.emulator );
	jw.writeProperty( P_PARALLEL_PLUGIN, obj.parallelPlugin );
	jw.writeProperty( P_MUPEN_PLUGIN, obj.mupenPlugin );
	jw.writeProperty( P_LAST_PLAYED, obj.lastPlayed );
	jw.writeProperty( P_PLAY_TIME, obj.playTime );
	jw.writePropertyName( P_TAGS );
	jw.writeArrayStart();
	for( const string &tag : obj.tags ) {
		jw.writeString( tag );
	}
	jw.writeArrayEnd();
	jw.writeProperty( P_NOTES, obj.notes );
	jw.writeProperty( P_OVERCLOCK_CPU, obj.overclockCPU );
	jw.writeProperty( P_OVERCLOCK_VI, obj.overclockVI );
	jw.writeObjectEnd();
}

template<> ROM JsonSerializer::parse<ROM>( const Json &json ) {
	std::set<string> tags;
	for( const Json &tag : json[P_TAGS].array() ) {
		tags.insert( tag.get<string>() );
	}

	return ROM{
		json[P_NAME].get<string>(),
		std::filesystem::path( json[P_PATH].get<string>() ),
		json[P_EMULATOR].getOrDefault<EmulatorCore>( EmulatorCore::ParallelN64 ),
		json[P_PARALLEL_PLUGIN].get<GfxPlugin>(),
		json[P_MUPEN_PLUGIN].getOrDefault<GfxPlugin>( GfxPlugin::UseDefault ),
		json[P_LAST_PLAYED].get<int64>(),
		json[P_PLAY_TIME].get<int64>(),
		std::move( tags ),
		json[P_NOTES].get<string>(),
		json[P_OVERCLOCK_CPU].getOrDefault<bool>( true ),
		json[P_OVERCLOCK_VI].getOrDefault<bool>( false )
	};
}

template<> void JsonSerializer::serialize<RomSource>( JsonWriter &jw, const RomSource &obj ) {
	jw.writeObjectStart();
	jw.writeProperty( P_FOLDER, obj.folder.string() );
	jw.writeProperty( P_RECURSIVE, obj.recursive );
	jw.writeProperty( P_IGNORE_HIDDEN, obj.ignoreHidden && obj.recursive );
	jw.writeProperty( P_FOLLOW_SYMLINKS, obj.followSymlinks && obj.recursive );
	jw.writeProperty( P_MAX_DEPTH, obj.recursive ? obj.maxDepth : 5 );
	jw.writePropertyName( P_TAGS );
	jw.writeArrayStart();
	for( const string &tag : obj.autoTags ) {
		jw.writeString( tag );
	}
	jw.writeArrayEnd();
	jw.writeObjectEnd();
}

template<> RomSource JsonSerializer::parse<RomSource>( const Json &json ) {
	std::set<string> tags;
	for( const Json &tag : json[P_TAGS].array() ) {
		tags.insert( tag.get<string>() );
	}

	return RomSource{
		std::filesystem::path( json[P_FOLDER].get<string>() ),
		json[P_RECURSIVE].get<bool>(),
		json[P_IGNORE_HIDDEN].get<bool>(),
		json[P_FOLLOW_SYMLINKS].get<bool>(),
		json[P_MAX_DEPTH].get<ubyte>(),
		std::move( tags )
	};
}

std::vector<ROM> RomFinder::scan(
	const std::vector<ROM> &currentRomList,
	const std::vector<RomSource> &sources,
	CancellationToken &cancellationToken
) {
	HashMap<fs::path,ROM> previousRoms;
	previousRoms.reserve( currentRomList.size() );
	for( const ROM &rom : currentRomList ) {
		previousRoms[rom.path] = rom;
	}

	HashMap<fs::path,std::set<string>> foundRoms;
	for( const RomSource &source : sources ) {
		if( cancellationToken.isCancelled() ) {
			return std::vector<ROM>();
		}

		const std::vector<fs::path> paths = FileSearch::find(
			source.folder,
#ifdef _WIN32
			"*.?64",
#else
			"*.[nvz]64",
#endif
			source.recursive ? source.maxDepth : 1,
			source.followSymlinks,
			source.ignoreHidden,
			cancellationToken
		);

		for( fs::path romPath : paths ) {
#ifdef _WIN32
			const char romType = romPath.extension().string().c_str()[1];
			if(
				romType != 'n' && romType != 'N' &&
				romType != 'v' && romType != 'V' &&
				romType != 'z' && romType != 'Z'
			) continue;
#endif

			if( fs::is_symlink( romPath ) ) {
				if( !source.followSymlinks ) continue;
				for( int i = 0; i < 9 && fs::is_symlink( romPath ); i++ ) {
					romPath = fs::read_symlink( romPath );
				}
			}

			if( fs::is_regular_file( romPath ) ) {
				foundRoms[romPath].insert( source.autoTags.begin(), source.autoTags.end() );
			}
		}
	}

	std::vector<ROM> roms;
	roms.reserve( foundRoms.size() );
	for( const auto &r : foundRoms ) {
		auto knownRom = previousRoms.find( r.first );
		if( knownRom != previousRoms.end() ) {
			roms.push_back( knownRom->second );
		} else {
			roms.push_back( ROM{
				/* name */ r.first.stem().string(),
				/* folder */ r.first,
				/* emulator */ EmulatorCore::UseDefault,
				/* parallelPlugin */ GfxPlugin::UseDefault,
				/* mupenPlugin */ GfxPlugin::UseDefault,
				/* lastPlayed */ 0,
				/* playTime */ 0,
				/* tags */ std::move( r.second ),
				/* notes */ "",
				/* overclockCPU */ true,
				/* overclockVI */ false
			});
		}
	}

	return roms;
}

