#ifndef SRC_RHDC_WEB_REQUIRE_LOGIN_HPP_
#define SRC_RHDC_WEB_REQUIRE_LOGIN_HPP_

#include "src/rhdc/core/credentials.hpp"

#define REQUIRE_LOGIN( retryFunc ) \
	if( !RhdcApi::isAuthenticated() ) { \
		const RhdcCredentials credentials = RhdcCredentials::load(); \
		if( credentials.username.empty() || credentials.password.empty() ) { \
			onFailure( ApiErrorType::NotAuthorized ); \
			return; \
		} \
		RhdcApi::loginAsync( credentials, retryFunc, onFailure ); \
		return; \
	}



#endif /* SRC_RHDC_WEB_REQUIRE_LOGIN_HPP_ */
