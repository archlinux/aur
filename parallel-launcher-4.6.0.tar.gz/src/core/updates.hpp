#ifndef SRC_CORE_CORES_HPP_
#define SRC_CORE_CORES_HPP_

#include "src/core/settings.hpp"
#include "src/core/version.hpp"
#include "src/core/json.hpp"
#include <functional>

struct CoreVersion {
	string commit;
	bool lock;
};

#ifndef __linux__
struct RetroArchVersion {
	Version version;
	bool lock;
};
#else
typedef CoreVersion RetroArchVersion;
#endif

struct CommitInfo {
	string hash;
	string message;
	string date;
};

struct CoreBuild {
	CommitInfo commit;
	string downloadLink;
};

struct InstalledVersionsInfo {
	RetroArchVersion retroArchVersion;
	CoreVersion parallelVersion;
	CoreVersion mupenVersion;
	int64 lastUpdateCheck;

	static const InstalledVersionsInfo Default;
};

namespace JsonSerializer {
	template<> void serialize<CoreVersion>( JsonWriter &jw, const CoreVersion &obj );
	template<> CoreVersion parse<CoreVersion>( const Json &json );

#ifndef __linux__
	template<> void serialize<RetroArchVersion>( JsonWriter &jw, const RetroArchVersion &obj );
	template<> RetroArchVersion parse<RetroArchVersion>( const Json &json );
#endif

	template<> void serialize<InstalledVersionsInfo>( JsonWriter &jw, const InstalledVersionsInfo &obj );
	template<> InstalledVersionsInfo parse<InstalledVersionsInfo>( const Json &json );
}

namespace CoreBuilds {

	void getLastKnownGood(
		EmulatorCore core,
		const string &branch,
		const string &laterThan,
		const std::function<void(const CoreBuild&)> &onSuccess,
		const std::function<void(void)> &onFailure
	);

}

namespace RetroUpdater {

	extern void checkForUpdates(
		bool waitForCoreUpdates,
		bool forceRuntimeUpdate,
		bool forceUpdate
	);

}

#endif /* SRC_CORE_CORES_HPP_ */
