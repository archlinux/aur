#!/usr/bin/env python3

import os
import json
import argparse
import subprocess
import curses
import signal
from pathlib import Path

CONFIG_PATH = Path.home() / ".dotctl.json"

# ---------------- CONFIG ---------------- #

def load_config():
    if not CONFIG_PATH.exists():
        return {"shells": []}
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)

# ---------------- PROCESS ---------------- #

def pid_alive(pid):
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def update_crash_state(shell):
    if shell.get("pid") and not pid_alive(shell["pid"]):
        shell["pid"] = None

def run_hook(hook, cwd):
    if hook:
        subprocess.Popen(
            hook,
            cwd=cwd,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

def kill_shell(shell):
    pid = shell.get("pid")
    if pid and pid_alive(pid):
        run_hook(shell.get("kill_hook"), shell["folder"])
        os.killpg(pid, signal.SIGTERM)
    shell["pid"] = None

def kill_all_except(cfg, keep_index):
    for i, shell in enumerate(cfg["shells"]):
        if i != keep_index:
            kill_shell(shell)

def run_shell(cfg, index):
    shell = cfg["shells"][index]

    update_crash_state(shell)

    # restart behavior
    if shell.get("pid"):
        kill_shell(shell)

    # auto-kill others
    kill_all_except(cfg, index)

    run_hook(shell.get("pre_hook"), shell["folder"])

    env = os.environ.copy()
    env.setdefault("XDG_SESSION_TYPE", "wayland")

    proc = subprocess.Popen(
        shell["command"],
        cwd=shell["folder"],
        shell=True,
        start_new_session=True,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    shell["pid"] = proc.pid

    run_hook(shell.get("post_hook"), shell["folder"])

# ---------------- TUI ---------------- #

def draw_menu(stdscr, cfg, selected):
    stdscr.clear()
    h, w = stdscr.getmaxyx()

    header = " dotctl | ↑↓ move | Enter start/restart | k kill | q quit "
    stdscr.addstr(0, 0, header[:w], curses.A_REVERSE)

    for i, shell in enumerate(cfg["shells"]):
        update_crash_state(shell)

        name = shell.get("name", "unnamed")
        status = "RUNNING" if shell.get("pid") else "STOPPED"

        left = f" [{i}] {name} "
        right = f" {status} "

        filler = max(1, w - len(left) - len(right))
        line = (left + " " * filler + right)[: w - 1]

        y = 2 + i
        if y >= h:
            break

        attr = curses.A_REVERSE if i == selected else 0
        stdscr.addstr(y, 0, line, attr)

    stdscr.refresh()

def tui_main(stdscr):
    curses.curs_set(0)
    stdscr.keypad(True)

    cfg = load_config()
    selected = 0

    while True:
        draw_menu(stdscr, cfg, selected)

        try:
            key = stdscr.getch()
        except KeyboardInterrupt:
            break

        if key in (ord("q"), 27):
            break
        elif key == curses.KEY_UP:
            selected = max(0, selected - 1)
        elif key == curses.KEY_DOWN:
            selected = min(len(cfg["shells"]) - 1, selected + 1)
        elif key in (10, 13):
            run_shell(cfg, selected)
            save_config(cfg)
        elif key == ord("k"):
            kill_shell(cfg["shells"][selected])
            save_config(cfg)

# ---------------- CLI ---------------- #

def main():
    p = argparse.ArgumentParser(prog="dotctl")

    p.add_argument("--tui", action="store_true")
    p.add_argument("-ia", "--idadd", action="store_true")
    p.add_argument("-rm", "--remove", type=int)
    p.add_argument("-i", "--id", type=int)

    p.add_argument("-s", "--shell")
    p.add_argument("-f", "--folder")
    p.add_argument("--command")
    p.add_argument("--pre-hook")
    p.add_argument("--post-hook")
    p.add_argument("--kill-hook")

    args = p.parse_args()
    cfg = load_config()

    if args.idadd:
        cfg["shells"].append({
            "name": args.shell or "unnamed",
            "folder": args.folder or "",
            "command": args.command or "",
            "pid": None,
            "pre_hook": args.pre_hook or "",
            "post_hook": args.post_hook or "",
            "kill_hook": args.kill_hook or "",
        })
        save_config(cfg)
        print(f"Shell {len(cfg['shells']) - 1} added.")
        return

    if args.remove is not None:
        if 0 <= args.remove < len(cfg["shells"]):
            kill_shell(cfg["shells"][args.remove])
            cfg["shells"].pop(args.remove)
            save_config(cfg)
            print("Shell removed.")
        return

    if args.id is not None:
        sh = cfg["shells"][args.id]
        if args.shell: sh["name"] = args.shell
        if args.folder: sh["folder"] = args.folder
        if args.command: sh["command"] = args.command
        if args.pre_hook: sh["pre_hook"] = args.pre_hook
        if args.post_hook: sh["post_hook"] = args.post_hook
        if args.kill_hook: sh["kill_hook"] = args.kill_hook
        save_config(cfg)
        print("Shell updated.")
        return

    if args.tui:
        try:
            curses.wrapper(tui_main)
        except KeyboardInterrupt:
            pass
        return

    p.print_help()

if __name__ == "__main__":
    main()
