# dotctl

**dotctl** is a terminal-based tool to manage multiple shell sessions with optional hooks, TUI, and CLI support.

---

## Features

* Manage multiple shells (start/stop/restart)
* TUI interface with keyboard navigation
* Hooks support (pre/post/kill)
* Auto-kill other shells when starting one
* Persistent configuration at `~/.dotctl.json`
* CLI for adding, updating, or removing shells

---

## Installation

Install from GitHub and compile with Nuitka:

```bash
git clone http://github.com/xZepyx/dotctl.git
cd dotctl/src
sudo pacman -S python-pipx patchelf
pipx install nuitka
~/.local/bin/nuitka --onefile --standalone --assume-yes-for-downloads dotctl.py
mv dotctl.bin dotctl
sudo mv dotctl /usr/bin/dotctl
```

---

## Configuration File

Located at `~/.dotctl.json`:

```json
{
  "shells": [
    {
      "name": "MyShell",
      "folder": "/home/user/projects",
      "command": "bash",
      "pid": null,
      "pre_hook": "",
      "post_hook": "",
      "kill_hook": ""
    }
  ]
}
```

---

## Usage

### TUI Mode

```bash
dotctl --tui
```

Controls:

* `↑` / `↓` — Move selection
* `Enter` — Start/restart selected shell
* `k` — Kill selected shell
* `q` or `Esc` — Quit

### CLI Mode

#### Add a shell

```bash
dotctl -ia -s MyShell -f /home/user/projects -c "bash"
```

Optional hooks:

```bash
--pre-hook "echo Starting"
--post-hook "echo Started"
--kill-hook "echo Killing"
```

#### Update a shell

```bash
dotctl -i 0 -s UpdatedShell -c "zsh"
```

#### Remove a shell

```bash
dotctl -rm 0
```

---

## Notes

* Only one shell runs at a time; starting a new shell auto-kills others.
* Hooks run silently.
* TUI shows shell status (`RUNNING`/`STOPPED`).

---

## Requirements

* Python 3.8+
* Linux/macOS (uses `os.killpg`)

---

## License

MIT License
