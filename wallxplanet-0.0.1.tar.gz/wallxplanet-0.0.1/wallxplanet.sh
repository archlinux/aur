#!/bin/sh

xplanet -conf /etc/wallxplanet/wallxplanet.conf -output /tmp/xplanet_earth.png -body earth -wait 120 -latitude 40 -longitude -4 -geometry 800x800