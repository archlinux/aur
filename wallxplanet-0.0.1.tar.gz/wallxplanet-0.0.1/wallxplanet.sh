#!/bin/sh

xplanet -conf xplanet.conf -output xplanet_earth.png -body earth -wait 120 -latitude 40 -longitude -4 -geometry 800x800 &