# CLAUDE.md

Guidance for AI assistants working in this repository.

## What whispy is

whispy is **push-to-talk dictation for Hyprland (Wayland)**. Hold/toggle a key,
speak, release — the transcribed text is injected into the focused field. Speech
never leaves the machine: a resident daemon keeps a speech model in RAM — NVIDIA
Parakeet via [transcribe.cpp](https://github.com/handy-computer/transcribe.cpp)
(`stt.engine = "parakeet"`, the default for new configs) or
[whisper.cpp](https://github.com/ggerganov/whisper.cpp) (`"whisper"`) — a thin
client is fired from Hyprland binds, and a [Quickshell](https://quickshell.org)
pill overlay shows live state.

Target platform is Linux + Wayland (Hyprland), developed on AMD RDNA4 with the
Vulkan backend (no ROCm). The STT server's compute backend is selectable via
`stt.backend` (`auto` / `vulkan` / `cpu`): `auto` builds Vulkan when its loader is
present, else a CPU build (OpenBLAS-accelerated when `libopenblas` is installed),
so GPU-less machines work too. It is **not** cross-platform (Linux/Wayland only).

## Architecture

```
Hyprland keybind ──► whispy-client ──(unix socket)──► whispy-daemon ──► STT server: whispy-stt | whisper-server
                                                          │
                                                          ├─► state.json ──► Quickshell pill
                                                          └─► inject ──► focused app
```

- **whispy-daemon** — resident systemd user service. Supervises the STT server
  child (model stays in RAM), captures audio (PipeWire), filters hallucinations,
  runs the text pipeline (corrections → snippets → optional LLM workflow), injects
  text, and publishes state.
- **whispy-client** — tiny binary called from Hyprland binds. Sends one command and
  exits fast (no async runtime, no config parsing).
- **STT server** — the child the daemon supervises, per `stt.engine`. Both take the
  same CLI (`-m MODEL -l LANG --host H --port P`) and serve the same
  `POST /inference` (multipart WAV → `verbose_json` subset), so `stt_server.rs` and
  `stt.rs` don't care which runs (what does differ lives in `engine.rs`):
  - **whispy-stt** (`crates/stt/`, `"parakeet"`) — our own server on the
    `transcribe-cpp` crate (CPU by default, `--features vulkan` for the GPU). A
    separate process on purpose: it keeps C++/Vulkan out of the daemon binary (it
    must start on GPU-less machines) and a driver crash out of the daemon.
    Shipped by the AUR package; `setup stt` builds it with cargo otherwise.
  - **whisper-server** (`"whisper"`) — whisper.cpp built with the backend
    `stt.backend` selects (Vulkan, or CPU/OpenBLAS). Built and managed per-machine
    by `whispy-daemon setup whisper`; **not** shipped in releases.
- **pill UI** — Quickshell layer overlay that reads `state.json` (`ui/quickshell/`).
- **Omarchy bar widget** — `ui/omarchy/` is an Omarchy 4 bar-widget plugin
  (`whispy.dictation`: `manifest.json` + `whispy.qml`, also reading `state.json`),
  embedded in the daemon via `include_str!`. `setup` installs it to
  `~/.config/omarchy/plugins/whispy.dictation/` and puts it on the bar only on first
  install (`omarchy-bar put`). No Python or other new runtime dependencies: UI stays
  QML on the Quickshell that Omarchy already ships.

### Recording flow

`start` → open PipeWire capture → on `stop`, transcription runs off-thread (client
returns immediately, UI follows `state.json`) → hallucination filter →
`pipeline::process` (vocabulary fuzzy-fix on Parakeet, corrections, snippets, AI workflow) → inject → flash
`success`/`error` and revert to `idle`.

## Workspace layout

Cargo workspace (`resolver = "3"`, `edition = "2024"`, MSRV `rust-version = 1.88`).

| Crate | Path | Role |
|-------|------|------|
| `whispy-common` | `crates/common/` | Shared IPC protocol + state types (`Cmd`, `Resp`, `State`, `StateSnapshot`). Serde only, no logic. |
| `whispy-daemon` | `crates/daemon/` | The resident service and the `setup` bootstrap. All the real logic. |
| `whispy-stt` | `crates/stt/` | Parakeet STT server on transcribe.cpp, whisper-server compatible (`multipart.rs`, `reply.rs` are the pure, tested wire format). Builds C++ via cmake; `.cargo/config.toml` sets `TRANSCRIBE_CMAKE_ARGS` (no system BLAS). |
| `whispy-client` | `crates/client/` | Thin sync client invoked from Hyprland binds. |

### Daemon modules (`crates/daemon/src/`)

| Module | Responsibility |
|--------|----------------|
| `main.rs` | CLI args (clap), config load, JSON logging init, signal handling, wires everything, runs the socket server. Also routes the `setup` subcommand. |
| `app.rs` | `App` — maps socket commands to the capture→transcribe→filter→inject flow; owns the active `Session` (capture + its `AppContext`, handed to the transcribe thread) and an inject lock so overlapping clips paste one at a time. |
| `server.rs` | Unix-socket server: line-based JSON (`Cmd` in, `Resp` out), polls a shutdown flag for clean SIGTERM exit. |
| `audio.rs` | PipeWire capture via `pw-record` (raw s16le mono), RMS metering, gain, clip limits, trailing-silence auto-stop, peak normalization. |
| `engine.rs` | `Engine` (`stt.engine`: `Whisper` \| `Parakeet`, serde-parsed): owns what differs per engine — server name/binary/extra args, model file + download source (URL, SHA-256), `setup` step, and the vocabulary strategy (`Prompt` for whisper, `Correct` via `vocab.rs` for Parakeet). Callers ask the engine instead of branching on it. |
| `stt_server.rs` | Spawns and supervises the STT server child (`whispy-stt` or `whisper-server`, per `Engine`); waits for its port; a monitor thread in `main` polls `is_alive` and `restart`s it if it dies; kills it on shutdown. |
| `vocab.rs` | Fuzzy custom-vocabulary correction (Levenshtein + Soundex over 1–3 word windows, ported from Handy) for Parakeet, which can't take whisper's prompt bias. |
| `stt.rs` | HTTP client to the STT server's `/inference` (multipart WAV, `verbose_json`); parses transcript + confidence signals. |
| `filter.rs` | Hallucination filter: confidence thresholds → punctuation-only rejection → exact + fuzzy (`strsim`) blacklist match. |
| `pipeline.rs` | Post-transcription text pipeline: corrections → snippets → AI workflow selection + LLM transform. Never fails (falls back to raw text). |
| `llm.rs` | Minimal OpenAI-compatible chat client (local ollama by default) for AI workflows. |
| `proc.rs` | Deadline-bounded subprocess helpers (`output`/`status`/`with_stdin`) used for every runtime tool call (clipboard, typing, `ydotool`, window-class probes) so a wedged tool can't hang a thread. |
| `inject.rs` | Text injection: `paste` mode (`wl-copy` + `ydotool` Ctrl+V, clipboard save/restore) or `type` mode (`wtype`). |
| `state.rs` | `StatePublisher` writes `state.json` atomically (tmp + rename); `Status` keeps in-memory + on-disk snapshot in sync and flashes transient states. |
| `config.rs` | TOML config; built-in defaults embedded via `include_str!`; `Config::validate` rejects bad config at startup. |
| `setup.rs` | `whispy-daemon setup` — idempotent one-shot bootstrap (install the STT engine: `whispy-stt` via cargo or whisper.cpp build; fetch + verify its model; ydotool perms, seed config, install systemd unit, opt-in Quickshell), then prints keybinds for the detected config (`HyprConfig`: Omarchy 4 Lua / Omarchy 3 / Hyprland Lua / hyprlang). |
| `stats.rs` | `whispy-daemon stats` — read-only summary of `transcripts.jsonl` (accepted vs dropped by reason) for filter tuning. |
| `settings/` | `whispy-daemon settings` — ratatui settings TUI (microphone + level meter + test dictation, language, typing, auto-stop, history). `form.rs` is the pure, tested screen state; `store.rs` edits `config.toml` with `toml_edit` so comments survive; `mic.rs` reuses `audio::Recorder` so the meter/test hear what dictation hears. Terminal palette colors only, so it follows the Omarchy theme. |

## IPC protocol

The client talks to the daemon over a Unix socket at
`$XDG_RUNTIME_DIR/whispy/whispy.sock` using a **line-based JSON** protocol: one
`Cmd` per line in, one `Resp` per line out. Types live in `crates/common/src/lib.rs`.

- Commands (`#[serde(tag = "cmd", rename_all = "lowercase")]`): `start` (optional
  `workflow`), `stop`, `cancel`, `status`, `ping`. `toggle` is client-side only
  (it queries `status`, then sends `start` or `stop`).
- `StateSnapshot` (also written to `state.json` for the UI) keeps `error_kind` /
  `error_message` always present (null when absent) so the UI JSON schema is stable.

**When changing the protocol, update `whispy-common` first** — both binaries depend
on it, and the QML pill reads the `state.json` shape.

## Configuration

- Authoritative defaults: `config/default.toml`, embedded in the binary via
  `include_str!`. The hallucination blacklist is `config/hallucinations.toml`.
- Runtime override: `$XDG_CONFIG_HOME/whispy/config.toml` (or `--config FILE`).
- Tilde paths (`~/...`) in config are expanded by the daemon.
- Logs: JSON lines to `$XDG_STATE_HOME/whispy/daemon.log`; level via `RUST_LOG`
  (default `info`). whisper-server output goes to `whisper-server.log` in the state dir.
  Both logs and `transcripts.jsonl` are size-capped via `config::rotate_if_larger`
  (one `.1` generation); `stats` reads both generations.

If you add a config field, update both the struct in `config.rs` and
`config/default.toml` (with an explanatory comment), and keep `#[serde(default)]`
on optional sections so existing user configs keep parsing.

## Development workflow

```sh
cargo build --workspace --locked          # build both binaries
cargo test --workspace --locked           # run tests
cargo fmt --all                           # format (CI checks --check)
cargo clippy --workspace --all-targets -- -D warnings   # CI treats warnings as errors

cargo run -p whispy-daemon                # run the daemon (needs whisper-server + model)
cargo run -p whispy-client -- status      # talk to a running daemon
```

CI (`.github/workflows/ci.yml`) runs, in order, on every push to `main` and every PR:
`cargo fmt --all --check`, `cargo clippy --workspace --all-targets -- -D warnings`,
`cargo build --workspace --locked`, `cargo test --workspace --locked`. A separate `qml`
job runs the bar module's tests:
`QT_QPA_PLATFORM=offscreen qmltestrunner -import ui/omarchy/tests/stubs -input ui/omarchy/tests/tst_whispy.qml`
(Ubuntu: `qt6-declarative-dev-tools qml6-module-qttest qml6-module-qtquick`). **Match this
locally before pushing.** `--locked` means `Cargo.lock` must be committed and current.

Releases (`.github/workflows/release.yml`) fire on `v*` tags: build, package the two
binaries (not whisper-server/model), publish a GitHub release, and push to the AUR
(`packaging/aur/PKGBUILD`).

## Conventions

- **Edition 2024**, MSRV 1.88 (let-chains, `slice::as_chunks`) — don't use features newer than that.
- Every module opens with a `//!` doc comment explaining its role; public items get
  `///` docs. Match this density.
- The daemon is **threaded, not async** — plain `std::thread`, `Mutex`, `Arc`,
  `AtomicBool`. Don't introduce tokio/async-std.
- HTTP uses `ureq` (sync). JSON via `serde`/`serde_json`. CLI via `clap` derive. Config
  via `toml`. Logging via `tracing` + `tracing-subscriber` (JSON). Keep the dependency
  set lean; new deps go in `[workspace.dependencies]` and are referenced with
  `{ workspace = true }`.
- Tests are inline `#[cfg(test)] mod tests` in the same file. Favor pure, testable
  helpers (e.g. `pick_workflow`, `pick_wayland_socket`) factored out of side-effecting code.
- External tools are invoked as subprocesses: `pw-record`, `wl-copy`/`wl-paste`,
  `ydotool`, `wtype`, `whisper-server`. Short-lived runtime calls go through `proc` with a
  timeout, never a bare `.output()`/`.status()`. Best-effort steps log via `tracing::warn!` and
  continue; only the critical step is a hard error.
- **Lints** are configured once in `[workspace.lints]` (root `Cargo.toml`; each crate
  opts in with `[lints] workspace = true`) and tuned in `clippy.toml`. Clippy
  `pedantic` is on plus anti-slop restriction lints (`unwrap_used`, `dbg_macro`,
  `todo`, `map_err_ignore`, `undocumented_unsafe_blocks`, `allow_attributes`, …) and
  rustc's `missing_docs`. CI denies every warning. Fix the code; when a lint is
  genuinely wrong for one site, silence just that site with
  `#[expect(clippy::name, reason = "...")]` — never a bare `#[allow]`, and don't
  loosen the workspace table to dodge a single hit. `unsafe` blocks need a
  `// SAFETY:` comment. Tests may `unwrap`/`expect`/`panic` freely.
- Commit messages follow Conventional Commits (`feat:`, `fix:`, `docs:`, `refactor:`,
  `style:`, `ci:`, optional scope like `fix(ci):`).

## Where things live

- `ui/quickshell/` — QML pill overlay (`Pill.qml`, `PillPanel.qml`, `Tokens.qml`); reads `state.json`.
- `ui/omarchy/` — Omarchy bar widget plugin (`manifest.json`, `whispy.qml`) plus `tests/` (qmltestrunner with
  stub Quickshell modules and a mock `bar`).
- `systemd/whispy-daemon.service` — user unit (installed by `setup`).
- `packaging/aur/` — AUR `PKGBUILD`s (`whispy` release + `whispy-git`).
- `scripts/` — `benchmark.sh` (STT latency per model), `setup-ydotool.sh`.
- `docs/` — `hyprland-setup.md`, `stt-benchmark.md`, `spike-fork-vs-build.md`.
- `install.sh` — distro-aware installer (AUR on Arch, build-from-source elsewhere).
- `.agents/skills/` (symlinked as `.claude/`) — bundled agent skills.

## Gotchas

- A systemd user service started before the compositor may lack `WAYLAND_DISPLAY`;
  `main.rs` discovers the lowest-numbered `wayland-N` socket so injection tools work.
- `state.json` is written atomically (tmp + rename) — never write it in place; the UI
  polls it and must never see a half-written file. Several threads write state, and
  all publishes share one `.tmp` path, so `Status` publishes while holding its lock.
- transcribe.cpp's CMake probes for a system BLAS and can pick a reference `libblas`
  without the `cblas_*` symbols (Arch), failing the final link of `whispy-stt`. The repo's
  `.cargo/config.toml` passes `-DTRANSCRIBE_USE_SYSTEM_BLAS=OFF`; `setup stt` passes the
  same flag itself because `cargo install --git` ignores repo config.
- whisper-server / whispy-stt is launched/supervised by the daemon and respawned in-process by a monitor
  thread (`main.rs`) if it dies. Don't shell out to start it elsewhere. STT requests are
  bounded by `stt.timeout_secs` so a hung server surfaces an error instead of stalling.
- Hyprland configs are now Lua (`hyprland.lua`, `hl.bind`) as well as hyprlang
  (`hyprland.conf`); Omarchy 4 adds an `o.bind` helper and loads user binds from
  `~/.config/hypr/bindings.lua`. Omarchy owns SUPER+SPACE (and its ALT/SHIFT/CTRL
  variants), so whispy's default keys are Omarchy's dictation keys: F9 push-to-talk,
  SUPER+CTRL+X toggle, SUPER+CTRL+SHIFT+X cancel. Keep docs, `README.md`, and
  `setup::wayland_keybinds` in sync when changing them.
- The mic records quiet (~20–25 dB low); audio is peak-normalized before transcription
  and the first ~50 ms are dropped to skip the codec stream-start transient. Keep this in
  mind when touching `audio.rs`.
