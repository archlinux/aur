#pragma once
#include <stdbool.h>

bool cmd_help_check(char *input);
bool cmd_help_exec(char *input);
