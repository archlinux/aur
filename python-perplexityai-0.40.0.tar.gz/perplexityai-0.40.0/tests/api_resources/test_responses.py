# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from perplexity import Perplexity, AsyncPerplexity
from tests.utils import assert_matches_type
from perplexity.types import ResponseCreateResponse, ResponseRetrieveResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestResponses:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_overload_1(self, client: Perplexity) -> None:
        response = client.responses.create(
            input="string",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params_overload_1(self, client: Perplexity) -> None:
        response = client.responses.create(
            input="string",
            background=True,
            instructions="instructions",
            language_preference="language_preference",
            max_output_tokens=1,
            max_steps=1,
            model="model",
            models=["string"],
            preset="preset",
            previous_response_id="previous_response_id",
            reasoning={"effort": "minimal"},
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "x",
                    "schema": {"foo": "bar"},
                    "description": "description",
                    "strict": True,
                },
            },
            store=True,
            stream=False,
            tools=[
                {
                    "type": "web_search",
                    "filters": {
                        "last_updated_after_filter": "last_updated_after_filter",
                        "last_updated_before_filter": "last_updated_before_filter",
                        "search_after_date_filter": "search_after_date_filter",
                        "search_before_date_filter": "search_before_date_filter",
                        "search_domain_filter": ["string"],
                        "search_recency_filter": "hour",
                    },
                    "max_tokens": 0,
                    "max_tokens_per_page": 0,
                    "search_context_size": "low",
                    "user_location": {
                        "city": "city",
                        "country": "country",
                        "latitude": 0,
                        "longitude": 0,
                        "region": "region",
                    },
                }
            ],
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_overload_1(self, client: Perplexity) -> None:
        http_response = client.responses.with_raw_response.create(
            input="string",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = http_response.parse()
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_overload_1(self, client: Perplexity) -> None:
        with client.responses.with_streaming_response.create(
            input="string",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = http_response.parse()
            assert_matches_type(ResponseCreateResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_overload_2(self, client: Perplexity) -> None:
        response_stream = client.responses.create(
            input="string",
            stream=True,
        )
        response_stream.response.close()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params_overload_2(self, client: Perplexity) -> None:
        response_stream = client.responses.create(
            input="string",
            stream=True,
            background=True,
            instructions="instructions",
            language_preference="language_preference",
            max_output_tokens=1,
            max_steps=1,
            model="model",
            models=["string"],
            preset="preset",
            previous_response_id="previous_response_id",
            reasoning={"effort": "minimal"},
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "x",
                    "schema": {"foo": "bar"},
                    "description": "description",
                    "strict": True,
                },
            },
            store=True,
            tools=[
                {
                    "type": "web_search",
                    "filters": {
                        "last_updated_after_filter": "last_updated_after_filter",
                        "last_updated_before_filter": "last_updated_before_filter",
                        "search_after_date_filter": "search_after_date_filter",
                        "search_before_date_filter": "search_before_date_filter",
                        "search_domain_filter": ["string"],
                        "search_recency_filter": "hour",
                    },
                    "max_tokens": 0,
                    "max_tokens_per_page": 0,
                    "search_context_size": "low",
                    "user_location": {
                        "city": "city",
                        "country": "country",
                        "latitude": 0,
                        "longitude": 0,
                        "region": "region",
                    },
                }
            ],
        )
        response_stream.response.close()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_overload_2(self, client: Perplexity) -> None:
        response = client.responses.with_raw_response.create(
            input="string",
            stream=True,
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = response.parse()
        stream.close()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_overload_2(self, client: Perplexity) -> None:
        with client.responses.with_streaming_response.create(
            input="string",
            stream=True,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = response.parse()
            stream.close()

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Perplexity) -> None:
        response = client.responses.retrieve(
            "response_id",
        )
        assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Perplexity) -> None:
        http_response = client.responses.with_raw_response.retrieve(
            "response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = http_response.parse()
        assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Perplexity) -> None:
        with client.responses.with_streaming_response.retrieve(
            "response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = http_response.parse()
            assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Perplexity) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            client.responses.with_raw_response.retrieve(
                "",
            )


class TestAsyncResponses:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_overload_1(self, async_client: AsyncPerplexity) -> None:
        response = await async_client.responses.create(
            input="string",
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params_overload_1(self, async_client: AsyncPerplexity) -> None:
        response = await async_client.responses.create(
            input="string",
            background=True,
            instructions="instructions",
            language_preference="language_preference",
            max_output_tokens=1,
            max_steps=1,
            model="model",
            models=["string"],
            preset="preset",
            previous_response_id="previous_response_id",
            reasoning={"effort": "minimal"},
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "x",
                    "schema": {"foo": "bar"},
                    "description": "description",
                    "strict": True,
                },
            },
            store=True,
            stream=False,
            tools=[
                {
                    "type": "web_search",
                    "filters": {
                        "last_updated_after_filter": "last_updated_after_filter",
                        "last_updated_before_filter": "last_updated_before_filter",
                        "search_after_date_filter": "search_after_date_filter",
                        "search_before_date_filter": "search_before_date_filter",
                        "search_domain_filter": ["string"],
                        "search_recency_filter": "hour",
                    },
                    "max_tokens": 0,
                    "max_tokens_per_page": 0,
                    "search_context_size": "low",
                    "user_location": {
                        "city": "city",
                        "country": "country",
                        "latitude": 0,
                        "longitude": 0,
                        "region": "region",
                    },
                }
            ],
        )
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_overload_1(self, async_client: AsyncPerplexity) -> None:
        http_response = await async_client.responses.with_raw_response.create(
            input="string",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = await http_response.parse()
        assert_matches_type(ResponseCreateResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_overload_1(self, async_client: AsyncPerplexity) -> None:
        async with async_client.responses.with_streaming_response.create(
            input="string",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = await http_response.parse()
            assert_matches_type(ResponseCreateResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_overload_2(self, async_client: AsyncPerplexity) -> None:
        response_stream = await async_client.responses.create(
            input="string",
            stream=True,
        )
        await response_stream.response.aclose()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params_overload_2(self, async_client: AsyncPerplexity) -> None:
        response_stream = await async_client.responses.create(
            input="string",
            stream=True,
            background=True,
            instructions="instructions",
            language_preference="language_preference",
            max_output_tokens=1,
            max_steps=1,
            model="model",
            models=["string"],
            preset="preset",
            previous_response_id="previous_response_id",
            reasoning={"effort": "minimal"},
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "x",
                    "schema": {"foo": "bar"},
                    "description": "description",
                    "strict": True,
                },
            },
            store=True,
            tools=[
                {
                    "type": "web_search",
                    "filters": {
                        "last_updated_after_filter": "last_updated_after_filter",
                        "last_updated_before_filter": "last_updated_before_filter",
                        "search_after_date_filter": "search_after_date_filter",
                        "search_before_date_filter": "search_before_date_filter",
                        "search_domain_filter": ["string"],
                        "search_recency_filter": "hour",
                    },
                    "max_tokens": 0,
                    "max_tokens_per_page": 0,
                    "search_context_size": "low",
                    "user_location": {
                        "city": "city",
                        "country": "country",
                        "latitude": 0,
                        "longitude": 0,
                        "region": "region",
                    },
                }
            ],
        )
        await response_stream.response.aclose()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_overload_2(self, async_client: AsyncPerplexity) -> None:
        response = await async_client.responses.with_raw_response.create(
            input="string",
            stream=True,
        )

        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        stream = await response.parse()
        await stream.close()

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_overload_2(self, async_client: AsyncPerplexity) -> None:
        async with async_client.responses.with_streaming_response.create(
            input="string",
            stream=True,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            stream = await response.parse()
            await stream.close()

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncPerplexity) -> None:
        response = await async_client.responses.retrieve(
            "response_id",
        )
        assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncPerplexity) -> None:
        http_response = await async_client.responses.with_raw_response.retrieve(
            "response_id",
        )

        assert http_response.is_closed is True
        assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"
        response = await http_response.parse()
        assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncPerplexity) -> None:
        async with async_client.responses.with_streaming_response.retrieve(
            "response_id",
        ) as http_response:
            assert not http_response.is_closed
            assert http_response.http_request.headers.get("X-Stainless-Lang") == "python"

            response = await http_response.parse()
            assert_matches_type(ResponseRetrieveResponse, response, path=["response"])

        assert cast(Any, http_response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncPerplexity) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `response_id` but received ''"):
            await async_client.responses.with_raw_response.retrieve(
                "",
            )
