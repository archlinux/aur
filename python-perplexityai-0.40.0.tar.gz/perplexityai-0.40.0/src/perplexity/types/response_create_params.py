# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .input_item_param import InputItemParam
from .function_tool_param import FunctionToolParam
from .shared_params.response_format import ResponseFormat

__all__ = [
    "ResponseCreateParamsBase",
    "Reasoning",
    "Tool",
    "ToolWebSearchTool",
    "ToolWebSearchToolFilters",
    "ToolWebSearchToolUserLocation",
    "ToolFetchURLTool",
    "ToolPeopleSearchTool",
    "ToolFinanceSearchTool",
    "ToolSandboxTool",
    "ToolMcpTool",
    "ResponseCreateParamsNonStreaming",
    "ResponseCreateParamsStreaming",
]


class ResponseCreateParamsBase(TypedDict, total=False):
    input: Required[Union[str, Iterable[InputItemParam]]]
    """Input content - either a string or array of input items"""

    background: Optional[bool]
    """Run the response asynchronously.

    When true, the request is queued and the response object's `status` will be
    `queued` or `in_progress`. Poll GET /v1/responses/{response_id} to retrieve the
    final result.
    """

    instructions: str
    """System instructions for the model"""

    language_preference: str
    """ISO 639-1 language code for response language"""

    max_output_tokens: int
    """Maximum tokens to generate"""

    max_steps: int
    """
    Maximum number of research loop steps. If provided, overrides the preset's
    max_steps value. Must be >= 1 if specified. Maximum allowed is 10.
    """

    model: str
    """
    Model ID in provider/model format (e.g., "xai/grok-4-1", "openai/gpt-4o"). If
    models is also provided, models takes precedence. Required if neither models nor
    preset is provided.
    """

    models: SequenceNotStr[str]
    """Model fallback chain.

    Each model is in provider/model format. Models are tried in order until one
    succeeds. Max 5 models allowed. If set, takes precedence over single model
    field. The response.model will reflect the model that actually succeeded.
    """

    preset: str
    """
    Preset configuration name (e.g., "sonar-pro", "sonar-reasoning"). Pre-configured
    model with system prompt and search parameters. Required if model is not
    provided.
    """

    previous_response_id: str
    """OpenAI-compatible previous response id for multi-turn response chains.

    When set, the new response continues from the completed prior response using its
    durable continuation snapshot. The prior response must belong to the same
    account and have completed.
    """

    reasoning: Reasoning

    response_format: ResponseFormat
    """Specifies the desired output format for the model response"""

    store: bool
    """OpenAI-compatible storage toggle.

    When false, the response is hidden from later retrieve calls, and the echoed
    response reports `store: false`. It can still be used as a
    `previous_response_id` continuation source.
    """

    tools: Iterable[Tool]
    """Tools available to the model"""


class Reasoning(TypedDict, total=False):
    effort: Literal["minimal", "low", "medium", "high", "xhigh"]
    """How much effort the model should spend on reasoning"""


class ToolWebSearchToolFilters(TypedDict, total=False):
    last_updated_after_filter: str
    """Input: MM/DD/YYYY, Output: YYYY-MM-DD"""

    last_updated_before_filter: str
    """Input: MM/DD/YYYY, Output: YYYY-MM-DD"""

    search_after_date_filter: str
    """Input: MM/DD/YYYY, Output: YYYY-MM-DD"""

    search_before_date_filter: str
    """Input: MM/DD/YYYY, Output: YYYY-MM-DD"""

    search_domain_filter: SequenceNotStr[str]

    search_recency_filter: Literal["hour", "day", "week", "month", "year"]


class ToolWebSearchToolUserLocation(TypedDict, total=False):
    """User's geographic location for search personalization"""

    city: str

    country: str
    """ISO 3166-1 alpha-2 country code"""

    latitude: float

    longitude: float

    region: str


class ToolWebSearchTool(TypedDict, total=False):
    type: Required[Literal["web_search"]]

    filters: ToolWebSearchToolFilters

    max_tokens: int

    max_tokens_per_page: int

    search_context_size: Literal["low", "medium", "high"]
    """Search context size (low, medium, high).

    Omit when supplying explicit max_tokens / max_tokens_per_page.
    """

    user_location: ToolWebSearchToolUserLocation
    """User's geographic location for search personalization"""


class ToolFetchURLTool(TypedDict, total=False):
    type: Required[Literal["fetch_url"]]

    max_urls: int
    """Maximum number of URLs to fetch per tool call"""


class ToolPeopleSearchTool(TypedDict, total=False):
    type: Required[Literal["people_search"]]
    """Enables the `people_search` tool."""


class ToolFinanceSearchTool(TypedDict, total=False):
    type: Required[Literal["finance_search"]]
    """Enables the `finance_search` tool.

    The model can request structured financial data (quotes, financials, segments,
    earnings transcripts, etc.) via category-based fan-out to FMP, Finchat, and
    Quartr.
    """


class ToolSandboxTool(TypedDict, total=False):
    type: Required[Literal["sandbox"]]
    """Enables the `sandbox` tool.

    The model can execute code in an isolated container during the request and use
    the result in its final answer.
    """


class ToolMcpTool(TypedDict, total=False):
    """Connects a user-supplied remote MCP server.

    The worker discovers the
    server's tools at boot and calls them like native tools. Matches
    OpenAI's mcp tool. `require_approval`, `connector_id`, and
    `defer_loading` are not supported in v1 and are ignored if sent:
    every call auto-runs, and only bring-your-own `server_url` is honored.
    """

    server_label: Required[str]
    """Unique per request, ^[a-zA-Z0-9_-]{1,64}$. Namespaces the server's tools."""

    server_url: Required[str]
    """HTTPS URL of the remote MCP server."""

    type: Required[Literal["mcp"]]

    allowed_tools: SequenceNotStr[str]
    """Optional allowlist of tool names. Empty exposes all discovered tools."""

    authorization: str
    """
    An OAuth access token that can be used with a remote MCP server, with a custom
    MCP server URL. Never logged or echoed.
    """

    headers: Dict[str, str]
    """Extra request headers. Never logged or echoed."""


Tool: TypeAlias = Union[
    ToolWebSearchTool,
    ToolFetchURLTool,
    ToolPeopleSearchTool,
    FunctionToolParam,
    ToolFinanceSearchTool,
    ToolSandboxTool,
    ToolMcpTool,
]


class ResponseCreateParamsNonStreaming(ResponseCreateParamsBase, total=False):
    stream: Literal[False]
    """If true, returns SSE stream instead of JSON"""


class ResponseCreateParamsStreaming(ResponseCreateParamsBase):
    stream: Required[Literal[True]]
    """If true, returns SSE stream instead of JSON"""


ResponseCreateParams = Union[ResponseCreateParamsNonStreaming, ResponseCreateParamsStreaming]
