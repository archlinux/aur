# Changelog

## 0.40.0 (2026-07-09)

Full Changelog: [v0.39.0...v0.40.0](https://github.com/perplexityai/perplexity-py/compare/v0.39.0...v0.40.0)

### Features

* **api:** manual updates ([07c9724](https://github.com/perplexityai/perplexity-py/commit/07c9724ab2a3c97386eacc43758ae0057a8b83e9))

## 0.39.0 (2026-07-02)

Full Changelog: [v0.38.0...v0.39.0](https://github.com/perplexityai/perplexity-py/compare/v0.38.0...v0.39.0)

### Features

* **responses:** add `mcp` tool and typed `mcp_list_tools`/`mcp_call` output items ([52f63d3](https://github.com/perplexityai/perplexity-py/commit/52f63d379a5b871fdffedc3bc38c0d6393f4db54))

## 0.38.0 (2026-06-08)

Full Changelog: [v0.37.0...v0.38.0](https://github.com/perplexityai/perplexity-py/compare/v0.37.0...v0.38.0)

### Features

* **responses:** add files subresource for sandbox file retrieval ([0dbfd9c](https://github.com/perplexityai/perplexity-py/commit/0dbfd9ce064505723a5dce4b40be6a766a08a733))

## 0.37.0 (2026-06-02)

Full Changelog: [v0.36.0...v0.37.0](https://github.com/perplexityai/perplexity-py/compare/v0.36.0...v0.37.0)

### Features

* **search:** add search_context_size to search and web_search tool ([44cbf9d](https://github.com/perplexityai/perplexity-py/commit/44cbf9d360d7f86f98f23ade673df470115edf59))

## 0.36.0 (2026-05-30)

Full Changelog: [v0.35.1...v0.36.0](https://github.com/perplexityai/perplexity-py/compare/v0.35.1...v0.36.0)

### Features

* **responses:** add sandbox built-in tool ([9306b5e](https://github.com/perplexityai/perplexity-py/commit/9306b5eeee047ccce4f63b00a5d858e0dede0772))

## 0.35.1 (2026-05-27)

Full Changelog: [v0.35.0...v0.35.1](https://github.com/perplexityai/perplexity-py/compare/v0.35.0...v0.35.1)

### Bug Fixes

* **search:** remove search_context_size from search.create (premature) ([e6f39b6](https://github.com/perplexityai/perplexity-py/commit/e6f39b62099dd180d3cf24924331b931ec8b84a4))

## 0.35.0 (2026-05-27)

Full Changelog: [v0.34.1...v0.35.0](https://github.com/perplexityai/perplexity-py/compare/v0.34.1...v0.35.0)

### Features

* **api:** search_context_size, background tasks, reasoning effort xhigh + responses.retrieve ([93027f5](https://github.com/perplexityai/perplexity-py/commit/93027f5e57e40a6ca07004281c58d5d86c9607b7))

## 0.34.1 (2026-05-27)

Full Changelog: [v0.34.0...v0.34.1](https://github.com/perplexityai/perplexity-py/compare/v0.34.0...v0.34.1)

### Bug Fixes

* **streaming:** yield named SSE events for responses.create + discriminate ResponseStreamEvent union ([011b962](https://github.com/perplexityai/perplexity-py/commit/011b9622d7ed0abdd4964811aa7055271eb8e08c))

## 0.34.0 (2026-05-13)

Full Changelog: [v0.33.0...v0.34.0](https://github.com/perplexityai/perplexity-py/compare/v0.33.0...v0.34.0)

### Features

* **search:** add search_type parameter for People Search routing ([cd15aef](https://github.com/perplexityai/perplexity-py/commit/cd15aef4f4f0a8b2f10eb6adb7fcba7dac7430f3))

## 0.33.0 (2026-05-13)

Full Changelog: [v0.32.1...v0.33.0](https://github.com/perplexityai/perplexity-py/compare/v0.32.1...v0.33.0)

### Features

* **internal/types:** support eagerly validating pydantic iterators ([bcf8068](https://github.com/perplexityai/perplexity-py/commit/bcf8068770450e60c8506561fcc00a51e6d75ba9))
* **responses:** add people_search and finance_search built-in tools ([c475e61](https://github.com/perplexityai/perplexity-py/commit/c475e6177f43d51eecd0409b2803c42c97c22277))
* support setting headers via env ([d0becdc](https://github.com/perplexityai/perplexity-py/commit/d0becdc6b94fb2f17a524c4c6f1e3d806e5d8748))


### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([3e27fb6](https://github.com/perplexityai/perplexity-py/commit/3e27fb63aaca1a81ff48fcc3b0e5f011b356b02b))
* use correct field name format for multipart file arrays ([7f8c6c9](https://github.com/perplexityai/perplexity-py/commit/7f8c6c95a8f1df0b8920c9a4127afe52c8237a73))


### Chores

* **internal:** more robust bootstrap script ([994f129](https://github.com/perplexityai/perplexity-py/commit/994f129a12bf538917303b6201b0766e40a2c526))
* **internal:** reformat pyproject.toml ([7e5d521](https://github.com/perplexityai/perplexity-py/commit/7e5d521fbdd36902af458db48b20429e6e24db77))

## 0.32.1 (2026-04-17)

Full Changelog: [v0.32.0...v0.32.1](https://github.com/perplexityai/perplexity-py/compare/v0.32.0...v0.32.1)

### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([1ce7a22](https://github.com/perplexityai/perplexity-py/commit/1ce7a2273aa0295c45d1b230224ffed1266d0858))

## 0.32.0 (2026-04-14)

Full Changelog: [v0.31.1...v0.32.0](https://github.com/perplexityai/perplexity-py/compare/v0.31.1...v0.32.0)

### Features

* send X-Source and X-Title headers ([430ab7a](https://github.com/perplexityai/perplexity-py/commit/430ab7a33c10604556496e089a1540eb00d8d0a9))

## 0.31.1 (2026-04-10)

Full Changelog: [v0.31.0...v0.31.1](https://github.com/perplexityai/perplexity-py/compare/v0.31.0...v0.31.1)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([fab7c84](https://github.com/perplexityai/perplexity-py/commit/fab7c84cc941910988d0eae8d34f1979e09ec837))
* ensure file data are only sent as 1 parameter ([dc90680](https://github.com/perplexityai/perplexity-py/commit/dc90680152c3edb6395db3539bf544e68afeaf5b))

## 0.31.0 (2026-03-26)

Full Changelog: [v0.30.4...v0.31.0](https://github.com/perplexityai/perplexity-py/compare/v0.30.4...v0.31.0)

### Features

* **internal:** implement indices array format for query and form serialization ([3639a28](https://github.com/perplexityai/perplexity-py/commit/3639a28cd332b7df2b194f35f12b84ce5bf7f1af))


### Chores

* **ci:** skip lint on metadata-only changes ([25a72f3](https://github.com/perplexityai/perplexity-py/commit/25a72f3f08edbf0600e62c07a122910cb05d1123))
* **internal:** update gitignore ([8fb5309](https://github.com/perplexityai/perplexity-py/commit/8fb53095aeadd031d454b0db588ab4dc795a0a3a))

## 0.30.4 (2026-03-22)

Full Changelog: [v0.30.3...v0.30.4](https://github.com/perplexityai/perplexity-py/compare/v0.30.3...v0.30.4)

## 0.30.3 (2026-03-22)

Full Changelog: [v0.30.2...v0.30.3](https://github.com/perplexityai/perplexity-py/compare/v0.30.2...v0.30.3)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([14fce5c](https://github.com/perplexityai/perplexity-py/commit/14fce5c10fee9c457ae654a7b7d238c9e8968114))
* **pydantic:** do not pass `by_alias` unless set ([ed9c1a7](https://github.com/perplexityai/perplexity-py/commit/ed9c1a7b8edd95530de24d6335eead8f2c108906))
* sanitize endpoint path params ([52867d4](https://github.com/perplexityai/perplexity-py/commit/52867d48d8bca5a1c01c9ebac8e410cbf980812b))


### Chores

* **internal:** tweak CI branches ([a880ea6](https://github.com/perplexityai/perplexity-py/commit/a880ea6cdedf9e9d122660ad6dc6ae4a4d1b5280))

## 0.30.2 (2026-03-07)

Full Changelog: [v0.30.1...v0.30.2](https://github.com/perplexityai/perplexity-py/compare/v0.30.1...v0.30.2)

### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([1d14d88](https://github.com/perplexityai/perplexity-py/commit/1d14d88af41a721cef12a16c65c5ffb1dbc0ad3f))

## 0.30.1 (2026-02-24)

Full Changelog: [v0.30.0...v0.30.1](https://github.com/perplexityai/perplexity-py/compare/v0.30.0...v0.30.1)

### Chores

* **internal:** make `test_proxy_environment_variables` more resilient ([7594ae9](https://github.com/perplexityai/perplexity-py/commit/7594ae9444db9b1bde345560bc955db892a59612))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([285dda6](https://github.com/perplexityai/perplexity-py/commit/285dda6fec7393b9539fd09f2c7ec82d121461f1))

## 0.30.0 (2026-02-23)

Full Changelog: [v0.29.1...v0.30.0](https://github.com/perplexityai/perplexity-py/compare/v0.29.1...v0.30.0)

### Features

* **api:** Add browser and sandbox API endpoints ([f5c3e58](https://github.com/perplexityai/perplexity-py/commit/f5c3e58836feb37a6b9ba366a55811513a8cd28c))
* **api:** manual updates ([a556321](https://github.com/perplexityai/perplexity-py/commit/a556321ac2ed946bfeccc9912dd20ee71349a34a))


### Chores

* **internal:** add request options to SSE classes ([b18a992](https://github.com/perplexityai/perplexity-py/commit/b18a992a0eedca20c38932809e1056dfb8c5b00e))
* **internal:** remove mock server code ([081b00d](https://github.com/perplexityai/perplexity-py/commit/081b00d6a86f95631caacd16a46ea91c8f6d97b9))
* update mock server docs ([d6f9a54](https://github.com/perplexityai/perplexity-py/commit/d6f9a5428ecb632baea8705f4eadc1225ba5a9fd))

## 0.29.1 (2026-02-12)

Full Changelog: [v0.29.0...v0.29.1](https://github.com/perplexityai/perplexity-py/compare/v0.29.0...v0.29.1)

### Chores

* format all `api.md` files ([d76052a](https://github.com/perplexityai/perplexity-py/commit/d76052a6e7d1ac44c3543656f8d224f1707627a9))

## 0.29.0 (2026-02-12)

Full Changelog: [v0.28.1...v0.29.0](https://github.com/perplexityai/perplexity-py/compare/v0.28.1...v0.29.0)

### Features

* **api:** Add Embeddings API ([15dec35](https://github.com/perplexityai/perplexity-py/commit/15dec35d373b2fb76a737cacb02b81335e65bf20))

## 0.28.1 (2026-02-11)

Full Changelog: [v0.28.0...v0.28.1](https://github.com/perplexityai/perplexity-py/compare/v0.28.0...v0.28.1)

### Chores

* **internal:** bump dependencies ([2bfd87b](https://github.com/perplexityai/perplexity-py/commit/2bfd87b6af223cc12ed5f254a880c600fd7d0a43))
* **internal:** fix lint error on Python 3.14 ([aab618c](https://github.com/perplexityai/perplexity-py/commit/aab618c6aba3763b603db6bb7428ff0aaf8e28dc))

## 0.28.0 (2026-01-29)

Full Changelog: [v0.27.0...v0.28.0](https://github.com/perplexityai/perplexity-py/compare/v0.27.0...v0.28.0)

### Features

* **client:** add custom JSON encoder for extended type support ([ba938d8](https://github.com/perplexityai/perplexity-py/commit/ba938d869a3ed5adf0662bc119fed186fd70e675))

## 0.27.0 (2026-01-27)

Full Changelog: [v0.26.0...v0.27.0](https://github.com/perplexityai/perplexity-py/compare/v0.26.0...v0.27.0)

### Features

* **api:** manual updates ([93a74f7](https://github.com/perplexityai/perplexity-py/commit/93a74f706faa240308546e28efbaffd71b280d3e))

## 0.26.0 (2026-01-24)

Full Changelog: [v0.25.0...v0.26.0](https://github.com/perplexityai/perplexity-py/compare/v0.25.0...v0.26.0)

### Features

* **client:** add output_text convenience property ([5ead294](https://github.com/perplexityai/perplexity-py/commit/5ead294740d418341a0d01b022cfe8f3e53e45c6))


### Bug Fixes

* sort imports in response_create_response.py ([fd021a3](https://github.com/perplexityai/perplexity-py/commit/fd021a341c3c1f082e6a6c47c320731ec8e92e46))

## 0.25.0 (2026-01-23)

Full Changelog: [v0.24.0...v0.25.0](https://github.com/perplexityai/perplexity-py/compare/v0.24.0...v0.25.0)

### Features

* **api:** manual updates ([f0303a2](https://github.com/perplexityai/perplexity-py/commit/f0303a22729670b04f3d3237577ed6a0cfe965f7))
* **api:** manual updates ([03236e6](https://github.com/perplexityai/perplexity-py/commit/03236e68d4cbe5352b0c82cda65847a9b4cc48cd))

## 0.24.0 (2026-01-23)

Full Changelog: [v0.23.0...v0.24.0](https://github.com/perplexityai/perplexity-py/compare/v0.23.0...v0.24.0)

### Features

* **api:** manual updates ([6b8c312](https://github.com/perplexityai/perplexity-py/commit/6b8c3120b1a845ec8460d3ff1dbb5ee68dba2724))

## 0.23.0 (2026-01-13)

Full Changelog: [v0.22.3...v0.23.0](https://github.com/perplexityai/perplexity-py/compare/v0.22.3...v0.23.0)

### Features

* **client:** add support for binary request streaming ([651a50d](https://github.com/perplexityai/perplexity-py/commit/651a50d83ed6448952b5ba3c087cd88d8239b7a7))

## 0.22.3 (2026-01-05)

Full Changelog: [v0.22.2...v0.22.3](https://github.com/perplexityai/perplexity-py/compare/v0.22.2...v0.22.3)

### Chores

* **internal:** add `--fix` argument to lint script ([6b73854](https://github.com/perplexityai/perplexity-py/commit/6b7385457abfe0ca60cfa9a69233ef88ff9beebc))
* **internal:** codegen related update ([0c1dc69](https://github.com/perplexityai/perplexity-py/commit/0c1dc698aae39057b83a164b2c970d3861cfac82))


### Documentation

* add more examples ([e30d66d](https://github.com/perplexityai/perplexity-py/commit/e30d66d2742254da014330466b5dbf58933c20f3))

## 0.22.2 (2025-12-17)

Full Changelog: [v0.22.1...v0.22.2](https://github.com/perplexityai/perplexity-py/compare/v0.22.1...v0.22.2)

### Bug Fixes

* use async_to_httpx_files in patch method ([87aa45b](https://github.com/perplexityai/perplexity-py/commit/87aa45bc26f1b60b0e8aab33b11ecbf0ee88d380))

## 0.22.1 (2025-12-16)

Full Changelog: [v0.22.0...v0.22.1](https://github.com/perplexityai/perplexity-py/compare/v0.22.0...v0.22.1)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([1dae6e5](https://github.com/perplexityai/perplexity-py/commit/1dae6e56a918d3ac6cbc38accd3058c169199515))


### Chores

* add missing docstrings ([be56ae3](https://github.com/perplexityai/perplexity-py/commit/be56ae34c5342b345e53b706c006f6a873e1db74))
* **internal:** add missing files argument to base client ([a2599a9](https://github.com/perplexityai/perplexity-py/commit/a2599a9261bf65ee59f611918b05eee8b7c55ead))
* speedup initial import ([2e54d11](https://github.com/perplexityai/perplexity-py/commit/2e54d1119537403fe72903a25cba1ef75fcb274f))

## 0.22.0 (2025-12-05)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/perplexityai/perplexity-py/compare/v0.21.0...v0.22.0)

### Features

* **api:** manual updates ([935821c](https://github.com/perplexityai/perplexity-py/commit/935821cb9acbf024ac84892e8dbe2954ae3c4305))


### Chores

* **docs:** use environment variables for authentication in code snippets ([cedc48d](https://github.com/perplexityai/perplexity-py/commit/cedc48d7d7e98f633d934b4e5e867f05005852ab))

## 0.21.0 (2025-12-02)

Full Changelog: [v0.20.1...v0.21.0](https://github.com/perplexityai/perplexity-py/compare/v0.20.1...v0.21.0)

### Features

* **api:** manual updates ([d3a7788](https://github.com/perplexityai/perplexity-py/commit/d3a77881d1015fcb54ee77190d12f1c70fc8c397))


### Bug Fixes

* ensure streams are always closed ([e693ad7](https://github.com/perplexityai/perplexity-py/commit/e693ad78fd587c93eadaf222bf19052644e0418d))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([2769af7](https://github.com/perplexityai/perplexity-py/commit/2769af76861bd8b6ad886874c53f666f05276fa8))
* update lockfile ([fb77b01](https://github.com/perplexityai/perplexity-py/commit/fb77b01b0ca50cafab392b776e31bf8eae1b7c3b))

## 0.20.1 (2025-11-22)

Full Changelog: [v0.20.0...v0.20.1](https://github.com/perplexityai/perplexity-py/compare/v0.20.0...v0.20.1)

### Bug Fixes

* compat with Python 3.14 ([d2d0f32](https://github.com/perplexityai/perplexity-py/commit/d2d0f3228fa678c3715c442f566597418d047a68))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([5e50bc7](https://github.com/perplexityai/perplexity-py/commit/5e50bc77cb15d1d275a3b8297e6f69ec2725a28f))


### Chores

* add Python 3.14 classifier and testing ([b1e5838](https://github.com/perplexityai/perplexity-py/commit/b1e5838891ee06d312d9e038789fd70f0492723f))
* **package:** drop Python 3.8 support ([c5802a8](https://github.com/perplexityai/perplexity-py/commit/c5802a88dec2fe830321b6c07b1fb6c2a0d8beb0))

## 0.20.0 (2025-11-04)

Full Changelog: [v0.19.1...v0.20.0](https://github.com/perplexityai/perplexity-py/compare/v0.19.1...v0.20.0)

### Features

* **api:** add country param ([16c185c](https://github.com/perplexityai/perplexity-py/commit/16c185cc1b1e977991c3b8f152c8b5d8ac8d913b))


### Chores

* **internal:** grammar fix (it's -&gt; its) ([89af593](https://github.com/perplexityai/perplexity-py/commit/89af593a699c843d97043c40aaa7b28a89d265f6))

## 0.19.1 (2025-10-31)

Full Changelog: [v0.19.0...v0.19.1](https://github.com/perplexityai/perplexity-py/compare/v0.19.0...v0.19.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([2d7b697](https://github.com/perplexityai/perplexity-py/commit/2d7b697dc5fce75416c4e770dc6c086bf0e7ec2a))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([5eb163f](https://github.com/perplexityai/perplexity-py/commit/5eb163fcff3a0f0bd9ecbc87407627e044535fee))

## 0.19.0 (2025-10-30)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/perplexityai/perplexity-py/compare/v0.18.0...v0.19.0)

### Features

* **api:** manual updates ([d32c134](https://github.com/perplexityai/perplexity-py/commit/d32c1346744e5521a50da56e0d5a81261fd53f27))

## 0.18.0 (2025-10-29)

Full Changelog: [v0.17.1...v0.18.0](https://github.com/perplexityai/perplexity-py/compare/v0.17.1...v0.18.0)

### Features

* **api:** manual updates ([7a08c95](https://github.com/perplexityai/perplexity-py/commit/7a08c95ea7f9a04004153aac6cfd78022a68fd11))

## 0.17.1 (2025-10-18)

Full Changelog: [v0.17.0...v0.17.1](https://github.com/perplexityai/perplexity-py/compare/v0.17.0...v0.17.1)

### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([c51305f](https://github.com/perplexityai/perplexity-py/commit/c51305fa20dc6109a5efcfcac1f78686234e6147))

## 0.17.0 (2025-10-16)

Full Changelog: [v0.16.1...v0.17.0](https://github.com/perplexityai/perplexity-py/compare/v0.16.1...v0.17.0)

### Features

* **api:** manual updates ([8202e20](https://github.com/perplexityai/perplexity-py/commit/8202e209cce2a2e775fb6b42194d9cfd030ab08d))

## 0.16.1 (2025-10-11)

Full Changelog: [v0.16.0...v0.16.1](https://github.com/perplexityai/perplexity-py/compare/v0.16.0...v0.16.1)

### Chores

* **internal:** detect missing future annotations with ruff ([26f14f1](https://github.com/perplexityai/perplexity-py/commit/26f14f1036636e9635044911c932bd5257d879f5))

## 0.16.0 (2025-10-10)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/perplexityai/perplexity-py/compare/v0.15.0...v0.16.0)

### Features

* **api:** manual updates ([59b9e2d](https://github.com/perplexityai/perplexity-py/commit/59b9e2de4c925b7a8be7e3cff6ffd0de270b5891))

## 0.15.0 (2025-10-08)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/perplexityai/perplexity-py/compare/v0.14.0...v0.15.0)

### Features

* **api:** manual updates ([729cd6a](https://github.com/perplexityai/perplexity-py/commit/729cd6a93cbee77f335a19d6ba09299f08f1d546))

## 0.14.0 (2025-10-08)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/perplexityai/perplexity-py/compare/v0.13.0...v0.14.0)

### Features

* **api:** manual updates ([6c510ea](https://github.com/perplexityai/perplexity-py/commit/6c510eaf7239b14380059214d2fdb65fe2048d5c))

## 0.13.0 (2025-10-02)

Full Changelog: [v0.12.1...v0.13.0](https://github.com/perplexityai/perplexity-py/compare/v0.12.1...v0.13.0)

### Features

* **api:** manual updates ([f92e6d7](https://github.com/perplexityai/perplexity-py/commit/f92e6d70fd638d895b60227dd33bb7641c169a4f))

## 0.12.1 (2025-09-30)

Full Changelog: [v0.12.0...v0.12.1](https://github.com/perplexityai/perplexity-py/compare/v0.12.0...v0.12.1)

## 0.12.0 (2025-09-26)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/perplexityai/perplexity-py/compare/v0.11.0...v0.12.0)

### Features

* **api:** add /chat/completions and /async/chat/completions ([945f7c2](https://github.com/perplexityai/perplexity-py/commit/945f7c27c80ca90f6c703590578a414351e0adb2))
* **api:** add /content endpoint ([7c08ab9](https://github.com/perplexityai/perplexity-py/commit/7c08ab9a1a728ddf8da3523b330e28c8f3f40cd4))
* **api:** change bearer_token to api_key ([af29515](https://github.com/perplexityai/perplexity-py/commit/af295151b4ff3dc44dc5768aa0e965a8f5984840))
* **api:** include /content endpoint ([46697bc](https://github.com/perplexityai/perplexity-py/commit/46697bc483a4647c47368820badcdea6753a1078))
* **api:** manual updates ([d0b1071](https://github.com/perplexityai/perplexity-py/commit/d0b1071f0a16cf589c8c7d58dd545f8455eb6878))
* **api:** manual updates ([7f38b2f](https://github.com/perplexityai/perplexity-py/commit/7f38b2f1eb750a6d5e435a5bfd376b62fa5a9594))
* **api:** manual updates ([8fbe318](https://github.com/perplexityai/perplexity-py/commit/8fbe318c5ed7df04335c2cd14de708cae5780623))
* **api:** update from perform -&gt; create ([c88982f](https://github.com/perplexityai/perplexity-py/commit/c88982f6b0b3ae6060f0754e1cbb8aa3035e4054))
* **api:** update via SDK Studio ([5a26918](https://github.com/perplexityai/perplexity-py/commit/5a269186a185f62a94fbfc57e627f8820194dc23))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([6642343](https://github.com/perplexityai/perplexity-py/commit/66423439ddc11f2db05dc47f71b362c37681a557))
* **internal:** update pydantic dependency ([cac84f2](https://github.com/perplexityai/perplexity-py/commit/cac84f25cd550ee57f8971d74231f63ba8d36905))
* remove custom code ([3270d55](https://github.com/perplexityai/perplexity-py/commit/3270d55b91143e4b9dbc118f39791d36444e0409))
* **types:** change optional parameter type from NotGiven to Omit ([3b0edc9](https://github.com/perplexityai/perplexity-py/commit/3b0edc968f37f3a4233d0a66333e526a23f5073e))
* update SDK settings ([bcb8f64](https://github.com/perplexityai/perplexity-py/commit/bcb8f64648137caf170f0cf4b9816a39780c9f9c))
* update SDK settings ([99e08d9](https://github.com/perplexityai/perplexity-py/commit/99e08d9fb37306acce60d1da281c98d082d34995))
* update SDK settings ([6de8ec2](https://github.com/perplexityai/perplexity-py/commit/6de8ec2ca199470e9f7b70a4f840a6aeef3b1104))

## 0.11.0 (2025-09-24)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/ppl-ai/perplexity-py/compare/v0.10.0...v0.11.0)

### Features

* **api:** manual updates ([d0b1071](https://github.com/ppl-ai/perplexity-py/commit/d0b1071f0a16cf589c8c7d58dd545f8455eb6878))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([6642343](https://github.com/ppl-ai/perplexity-py/commit/66423439ddc11f2db05dc47f71b362c37681a557))
* **types:** change optional parameter type from NotGiven to Omit ([3b0edc9](https://github.com/ppl-ai/perplexity-py/commit/3b0edc968f37f3a4233d0a66333e526a23f5073e))

## 0.10.0 (2025-09-19)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/ppl-ai/perplexity-py/compare/v0.9.0...v0.10.0)

### Features

* **api:** manual updates ([7f38b2f](https://github.com/ppl-ai/perplexity-py/commit/7f38b2f1eb750a6d5e435a5bfd376b62fa5a9594))

## 0.9.0 (2025-09-17)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/ppl-ai/perplexity-py/compare/v0.8.0...v0.9.0)

### Features

* **api:** manual updates ([8fbe318](https://github.com/ppl-ai/perplexity-py/commit/8fbe318c5ed7df04335c2cd14de708cae5780623))


### Chores

* **internal:** update pydantic dependency ([cac84f2](https://github.com/ppl-ai/perplexity-py/commit/cac84f25cd550ee57f8971d74231f63ba8d36905))

## 0.8.0 (2025-09-15)

Full Changelog: [v0.7.2...v0.8.0](https://github.com/ppl-ai/perplexity-py/compare/v0.7.2...v0.8.0)

### Features

* **api:** update via SDK Studio ([5a26918](https://github.com/ppl-ai/perplexity-py/commit/5a269186a185f62a94fbfc57e627f8820194dc23))

## 0.7.2 (2025-09-10)

Full Changelog: [v0.7.1...v0.7.2](https://github.com/ppl-ai/perplexity-py/compare/v0.7.1...v0.7.2)

## 0.7.1 (2025-09-10)

Full Changelog: [v0.7.0...v0.7.1](https://github.com/ppl-ai/perplexity-py/compare/v0.7.0...v0.7.1)

### Chores

* remove custom code ([3270d55](https://github.com/ppl-ai/perplexity-py/commit/3270d55b91143e4b9dbc118f39791d36444e0409))

## 0.7.0 (2025-09-10)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/ppl-ai/perplexity-py/compare/v0.6.0...v0.7.0)

### Features

* **api:** add /chat/completions and /async/chat/completions ([945f7c2](https://github.com/ppl-ai/perplexity-py/commit/945f7c27c80ca90f6c703590578a414351e0adb2))

## 0.6.0 (2025-09-08)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/ppl-ai/perplexity-py/compare/v0.5.0...v0.6.0)

### Features

* **api:** add /content endpoint ([a83e23b](https://github.com/ppl-ai/perplexity-py/commit/a83e23bbcacc8b80748ccf512f3a287ed6011a37))
* **api:** include /content endpoint ([d30ca3e](https://github.com/ppl-ai/perplexity-py/commit/d30ca3e3697f8fd5e17f00762ab2a89ea4d5814f))

## 0.5.0 (2025-09-08)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/ppl-ai/perplexity-py/compare/v0.4.0...v0.5.0)

### Features

* **api:** change bearer_token to api_key ([875bba1](https://github.com/ppl-ai/perplexity-py/commit/875bba126072093d572f00818746b0637a1a56a6))

## 0.4.0 (2025-09-07)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/ppl-ai/perplexity-py/compare/v0.3.0...v0.4.0)

### Features

* **api:** update from perform -&gt; create ([35d2c42](https://github.com/ppl-ai/perplexity-py/commit/35d2c42567e59d53b37be7d4699f80755c09ca30))


### Chores

* update SDK settings ([a5a9d00](https://github.com/ppl-ai/perplexity-py/commit/a5a9d0009d07b48cf9b5f4521705acdb6878c904))

## 0.3.0 (2025-09-07)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/ppl-ai/perplexity-py/compare/v0.2.1...v0.3.0)

### Features

* **api:** update project name ([b9ab21e](https://github.com/ppl-ai/perplexity-py/commit/b9ab21e669afb28c61908dc222cc5a94ec1d6b8e))

## 0.2.1 (2025-09-07)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/ppl-ai/perplexity-py/compare/v0.2.0...v0.2.1)

### Chores

* remove custom code ([e275207](https://github.com/ppl-ai/perplexity-py/commit/e27520747d07452162ae76fddcc7064d3d7f4631))
* update SDK settings ([b4668b0](https://github.com/ppl-ai/perplexity-py/commit/b4668b0ab36992c7e097f4e134a8eb36a2de7395))

## 0.2.0 (2025-09-07)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/ppl-ai/perplexity-py/compare/v0.1.0...v0.2.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))
* **api:** simplify name ([6794370](https://github.com/ppl-ai/perplexity-py/commit/679437027a8d0f3d930902d3410e366cd392beb8))

## 0.1.0 (2025-09-07)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/ppl-ai/perplexity-py/compare/v0.0.2...v0.1.0)

### Features

* **api:** initial updates ([dd0709d](https://github.com/ppl-ai/perplexity-py/commit/dd0709dcc9775ae935a6dad72bc826d2a61dd740))

## 0.0.2 (2025-09-07)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/ppl-ai/perplexity-py/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([b968b23](https://github.com/ppl-ai/perplexity-py/commit/b968b23fc9d25d7cd9e84d2796e33a3f56c60656))
* update SDK settings ([e3c15b6](https://github.com/ppl-ai/perplexity-py/commit/e3c15b6ab6392d0f7605c7ba7666cec2eb405f23))
* update SDK settings ([235c22f](https://github.com/ppl-ai/perplexity-py/commit/235c22f4bdd73b3dd5657bd1caadef4bac172fbe))
