"""Configuration loading and saving — YAML-based settings in ~/.config/fileconverter/."""

from __future__ import annotations
import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from fileconverter.presets import ConversionPreset

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "fileconverter"
CONFIG_FILE = CONFIG_DIR / "settings.yaml"

# resources/ lives INSIDE the package so a pip install ships it too (outside,
# it was simply not installed and the tool started with zero presets).
# PyInstaller bundles data files into sys._MEIPASS.
_BASE_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
DEFAULT_PRESETS_FILE = _BASE_DIR / "resources" / "default_presets.yaml"


HWACCEL_MODES = ["off", "auto", "nvenc", "vaapi", "videotoolbox"]

# Human-readable labels for HWACCEL_MODES, index-aligned — shared by the GTK
# and tkinter settings windows so the dropdowns can't drift apart.
HWACCEL_LABELS = ["Off", "Auto-detect", "NVENC (NVIDIA)", "VAAPI (AMD/Intel)",
                  "VideoToolbox (Apple)"]


CURRENT_VERSION = 2


@dataclass
class Settings:
    max_simultaneous_conversions: int = 2
    exit_when_done: bool = True
    exit_delay_seconds: int = 3
    hardware_acceleration: str = "off"  # off | auto | nvenc | vaapi | videotoolbox
    language: str = "auto"  # auto (system) | locale code like "it_IT"
    presets: list[ConversionPreset] = field(default_factory=list)
    # Bundled presets the user deleted. Without this, the additive merge in
    # load_settings() would re-add them on the very next load, making "Remove"
    # in the settings window impossible.
    removed_presets: list[str] = field(default_factory=list)
    version: int = CURRENT_VERSION

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "max_simultaneous_conversions": self.max_simultaneous_conversions,
            "exit_when_done": self.exit_when_done,
            "exit_delay_seconds": self.exit_delay_seconds,
            "hardware_acceleration": self.hardware_acceleration,
            "language": self.language,
            "removed_presets": list(self.removed_presets),
            "presets": [p.to_dict() for p in self.presets],
        }

    @classmethod
    def from_dict(cls, data: dict) -> Settings:
        # Tolerate a hand-edited or crash-truncated config: coerce every field
        # instead of trusting it. A wrong type here used to be a raw traceback
        # at startup that bricked the app until the YAML was fixed by hand.
        if not isinstance(data, dict):
            data = {}

        hw = data.get("hardware_acceleration", "off")
        if hw not in HWACCEL_MODES:
            hw = "off"

        def _int(key, default, lo, hi):
            try:
                return max(lo, min(hi, int(data.get(key, default))))
            except (TypeError, ValueError):
                return default

        def _bool(key, default):
            val = data.get(key, default)
            return bool(val) if isinstance(val, (bool, int)) else default

        raw_presets = data.get("presets")
        if not isinstance(raw_presets, list):
            raw_presets = []
        presets = []
        for p in raw_presets:
            if not isinstance(p, dict) or not p.get("name") or not p.get("output_type"):
                continue   # skip a malformed preset rather than crash the load
            try:
                presets.append(ConversionPreset.from_dict(p))
            except (TypeError, ValueError, KeyError):
                continue

        removed = data.get("removed_presets")
        removed = [str(n) for n in removed] if isinstance(removed, list) else []

        lang = data.get("language", "auto")
        if not isinstance(lang, str):
            lang = "auto"

        return cls(
            max_simultaneous_conversions=_int("max_simultaneous_conversions", 2, 1, 16),
            exit_when_done=_bool("exit_when_done", True),
            exit_delay_seconds=_int("exit_delay_seconds", 3, 0, 3600),
            hardware_acceleration=hw,
            language=lang,
            presets=presets,
            removed_presets=removed,
            version=_int("version", 1, 1, 9999),
        )


def ensure_config() -> None:
    """Create config directory and copy default presets if settings.yaml doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists() and DEFAULT_PRESETS_FILE.exists():
        shutil.copy2(DEFAULT_PRESETS_FILE, CONFIG_FILE)


def _load_default_settings() -> Settings | None:
    if not DEFAULT_PRESETS_FILE.exists():
        return None
    with open(DEFAULT_PRESETS_FILE, "r") as f:
        data = yaml.safe_load(f) or {}
    return Settings.from_dict(data)


def load_settings() -> Settings:
    """Load settings from YAML config, falling back to defaults.

    Every load runs an additive merge: any default preset whose name is
    missing from the user config is appended.

    When the user config version is older than the bundled default version,
    we also union the input_types of presets that exist in both — so a user
    who hasn't customised inputs picks up newly supported formats. User
    settings (quality, scale, etc.) are never touched.
    """
    ensure_config()
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                raise ValueError("settings.yaml is not a mapping")
        except (yaml.YAMLError, ValueError, OSError) as e:
            # A corrupt config (hand-edited, or truncated by a crash/power
            # loss) must not brick the app. Preserve the bad file for the
            # user, then fall back to bundled defaults.
            try:
                backup = CONFIG_FILE.with_suffix(".yaml.bak")
                shutil.copy2(CONFIG_FILE, backup)
                print(f"fileconverter: settings.yaml unreadable ({e}); "
                      f"backed up to {backup}, using defaults", file=sys.stderr)
            except OSError:
                pass
            defaults = _load_default_settings()
            return defaults if defaults is not None else Settings()

        settings = Settings.from_dict(data)

        defaults = _load_default_settings()
        if defaults is not None:
            changed = False
            existing = {p.name: p for p in settings.presets}
            removed = set(settings.removed_presets)

            for d in defaults.presets:
                if d.name in removed:
                    continue          # the user deleted it — stay deleted
                if d.name not in existing:
                    settings.presets.append(d)
                    changed = True
                elif settings.version < CURRENT_VERSION:
                    # Union input_types so older configs gain newly supported inputs.
                    user_p = existing[d.name]
                    merged = sorted(set(user_p.input_types) | set(d.input_types))
                    if merged != user_p.input_types:
                        user_p.input_types = merged
                        changed = True

            if settings.version < CURRENT_VERSION:
                settings.version = CURRENT_VERSION
                changed = True

            if changed:
                save_settings(settings)
        return settings

    defaults = _load_default_settings()
    if defaults is not None:
        return defaults

    return Settings()


def save_settings(settings: Settings) -> None:
    """Save settings to YAML config file.

    Records which bundled presets are currently absent, so the additive merge
    in load_settings() doesn't resurrect the ones the user removed. Deleting a
    preset and re-adding it by name later simply clears it from the list.
    """
    defaults = _load_default_settings()
    if defaults is not None:
        present = {p.name for p in settings.presets}
        settings.removed_presets = sorted(
            {d.name for d in defaults.presets} - present
        )

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(settings.to_dict(), f, default_flow_style=False, sort_keys=False, allow_unicode=True)
