import asyncio
import json
import logging
import traceback
from datetime import datetime
from typing import TYPE_CHECKING, cast

from keymasq.common.ipc import Command, CommandType
from keymasq.common.models import ActionType, HardwareConfig, ProfileConfig
from keymasq.session.profiles import ResolvedCombo, ResolvedDeviceProfile

from . import payloads as runtime_payloads
from .common import JsonObject
from .common import int_value as _int_value
from .common import json_list as _json_list
from .common import json_object as _json_object

if TYPE_CHECKING:
    from .core import SessionManager

log = logging.getLogger("keymasq-session")
GRAB_DEVICE_TIMEOUT_S = 330.0
GRAB_RETRY_DELAY_S = 5.0


async def activate_initial_profiles(manager: "SessionManager") -> None:
    hardware_ids = manager.hardware.list_hardware_ids()
    log.info("Found %d hardware config(s): %s", len(hardware_ids), hardware_ids)
    await reevaluate_profiles(manager, reason="initial activation")


async def set_profile_enabled(
    manager: "SessionManager",
    profile_name: str,
    enabled: bool | None,
) -> JsonObject:
    profile = await asyncio.to_thread(
        manager.profiles.set_profile_enabled,
        profile_name,
        enabled,
    )
    if profile is None:
        manager.send_notification(
            "Keymasq: Profile Not Found",
            f"Profile '{profile_name}' was not found.",
        )
        return {
            "status": "error",
            "message": f"Profile '{profile_name}' not found",
        }

    await reevaluate_profiles(manager, reason=f"profile {profile_name} enabled={profile.enabled}")
    return {
        "status": "ok",
        "profile_name": profile.name,
        "enabled": profile.enabled,
        "active_profiles": list(manager.profile_state.active_profile_names),
    }


def build_active_profiles_payload(manager: "SessionManager") -> JsonObject:
    devices: dict[str, JsonObject] = {}
    for hardware_id, resolved in sorted(manager.profile_state.resolved_devices.items()):
        hardware = manager.hardware.get_hardware(hardware_id)
        devices[hardware_id] = {
            "device_name": hardware.name if hardware else hardware_id,
            "profiles": list(resolved.active_profile_names),
            "mapping_count": resolved.mapping_count,
            "always_grab_all": resolved.always_grab_all,
        }

    return {
        "status": "ok",
        "active_profiles": list(manager.profile_state.active_profile_names),
        "devices": devices,
    }


def build_profile_overview(manager: "SessionManager") -> JsonObject:
    known_hardware_ids = set(manager.hardware.list_hardware_ids())
    for info in manager.profiles.list_profiles():
        known_hardware_ids.update(info.config.device_layers.keys())

    profiles = sorted(
        manager.profiles.list_profiles(),
        key=lambda p: (p.config.name.casefold(), p.config.created_at or datetime.min),
    )
    devices: list[JsonObject] = []
    for hardware_id in sorted(known_hardware_ids):
        hardware = manager.hardware.get_hardware(hardware_id)
        resolved = manager.profile_state.resolved_devices.get(
            hardware_id,
            ResolvedDeviceProfile(hardware_id),
        )
        devices.append(
            {
                "hardware_id": hardware_id,
                "device_name": hardware.name if hardware else hardware_id,
                "active_profiles": list(resolved.active_profile_names),
                "mapping_count": resolved.mapping_count,
                "always_grab_all": resolved.always_grab_all,
                "profile_count": sum(
                    1 for info in profiles if hardware_id in info.config.device_layers
                ),
            }
        )

    return {
        "status": "ok",
        "profiles": [
            {
                "name": info.config.name,
                "enabled": info.config.enabled,
                "is_permanent": info.config.is_permanent,
                "priority": info.config.priority,
                "window_rule_count": len(info.config.window_rules),
                "created_at": (
                    info.config.created_at.isoformat() if info.config.created_at else ""
                ),
                "devices": sorted(info.config.device_layers.keys()),
                "active": info.config.name in manager.profile_state.active_profile_names,
            }
            for info in profiles
        ],
        "devices": devices,
    }


def cancel_grab_retry(manager: "SessionManager", hardware_id: str) -> None:
    task = manager.profile_state.grab_retry_tasks.pop(hardware_id, None)
    if task is not None and not task.done():
        task.cancel()


def schedule_grab_retry(
    manager: "SessionManager",
    hardware_id: str,
    delay_s: float,
) -> None:
    if not hardware_id:
        return
    existing = manager.profile_state.grab_retry_tasks.get(hardware_id)
    if existing is not None and not existing.done():
        return

    async def _retry() -> None:
        try:
            await asyncio.sleep(delay_s)
            await reevaluate_profiles(manager, reason=f"grab retry for {hardware_id}")
        except asyncio.CancelledError:
            pass
        finally:
            task = manager.profile_state.grab_retry_tasks.get(hardware_id)
            if task is asyncio.current_task():
                manager.profile_state.grab_retry_tasks.pop(hardware_id, None)

    manager.profile_state.grab_retry_tasks[hardware_id] = asyncio.create_task(_retry())


def invalidate_grabbed_state(manager: "SessionManager") -> None:
    runtime_payloads.clear_all_exec_refs(manager)
    for task in list(manager.profile_state.grab_retry_tasks.values()):
        if not task.done():
            task.cancel()
    manager.profile_state.grab_retry_tasks.clear()
    manager.profile_state.grabbed_devices.clear()
    manager.profile_state.grabbed_interfaces.clear()
    manager.profile_state.grab_waiting_devices.clear()
    manager.profile_state.last_sent_grab_signatures.clear()
    manager.profile_state.last_sent_mapping_signatures.clear()
    manager.profile_state.last_sent_combo_signature = ""


def invalidate_runtime_payload_signatures(manager: "SessionManager") -> None:
    manager.profile_state.last_sent_mapping_signatures.clear()
    manager.profile_state.last_sent_combo_signature = ""


async def refresh_macro_bindings(manager: "SessionManager") -> None:
    invalidate_runtime_payload_signatures(manager)
    await reevaluate_profiles(manager, reason="macro bindings refreshed")


def schedule_topology_refresh(
    manager: "SessionManager",
    debounce_s: float,
    retry_s: float,
) -> None:
    existing = manager.profile_state.topology_refresh_task
    if existing is not None and not existing.done():
        existing.cancel()

    async def _run() -> None:
        try:
            delay = debounce_s
            while True:
                await asyncio.sleep(delay)
                try:
                    invalidate_grabbed_state(manager)
                    await reevaluate_profiles(manager, reason="topology refresh")
                    return
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    log.warning("Topology refresh failed: %s", e)
                    delay = retry_s
        except asyncio.CancelledError:
            raise
        finally:
            task = manager.profile_state.topology_refresh_task
            if task is asyncio.current_task():
                manager.profile_state.topology_refresh_task = None

    manager.profile_state.topology_refresh_task = asyncio.create_task(_run())


async def request_profile_reevaluation(
    manager: "SessionManager",
    *,
    reason: str = "",
    wait: bool = False,
) -> asyncio.Task[None]:
    manager.profile_state.apply_generation += 1
    generation = manager.profile_state.apply_generation
    previous = manager.profile_state.apply_task
    current = asyncio.current_task()
    if previous is not None and previous is not current and not previous.done():
        previous.cancel()

    task = asyncio.create_task(
        _reevaluate_profiles_for_generation(manager, generation, reason=reason)
    )
    manager.profile_state.apply_task = task
    manager.profile_state.apply_reason = reason

    def _clear_current_apply(done: asyncio.Task[None]) -> None:
        if manager.profile_state.apply_task is done:
            manager.profile_state.apply_task = None

    task.add_done_callback(_clear_current_apply)
    if wait:
        await task
        latest = cast(
            asyncio.Task[None] | None,
            manager.profile_state.__dict__.get("apply_task"),
        )
        if (
            not profile_apply_is_current(manager, generation)
            and latest is not None
            and latest is not task
        ):
            await latest
    return task


async def reevaluate_profiles(manager: "SessionManager", *, reason: str = "") -> None:
    await request_profile_reevaluation(manager, reason=reason, wait=True)


def profile_apply_is_current(manager: "SessionManager", generation: int | None) -> bool:
    return generation is None or generation == manager.profile_state.apply_generation


def raise_if_stale_profile_apply(
    manager: "SessionManager",
    generation: int | None,
) -> None:
    if not profile_apply_is_current(manager, generation):
        raise asyncio.CancelledError


async def _reevaluate_profiles_for_generation(
    manager: "SessionManager",
    generation: int,
    *,
    reason: str = "",
) -> None:
    try:
        await _reevaluate_profiles(manager, generation=generation, reason=reason)
    except asyncio.CancelledError:
        if manager.verbosity >= 1:
            log.debug(
                "Profile reevaluation interrupted: generation=%s reason=%s",
                generation,
                reason,
            )
    except Exception:
        log.exception("Profile reevaluation failed: generation=%s reason=%s", generation, reason)
        raise


async def _reevaluate_profiles(
    manager: "SessionManager",
    *,
    generation: int | None,
    reason: str = "",
) -> None:
    raise_if_stale_profile_apply(manager, generation)
    hardware_ids = manager.hardware.list_hardware_ids()
    resolved = manager.profiles.resolve_active_profiles(
        manager.compositor_state.current_window,
        manager.compositor_state.compositor_capabilities,
        hardware_ids=hardware_ids,
    )
    raise_if_stale_profile_apply(manager, generation)
    old_active_profile_names = list(manager.profile_state.active_profile_names)
    manager.profile_state.active_profile_names = [
        profile.name for profile in resolved.active_profiles
    ]

    for hardware_id in hardware_ids:
        if hardware_id in manager.capture_state.locks:
            log.info("Reevaluate skipped for %s: capture lock active", hardware_id)
            continue
        device_resolution = resolved.devices.get(
            hardware_id,
            ResolvedDeviceProfile(hardware_id),
        )
        await apply_resolved_device_profile(
            manager,
            hardware_id,
            device_resolution,
            generation=generation,
        )
        raise_if_stale_profile_apply(manager, generation)

    stale_ids = [
        hardware_id
        for hardware_id in list(manager.profile_state.resolved_devices)
        if hardware_id not in set(hardware_ids)
    ]
    for hardware_id in stale_ids:
        manager.profile_state.resolved_devices.pop(hardware_id, None)
        manager.profile_state.last_sent_grab_signatures.pop(hardware_id, None)
        manager.profile_state.last_sent_mapping_signatures.pop(hardware_id, None)

    await update_combos(manager, resolved.combos, generation=generation)
    raise_if_stale_profile_apply(manager, generation)
    manager.broadcast_to_session_clients(
        {"event": "profiles_changed", **build_active_profiles_payload(manager)}
    )
    await play_profile_lifecycle_macros(
        manager,
        old_active_profile_names,
        resolved.active_profiles,
    )


async def play_profile_lifecycle_macros(
    manager: "SessionManager",
    old_active_profile_names: list[str],
    new_active_profiles: list[ProfileConfig],
) -> None:
    old_names = set(old_active_profile_names)
    new_names = {profile.name for profile in new_active_profiles}

    deactivated_names = [name for name in old_active_profile_names if name not in new_names]
    activated_profiles = [
        profile for profile in new_active_profiles if profile.name not in old_names
    ]

    for profile_name in deactivated_names:
        profile_info = manager.profiles.get_profile(profile_name)
        if profile_info is None:
            continue
        await play_profile_lifecycle_macro(
            manager,
            profile_info.config.deactivation_macro_name,
            profile_name=profile_name,
            transition="deactivation",
        )

    for profile in activated_profiles:
        await play_profile_lifecycle_macro(
            manager,
            profile.activation_macro_name,
            profile_name=profile.name,
            transition="activation",
        )


async def play_profile_lifecycle_macro(
    manager: "SessionManager",
    macro_name: str | None,
    *,
    profile_name: str,
    transition: str,
) -> None:
    if not macro_name:
        return
    try:
        result = await manager.client.send_command(
            Command(
                command=CommandType.MACRO_PLAY_BY_NAME,
                data={"name": macro_name},
            )
        )
    except Exception as exc:
        log.warning(
            "Failed to play %s macro '%s' for profile '%s': %s",
            transition,
            macro_name,
            profile_name,
            exc,
        )
        return

    if result.status != "ok":
        log.warning(
            "Failed to play %s macro '%s' for profile '%s': %s",
            transition,
            macro_name,
            profile_name,
            result.error or result.data or "playback failed",
        )


async def apply_resolved_device_profile(
    manager: "SessionManager",
    hardware_id: str,
    resolved: ResolvedDeviceProfile,
    *,
    generation: int | None = None,
) -> None:
    raise_if_stale_profile_apply(manager, generation)
    if hardware_id in manager.capture_state.locks:
        log.debug("Skipping activation for %s while capture is active", hardware_id)
        return

    hardware_config = manager.hardware.get_hardware(hardware_id)
    if not hardware_config:
        log.warning("No hardware config for %s", hardware_id)
        return

    old_resolved = manager.profile_state.resolved_devices.get(hardware_id)
    old_profile_names = old_resolved.active_profile_names if old_resolved else []
    manager.profile_state.resolved_devices[hardware_id] = resolved

    if not resolved.has_effective_mapping:
        cancel_grab_retry(manager, hardware_id)
        manager.profile_state.grab_waiting_devices.discard(hardware_id)
        if hardware_id in manager.profile_state.grabbed_devices:
            await deactivate_profile(
                manager,
                hardware_id,
                immediate=True,
                generation=generation,
            )
        return

    new_interfaces = get_interfaces_to_grab(hardware_config, resolved)
    current_interfaces = manager.profile_state.grabbed_interfaces.get(hardware_id, {})
    grab_payload = build_grab_device_payload(
        manager,
        hardware_id,
        hardware_config,
        resolved,
        new_interfaces,
    )
    grab_signature = grab_device_payload_signature(grab_payload)

    if hardware_id in manager.profile_state.grabbed_devices:
        if set(current_interfaces.keys()) == set(new_interfaces.keys()):
            grab_update_needed = (
                manager.profile_state.last_sent_grab_signatures.get(hardware_id, "")
                != grab_signature
            )
            mapping_update_needed = runtime_payloads.mapping_update_needed(
                manager,
                hardware_id,
                resolved,
            )
            if not grab_update_needed and not mapping_update_needed:
                log.debug("Skipping unchanged mapping for %s", hardware_id)
                maybe_notify_profile_activation(
                    manager,
                    hardware_config.name,
                    old_profile_names,
                    resolved,
                )
                return
            if grab_update_needed:
                updated_grab = await update_grab_device_payload(
                    manager,
                    hardware_id,
                    grab_payload,
                    grab_signature,
                    generation=generation,
                )
                raise_if_stale_profile_apply(manager, generation)
                if not updated_grab:
                    log.warning(
                        "Grab update failed for %s with same interfaces; forcing re-grab",
                        hardware_id,
                    )
                    await deactivate_profile(manager, hardware_id, generation=generation)
                elif not mapping_update_needed:
                    maybe_notify_profile_activation(
                        manager,
                        hardware_config.name,
                        old_profile_names,
                        resolved,
                    )
                    return
            if hardware_id not in manager.profile_state.grabbed_devices:
                log.info(
                    "Grab config refresh deactivated %s; reconfiguring in keymasqd",
                    hardware_id,
                )
            elif mapping_update_needed:
                if old_profile_names == resolved.active_profile_names and manager.verbosity >= 1:
                    log.debug(
                        "Resolved profile set already active for %s, updating mapping only",
                        hardware_id,
                    )
                elif old_profile_names != resolved.active_profile_names:
                    log.info(
                        "Same interfaces for %s, updating mapping only (old=%s new=%s)",
                        hardware_id,
                        old_profile_names,
                        resolved.active_profile_names,
                    )
                updated = await update_mapping(
                    manager,
                    hardware_id,
                    resolved,
                    generation=generation,
                )
                raise_if_stale_profile_apply(manager, generation)
                if updated:
                    maybe_notify_profile_activation(
                        manager,
                        hardware_config.name,
                        old_profile_names,
                        resolved,
                    )
                    return
                log.warning(
                    "Mapping update failed for %s with same interfaces; forcing re-grab",
                    hardware_id,
                )
                await deactivate_profile(manager, hardware_id, generation=generation)
                manager.profile_state.last_sent_grab_signatures.pop(hardware_id, None)
            else:
                maybe_notify_profile_activation(
                    manager,
                    hardware_config.name,
                    old_profile_names,
                    resolved,
                )
                return

        log.info(
            "Interfaces changed for %s, reconfiguring in keymasqd (old: %s -> new: %s)",
            hardware_id,
            list(current_interfaces.keys()),
            list(new_interfaces.keys()),
        )

    log.info("Grabbing device %s (interfaces: %s)", hardware_id, list(new_interfaces.keys()))
    try:
        result = await manager.client.send_command(
            Command(
                command=CommandType.GRAB_DEVICE,
                data=grab_payload,
            ),
            timeout=GRAB_DEVICE_TIMEOUT_S,
        )
        raise_if_stale_profile_apply(manager, generation)
        if result.status == "ok":
            result_data = _json_object(result.data)
            grabbed_count = (
                _int_value(result_data.get("grabbed_count"), 0)
                if result_data is not None
                else 0
            )
            cancel_grab_retry(manager, hardware_id)
            manager.profile_state.grab_waiting_devices.discard(hardware_id)
            log.info("keymasqd: Grabbed device %s: %s", hardware_id, result.data)
            if grabbed_count > 0:
                manager.profile_state.grabbed_devices.add(hardware_id)
                manager.profile_state.grabbed_interfaces[hardware_id] = new_interfaces
                manager.profile_state.last_sent_grab_signatures[hardware_id] = grab_signature
            else:
                manager.profile_state.grabbed_devices.discard(hardware_id)
                manager.profile_state.grabbed_interfaces.pop(hardware_id, None)
                manager.profile_state.last_sent_grab_signatures.pop(hardware_id, None)
                log.warning(
                    (
                        "keymasqd grab returned zero interfaces for %s "
                        "(requested=%s, mappings=%d)"
                    ),
                    hardware_id,
                    list(new_interfaces.keys()),
                    len(resolved.mappings),
                )
                manager.profile_state.last_sent_mapping_signatures.pop(hardware_id, None)
                return
        else:
            log.error("keymasqd: Failed to grab device %s: %s", hardware_id, result.error)
            if "timed out waiting" in str(result.error or "").lower():
                schedule_grab_retry(manager, hardware_id, delay_s=GRAB_RETRY_DELAY_S)
            return
    except Exception as e:
        log.error(
            "keymasqd: Exception grabbing device %s: %s: %s",
            hardware_id,
            type(e).__name__,
            e,
        )
        traceback.print_exc()
        if isinstance(e, TimeoutError):
            manager.send_notification(
                "Keymasq: Grab Timed Out",
                (
                    f"{device_name_for_hardware(manager, hardware_id)}: grab timed out while "
                    "waiting for keys to be released. Retrying automatically."
                ),
            )
            schedule_grab_retry(manager, hardware_id, delay_s=GRAB_RETRY_DELAY_S)
        return

    log.info(
        "Setting mapping for %s with %d buttons from profiles=%s",
        hardware_id,
        len(resolved.mappings),
        resolved.active_profile_names,
    )
    try:
        mapping = runtime_payloads.profile_to_mapping(manager, resolved, hardware_id)
        log.debug("Mapping data: %s", runtime_payloads.mapping_log_view(mapping))
        raise_if_stale_profile_apply(manager, generation)

        result = await manager.client.send_command(
            Command(
                command=CommandType.SET_MAPPING,
                data={
                    "hardware_id": hardware_id,
                    "mapping": mapping,
                },
            )
        )
        raise_if_stale_profile_apply(manager, generation)

        if result.status == "ok":
            manager.profile_state.last_sent_mapping_signatures[hardware_id] = (
                runtime_payloads.resolved_mapping_signature(manager, resolved, hardware_id)
            )
            log.info(
                "Activated resolved profiles %s for %s",
                resolved.active_profile_names,
                hardware_id,
            )
            maybe_notify_profile_activation(
                manager,
                hardware_config.name,
                old_profile_names,
                resolved,
            )
        else:
            log.error("Failed to set mapping: %s", result.error)

    except Exception as e:
        log.error("Exception setting mapping: %s: %s", type(e).__name__, e)
        traceback.print_exc()


def get_interfaces_to_grab(
    hardware_config: HardwareConfig,
    resolved: ResolvedDeviceProfile,
) -> dict[str, str]:
    interface_to_path: dict[str, str] = {}
    for dev in hardware_config.evdev_devices:
        if dev.id:
            interface_to_path[dev.id] = dev.path

    if resolved.always_grab_all:
        return interface_to_path

    button_to_source: dict[str, str] = {
        b.id: b.source for b in hardware_config.buttons if b.source
    }

    sources_to_grab: set[str] = set()
    for button_id, action in resolved.mappings.items():
        if action.action_type != ActionType.PASSTHROUGH:
            source = button_to_source.get(button_id)
            if source:
                sources_to_grab.add(source)

    if resolved.combo_event_count:
        if resolved.combo_sources:
            sources_to_grab.update(resolved.combo_sources)
        else:
            return interface_to_path

    log.info(
        (
            "Interface selection for %s profile=%s: total_ifaces=%d "
            "mapped_buttons=%d resolved_sources=%d"
        ),
        hardware_config.hardware_id,
        resolved.active_profile_names,
        len(interface_to_path),
        len(resolved.mappings),
        len(sources_to_grab),
    )

    return {
        source: interface_to_path[source]
        for source in sources_to_grab
        if source in interface_to_path
    }


def build_grab_device_payload(
    manager: "SessionManager",
    hardware_id: str,
    hardware_config: HardwareConfig,
    resolved: ResolvedDeviceProfile,
    interfaces: dict[str, str],
) -> JsonObject:
    return {
        "hardware_id": hardware_id,
        "evdev_paths": list(interfaces.values()),
        "button_map": {b.id: b.evdev for b in hardware_config.buttons},
        "button_codes": manager.resolved_button_codes(hardware_config.buttons),
        "button_values": {
            b.id: int(evdev_value)
            for b in hardware_config.buttons
            if (evdev_value := getattr(b, "evdev_value", None)) is not None
        },
        "button_sources": {b.id: b.source for b in hardware_config.buttons if b.source},
        "force_grab_unmapped": bool(resolved.combo_event_count),
    }


def grab_device_payload_signature(payload: JsonObject) -> str:
    signature_payload = {
        "evdev_paths": sorted(str(path) for path in _json_list(payload.get("evdev_paths"))),
        "button_map": payload.get("button_map", {}),
        "button_codes": payload.get("button_codes", {}),
        "button_values": payload.get("button_values", {}),
        "force_grab_unmapped": bool(payload.get("force_grab_unmapped", False)),
    }
    return json.dumps(signature_payload, sort_keys=True, separators=(",", ":"))


async def update_grab_device_payload(
    manager: "SessionManager",
    hardware_id: str,
    payload: JsonObject,
    signature: str,
    *,
    generation: int | None = None,
) -> bool:
    try:
        raise_if_stale_profile_apply(manager, generation)
        result = await manager.client.send_command(
            Command(
                command=CommandType.GRAB_DEVICE,
                data=payload,
            ),
            timeout=GRAB_DEVICE_TIMEOUT_S,
        )
        raise_if_stale_profile_apply(manager, generation)
        if result.status != "ok":
            log.error("Failed to update grab config for %s: %s", hardware_id, result.error)
            return False
        result_data = _json_object(result.data)
        grabbed_count = (
            _int_value(result_data.get("grabbed_count"), 0)
            if result_data is not None
            else 0
        )
        if grabbed_count <= 0:
            log.error("Grab config update for %s returned zero grabbed interfaces", hardware_id)
            return False
        manager.profile_state.last_sent_grab_signatures[hardware_id] = signature
        return True
    except Exception as e:
        log.error("Exception updating grab config for %s: %s: %s", hardware_id, type(e).__name__, e)
        return False


async def update_combos(
    manager: "SessionManager",
    combos: list[ResolvedCombo],
    *,
    generation: int | None = None,
) -> None:
    raise_if_stale_profile_apply(manager, generation)
    signature = runtime_payloads.resolved_combos_signature(manager, combos)
    if signature == manager.profile_state.last_sent_combo_signature:
        log.debug("Skipping unchanged combo payload")
        return
    runtime_payloads.clear_combo_exec_refs(manager)
    payload = runtime_payloads.resolved_combos_payload(manager, combos)
    try:
        raise_if_stale_profile_apply(manager, generation)
        result = await manager.client.send_command(
            Command(
                command=CommandType.SET_COMBOS,
                data={"combos": payload},
            )
        )
        raise_if_stale_profile_apply(manager, generation)
        if result.status != "ok":
            log.error("Failed to update combos: %s", result.error)
            return
        manager.profile_state.last_sent_combo_signature = signature
    except Exception as e:
        log.error("Exception updating combos: %s: %s", type(e).__name__, e)


async def update_mapping(
    manager: "SessionManager",
    hardware_id: str,
    resolved: ResolvedDeviceProfile,
    *,
    generation: int | None = None,
) -> bool:
    raise_if_stale_profile_apply(manager, generation)
    if hardware_id not in manager.profile_state.grabbed_devices:
        return False

    signature = runtime_payloads.resolved_mapping_signature(manager, resolved, hardware_id)
    runtime_payloads.clear_exec_refs(manager, hardware_id)

    log.info("Updating mapping for %s with %d buttons", hardware_id, len(resolved.mappings))
    try:
        mapping = runtime_payloads.profile_to_mapping(manager, resolved, hardware_id)
        raise_if_stale_profile_apply(manager, generation)
        result = await manager.client.send_command(
            Command(
                command=CommandType.SET_MAPPING,
                data={
                    "hardware_id": hardware_id,
                    "mapping": mapping,
                },
            )
        )
        raise_if_stale_profile_apply(manager, generation)
        if result.status == "ok":
            log.info("Updated mapping for %s", hardware_id)
            manager.profile_state.last_sent_mapping_signatures[hardware_id] = signature
            return True
        log.error("Failed to update mapping: %s", result.error)
        return False
    except Exception as e:
        log.error("Exception updating mapping: %s: %s", type(e).__name__, e)
        return False


async def deactivate_profile(
    manager: "SessionManager",
    hardware_id: str,
    immediate: bool = False,
    *,
    generation: int | None = None,
) -> None:
    raise_if_stale_profile_apply(manager, generation)
    cancel_grab_retry(manager, hardware_id)
    manager.profile_state.grab_waiting_devices.discard(hardware_id)
    if hardware_id not in manager.profile_state.grabbed_devices:
        return

    try:
        result = await manager.client.send_command(
            Command(
                command=CommandType.RELEASE_DEVICE,
                data={"hardware_id": hardware_id, "immediate": bool(immediate)},
            )
        )
        raise_if_stale_profile_apply(manager, generation)
        if result.status != "ok":
            log.error("Failed to release device %s: %s", hardware_id, result.error)
            return
        manager.profile_state.grabbed_devices.discard(hardware_id)
        manager.profile_state.grabbed_interfaces.pop(hardware_id, None)
        manager.profile_state.last_sent_grab_signatures.pop(hardware_id, None)
        manager.profile_state.last_sent_mapping_signatures.pop(hardware_id, None)
    except Exception as e:
        log.error("Failed to release device %s: %s", hardware_id, e)

    runtime_payloads.clear_exec_refs(manager, hardware_id)
    log.info("Deactivated grabbed mapping for %s", hardware_id)


def maybe_notify_profile_activation(
    manager: "SessionManager",
    device_name: str,
    old_profile_names: list[str],
    resolved: ResolvedDeviceProfile,
) -> None:
    if old_profile_names == resolved.active_profile_names:
        return
    if not resolved.notify_profiles:
        return
    profile_list = ", ".join(resolved.active_profile_names) or "passthrough"
    manager.send_notification("Profile Activated", f"{device_name}: {profile_list}")


def device_name_for_hardware(manager: "SessionManager", hardware_id: str) -> str:
    hardware = manager.hardware.get_hardware(hardware_id)
    if hardware is None:
        return hardware_id
    return str(getattr(hardware, "name", "") or hardware_id)
