import logging
import os
from collections.abc import Callable, Mapping, Sequence
from typing import Final, Protocol, cast

TEST_UINPUT_ENV = "KEYMASQ_TEST_UINPUT"
TEST_UINPUT_PREFIX = "keymasq-test"
TEST_UINPUT_VENDOR = 0x4B46
TEST_UINPUT_PRODUCTS = {
    "keyboard": 0x1001,
    "mouse": 0x1002,
    "gamepad": 0x1003,
    "passthrough": 0x1004,
}


class _ClosableUInput(Protocol):
    def close(self) -> None: ...


class _WritableUInput(_ClosableUInput, Protocol):
    def write(self, event_type: int, code: int, value: int) -> None: ...

    def syn(self) -> None: ...


type UInputWriter = Callable[[_ClosableUInput | None], _WritableUInput | None]


class _OutputState(Protocol):
    device_count: int
    keyboard_uinput: _ClosableUInput | None
    mouse_uinput: _ClosableUInput | None
    gamepad_uinput: _ClosableUInput | None


class _OutputManager(Protocol):
    output_state: _OutputState


class _AbsInfoFactory(Protocol):
    def __call__(
        self, value: int, min: int, max: int, fuzz: int, flat: int, resolution: int
    ) -> object: ...


class _UInputFactory(Protocol):
    def __call__(
        self,
        *,
        events: Mapping[int, Sequence[object]],
        name: str,
        vendor: int = ...,
        product: int = ...,
        version: int = ...,
        bustype: int = ...,
    ) -> _ClosableUInput: ...


class _Ecodes(Protocol):
    EV_KEY: Final[int]
    EV_SYN: Final[int]
    EV_REL: Final[int]
    EV_ABS: Final[int]
    KEY_ESC: Final[int]
    KEY_1: Final[int]
    KEY_2: Final[int]
    KEY_3: Final[int]
    KEY_4: Final[int]
    KEY_5: Final[int]
    KEY_6: Final[int]
    KEY_7: Final[int]
    KEY_8: Final[int]
    KEY_9: Final[int]
    KEY_0: Final[int]
    KEY_MINUS: Final[int]
    KEY_EQUAL: Final[int]
    KEY_BACKSPACE: Final[int]
    KEY_TAB: Final[int]
    KEY_Q: Final[int]
    KEY_W: Final[int]
    KEY_E: Final[int]
    KEY_R: Final[int]
    KEY_T: Final[int]
    KEY_Y: Final[int]
    KEY_U: Final[int]
    KEY_I: Final[int]
    KEY_O: Final[int]
    KEY_P: Final[int]
    KEY_LEFTBRACE: Final[int]
    KEY_RIGHTBRACE: Final[int]
    KEY_ENTER: Final[int]
    KEY_LEFTCTRL: Final[int]
    KEY_A: Final[int]
    KEY_S: Final[int]
    KEY_D: Final[int]
    KEY_F: Final[int]
    KEY_G: Final[int]
    KEY_H: Final[int]
    KEY_J: Final[int]
    KEY_K: Final[int]
    KEY_L: Final[int]
    KEY_SEMICOLON: Final[int]
    KEY_APOSTROPHE: Final[int]
    KEY_GRAVE: Final[int]
    KEY_LEFTSHIFT: Final[int]
    KEY_BACKSLASH: Final[int]
    KEY_102ND: Final[int]
    KEY_Z: Final[int]
    KEY_X: Final[int]
    KEY_C: Final[int]
    KEY_V: Final[int]
    KEY_B: Final[int]
    KEY_N: Final[int]
    KEY_M: Final[int]
    KEY_COMMA: Final[int]
    KEY_DOT: Final[int]
    KEY_SLASH: Final[int]
    KEY_RIGHTSHIFT: Final[int]
    KEY_LEFTALT: Final[int]
    KEY_LEFTMETA: Final[int]
    KEY_SPACE: Final[int]
    KEY_CAPSLOCK: Final[int]
    KEY_F1: Final[int]
    KEY_F2: Final[int]
    KEY_F3: Final[int]
    KEY_F4: Final[int]
    KEY_F5: Final[int]
    KEY_F6: Final[int]
    KEY_F7: Final[int]
    KEY_F8: Final[int]
    KEY_F9: Final[int]
    KEY_F10: Final[int]
    KEY_F11: Final[int]
    KEY_F12: Final[int]
    KEY_RIGHTCTRL: Final[int]
    KEY_RIGHTALT: Final[int]
    KEY_RIGHTMETA: Final[int]
    KEY_MENU: Final[int]
    KEY_SYSRQ: Final[int]
    KEY_SCROLLLOCK: Final[int]
    KEY_PAUSE: Final[int]
    KEY_HOME: Final[int]
    KEY_UP: Final[int]
    KEY_PAGEUP: Final[int]
    KEY_LEFT: Final[int]
    KEY_RIGHT: Final[int]
    KEY_END: Final[int]
    KEY_DOWN: Final[int]
    KEY_PAGEDOWN: Final[int]
    KEY_INSERT: Final[int]
    KEY_DELETE: Final[int]
    KEY_MUTE: Final[int]
    KEY_VOLUMEDOWN: Final[int]
    KEY_VOLUMEUP: Final[int]
    KEY_NUMLOCK: Final[int]
    KEY_KPSLASH: Final[int]
    KEY_KPASTERISK: Final[int]
    KEY_KPMINUS: Final[int]
    KEY_KP7: Final[int]
    KEY_KP8: Final[int]
    KEY_KP9: Final[int]
    KEY_KPPLUS: Final[int]
    KEY_KP4: Final[int]
    KEY_KP5: Final[int]
    KEY_KP6: Final[int]
    KEY_KP1: Final[int]
    KEY_KP2: Final[int]
    KEY_KP3: Final[int]
    KEY_KPENTER: Final[int]
    KEY_KP0: Final[int]
    KEY_KPDOT: Final[int]
    BTN_LEFT: Final[int]
    BTN_RIGHT: Final[int]
    BTN_MIDDLE: Final[int]
    BTN_SIDE: Final[int]
    BTN_EXTRA: Final[int]
    BTN_FORWARD: Final[int]
    BTN_BACK: Final[int]
    REL_X: Final[int]
    REL_Y: Final[int]
    REL_WHEEL: Final[int]
    REL_HWHEEL: Final[int]
    BTN_SOUTH: Final[int]
    BTN_EAST: Final[int]
    BTN_NORTH: Final[int]
    BTN_WEST: Final[int]
    BTN_TL: Final[int]
    BTN_TR: Final[int]
    BTN_TL2: Final[int]
    BTN_TR2: Final[int]
    BTN_SELECT: Final[int]
    BTN_START: Final[int]
    BTN_MODE: Final[int]
    BTN_THUMBL: Final[int]
    BTN_THUMBR: Final[int]
    BTN_DPAD_UP: Final[int]
    BTN_DPAD_DOWN: Final[int]
    BTN_DPAD_LEFT: Final[int]
    BTN_DPAD_RIGHT: Final[int]
    ABS_X: Final[int]
    ABS_Y: Final[int]
    ABS_RX: Final[int]
    ABS_RY: Final[int]
    ABS_Z: Final[int]
    ABS_RZ: Final[int]
    ABS_HAT0X: Final[int]
    ABS_HAT0Y: Final[int]


class _EvdevModule(Protocol):
    ecodes: Final[_Ecodes]
    UInput: Final[_UInputFactory]
    AbsInfo: Final[_AbsInfoFactory]


def _test_uinput_enabled() -> bool:
    value = str(os.environ.get(TEST_UINPUT_ENV, "")).strip().lower()
    return value not in {"", "0", "false", "no"}


def uinput_identity(
    normal_name: str,
    kind: str,
    *,
    test_name: str | None = None,
) -> tuple[str, int | None, int | None]:
    if not _test_uinput_enabled():
        return normal_name, None, None
    return (
        f"{TEST_UINPUT_PREFIX}-{test_name or kind}",
        TEST_UINPUT_VENDOR,
        TEST_UINPUT_PRODUCTS[kind],
    )


def create_global_uinputs(
    manager: _OutputManager,
    *,
    evdev_mod: _EvdevModule,
    log: logging.Logger,
    uinput_writer: UInputWriter,
) -> None:
    if manager.output_state.device_count == 0:
        log.info("Creating global output uinput devices")

        keyboard_caps = {
            evdev_mod.ecodes.EV_KEY: [
                evdev_mod.ecodes.KEY_ESC,
                evdev_mod.ecodes.KEY_1,
                evdev_mod.ecodes.KEY_2,
                evdev_mod.ecodes.KEY_3,
                evdev_mod.ecodes.KEY_4,
                evdev_mod.ecodes.KEY_5,
                evdev_mod.ecodes.KEY_6,
                evdev_mod.ecodes.KEY_7,
                evdev_mod.ecodes.KEY_8,
                evdev_mod.ecodes.KEY_9,
                evdev_mod.ecodes.KEY_0,
                evdev_mod.ecodes.KEY_MINUS,
                evdev_mod.ecodes.KEY_EQUAL,
                evdev_mod.ecodes.KEY_BACKSPACE,
                evdev_mod.ecodes.KEY_TAB,
                evdev_mod.ecodes.KEY_Q,
                evdev_mod.ecodes.KEY_W,
                evdev_mod.ecodes.KEY_E,
                evdev_mod.ecodes.KEY_R,
                evdev_mod.ecodes.KEY_T,
                evdev_mod.ecodes.KEY_Y,
                evdev_mod.ecodes.KEY_U,
                evdev_mod.ecodes.KEY_I,
                evdev_mod.ecodes.KEY_O,
                evdev_mod.ecodes.KEY_P,
                evdev_mod.ecodes.KEY_LEFTBRACE,
                evdev_mod.ecodes.KEY_RIGHTBRACE,
                evdev_mod.ecodes.KEY_ENTER,
                evdev_mod.ecodes.KEY_LEFTCTRL,
                evdev_mod.ecodes.KEY_A,
                evdev_mod.ecodes.KEY_S,
                evdev_mod.ecodes.KEY_D,
                evdev_mod.ecodes.KEY_F,
                evdev_mod.ecodes.KEY_G,
                evdev_mod.ecodes.KEY_H,
                evdev_mod.ecodes.KEY_J,
                evdev_mod.ecodes.KEY_K,
                evdev_mod.ecodes.KEY_L,
                evdev_mod.ecodes.KEY_SEMICOLON,
                evdev_mod.ecodes.KEY_APOSTROPHE,
                evdev_mod.ecodes.KEY_GRAVE,
                evdev_mod.ecodes.KEY_LEFTSHIFT,
                evdev_mod.ecodes.KEY_BACKSLASH,
                evdev_mod.ecodes.KEY_102ND,
                evdev_mod.ecodes.KEY_Z,
                evdev_mod.ecodes.KEY_X,
                evdev_mod.ecodes.KEY_C,
                evdev_mod.ecodes.KEY_V,
                evdev_mod.ecodes.KEY_B,
                evdev_mod.ecodes.KEY_N,
                evdev_mod.ecodes.KEY_M,
                evdev_mod.ecodes.KEY_COMMA,
                evdev_mod.ecodes.KEY_DOT,
                evdev_mod.ecodes.KEY_SLASH,
                evdev_mod.ecodes.KEY_RIGHTSHIFT,
                evdev_mod.ecodes.KEY_LEFTALT,
                evdev_mod.ecodes.KEY_LEFTMETA,
                evdev_mod.ecodes.KEY_SPACE,
                evdev_mod.ecodes.KEY_CAPSLOCK,
                evdev_mod.ecodes.KEY_F1,
                evdev_mod.ecodes.KEY_F2,
                evdev_mod.ecodes.KEY_F3,
                evdev_mod.ecodes.KEY_F4,
                evdev_mod.ecodes.KEY_F5,
                evdev_mod.ecodes.KEY_F6,
                evdev_mod.ecodes.KEY_F7,
                evdev_mod.ecodes.KEY_F8,
                evdev_mod.ecodes.KEY_F9,
                evdev_mod.ecodes.KEY_F10,
                evdev_mod.ecodes.KEY_F11,
                evdev_mod.ecodes.KEY_F12,
                evdev_mod.ecodes.KEY_RIGHTCTRL,
                evdev_mod.ecodes.KEY_RIGHTALT,
                evdev_mod.ecodes.KEY_RIGHTMETA,
                evdev_mod.ecodes.KEY_MENU,
                evdev_mod.ecodes.KEY_SYSRQ,
                evdev_mod.ecodes.KEY_SCROLLLOCK,
                evdev_mod.ecodes.KEY_PAUSE,
                evdev_mod.ecodes.KEY_HOME,
                evdev_mod.ecodes.KEY_UP,
                evdev_mod.ecodes.KEY_PAGEUP,
                evdev_mod.ecodes.KEY_LEFT,
                evdev_mod.ecodes.KEY_RIGHT,
                evdev_mod.ecodes.KEY_END,
                evdev_mod.ecodes.KEY_DOWN,
                evdev_mod.ecodes.KEY_PAGEDOWN,
                evdev_mod.ecodes.KEY_INSERT,
                evdev_mod.ecodes.KEY_DELETE,
                evdev_mod.ecodes.KEY_MUTE,
                evdev_mod.ecodes.KEY_VOLUMEDOWN,
                evdev_mod.ecodes.KEY_VOLUMEUP,
                evdev_mod.ecodes.KEY_NUMLOCK,
                evdev_mod.ecodes.KEY_KPSLASH,
                evdev_mod.ecodes.KEY_KPASTERISK,
                evdev_mod.ecodes.KEY_KPMINUS,
                evdev_mod.ecodes.KEY_KP7,
                evdev_mod.ecodes.KEY_KP8,
                evdev_mod.ecodes.KEY_KP9,
                evdev_mod.ecodes.KEY_KPPLUS,
                evdev_mod.ecodes.KEY_KP4,
                evdev_mod.ecodes.KEY_KP5,
                evdev_mod.ecodes.KEY_KP6,
                evdev_mod.ecodes.KEY_KP1,
                evdev_mod.ecodes.KEY_KP2,
                evdev_mod.ecodes.KEY_KP3,
                evdev_mod.ecodes.KEY_KPENTER,
                evdev_mod.ecodes.KEY_KP0,
                evdev_mod.ecodes.KEY_KPDOT,
            ],
            evdev_mod.ecodes.EV_SYN: [],
        }
        keyboard_name, keyboard_vendor, keyboard_product = uinput_identity(
            "keymasq-keyboard",
            "keyboard",
        )
        if keyboard_vendor is None or keyboard_product is None:
            manager.output_state.keyboard_uinput = evdev_mod.UInput(
                events=cast(dict[int, Sequence[int]], keyboard_caps),
                name=keyboard_name,
            )
        else:
            manager.output_state.keyboard_uinput = evdev_mod.UInput(
                events=cast(dict[int, Sequence[int]], keyboard_caps),
                name=keyboard_name,
                vendor=keyboard_vendor,
                product=keyboard_product,
            )

        mouse_caps = {
            evdev_mod.ecodes.EV_KEY: [
                evdev_mod.ecodes.BTN_LEFT,
                evdev_mod.ecodes.BTN_RIGHT,
                evdev_mod.ecodes.BTN_MIDDLE,
                evdev_mod.ecodes.BTN_SIDE,
                evdev_mod.ecodes.BTN_EXTRA,
                evdev_mod.ecodes.BTN_FORWARD,
                evdev_mod.ecodes.BTN_BACK,
            ],
            evdev_mod.ecodes.EV_REL: [
                evdev_mod.ecodes.REL_X,
                evdev_mod.ecodes.REL_Y,
                evdev_mod.ecodes.REL_WHEEL,
                evdev_mod.ecodes.REL_HWHEEL,
            ],
            evdev_mod.ecodes.EV_SYN: [],
        }
        mouse_rel_caps = list(mouse_caps[evdev_mod.ecodes.EV_REL])
        for high_res_code in (
            getattr(evdev_mod.ecodes, "REL_WHEEL_HI_RES", None),
            getattr(evdev_mod.ecodes, "REL_HWHEEL_HI_RES", None),
        ):
            if high_res_code is not None and high_res_code not in mouse_rel_caps:
                mouse_rel_caps.append(high_res_code)
        mouse_caps[evdev_mod.ecodes.EV_REL] = mouse_rel_caps
        mouse_name, mouse_vendor, mouse_product = uinput_identity(
            "keymasq-mouse",
            "mouse",
        )
        if mouse_vendor is None or mouse_product is None:
            manager.output_state.mouse_uinput = evdev_mod.UInput(
                events=cast(dict[int, Sequence[int]], mouse_caps),
                name=mouse_name,
            )
        else:
            manager.output_state.mouse_uinput = evdev_mod.UInput(
                events=cast(dict[int, Sequence[int]], mouse_caps),
                name=mouse_name,
                vendor=mouse_vendor,
                product=mouse_product,
            )

        gamepad_caps = {
            evdev_mod.ecodes.EV_KEY: [
                evdev_mod.ecodes.BTN_SOUTH,
                evdev_mod.ecodes.BTN_EAST,
                evdev_mod.ecodes.BTN_NORTH,
                evdev_mod.ecodes.BTN_WEST,
                evdev_mod.ecodes.BTN_TL,
                evdev_mod.ecodes.BTN_TR,
                evdev_mod.ecodes.BTN_TL2,
                evdev_mod.ecodes.BTN_TR2,
                evdev_mod.ecodes.BTN_SELECT,
                evdev_mod.ecodes.BTN_START,
                evdev_mod.ecodes.BTN_MODE,
                evdev_mod.ecodes.BTN_THUMBL,
                evdev_mod.ecodes.BTN_THUMBR,
                evdev_mod.ecodes.BTN_DPAD_UP,
                evdev_mod.ecodes.BTN_DPAD_DOWN,
                evdev_mod.ecodes.BTN_DPAD_LEFT,
                evdev_mod.ecodes.BTN_DPAD_RIGHT,
            ],
            evdev_mod.ecodes.EV_ABS: [
                (evdev_mod.ecodes.ABS_X, evdev_mod.AbsInfo(0, -32768, 32767, 16, 128, 0)),
                (evdev_mod.ecodes.ABS_Y, evdev_mod.AbsInfo(0, -32768, 32767, 16, 128, 0)),
                (evdev_mod.ecodes.ABS_RX, evdev_mod.AbsInfo(0, -32768, 32767, 16, 128, 0)),
                (evdev_mod.ecodes.ABS_RY, evdev_mod.AbsInfo(0, -32768, 32767, 16, 128, 0)),
                (evdev_mod.ecodes.ABS_Z, evdev_mod.AbsInfo(0, 0, 255, 0, 0, 0)),
                (evdev_mod.ecodes.ABS_RZ, evdev_mod.AbsInfo(0, 0, 255, 0, 0, 0)),
                (evdev_mod.ecodes.ABS_HAT0X, evdev_mod.AbsInfo(0, -1, 1, 0, 0, 0)),
                (evdev_mod.ecodes.ABS_HAT0Y, evdev_mod.AbsInfo(0, -1, 1, 0, 0, 0)),
            ],
            evdev_mod.ecodes.EV_SYN: [],
        }
        gamepad_name, gamepad_vendor, gamepad_product = uinput_identity(
            "keymasq-gamepad",
            "gamepad",
        )
        manager.output_state.gamepad_uinput = evdev_mod.UInput(
            events=cast(dict[int, Sequence[int]], gamepad_caps),
            name=gamepad_name,
            vendor=0x045E if gamepad_vendor is None else gamepad_vendor,
            product=0x028E if gamepad_product is None else gamepad_product,
            version=0x0110,
            bustype=0x0003,
        )

        gamepad_uinput = uinput_writer(manager.output_state.gamepad_uinput)
        if gamepad_uinput is not None:
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_X, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_Y, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_RX, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_RY, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_Z, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_RZ, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_HAT0X, 0)
            gamepad_uinput.write(evdev_mod.ecodes.EV_ABS, evdev_mod.ecodes.ABS_HAT0Y, 0)
            gamepad_uinput.syn()

    manager.output_state.device_count += 1


def destroy_global_uinputs(manager: _OutputManager, *, log: logging.Logger) -> None:
    manager.output_state.device_count = max(0, manager.output_state.device_count - 1)

    if manager.output_state.device_count == 0:
        log.info("Destroying global output uinput devices")

        for uinput_dev in [
            manager.output_state.keyboard_uinput,
            manager.output_state.mouse_uinput,
            manager.output_state.gamepad_uinput,
        ]:
            if uinput_dev:
                try:
                    uinput_dev.close()
                except Exception as exc:
                    log.warning("Failed to close global uinput device: %s", exc)

        manager.output_state.keyboard_uinput = None
        manager.output_state.mouse_uinput = None
        manager.output_state.gamepad_uinput = None
