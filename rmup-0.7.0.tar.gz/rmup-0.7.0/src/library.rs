/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

use anyhow::{anyhow, Result};
use lofty::{
    file::{AudioFile, TaggedFileExt},
    probe::Probe,
    tag::Accessor,
};
use std::{fs, path::Path};

use crate::playlist::Playlist;

pub mod album;
pub mod artist;
pub mod track;

use album::Album;
use artist::Artist;
use track::Track;

pub fn get_track_data<P: AsRef<Path>>(path: P) -> Result<(Track, Artist, Album)> {
    let path = path.as_ref();
    if !path.is_file() {
        return Err(anyhow!("{} is not a file", path.display()));
    }

    let tagged_file = Probe::open(path)?.read()?;

    let track = if let Some(tag) = tagged_file.primary_tag() {
        Track {
            title: tag.title().as_deref().map(|s| s.to_owned()),
            artist: tag.artist().as_deref().unwrap_or("Unknown").to_owned(),
            album: tag.album().as_deref().unwrap_or("Unknown").to_owned(),
            year: tag.year(),
            number: tag.track(),
            length: tagged_file.properties().duration(),
            file_path: path.to_str().unwrap().to_string(),
        }
    } else {
        Track {
            title: None,
            artist: "Unknown".to_owned(),
            album: "Unknown".to_owned(),
            year: None,
            number: None,
            length: tagged_file.properties().duration(),
            file_path: path.to_str().unwrap().to_string(),
        }
    };

    let mut artist = Artist::default().name(track.artist.as_str());

    let mut album = Album::default().name(track.album.as_str()).year(track.year);

    album.tracks.push(track.clone());

    artist.albums.push(Album::default().name("All Albums"));
    artist.albums[0].tracks.push(track.clone());
    artist.albums.push(album.clone());

    Ok((track, artist, album))
}

pub fn add_path<P: AsRef<Path>>(library: &mut Playlist, path: P) -> Result<()> {
    let path = path.as_ref();
    if !path.exists() {
        return Err(anyhow!("{}: No such file or directory", path.display()));
    }
    if !path.is_dir() {
        if let Some(ext) = path.extension() {
            let ext = ext.to_string_lossy().into_owned();
            match ext.as_str() {
                "mp3" | "flac" | "aiff" | "m4a" | "ogg" | "opus" | "aac" | "wav" => {}
                _ => {
                    return Ok(());
                }
            }
        } else {
            return Ok(());
        }
        let (track, _, _) = get_track_data(path)?;

        // Add track to library
        library.tracks.push(track.clone());
    } else {
        for entry in fs::read_dir(path)? {
            let entry = entry?;
            add_path(library, entry.path())?;
        }
    }

    Ok(())
}
