/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

use ratatui::widgets::ListItem;
use serde::{Deserialize, Serialize};
use std::cmp::Ordering;

use super::track::Track;
use crate::util::*;

#[derive(Clone, Default, Serialize, Deserialize, Debug, Eq, PartialEq)]
pub struct Album {
    /// Name of the album
    pub name: String,

    /// Year from metadata, if present in tracks
    pub year: Option<u32>,

    /// Tracks in the album.
    pub tracks: Vec<Track>,
}

impl Album {
    pub fn name(mut self, name: &str) -> Self {
        self.name = name.to_owned();
        self
    }

    pub fn year(mut self, year: Option<u32>) -> Self {
        self.year = year;
        self
    }
}

/// Albums sort alphabetically
impl Ord for Album {
    fn cmp(&self, other: &Self) -> Ordering {
        if self.name == "All Albums" && other.name != "All Albums" {
            Ordering::Less
        } else if other.name == "All Albums" {
            Ordering::Greater
        } else {
            self.name.to_lowercase().cmp(&other.name.to_lowercase())
        }
    }
}

impl PartialOrd for Album {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl<'a> Into<ListItem<'a>> for &Album {
    fn into(self) -> ListItem<'a> {
        let title = self.name.clone();
        let year = match self.year {
            Some(y) => y.to_string(),
            None => "".to_owned(),
        };
        let term_width = crossterm::terminal::size().unwrap_or((80, 24)).0 as usize;
        let extra = term_width % 2;
        let box_width = term_width / 2 + extra - 2;
        let title_width = box_width - 4;
        ListItem::new(format!("{}{}", to_width(&title, title_width, false), year))
    }
}
