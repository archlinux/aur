#include "src/flatpak/flatpak-progress-dialog.hpp"
#include "ui_flatpak-progress-dialog.h"

#include <QMessageBox>
#include <memory>
#include "src/core/numeric-string.hpp"
#include "src/core/updates.hpp"
#include "src/core/qthread.hpp"
#include "src/ui/icons.hpp"
#include "src/types.hpp"

struct ProgressContext {
	int numOperations;
	int operationsCompleted;
	string operationError;
	Flatpak::OperationType opType;
	bool taskFinished;
	Flatpak::OperationResult result;
	bool dialogExists;
};

static inline string getOpTypeString( Flatpak::OperationType opType ) {
	switch( opType ) {
		case Flatpak::OperationType::Install:
			return "Installing ";
		case Flatpak::OperationType::Update:
			return "Updating ";
		case Flatpak::OperationType::Remove:
			return "Removing ";
		default:
			return "Configuring ";
	}
}

static inline string formatRef( const string &ref ) {
	int splits[3];
	for( size_t i = 0, j = 0; i < ref.length(); i++ ) {
		if( ref[i] == '/' ) {
			splits[j++] = i;
			if( j == 3 ) {
				return ref.substr( splits[0] + 1, splits[1] - splits[0] - 1 ) + " (" + ref.substr( splits[2] + 1 ) + ')';
			}
		}
	}

	return ref;
}

static inline string formatOperationCount( const ProgressContext &context ) {
	return "Operation "s + Number::toString( context.operationsCompleted + 1 ) + " of " + Number::toString( context.numOperations );
}

FlatpakProgressDialog::FlatpakProgressDialog( QWidget *parent ) :
	QDialog( parent ),
	m_ui( new Ui::FlatpakProgressDialog )
{
	m_ui->setupUi( this );
	m_ui->opCountLabel->setText( "Initializing..." );
	m_ui->totalProgress->setRange( 0, 0 );
	m_ui->currentOpLabel->setText( "Initializing..." );
	m_ui->operationProgress->setRange( 0, 0 );
	setFixedSize(size());
	setWindowIcon( Icon::appIcon() );
}

static bool s_trueFunc() noexcept { return true; }

bool FlatpakProgressDialog::run(
	Flatpak::CancelFunc(*operation)(const Flatpak::AsyncCallbacks&),
	const char *dialogTitle,
	const char *initialMessage,
	const char *successMessage,
	const char *failureMessage,
	const char *confirmMessage,
	QWidget *parent
) {
	std::shared_ptr<ProgressContext> context( new ProgressContext );

	FlatpakProgressDialog dialog( parent );
	dialog.setWindowTitle( dialogTitle );
	dialog.m_ui->statusLabel->setText( initialMessage );

	context->numOperations = 0;
	context->operationsCompleted = 0;
	context->operationError = string();
	context->opType = Flatpak::OperationType::Update;
	context->taskFinished = false;
	context->result = Flatpak::OperationResult::Failure;
	context->dialogExists = true;

	Flatpak::AsyncCallbacks callbacks;

	callbacks.onReady = [context,&dialog](int numOperations) {
		if( !context->dialogExists ) return;
		context->numOperations = numOperations;
		QtThread::safeAsync( [context,numOperations,&dialog]() {
			if( !context->dialogExists ) return;
			dialog.m_ui->totalProgress->setRange( 0, numOperations * 100 );
			dialog.m_ui->totalProgress->setValue( 0 );
		});
	};

	callbacks.onOperationStart = [context,&dialog](string ref, string status, Flatpak::OperationType type) {
		if( !context->dialogExists ) return;
		context->opType = type;
		QtThread::safeAsync( [context,ref,status,&dialog]() {
			if( !context->dialogExists ) return;
			dialog.m_ui->opCountLabel->setText( formatOperationCount( *context ).c_str() );
			dialog.m_ui->currentOpLabel->setText( (getOpTypeString( context->opType ) + formatRef( ref )).c_str() );
			dialog.m_ui->operationProgress->setRange( 0, 100 );
			dialog.m_ui->operationProgress->setValue( 0 );
			dialog.m_ui->statusLabel->setText( status.c_str() );
		});
	};

	callbacks.onOperationProgress = [context,&dialog](string status, int progress) {
		if( !context->dialogExists ) return;
		QtThread::safeAsync( [context,status,progress,&dialog]() {
			if( !context->dialogExists ) return;
			dialog.m_ui->totalProgress->setValue( (100 * context->operationsCompleted) + progress );
			if( progress < 100 ) {
				dialog.m_ui->operationProgress->setValue( progress );
				dialog.m_ui->statusLabel->setText( status.c_str() );
			} else {
				dialog.m_ui->operationProgress->setValue( 99 );
				dialog.m_ui->statusLabel->setText( "Finalizing..." );
			}
		});
	};

	callbacks.onOperationFinished = [context]() {
		context->operationsCompleted++;
	};

	callbacks.onOperationError = [context](string errorMessage) {
		context->operationError = errorMessage;
	};

	callbacks.onFinished = [context,&dialog](Flatpak::OperationResult result) {
		context->taskFinished = true;
		context->result = result;
		if( !context->dialogExists ) return;
		QtThread::safeAsync( [context,&dialog]() {
			if( !context->dialogExists ) return;
			dialog.close();
		});
	};

	if( confirmMessage == nullptr ) {
		callbacks.getConfirmation = s_trueFunc;
	} else {
		callbacks.getConfirmation = [confirmMessage]() {
			return QtThread::safeWait<bool>([confirmMessage](){
				return QMessageBox::question( nullptr, "Confirm", confirmMessage ) == QMessageBox::Yes;
			});
		};
	}

	Flatpak::CancelFunc cancelFunc = operation( std::move( callbacks ) );
	dialog.exec();

	context->dialogExists = false;
	if( !context->taskFinished ) {
		cancelFunc();
		return false;
	} else if( context->result == Flatpak::OperationResult::Success ) {
		QMessageBox::information( parent, "Operation Succeeded", successMessage );
		return true;
	} else if( context->result == Flatpak::OperationResult::Failure ) {
		if( context->operationError.empty() ) {
			QMessageBox::critical( parent, "Operation Failed", failureMessage );
		} else {
			QMessageBox::critical( parent, "Operation Failed", (string( failureMessage ) + "\n\nError Details:\n" + context->operationError).c_str() );
		}
		return false;
	}

	return false;
}
