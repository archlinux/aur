# clr-power-tweaks

This is a utility, authored for the purposes of Clear Linux, that sets
reasonable power management defaults for platform devices. This is to improve
energy efficiency while platform is idle.


# Contact

Mailing list, Forums, IRC (freenode), source code repositories, direct e-mail
information, as well as guidance for how to contribute to the Clear Linux
project are maintained at our project website:
* https://clearlinux.org/about


# License

```
Copyright (C) 2012-2019  Intel Corporation

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
```

(The COPYING file has a full copy of the License.)
