#include <sys/socket.h>

int main(int argc, char **argv) {
	socklen_t len;
	return !!sizeof(len);
}
