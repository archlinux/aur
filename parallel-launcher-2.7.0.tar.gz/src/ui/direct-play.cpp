#include "src/ui/direct-play.hpp"

#include <QMessageBox>
#include <cstdlib>
#include <chrono>
#include "src/core/preset-controllers.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/bps.hpp"
#include "src/ui/singleplayer-controller-select-dialog.hpp"
#include "src/ui/direct-play-window.hpp"
#include "src/ui/now-playing-window.hpp"
#include "src/ui/process-awaiter.hpp"
#include "src/ui/core-installer.hpp"
#include "src/ui/main-window.hpp"
#include "src/input/gamepad-controller.hpp"

//TODO: remove some duplicated code from main-window.cpp

static const char *s_crashMessageParallel = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. Alternatively, if you have a very old onboard graphics card, it is possible that Vulkan is not "
	"supported on your system. In either case, using the Glide64 graphics plugin might resolve the issue.";

static const char *s_crashMessageAngrylion = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. If this is the case, try running the ROM with the Glide64 graphics plugin instead.";

#ifndef _WIN32
static const char *s_crashMessageFlatpak = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM is most likely corrupt. If you are not able to launch any ROMs, verify that you have not updated "
	"your graphics drivers since installing RetroArch in Flatpak. If you have, run `flatpak update` to sync "
	"the drivers in Flatpak with the rest of your system.";
#endif

static const char *s_crashMessageDefault = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM is most likely corrupt. If you are not able to launch any ROMs, check that the ParallelN64 "
	"emulator core is installed and that you are using RetroArch version 1.9 or later.";

static inline bool hasBpsExtension( const fs::path &path ) {
	const string extension = path.extension().string();
	return (
		extension.length() == 4 &&
		extension[0] == '.' &&
		( extension[1] == 'b' || extension[1] == 'B' ) &&
		( extension[2] == 'p' || extension[2] == 'P' ) &&
		( extension[3] == 's' || extension[3] == 'S' )
	);
}

static inline ConnectedGamepad getActiveController( const AppSettings &settings ) {
	std::vector<ConnectedGamepad> connectedControllers = GamepadController::instance().getConnected();
	if( connectedControllers.empty() ) {
		return ConnectedGamepad{ -1, ControllerInfo() };
	} else if( connectedControllers.size() == 1 ) {
		return connectedControllers[0];
	}

	if( settings.preferredController.has_value() ) {
		for( const ConnectedGamepad &controller : connectedControllers ) {
			if( controller.info.uuid == settings.preferredController.value() ) {
				return controller;
			}
		}
	}

	SingleplayerControllerSelectDialog dialog( connectedControllers );
	dialog.exec();
	return dialog.getSelectedController();
}

static inline ControllerProfile getControllerProfile( const ConnectedGamepad &controller ) {
	if( controller.id < 0 ) {
		return DefaultProfile::XBox360;
	}

	const HashMap<Uuid,string> mappings = FileController::loadControllerMappings();
	if( mappings.count( controller.info.uuid ) > 0 ) {
		const string &activeProfile = mappings.at( controller.info.uuid );

		const std::map<string, ControllerProfile> profiles = FileController::loadControllerProfiles();
		if( profiles.count( activeProfile ) > 0 ) {
			return profiles.at( activeProfile );
		}
	}

	if( getControllerType( controller.info.controllerId ) == ControllerType::Gamecube ) {
		return DefaultProfile::Gamecube;
	}

	return DefaultProfile::XBox360;
}

static void playRom( const ROM &rom ) {
	const AppSettings &settings = FileController::loadAppSettings();

	const ConnectedGamepad activeController = getActiveController( settings );
	const EmulatorCore emulatorCore = (rom.emulator == EmulatorCore::UseDefault) ? settings.defaultEmulator : rom.emulator;
	if( !CoreInstaller::requireCore( emulatorCore ) ) return;

	const GfxPlugin gfxPlugin = (emulatorCore == EmulatorCore::ParallelN64) ?
		((rom.parallelPlugin == GfxPlugin::UseDefault) ? settings.defaultParallelPlugin : rom.parallelPlugin) :
		((rom.mupenPlugin == GfxPlugin::UseDefault) ? settings.defaultMupenPlugin : rom.mupenPlugin);


	AsyncProcess *emulator = new AsyncProcess();
	try {
		*emulator = RetroArch::launchRom(
			rom.path,
			settings,
			{{ getControllerProfile( activeController ), activeController.info.uuid }},
			FileController::loadInputModes().at( rom.inputModeId ),
			emulatorCore,
			gfxPlugin,
			rom.overclockCPU,
			rom.overclockVI,
			true,
			rom.widescreen
		);
	} catch( ... ) {
		QMessageBox::critical( nullptr, "Emulator Missing", "Failed to launch emulator. It does not appear to be installed." );
		std::exit( 1 );
		return;
	}

	NowPlayingWindow *nowPlayingWindow = nullptr;
	if( !settings.hideWhenPlaying ) {
		nowPlayingWindow = new NowPlayingWindow( emulator, rom.name, rom.playTime );
		nowPlayingWindow->show();
	}

	ProcessAwaiter::QtSafeAwait(
		emulator,
		[=]( [[maybe_unused]] int64 exitCode, int64 runtimeMs ) {
			delete emulator;
			if( nowPlayingWindow != nullptr ) {
				nowPlayingWindow->close();
				nowPlayingWindow->deleteLater();
			}

			if( runtimeMs > 0 ) {
				std::vector<ROM> romList = FileController::loadRomList();
				for( ROM &r : romList ) {
					if( r.path != rom.path ) continue;
					r.playTime = runtimeMs;
					r.lastPlayed = std::chrono::duration_cast<std::chrono::milliseconds>(
						std::chrono::system_clock::now().time_since_epoch()
					).count();
				}
				FileController::saveRomList( romList );
			}

			if( runtimeMs < 2000 ) {
				const char *errorMessage;
				switch( gfxPlugin ) {
					case GfxPlugin::ParaLLEl:
						errorMessage = s_crashMessageParallel;
						break;
					case GfxPlugin::Angrylion:
						errorMessage = s_crashMessageAngrylion;
						break;
					default:
#ifdef _WIN32
						errorMessage = s_crashMessageDefault;
#else
						errorMessage = settings.usingFlatpak ? s_crashMessageFlatpak : s_crashMessageDefault;
#endif
						break;
				}
				QMessageBox::critical( nullptr, "Possible ROM Error", errorMessage );
			}

			std::exit( 0 );
		}
	);
}

static int runWithRom( QApplication &app, const fs::path &romPath, const ROM *rom ) {
	DirectPlayWindow mainWindow( romPath );
	if( rom == nullptr ) {
		QObject::connect( &mainWindow, &DirectPlayWindow::play, [&](){
			ROM romInfo = mainWindow.getRomInfo();

			std::vector<ROM> romList = FileController::loadRomList();
			std::vector<fs::path> savedRoms = FileController::loadSavedRoms();

			romList.push_back( romInfo );
			savedRoms.push_back( romPath );

			FileController::saveRomList( romList );
			FileController::saveSavedRoms( savedRoms );

			playRom( mainWindow.getRomInfo() );
		});

		mainWindow.show();

		QRect geo = mainWindow.geometry();
		geo.setHeight( 0 );
		mainWindow.setGeometry( geo );
	} else {
		mainWindow.hide();
		playRom( *rom );
	}
	return app.exec();
}

static int runWithoutRom( QApplication &app ) {
	QGuiApplication::setQuitOnLastWindowClosed( false );
	MainWindow mainWindow;
	mainWindow.show();
	return app.exec();
}

int DirectPlay::start( QApplication &app, fs::path romPath ) {
	const std::vector<ROM> &romList = FileController::loadRomList();

	if( hasBpsExtension( romPath ) ) {
		Bps::BpsApplyError patchResult = Bps::tryApplyBps( romPath, romList );
		switch( patchResult ) {
			case Bps::BpsApplyError::None:
				romPath.replace_extension( ".z64" );
				break;
			case Bps::BpsApplyError::InvalidBps:
				QMessageBox::critical( nullptr, "Patch Failed", "Failed to patch ROM. The .bps patch appears to be invalid." );
				return runWithoutRom( app );
			case Bps::BpsApplyError::PatchFailed:
				QMessageBox::critical( nullptr, "Patch Failed", "Failed to patch ROM. The base ROM does not match what the patch expects.." );
				return runWithoutRom( app );
			case Bps::BpsApplyError::NoBaseRom:
				QMessageBox::critical( nullptr, "Patch Failed", "Failed to patch ROM. The base rom required to patch is not known to Parallel Launcher." );
				return runWithoutRom( app );
			case Bps::BpsApplyError::WriteError:
				QMessageBox::critical( nullptr, "Patch Failed", "Failed to patch ROM. An error occurred while writing the patched ROM to disk." );
				return runWithoutRom( app );
		}
	}

	const ROM *foundRom = nullptr;
	for( const ROM &rom : romList ) {
		if( rom.path == romPath ) {
			foundRom = &rom;
			break;
		}
	}

	return runWithRom( app, romPath, foundRom );
}
