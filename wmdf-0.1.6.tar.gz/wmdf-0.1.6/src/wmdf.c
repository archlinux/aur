/*
 *    wmthrottle- A dockapp to throttle CPU via ACPI status
 *    Copyright (C) 2002  Thomas Nemeth <tnemeth@free.fr>
 *
 *    Based on work by Seiichi SATO <ssato@sh.rim.or.jp>
 *    Copyright (C) 2001,2002  Seiichi SATO <ssato@sh.rim.or.jp>
 *    and on work by Mark Staggs <me@markstaggs.net>
 *    Copyright (C) 2002  Mark Staggs <me@markstaggs.net>

 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.

 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.

 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/vfs.h>
#include <math.h>
#include "dockapp.h"
#include "backlight_on.xpm"
#include "backlight_off.xpm"
#include "backlight_on_empty.xpm"
#include "backlight_off_empty.xpm"
#include "parts.xpm"

#ifdef linux
#include <sys/stat.h>
#endif

#define FREE(data) {if (data) free (data); data = NULL;}

#define SIZE	    58
#define MAXSTRLEN   512
#define MAXENTS     20
#define WINDOWED_BG ". c #AEAAAE"
#define MAX_HISTORY 16
#define CPUNUM_NONE -1
#define SEPARATOR " ** "

typedef enum { LIGHTOFF, LIGHTON } light;

typedef struct DiskInfo {
	int scrolling;
	int partnumber;
	char *mountdir;
	char *devname;
	float total_blocks;
	float free_blocks;
	float used_blocks;
	long blocksize;
	int percentage;
	struct DiskInfo *next;
} DiskInfo;

Pixmap pixmap;
Pixmap backdrop_on;
Pixmap backdrop_off;
Pixmap backdrop_on_empty;
Pixmap backdrop_off_empty;
Pixmap parts;
Pixmap mask;
int but_stat = -1;
int num_parts = 0;
float title_pos = 0;
float title_pos_track[MAXENTS];
float total_pages;
int motion = 0;
static page = 0;
static int iograph = 0;
static char	*display_name     = "";
static char	*light_color      = NULL;	/* back-light color */
static unsigned update_interval   = 1;
static light    backlight         = LIGHTOFF;
static unsigned switch_authorized = True;
static unsigned alarm_level = 95;
static unsigned int junk, drive_io = 0, drive_rio = 0, drive_wio = 0;
static unsigned int old_rio = 0, old_wio = 0;
static struct statfs fsd;
static DiskInfo *cur_disk_infos = NULL;

#ifdef linux
# ifndef ACPI_32_BIT_SUPPORT
#  define ACPI_32_BIT_SUPPORT      0x0002
# endif
#endif


/* prototypes */
static void update();
static void switch_light();
static void parse_arguments(int argc, char **argv);
static void print_help(char *prog);
static int my_system (char *cmd);
static void init_buttons();
static void button_down(int w, int x, int y);
static void update_title(char *name,int x);
static int update_usage(char *name,int z,int x);
static void add_arrow();
static void setup_icon(int y);
static void setup_scroll(int y);
static void setup_slider(int y);
static void set_scrolling(int x, int y);
static void get_disk_info();
static void update_slider(int x, int z);
static int get_part_numbers(DiskInfo *dsk);
DiskInfo *ret_item(DiskInfo *dsk,int x);
static void just_print(DiskInfo *list);
static void propagate_diskinfo();
static void add_disk(DiskInfo **dsk,char *mnt,char *dev,int x);
static void empty_all(DiskInfo **dsk);
static char * get_mountname(int i);
static void zero_pos();
static void check_alarm(DiskInfo *dsk);
static void update_iograph();
void *xmalloc(size_t size);

int list_of_scroll[MAXENTS];


int main(int argc, char **argv) {
    XEvent   event;
    XpmColorSymbol colors[2] = { {"Back0", NULL, 0}, {"Back1", NULL, 0} };
    int      ncolor = 0;
    struct   sigaction sa;
    FILE *fp;

    sa.sa_handler = SIG_IGN;
#ifdef SA_NOCLDWAIT
    sa.sa_flags = SA_NOCLDWAIT;
#else
    sa.sa_flags = 0;
#endif
    sigemptyset(&sa.sa_mask);
    sigaction(SIGCHLD, &sa, NULL);

    /* Parse CommandLine */
    parse_arguments(argc, argv);

    /* Initialize Application */
    dockapp_open_window(display_name, PACKAGE, SIZE, SIZE, argc, argv);
    dockapp_set_eventmask();

    if (light_color) {
        colors[0].pixel = dockapp_getcolor(light_color);
        colors[1].pixel = dockapp_blendedcolor(light_color, -24, -24, -24, 1.0);
        ncolor = 2;
    }

    /* change raw xpm data to pixmap */
    if (dockapp_iswindowed) {
        backlight_on_xpm[1] = backlight_off_xpm[1] = WINDOWED_BG;
        backlight_on_empty_xpm[1] = backlight_off_empty_xpm[1] = WINDOWED_BG;
    }
    if (!dockapp_xpm2pixmap(backlight_on_empty_xpm, &backdrop_on_empty, &mask, colors, ncolor)) {
        fprintf(stderr, "Error initializing backlit background image.\n");
        exit(1);
    }
    if (!dockapp_xpm2pixmap(backlight_off_empty_xpm, &backdrop_off_empty, NULL, NULL, 0)) {
        fprintf(stderr, "Error initializing background image.\n");
        exit(1);
    }
    if (!dockapp_xpm2pixmap(backlight_on_xpm, &backdrop_on, &mask, colors, ncolor)) {
        fprintf(stderr, "Error initializing backlit background image.\n");
        exit(1);
    }
    if (!dockapp_xpm2pixmap(backlight_off_xpm, &backdrop_off, NULL, NULL, 0)) {
        fprintf(stderr, "Error initializing background image.\n");
        exit(1);
    }
    if (!dockapp_xpm2pixmap(parts_xpm, &parts, NULL, colors, ncolor)) {
        fprintf(stderr, "Error initializing parts image.\n");
        exit(1);
    }

    /* shape window */
    if (!dockapp_iswindowed) dockapp_setshape(mask, 0, 0);
    if (mask) XFreePixmap(display, mask);

    /* pixmap : draw area */
    pixmap = dockapp_XCreatePixmap(SIZE, SIZE);

    /* Initialize pixmap */
    if (backlight == LIGHTON) 
        dockapp_copyarea(backdrop_on, pixmap, 0, 0, SIZE, SIZE, 0, 0);
    else
        dockapp_copyarea(backdrop_off, pixmap, 0, 0, SIZE, SIZE, 0, 0);

    dockapp_set_background(pixmap);
    dockapp_show();
    update();
    init_buttons();

    /* Main loop */
    while (1) {
        if(dockapp_nextevent_or_timeout(&event, update_interval*100)) {
            /* Next Event */
            switch (event.type) {
                case ButtonPress:
				button_down(event.xbutton.button,event.xbutton.x, event.xbutton.y);
				break;
                default: break;
		    }
            }
	else {
			update();
	}
	}
    return 0;
}

static void button_down(int w,int x, int y) {

	int z;

	z = CheckMouseRegion(x, y);

	if(w == 3) {

		if (!iograph) {
			iograph = 1;
			update_interval = 2;
    			switch (backlight) {
        			case LIGHTOFF:
            				dockapp_copyarea(backdrop_off_empty, pixmap, 0, 0, 58, 58, 0, 0);
            			break;
        			case LIGHTON:
            				dockapp_copyarea(backdrop_on_empty, pixmap, 0, 0, 58, 58, 0, 0);
            			break;
			}
			dockapp_copy2window(pixmap);
		}
		else {
			iograph = 0;
			update_interval = 1;
    			switch (backlight) {
        			case LIGHTOFF:
            				dockapp_copyarea(backdrop_off, pixmap, 0, 0, 58, 58, 0, 0);
            			break;
        			case LIGHTON:
            				dockapp_copyarea(backdrop_on, pixmap, 0, 0, 58, 58, 0, 0);
            			break;
			}
			dockapp_copy2window(pixmap);
		}
	}
	else {
		if(iograph) { 
			switch_light();
			return;
		}
		switch (z) {
			case -1:
				if (w == 1)
					switch_light();
				break;
			case 0: 
				page++;
				if(page > total_pages) {
					page = 0;
				}
				break;
			case 1:
				if(list_of_scroll[page*4 + 0])
				   set_scrolling(page*4 + 0,0);
				else 
				   set_scrolling(page*4 + 0,1);
				break;
			case 2:
				if(list_of_scroll[page*4 + 1])
				   set_scrolling(page*4 + 1,0);
				else
				   set_scrolling(page*4 + 1,1);
				break;
			case 3:
				if(list_of_scroll[page*4 + 2])
				   set_scrolling(page*4 + 2,0);
				else
				   set_scrolling(page*4 + 2,1);
				break;
			case 4:
				if(list_of_scroll[page*4 + 3])
				   set_scrolling(page*4 + 3,0);
				else 
				   set_scrolling(page*4 + 3,1);
				break;
			default:
				break;
		}
	}
}

void *xmalloc(size_t size) {
    void *ret = malloc(size);
    if (ret == NULL) {
       perror("malloc() ");
       exit(-1);
    } else
       return ret;
}

static void empty_all(DiskInfo **dsk) {

	DiskInfo *disk = *dsk,*next;
	while (disk) {
		next = disk->next;
		FREE(disk->devname);
		FREE(disk->mountdir);
		free(disk);
		disk = next;
	}
	*dsk = NULL;
}

static void propagate_diskinfo() {
 
	FILE *fp,*fd;
	char mountpoint[255], dummy[255],devnme[255],fstype[255],options[255];
	char s[255];

	unsigned int rio = 0,wio = 0,temprio = 0,tempwio = 0;
	int i = 0;
	int pos = 0;
	int x;

	empty_all(&cur_disk_infos);

	if((fp = fopen("/etc/mtab","r")) != NULL) {

	   while(!feof(fp)) {
		   fscanf(fp,"%s %s %s %s %s %s\n",devnme,mountpoint,fstype,options,dummy,dummy);
		   if((x = strcmp("none",devnme)) != 0) {
			  add_disk(&cur_disk_infos,mountpoint,devnme,i);
			   i++;
		   }
	   }
	} else { 
		fprintf(stderr,"Error opening /etc/mtab\n");
		return;
	}

	fclose(fp);

	/*Uncomment this if you are running a 2.4 kernel*/
	/*if((fd = fopen("/proc/stat","r")) != NULL) {
		while(!feof(fd)) {
			fgets(s,254,fd);
			if( strstr (s, "disk_io: ")) {
				pos = 9;
				while(pos < strlen(s) - 1) {
			   		sscanf(s + pos, "(%u, %u):(%u,%u,%u,%u,%u) ", &junk,&junk, &drive_io, &rio, &junk, &wio, &junk);
					pos += strcspn(s + pos, " ") + 1;
					temprio += rio;
					tempwio += wio;
				}
			}
		}
	} else {
		fprintf(stderr,"Error opening /proc/stat\n");
		return;
	}
	*/
	if(iograph) {
		if((fd = fopen("/proc/diskstats","r")) != NULL) {
			while(!feof(fd)) {
				fgets(s,254,fd);
				if( (strstr (s, "hda ")) || (strstr (s, "sda ")) || (strstr (s, "hdc "))) {
					pos = 14;
			   			sscanf(s + pos, "%u %u %u %u %u %u %u ", &junk, &junk, &rio, &junk, &junk, &junk, &wio);
						temprio += rio;
						tempwio += wio;
				}
			}
		} else {
			fprintf(stderr,"Error opening /proc/diskstats\n");
			return;
		}
		if(old_rio) 
			drive_rio = temprio - old_rio;
		old_rio = temprio;
		if(old_wio) 
			drive_wio = tempwio - old_wio;
		old_wio = tempwio;
			
		fclose(fd);
	}
}

void add_disk(DiskInfo **dsk,char *mnt,char *dev,int x) {

	DiskInfo *disk = *dsk;
	Bool ok = True;
	int s;

	if( !disk) {

		disk = xmalloc(sizeof(DiskInfo));
		*dsk = disk;
	}else { 
		if(x == disk->partnumber) ok = False;
		while( (disk->next) && ok) {
			disk = disk->next;
			if(x == disk->partnumber) ok = False;
		}
		if(!ok) return;
		disk->next = xmalloc(sizeof(DiskInfo));
		disk = disk->next;
	}
		disk->devname = strdup(dev);
		disk->mountdir = strdup(mnt);
		disk->partnumber = x;
		disk->scrolling = list_of_scroll[x];
		statfs(disk->mountdir,&fsd);
		disk->total_blocks = fsd.f_blocks;
		disk->free_blocks = fsd.f_bfree;
		disk->used_blocks = disk->total_blocks - disk->free_blocks;
		disk->blocksize = fsd.f_bsize;
		disk->percentage = disk->free_blocks / disk->total_blocks * 100;
		disk->next = NULL;
}

DiskInfo *ret_item(DiskInfo *dsk,int x) {

	int count = 0;
	DiskInfo *lst = dsk;
	DiskInfo *disk;

	if(x >= num_parts) return NULL;

	while((lst) && (count <= x) && (count < num_parts)) {
		disk = lst;
		lst = lst->next;
		count++;
	}
	return disk;
}

static void update_slider(int x, int z) {

	int y;

	y = 0;

	if(x == 50) x = 49;

	if(backlight == LIGHTON)
		y = 11;

	dockapp_copyarea(parts,pixmap,105,6,x,4,5,(z*13 + 11));
	dockapp_copyarea(parts,pixmap,105,y,(49 - x),4,x+5,(z*13 + 11));

	dockapp_copy2window(pixmap);
}


static void set_scrolling(int x, int y) {

	char *nm ;
	nm = get_mountname(x);
	
	if(!strcmp(nm,"       ")) {
		return;
	}

	list_of_scroll[x] = y;
}

static int get_part_numbers(DiskInfo *dsk) {

	DiskInfo *lst = dsk;
	int n = 0;

	while(lst) {
		n++;
		lst = lst->next;
	}
	return n;
   }

static void just_print(DiskInfo *list) {

	DiskInfo *disk = list;
	float total,free;
	int perc;

	while(disk){
		free = disk->free_blocks;
		total = disk->total_blocks;
		perc = free / total *100;
		fprintf(stderr,"%d %s %s %d %.2f %.2f %d\n",disk->partnumber,disk->devname,disk->mountdir,disk->scrolling,disk->total_blocks,disk->free_blocks,disk->percentage);
		disk = disk->next;
	}
}

static void init_buttons() {

	int i;

	AddMouseRegion(0,50,4,54,8);
	AddMouseRegion(1,5,3,45,9);
	AddMouseRegion(2,5,16,45,22);
	AddMouseRegion(3,5,29,45,35);
	AddMouseRegion(4,5,42,45,48);

	for(i = 0;i < num_parts;i++) {
		set_scrolling(i,0);
	}
}

static int update_usage(char *name, int z, int x)
{
	int i,len,max,pos;
	char title[1024];
	char c = ' ';

	int y;

	y = 0;

	if (backlight == LIGHTON)
		y = 17;

	if (name == NULL)
		return;

	pos = title_pos_track[z];

	len = strlen(name);

	if (len < 6)
	{
		max = len;
		snprintf(title,1024,"%s",name);
	} else {
		max = 6;
		snprintf(title,1024,"%s%s", name,SEPARATOR);
		len = strlen(title);
	}

	if ( pos >= len)
	{
		title_pos_track[z] = 0;
		pos = 0;
	}


	for (i=0; i<max; i++)
	{
		{
			int tmp = i+pos;

			if(tmp < len)
				c = toupper(title[tmp]);
			else
				c = toupper(title[(tmp - len)%6]);
		}

		if (isalpha(c))
			dockapp_copyarea(parts,pixmap,(c - 'A')*6 ,72 + y, 6, 7,(i*6)+5,(x*13)+3);
		else if (isdigit(c))
			dockapp_copyarea(parts,pixmap,(c - '0')*6 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
		else if (isspace(c))
			dockapp_copyarea(parts,pixmap,60 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
		else {
			switch(c)
			{
				case '-':
					dockapp_copyarea(parts,pixmap,66 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case '.':
					dockapp_copyarea(parts,pixmap,72 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case 0x27:
					dockapp_copyarea(parts,pixmap,79 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case '(':
					dockapp_copyarea(parts,pixmap,84 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case ')':
					dockapp_copyarea(parts,pixmap,90 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case '*':
					dockapp_copyarea(parts,pixmap,96 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				case '/':
					dockapp_copyarea(parts,pixmap,103 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
				default:
					dockapp_copyarea(parts,pixmap,60 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					break;
			}
		}
	}
	for (;i<7; i++)
	{
		dockapp_copyarea(parts,pixmap,60 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
	}
	if (len > 6)
		title_pos_track[z] = title_pos_track[z] + 0.5;
	return 1;
}

static char *get_mountname(int i) {

	DiskInfo *lst = cur_disk_infos;
	char *nme;

	while(lst) {
		if(lst->partnumber == i) {
			return lst->mountdir;
		}
		else
			lst = lst->next;
	}
	return "       ";
}

static void update_title(char *name, int x)
{
	int i,len,max,pos;
	char *title = NULL;
	char c = ' ';
	int slash = 0;
	int y;

	y = 0;

	if(backlight == LIGHTON)
	    y = 17;

	if (name == NULL)
		return;

	len = strlen(name);

	if (len > 7) 
		max = 7;
	else
		max = len;

	title = strdup(name);

	for (i=0; i<max; i++)
	{
		c = title[i];

		if (isalpha(c)) {
			c = toupper(title[i]);
			if (slash)
			   dockapp_copyarea(parts,pixmap,(c - 'A')*6 ,72 + y, 6, 7,(i*6)+4,(x*13)+3);
			else
			   dockapp_copyarea(parts,pixmap,(c - 'A')*6 ,72 + y, 6, 7,(i*6)+5,(x*13)+3);
			slash = 0;
		}
		else if (isdigit(c)) {
			if(slash)
		   	   dockapp_copyarea(parts,pixmap,(c - '0')*6 ,81 + y, 6, 7,(i*6)+4,(x*13)+3);
			else
			   dockapp_copyarea(parts,pixmap,(c - '0')*6 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
			slash = 0;
		}
		else {
			switch(c)
			{
				case '-':
					dockapp_copyarea(parts,pixmap,66 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					slash = 0;
					break;
				case '.':
					dockapp_copyarea(parts,pixmap,72 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					slash = 0;
					break;
				case '/': 
					dockapp_copyarea(parts,pixmap,103 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					slash = 1;
					break;
				default:
					dockapp_copyarea(parts,pixmap,60 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
					slash = 0;
					break;
			}
		}
	}
	for (;i<7; i++)
	{
		dockapp_copyarea(parts,pixmap,60 ,81 + y, 6, 7,(i*6)+5,(x*13)+3);
	}
	if (len > 6)
		title_pos = title_pos + 0.5;
	free(title);
}

static void add_arrow() {

	int y = 0;

	if(backlight == LIGHTON)
		y = 6;
	dockapp_copyarea(parts,pixmap,105 ,16 + y, 5, 5,50,4);
}

static void setup_slider(int y) {

	int i;
	int a;
	DiskInfo *dsk;

	a = y;

	for (i = 0; i < 4 ;i++) {
		dsk = ret_item(cur_disk_infos,a);
		if(dsk == NULL)
			update_slider(((0) / 2),i);
		else
			update_slider(((100 - dsk->percentage) / 2),i);
		a++;
	}

}

static void setup_icon(int y) {

	int i;
	int a;
	char *nm;
	int done = 1;

	a = y;

	for (i = 0; i < 4 ;i++) {
			nm = get_mountname(a);
			update_title(nm,i);
			a++;
	}

}

static void setup_scroll(int y) {

	int a;
	int i;
	char usage[1024];
	float total_meg = 0;
	float  total_gb = 0;
	float free_meg = 0;
	float free_gb = 0;
	float used_meg = 0;
	float used_gb = 0;
	DiskInfo *disk;

	a = y;

	for (i = 0; i < 4; i++) {
		
		total_meg = 0;
		total_gb = 0;
		free_meg = 0;
		free_gb = 0;
		used_meg = 0;
		used_gb = 0;

		if(list_of_scroll[a]) {

			disk = ret_item(cur_disk_infos,a);
			free_meg = (disk->free_blocks * disk->blocksize) / 1048576;
			total_meg = (disk->total_blocks * disk->blocksize) / 1048576;
			used_meg = (disk->used_blocks * disk->blocksize) / 1048576;
			if(total_meg > 1000) {
				total_gb = total_meg / 1000;
				total_meg = 0;
			}
			if(free_meg > 1000) {
				free_gb = free_meg / 1000;
				free_meg = 0;
			}
			if(used_meg > 1000) {
				used_gb = used_meg / 1000;
				used_meg = 0;
			}
			snprintf(usage,1024,"%s - TOTAL",disk->mountdir);
			if(total_gb)
			   	sprintf(usage,"%s %.2f GB USED",usage,total_gb);
			if(total_meg)
			   	sprintf(usage,"%s %.2f MB USED",usage,total_meg);
			if(used_gb)
			   	sprintf(usage,"%s %.2f GB FREE",usage,used_gb);
			if(used_meg)
			   	sprintf(usage,"%s %.2f MB FREE",usage,used_meg);
			if(free_gb)
			   	sprintf(usage,"%s %.2f GB",usage,free_gb);
			if(free_meg)
			   	sprintf(usage,"%s %.2f MB",usage,free_meg);
		 		update_usage(usage,a,i);
	}
		  	a++;
    }
}

static void update_iograph() {

	int x;
	int z;

	if(backlight == LIGHTON)
		x = 27;
	else
		x = 0;
	z = (44 > drive_wio) ? drive_wio : 44;
        dockapp_copyarea(parts, pixmap, 125 + x, 25 + (45 - z), 25,44 - (44 - z),4,54 - z);
        dockapp_copyarea(parts, pixmap, 53 + x, 25, 25, (45 - z), 4, 10);
	z = (44 > drive_rio) ? drive_rio : 44;
        dockapp_copyarea(parts, pixmap, 125 + x, 25 + (45 - z), 25,44 - (44 - z),31,54 - z);
        dockapp_copyarea(parts, pixmap, 53 + x, 25, 25, (45 - z), 31, 10);
	dockapp_copy2window(pixmap);
}

static void check_alarm(DiskInfo *dsk) {

	DiskInfo *disk = dsk;
	static Bool in_alarm_mode = False;
	static light pre_backlight;

	while(disk) {

		if (strstr(disk->mountdir,"cdrom") == NULL) {
		if((disk->percentage) < (100 - alarm_level)) {
			if(!in_alarm_mode) {
				in_alarm_mode = True;
				pre_backlight = backlight;
			}
			if( (switch_authorized) || ((! switch_authorized) && (backlight != pre_backlight) ) ) {
				switch_light();
				return;
			}
		}
		else {
		        if (in_alarm_mode) {
			            in_alarm_mode = False;
		                    if (backlight != pre_backlight) {
				                switch_light();
				                return;
				     }
			 }
		}
           }
		disk = disk->next;
	}
}

/* called by timer */
static void update() {
    
	static light pre_backlight;
    	int x;

       propagate_diskinfo();
       if(!iograph) {
       		num_parts = get_part_numbers(cur_disk_infos);
       		if(num_parts == 4) 
	       		total_pages = 0;
       		else
    	       		total_pages = num_parts/4;
       		check_alarm(cur_disk_infos);
       		setup_icon(page*4);
       		setup_scroll(page*4);
       		setup_slider(page*4);
       		add_arrow();
       }
       else {
       	       check_alarm(cur_disk_infos);
	       update_iograph();
       }

}


/* called when mouse button pressed */
static void switch_light() {
	if(iograph) {
    switch (backlight) {
        case LIGHTOFF:
            backlight = LIGHTON;
            dockapp_copyarea(backdrop_on_empty, pixmap, 0, 0, 58, 58, 0, 0);
            break;
        case LIGHTON:
            backlight = LIGHTOFF;
            dockapp_copyarea(backdrop_off_empty, pixmap, 0, 0, 58, 58, 0, 0);
            break;
    }
	}
	else {
    switch (backlight) {
        case LIGHTOFF:
            backlight = LIGHTON;
            dockapp_copyarea(backdrop_on, pixmap, 0, 0, 58, 58, 0, 0);
            break;
        case LIGHTON:
            backlight = LIGHTOFF;
            dockapp_copyarea(backdrop_off, pixmap, 0, 0, 58, 58, 0, 0);
            break;
    }
	}

    /* show */
    dockapp_copy2window(pixmap);
}

static void parse_arguments(int argc, char **argv) {
    int i;
    int integer;
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            print_help(argv[0]), exit(0);
        } else if (!strcmp(argv[i], "--version") || !strcmp(argv[i], "-v")) {
            printf("%s version %s\n", PACKAGE, VERSION), exit(0);
        } else if (!strcmp(argv[i], "--display") || !strcmp(argv[i], "-d")) {
            display_name = argv[i + 1];
            i++;
        } else if (!strcmp(argv[i], "--backlight") || !strcmp(argv[i], "-bl")) {
            backlight = LIGHTON;
        } else if (!strcmp(argv[i], "--light-color") || !strcmp(argv[i], "-lc")) {
            light_color = argv[i + 1];
            i++;
        } else if (!strcmp(argv[i], "--alarm_threshold") || !strcmp(argv[i], "-at")) {
            if (argc == i + 1)
                fprintf(stderr, "%s: error parsing argument for option %s\n",
                        argv[0], argv[i]), exit(1);
            if (sscanf(argv[i + 1], "%i", &integer) != 1)
                fprintf(stderr, "%s: error parsing argument for option %s\n",
                        argv[0], argv[i]), exit(1);
            if (integer < 1)
                fprintf(stderr, "%s: argument %s must be >=1\n",
                        argv[0], argv[i]), exit(1);
            alarm_level = integer;
            i++;
        } else if (!strcmp(argv[i], "--interval") || !strcmp(argv[i], "-i")) {
            if (argc == i + 1)
                fprintf(stderr, "%s: error parsing argument for option %s\n",
                        argv[0], argv[i]), exit(1);
            if (sscanf(argv[i + 1], "%i", &integer) != 1)
                fprintf(stderr, "%s: error parsing argument for option %s\n",
                        argv[0], argv[i]), exit(1);
            if (integer < 1)
                fprintf(stderr, "%s: argument %s must be >=1\n",
                        argv[0], argv[i]), exit(1);
            update_interval = integer;
            i++;
        } else {
            fprintf(stderr, "%s: unrecognized option '%s'\n", argv[0], argv[i]);
            print_help(argv[0]), exit(1);
        }
    }
}


static void print_help(char *prog)
{
    printf("Usage : %s [OPTIONS]\n"
           "%s - Window Maker mails monitor dockapp\n"
           "  -d,  --display <string>        display to use\n"
           "  -bl, --backlight               turn on back-light\n"
           "  -lc, --light-color <string>    back-light color(rgb:6E/C6/3B is default)\n"
           "  -i,  --interval <number>       number of secs between updates (1 is default)\n"
           "  -h,  --help                    show this help text and exit\n"
           "  -v,  --version                 show program version and exit\n"
           "  -w,  --windowed                run the application in windowed mode\n"
           "  -bw, --broken-wm               activate broken window manager fix\n"
           "  -at, --alarm_threshold         set the disk usage percent to sound alarm at (95 is default)\n",
           prog, prog);
    /* OPTIONS SUPP :
     *  ? -f, --file    : configuration file
     */
}
