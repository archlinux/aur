#!/usr/bin/env bash
systemctl --user start canokey-console-legacy
while ! timeout 2 bash -c "echo > /dev/tcp/localhost/31098" 2>/dev/null; do
  sleep 0.1
done
(chromium http://localhost:31098/ &> /dev/null &)
