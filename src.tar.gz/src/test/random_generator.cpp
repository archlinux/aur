#include <chrono>
#include <iostream>

int main() {
  std::srand(std::time(nullptr));
  for (int i = 0; i < 20; ++i) std::cout << (std::rand()/((RAND_MAX + 1u)/3)) << std::endl;
  return 0;
}
