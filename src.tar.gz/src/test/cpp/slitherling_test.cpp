#include "slitherling.h"
#include <cassert>
#include <iostream>

void testGameState() {
  slitherling::GameState gs{};
  slitherling::GameStateReport r = gs.report();
  int speed = r.s.getSpeed();
  float singlePixelSeconds = 1.0 / speed;

  std::cout << "===GAMESTATE===" << std::endl;

  // Initial state - moving right, root 10, 10
  std::cout << r.getSegments()[0].getRoot().x << ", ";
  std::cout << r.getSegments()[0].getRoot().y << std::endl;

  // Update time sufficient to move one pixel, confirm root now at 11
  gs.update(singlePixelSeconds, 0);
  r = gs.report();
  assert(r.getSegments()[0].getRoot().x == 11);

  // Move one pixel, confirm length, dir unchanged, root now at 12
  gs.update(singlePixelSeconds, 0);
  r = gs.report();
  assert(r.getSegments()[0].getDirection() == slitherling::Direction::E);
  assert(r.getSegments()[0].getLength() == 30);

  // Change direction, new head added with root at old root (12) + length (30) = 42
  gs.directionChange(slitherling::Direction::S);
  r = gs.report();
  assert(r.getSegments().size() == 2);
  assert(r.getSegments()[0].getDirection() == slitherling::Direction::S);
  assert(r.getSegments()[0].getRoot().x == 42);
  assert(r.getSegments()[0].getRoot().y == 10);
  assert(r.getSegments()[0].getLength() == 0);

  // Update now extend new head by one length in y dir and retract old segment
  gs.update(singlePixelSeconds, 0);
  r = gs.report();
  assert(r.getSegments().size() == 2);
  assert(r.getSegments()[0].getDirection() == slitherling::Direction::S);
  assert(r.getSegments()[0].getLength() == 1);
  assert(r.getSegments()[1].getLength() == 29);

  // Update 29 more pixels, head is extended to original 30 px, tail segment is gone
  gs.update(singlePixelSeconds * 29, 0);
  r = gs.report();
  assert(r.getSegments().size() == 1);
  assert(r.getSegments()[0].getLength() == 30);
  assert(r.getSegments()[0].getRoot().y == 10);

  // Update 1 more pixels, head is extended 1 south and also retracted 1 to 11
  gs.update(singlePixelSeconds, 0);
  r = gs.report();
  assert(r.getSegments().size() == 1);
  assert(r.getSegments()[0].getLength() == 30);
  assert(r.getSegments()[0].getRoot().y == 11);

  // Update 20 more pixels, head has moved 20 south
  gs.update(singlePixelSeconds * 20, 0);
  r = gs.report();
  assert(r.getSegments().size() == 1);
  assert(r.getSegments()[0].getLength() == 30);
  assert(r.getSegments()[0].getRoot().y == 31);

  // Change direction, new head added with root at old root (42, 31) + length (30) = 61
  gs.directionChange(slitherling::Direction::E);
  r = gs.report();
  assert(r.getSegments().size() == 2);
  assert(r.getSegments()[0].getDirection() == slitherling::Direction::E);
  assert(r.getSegments()[0].getRoot().x == 42);
  std::cout << r.getSegments()[0].getLength() << std::endl;
  assert(r.getSegments()[0].getRoot().y == 61);
  assert(r.getSegments()[0].getLength() == 0);

  // Update 35 pixels. New head grows 35, old head retracts 35 which is longer than
  // its length, so it retracts 5 pixels into the new head giving a single segment
  // with length 30 again.

  gs.update(singlePixelSeconds * 35, 0);
  r = gs.report();
  assert(r.getSegments().size() == 1);
  assert(r.getSegments()[0].getLength() == 30);
  assert(r.getSegments()[0].getRoot().y == 61);
  assert(r.getSegments()[0].getRoot().x == 42 + 5);

  std::cout << "===============" << std::endl;
}

int main() {
  testGameState();

  slitherling::GameState gs{};
  slitherling::start(gs);
}
