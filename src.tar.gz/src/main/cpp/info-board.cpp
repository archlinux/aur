#include "info-board.h"

slitherling::InfoBoard::InfoBoard(const sf::Font& font, const CycleTime& ct) : ct(ct) {
  text.setFont(font);
  text.setPosition(5, 5);
}

void slitherling::InfoBoard::draw(sf::RenderTarget& target, sf::RenderStates) const {
  target.draw(text);
}

void slitherling::InfoBoard::appendItem(std::string itemText, float removalSecond) {
  items.push_back(std::make_pair(itemText, removalSecond));
  sort(items.begin(), items.end(), [](auto a, auto b){return a.second < b.second;});

  std::stringstream displayText;
  for (auto item : items) {
    displayText << item.first << std::endl;
  }

  refresh(displayText);
}

void slitherling::InfoBoard::removeExpired() {
  float secondsSinceStart = ct.totalElapsedSeconds();

  if (items.empty() || items[0].second > secondsSinceStart) return;

  std::size_t i = 0;
  std::stringstream displayText;
  while (i < items.size() && items[i].second >= secondsSinceStart) {
    displayText << items.at(i).first << std::endl;
    ++i;
  }

  items.resize(i);
  refresh(displayText);
}

void slitherling::InfoBoard::refresh(const std::stringstream &displayText) {
  static const float screenPixelHeight = sf::VideoMode::getFullscreenModes()[0].height;
  text.setString(displayText.str());
  text.setPosition(5, screenPixelHeight - 5 - text.getGlobalBounds().height);
}
