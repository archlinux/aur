#include "infect-sound.h"
#include "path-finder.h"

slitherling::InfectSound::InfectSound() {
  soundPath = findPathTo("infect.wav");
  if (!soundPath.empty()) {
    buffer.loadFromFile(soundPath / "infect.wav");
    sound.setBuffer(buffer);
  }
}

sf::Sound& slitherling::InfectSound::get() {
  return sound;
}
