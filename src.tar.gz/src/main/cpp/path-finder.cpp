#include "path-finder.h"
#include <cstdlib>
#include <filesystem>

std::filesystem::path slitherling::findPathTo(std::string filename) {
  namespace fs = std::filesystem;

  char* snapEnv = std::getenv("SNAP");

  fs::path root("/");
  fs::path path(fs::current_path());

  while (!fs::exists(path / filename) && !fs::equivalent(path, root)) {
    path /= "..";
  }

  if (!fs::exists(path / filename) && snapEnv != nullptr) path = snapEnv;
  if (!fs::exists(path / filename)) path = fs::path("/usr/share/slitherling");
  if (!fs::exists(path / filename)) path.clear();

  return path;
}
