#include "font-provider.h"
#include "path-finder.h"

slitherling::FontProvider::FontProvider() {
  fontPath = findPathTo("slitherling_font.ttf");
  if (!fontPath.empty()) font.loadFromFile(fontPath / "slitherling_font.ttf");
}

sf::Font& slitherling::FontProvider::getFont() {
  return font;
}
