#include "cycle-time.h"

void slitherling::CycleTime::mark() {
  cycleTime = clock.restart();
  totalTime += cycleTime;
}

float slitherling::CycleTime::totalElapsedSeconds() const {
  return totalTime.asSeconds();
}

float slitherling::CycleTime::cycleElapsedSeconds() const {
  return cycleTime.asSeconds();
}
