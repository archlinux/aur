#include "version-provider.h"
#include "path-finder.h"

std::string slitherling::VersionProvider::getVersion() {
  std::stringstream versionStream;
  std::string fn = "SLITHERLING_VERSION";
  std::filesystem::path versionPath = findPathTo(fn);

  if (!versionPath.empty()) versionStream << std::ifstream{versionPath / fn}.rdbuf();

  return versionStream.str();
}
