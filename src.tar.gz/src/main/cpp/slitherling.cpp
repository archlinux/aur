#include "slitherling.h"

void slitherling::start(slitherling::GameState gs) {
  sf::RenderWindow window(sf::VideoMode::getFullscreenModes()[0], "slitherling", sf::Style::Fullscreen);
  window.setMouseCursorVisible(false);
  window.setFramerateLimit(60);
  window.setKeyRepeatEnabled(false);
  CycleTime ct{};
  FontProvider fp{};
  InfoBoard ib(fp.getFont(), ct);
  ib.appendItem("Version: " + VersionProvider::getVersion(), 5);
  while (window.isOpen()) {
    sf::Event event;
    bool directionChanged = false;

    while (window.pollEvent(event)) {
      if (event.type == sf::Event::Closed) window.close();
      if (event.type == sf::Event::KeyPressed && !directionChanged) {
        directionChanged = true;
        switch (event.key.code) {
          case sf::Keyboard::Right :
          case sf::Keyboard::L :
            gs.directionChange(Direction::E);
          break;
          case sf::Keyboard::Down :
          case sf::Keyboard::J :
            gs.directionChange(Direction::S);
          break;
          case sf::Keyboard::Left :
          case sf::Keyboard::H :
            gs.directionChange(Direction::W);
          break;
          case sf::Keyboard::Up :
          case sf::Keyboard::K :
            gs.directionChange(Direction::N);
          break;
          case sf::Keyboard::Escape :
            window.close();
          break;
          case sf::Keyboard::Space :
            gs.directionChangeAuto();
          break;
          default:
          break;
        }
      }
    }

    ct.mark();
    gs.update(ct.cycleElapsedSeconds(), ct.totalElapsedSeconds());
    ib.removeExpired();
    window.clear();
    window.draw(gs);
    window.draw(ib);
    window.display();

    if (gs.endState()) {
      using namespace std::chrono_literals;
      std::this_thread::sleep_for(2s);
      gs.reset();
      ct.mark();
    }
  }
}

slitherling::Fruit::Fruit(const sf::Texture &appleTexture, float totalElapsedSeconds) {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;
  static const float screenPixelHeight = sf::VideoMode::getFullscreenModes()[0].height;

  sprite = sf::Sprite(appleTexture);
  bounds = sprite.getGlobalBounds();
  float randX = bounds.width + std::rand()/((RAND_MAX + 1u)/(screenPixelWidth - 2 * bounds.width));
  float randY = bounds.height + std::rand()/((RAND_MAX + 1u)/(screenPixelHeight - 2 * bounds.height));
  posn = sf::Vector2f{randX, randY};
  sprite.setPosition(posn.x - bounds.width / 2, posn.y - bounds.height / 2);
  bounds = sprite.getGlobalBounds();
  sprite.setColor(sf::Color(255, 0, 0, 255));
  rotSecond = totalElapsedSeconds + secondsToRot;
}

void slitherling::Fruit::draw(sf::RenderTarget &target, sf::RenderStates) const {
  target.draw(sprite);
}

bool slitherling::Fruit::isBeingEaten(const slitherling::Snake &s) const {
  return bounds.contains(s.tipPosn());
}

void slitherling::GameState::draw(sf::RenderTarget &target, sf::RenderStates rs) const {
  s.draw(target, rs);
  for (Fruit fruit : fruits) fruit.draw(target, rs);
  for (Parasite parasite : parasites) parasite.draw(target, rs);
}

slitherling::Direction slitherling::Snake::direction() const {
  return segments.front().getDirection();
}

sf::Vector2f slitherling::GameState::nearestFruitPosn(slitherling::Snake s) const {
  float distance = std::numeric_limits<float>::max();
  sf::Vector2f tipPosn = s.tipPosn();

  sf::Vector2f fruitPosn{-1, 0};
  for (Fruit fruit : fruits) {
    float fruitDistance = std::abs(fruit.posn.x - tipPosn.x) + std::abs(fruit.posn.y - tipPosn.y);
    if (fruitDistance < distance) {
      fruitPosn.x = fruit.posn.x;
      fruitPosn.y = fruit.posn.y;
      distance = fruitDistance;
    }
  }

  return fruitPosn;
}

sf::Vector2f slitherling::GameState::centerScreen() const {
  static const sf::Vector2f center{
    (float)sf::VideoMode::getFullscreenModes()[0].width / 2,
    (float)sf::VideoMode::getFullscreenModes()[0].height / 2};

  return center;
}

void slitherling::GameState::directionChangeAuto() {
  sf::Vector2f fruitPosn = nearestFruitPosn(s);
  if (fruitPosn.x == -1) fruitPosn = centerScreen();

  switch (s.direction()) {
    case E:
    case W:
      directionChange(fruitPosn.y > s.tipPosn().y ? Direction::S : Direction::N);
    break;
    case N:
    case S:
      directionChange(fruitPosn.x > s.tipPosn().x ? Direction::E : Direction::W);
    break;
  }
}

void slitherling::GameState::directionChange(Direction d) {
  s.changeDirection(d);
}

slitherling::GameStateReport::GameStateReport(Snake s, std::vector<Fruit> f) : s(s), fruits(f) {}

slitherling::GameStateReport slitherling::GameState::report() {
  GameStateReport r{s, fruits};
  return r;
}

std::vector<slitherling::Snake::Segment> slitherling::GameStateReport::getSegments() const {
  return s.segments;
}

sf::Vector2f slitherling::Snake::tipPosn() const {
  Segment headSegment = segments.front();

  switch (headSegment.d) {
    case Direction::E:
      return sf::Vector2f{headSegment.root.x + headSegment.length, headSegment.root.y};
    case Direction::S:
      return sf::Vector2f{headSegment.root.x, headSegment.root.y + headSegment.length};
    case Direction::W:
      return sf::Vector2f{headSegment.root.x - headSegment.length, headSegment.root.y};
    case Direction::N:
      return sf::Vector2f{headSegment.root.x, headSegment.root.y - headSegment.length};
    default:
      return sf::Vector2f{};
  }
}

bool slitherling::Snake::isDead() const {
  return energy <= 0;
}

void slitherling::Snake::reset() {
  segments.clear();
  segments.resize(1);
  energy = 100;
}

bool slitherling::GameState::endState() const {
  return s.isDead();
}

void slitherling::GameState::reset() {
  s.reset();
  fruits.clear();
  parasites.clear();
}

sf::Vector2f slitherling::Fruit::getPosn() const {
  return posn;
}

void slitherling::Fruit::updateColor(float totalElapsedSeconds) {
  float rotPercentage = 1.0f - std::min((rotSecond - totalElapsedSeconds) / secondsToRot, 100.0f);
  return sprite.setColor(sf::Color(255, 255 * rotPercentage, 255 * rotPercentage, 255));
}

bool slitherling::Fruit::isRotten(float totalElapsedSeconds) const {
  return rotSecond <= totalElapsedSeconds;
}

void slitherling::GameState::update(float cycleElapsedSeconds, float totalElapsedSeconds) {
  s.slither(cycleElapsedSeconds);

  for (auto it = parasites.begin(); it != parasites.end();) {
    if (it->shouldDie(totalElapsedSeconds)) {
      it = parasites.erase(it);
    } else if (s.containsPoint(it->posn)) {
      s.absorbParasite();
      it = parasites.erase(it);
    } else {
      it->update(cycleElapsedSeconds);
      ++it;
    }
  }

  for (auto it = fruits.begin(); it != fruits.end();) {
    if (it->isBeingEaten(s)) {
      s.grow();

      it = fruits.erase(it);
    } else if (it->isRotten(totalElapsedSeconds)) {
      spawnSound.get().play();
      for (int i = 0; i < 4; ++i) parasites.emplace_back(it->getPosn(), totalElapsedSeconds);
      it = fruits.erase(it);
    } else {
      it->updateColor(totalElapsedSeconds);
      ++it;
    }
  }

  if (std::rand() % 100 == 0) fruits.emplace_back(appleTexture.get(), totalElapsedSeconds);
}

slitherling::GameState::GameState() : gulpSound(), spawnSound(), infectSound(), s(gulpSound.get(), infectSound.get()) {
  std::srand(std::time(nullptr));
}

slitherling::Snake::Segment::Segment() {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;

  root = sf::Vector2f(10, 10);
  d = Direction::E;
  length = screenPixelWidth / initialLengthScreenWidthFraction;
  width = length / 5;
  halfWidth = width / 2;
  circle = sf::CircleShape(halfWidth);
}

bool slitherling::Snake::Segment::containsPoint(const sf::Vector2f &point) const {
  sf::FloatRect rect;

  switch(d) {
    case Direction::E :
      rect = sf::FloatRect{root.x, root.y - halfWidth, length, width};
    break;
    case Direction::S :
      rect = sf::FloatRect{root.x - halfWidth, root.y, width, length};
    break;
    case Direction::W :
      rect = sf::FloatRect{root.x - length, root.y - halfWidth, length, width};
    break;
    case Direction::N :
      rect = sf::FloatRect{root.x - halfWidth, root.y - length, width, length};
    break;
  }

  return rect.contains(point);
}

sf::Vector2f slitherling::Snake::Segment::getRoot() const {
  return root;
}

slitherling::Direction slitherling::Snake::Segment::getDirection() const {
  return d;
}

float slitherling::Snake::Segment::getLength() const {
  return length;
}

void slitherling::Snake::Segment::retract(float distance) {
  switch (d) {
    case E:
      root.x += distance;
      break;
    case S:
      root.y += distance;
      break;
    case W:
      root.x -= distance;
      break;
    case N:
      root.y -= distance;
      break;
  }

  length -= distance;
}

void slitherling::Snake::Segment::extend(float distance) {
  length += distance;
}

void slitherling::Snake::Segment::updateDrawnEntities() {
  switch (d) {
    case N:
    case S:
      rectangle.setPosition(root.x - halfWidth, root.y);
      break;
    case E:
    case W:
      rectangle.setPosition(root.x, root.y + halfWidth);
      break;
  }

  switch (d) {
    case N:
      rectangle.setSize(sf::Vector2f(width, -length));
      circle.setPosition(root.x - halfWidth, root.y - halfWidth - length);
      break;
    case S:
      rectangle.setSize(sf::Vector2f(width, length));
      circle.setPosition(root.x - halfWidth, root.y - halfWidth + length);
      break;
    case E:
      rectangle.setSize(sf::Vector2f(length, -width));
      circle.setPosition(root.x - halfWidth + length, root.y - halfWidth);
      break;
    case W:
      rectangle.setSize(sf::Vector2f(-length, -width));
      circle.setPosition(root.x - halfWidth - length, root.y - halfWidth);
      break;
  }
}

void slitherling::Snake::Segment::draw(sf::RenderTarget &target, sf::RenderStates) const {
  target.draw(rectangle);
  target.draw(circle);
}

slitherling::Snake::Snake(sf::Sound &growthSound, sf::Sound &infectSound) : growthSound(growthSound), infectSound(infectSound) {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;
  speed = screenPixelWidth / 10; // initial speed 10 seconds to traverse screen;
  segments.resize(1);
}

bool slitherling::Snake::containsPoint(const sf::Vector2f &posn) const {
  for (auto &segment : segments) {
    if (segment.containsPoint(posn)) return true;
  }

  return false;
}

void slitherling::Snake::Segment::updateColor(float energy) {
  int colorComponent = 255.0f * energy / 100;
  rectangle.setFillColor(sf::Color(colorComponent, colorComponent, colorComponent, 255));
  circle.setFillColor(sf::Color(colorComponent, colorComponent, colorComponent, 255));
}

void slitherling::Snake::absorbParasite() {
  energy -= 10;
  playInfectSound();
  for (Segment &segment : segments) {
    segment.updateColor(energy);
    segment.updateColor(energy);
  }
}

int slitherling::Snake::getSpeed() {
  return speed;
}

void slitherling::Snake::grow() {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;
  storedGrowth += screenPixelWidth / initialLengthScreenWidthFraction;
  playGrowthSound();
}

void slitherling::Snake::playInfectSound() {
  infectSound.play();
}

void slitherling::Snake::playGrowthSound() {
  growthSound.play();
}

void slitherling::Snake::slither(float cycleElapsedSeconds) {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;
  static const float screenPixelHeight = sf::VideoMode::getFullscreenModes()[0].height;

  float distance = speed * cycleElapsedSeconds;
  Segment &head = segments.front();
  head.extend(distance);
  head.updateDrawnEntities();

  float screenOvershoot = -1.f;
  switch (head.d) {
    case Direction::E:
      screenOvershoot = std::max(0.0f, head.root.x + head.length - screenPixelWidth);
      break;
    case Direction::S:
      screenOvershoot = std::max(0.0f, head.root.y + head.length - screenPixelHeight);
      break;
    case Direction::W:
      screenOvershoot = std::max(0.0f, head.length - head.root.x);
      break;
    case Direction::N:
      screenOvershoot = std::max(0.0f, head.length - head.root.y);
      break;
  }

  if (screenOvershoot > 0) {
    segments.emplace(segments.begin());
    Segment &head = segments.front();
    Segment &neck = segments.at(1);

    head.d = neck.d;
    head.width = neck.width;
    head.length = screenOvershoot;
    switch (head.d) {
      case Direction::E:
        head.root.x = 0;
        head.root.y = neck.root.y;
        break;
      case Direction::S:
        head.root.x = neck.root.x;
        head.root.y = 0;
        break;
      case Direction::W:
        head.root.x = screenPixelWidth;
        head.root.y = neck.root.y;
        break;
      case Direction::N:
        head.root.x = neck.root.x;
        head.root.y = screenPixelHeight;
        break;
    }

    head.updateDrawnEntities();
    neck.updateDrawnEntities();
    head.updateColor(energy);
  }

  if (storedGrowth > distance) {
    storedGrowth -= distance;
  } else {
    segments.back().retract(distance - storedGrowth);
    storedGrowth = 0;
  }

  while (segments.back().length <= 0) {
    float retractionRemaining = segments.back().length;
    segments.pop_back();
    segments.back().retract(-retractionRemaining);
  }

  segments.back().updateDrawnEntities();
}

void slitherling::Snake::changeDirection(Direction d) {
  Segment &oldHead = segments.front();
  sf::Vector2f oldTipPosn{tipPosn()};

  switch (oldHead.d) {
    case Direction::E :
    case Direction::W :
      if (d == Direction::E || d == Direction::W) return;
      break;
    case Direction::N :
    case Direction::S :
      if (d == Direction::N || d == Direction::S) return;
      break;
  }

  segments.emplace(segments.begin());
  Segment &newHead = segments[0];

  newHead.d = d;
  newHead.length = 0;
  newHead.width = oldHead.width;
  newHead.root.x = oldTipPosn.x;
  newHead.root.y = oldTipPosn.y;
  newHead.updateColor(energy);
}

void slitherling::Snake::draw(sf::RenderTarget &target, sf::RenderStates rs) const {
  for (auto segment : segments) {
    segment.draw(target, rs);
  }
}

slitherling::Parasite::Parasite(sf::Vector2f startPosn, float totalElapsedSeconds) {
  directions = std::vector<Direction>{
    Direction::E,
    Direction::S,
    Direction::W,
    Direction::N
  };

  int prohibitedDir = std::rand()/((RAND_MAX + 1u)/4);

  directions.erase(directions.begin() + prohibitedDir);

  posn = startPosn;
  deathSecond = totalElapsedSeconds + secondsToLive;
  circle = sf::CircleShape(size);

  char* rainbowEnv = std::getenv("SLITHERLING_RAINBOW_PARASITES");
  if (rainbowEnv != nullptr) {
    circle.setFillColor(sf::Color(
      std::rand()/((RAND_MAX + 1u)/256),
      std::rand()/((RAND_MAX + 1u)/256),
      std::rand()/((RAND_MAX + 1u)/256),
    255));
  }

  circle.setPosition(startPosn);
}

bool slitherling::Parasite::shouldDie(float totalElapsedSeconds) {
  return deathSecond <= totalElapsedSeconds;
}

void slitherling::Parasite::update(float cycleElapsedSeconds) {
  static const float screenPixelWidth = sf::VideoMode::getFullscreenModes()[0].width;
  static const float screenPixelHeight = sf::VideoMode::getFullscreenModes()[0].height;

  float distance = speed * cycleElapsedSeconds;
  int randDir = 1 + std::rand()/((RAND_MAX + 1u)/3);

  Direction d = directions[randDir];
  if (d == prevDir) return;

  float screenOvershoot = -1.f;
  switch (d) {
    case Direction::E:
      posn.x += distance;
      screenOvershoot = std::max(0.0f, posn.x - screenPixelWidth);
      break;
    case Direction::S:
      posn.y += distance;
      screenOvershoot = std::max(0.0f, posn.y - screenPixelHeight);
      break;
    case Direction::W:
      posn.x -= distance;
      screenOvershoot = std::max(0.0f, -posn.x);
      break;
    case Direction::N:
      posn.y -= distance;
      screenOvershoot = std::max(0.0f, -posn.y);
      break;
  }

  if (screenOvershoot > 0) {
    switch (d) {
      case Direction::E:
        posn.x = screenOvershoot;
        break;
      case Direction::S:
        posn.y = screenOvershoot;
        break;
      case Direction::W:
        posn.x = screenPixelWidth - screenOvershoot;
        break;
      case Direction::N:
        posn.y = screenPixelHeight - screenOvershoot;
        break;
    }
  }

  circle.setPosition(posn);
}

void slitherling::Parasite::draw(sf::RenderTarget &target, sf::RenderStates) const {
  target.draw(circle);
}

int main() {
  slitherling::GameState gs{};
  slitherling::start(gs);
  return 0;
}
