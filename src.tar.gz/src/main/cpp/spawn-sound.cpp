#include "spawn-sound.h"
#include "path-finder.h"

slitherling::SpawnSound::SpawnSound() {
  soundPath = findPathTo("spawn.wav");
  if (!soundPath.empty()) {
    buffer.loadFromFile(soundPath / "spawn.wav");
    sound.setBuffer(buffer);
  }
}

sf::Sound& slitherling::SpawnSound::get() {
  return sound;
}
