#include "gulp-sound.h"
#include "path-finder.h"

slitherling::GulpSound::GulpSound() {
  soundPath = findPathTo("gulp.wav");
  if (!soundPath.empty()) {
    buffer.loadFromFile(soundPath / "gulp.wav");
    sound.setBuffer(buffer);
  }
}

sf::Sound& slitherling::GulpSound::get() {
  return sound;
}
