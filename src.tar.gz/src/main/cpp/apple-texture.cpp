#include "apple-texture.h"
#include "path-finder.h"

slitherling::AppleTexture::AppleTexture() {
  texturePath = findPathTo("apple.png");
  if (!texturePath.empty()) texture.loadFromFile(texturePath / "apple.png");
}

const sf::Texture& slitherling::AppleTexture::get() const {
  return texture;
}
