#pragma once
#include <filesystem>

namespace slitherling {
  std::filesystem::path findPathTo(std::string filename);
}
