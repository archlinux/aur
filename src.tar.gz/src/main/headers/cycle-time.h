#pragma once
#include <SFML/Graphics.hpp>
#include <filesystem>
namespace slitherling {
  class CycleTime {
    private:
      sf::Clock clock;
      sf::Time cycleTime;
      sf::Time totalTime;

    public:
      void mark();
      float cycleElapsedSeconds() const;
      float totalElapsedSeconds() const;
  };
}
