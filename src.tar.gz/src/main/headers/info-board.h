#pragma once
#include <SFML/Graphics.hpp>
#include <map>
#include <string>
#include <sstream>
#include <utility>
#include "cycle-time.h"

namespace slitherling {
  class InfoBoard : public sf::Drawable {
    private:
      const CycleTime& ct;
      sf::Text text;
      std::vector<std::pair<std::string, float>> items;

      virtual void draw(sf::RenderTarget&, sf::RenderStates) const;
      void refresh(const std::stringstream &displayText);

    public:
      InfoBoard(const sf::Font& font, const CycleTime& ct);
      void appendItem(std::string, float removalSecond);
      void removeExpired();
  };
}
