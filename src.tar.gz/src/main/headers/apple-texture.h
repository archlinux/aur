#pragma once
#include <filesystem>
#include <SFML/Graphics.hpp>

namespace slitherling {
  class AppleTexture {
    private:
      std::filesystem::path texturePath;
      sf::Texture texture;

    public:
      AppleTexture();
      const sf::Texture& get() const;
  };
}
