#pragma once
#include <filesystem>
#include <fstream>
#include <sstream>

namespace slitherling {
  class VersionProvider {
    public:
      static std::string getVersion();
  };
}
