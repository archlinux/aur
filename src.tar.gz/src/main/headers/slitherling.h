#pragma once
#include <SFML/Graphics.hpp>
#include "cycle-time.h"
#include "font-provider.h"
#include "version-provider.h"
#include "info-board.h"
#include "apple-texture.h"
#include "gulp-sound.h"
#include "infect-sound.h"
#include "spawn-sound.h"
#include <thread>
#include <chrono>
#include <limits>
namespace slitherling {
  enum Direction {E, S, W, N};

  class Snake : public sf::Drawable {
    public:
      sf::Sound &growthSound;
      sf::Sound &infectSound;
      float energy = 100;
      Direction direction() const;
      void reset();
      int getSpeed();
      void playGrowthSound();
      void playInfectSound();
      bool isDead() const;
      sf::Vector2f tipPosn() const;

      Snake(sf::Sound &growthSound, sf::Sound &infectSound);
      void absorbParasite();
      bool containsPoint(const sf::Vector2f &posn) const;

    private:
      const static int initialLengthScreenWidthFraction = 50;
      int speed; // pixels per second
      float storedGrowth = 0;
      virtual void draw(sf::RenderTarget&, sf::RenderStates) const;
      void slither(float cycleElapsedSeconds);
      void changeDirection(Direction);
      void grow();
      friend class GameState;
      friend class GameStateReport;

      class Segment : public sf::Drawable {
        private:
          sf::Vector2f root;
          Direction d;
          sf::RectangleShape rectangle;
          sf::CircleShape circle;
          float halfWidth;
          float width;
          float length;
          bool containsPoint(const sf::Vector2f &point) const;
          virtual void draw(sf::RenderTarget&, sf::RenderStates) const;
          friend class Snake;

        public:
          Segment();
          void updateColor(float energy);
          sf::Vector2f getRoot() const;
          Direction getDirection() const;
          float getLength() const;
          void extend(float distance);
          void retract(float distance);
          void updateDrawnEntities();
      };

      std::vector<Segment> segments;
  };

  class Fruit: public sf::Drawable {
    private:
      sf::Vector2f posn;
      sf::Sprite sprite;
      sf::FloatRect bounds;
      sf::Sound sound;
      float rotSecond;
      float secondsToRot = 20;
      virtual void draw(sf::RenderTarget&, sf::RenderStates) const;
      friend class GameState;

    public:
      Fruit(const sf::Texture &AppleTexture, float totalElapsedSeconds);
      bool isBeingEaten(const Snake&) const;
      bool isRotten(float totalElapsedSeconds) const;
      void updateColor(float totalElapsedSeconds);
      sf::Vector2f getPosn() const;
  };

  struct GameStateReport {
    Snake s;
    std::vector<Fruit> fruits;
    GameStateReport(Snake, std::vector<Fruit>);
    std::vector<Snake::Segment> getSegments() const;
  };

  class Parasite : public sf::Drawable {
    private:
      sf::Vector2f posn;
      float speed = 40;
      float size = 5;
      float secondsToLive = 60;
      float deathSecond;
      Direction prevDir;
      std::vector<Direction> directions;
      sf::CircleShape circle;
      virtual void draw(sf::RenderTarget&, sf::RenderStates) const;
      friend class GameState;

    public:
      bool shouldDie(float totalElapsedSeconds);
      Parasite(sf::Vector2f startPosn, float totalElapsedSeconds);
      void update(float cycleElapsedSeconds);
  };

  class GameState : public sf::Drawable {
    private:
      GulpSound gulpSound;
      SpawnSound spawnSound;
      InfectSound infectSound;
      Snake s;
      std::vector<Fruit> fruits;
      std::vector<Parasite> parasites;
      AppleTexture appleTexture;
      virtual void draw(sf::RenderTarget&, sf::RenderStates) const;

    public:
      GameState();
      GameStateReport report();
      void draw(sf::RenderWindow&);
      void update(float cycleElapsedSeconds, float totalElapsedSeconds);
      sf::Vector2f nearestFruitPosn(Snake) const;
      sf::Vector2f centerScreen() const;
      void reset();
      bool endState() const;
      void directionChange(Direction);
      void directionChangeAuto();
      int snakeLength();
  };

  void start(GameState);
}
