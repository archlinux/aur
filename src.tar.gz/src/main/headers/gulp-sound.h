#pragma once
#include <filesystem>
#include <SFML/Audio.hpp>

namespace slitherling {
  class GulpSound {
    private:
      std::filesystem::path soundPath;
      sf::Sound sound;
      sf::SoundBuffer buffer;

    public:
      GulpSound();
      sf::Sound& get();
  };
}
