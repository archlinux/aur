#pragma once
#include <filesystem>
#include <SFML/Graphics.hpp>

namespace slitherling {
  class FontProvider {
    private:
      std::filesystem::path fontPath;
      sf::Font font;

    public:
      FontProvider();
      sf::Font& getFont();
  };
}
