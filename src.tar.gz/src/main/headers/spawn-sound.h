#pragma once
#include <filesystem>
#include <SFML/Audio.hpp>

namespace slitherling {
  class SpawnSound {
    private:
      std::filesystem::path soundPath;
      sf::Sound sound;
      sf::SoundBuffer buffer;

    public:
      SpawnSound();
      sf::Sound& get();
  };
}
