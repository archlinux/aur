#include "slitherling.h"

int main() {
  slitherling::GameState gs{};
  slitherling::start(gs);
  return 0;
}
