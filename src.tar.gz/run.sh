#!/usr/bin/env bash
PATH="$PATH:/home/$(whoami)/.local/bin"
# for twisted installed by pipx
# SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
SCRIPT_DIR="/usr/lib/canokey-console-legacy/"
cd /tmp # for PID file
# see twisted/internet/endpoints.py -> serverFromString for listen config
twistd --pidfile /tmp/console-legacy.canokeys.org.pid -n web --path "$SCRIPT_DIR" --listen=tcp:31098:interface=127.0.0.1
