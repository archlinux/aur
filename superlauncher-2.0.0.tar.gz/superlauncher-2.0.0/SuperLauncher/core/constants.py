CURRENT_VERSION = "v2.0.0_2026"
MODRINTH_API = "https://api.modrinth.com/v2"
CURSEFORGE_API = "https://api.curseforge.com/v1"

CONFIG_FILE = "settings.json"
ACCOUNTS_FILE = "accounts.json"
LICENSES_FILE = "licenses.json"
SERVERS_FILE = "servers_list.json"

APP_NAME = "SuperLauncher"
ORG_NAME = "SuperLauncher"
