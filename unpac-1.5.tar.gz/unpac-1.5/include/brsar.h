#pragma once

#include "estream.h"

class Brsar {
public:
    int Main(const std::string& filename);
private:
    estream in;
};
