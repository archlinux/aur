#!/bin/bash

pkgdir="$1"

create_dirs() {
  mkdir -p "$pkgdir/usr/bin" || exit 1
  mkdir -p "$pkgdir/etc/systemd/user" || exit 1
}

copy_files() {
  install checkupdates-notify "$pkgdir/usr/bin/" || exit 1
  cp checkupdates-notify.service checkupdates-notify.timer "$pkgdir/etc/systemd/user/" || exit 1
}

create_dirs
copy_files

exit
