#pragma once
#include <stdbool.h>

int cmd_clear_check(const char *input);
bool cmd_clear_exec(char *input, int code);
