#ifndef SCP_VERSION
#define SCP_VERSION

#define SCP_VERSION_MAJOR "2"
#define SCP_VERSION_MINOR "2"
#define SCP_VERSION_PATCH "0"
#define SCP_VERSION_TWEAK ""

#define SCP_DATA_DIRECTORY_DEV "/personal/Projects/Applications/CPP/scolorpicker/data"
#define SCP_DATA_DIRECTORY_REL "/usr/local/share/scolorpicker"

/* #undef SCP_ENABLE_X11 */
/* #undef SCP_ENABLE_XLIB */
/* #undef SCP_ENABLE_XCB */
#define SCP_ENABLE_WAYLAND
/* #undef SCP_ENABLE_LINUX */

#endif // SCP_VERSION
