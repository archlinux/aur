#include "src/ui/main-window.hpp"
#include "ui_main-window.h"

#include <QCoreApplication>
#include <QMessageBox>
#include <QCheckBox>
#include "src/ui/icons.hpp"
#include "src/ui/rom-list-model.hpp"
#include "src/ui/rom-source-dialog.hpp"
#include "src/ui/settings-dialog.hpp"
#include "src/ui/controller-select-dialog.hpp"
#include "src/ui/keyboard-config-dialog.hpp"
#include "src/ui/process-awaiter.hpp"
#include "src/ui/now-playing-window.hpp"
#include "src/ui/singleplayer-controller-select-dialog.hpp"
#include "src/ui/multiplayer-controller-select-dialog.hpp"
#include "src/ui/save-file-editor-dialog.hpp"
#include "src/ui/save-slot-editor-dialog.hpp"
#include "src/ui/core-installer.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/rom-finder.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/rom.hpp"
#include "src/core/preset-controllers.hpp"
#include "src/core/bps.hpp"
#include "src/core/version.hpp"
#include "src/core/time.hpp"
#include "src/input/gamepad-controller.hpp"
#include "src/db/data-provider.hpp"

MainWindow::MainWindow() :
	QMainWindow( nullptr ),
	m_ui( new Ui::MainWindow ),
	m_showAllPlugins( false ),
	m_settings( FileController::loadAppSettings() ),
	m_exists( new bool( true ) )
{
	m_ui->setupUi( this );
	setWindowIcon( Icon::appIcon() );

	m_ui->titleLabel->setText( QString(
		( "Parallel Launcher v"s + CurrentVersion::Application.toString() ).c_str()
	));

	m_ui->pluginAngrylionRadio->setVisible( false );
	m_ui->pluginGlidenRadio->setVisible( false );
	m_ui->pluginRiceRadio->setVisible( false );
	m_ui->pluginWarningLabel->setVisible( false );

	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginParallelRadio, (int)GfxPlugin::ParaLLEl );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlideRadio, (int)GfxPlugin::Glide64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginAngrylionRadio, (int)GfxPlugin::Angrylion );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginGlidenRadio, (int)GfxPlugin::GlideN64 );
	m_ui->parallelPluginRadioGroup->setId( m_ui->pluginRiceRadio, (int)GfxPlugin::Rice );

	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginParallelRadio2, (int)GfxPlugin::ParaLLEl );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginAngrylionRadio2, (int)GfxPlugin::Angrylion );
	m_ui->mupenPluginRadioGroup->setId( m_ui->pluginGlidenRadio2, (int)GfxPlugin::GlideN64 );

	m_ui->controllerConfigButton->setIcon( Icon::gamepad() );
	m_ui->menuButton->setIcon( Icon::menu() );
	m_ui->refreshButton->setIcon( Icon::refresh() );
	m_ui->playSingleplayerButton->setIcon( Icon::play() );
	m_ui->playMultiplayerButton->setIcon( Icon::group() );

	const UiState uiState = FileController::loadUiState();
	m_ui->romList->refetchAll();
	m_ui->romList->restoreTreeState( uiState.romList );
	m_ui->romView->setCurrentIndex( m_ui->romList->hasRoms() ? 1 : 0 );
		
	m_ui->actionSettings->setIcon( Icon::configure() );
	m_ui->actionManageSources->setIcon( Icon::search() );
	m_ui->actionConfigureControllers->setIcon( Icon::gamepad() );
	m_ui->actionConfigureKeyboard->setIcon( Icon::keyboard() );

	m_ui->menuButton->addAction( m_ui->actionSettings );
	m_ui->menuButton->addAction( m_ui->actionManageSources );
	m_ui->menuButton->addAction( m_ui->actionConfigureControllers );
	m_ui->menuButton->addAction( m_ui->actionConfigureKeyboard );

	resize( uiState.windowWidth, uiState.windowHeight );

	if( uiState.showAllPlugins ) {
		morePluginsToggled();
	}

	connect( m_ui->refreshButton, SIGNAL(clicked()), this, SLOT(refreshRomList()) );
	connect( m_ui->romList->selectionModel(), SIGNAL(currentChanged(const QModelIndex&, const QModelIndex&)), this, SLOT(romSelectionChanged()) );
	connect( m_ui->parallelPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(parallelPluginChanged(int,bool)) );
	connect( m_ui->mupenPluginRadioGroup, SIGNAL(buttonToggled(int,bool)), this, SLOT(mupenPluginChanged(int,bool)) );
	connect( m_ui->romList, SIGNAL(editSave(fs::path)), this, SLOT(editSave(fs::path)) );
	connect( m_ui->romList, SIGNAL(launchRom()), this, SLOT(playSingleplayer()) );

	reloadSettings();
	romSelectionChanged();

	refreshRomList();
}

MainWindow::~MainWindow() {
	m_ui->romList->model()->deleteLater();
	delete m_ui;
}

void MainWindow::reloadSettings() {
	m_settings = FileController::loadAppSettings();

	m_ui->romList->setColumnHidden( 0, false );
	m_ui->romList->setColumnHidden( 1, !Flags::has( m_settings.visibleColumns, RomInfoColumn::InternalName ) );
	m_ui->romList->setColumnHidden( 2, !Flags::has( m_settings.visibleColumns, RomInfoColumn::Path ) );
	m_ui->romList->setColumnHidden( 3, !Flags::has( m_settings.visibleColumns, RomInfoColumn::LastPlayed ) );
	m_ui->romList->setColumnHidden( 4, !Flags::has( m_settings.visibleColumns, RomInfoColumn::PlayTime ) );
	m_ui->romList->setColumnHidden( 5, !Flags::has( m_settings.visibleColumns, RomInfoColumn::Notes ) );
}

void MainWindow::refreshRomList() {
	m_romSearch.cancel();
	m_ui->searchIndicator->setVisible( true );
	std::shared_ptr<bool> windowExists = m_exists;
	m_romSearch = RomFinder::scanAsync( [this,windowExists](RomFinder::SearchResults result){
		if( !*windowExists ) return;
		switch( result ) {
			case RomFinder::SearchResults::Updated:
				this->m_ui->romList->refetchAll();
				this->m_ui->romView->setCurrentIndex( this->m_ui->romList->hasRoms() ? 1 : 0 );
				[[fallthrough]];
			case RomFinder::SearchResults::NoChanges:
				this->m_ui->searchIndicator->setVisible( false );
				break;
			default: break;
		}
	});
}

void MainWindow::romSelectionChanged() {
	const RomInfo *rom = m_ui->romList->tryGetSelectedRom().info;
	const bool romSelected = (rom != nullptr);

	m_ui->overclockCpuCheckbox->setEnabled( romSelected );
	m_ui->overclockViCheckbox->setEnabled( romSelected );
	m_ui->widescreenCheckbox->setEnabled( romSelected );
	m_ui->pluginGroup->setEnabled( romSelected );
	m_ui->mupenPluginGroup->setEnabled( romSelected );
	m_ui->playSingleplayerButton->setEnabled( romSelected );
	m_ui->playMultiplayerButton->setEnabled( romSelected );
	m_ui->inputModeSelect->setEnabled( romSelected );

	if( romSelected ) {
		const EmulatorCore emulatorCore = (rom->emulator == EmulatorCore::UseDefault) ? m_settings.defaultEmulator : rom->emulator;
		const GfxPlugin parallelPlugin = (rom->parallelPlugin == GfxPlugin::UseDefault) ? m_settings.defaultParallelPlugin : rom->parallelPlugin;
		const GfxPlugin mupenPlugin = (rom->mupenPlugin == GfxPlugin::UseDefault) ? m_settings.defaultMupenPlugin : rom->mupenPlugin;
		m_ui->overclockCpuCheckbox->setChecked( rom->overclockCPU );
		m_ui->overclockViCheckbox->setChecked( rom->overclockVI );
		m_ui->widescreenCheckbox->setChecked( rom->widescreen );
		m_ui->parallelPluginRadioGroup->button( (int)parallelPlugin )->setChecked( true );
		m_ui->mupenPluginRadioGroup->button( (int)mupenPlugin )->setChecked( true );
		m_ui->emulatorTabs->setCurrentIndex( (int)emulatorCore - 1 );
		m_ui->inputModeSelect->setSelected( rom->inputModeId );

		m_ui->pluginWarningLabel->setVisible(
			emulatorCore == EmulatorCore::ParallelN64 &&
			parallelPlugin == GfxPlugin::GlideN64
		);
	}

	overclockCpuToggled();
	overclockViToggled();
}

void MainWindow::overclockCpuToggled() {
	const bool optimizationsDisabled = m_ui->overclockCpuCheckbox->isEnabled() && !m_ui->overclockCpuCheckbox->isChecked();
	m_ui->performanceWarningLabel->setVisible( optimizationsDisabled );

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockCPU = m_ui->overclockCpuCheckbox->isChecked();
	DataProvider::updateRomCpuOverclocking( romInfo->sha1, romInfo->overclockCPU );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::overclockViToggled() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->overclockVI = m_ui->overclockViCheckbox->isChecked();
	DataProvider::updateRomViOverclocking( romInfo->sha1, romInfo->overclockVI );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::widescreenToggled() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->widescreen = m_ui->widescreenCheckbox->isChecked();
	DataProvider::updateRomWidescreen( romInfo->sha1, romInfo->widescreen );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::parallelPluginChanged( int pluginId, bool checked ) {
	if( !checked ) return;
	const GfxPlugin plugin = (GfxPlugin)pluginId;

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->parallelPlugin == plugin ) return;

	romInfo->parallelPlugin = plugin;
	DataProvider::updateRomParallelPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );

	m_ui->pluginWarningLabel->setVisible( plugin == GfxPlugin::GlideN64 );
}

void MainWindow::mupenPluginChanged( int pluginId, bool checked ) {
	if( !checked ) return;
	const GfxPlugin plugin = (GfxPlugin)pluginId;

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr || romInfo->mupenPlugin == plugin ) return;

	romInfo->mupenPlugin = plugin;
	DataProvider::updateRomMupenPlugin( romInfo->sha1, plugin );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::inputModeChanged() {
	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->inputModeId = m_ui->inputModeSelect->getSelected().id;
	DataProvider::updateRomInputMode( romInfo->sha1, romInfo->inputModeId );
	m_ui->romList->updateRomInfo( *romInfo, false, false );
}

void MainWindow::emulatorChanged() {
	const EmulatorCore emulator = (EmulatorCore)(m_ui->emulatorTabs->currentIndex() + 1);
	assert( emulator == EmulatorCore::ParallelN64 || emulator == EmulatorCore::Mupen64plusNext );

	RomInfo *romInfo = m_ui->romList->tryGetSelectedRom().info;
	if( romInfo == nullptr ) return;

	romInfo->emulator = emulator;
	DataProvider::updateRomEmulator( romInfo->sha1, emulator );
	m_ui->romList->updateRomInfo( *romInfo, false, false );

	m_ui->pluginWarningLabel->setVisible(
		emulator == EmulatorCore::ParallelN64 &&
		m_ui->pluginGlidenRadio->isChecked()
	);
}

void MainWindow::morePluginsToggled() {
	m_showAllPlugins = !m_showAllPlugins;
	m_ui->pluginAngrylionRadio->setVisible( m_showAllPlugins );
	m_ui->pluginGlidenRadio->setVisible( m_showAllPlugins );
	m_ui->pluginRiceRadio->setVisible( m_showAllPlugins );
	m_ui->showMorePluginsLinks->setText( m_showAllPlugins ?
		"<a href=\"#\">Show Fewer Plugins</a>" :
		"<a href=\"#\">Show More Plugins</a>"
	);
}

static const char *s_crashMessageParallel = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. Alternatively, if you have a very old onboard graphics card, it is possible that Vulkan is not "
	"supported on your system. In either case, using another graphics plugin might resolve the issue.";

static const char *s_crashMessageAngrylion = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM may contain invalid or unsafe RSP microcode that cannot be run on console accurate graphics "
	"plugins. If this is the case, try running the ROM with another graphics plugin instead.";

static const char *s_crashMessageDefault = ""
	"The emulator exited shortly after launching. If you are able to launch other ROMs without issues, then "
	"this ROM is most likely corrupt.";

static inline ConnectedGamepad getActiveController( AppSettings &settings ) {
	std::vector<ConnectedGamepad> connectedControllers = GamepadController::instance().getConnected();
	if( connectedControllers.empty() ) {
		return ConnectedGamepad{ -1, ControllerInfo() };
	} else if( connectedControllers.size() == 1 ) {
		return connectedControllers[0];
	}

	if( settings.preferredController.has_value() ) {
		for( const ConnectedGamepad &controller : connectedControllers ) {
			if( controller.info.uuid == settings.preferredController.value() ) {
				return controller;
			}
		}
	}

	SingleplayerControllerSelectDialog dialog( connectedControllers );
	dialog.exec();
	return dialog.getSelectedController();
}

static inline ControllerProfile getControllerProfile( const ConnectedGamepad &controller ) {
	if( controller.id < 0 ) {
		return DefaultProfile::XBox360;
	}

	const HashMap<Uuid,string> mappings = FileController::loadControllerMappings();
	if( mappings.count( controller.info.uuid ) > 0 ) {
		const string &activeProfile = mappings.at( controller.info.uuid );

		const std::map<string, ControllerProfile> profiles = FileController::loadControllerProfiles();
		if( profiles.count( activeProfile ) > 0 ) {
			return profiles.at( activeProfile );
		}
	}

	switch( getControllerType( controller.info.controllerId ) ) {
		case ControllerType::Gamecube:
			return DefaultProfile::Gamecube;
		case ControllerType::Nintendo64:
			return DefaultProfile::Nintendo64;
		default:
			return DefaultProfile::XBox360;
	}
}

void MainWindow::playSingleplayer() {
	const ConnectedGamepad activeController = getActiveController( m_settings );
	const std::vector<PlayerController> players = {
		{ getControllerProfile( activeController ), activeController.info.uuid }
	};
	launchEmulator( m_ui->romList->tryGetSelectedRom(), players, true );
}

void MainWindow::playMultiplayer() {
	MultiplayerControllerSelectDialog dialog( m_ui->inputModeSelect->getSelected().usesTwoPorts() );
	if( dialog.exec() != QDialog::Accepted ) return;

	const std::array<ConnectedGamepad,4> controllers = dialog.getControllers();
	std::vector<PlayerController> players;
	players.reserve( 4 );

	for( size_t i = 0; i < 4; i++ ) {
		if( controllers[i].id < 0 ) continue;

		while( i > players.size() ) players.push_back({ DefaultProfile::XBox360, Uuid() });
		players.push_back({ getControllerProfile( controllers[i] ), controllers[i].info.uuid });
	}

	if( players.empty() ) {
		players.push_back({ DefaultProfile::XBox360, 0 });
	}

	launchEmulator( m_ui->romList->tryGetSelectedRom(), players, dialog.canBindSavestates() );
}

void MainWindow::launchEmulator(
	const RomReference &rom,
	const std::vector<PlayerController> &players,
	bool bindSavestate
) {
	if( rom.file == nullptr ) return;

	const EmulatorCore emulatorCore = (rom.info->emulator == EmulatorCore::UseDefault) ? m_settings.defaultEmulator : rom.info->emulator;
	if( !CoreInstaller::requireCore( emulatorCore ) ) return;

	GfxPlugin gfxPlugin;
	AsyncProcess *emulator = new AsyncProcess();
	try {
		*emulator = RetroArch::launchRom(
			rom.file->path,
			m_settings,
			players,
			*rom.info,
			bindSavestate,
			&gfxPlugin
		);
	} catch( ... ) {
		QMessageBox::critical( this, "Emulator Missing", "Failed to launch emulator. It does not appear to be installed." );
		return;
	}

	const QRect winGeo = geometry();
	hide();

	NowPlayingWindow *nowPlayingWindow = nullptr;
	if( !m_settings.hideWhenPlaying ) {
		nowPlayingWindow = new NowPlayingWindow( emulator, rom.info->name, rom.info->playTime );
		nowPlayingWindow->show();
	}

	const string sha1 = rom.file->sha1;
	std::shared_ptr<bool> windowExists = m_exists;
	ProcessAwaiter::QtSafeAwait(
		emulator,
		[=]( [[maybe_unused]] int64 exitCode, int64 runtimeMs ) {
			delete emulator;
			if( nowPlayingWindow != nullptr ) {
				nowPlayingWindow->close();
				nowPlayingWindow->deleteLater();
			}

			if( runtimeMs > 0 ) {
				RomInfo romInfo;
				if( DataProvider::tryFetchRomByHash( sha1, true, &romInfo ) ) {
					romInfo.lastPlayed = Time::nowMs();
					romInfo.playTime += runtimeMs;
					DataProvider::updatePlayTime( sha1, romInfo.lastPlayed, romInfo.playTime );
					if( *windowExists ) {
						this->m_ui->romList->updateRomInfo( romInfo, false, true );
					}
				}
			}

			this->setGeometry( winGeo );
			this->show();
			QTimer::singleShot( 50, [=](){ this->setGeometry( winGeo ); } );

			if( runtimeMs < 2000 ) {
				const char *errorMessage;
				switch( gfxPlugin ) {
					case GfxPlugin::ParaLLEl:
						errorMessage = s_crashMessageParallel;
						break;
					case GfxPlugin::Angrylion:
						errorMessage = s_crashMessageAngrylion;
						break;
					default:
						errorMessage = s_crashMessageDefault;
						break;
				}
				QMessageBox::critical( this, "Possible ROM Error", errorMessage );
			}
		}
	);
}

void MainWindow::configureController() {
	ControllerSelectDialog dialog;
	dialog.exec();
}

void MainWindow::configureKeyboard() {
	KeyboardConfigDialog dialog;
	dialog.exec();
}

void MainWindow::editSettings() {
	SettingsDialog *dialog = new SettingsDialog();
	dialog->exec();
	delete dialog;
	reloadSettings();
}

void MainWindow::manageRomSources() {
	RomSourceDialog *dialog = new RomSourceDialog();
	dialog->exec();
	delete dialog;
	m_ui->romList->refetchAll();
	refreshRomList();
}

void MainWindow::closeEvent( QCloseEvent *event ) {
	const UiState uiState = {
		m_ui->romList->saveTreeState(),
		width(),
		height(),
		m_ui->pluginRiceRadio->isVisible()
	};

	FileController::saveUiState( uiState );
	QMainWindow::closeEvent( event );
	QCoreApplication::quit();
}

void MainWindow::editSave( fs::path saveFilePath ) {
	SaveFileEditorDialog dialog( saveFilePath );
	if( dialog.exec() == QDialog::Accepted ) {
		SaveSlotEditorDialog dialog2( saveFilePath, dialog.getSaveSlot() );
		dialog2.exec();
	}
}
