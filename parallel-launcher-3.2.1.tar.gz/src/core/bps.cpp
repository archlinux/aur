#include "src/core/bps.hpp"

#include "src/core/buffer.hpp"
#include "src/core/file-controller.hpp"
#include "src/thirdparty/libbps.h"
#include "src/polyfill/base-directory.hpp"
#include "src/db/data-provider.hpp"
#include <fstream>
#include <cstring>
#include <ios>

class BpsFile : public file {

	private:
	const size_t m_fileSize;
	std::ifstream m_file;
	#ifdef _WIN32
	char *m_buffer;
	#endif

	public:
	BpsFile( const fs::path &bpsPath ) : m_fileSize( (size_t)fs::file_size( bpsPath ) ) {
		m_file = std::ifstream( bpsPath, std::ios_base::in | std::ios_base::binary );
#ifdef _WIN32
		m_buffer = new char[8192];
		m_file.rdbuf()->pubsetbuf( m_buffer, 8192 );
#endif
	}

	~BpsFile() {
#ifdef _WIN32
		m_file.rdbuf()->pubsetbuf( nullptr, 0 );
		delete[] m_buffer;
#endif
	}

	size_t len() override { return m_fileSize; }

	bool read( uint8_t* target, size_t start, size_t len ) override {
		m_file.seekg( start );
		m_file.read( (char*)target, len );
		return m_file.good();
	}
};

static bool isBpsFile( const fs::path &bpsPath ) {
	std::ifstream bpsFile( bpsPath, std::ios_base::in | std::ios_base::binary );

	char fileHeader[4];
	bpsFile.read( fileHeader, 4 );
	return bpsFile.good() && std::strncmp( fileHeader, "BPS1", 4 ) == 0;
}

static Bps::BpsApplyError applyBps(
	const fs::path &bpsPath,
	const fs::path &baseRomPath,
	BpsFile &bpsFile,
	const bpsinfo &bpsInfo,
	fs::path &patchedRomPath
) {
	if ( bpsInfo.error != bpserror::bps_ok ) {
		return Bps::BpsApplyError::InvalidBps;
	}

	const size_t baseRomSize = (size_t)fs::file_size( baseRomPath );
	Buffer patchData( bpsFile.len() );
	bpsFile.read( patchData.udata(), 0, bpsFile.len() );

	Buffer baseRomData( baseRomSize );
	{
		std::ifstream baseRom( baseRomPath, std::ios_base::in | std::ios_base::binary );
		baseRom.read( (char*)baseRomData.data(), baseRomSize );
	}

	mem patchMem, baseRomMem, patchedRomMem;
	patchMem.ptr = patchData.udata();
	patchMem.len = bpsFile.len();
	baseRomMem.ptr = baseRomData.udata();
	baseRomMem.len = baseRomSize;

	bpserror result = bps_apply( patchMem, baseRomMem, &patchedRomMem, nullptr, false );
	CBuffer patchedRomData( patchedRomMem.ptr ); // Take ownership of pointer

	if ( result != bpserror::bps_ok ) {
		return Bps::BpsApplyError::PatchFailed;
	}

	const AppSettings &settings = FileController::loadAppSettings();
	if( settings.patchToSameFolder ) {
		patchedRomPath = bpsPath;
	} else {
		patchedRomPath = BaseDir::expandHome( settings.patchedRomFolder ) / bpsPath.filename();

		std::error_code err;
		fs::create_directories( patchedRomPath.parent_path(), err );
		if( err ) return Bps::BpsApplyError::WriteError;
	}
	patchedRomPath.replace_extension( ".z64" );

	std::ofstream patchedRom( patchedRomPath, std::ios_base::out | std::ios_base::binary | std::ios_base::trunc );
	patchedRom.write( patchedRomData.data<char>(), patchedRomMem.len );

	return patchedRom.good() ? Bps::BpsApplyError::None : Bps::BpsApplyError::WriteError;
}

Bps::BpsApplyError Bps::tryApplyBps(
	const fs::path &bpsPath,
	fs::path &patchedRomPath
) {
	if( !isBpsFile( bpsPath ) ) {
		return BpsApplyError::InvalidBps;
	}

	BpsFile bpsFile( bpsPath );
	bpsinfo info = bps_get_info( &bpsFile, false );

	if ( info.error != bpserror::bps_ok ) {
		return BpsApplyError::InvalidBps;
	}

	fs::path baseRomPath;
	if( !DataProvider::tryFetchRomPathWithCrc32( info.crc_in, baseRomPath ) ) {
		return BpsApplyError::NoBaseRom;
	}

	return applyBps( bpsPath, baseRomPath, bpsFile, info, patchedRomPath );
}

Bps::BpsApplyError Bps::tryApplyBps(
	const fs::path &bpsPath,
	const fs::path &baseRomPath,
	fs::path &patchedRomPath
) {
	if( !isBpsFile( bpsPath ) ) {
		return BpsApplyError::InvalidBps;
	} else if( !fs::isRegularFileSafe( baseRomPath ) ) {
		return BpsApplyError::NoBaseRom;
	}

	BpsFile bpsFile( bpsPath );
	bpsinfo info = bps_get_info( &bpsFile, false );

	if ( info.error != bpserror::bps_ok ) {
		return BpsApplyError::InvalidBps;
	}

	return applyBps( bpsPath, baseRomPath, bpsFile, info, patchedRomPath );
}
