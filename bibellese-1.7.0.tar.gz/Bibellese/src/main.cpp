#include <QApplication>
#include <QDir>
#include <QLibraryInfo>
#include <QTranslator>
#include "mainwindow.h"
#include "config.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QApplication::setApplicationName(APP_NAME);
    QApplication::setApplicationVersion(APP_VERSION);
    QApplication::setOrganizationName("Imkerei Brodbeck");
    QApplication::setOrganizationDomain("imkerei-brodbeck.de");

    QTranslator qtTranslator;
    QLocale german(QLocale::German);
#ifdef __linux__
    qtTranslator.load("qt_" + german.name(),
                      QLibraryInfo::location(QLibraryInfo::TranslationsPath));
#endif
#ifdef _WIN32
    qtTranslator.load("qt_" + german.name(), QApplication::applicationDirPath() +
                                             QDir::separator() + "translations");
#endif
    a.installTranslator(&qtTranslator);

    MainWindow w;
    w.show();

    return a.exec();
}
