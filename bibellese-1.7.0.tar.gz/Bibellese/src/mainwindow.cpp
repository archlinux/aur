#include <string>
#include <sstream>
#include <locale>
#include <boost/filesystem.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <QSettings>
#include <QMessageBox>
#include <QFileDialog>
#include <QDesktopServices>

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <config.h>
#include "oeab.h"
#include "jahresbibel.h"
#include "perikopen.h"
#include "settingsdialog.h"
#include "licensedialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    mLeseplan(nullptr)
{
    ui->setupUi(this);

    //QMessageBox::information(this, "Info", QApplication::applicationDirPath(), QMessageBox::StandardButton::Ok);

    // Create ÖAB submenus
    boost::filesystem::path pfad(INSTALL_PREFIX + std::string("/share/bibellese/data"));
    // If there are no Bibellese data files relative to INSTALL_PREFIX, search relative to the executable file
    // This fixes the problem that INSTALL_PREFIX is not available/valid when using RPM
    if (!boost::filesystem::exists(pfad)) {
        pfad = QApplication::applicationDirPath().toStdString() + std::string("/../share/bibellese/data");
    }
    // If there are no Bibellese files installed, search in the local path
    if (!boost::filesystem::exists(pfad)) {
        pfad = boost::filesystem::current_path();
        pfad /= "data";
        // If there are even in the local path no data files, give up!
        if(!boost::filesystem::exists(pfad)) {
            QMessageBox::critical(nullptr, "Fehler", "Es konnten keine Datendateien gefunden werden.\nDie Anwendung wird beendet.");
            exit(0);
        }
    }


    boost::filesystem::directory_iterator end_iter;
    for (boost::filesystem::directory_iterator iter(pfad); iter != end_iter; ++iter) {
        if (iter->path().extension() == ".csv") {
            mDateiMap[iter->path().stem().string()] = iter->path().string();
        }
    }
    for (auto iter : mDateiMap) {
        QAction *action = new QAction(this);
        action->setText(QString::fromStdString(iter.first));
        ui->menuNeu_OEAB->addAction(action);
    }
    QObject::connect(ui->menuNeu_OEAB, SIGNAL(triggered(QAction*)), this, SLOT(new_oeab_plan(QAction*)));

    // Create Perikopen submenus
    boost::gregorian::date curDatum(boost::gregorian::day_clock::local_day());
    for (int i = 0; i < 3; i++)
    {
        QAction *action = new QAction(this);
        action->setText(QString(tr("%1").arg(curDatum.year() + i)));
        action->setData(curDatum.year() + i);
        ui->menuNeuPerikopen->addAction(action);
    }
    QObject::connect(ui->menuNeuPerikopen, SIGNAL(triggered(QAction*)), this, SLOT(newPerikopenPlan(QAction*)));

    // Initially create OEB plan of the current year ...
    std::string curYearString = boost::lexical_cast<std::string> (curDatum.year());
    bool curYearActionFound = false;
    for(auto action : ui->menuNeu_OEAB->actions())
    {
        if(action->text() == QString(curYearString.c_str()))
        {
            action->trigger();
            curYearActionFound = true;
            break;
        }
    }
    // ... else create the OEB from the first possible OEB entry
    if(curYearActionFound == false)
        ui->menuNeu_OEAB->actions().first()->trigger();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::new_oeab_plan(QAction *action)
{
    if (mLeseplan != nullptr)
        delete mLeseplan;
    QString title(QString::fromUtf8("Bibellese - (ÖAB "));
    title.append(action->iconText()).append(")");
    setWindowTitle(title);
    mLeseplan = new Oeab(mDateiMap[action->iconText().toStdString()]);
    updateTable();
}

void MainWindow::newJahresbibelPlan()
{
    if (mLeseplan != nullptr)
        delete mLeseplan;
    setWindowTitle(QString::fromUtf8("Bibellese - (Jahresbibel)"));
    mLeseplan = new Jahresbibel();
    updateTable();
}

void MainWindow::newPerikopenPlan(QAction *action)
{
    if (mLeseplan != nullptr)
        delete mLeseplan;
    QString title(QString::fromUtf8("Bibellese - (Perikopen "));
    title.append(action->iconText()).append(")");
    setWindowTitle(title);
    mLeseplan = new Perikopen(action->data().toInt());
    updateTable();
}

void MainWindow::updateTable()
{
    std::stringstream ss;
    boost::gregorian::date_facet *dateFacet = new boost::gregorian::date_facet("%d.%m.%Y");

    ss.imbue(std::locale(std::locale::classic(), dateFacet));


    ui->tableWidget->clearContents();

    int row = 0;
    auto plan = mLeseplan->getBibelstellen();
    ui->tableWidget->setRowCount(plan.size());

    QStringList headerLabels;
    for(auto item : mLeseplan->getTitel())
    {
        headerLabels.append(QString::fromUtf8(item.c_str()));
    }
    ui->tableWidget->setColumnCount(mLeseplan->getTitel().size());
    ui->tableWidget->setHorizontalHeaderLabels(headerLabels);

    for (auto item : plan) {

        ss << item.getDatum();
        QTableWidgetItem *newItemDatum = new QTableWidgetItem(tr("%1").arg(QString::fromStdString(ss.str())));
        ui->tableWidget->setItem(row, 0, newItemDatum);
        ss.str("");
        for(size_t i = 0; i < item.getBibelstellen().size(); i++)
        {
            QTableWidgetItem *newItemName = new QTableWidgetItem(tr("%1").arg(QString::fromUtf8(item.getBibelstellen()[i].c_str())));
            ui->tableWidget->setItem(row, i + 1, newItemName);
        }

        ++row;
    }
    ui->tableWidget->resizeColumnsToContents();
    ui->tableWidget->resizeRowsToContents();
    ui->tableWidget->horizontalHeader()->setStretchLastSection(true);

    boost::gregorian::date curDatum = boost::gregorian::day_clock::local_day();
    if (mLeseplan->type() != "Perikopen" && mLeseplan->getJahr() == curDatum.year()) {
        ss << curDatum;
        QList<QTableWidgetItem*> items = ui->tableWidget->findItems(QString::fromStdString(ss.str()),
                                                                    Qt::MatchExactly);
        ui->tableWidget->selectRow(items.first()->row());
    } else if (mLeseplan->type() == "Perikopen" && mLeseplan->getJahr() == curDatum.year()) {
        for (auto item: mLeseplan->getBibelstellen())
        {
            if (item.getDatum() >= curDatum)
            {
                ss << item.getDatum();
                break;
            }
        }
        QList<QTableWidgetItem*> items = ui->tableWidget->findItems(QString::fromStdString(ss.str()),
                                                                    Qt::MatchExactly);
         ui->tableWidget->selectRow(items.first()->row());
    } else {
        ui->tableWidget->selectRow(-1);
        ui->tableWidget->scrollToTop();
    }
}

void MainWindow::showSettings()
{
    SettingsDialog dialog(this);
    dialog.exec();
}

void MainWindow::showLicense()
{
    LicenseDialog dialog(this);
    dialog.exec();
}

void MainWindow::exportToIcal()
{
    QSettings settings;

    if(settings.contains("oeab/start_hour") == false)
    {
        QMessageBox::information(this, "Information", "Sie werden nun zu den Einstellungen weitergeleitet, da Sie noch keine Uhrzeiten angegeben haben.", QMessageBox::Ok);
        SettingsDialog dialog;
        int code = dialog.exec();
        if (code == QDialog::Rejected) {
            return;
        }
    }


    QString filename = QFileDialog::getSaveFileName(this, "Export nach iCalendar", nullptr, "iCal files (*.ics)");
    if(filename.length() > 0)
    {
        if (mLeseplan->type() == "ÖAB") {
            mLeseplan->speichernAlsIcal(filename.toUtf8().constData(), settings.value("oeab/start_hour").toInt(),
                                        settings.value("oeab/start_minute").toInt(), settings.value("oeab/duration").toInt());
        } else if (mLeseplan->type() == "Jahresbibel") {
            mLeseplan->speichernAlsIcal(filename.toUtf8().constData(), settings.value("jahresbibel/start_hour").toInt(),
                                        settings.value("jahresbibel/start_minute").toInt(), settings.value("jahresbibel/duration").toInt());;
        } else if (mLeseplan->type() == "Perikopen") { // reuse Jahresbibel-Settings for Perikopen
            mLeseplan->speichernAlsIcal(filename.toUtf8().constData(), 9, 30, 60);;
        }

    } else {
        std::cout << "Abgebrochen" << std::endl;
    }
}

void MainWindow::aboutProg()
{
    QString aboutString;
    aboutString.append("<b>").append(QApplication::applicationName()).append("&nbsp;");
    aboutString.append(QApplication::applicationVersion()).append("</b><br />");
    aboutString.append(QString::fromUtf8("""Erstellt folgende Bibellesepläne:"""
                                         """<ul><li>ÖAB (Ökumenische Arbeitsgemeinschaft für Bibellesen)</li>"""
                                         """<li>Jahresbibel</li>"""
                                         """<li>Perikopenordnung</li></ul>"""));
    aboutString.append(QString::fromUtf8("Autor: Martin Brodbeck &lt;<a href=\"mailto:martin@brodbeck-online.de\">martin@brodbeck-online.de</a>&gt;"));
    QMessageBox::about(this, QString::fromUtf8("Über Bibellese"), aboutString);

}

void MainWindow::aboutQt()
{
    QMessageBox::aboutQt(this);
}

void MainWindow::onItemDoubleClicked(QTableWidgetItem *item)
{
    QString headerText(ui->tableWidget->horizontalHeaderItem(item->column())->text());
    if (headerText.startsWith("Datum") || headerText.startsWith("Liturg")) {
        return;
    }
    QString bibleText = item->text();
    QDesktopServices::openUrl(QUrl("http://www.bibleserver.com/text/LUT/" + bibleText));
}

void MainWindow::on_pbExport_clicked()
{
    exportToIcal();
}
