#ifndef PREDIGTTEXTE_H
#define PREDIGTTEXTE_H

#include <boost/date_time/gregorian/gregorian.hpp>
#include <string>
#include <map>

#include "leseplan.h"

class LiturgischerTag
{
public:
    LiturgischerTag();
    LiturgischerTag(const boost::gregorian::date& date, const std::string& text = "");
    boost::gregorian::date getDate();
    void setText(const std::string& text);
    std::string getText();
private:
    boost::gregorian::date mLitDate;
    std::string mLitText;
};

class Perikopen : public Leseplan
{
public:
    Perikopen();
    Perikopen(int year);
    virtual std::string type() {return "Perikopen";}
    virtual const std::vector<Bibelstelle> getBibelstellen();
    virtual boost::gregorian::greg_year getJahr();
protected:
    virtual void auslesen();
private:
    void appendBibelstellen();
    int mYear;
    std::map<std::string, LiturgischerTag> mLitDates;
    std::vector<Bibelstelle> mBibelstellen;
    void calcKirchenjahr(int start_year);
    boost::gregorian::date calcOstersonntag(int year);
};

#endif // PREDIGTTEXTE_H
