#include "src/polyfill/windows/unicode.hpp"

#include <windows.h>
#include <codecvt>
#include <locale>
#include <fstream>
#include "src/core/filesystem.hpp"
#include "src/core/buffer.hpp"

void Unicode::fixFileEncoding( const wchar_t *fileName ) {
	const fs::path filePath = fs::path( fileName );
	if( !fs::is_regular_file( filePath ) ) return;

	const size_t fileSize = (size_t)fs::file_size( filePath );
	Buffer fileBuffer( fileSize + 1 );

	std::fstream file( filePath, std::ios_base::in | std::ios_base::out );
	file.seekg( 0 );
	file.read( fileBuffer.data(), fileSize );
	fileBuffer.data()[fileSize] = '\0';

	const int numWideChars = MultiByteToWideChar( CP_ACP, 0, fileBuffer.data(), (int)fileSize + 1, nullptr, 0 );
	Buffer wideBuffer( numWideChars * 2 );
	if( !MultiByteToWideChar( CP_ACP, 0, fileBuffer.data(), (int)fileSize + 1, (wchar_t*)wideBuffer.data(), numWideChars ) ) return;
	const std::string encodedData = Unicode::toUtf8( (const wchar_t*)wideBuffer.data() );

	file.seekp( 0 );
	file.write( encodedData.data(), encodedData.length() );
}

std::wstring Unicode::toUtf16( const char *u8str ) {
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>,wchar_t> converter;
	return converter.from_bytes( u8str );
}

std::string Unicode::toUtf8( const wchar_t *u16str ) {
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>,wchar_t> converter;
	return converter.to_bytes( u16str );
}

std::vector<std::string> Unicode::argvUtf8() {
	int argc;
	wchar_t **argv = CommandLineToArgvW( GetCommandLineW(), &argc );

	std::vector<std::string> args;
	if( argv == nullptr ) return args;

	args.reserve( argc );
	for( int i = 0; i < argc; i++ ) {
		args.push_back( Unicode::toUtf8( argv[i] ) );
	}

	LocalFree( argv );
	return args;
}
