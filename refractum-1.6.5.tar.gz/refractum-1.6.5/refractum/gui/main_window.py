"""
Main selection window — GTK4 / PyGObject.

Two tabs via Gtk.Notebook:
  1. "Arch mirrors"  — country + mirror options
  2. "Distro mirrors" — CachyOS / EndeavourOS / Artix speed-based ranking
"""

from __future__ import annotations

import gi
import math

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk  # noqa: E402

from collections.abc import Callable
from dataclasses import dataclass, field
from ..models import Country, ReflectorOptions
from ..config import save_user_config, save_global_config
from ..distros import MirrorSet, ALL_MIRROR_SETS, installed_mirror_sets, detect_distro_id


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class SelectionResult:
    """Everything the user chose in the main window."""

    options: ReflectorOptions
    distro_sets: list[MirrorSet] = field(default_factory=list)
    cancelled: bool = False


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------


class MainWindow(Gtk.ApplicationWindow):
    def __init__(
        self,
        app: Gtk.Application,
        countries: list[Country],
        local_code: str,
        defaults: ReflectorOptions,
        columns: int = 5,
        width: int = 1000,
        height: int = 750,
        on_result: Callable[[SelectionResult], None] | None = None,
    ) -> None:
        super().__init__(application=app, title="refractum — Select Arch mirrors")
        self.set_default_size(width, height)

        self._countries = countries
        self._local_code = local_code
        self._defaults = defaults
        self._columns = columns
        self._on_result = on_result

        self._country_checks: list[Gtk.CheckButton] = []
        self._distro_checks: dict[str, Gtk.CheckButton] = {}  # id → CheckButton
        self._updating_countries = False

        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.set_margin_start(8)
        root.set_margin_end(8)
        root.set_margin_top(8)
        root.set_margin_bottom(8)
        self.set_child(root)

        # Gtk.Notebook — tabbed container
        notebook = Gtk.Notebook()
        notebook.set_vexpand(True)
        root.append(notebook)

        # Tab 1: Arch mirrors
        arch_page = self._build_arch_tab()
        notebook.append_page(arch_page, Gtk.Label(label="Arch mirrors"))

        # Tab 2: Distro mirrors
        distro_page = self._build_distro_tab()
        notebook.append_page(distro_page, Gtk.Label(label="Distro mirrors"))

        root.append(self._make_buttons())

    # ------------------------------------------------------------------
    # Tab 1: Arch mirrors
    # ------------------------------------------------------------------

    def _build_arch_tab(self) -> Gtk.Box:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_start(4)
        box.set_margin_end(4)
        box.set_margin_top(8)

        box.append(
            Gtk.Label(
                label="Select countries to include in mirror ranking.\n"
                "Closest locations are usually the fastest. HTTPS is preferred.",
                xalign=0,
            )
        )

        scroll = self._make_country_scroll()
        scroll.set_vexpand(True)
        box.append(scroll)
        box.append(self._make_options())
        return box

    def _make_country_scroll(self) -> Gtk.ScrolledWindow:
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_overlay_scrolling(False)

        grid = Gtk.Grid()
        grid.set_column_spacing(8)
        grid.set_row_spacing(4)
        grid.set_margin_start(4)
        grid.set_margin_top(4)

        pre_selected = set(self._defaults.countries) if self._defaults.countries else {self._local_code}
        ww_active = "WW" in pre_selected

        n = len(self._countries)
        rows = math.ceil(n / self._columns)

        for idx, country in enumerate(self._countries):
            cb = Gtk.CheckButton(label=country.name)
            cb.set_active(country.code in pre_selected)
            if country.code != "WW":
                cb.set_sensitive(not ww_active)
            self._country_checks.append(cb)
            col = idx // rows
            row = idx % rows
            grid.attach(cb, col, row, 1, 1)
            if country.code == "WW":
                cb.connect("toggled", self._on_worldwide_toggled)
            else:
                cb.connect("toggled", self._on_country_toggled)

        scroll.set_child(grid)
        return scroll

    def _make_options(self) -> Gtk.Frame:
        frame = Gtk.Frame(label="Mirror options")
        frame.set_margin_top(4)

        grid = Gtk.Grid()
        grid.set_column_spacing(12)
        grid.set_row_spacing(6)
        grid.set_margin_start(8)
        grid.set_margin_end(8)
        grid.set_margin_top(6)
        grid.set_margin_bottom(6)
        frame.set_child(grid)

        row = 0

        # Protocols
        grid.attach(Gtk.Label(label="Protocols:", xalign=0), 0, row, 1, 1)
        proto_box = Gtk.Box(spacing=8)
        self._https_cb = Gtk.CheckButton(label="https")
        self._https_cb.set_active("https" in self._defaults.protocols if self._defaults.protocols else True)
        self._http_cb = Gtk.CheckButton(label="http")
        self._http_cb.set_active("http" in self._defaults.protocols)
        for w in (self._https_cb, self._http_cb):
            proto_box.append(w)
        grid.attach(proto_box, 1, row, 3, 1)
        row += 1

        # Sort
        grid.attach(Gtk.Label(label="Sort by:", xalign=0), 0, row, 1, 1)
        _SORT_OPTS = ["rate", "age", "country", "score", "delay"]
        self._sort_opts = _SORT_OPTS
        self._sort_combo = Gtk.DropDown.new_from_strings(_SORT_OPTS)
        current = self._defaults.sort or "rate"
        self._sort_combo.set_selected(_SORT_OPTS.index(current) if current in _SORT_OPTS else 0)
        grid.attach(self._sort_combo, 1, row, 1, 1)
        row += 1

        # Sync recency — mutually exclusive: --age N  vs  --latest N
        grid.attach(Gtk.Label(label="Sync recency:", xalign=0), 0, row, 1, 1)
        freshness_box = Gtk.Box(spacing=12)

        self._radio_age = Gtk.CheckButton(label="Max age (h):")
        self._radio_latest = Gtk.CheckButton(label="Latest synced:")
        self._radio_latest.set_group(self._radio_age)  # mutual exclusion

        adj_age = Gtk.Adjustment(value=self._defaults.age or 24, lower=1, upper=8760, step_increment=1)
        self._age_spin = Gtk.SpinButton(adjustment=adj_age, climb_rate=1, digits=0)
        self._age_spin.set_width_chars(6)

        adj_latest = Gtk.Adjustment(value=self._defaults.latest, lower=1, upper=500, step_increment=5)
        self._latest_spin = Gtk.SpinButton(adjustment=adj_latest, climb_rate=1, digits=0)
        self._latest_spin.set_width_chars(6)

        use_latest = self._defaults.use_latest
        self._radio_age.set_active(not use_latest)
        self._radio_latest.set_active(use_latest)
        self._age_spin.set_sensitive(not use_latest)
        self._latest_spin.set_sensitive(use_latest)

        def _on_recency_toggled(btn: Gtk.CheckButton) -> None:
            age_mode = btn is self._radio_age and btn.get_active()
            self._age_spin.set_sensitive(age_mode)
            self._latest_spin.set_sensitive(not age_mode)

        self._radio_age.connect("toggled", _on_recency_toggled)
        self._radio_latest.connect("toggled", _on_recency_toggled)

        freshness_box.append(self._radio_age)
        freshness_box.append(self._age_spin)
        freshness_box.append(self._radio_latest)
        freshness_box.append(self._latest_spin)
        grid.attach(freshness_box, 1, row, 3, 1)
        row += 1

        # Number
        grid.attach(Gtk.Label(label="Max mirrors:", xalign=0), 0, row, 1, 1)
        adj = Gtk.Adjustment(value=self._defaults.number or 10, lower=1, upper=200, step_increment=1)
        self._number_spin = Gtk.SpinButton(adjustment=adj, climb_rate=1, digits=0)
        self._number_spin.set_width_chars(6)
        grid.attach(self._number_spin, 1, row, 1, 1)
        row += 1

        # Timeout
        grid.attach(Gtk.Label(label="Download timeout (s):", xalign=0), 0, row, 1, 1)
        adj2 = Gtk.Adjustment(value=self._defaults.download_timeout or 10, lower=1, upper=120, step_increment=1)
        self._timeout_spin = Gtk.SpinButton(adjustment=adj2, climb_rate=1, digits=0)
        self._timeout_spin.set_width_chars(6)
        grid.attach(self._timeout_spin, 1, row, 1, 1)
        row += 1

        # Threads
        grid.attach(Gtk.Label(label="Threads:", xalign=0), 0, row, 1, 1)
        adj3 = Gtk.Adjustment(value=self._defaults.threads or 5, lower=1, upper=32, step_increment=1)
        self._threads_spin = Gtk.SpinButton(adjustment=adj3, climb_rate=1, digits=0)
        self._threads_spin.set_width_chars(6)
        grid.attach(self._threads_spin, 1, row, 1, 1)
        row += 1

        return frame

    # ------------------------------------------------------------------
    # Tab 2: Distro mirrors (speed-based)
    # ------------------------------------------------------------------

    def _build_distro_tab(self) -> Gtk.Box:
        """
        Shows all installed distro mirrorlist sets with checkboxes.
        The user picks which ones to re-rank.
        """
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(8)
        box.set_margin_end(8)
        box.set_margin_top(8)

        box.append(
            Gtk.Label(
                label="Select which distro mirror lists to rank by download speed.\n"
                "Grayed out entries are not installed on this system.\n"
                "This is independent of the Arch mirrors tab — uncheck all to skip.",
                xalign=0,
            )
        )

        # All primary sets — derived sets (v3/v4) are ranked automatically.
        all_primaries = [ms for ms in ALL_MIRROR_SETS if not ms.primary_id]
        installed_ids = {ms.id for ms in installed_mirror_sets()}

        derived_by_primary: dict[str, list] = {}
        for ms in ALL_MIRROR_SETS:
            if ms.primary_id:
                derived_by_primary.setdefault(ms.primary_id, []).append(ms)

        # Pre-select the set that matches the running distro (if any).
        # Plain Arch has no distro-specific mirror set, so nothing is pre-selected.
        _distro_to_set_id = {
            "cachyos": "cachyos",
            "endeavouros": "endeavouros",
            "artix": "artix",
            "blackarch": "blackarch",
            "rebornos": "rebornos",
        }
        auto_id = _distro_to_set_id.get(detect_distro_id(), "")

        hint_label = Gtk.Label(label="", xalign=0, css_classes=["dim-label"])
        hint_label.set_margin_top(2)
        hint_label.set_margin_start(4)

        groups = [
            ("Distributions", [ms for ms in all_primaries if not ms.is_repo]),
            ("Third-party repositories", [ms for ms in all_primaries if ms.is_repo]),
        ]

        for group_label, members in groups:
            header = Gtk.Label(label=group_label, xalign=0)
            header.set_margin_top(8)
            header.set_margin_bottom(2)
            box.append(header)

            list_box = Gtk.ListBox()
            list_box.set_selection_mode(Gtk.SelectionMode.NONE)
            list_box.add_css_class("boxed-list")

            for ms in members:
                is_installed = ms.id in installed_ids
                paths = [ms.mirrorlist_path] + [d.mirrorlist_path for d in derived_by_primary.get(ms.id, [])]
                suffix = "" if is_installed else "  (not installed)"
                hint_text = "  |  ".join(str(p) for p in paths) + suffix

                row = Gtk.ListBoxRow()
                row_box = Gtk.Box(spacing=12)
                row_box.set_margin_start(8)
                row_box.set_margin_end(8)
                row_box.set_margin_top(6)
                row_box.set_margin_bottom(6)

                cb = Gtk.CheckButton()
                if self._defaults.distro_sets is not None:
                    # Restore saved selection
                    cb.set_active(is_installed and ms.id in self._defaults.distro_sets)
                else:
                    # First launch: auto-select distro match + all installed repos
                    cb.set_active(is_installed and (ms.id == auto_id or ms.is_repo))
                cb.set_sensitive(is_installed)
                self._distro_checks[ms.id] = cb

                name_label = Gtk.Label(label=ms.display_name, xalign=0, hexpand=True)
                if not is_installed:
                    name_label.add_css_class("dim-label")

                row_box.append(cb)
                row_box.append(name_label)
                row.set_child(row_box)

                motion = Gtk.EventControllerMotion()
                motion.connect("enter", lambda _c, _x, _y, t=hint_text: hint_label.set_text(t))
                motion.connect("leave", lambda _c: hint_label.set_text(""))
                row.add_controller(motion)

                list_box.append(row)

            box.append(list_box)

        box.append(hint_label)

        # Speed test settings (timeout and max mirrors come from Arch mirrors tab)
        opts_frame = Gtk.Frame(label="Speed test options")
        opts_frame.set_margin_top(8)
        opts_grid = Gtk.Grid()
        opts_grid.set_column_spacing(12)
        opts_grid.set_row_spacing(6)
        opts_grid.set_margin_start(8)
        opts_grid.set_margin_end(8)
        opts_grid.set_margin_top(6)
        opts_grid.set_margin_bottom(6)
        opts_frame.set_child(opts_grid)

        self._ww_fallback_cb = Gtk.CheckButton(label="Worldwide fallback")
        self._ww_fallback_cb.set_active(self._defaults.distro_ww_fallback)
        self._ww_fallback_cb.set_tooltip_text(
            "On: silently use all worldwide mirrors when none are found in the selected countries.\n"
            "Off: ask before falling back."
        )
        opts_grid.attach(self._ww_fallback_cb, 0, 0, 3, 1)

        opts_grid.attach(
            Gtk.Label(
                label="Timeout, threads and max mirrors are taken from the Arch mirrors tab.",
                xalign=0,
                css_classes=["dim-label"],
            ),
            0,
            1,
            3,
            1,
        )

        box.append(opts_frame)
        return box

    # ------------------------------------------------------------------
    # Buttons
    # ------------------------------------------------------------------

    def _make_buttons(self) -> Gtk.Box:
        box = Gtk.Box(spacing=8)
        box.set_margin_top(8)

        global_btn = Gtk.Button(label="Save as global default")
        global_btn.set_tooltip_text("Write current settings to /etc/refractum.toml (requires root)")
        global_btn.connect("clicked", self._on_save_global)

        spacer = Gtk.Box()
        spacer.set_hexpand(True)

        cancel_btn = Gtk.Button(label="Cancel")
        cancel_btn.connect("clicked", self._on_cancel)

        ok_btn = Gtk.Button(label="OK")
        ok_btn.add_css_class("suggested-action")
        ok_btn.connect("clicked", self._on_ok)

        box.append(global_btn)
        box.append(spacer)
        box.append(cancel_btn)
        box.append(ok_btn)
        return box

    # ------------------------------------------------------------------
    # Signal handlers
    # ------------------------------------------------------------------

    def _collect_options(self) -> ReflectorOptions:
        selected_codes = [c.code for c, cb in zip(self._countries, self._country_checks) if cb.get_active()]
        if "WW" in selected_codes:
            selected_codes = ["WW"]  # WW = no country filter; discard grayed-out individuals
        protocols = []
        if self._https_cb.get_active():
            protocols.append("https")
        if self._http_cb.get_active():
            protocols.append("http")

        use_latest = self._radio_latest.get_active()
        return ReflectorOptions(
            countries=selected_codes,
            protocols=protocols,
            sort=self._sort_opts[idx] if (idx := self._sort_combo.get_selected()) < len(self._sort_opts) else "rate",
            use_latest=use_latest,
            latest=int(self._latest_spin.get_value()),
            age=None if use_latest else int(self._age_spin.get_value()),
            number=int(self._number_spin.get_value()),
            download_timeout=int(self._timeout_spin.get_value()),
            threads=int(self._threads_spin.get_value()),
        )

    def _on_ok(self, _: Gtk.Button) -> None:
        opts = self._collect_options()

        # Distro sets: start with checked primaries, then append their derived sets.
        all_installed = installed_mirror_sets()
        selected_distros: list[MirrorSet] = []
        for ms in all_installed:
            if ms.primary_id:
                continue  # derived sets are added below
            cb = self._distro_checks.get(ms.id)
            if cb and cb.get_active():
                selected_distros.append(ms)
                for derived in all_installed:
                    if derived.primary_id == ms.id:
                        selected_distros.append(derived)

        opts.distro_ww_fallback = self._ww_fallback_cb.get_active()
        opts.distro_sets = [ms.id for ms in selected_distros if not ms.primary_id]
        save_user_config(opts)

        result = SelectionResult(
            options=opts,
            distro_sets=selected_distros,
        )
        # Fire callback BEFORE closing so the next window opens first.
        # If we closed first, GTK might see zero windows and try to quit.
        if self._on_result:
            self._on_result(result)
        self.close()

    def _on_save_global(self, _: Gtk.Button) -> None:
        opts = self._collect_options()
        opts.distro_ww_fallback = self._ww_fallback_cb.get_active()
        try:
            save_global_config(opts)
            self._show_toast("System defaults saved to /etc/refractum.toml")
        except PermissionError:
            pass  # user cancelled pkexec — no error needed
        except Exception as exc:
            self._show_toast(f"Failed to save: {exc}")

    def _on_cancel(self, _: Gtk.Button) -> None:
        result = SelectionResult(options=self._defaults, cancelled=True)
        if self._on_result:
            self._on_result(result)
        self.close()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _on_worldwide_toggled(self, cb: Gtk.CheckButton) -> None:
        if self._updating_countries:
            return
        ww_active = cb.get_active()
        for check, country in zip(self._country_checks, self._countries):
            if country.code != "WW":
                check.set_sensitive(not ww_active)

    def _on_country_toggled(self, cb: Gtk.CheckButton) -> None:
        if self._updating_countries or not cb.get_active():
            return
        self._updating_countries = True
        for check, country in zip(self._country_checks, self._countries):
            if country.code == "WW":
                check.set_active(False)
        self._updating_countries = False

    def _show_toast(self, message: str) -> None:
        dialog = Gtk.AlertDialog()
        dialog.set_message(message)
        dialog.set_buttons(["OK"])
        dialog.show(self)
