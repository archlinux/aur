[![builds.sr.ht status](https://builds.sr.ht/~nedia.svg)](https://builds.sr.ht/~nedia?)
[![Go Reference](https://pkg.go.dev/badge/git.sr.ht/~nedia/nedots.svg)](https://pkg.go.dev/git.sr.ht/~nedia/nedots)

Open an issue [here](https://todo.sr.ht/~nedia/nedots).
Mirrored on [GitHub](https://github.com/aidenlangley/nedots.go).

# [nedots](https://git.sr.ht/~nedia/nedots) | [nedots.go](https://git.sr.ht/~nedia/nedots.go)

A dotfile management tool. `nedots --help` for more information.

## Install 

```sh
go install git.sr.ht/~nedia/nedots@latest
```

Also available on the [AUR](https://aur.archlinux.org/packages/nedots).
I recommend [yay](https://github.com/Jguer/yay).

```sh
yay -S nedots
```

## Config

There is a sample config in `example/config.yml`.
Config lives in `$XDG_CONFIG_HOME` or `~/.config/nedots`.

```yaml
remote: https://git.sr.ht/~nedia/dots-sample
dots:
  - .profile
  - .config/river
  - /usr/local/bin/river-run
repos:
  - remote: https://git.sr.ht/~nedia/config.nvim
    path: .config/nvim
```

## Development

If you've forked or want to contribute, the following should help.

### Working with `src` submodule

Clone the repository with `--recursive`.

```sh 
git clone https://git.sr.ht/~nedia/nedots.go --recursive`
```

### Working with the container

```sh
# Build as is
docker build --tag nedots .

# Build as this user instead of the default (me)
docker build -t nedots --build-arg USERNAME=myusername .

# Simply run the container and remove it once it's finished
docker run --interactive --tty --rm nedots:latest 

# List containers
docker ps --all

# Remove stale containers
docker rm nedots
docker rm --all

# Start the container and detach with `-d` and run `bash`, thereby leaving a 
# shell running
#
# Also mounts working directory so we can `go build` without rebuilding the 
# container
docker run -it --detach --name nedots\
  --volume "$PWD":/usr/src/nedots\
  nedots:latest bash

# Now run `go build` on the container we started previously
# Optionally include `-buildvcs false`
docker exec -it nedots\
  go build -C /usr/src/nedots -o /usr/local/bin/nedots .

# Finally attach to the container which is already running a shell
docker attach nedots

# Start the container again if it's exited
docker start --attach nedots
```
