void BuildFileList(QTableWidget *table,
    QStringList *listFile, const QString pattern);

