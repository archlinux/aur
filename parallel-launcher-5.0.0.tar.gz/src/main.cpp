#include "src/types.hpp"

#if defined(DEBUG) && !defined(_WIN32)
#include "src/core/traceable-exception.hpp"
#include <execinfo.h>
#include <exception>
#include <iostream>
#include <csignal>
#include <cstdlib>
#endif

#include <QCoreApplication>
#include <QGuiApplication>
#include <QApplication>
#include <QMessageBox>
#include <QTranslator>
#include <initializer_list>
#include <set>
#include "src/core/migration.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/retroarch.hpp"
#include "src/core/zip.hpp"
#include "src/core/updates.hpp"
#include "src/ui/direct-play.hpp"
#include "src/ui/main-window.hpp"
#include "src/ui/ui-fixes.hpp"
#include "src/ui/core-installer.hpp"
#include "src/rhdc/web/api.hpp"
#include "src/polyfill/base-directory.hpp"
#ifdef _WIN32
#include "src/polyfill/windows/unicode.hpp"
#include "src/polyfill/windows/locale.hpp"
#endif
#ifndef __linux__
#include <QInputDialog>
#include "src/windows-mac-updater/self-updater.hpp"
#include "src/windows-mac-updater/retroarch-updater.hpp"
#else
#include "src/flatpak/flatpak-progress-dialog.hpp"
#include "src/polyfill/process.hpp"
#include <cstdlib>

static const char *const m_msgSetupFlatpak = QT_TRANSLATE_NOOP( "Main", ""
	"Parallel Launcher will now setup an isolated Flatpak installation to "
	"install and manage RetroArch. This is kept separate from your main "
	"system and user installations." );

#endif

static int runMainWindow( QApplication &app ) {
	QGuiApplication::setQuitOnLastWindowClosed( false );
	MainWindow mainWindow;
	mainWindow.show();
	RetroUpdater::checkForUpdates( false, false, false );
	return app.exec();
}

#if defined(DEBUG) && !defined(_WIN32)
extern "C" void onSegfault( [[maybe_unused]] int signal ) {
	void *trace[32];
	int frames = backtrace( trace, 32 );
	backtrace_symbols_fd( trace, frames, 2 );
	std::cerr << "Segmentation Fault" << std::endl << std::flush;
	std::_Exit( EXIT_FAILURE );
}

static void onTerminate() {
	const std::exception_ptr ep = std::current_exception();
	if( !ep ) return;

	try {
		std::rethrow_exception( ep );
	} catch( const std::exception &exception ) {
		std::cerr << "Uncaught Exception: " << std::endl << exception.what() << std::endl;
		const TraceableException *traceableException = dynamic_cast<const TraceableException*>( &exception );
		if( traceableException != nullptr ) {
			traceableException->printBacktrace();
		}
		std::cerr << std::flush;
	} catch( ... ) {
		std::cerr << "Uncaught Exception: (non-std::exception)" << std::endl << std::flush;
	}

	std::abort();
}
#endif

static fs::path tryGetRomPath( int argc, [[maybe_unused]] char **argv ) {
	if( argc < 2 ) return fs::path();

#ifdef _WIN32
	const string romArg = Unicode::argvUtf8().at( 1 );
	const fs::path romPath = fs::to_path( romArg.c_str() );
#else
	const fs::path romPath = fs::path( argv[1] );
#endif

	static const std::set<string> s_allowedExtensions = std::set<string>{
		".z64", ".n64", ".v64",
		".Z64", ".N64", ".V64",
		".bps", ".BPS", ".Bps"
	};

	try {
		if( !fs::isRegularFileSafe( romPath ) ) {
			return fs::path();
		}

		if( s_allowedExtensions.count( romPath.extension().u8string() ) <= 0 ) {
			return fs::path();
		}

		if( romPath.is_relative() ) {
			return fs::current_path() / romPath;
		}

		return romPath;

	} catch( ... ) {}

	return fs::path();
}

static inline void loadTranslations(
	QTranslator &translations,
	std::initializer_list<fs::path> translationDirectories
) {
	const QLocale locale = QLocale();
	for( const fs::path &folder : translationDirectories ) {
		if( translations.load( locale, "parallel-launcher", ".", folder.u8string().c_str() ) ) {
			return;
		}
	}
}


int main( int argc, char **argv ) {
#if defined(DEBUG) && !defined(_WIN32)
	std::signal( SIGSEGV, onSegfault );
	std::set_terminate( onTerminate );
#endif

	Migration::updateDatabaseSchema();

	QApplication app( argc, argv );
	applyUiFixes( app );

	Migration::run();
	AppSettings settings = FileController::loadAppSettings();

	if( settings.locale.empty() ) {
#ifdef _WIN32
		QLocale::setDefault( QLocale( WindowsLocale::getUserLocale().c_str() ) );
#endif
	} else {
		QLocale::setDefault( QLocale( settings.locale.c_str() ) );
	}

	QTranslator translations;
	loadTranslations( translations, {
#ifdef __linux__
#ifdef DEBUG
		BaseDir::program() / "lang",
		fs::path( "/usr/local/share/parallel-launcher/" ),
		fs::path( "/usr/share/parallel-launcher/" )
#else
		fs::path( "/usr/share/parallel-launcher/" ),
		fs::path( "/usr/local/share/parallel-launcher/" ),
		BaseDir::program() / "lang"
#endif
#elif __APPLE__
		BaseDir::program().parent_path() / "Resources" / "translations"
#else
		BaseDir::program() / "translations"
#endif
	});
	app.installTranslator( &translations );

	RhdcApi::fetchLayoutsAysnc(
		[](LayoutManager &layouts){
			FileController::saveLayoutManager( layouts );
		},
		RhdcApi::logApiError( "Failed to download Parallel Star Layouts" )
	);

#ifndef __linux__
	if( !RetroArch::isRetroArchInstalled() ) {
		if( QMessageBox::information(
			nullptr,
			QCoreApplication::translate( "Main", "Installing RetroArch" ),
			QCoreApplication::translate( "Main", "Parallel Launcher will now install RetroArch." ),
			QMessageBox::Ok | QMessageBox::Cancel
		) != QMessageBox::Ok ) {
			std::exit( 0 );
		}

		if( !RetroArchUpdater::install() ) {
			QMessageBox::critical(
				nullptr,
				QCoreApplication::translate( "Main", "Fatal Error" ),
				QCoreApplication::translate( "Main", "Failed to install RetroArch." )
			);
			std::exit( 1 );
		}
	}
#else
	if( !Flatpak::hasInstallation() ) {
		if( QMessageBox::information(
			nullptr,
			QCoreApplication::translate( "Main", "Flatpak Setup" ),
			QCoreApplication::translate( "Main", m_msgSetupFlatpak ),
			QMessageBox::Ok | QMessageBox::Cancel
		) != QMessageBox::Ok ) {
			std::exit( 0 );
		}

		if(	Flatpak::createInstallation() ) {
			std::vector<string> args;
			args.reserve( argc - 1 );
			for( int i = 1; i < argc; i++ ) {
				args.push_back( argv[i] );
			}
			AsyncProcess( fs::read_symlink( "/proc/self/exe" ).string(), args ).detach();
			std::exit( 0 );
		} else {
			QMessageBox::critical(
				nullptr,
				QCoreApplication::translate( "Main", "Fatal Error" ),
				QCoreApplication::translate( "Main", "Failed to create Flatpak installation." )
			);
			std::exit( 1 );
		}

	}

	if( !Flatpak::isRetroArchInstalled() ) {
		if( QMessageBox::information(
				nullptr,
				QCoreApplication::translate( "Main", "Installing RetroArch" ),
				QCoreApplication::translate( "Main", "RetroArch will now be installed." ),
				QMessageBox::Ok | QMessageBox::Cancel
			) != QMessageBox::Ok ) {
			std::exit( 0 );
		}

		if( !FlatpakProgressDialog::run(
			Flatpak::installRetroArchAsync,
			QT_TRANSLATE_NOOP( "FlatpakProgressDialog", "Installing RetroArch" ),
			QT_TRANSLATE_NOOP( "FlatpakProgressDialog", "Preparing to install RetroArch..." ),
			QT_TRANSLATE_NOOP( "FlatpakProgressDialog", "RetroArch installed successfully." ),
			QT_TRANSLATE_NOOP( "FlatpakProgressDialog", "Failed to install RetroArch." )
		)) {
			std::exit( 1 );
		}
	}
#endif

#ifndef __linux__
	SelfUpdater::checkForUpdates();
#endif

	const fs::path romPath = (argc >= 2) ? tryGetRomPath( argc, argv ) : fs::path();
	const int exitCode = romPath.empty() ? runMainWindow( app ) : DirectPlay::start( app, romPath );

#ifdef __linux__
	fs::error_code err;
	fs::remove_all( BaseDir::homeTemp(), err );
#endif

	return exitCode;

}
