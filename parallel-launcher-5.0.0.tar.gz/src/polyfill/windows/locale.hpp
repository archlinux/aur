#ifndef SRC_POLYFILL_WINDOWS_LOCALE_HPP_
#define SRC_POLYFILL_WINDOWS_LOCALE_HPP_

#include <string>

namespace WindowsLocale {

	extern std::string getUserLocale();

}



#endif /* SRC_POLYFILL_WINDOWS_LOCALE_HPP_ */
