#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"
#include "src/rhdc/web/require-login.hpp"

#include <map>
#include "src/core/special-groups.hpp"
#include "src/core/logging.hpp"

struct GroupNameJson {
	string data;
};

template<> void JsonSerializer::serialize<GroupNameJson>( JsonWriter &jw, const GroupNameJson &obj ) {
	std::ostringstream doubleJson;
	JsonWriter innerWriter( &doubleJson, false );
	innerWriter.writeString( obj.data );

	jw.writeObjectStart();
	jw.writeProperty( "data", doubleJson.str() );
	jw.writeObjectEnd();
}

static inline string listToGroup( const string &listName ) {
	if( listName == "Want To Play" ) {
		return SpecialGroups::WantToPlay;
	} else if( listName == "In Progress" ) {
		return SpecialGroups::InProgress;
	} else if( listName == "Completed" ) {
		return SpecialGroups::Completed;
	} else if( listName == "Favorites" ) {
		return SpecialGroups::Favourites;
	} else return listName;
}

static inline std::optional<GfxPlugin> parsePlugin( const Json &jString ) {
	static const std::map<string,GfxPlugin> tokens = {
		{ "ParaLLEl", GfxPlugin::ParaLLEl },
		{ "GLideN64", GfxPlugin::GlideN64 },
		{ "Glide64", GfxPlugin::Glide64 },
		{ "Rice", GfxPlugin::Rice },
		{ "Angrylion", GfxPlugin::Angrylion }
	};

	const auto p = tokens.find( jString.getOrDefault<string>( "" ) );
	if( p == tokens.end() ) return std::nullopt;
	return p->second;
}

static inline PluginFlags parsePluginFlags( const Json &jArray ) {
	static const std::map<string,PluginFlags> tokens = {
		{ "upscale-texrects", PluginFlags::UpscaleTexrects },
		{ "allow-hle-fallback", PluginFlags::AllowHleFallback },
		{ "emulate-framebuffer", PluginFlags::EmulateFramebuffer },
		{ "accurate-depth-compare", PluginFlags::AcccurateDepthCompare }
	};

	PluginFlags flags = PluginFlags::None;
	if( !jArray.isArray() ) return flags;
	for( const Json &jString : jArray.array() ) {
		const auto f = tokens.find( jString.getOrDefault<string>( "" ) );
		if( f == tokens.end() ) continue;
		flags |= f->second;
	}

	return flags;
}

void RhdcApi::getFollowedHacksAsync(
	const std::function<void(HashMap<string,FollowedHack>&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getFollowedHacksAsync( onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/user/getlists" );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( !json.isObject() ) {
			logError( "Unexpected JSON format in response from RHDC getlists query" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		HashMap<string,FollowedHack> hackMap;
		const JObject lists = json.object();
		for( const auto &[key, hacks] : lists ) {
			if( !hacks.isArray() ) continue;
			const string group = listToGroup( key );
			for( const Json &hack : hacks.array() ) {
				const string hackId = hack["_id"].getOrDefault<string>( "" );
				if( hackId.empty() ) continue;
				if( hackMap.count( hackId ) > 0 ) {
					hackMap[hackId].groups.push_back( group );
				} else {
					const string slug = hack["urlTitle"].getOrDefault<string>( "" );
					if( slug.empty() || !hack["versions"].isArray() ) continue;

					const JArray versionsJson = hack["versions"].array();
					std::vector<RhdcHackVersionExt> versions;
					versions.reserve( versionsJson.size() );
					for( const Json &version : versionsJson ) {
						string sha1 = version["patchedSha1"].getOrDefault<string>( "" );
						if( sha1.empty() ) continue;
						const string download = version["download"].getOrDefault<string>( "" );
						if( download.empty() ) continue;
						versions.push_back({
							sha1,
							download,
							parsePlugin( version["plugin"] ),
							parsePluginFlags( version["pluginFlags"] )
						});
					}

					if( versions.empty() ) continue;
					std::reverse( versions.begin(), versions.end() );

					string layoutUrl = hack["sml"].getOrDefault<string>( "" );
					if( !layoutUrl.empty() ) {
						layoutUrl = "https://api.romhacking.com/game/"s + hackId + '/' + ApiUtil::urlEncode( layoutUrl );
					}

					const JArray authorsJson = hack["authors"].array();
					std::vector<string> authors;
					authors.reserve( authorsJson.size() );
					for( const Json &authorJson : authorsJson ) {
						string author = authorJson.isObject() ? authorJson["username"].getOrDefault<string>( "" ) : authorJson.getOrDefault<string>( "" );
						if( author.empty() ) continue;
						authors.push_back( std::move( author ) );
					}

					hackMap[hackId] = FollowedHack{
						RhdcHackInfo {
							hackId,
							hack["title"].getOrDefault<string>( "" ),
							slug,
							hack["description"].getOrDefault<string>( "" ),
							hack["stars"].getOrDefault<int>( 0 ),
							hack["numDownloads"].getOrDefault<int>( 1 ),
							hack["rating"].getOrDefault<double>( 0.0 ),
							hack["difficulty"].getOrDefault<double>( 0.0 ),
							hack["category"].getOrDefault<string>( "None" )
						},
						std::move( versions ),
						{ group },
						std::move( authors ),
						std::move( layoutUrl )
					};
				}
			}
		}

		onSuccess( hackMap );
	}, onFailure );
}

void RhdcApi::getLayoutAndRecommendedPluginAsync(
	const string &hackId,
	const string &versionName,
	const std::function<void(PluginAndLayoutInfo&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ getLayoutAndRecommendedPluginAsync( hackId, versionName, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/game/"s + hackId );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		if( !json.isObject() || !json["versions"].isArray() ) {
			logError( "Unexpected JSON format in response from RHDC game query" );
			onFailure( ApiErrorType::JsonError );
			return;
		}

		string layoutUrl = json["sml"].getOrDefault<string>( "" );
		if( !layoutUrl.empty() ) {
			layoutUrl = "https://api.romhacking.com/game/"s + hackId + '/' + ApiUtil::urlEncode( layoutUrl );
		}

		const JArray versionsJson = json["versions"].array();
		for( const Json &version : versionsJson ) {
			if( version["download"].getOrDefault<string>( "" ) != versionName ) continue;

			PluginAndLayoutInfo info = {
				parsePlugin( version["plugin"] ),
				parsePluginFlags( version["pluginFlags"] ),
				std::move( layoutUrl )
			};

			onSuccess( info );
			return;
		}

		onFailure( ApiErrorType::NotFound );
	}, onFailure );
}


static void createListAsync(
	const string &group,
	const std::function<void(void)> &callback
) {
	QNetworkReply *response = ApiUtil::send<GroupNameJson>( HttpMethod::Post, "https://api.romhacking.com/user/createlist/", { group } );
	ApiUtil::onResponse( response, callback, [callback](ApiErrorType){ callback(); } );
}

void RhdcApi::addHackToListAsync(
	const string &hackId,
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ addHackToListAsync( hackId, group, onSuccess, onFailure ); })
	createListAsync( group, [=]() {
		QNetworkReply *response = ApiUtil::send( HttpMethod::Put, "https://api.romhacking.com/user/addtolist/"s + ApiUtil::urlEncode( group ) + '/' + hackId );
		ApiUtil::onResponse( response, onSuccess, onFailure );
	});
}

void RhdcApi::removeHackFromListAsync(
	const string &hackId,
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ removeHackFromListAsync( hackId, group, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Delete, "https://api.romhacking.com/user/deletefromlist/"s + ApiUtil::urlEncode( group ) + '/' + hackId );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::deleteListAsync(
	const string &group,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ deleteListAsync( group, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Delete, "https://api.romhacking.com/user/deletelist/"s + ApiUtil::urlEncode( group ) );
	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::downloadHack(
	const string &downloadUrl,
	QFile *destinationFile,
	const std::function<void(int64,int64)> &onProgress,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ downloadHack( downloadUrl, destinationFile, onProgress, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, downloadUrl );

	QObject::connect( response, &QNetworkReply::readyRead, ApiUtil::web(), [=](){
		destinationFile->write( response->readAll() );
	});

	QObject::connect( response, &QNetworkReply::downloadProgress, ApiUtil::web(), [=](qint64 downloaded, qint64 total){
		onProgress( (int64)downloaded, (int64)total );
	});

	ApiUtil::onResponse( response, onSuccess, onFailure );
}

void RhdcApi::downloadThumbnail(
	const string &hackId,
	QFile *destinationFile,
	const std::function<void(void)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	REQUIRE_LOGIN( [=](){ downloadThumbnail( hackId, destinationFile, onSuccess, onFailure ); })
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/game/"s + hackId );
	ApiUtil::onResponse( response, [=]() {
		const Json json = ApiUtil::readJson( response );
		if( !json["screenshots"].isArray() ) {
			onFailure( ApiErrorType::JsonError );
			return;
		}

		const JArray screenshots = json["screenshots"].array();
		if( screenshots.empty() ) {
			onFailure( ApiErrorType::NotFound );
			return;
		}

		const string screenshotName = screenshots[0].getOrDefault<string>( "" );
		if( screenshotName.empty() ) {
			onFailure( ApiErrorType::NotFound );
			return;
		}

		QNetworkReply *download = ApiUtil::send( HttpMethod::Get, "https://api.romhacking.com/game/"s + hackId + '/' + ApiUtil::urlEncode( screenshotName ) );
		QObject::connect( download, &QNetworkReply::readyRead, ApiUtil::web(), [=](){
			destinationFile->write( download->readAll() );
		});

		ApiUtil::onResponse( download, onSuccess, onFailure );
	}, onFailure );
}
