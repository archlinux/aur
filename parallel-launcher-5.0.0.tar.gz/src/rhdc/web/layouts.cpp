#include "src/rhdc/web/api.hpp"
#include "src/rhdc/web/api-helpers.hpp"

#include "src/core/logging.hpp"
#include "src/rhdc/web/require-login.hpp"

void RhdcApi::fetchLayoutsAysnc(
	const std::function<void(LayoutManager&)> &onSuccess,
	const std::function<void(ApiErrorType)> &onFailure
) {
	QNetworkReply *response = ApiUtil::send( HttpMethod::Get, "https://parallel-launcher.ca/layouts.json" );
	ApiUtil::onResponse( response, [=](){
		const Json json = ApiUtil::readJson( response );
		try {
			LayoutManager layout = JsonSerializer::parse<LayoutManager>( json );
			onSuccess( layout );
		} catch( ... ) {
			logError( "JSON deserialization error reading star layouts" );
			onFailure( ApiErrorType::JsonError );
		}
	}, onFailure );
}
