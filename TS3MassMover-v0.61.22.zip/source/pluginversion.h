/*
* TS3MassMover - Teamspeak 3 Client Plugin
*
* Copyright (c) 2010-2018 Stefan Martens, Mr. S
*/

// Automatic generated file: 02.01.2018 20:24:28,01

#ifndef PLUGINVERSION_H
#define PLUGINVERSION_H

#define VERSION_MAJOR 0 
#define VERSION_MINOR 61 
#define VERSION_BUILD 22 
#define VERSION_QFE 32 

#define _STR(x) #x
#define STR(x) _STR(x)
#define VERSION_NUMBER VERSION_MAJOR,VERSION_MINOR,VERSION_BUILD,VERSION_QFE
#define VERSION_STRING STR(VERSION_MAJOR) "." STR(VERSION_MINOR) "." STR(VERSION_BUILD) "." STR(VERSION_QFE)

#define PLUGIN_VERSION VERSION_STRING
#define PLUGIN_API_VERSION VERSION_BUILD
#define PLUGIN_FILENAME "TS3MassMover_win32.dll"

#endif
