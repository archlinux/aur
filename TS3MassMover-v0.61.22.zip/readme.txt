TS3MassMover - Teamspeak 3 Client Plugin
Author: Stefan Martens, Mr. S

E-Mail:
info@stefan1200.de

Homepage:
http://www.stefan1200.de


-= Copyright =-
This plugin is free for use, but please notify us if you found a bug or if you have some suggestion.
The author of this plugin is not responsible for any damage or data loss!
It is not allowed to sell this plugin for money, it has to be free to get!
It is also not allowed to use our source code and publish that with your name!
Please ask us for a permission first if you want to publish something which contains parts of our source code!

Teamspeak 3 is developed by TeamSpeak Systems GmbH, Sales & Licensing by Triton CI & Associates, Inc.
More informations about Teamspeak 3: http://www.teamspeak.com


-= Informations =-
With this Teamspeak 3 Client plugin you have short chat commands to move all clients from a channel
or the whole virtual server to a specified channel. In addition to that, some commands also have
a context menu entry, so you can just click with your mouse.


-= System requirements =-
Since TS3MassMover version 0.4 you need the following system component on Windows,
depends on your TS3 client version (x86 / x64):

Microsoft Visual C++ Redistributable Packages for Visual Studio 2013: https://www.microsoft.com/en-us/download/details.aspx?id=40784

-= Installation =-
On Windows just copy the right DLL file into the C:\Program Files\Teamspeak 3\config\plugins directory.
This plugin contains two DLL files, one for 32 bit and one for 64 bit.
Use the right one for your Teamspeak 3 Client installation. If you use the 64 bit Teamspeak 3 Client,
use the 64 bit plugin. For the 32 bit Teamspeak 3 Client use the 32 bit plugin.

On Linux you can just compile the source. Just do something like
g++ -shared plugin.cpp -o TS3MassMover.so

After you put the right DLL or SO file into the plugins directory,
just activate the plugin in the Teamspeak 3 Client. To do this, just click on Settings -> Plugins,
click on "Reload All" and activate the check box next to the TS3MassMover.

To localize messages copy the selected language from lang folder into the TeamSpeak 3 Client \ plugins
directory and rename it to TS3MassMover.lang.
copy C:\Users\Dev\Downloads\TS3MassMover-v0.60.21\lang\TS3MassMover.de "C:\Program Files\Teamspeak 3\config\plugins\TS3MassMover.lang"
If TS3MassMover.lang is missing the plugin will create the english version, so you could also translate
it by your own.

-= Configuration =-
You might have problems with saving the configuration by missing access rights or due to other plugins.
The configuration is available under $(Teamspeak)\config\plugins\TS3MassMover.conf.
You could create the file by Hand with the following content:

Code:
MENU_CHANNEL_FROM_ME=1
MENU_CHANNEL_FROM_SERVER=1
MENU_CHANNEL_TO_ME=1
MENU_GLOBAL_TO_ME=1

-= Usage =-
For three common commands just right click a channel and open the sub context menu entry TS3MassMover.
On that way you can easily move all clients from or to the selected channel without using chat command,
which is similar to the /m h and /m t chat command. You can also move all clients on the TS3 server
to that selected channel, which is the same like /m at command. One command you will find at
the TS3 main menu Plugins -> TS3MassMover and acts like the /m ah command.

But of course the chat commands are still working, just enter the chat message:
/m help
This shows you information about the usage of this plugin with chat commands.
As an example:
To move the clients of the current channel to another channel with the channel ID 10, just write:
/m t 10
If you want to move to the channel ID 12 and this channel have the password xefr34, just write:
/m t 12 xefr34

Other functions are:
To move the clients from channel ID 28 to your current channel (your channel has no password), just write:
/m h 28
To move all clients from virtual server to your current channel, just write:
/m ah
To move all clients from virtual server to channel ID 58, just write:
/m at 58
To move all members of server group ID 6 to channel ID 38, just write:
/m sgt 6 38
To move all members of server group ID 6 to your current channel, just write:
/m sgh 6
Like in the second example, you can write the channel password as last argument on all commands. Moves all clients of one channel to another channel!
/m fctc <from channel id> <target channel id> [password of target channel]
Move all clients which are not members of server group ID 6 to channel ID 58, just write:
/m nsgt 6 58

To remember the commands easy, just read the characters like:
m t = move to
m h = move here
m at = move all to
m ah = move all here
m sgt = move server group to
m sgh = move server group here
m fctc = move from channel to channel
m nsgt = move not in server group to channel


-= Changelog =-
Version 0.61.22 (02.01.2018)
o Updated build tool chain to VS2015
o Updated TS3 Client API version to 22

Version 0.61.21 (20.01.2017)
o Include localisation by code (switch to german if OS gui is set to german)
o Rename plugin DLLs to support and create myTeamSpeak packages

Version 0.60.21 (22.08.2016)
o Add configuration dialog to enable/disable menu options (Qt 5.6.1)
o Updated TS3 Client API version to 21 (needed for 3.1)

Version 0.59.20 (22.03.2015)
o Add translation option

Version 0.58.20 (22.08.2014)
o Add moving clients which are not members of a selected server group to a specified channel

Version 0.57.20 (18.01.2014)
o Updated TS3 Client API version to 20 (needed for 3.0.14)

Version 0.56.19 (13.10.2012)
o Updated TS3 Client API version to 19 (needed for 3.0.9)

Version 0.56.18 (06.10.2012)
o Add version info to DLLs
o Updated TS3 Client API version to 18 (needed for 3.0.8)

Version 0.55.16 (07.05.2012)
o Add API version to plugin version
o Add channel context menu
o Add plugin menu
o Updated TS3 Client API version to 16 (needed for 3.0.6)

Version 0.54 (16.01.2011)
o Updated TS3 Client API version to 15 (needed for 3.0.3)

Version 0.53 (08.11.2011)
o Updated TS3 Client API version to 14 (needed for 3.0.2)

Version 0.52 (10.08.2011)
o Updated TS3 Client API version to 13 (needed for 3.0.0)

Version 0.51 (14.05.2011)
o Updated TS3 Client API version to 11 (needed for rc2-pre1)

Version 0.5 (25.04.2011)
o Updated TS3 Client API version to 10 (needed for rc1-pre12)

Version 0.4 (19.02.2011)
+ Added command fctc to moves all clients of one channel to another channel!
o Updated TS3 Client API version to 109 (needed for rc1-pre9)

Version 0.3 (07.11.2010)
+ Added commands sgt and sgh to move all members of a server group.

Version 0.2 (09.09.2010)
o Small changes releated to TS3 client beta 28.
o Updated TS3 Client API version to 8 (needed for beta 28+)

Version 0.1 new release (06.08.2010)
o Updated TS3 Client API version to 7 (needed for beta 25+)

Version 0.1 new release (02.08.2010)
o Updated TS3 Client API version to 6 (needed for beta 23)

Version 0.1 (06.07.2010)
o First release