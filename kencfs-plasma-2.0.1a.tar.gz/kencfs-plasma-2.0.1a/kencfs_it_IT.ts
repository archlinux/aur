<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="33"/>
        <source>Encrypted FileSystem</source>
        <oldsource>Crypted FileSystem</oldsource>
        <translation>FileSystem Criptati</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="80"/>
        <source>&amp;Remove</source>
        <oldsource>&amp;Rimuovi</oldsource>
        <translation>&amp;Rimuovi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="122"/>
        <source>&amp;Mount</source>
        <oldsource>&amp;Monta</oldsource>
        <translation>&amp;Monta</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="132"/>
        <source>&amp;Umount</source>
        <oldsource>&amp;Smonta</oldsource>
        <translation>&amp;Smonta</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="64"/>
        <source>&amp;Add</source>
        <translation>&amp;Aggiungi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="93"/>
        <source>E&amp;dit</source>
        <translation>M&amp;odifica</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="109"/>
        <source>&amp;Browse</source>
        <translation>A&amp;pri</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="155"/>
        <source>&amp;Hide</source>
        <translation>&amp;Nascondi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="165"/>
        <location filename="mainwindow.ui" line="233"/>
        <source>&amp;Exit</source>
        <oldsource>&amp;Esci</oldsource>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="209"/>
        <source>&amp;Hide / Show</source>
        <translation>&amp;Nascondi / Mostra</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>Hide / Show</source>
        <translation>&amp;Nascondi / Mostra</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="217"/>
        <source>&amp;Config</source>
        <oldsource>&amp;Configura</oldsource>
        <translation>&amp;Configura</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="220"/>
        <source>Config</source>
        <oldsource>Configura</oldsource>
        <translation>&amp;Configura</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="225"/>
        <source>&amp;About</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="228"/>
        <source>About</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="236"/>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Mount Point</source>
        <translation>Punto di Mount</translation>
    </message>
    <message>
        <source>Crypted Directory</source>
        <translation type="obsolete">Directory Criptata</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <source>Easy manager for encrypted filesystem</source>
        <translation>Semplice manager di filesystem criptati</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>FileSystem ID</source>
        <translation>ID FileSystem</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Status</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Encrypted Directory</source>
        <translation>Directory Criptata</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Encfs Options</source>
        <translation>Opzioni Encfs</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <source>Fuse Options</source>
        <translation>Opzioni Fuse</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="116"/>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="117"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="118"/>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="119"/>
        <source>Mount</source>
        <translation>Monta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="120"/>
        <source>Umount</source>
        <translation>Smonta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="121"/>
        <source>Browse</source>
        <oldsource>Browse FS</oldsource>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="290"/>
        <source>Do really you want to remove FileSystem &apos;</source>
        <translation>Vuoi veramente rimuovere il FileSystem &apos;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="291"/>
        <source>Remove FileSystem</source>
        <translation>Rimozione FileSystem</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="356"/>
        <source>Mounted</source>
        <oldsource>Montato</oldsource>
        <translation>Montato</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="375"/>
        <source>File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="521"/>
        <source>Donations</source>
        <translation>Donazioni</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="521"/>
        <source>Please, consider to make a &lt;a href=&apos;https://www.linux-apps.com/p/1170068/&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation>Per favore, considera la possibilità di fare una &lt;a href=&apos;https://www.linux-apps.com/p/1170068/&apos;&gt;DONAZIONE&lt;/a&gt; per il mio lavoro.
Se ti piace questa applicazione, per favore dona qualcosa.
Tutto il denaro ricavato verrà donato in favore di meritorie iniziative di carità.</translation>
    </message>
    <message>
        <source>Please, consider to make a &lt;a href=&apos;https://www.linux-apps.com/p/1127802/&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="vanished">Per favore, considera la possibilità di fare una &lt;a href=&apos;https://www.linux-apps.com/p/1170068/&apos;&gt;DONAZIONE&lt;/a&gt; per il mio lavoro.
Se ti piace questa applicazione, per favore dona qualcosa.
Tutto il denaro ricavato verrà donato in favore di meritorie iniziative di carità.</translation>
    </message>
    <message>
        <source>Please, consider to make a &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="vanished">Per favore, considera la possibilità di fare una &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Donazione&lt;/a&gt; per questa applicazione.
Se hai trovato utile questa applicazione, per cortesia, dona una piccola cifra.
Tutto il denaro ricavato verrà utilizzato per iniziative caritatevoli e meritorie.

</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>I couldn&apos;t detect any system tray on this system.</source>
        <translation type="vanished">Non ho trovato nessun vassoio di sistema in questo sisistema</translation>
    </message>
</context>
<context>
    <name>configDialog</name>
    <message>
        <location filename="configdialog.ui" line="14"/>
        <source>KEncFS - Confguration</source>
        <oldsource>KEncFS - Configurazione</oldsource>
        <translation>KEncFS - Configurazione</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="59"/>
        <source>&amp;Start in TrayBar</source>
        <oldsource>Start in TrayBar</oldsource>
        <translation>&amp;Avvia nel vassoio di sistema</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="85"/>
        <location filename="configdialog.cpp" line="44"/>
        <source>Icon&apos;s Selection</source>
        <translation>Selezione Icona</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="140"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="22"/>
        <source>&amp;Use KDE Wallet</source>
        <translation>&amp;Usa KDE Wallet</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="42"/>
        <source>&amp;Try AutoMount on start (KDE Wallet must be enabled)</source>
        <translation>Tenta AutoMount alla partenza (KDE Wallet abilitato)</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="32"/>
        <source>&amp;Browse after mount (not for AutoMount function) </source>
        <oldsource>&amp;Browse after mount</oldsource>
        <translation>A&amp;pri dopo aver montato (non attivo con Automount)</translation>
    </message>
</context>
<context>
    <name>fsDialog</name>
    <message>
        <location filename="fsdialog.ui" line="14"/>
        <source>KEncFs - Add FileSystem</source>
        <translation>KEncFs - Aggiungi FileSystem</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="32"/>
        <source>FileSystem ID</source>
        <translation>ID FileSystem</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="46"/>
        <source>Mountpoint</source>
        <oldsource>Punto di mount</oldsource>
        <translation>Punto di Mount</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="60"/>
        <location filename="fsdialog.ui" line="81"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="67"/>
        <source>Encrypted Directory</source>
        <oldsource>Crypted Directory</oldsource>
        <translation>Directory Criptata</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="88"/>
        <source>Auto &amp;Umount after 10 mins of inactivity</source>
        <translation>&amp;AutoSmontaggio dopo 10 minuti di inattività</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="95"/>
        <source>Advanced &amp;Options</source>
        <translation>&amp;Opzioni Avanzate</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="106"/>
        <source>Encfs options</source>
        <translation>Opzioni Encfs</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="124"/>
        <source>Fuse options</source>
        <translation>Opzioni Fuse</translation>
    </message>
    <message>
        <source>Select encrypted existing directory or create new</source>
        <oldsource>Select crypted existing directory or create new</oldsource>
        <translation type="vanished">Seleziona la directory criptata o creane una nuova</translation>
    </message>
    <message>
        <source>Select mountpoint existing directory or create new</source>
        <translation type="vanished">Seleziona la directory per montaggio del FS o creane una nuova</translation>
    </message>
    <message>
        <source>Mounted</source>
        <oldsource>Montato</oldsource>
        <translation type="vanished">Montato</translation>
    </message>
    <message>
        <source>Fatal Error</source>
        <oldsource>Errore fatale</oldsource>
        <translation type="vanished">Errore Fatale</translation>
    </message>
    <message>
        <source>Warning! &apos;encfs&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Attenzione! &apos;encfs&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <source>Warning! &apos;fusermount&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Attenzione! &apos;fusermount&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <source>Warning! &apos;dolphin&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Attenzione! &apos;dolphin&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <source>Warning! MountPoint directory doesn&apos;t exists

</source>
        <translation type="vanished">Attenzione! La directory ove montare il filesystem non esiste

</translation>
    </message>
    <message>
        <source>Warning! Encrypted directory doesn&apos;t exists

</source>
        <translation type="vanished">Attenzione! La directory criptata non esiste

</translation>
    </message>
    <message>
        <source>Password for Encrypted FileSystem:</source>
        <translation type="vanished">Password per il FileSystem Criptato:</translation>
    </message>
    <message>
        <source>Mount Error!

</source>
        <translation type="vanished">Errore di Montaggio</translation>
    </message>
    <message>
        <source>Error returned from Encfs:
</source>
        <oldsource>Encfs returns:
</oldsource>
        <translation type="vanished">Errore restituito da Encfs:</translation>
    </message>
    <message>
        <source>Mount error!

</source>
        <translation type="obsolete">Errore di montaggio!

</translation>
    </message>
    <message>
        <source>Warning! Crypted directory doesn&apos;t exists

</source>
        <translation type="obsolete">Attenzione! La directory criptata non esiste

</translation>
    </message>
    <message>
        <source>Password Request</source>
        <oldsource>Richiesta Password</oldsource>
        <translation type="vanished">Richiesta password</translation>
    </message>
</context>
</TS>
