<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>MainWindow</name>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>&amp;Add</source>
        <translation>&amp;Добавить</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation>&amp;Выход</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="obsolete">&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Hide</source>
        <translation>&amp;Скрыть</translation>
    </message>
    <message>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <source>Mount</source>
        <translation>Подключить</translation>
    </message>
    <message>
        <source>&amp;Hide / Show</source>
        <translation>&amp;Скрыть / Показать</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;О программе</translation>
    </message>
    <message>
        <source>&amp;Mount</source>
        <translation>&amp;Подключить</translation>
    </message>
    <message>
        <source>Hide / Show</source>
        <translation>Скрыть / Показать</translation>
    </message>
    <message>
        <source>Mounted</source>
        <translation>Подключено</translation>
    </message>
    <message>
        <source>Donations</source>
        <translation>Пожертвования</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <source>Config</source>
        <translation>Настроить</translation>
    </message>
    <message>
        <source>Encrypted FileSystem</source>
        <translation>Зашифрованная файловая система</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Состояние</translation>
    </message>
    <message>
        <source>Umount</source>
        <translation>Отключить</translation>
    </message>
    <message>
        <source>Mount Point</source>
        <translation>Точка монтирования</translation>
    </message>
    <message>
        <source>Remove FileSystem</source>
        <translation>Удалить файловую систему</translation>
    </message>
    <message>
        <source>FileSystem ID</source>
        <translation>Идентификатор файловой системы</translation>
    </message>
    <message>
        <source>Easy manager for encrypted filesystem</source>
        <translation>Простой менеджер шифрования файловой системы</translation>
    </message>
    <message>
        <source>&amp;Browse</source>
        <translation>О&amp;бзор</translation>
    </message>
    <message>
        <source>&amp;Config</source>
        <translation>&amp;Настроить</translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <source>&amp;Umount</source>
        <translation>&amp;Отключить</translation>
    </message>
    <message>
        <source>Do really you want to remove FileSystem &apos;</source>
        <translation>Вы действительно хотите удалить файловую систему &apos;</translation>
    </message>
    <message>
        <source>Encrypted Directory</source>
        <translation>Зашифрованная директория</translation>
    </message>
    <message>
        <source>Please, consider to make a &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="vanished">Пожалуйста, сделайте здесь &lt;a href=&apos;http://kde-apps.org/content/donate.php?content=134003&apos;&gt;Пожертвование&lt;/a&gt; для моей работы.
Если вам нравится это приложение, пожалуйста, пожертвуйте что-нибудь.
Все собранные деньги будут переданы на благотворительные цели для благих инициатив.

</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>E&amp;dit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encfs Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuse Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please, consider to make a &lt;a href=&apos;https://www.linux-apps.com/p/1170068/&apos;&gt;Donation&lt;/a&gt; for my work.
If you like this application, please donate something.
All money raised will be donated to charity for meritorious initiatives.

</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>configDialog</name>
    <message>
        <source>&amp;Start in TrayBar</source>
        <translation>&amp;Запускать в системном лотке</translation>
    </message>
    <message>
        <source>&amp;Browse after mount (not for AutoMount function) </source>
        <translation>&amp;Обзор после подключения (не применяется для функции автоматического монтирования)</translation>
    </message>
    <message>
        <source>KEncFS - Confguration</source>
        <translation>Конфигурация - KEncFS</translation>
    </message>
    <message>
        <source>&amp;Use KDE Wallet</source>
        <translation>&amp;Использовать бумажник KDE</translation>
    </message>
    <message>
        <source>&amp;Try AutoMount on start (KDE Wallet must be enabled)</source>
        <translation>&amp;Пытаться автоматически монтировать при запуске (бумажник KDE должен быть включен)</translation>
    </message>
    <message>
        <source>Icon&apos;s Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>fsDialog</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Error returned from Encfs:
</source>
        <translation type="vanished">Encfs возвратил ошибку:</translation>
    </message>
    <message>
        <source>Warning! &apos;fusermount&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Внимание! &apos;fusermount&apos;&apos; не установлен.

Установите его!

</translation>
    </message>
    <message>
        <source>Select mountpoint existing directory or create new</source>
        <translation type="vanished">Выбрать существующую точку монтирования или создать новую</translation>
    </message>
    <message>
        <source>Password Request</source>
        <translation type="vanished">Требуется пароль</translation>
    </message>
    <message>
        <source>Password for Encrypted FileSystem:</source>
        <translation type="vanished">Пароль для зашифрованной файловой системы:</translation>
    </message>
    <message>
        <source>Mounted</source>
        <translation type="vanished">Подключено</translation>
    </message>
    <message>
        <source>Mountpoint</source>
        <translation>Точка монтирования</translation>
    </message>
    <message>
        <source>Warning! Encrypted directory doesn&apos;t exists

</source>
        <translation type="vanished">Внимание! Зашифрованного каталога не существует

</translation>
    </message>
    <message>
        <source>Warning! &apos;dolphin&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Внимание! &apos;dolphin&apos; не установлен.

Установите его!

</translation>
    </message>
    <message>
        <source>FileSystem ID</source>
        <translation>Идентификатор файловой системы</translation>
    </message>
    <message>
        <source>Select encrypted existing directory or create new</source>
        <translation type="vanished">Выбрать существующий зашифрованный каталог или создать новый</translation>
    </message>
    <message>
        <source>Warning! &apos;encfs&apos; is not installed.

Please, install it!

</source>
        <translation type="vanished">Внимание! &apos;encfs&apos; не установлен.

Установите его!

</translation>
    </message>
    <message>
        <source>KEncFs - Add FileSystem</source>
        <translation>Добавить файловую систему</translation>
    </message>
    <message>
        <source>Fatal Error</source>
        <translation type="vanished">Критическая ошибка</translation>
    </message>
    <message>
        <source>Encrypted Directory</source>
        <translation>Зашифрованная директория</translation>
    </message>
    <message>
        <source>Warning! MountPoint directory doesn&apos;t exists

</source>
        <translation type="vanished">Внимание! Каталог точки монтирования не существует

</translation>
    </message>
    <message>
        <source>Mount Error!

</source>
        <translation type="vanished">Ошибка монтироования!

</translation>
    </message>
    <message>
        <source>Auto &amp;Umount after 10 mins of inactivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced &amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Encfs options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuse options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
