<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="fr">
<context>
    <name>ConfirmWindow</name>
    <message>
        <location filename="confirm.py" line="92"/>
        <source>Confirmation</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="confirm.py" line="93"/>
        <source>Je comprend les risques et j&apos;accepte les termes du contrat</source>
        <translation>I Understand the risk and i accept the terms of the contract </translation>
    </message>
    <message>
        <location filename="confirm.py" line="94"/>
        <source>Confirmer</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="confirm.py" line="95"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="preference.py" line="632"/>
        <source>Parcourir</source>
        <translation>Browse</translation>
    </message>
    <message>
        <location filename="preference.py" line="631"/>
        <source>Appliquer ce profil au demarrage de nvidiux</source>
        <translation>apply this profile at nvidiux startup</translation>
    </message>
    <message>
        <location filename="preference.py" line="633"/>
        <source>Appliquer ce profil au demarrage du systeme</source>
        <translation>apply this profile at system startup</translation>
    </message>
    <message>
        <location filename="preference.py" line="444"/>
        <source>Aucun profil</source>
        <translation type="obsolete">No profile</translation>
    </message>
    <message>
        <location filename="preference.py" line="636"/>
        <source>Actualiser les donnees toutes les</source>
        <translation>Refresh data any</translation>
    </message>
    <message>
        <location filename="preference.py" line="637"/>
        <source> secondes</source>
        <translation>seconds</translation>
    </message>
    <message>
        <location filename="preference.py" line="638"/>
        <source>Nvidiux</source>
        <translation>Nvidiux</translation>
    </message>
    <message>
        <location filename="preference.py" line="639"/>
        <source>Moniteur</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <location filename="preference.py" line="640"/>
        <source>A Propos</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="preference.py" line="455"/>
        <source>Langue</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="preference.py" line="509"/>
        <source>Rafraichissement continu</source>
        <translation>continuous refresh</translation>
    </message>
    <message>
        <location filename="preference.py" line="576"/>
        <source>Permet d&apos;underclocker ou d&apos;overclocker votre gpu nvidia
(C) 2014 Payet Guillaume
Nvidiux n&apos;est en aucun cas affiliÃ© Ã  Nvidia</source>
        <translation type="obsolete">Allows you underclock or overclock your nvidia gpu
(C) 2014 Payet Guillaume
Nvidiux is no way affiliated to nvidia</translation>
    </message>
    <message>
        <location filename="preference.py" line="108"/>
        <source>Impossible de continuer</source>
        <translation>unable to continue</translation>
    </message>
    <message>
        <location filename="preference.py" line="116"/>
        <source>Auto chargement profil desactive</source>
        <translation>load profile disabled</translation>
    </message>
    <message>
        <location filename="preference.py" line="252"/>
        <source>Ãchec</source>
        <translation type="obsolete">Failure</translation>
    </message>
    <message>
        <location filename="preference.py" line="130"/>
        <source>Erreur Interne</source>
        <translation>Internal error</translation>
    </message>
    <message>
        <location filename="preference.py" line="137"/>
        <source>Chargement profil au demarage desactive</source>
        <translation>Auto startup load disabled</translation>
    </message>
    <message>
        <location filename="preference.py" line="195"/>
        <source>Erreur Credential</source>
        <translation>Credential Error</translation>
    </message>
    <message>
        <location filename="preference.py" line="195"/>
        <source>Votre mot de passe est incorrect</source>
        <translation>Wrong password</translation>
    </message>
    <message>
        <location filename="preference.py" line="186"/>
        <source>Erreur non gÃ©rÃ©e</source>
        <translation type="obsolete">Error</translation>
    </message>
    <message>
        <location filename="preference.py" line="188"/>
        <source>Le profil:</source>
        <translation>This profil:</translation>
    </message>
    <message>
        <location filename="preference.py" line="176"/>
        <source>
sera chargÃ© Ã  chaque dÃ©marrage du systeme</source>
        <translation type="obsolete">is loading on startup</translation>
    </message>
    <message>
        <location filename="preference.py" line="205"/>
        <source>Fichier:</source>
        <translation>File:</translation>
    </message>
    <message>
        <location filename="preference.py" line="212"/>
        <source>Impossible de modifier la configuration</source>
        <translation>Unable to modify configuration</translation>
    </message>
    <message>
        <location filename="preference.py" line="211"/>
        <source>Fichier endommagÃ©</source>
        <translation type="obsolete">Corrupted file</translation>
    </message>
    <message>
        <location filename="preference.py" line="225"/>
        <source>Impossible de charger ce fichier de configuration</source>
        <translation>Unable to load this config file</translation>
    </message>
    <message>
        <location filename="preference.py" line="252"/>
        <source>Ãchec chargement du profil</source>
        <translation type="obsolete">Failure load this profile</translation>
    </message>
    <message>
        <location filename="preference.py" line="253"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="preference.py" line="253"/>
        <source>Le profil est pour une version plus recente de Nvidiux
Charger tous de mÃªme ?</source>
        <translation>This profile is for a more recent version of nvidiux
Load anyway ?</translation>
    </message>
    <message>
        <location filename="preference.py" line="352"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="preference.py" line="352"/>
        <source>Veuillez redemarer nvidiux</source>
        <translation>Please restart nvidiux</translation>
    </message>
    <message>
        <location filename="preference.py" line="635"/>
        <source>Activer overvoltage</source>
        <translation>Enable Overvolting</translation>
    </message>
    <message>
        <location filename="preference.py" line="356"/>
        <source>Attention</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="preference.py" line="324"/>
        <source>Fonction reservÃ© aux experts.
Modifier le voltage du gpu peut causer des dommages irrÃ©versibles et annule la garantie.
Activer tous de mÃªme cette fonction ?</source>
        <translation type="obsolete">This fonction is expert bassed
change gpu voltage may result irreversible damage and void warrant
Continue and enable this feature ?  </translation>
    </message>
    <message>
        <location filename="preference.py" line="566"/>
        <source>Afficher ce gpu</source>
        <translation>Show Gpu</translation>
    </message>
    <message>
        <location filename="preference.py" line="277"/>
        <source>Echec</source>
        <translation>Fail</translation>
    </message>
    <message>
        <location filename="preference.py" line="277"/>
        <source>Echec chargement du profil</source>
        <translation>Unable to load profile</translation>
    </message>
    <message>
        <location filename="preference.py" line="334"/>
        <source>Fonction reservÃ© aux experts.
Modifier le voltage du gpu peut causer des dommages irrÃ©versibles et annule la garantie.
Nvidiux n&apos;est pas responsable des eventuels dommages due a une utilisation de cette fonction
Activer tous de mÃªme cette fonctionnalitÃ© ?</source>
        <translation type="obsolete">This fonction is expert bassed
change gpu voltage may result irreversible damage and void warrant
nvidiux and this author is not responsible for responsible of bad use and no liability for damages, direct or consequential, which may result from this fonction
Continue and enable this feature ?</translation>
    </message>
    <message>
        <location filename="preference.py" line="198"/>
        <source>Erreur non geree</source>
        <translation>unhandled error</translation>
    </message>
    <message>
        <location filename="preference.py" line="188"/>
        <source>
sera charge Ã  chaque demarrage du systeme</source>
        <translation>is load at system startup</translation>
    </message>
    <message>
        <location filename="preference.py" line="225"/>
        <source>Fichier endommage</source>
        <translation>corrupt file</translation>
    </message>
    <message>
        <location filename="preference.py" line="605"/>
        <source>Permet d&apos;underclocker ou d&apos;overclocker votre gpu nvidia
(C) 2014 Payet Guillaume
Nvidiux n&apos;est en aucun cas affilie Ã  Nvidia</source>
        <translation>Permit underclock or overclock your nvidia gpu
(c) 2014 Payet Guillaume
Nvidiux is no way affiliated to Nvidia</translation>
    </message>
    <message>
        <location filename="preference.py" line="629"/>
        <source>Preferences</source>
        <translation>Settings</translation>
    </message>
    <message>
        <location filename="preference.py" line="356"/>
        <source>Fonction reserve aux experts.
Modifier le voltage du gpu peut causer des dommages irreversibles et annule la garantie.
Nvidiux n&apos;est pas responsable des eventuels dommages due a une utilisation de cette fonction
Activer tous de mÃªme cette fonctionnalite ?</source>
        <translation>This function is expert based
Modify gpu voltage may cause irreversible damage and void the warranty.
Nvidiux is not responsible for any damage caused by thtis feature
continue and enable this feature ?
</translation>
    </message>
    <message>
        <location filename="preference.py" line="498"/>
        <source>Appliquer les meme parametres a des gpu identique</source>
        <translation>Apply same param for identical gpu</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="nvidiux.py" line="603"/>
        <source>Information</source>
        <translation type="obsolete">Information</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="538"/>
        <source>Nvidiux</source>
        <translation>Nvidiux</translation>
    </message>
    <message>
        <location filename="windows.py" line="504"/>
        <source>Mémoire</source>
        <translation type="obsolete">memory</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="536"/>
        <source>Shader</source>
        <translation>Shader</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="537"/>
        <source>Gpu</source>
        <translation>Gpu</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="539"/>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="540"/>
        <source>Appliquer</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="windows.py" line="509"/>
        <source>Version XXX</source>
        <translation type="obsolete">Version XXX</translation>
    </message>
    <message>
        <location filename="windows.py" line="505"/>
        <source>i</source>
        <translation type="obsolete">I</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="542"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="543"/>
        <source>Fan</source>
        <translation>Fan</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="573"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="574"/>
        <source>Configurer</source>
        <translation>Configure</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="571"/>
        <source>Moniteur</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="577"/>
        <source>Charger</source>
        <translation>Load</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="552"/>
        <source>Enregister</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="553"/>
        <source>Profil</source>
        <translation>Profile</translation>
    </message>
    <message>
        <location filename="windows.py" line="519"/>
        <source>Nom gpu</source>
        <translation type="obsolete">Gpu Name</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="556"/>
        <source>Mhz</source>
        <translation>Mhz</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="557"/>
        <source>Optimus</source>
        <translation>Optimus</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="558"/>
        <source>Sli</source>
        <translation>Sli</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="559"/>
        <source>Vaapi</source>
        <translation>Vaapi</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="560"/>
        <source>VSync</source>
        <translation>Vsync</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="562"/>
        <source>Version pilote</source>
        <translation>Driver version</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="563"/>
        <source>OpenGl Support</source>
        <translation>OpenGL Support</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="564"/>
        <source>Mem Gpu</source>
        <translation>Gpu memory</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="565"/>
        <source>Cudacore</source>
        <translation>Cuda Core</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="566"/>
        <source>Gpu utilisation</source>
        <translation>Gpu use</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="567"/>
        <source>Mem utilisation</source>
        <translation>Mem use</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="568"/>
        <source>Pcie utili</source>
        <translation>PCIE use</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="569"/>
        <source>Temp</source>
        <translation>Temp</translation>
    </message>
    <message>
        <location filename="windows.py" line="535"/>
        <source>Img</source>
        <translation type="obsolete">Img</translation>
    </message>
    <message>
        <location filename="windows.py" line="538"/>
        <source>Mem</source>
        <translation type="obsolete">Mem</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="570"/>
        <source>Fichier</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="572"/>
        <source>Quitter</source>
        <translation>Quit</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="575"/>
        <source>A Propos</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="578"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="535"/>
        <source>Memoire</source>
        <translation>Memory</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="576"/>
        <source>Preferences</source>
        <translation>Pref</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="544"/>
        <source>Lancer</source>
        <translation>Launch</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="548"/>
        <source>Overvolt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="561"/>
        <source>Max Perf</source>
        <translation>Max perf</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="547"/>
        <source>0 Î¼v</source>
        <translation>μv</translation>
    </message>
    <message>
        <location filename="Ui_Nvidiux.py" line="549"/>
        <source> Î¼v</source>
        <translation>μv</translation>
    </message>
</context>
<context>
    <name>nvidiux</name>
    <message>
        <location filename="nvidiux.py" line="677"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="124"/>
        <source>Temperature</source>
        <translation>Temperature</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="134"/>
        <source>Utilisation Bus PCIE</source>
        <translation>PCIE Use</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="135"/>
        <source>Utilisation Gpu</source>
        <translation>Gpu use</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="147"/>
        <source>Utilisation Memoire</source>
        <translation>Memory Use</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="165"/>
        <source>Start</source>
        <translation type="obsolete">Start</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="986"/>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="986"/>
        <source>Etes vous sur de vouloir quitter sans appliquer les modifications ?</source>
        <translation>Are you sure exit without applying change?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="380"/>
        <source>Echec
changement vitesse ventillo</source>
        <translation>Fail change speed fan</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="402"/>
        <source>Driver introuvable 
Veuillez installer les pilotes proprietaires</source>
        <translation>Missing drivers please install nvidia proprietary driver</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="404"/>
        <source>Nvidia settings introuvable 
veuillez installer les pilotes proprietaires et nvidia settings</source>
        <translation>Please install nvidia proprietary drivers</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="379"/>
        <source>Seul prime est supportÃ© pour les configurations optimus</source>
        <translation type="obsolete">Only Prime is support</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="416"/>
        <source>Configuration Prime
Veuillez passer en mode nvidia svp</source>
        <translation>Please use nvidia mode in nvidia settings</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="423"/>
        <source>Xorg.conf</source>
        <translation>Xorg.conf</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="388"/>
        <source>Pas de fichier xorg.conf en gÃ©nÃ©rer un ?</source>
        <translation type="obsolete">File Xorg.conf not found generate it ?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="957"/>
        <source>Erreur</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="425"/>
        <source>Vous devez avoir un fichier xorg.conf</source>
        <translation>You must generate an xorg.conf file</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="419"/>
        <source>Configuration effectuÃ©
Vous devez redÃ©marrer votre machine</source>
        <translation type="obsolete">Configuration complete
Restart your pc for use nvidiux</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="451"/>
        <source>Erreur configuration nvidiux</source>
        <translation>Errot configuration </translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="437"/>
        <source>Erreur Credential</source>
        <translation>Credential Error</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="437"/>
        <source>Votre mot de passe est incorrect</source>
        <translation>Wrong password</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="419"/>
        <source>RedÃ©marrage Requis</source>
        <translation type="obsolete">Restart is required</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="786"/>
        <source>Ãchec</source>
        <translation type="obsolete">Failure</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="482"/>
        <source>Impossible de determiner la version des drivers</source>
        <translation>Unable to detect your drivers version</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="462"/>
        <source>Driver non supportÃ© (trop ancien)!
Overclock desactivÃ©</source>
        <translation type="obsolete">Driver too old
Overclock is disable</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="497"/>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="496"/>
        <source>Driver non supporte (trop ancien)!
Overclock desactive</source>
        <translation>Driver too old
Disabled overclock</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="633"/>
        <source>Ãchec chargement des parametres Gpu</source>
        <translation type="obsolete">Unable to load gpu configuration</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="613"/>
        <source>incompatible(impossible de detecter la vitesse)</source>
        <translation>incompatible (unable to detect speed)</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="637"/>
        <source>incompatible</source>
        <translation>incomptatible</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="663"/>
        <source>Ce gpu </source>
        <translation>This gpu</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="661"/>
        <source> n&apos;est pas dans la liste blanche
n&apos;hesitez pas Ã  confirmer son fonctionnement</source>
        <translation>is not in white list
Please tell me if is work</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="673"/>
        <source>Gpu(</source>
        <translation>Gpu(</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="626"/>
        <source>)non supportÃ©</source>
        <translation type="obsolete">) not supported</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="728"/>
        <source>Version </source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="845"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="747"/>
        <source>Le fichier de configuration est pour une version plus recente de Nvidiux
Charger tous de mÃªme ?</source>
        <translation>The configuration file is for a more recent version of nvidiux
Load him ?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="739"/>
        <source>Fichier endommagÃ©</source>
        <translation type="obsolete">Corrupted file</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="817"/>
        <source>Impossible de charger ce fichier de configuration</source>
        <translation>Unable to load this config file</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="786"/>
        <source>Ãchec chargement du profil</source>
        <translation type="obsolete">Failure load this profile</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="845"/>
        <source>Le profil est pour une version plus recente de Nvidiux
Charger tous de mÃªme ?</source>
        <translation>This profile is for a more recent version of nvidiux
Load anyway ?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="957"/>
        <source>Erreur interne overclock/downclock impossible</source>
        <translation>Error fail overclock/downclock </translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="899"/>
        <source>Reset effectuÃ©</source>
        <translation type="obsolete">successful reset</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="843"/>
        <source>EffectuÃ©</source>
        <translation type="obsolete">Applied</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="843"/>
        <source>Changement effectuÃ©</source>
        <translation type="obsolete">changes made</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="846"/>
        <source>Overclock effectuÃ©</source>
        <translation type="obsolete">overclock complete</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="848"/>
        <source>Auto overclock effectuÃ©</source>
        <translation type="obsolete">auto overclock complete</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="982"/>
        <source>Echec</source>
        <translation>Fail</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="858"/>
        <source>L&apos;overclock Ã  Ã©chouÃ©</source>
        <translation type="obsolete">failed to overclock</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="860"/>
        <source>Le reset Ã  Ã©chouÃ©</source>
        <translation type="obsolete">failed to reset</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1150"/>
        <source>Impossible</source>
        <translation>unable</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1094"/>
        <source>Impossible de changer la configuration des ventillos</source>
        <translation>unable change fan configuration</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1110"/>
        <source>Impossible de revenir Ã  la configuration par defaut des ventillos</source>
        <translation>unable to load fan default config </translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1119"/>
        <source>Erreur communication</source>
        <translation>Communication error</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1119"/>
        <source>Impossible de communiquer avec le processus monitor</source>
        <translation>Unable to communicate with monitor process</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1142"/>
        <source>Impossible d&apos;activer la syncro vertical</source>
        <translation>Unable to enable sync refresh</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1150"/>
        <source>Impossible de desactiver la syncro vertical</source>
        <translation>Unable to disable sync refresh</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="704"/>
        <source>Memoire video</source>
        <translation>Video Memory</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="705"/>
        <source>NB coeur cuda</source>
        <translation>Number of cuda core</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="706"/>
        <source>Version du Pilote</source>
        <translation>Driver version</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="707"/>
        <source>OpenGl Support</source>
        <translation>OpenGL Support</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="168"/>
        <source>Lancer</source>
        <translation>Launch</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="663"/>
        <source> n&apos;est pas supporte 
(Overclock desactive !)</source>
        <translation>is not support
(Disabled Overclock !)</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="454"/>
        <source>Configuration effectue
Vous devez redemarrer votre machine</source>
        <translation>Configuration complete
Please restart your system</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="414"/>
        <source>Seul prime est supporte pour les configurations optimus</source>
        <translation>Only Prime is supported for optimus configuration</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="423"/>
        <source>Pas de fichier xorg.conf en generer un ?</source>
        <translation>File Xorg.conf not found generate it ?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="454"/>
        <source>Redemarrage Requis</source>
        <translation>you must restart your system</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="497"/>
        <source>Driver non supporte:trop ancien
Overclock desactive
Il vous faut la version 337.19 ou plus recent pour overclocker</source>
        <translation>Drivers too old
Disabled Overclock
You must install 337.19 version or newer</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="673"/>
        <source>)non supporte</source>
        <translation>) no support</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="817"/>
        <source>Fichier endommage</source>
        <translation>corrupt file</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1023"/>
        <source>Reset effectue</source>
        <translation>Reset complete</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="963"/>
        <source>Effectue</source>
        <translation>Succeed</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="963"/>
        <source>Changement effectue</source>
        <translation>Change successfuly</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="966"/>
        <source>Overclock effectue</source>
        <translation>Overclock complete</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="968"/>
        <source>Auto overclock effectue</source>
        <translation>auto overclock done</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="980"/>
        <source>L&apos;overclock Ã  echoue</source>
        <translation>Fail to overclock</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="982"/>
        <source>Le reset Ã  echoue</source>
        <translation>fail to reset</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="901"/>
        <source>Mode Performance</source>
        <translation>Performance Mode</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="901"/>
        <source>Passer en mode performance oblige votre gpu a fonctionner a sa frequence maximale
Cette fonction est deconseille si vous avez un portable sur batterie
voulez vous continuer ?</source>
        <translation>Switch to performance mode requires your gpu to operate at its maximum frequency
This is not recommended if you use a laptop
Continue anyway ?</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="906"/>
        <source>Impossible de passer en mode max perf</source>
        <translation>Unable to switch on performance mode</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="914"/>
        <source>Impossible de passer en mode adaptatif</source>
        <translation>unable to switch on adaptative mode</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="870"/>
        <source>Echec chargement du profil</source>
        <translation>unable load profile</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="1071"/>
        <source>Î¼v</source>
        <translation>μv</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="679"/>
        <source>Echec chargement des parametres Gpu</source>
        <translation>unable load gpu conf</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="919"/>
        <source>Confirmation</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="919"/>
        <source>Etes vous sur de vouloir appliquer cet overvolt  + </source>
        <translation>Are you sur apply this overvolting settings ? +</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="919"/>
        <source>Î¼v
Pour ce gpu: </source>
        <translation>μv
For this gpu:</translation>
    </message>
    <message>
        <location filename="nvidiux.py" line="923"/>
        <source>Echec application overvoltage</source>
        <translation>fail applying overvolt</translation>
    </message>
</context>
</TS>
