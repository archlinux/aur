Duty
====

It is a program that allows you to generate questions / homework LaTeX
randomly. You can choose either a period or a number of exercises


Installation
============

```
git clone https://github.com/Chipsterjulien/duty.git
python setup.py install
```


Usage
=====
```
python duty -h
```



License
=======
<a href="http://en.wikipedia.org/wiki/Gplv3#Version_3">GPL v3</a>
