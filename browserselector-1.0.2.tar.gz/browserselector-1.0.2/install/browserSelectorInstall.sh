#!/bin/bash

set -e

Dir=$(dirname "$0")

# Detect OS type
if [[ -f /etc/debian_version ]]; then
  OS="debian"
elif [[ -f /etc/arch-release ]]; then
  OS="arch"
else
  echo >&2 "Unsupported OS. This script supports Debian-based and Arch-based systems only."
  exit 1
fi

if [[ "$OS" == "debian" ]]; then
  apt update
  PyQtPackage=$(apt-cache search --names-only '^python3-pyqt[56]$' | awk '{print $1}' | sort -u | tail -1)

  if [[ -z "$PyQtPackage" ]]; then
    echo >&2 "No PyQT package available. Cannot install."
    exit 1
  fi

  Packages=(
    python3
    python3-xdg
    "$PyQtPackage"
  )

  # Install packages
  sudo apt install -y "${Packages[@]}"

elif [[ "$OS" == "arch" ]]; then
  PyQtPackage=$(pacman -Ss '^python-pyqt[56]$' | awk '{print $1}' | sort -u | tail -1)

  if [[ -z "$PyQtPackage" ]]; then
    echo >&2 "No PyQT package available. Cannot install."
    exit 1
  fi

  Packages=(
    python
    python-pyxdg
    "$PyQtPackage"
  )

  # Install packages
  sudo pacman -Syu --noconfirm --needed "${Packages[@]}"
fi

# Install the browserSelector.desktop file in a place where your DE can find it
mkdir -p ~/.local/share/applications ~/
ActualPath=$(readlink -e "$Dir/../source/browserSelector.py")
awk -v ActualPath="$ActualPath" '
  /^Exec=/ {
    print "Exec=" ActualPath " %U"
    next
  }
  { print }
' "$Dir/browserSelector.desktop" >~/.local/share/applications/browserSelector.desktop
