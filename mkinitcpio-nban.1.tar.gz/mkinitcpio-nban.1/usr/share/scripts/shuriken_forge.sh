#!/bin/bash
#
#  Written for Ninja OS by the development team.
#  licensed under the GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
#
# This is it, the script that makes shurikens. A shuriken combines syslinux
# and mkinitcpio-nban (Ninja Boot'n'Nuke) to make a single use self-wiping
# automated book and nuke solution on a thumb drive. Use with care. The wipe
# pattern is identical to zeroize. See bootanuke.sh for more information.

TARGET=""
REUSE="FALSE"
INERT="FALSE"
NBANONLY="FALSE"
BOOTLOADER="extlinux"
MOUNT_POINT="/mnt/shuriken"
KERNEL_NAME="default"

part_shuriken() {
    # This function creates a blank disk with EXT2 on it. parameter one is the
    # target.
    local -i exit=0
    local -i part_size=31 # size of partition in megabytes. makes the shuriken
                           # quicker than formating the entire drive.
    local target="$1"
    submsg "Formatting..."
    sudo dd if=/dev/zero of=${target} bs=128k count=1 &> /dev/null
    exit+=$?
    sync
    sudo parted -s ${target} mklabel msdos
    exit+=$?
    sudo parted -s ${target} -- mkpart primary 0 ${part_size} &> /dev/null
    exit+=$?
    sudo parted -s ${target} set 1 boot on
    exit+=$?
    sudo mkfs.ext2 -q -L SHURIKEN ${target}1
    exit+=$?
    sync
    return $exit
}

syslinux_install() {
    #install extlinux on the target. takes one parameter.
    local -i exit=0
    local target="$1"
    local mount_boot_dir="${MOUNT_POINT}/syslinux/"
    submsg "Installing bootloader..."
    sudo mkdir -p "${mount_boot_dir}"
    exit+=$?
    sudo cp -a /usr/lib/syslinux/bios/vesamenu.c32 "${mount_boot_dir}"

    sudo cp -a /usr/lib/syslinux/bios/chain.c32 "${mount_boot_dir}"
    sudo cp -a /usr/lib/syslinux/bios/libcom32.c32 "${mount_boot_dir}"
    sudo cp -a /usr/lib/syslinux/bios/libutil.c32 "${mount_boot_dir}"
    sudo cp -a /usr/lib/syslinux/bios/reboot.c32 "${mount_boot_dir}"

    #set correct kernel name.
    sed "s/vmlinuz-linux/vmlinuz-linux${KERNEL_NAME}/g" /usr/share/shuriken/extlinux.conf > /tmp/extlinux.conf
    exit+=$?

    sudo cp -fa /tmp/extlinux.conf "${mount_boot_dir}"
    exit+=$?
    sudo rm -f /tmp/extlinux.org
    exit+=$?
    sudo cp -a /usr/share/shuriken/shuriken.jpg "${mount_boot_dir}"
    exit+=$?
    sudo dd if=/usr/lib/syslinux/bios/mbr.bin of=${target} bs=440 count=1 &> /dev/null
    exit+=$?
    sync
    sudo extlinux --install "${mount_boot_dir}" &> /dev/null
    exit+=$?
    sync
    return $exit
}

set_immutable_all(){
    #set immutable bit on everything
    chattr -R +i "$MOUNT_POINT"
    return $?
}

check_nban() {
  #check if nban is already compiled
  if [ -f /boot/nban.img ];then
      echo "TRUE"
    else
      echo "FALSE" 
  fi
}

set_mount_point() {
  # make sure there is not a directory on our mount point, add a number and keep
  # incrementing until we find free name space
  local -i n=1
  local mount="$MOUNT_POINT"
  while [ -d "$MOUNT_POINT" ];do
    MOUNT_POINT="${mount}${n}"
    n+=1
  done
  sudo mkdir -p "$MOUNT_POINT"
  return $?
}

help_and_exit() {
  echo "$(tput bold)shuriken_forge.sh:$(tput sgr0)" 1>&2
  cat 1>&2 << EOF
This script makes a a Ninja Shuriken. A Shuriken is the Ninja OS Boot and Nuke
script combined with a basic extlinux bootloader on a USB stick.

Booting a shuriken will wipe all the storage media attached to the computer
including the shuriken, leaving blank FAT32 formated media. Block device is the
/dev/sdX name of the USB stick you want to use.

	Usage:
	$ shuriken_forge [-options] <block device>

	Switches:

	-?, --help		This message

	-r, --reuse-nban	reuses a build nban initcpio image. This must
				be in /boot/ on the host Ninja OS system.

	-k, --kernel-name	Specify the kernel name, the default for Arch
				Linux the default is "default". use "default" or
				"linux" for the vanilla Arch Linux kernel.

	-n, --nban-only		Compile Ninja Boot'N'Nuke initcpio image only.
				do not make a shuriken.

        	-NOT IMPLEMENTED YET-
	-i, --inert		Makes an inert shuriken, for testing purposes
				only.

	-b, --bootloader	Specify the type of bootloader. Three options:
				extlinux, isolinux, and pxelinux.

EOF
exit 1
}

exit_with_error() {
    # parameter 1 is exit code, 2 is message, be sure to quote the message.
    echo "$(tput bold)shuriken_forge.sh: $(tput setaf 1)ERROR:$(tput sgr0) $2" 1>&2
    sudo umount -f "${MOUNT_POINT}" &> /dev/null
    sudo rm -rf "${MOUNT_POINT}" &> /dev/null
    exit $1
}

create_initcpio_nban() {
    #Compile the Boot'N'Nuke image.
    local -i exit=0
    submsg "Generating Ninja Boot'n'Nuke .img file..."
    sudo cp -af /etc/mkinitcpio.d/nban.preset /tmp/nban.preset.orig
    sed "s/vmlinuz-linux/vmlinuz-linux${KERNEL_NAME}/g" /etc/mkinitcpio.d/nban.preset > /tmp/nban.preset
    exit+=$?
    sudo mv -f /tmp/nban.preset /etc/mkinitcpio.d/
    exit+=$?
    sudo mount -o rw,remount /boot
    exit+=$?
    sudo mkinitcpio -p nban &> /dev/null
    exit+=$?
    sudo mount -o ro,remount /boot
    sudo cp -af /tmp/nban.preset.orig /etc/mkinitcpio.d/nban.preset
    return $exit
}

copy_kernel_nban() {
    local -i exit=0
    submsg "Copying Kernel and Boot'n'Nuke image..."
    sudo cp -a /boot/nban.img "${MOUNT_POINT}"
    exit+=$?
    sudo cp -a /boot/vmlinuz-linux${KERNEL_NAME} "${MOUNT_POINT}"
    exit+=$?
    return $exit
}

clean_up() {
    local -i exit=0
    submsg "Cleaning up..."
    sudo umount -f "${MOUNT_POINT}"
    exit+=$?
    sudo rmdir "${MOUNT_POINT}"
    exit+=$?
    return $exit
}

nban_only() {
    #this only generates the nban mkinitcpio profile. It runs and exits.
    echo "$(tput bold;tput setaf 6)  --+$(tput setaf 7)Shuriken Forge$(tput setaf 6)+-- $(tput sgr0)"
    create_initcpio_nban
    [ $? -ne 0 ] && exit_with_error $? "Failed to make Boot'n'Nuke image, halting."
    message "Boot'n'Nuke image generation complete!"
    exit 0
}

message() {
    echo "$(tput bold)shuriken_forge.sh:$(tput sgr0) $@"
}
submsg() {
    echo "		   $@"
}
switch_checker() {
    PARMS=""
    while [ ! -z "$1" ];do
        case "$1" in
          --help|-\?)
            help_and_exit
            ;;
          --reuse-nban|-r)
            REUSE="TRUE"
            ;;
          --inert|-i)
            INERT="TRUE"
            ;;
          --nban-only|-n)
            NBANONLY="TRUE"
            ;;
          --kernel-name|-k)
            KERNAL_NAME=${2,,}
            shift
            ;;
          --bootloader|-b)
            BOOTLOADER=${2,,}
            shift
            ;;
          *)
            PARMS="${PARMS} $1"
            ;;
        esac
        shift
    done
}
main() {
    trap "exit_with_error 1 'Aborted!' " SIGINT SIGTERM #exit cleanly with an abort
    TARGET="$1"
    [[ ${NBANONLY} == "TRUE" ]] && nban_only
    [[ -z ${TARGET} ]] && help_and_exit
    [[ ! -b ${TARGET} ]] && exit_with_error 1 "${TARGET} is not a block device see --help"
    case $KERNEL_NAME in
      default|arch|linux)
        KERNEL_NAME=""
        ;;
      *)
        KERNEL_NAME="-${KERNEL_NAME}"
        ;;
    esac
    echo "$(tput bold;tput setaf 6)  --+$(tput setaf 7)Shuriken Forge$(tput setaf 6)+-- $(tput sgr0)"
    message "Making Shuriken on ${TARGET}"

    # generate the nban initcpio image. Lets do this first because it doesn't
    # The drive to be mounted
    REUSE=${REUSE,,} #lower case
    case ${REUSE} in
      false)
        create_initcpio_nban
        [ $? -ne 0 ] && exit_with_error $? "Failed to make Boot'n'Nuke image, halting."
        ;;
      true)
        [[ $(check_nban) == "FALSE" ]] && exit_with_error 1 "--reuse-nban selected, but no nban image can be found, see --help"
        true
        ;;
      *)
        exit_with_error 1 "bad REUSE= option, the script should never throw this error, debug"
        ;;
    esac

    #Partition the drive. one MBR partition, also, zerofill the beginning first
    part_shuriken "${TARGET}"
    [ $? -ne 0 ] && exit_with_error $? "partitioning failed, halting."

    # Mount the partion, we are going to stay mounted until we are done.
    set_mount_point
    [ $? -ne 0 ] && exit_with_error $? "Cannot create directory ${MOUNT_POINT}, halting."
    sudo mount -t ext2 ${TARGET}1 "${MOUNT_POINT}"
    [ $? -ne 0 ] && exit_with_error $? "Cannot mount ${TARGET}1 on ${MOUNT_POINT}, halting."

    #Install the bootloader extlinux
    syslinux_install "${TARGET}"
    [ $? -ne 0 ] && exit_with_error $? "Bootloader install failed, halting."

    #Copy the kernel and the nban.img we made earlier
    copy_kernel_nban
    [ $? -ne 0 ] && exit_with_error $? "Failed to copy Boot'n'Nuke and/or kernel"
    sync

    #unmount the partition and remove the mount point
    clean_up
    [ $? -ne 0 ] && exit_with_error $? "Cleanup failed, since we got this far the shuriken most likely works, but you'll need to clean up /mnt/ manually"

    message "Shuriken is ready on ${TARGET} $(tput bold;tput setaf 6)DONE!$(tput sgr0)"
    exit 0
}
switch_checker "${@}"
main ${PARMS}
