Add  "Extract here", "Extract in folder", "Compress" context menu to dolphin using file-roller. 

Copied from https://store.kde.org/p/998273/. I can't figure out how to dowload from store.kde.com from a PKGBUILD, so here we are. 

Install by copying the .desktop files into /usr/share/kservices5/ServiceMenus/ or ~/.local/share/kservices5/ServiceMenus/