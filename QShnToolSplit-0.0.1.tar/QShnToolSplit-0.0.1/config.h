//-----------------------------------------------------------------------------
#ifndef CONFIG_H
#define CONFIG_H
//-----------------------------------------------------------------------------
#include <QSettings>
#include <QStringList>
//-----------------------------------------------------------------------------
class Config
{
    QSettings *settings;

    public:

        QStringList mediaFileExts, outputFormat;
        int defaultOutputDir;
        QString defaultInputDir, customOutputDir;

        Config(QObject *parent);
        ~Config();

        void saveDefault();
        void save();
        void read();
};
//-----------------------------------------------------------------------------
#endif // CONFIG_H
//-----------------------------------------------------------------------------
