//-----------------------------------------------------------------------------
#include "config.h"
//-----------------------------------------------------------------------------
#include <QDir>
#include <QMessageBox>
//-----------------------------------------------------------------------------
Config::Config(QObject *parent)
{
    settings = new QSettings("Longinus Software", "QShnToolSplit", parent);
}
//-----------------------------------------------------------------------------
Config::~Config()
{
    delete settings;
}
//-----------------------------------------------------------------------------
void Config::saveDefault()
{
    settings->setValue("FIRST_START", false);
    settings->setValue("DEFAULT_INPUT_DIRECTORY", QDir::homePath());
    settings->setValue("MEDIA_FILE_EXTENSIONS",
                       QStringList() << "*.flac" << "*.ape" << "*.wv");
    settings->setValue("OUTPUT_FORMAT",
                       QStringList() << "flac" << "ape" << "cust ext=mp3 lame -b320 -ms %f");
    settings->setValue("DEFAULT_OUTPUT_DIRECTORY", 1);
    settings->setValue("CUSTOM_OUTPUT_DIRECTORY", QDir::homePath());
}
//-----------------------------------------------------------------------------
void Config::save()
{
    mediaFileExts.removeAll("");
    outputFormat.removeAll("");

    settings->setValue("DEFAULT_INPUT_DIRECTORY", defaultInputDir);
    settings->setValue("MEDIA_FILE_EXTENSIONS", mediaFileExts);
    settings->setValue("OUTPUT_FORMAT", outputFormat);
    settings->setValue("DEFAULT_OUTPUT_DIRECTORY", defaultOutputDir);
    settings->setValue("CUSTOM_OUTPUT_DIRECTORY", customOutputDir);
}
//-----------------------------------------------------------------------------
void Config::read()
{
    if (settings->value("FIRST_START", true).toBool())
        saveDefault();

    defaultInputDir = settings->value("DEFAULT_INPUT_DIRECTORY").toString();
    defaultOutputDir = settings->value("DEFAULT_OUTPUT_DIRECTORY").toInt();
    customOutputDir = settings->value("CUSTOM_OUTPUT_DIRECTORY").toString();
    mediaFileExts = settings->value("MEDIA_FILE_EXTENSIONS").toStringList();
    outputFormat = settings->value("OUTPUT_FORMAT").toStringList();
}
//-----------------------------------------------------------------------------
