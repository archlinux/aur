//-----------------------------------------------------------------------------
#ifndef MAINWINDOW_H
#define MAINWINDOW_H
//-----------------------------------------------------------------------------
#include "PreferenceDialog.h"
#include "config.h"
//-----------------------------------------------------------------------------
#include "ui_MainWindow.h"

#include <QtGui/QMainWindow>
#include <QDirModel>
#include <QProcess>
//-----------------------------------------------------------------------------
class MainWindow : public QMainWindow, public Ui_MainWindowClass
{
    Q_OBJECT

public:

    QDirModel *dirModel;

    PreferenceDialog *prefDlg;
    Config *config;
    QList<QProcess*> processes;

    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    QString getFullPath(QModelIndex modelIndex);
    void on_fsLevelUp_clicked();
    void on_fsTW_activated(QModelIndex modelIndex);
    void on_fsTW_expanded(QModelIndex modelIndex);
    void on_actionPreference_activated();
    void on_outputDirTB_clicked();
    void on_actionStart_process_activated();
    void on_actionAbout_Qt_activated();
    void on_actionAbout_activated();
    void process_finished(int exitCode, QProcess::ExitStatus exitStatus);
    void on_actionExit_activated();

public slots:

    bool setFSBrowserPath(QString path);

};
//-----------------------------------------------------------------------------
#endif // MAINWINDOW_H
//-----------------------------------------------------------------------------
