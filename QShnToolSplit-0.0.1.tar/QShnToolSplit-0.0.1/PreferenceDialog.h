//-----------------------------------------------------------------------------
#ifndef PREFERENCEDIALOG_H
#define PREFERENCEDIALOG_H
//-----------------------------------------------------------------------------
#include "config.h"
//-----------------------------------------------------------------------------
#include "ui_PreferenceDialog.h"

#include <QtGui/QDialog>
//-----------------------------------------------------------------------------
class PreferenceDialog : public QDialog, public Ui_PreferenceDialogClass
{
    Q_OBJECT

public:
    
    Config *config;

    PreferenceDialog(QWidget *parent, Config *_config);

private slots:

    void on_defaultHomeRB_clicked(bool checked);
    void on_defaultCurrentRB_clicked(bool checked);
    void on_customOutputDirRB_clicked(bool checked);
    void on_defaultInputDirTB_clicked();
    void on_customOutputDirTB_clicked();
    void on_buttonBox_accepted();
    void on_buttonBox_rejected();

public slots:

    void readSettings();
    bool saveSettings();

};
//-----------------------------------------------------------------------------
#endif // PREFERENCEDIALOG_H
//-----------------------------------------------------------------------------
