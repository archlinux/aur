//-----------------------------------------------------------------------------
#include "MainWindow.h"
#include "ui_MainWindow.h"
//-----------------------------------------------------------------------------
#include <QDir>
#include <QMessageBox>
#include <QFileDialog>
//-----------------------------------------------------------------------------
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUi(this);

    fsLevelUp->setIcon(style()->standardIcon(QStyle::SP_ArrowUp));
    outputDirTB->setIcon(style()->standardIcon(QStyle::SP_DialogOpenButton));
    actionStart_process->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    actionPreference->setIcon(style()->standardIcon(QStyle::SP_FileDialogDetailedView));
    actionExit->setIcon(style()->standardIcon(QStyle::SP_TitleBarCloseButton));
    actionAbout->setIcon(style()->standardIcon(QStyle::SP_DialogHelpButton));

    config = new Config(this);
    config->read();

    dirModel = new QDirModel;
    fsTW->setModel(dirModel);

    prefDlg = new PreferenceDialog(this, config);

    switch (config->defaultOutputDir)
    {
       case 0: outputDirLE->setText(QDir::homePath()); break;
       case 1: outputDirLE->setText(fsPathLE->text()); break;
       case 2: outputDirLE->setText(config->customOutputDir); break;
    }

    outputFormatCB->addItems(config->outputFormat);
    setFSBrowserPath(config->defaultInputDir);
}
//-----------------------------------------------------------------------------
MainWindow::~MainWindow()
{
    delete prefDlg;
    delete config;
}
//-----------------------------------------------------------------------------
bool MainWindow::setFSBrowserPath(QString path)
{
    QDir tmpPath(path);
    if (!tmpPath.exists())
        return false;

    fsPathLE->setText(path);
    fsTW->setCurrentIndex(dirModel->index(path));
    return true;
}
//-----------------------------------------------------------------------------
void MainWindow::on_fsTW_activated(QModelIndex modelIndex)
{
    //fsPathLE->setText(modelIndex.data().toString());
}
//-----------------------------------------------------------------------------
void MainWindow::on_fsTW_expanded(QModelIndex modelIndex)
{
   fsPathLE->setText(getFullPath(modelIndex));

   if (config->defaultOutputDir == 1)
       outputDirLE->setText(fsPathLE->text());

   QDir tmpDir(getFullPath(modelIndex));
   cuePathCB->clear();
   cuePathCB->addItems(tmpDir.entryList(QStringList() << "*.cue", QDir::Files));
   mediaFileCB->clear();
   mediaFileCB->addItems(tmpDir.entryList(config->mediaFileExts, QDir::Files));
}
//-----------------------------------------------------------------------------
QString MainWindow::getFullPath(QModelIndex modelIndex)
{
    if (modelIndex.parent().isValid())
    {
        if (modelIndex.parent().data().toString() == QDir::separator())
            return getFullPath(modelIndex.parent()) + modelIndex.data().toString();
        else
            return getFullPath(modelIndex.parent()) + QDir::separator() + modelIndex.data().toString();
    }
    else
        return modelIndex.data().toString();
}
//-----------------------------------------------------------------------------
void MainWindow::on_actionPreference_activated()
{
    prefDlg->readSettings();
    prefDlg->exec();
}
//-----------------------------------------------------------------------------
void MainWindow::on_outputDirTB_clicked()
{
    QString tmpDir = QFileDialog::getExistingDirectory(this, "Open output directory...", config->customOutputDir);
    if (tmpDir.isEmpty())
        return;

    outputDirLE->setText(tmpDir);
}
//-----------------------------------------------------------------------------
void MainWindow::on_actionStart_process_activated()
{
    if (cuePathCB->currentText().isEmpty())
    {
        QMessageBox::warning(this, "Warning...", "Cue file is not found.");
        return;
    }

    if (mediaFileCB->currentText().isEmpty())
    {
        QMessageBox::warning(this, "Warning...", "Media file is not found.");
        return;
    }

    QDir tmpPath(outputDirLE->text());
    if (!tmpPath.exists())
    {
        QMessageBox::warning(this, "Warning...", "Output directory is not found.");
        return;
    }

    QProcess *tmpProc = new QProcess(this);
    QObject::connect(tmpProc,
                     SIGNAL(finished(int, QProcess::ExitStatus)),
                     this,
                     SLOT(process_finished(int, QProcess::ExitStatus)));
    processes.append(tmpProc);
    tmpProc->start("xterm", QStringList()
                   << "-e"
                   << "shntool split -o \"" + outputFormatCB->currentText()
                   + "\" -f \"" + fsPathLE->text()
                   + QDir::separator() + cuePathCB->currentText()
                   + "\" -d \"" + outputDirLE->text()
                   + "\" \"" + fsPathLE->text() + QDir::separator()
                   + mediaFileCB->currentText() + "\" ; read");
    countProcessesL->setText(QString("%1").arg(processes.size()));
}
//-----------------------------------------------------------------------------
void MainWindow::process_finished(int exitCode, QProcess::ExitStatus exitStatus)
{
    processes.removeAll((QProcess*)sender());
    countProcessesL->setText(QString("%1").arg(processes.size()));
}
//-----------------------------------------------------------------------------
void MainWindow::on_fsLevelUp_clicked()
{
    if (fsTW->currentIndex().data().toString() == QDir::separator())
        return;

    setFSBrowserPath(getFullPath(fsTW->currentIndex().parent()));
}
//-----------------------------------------------------------------------------
void MainWindow::on_actionAbout_Qt_activated()
{
    QMessageBox::aboutQt(this, "About Qt...");
}
//-----------------------------------------------------------------------------
void MainWindow::on_actionAbout_activated()
{
    QMessageBox::about(this, "About QShnToolSplit...",
                       QString("<h1>QShnToolSplit</h1>")
                       + "<p>Graphical frontend for shntool-split utility."
                       + "<br>Version: 0.0.1</p>"
                       + "<p>Created by I_am_milk</p>");
}
//-----------------------------------------------------------------------------
void MainWindow::on_actionExit_activated()
{
    if (processes.size() != 0)
        if (QMessageBox::question(this, "Warning!",
                              "Some processes in running now. Do you want stop it?",
                              QMessageBox::Yes, QMessageBox::No) == QMessageBox::Yes)
            qApp->quit();
}
//-----------------------------------------------------------------------------
