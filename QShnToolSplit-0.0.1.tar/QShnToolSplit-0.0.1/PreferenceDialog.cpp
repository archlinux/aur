//-----------------------------------------------------------------------------
#include "PreferenceDialog.h"
#include "ui_PreferenceDialog.h"
//-----------------------------------------------------------------------------
#include <QMessageBox>
#include <QFileDialog>
//-----------------------------------------------------------------------------
PreferenceDialog::PreferenceDialog(QWidget *parent, Config *_config)
    : QDialog(parent)
{
    setupUi(this);
    config = _config;

    defaultInputDirTB->setIcon(style()->standardIcon(QStyle::SP_DialogOpenButton));
    customOutputDirTB->setIcon(style()->standardIcon(QStyle::SP_DialogOpenButton));
}
//-----------------------------------------------------------------------------
void PreferenceDialog::readSettings()
{
    QString tmpLine;

    defaultInputDirLE->setText(config->defaultInputDir);

    mediaFileExtsTE->clear();
    foreach (tmpLine, config->mediaFileExts)
        mediaFileExtsTE->setPlainText(mediaFileExtsTE->toPlainText() + tmpLine + "\n");

    outputFormatTE->clear();
    foreach (tmpLine, config->outputFormat)
        outputFormatTE->setPlainText(outputFormatTE->toPlainText() + tmpLine + "\n");

    switch (config->defaultOutputDir)
    {
        case 0: defaultHomeRB->setChecked(true); break;
        case 1: defaultCurrentRB->setChecked(true); break;
        case 2:
            customOutputDirRB->setChecked(true);
            customOutputDirLE->setEnabled(true);
            customOutputDirTB->setEnabled(true);
            break;
    }

    customOutputDirLE->setText(config->customOutputDir);
}
//-----------------------------------------------------------------------------
bool PreferenceDialog::saveSettings()
{
    if (!QDir(defaultInputDirLE->text()).isReadable())
    {
        QMessageBox::warning(this, "Warning...", "Default input directory is unreadable.");
        return false;
    }

    if (!QDir(customOutputDirLE->text()).isReadable())
    {
        QMessageBox::warning(this, "Warning...", "Default input directory is unreadable.");
        return false;
    }

    if (mediaFileExtsTE->toPlainText().isEmpty())
    {
        QMessageBox::warning(this, "Warning...", "Media file extensions is empty.");
        return false;
    }

    if (outputFormatTE->toPlainText().isEmpty())
    {
        QMessageBox::warning(this, "Warning...", "Output format is empty.");
        return false;
    }

    config->defaultInputDir = defaultInputDirLE->text();
    config->customOutputDir = customOutputDirLE->text();
    config->mediaFileExts = mediaFileExtsTE->toPlainText().split("\n");
    config->outputFormat = outputFormatTE->toPlainText().split("\n");

    if (defaultHomeRB->isChecked())
        config->defaultOutputDir = 0;
    if (defaultCurrentRB->isChecked())
        config->defaultOutputDir = 1;
    if (customOutputDirRB->isChecked())
        config->defaultOutputDir = 2;

    return true;
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_defaultHomeRB_clicked(bool checked)
{
    customOutputDirLE->setEnabled(false);
    customOutputDirTB->setEnabled(false);
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_defaultCurrentRB_clicked(bool checked)
{
    customOutputDirLE->setEnabled(false);
    customOutputDirTB->setEnabled(false);
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_customOutputDirRB_clicked(bool checked)
{
    customOutputDirLE->setEnabled(true);
    customOutputDirTB->setEnabled(true);
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_defaultInputDirTB_clicked()
{
    QString tmpDir = QFileDialog::getExistingDirectory(this, "Open default input directory...", QDir::homePath());
    if (tmpDir.isEmpty())
        return;

    defaultInputDirLE->setText(tmpDir);
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_customOutputDirTB_clicked()
{
    QString tmpDir = QFileDialog::getExistingDirectory(this, "Open custom output directory...", QDir::homePath());
    if (tmpDir.isEmpty())
        return;

    customOutputDirLE->setText(tmpDir);
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_buttonBox_accepted()
{
    if (saveSettings())
    {
        config->save();
        this->accept();
    }
}
//-----------------------------------------------------------------------------
void PreferenceDialog::on_buttonBox_rejected()
{
    this->reject();
}
//-----------------------------------------------------------------------------
