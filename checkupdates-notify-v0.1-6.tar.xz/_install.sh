#!/bin/bash

#
# SPDX-FileCopyrightText: Arch Linux Contributors
#
# SPDX-License-Identifier: 0BSD
#

readonly pkgdir="$1"
readonly pkgname=$2

install -Dm755 ${pkgname} -t "${pkgdir}/usr/bin/" || exit 1
install -dm755 "${pkgdir}/etc/systemd/user" || exit 1
install -m644 ${pkgname}.service ${pkgname}.timer "${pkgdir}/etc/systemd/user/" || exit 1
install -Dm644 LICENSE -t "${pkgdir}/usr/share/licenses/${pkgname}/"

exit
