#include "src/rhdc/core/sync.hpp"

#include <algorithm>
#include <QCoreApplication>
#include "src/rhdc/web/api.hpp"
#include "src/rhdc/ui/rhdc-download-dialog.hpp"
#include "src/core/file-controller.hpp"
#include "src/core/special-groups.hpp"
#include "src/core/logging.hpp"
#include "src/core/sm64.hpp"
#include "src/db/data-provider.hpp"
#include "src/db/transaction.hpp"
#include "src/ui/toast.hpp"

void RHDC::sync( const std::function<void(RequiredAction)> &callback ) {
	using namespace RHDC;

	RhdcApi::getFollowedHacksAsync(
		[callback](HashMap<string,FollowedHack> &hacks) {
			const HashSet<string> knownHashes = DataProvider::fetchAllKnownChecksums();
			std::vector<string> hacksToDownload;

			SqlTransaction transaction;
			DataProvider::clearRhdcHacks();
			foreach_cvalue( hack, hacks ) {
				DataProvider::addOrUpdateRhdcHack( hack.info );
				bool knownHack = false;
				for( const string &hash : hack.versions ) {
					DataProvider::addRhdcHackVersion( hack.info.hackId, hash );
					if( knownHashes.count( hash ) > 0 ) {
						knownHack = true;
					}
				}

				if( !knownHack ) {
					hacksToDownload.push_back( hack.info.hackId );
				} else if( FileController::loadRhdcSettings().syncGroups ) {
					std::set<string> localGroups = DataProvider::fetchGroupsForRhdcHack( hack.info.hackId );
					for( const string &group : hack.groups ) {
						if( localGroups.count( group ) > 0 ) {
							localGroups.erase( group );
						} else {
							DataProvider::addRhdcHackToGroup( hack.info.hackId, group );
						}
					}

					for( const string &group : localGroups ) {
						if( group == SpecialGroups::Favourites ) {
							RhdcApi::addHackToListAsync( hack.info.hackId, "Favorites", [](){}, RhdcApi::logApiError( "Failed to add hack to list" ) );
						} else if( !group.empty() && group[0] != (char)1 ) {
							RhdcApi::addHackToListAsync( hack.info.hackId, group, [](){}, RhdcApi::logApiError( "Failed to add hack to list" ) );
						}
					}
				}
			}
			transaction.commit();

			if( !hacksToDownload.empty() ) {
				fs::path sm64path;
				if( SM64::tryGetPath( sm64path ) ) {
					HashMap<string,FollowedHack> downloadableHacks;
					for( const string &hackId : hacksToDownload ) {
						downloadableHacks[hackId] = hacks.at( hackId );
					}
					RhdcDownloadDialog::run( downloadableHacks );
				} else {
					ToastMessageManager::display( ToastType::Error, QCoreApplication::translate( "RhdcSync", "Cannot apply patches because vanilla SM64 was not found" ) );
				}
			}

			const bool downloadedNewHacks = !hacksToDownload.empty();
			RhdcApi::getStarpowerAsync(
				[callback,downloadedNewHacks](HashMap<string,Starpower> &serverStarpower) {
					const HashMap<string,StarpowerExt> clientStarpower = DataProvider::fetchAllStarpower();
					SqlTransaction transaction;

					bool playTimeUpdated = false;
					for( const auto &[hackId, starpower] : serverStarpower ) {
						if( clientStarpower.count( hackId ) <= 0 ) {
							DataProvider::updateRhdcProgress( hackId, starpower.progress );
							DataProvider::suggestRhdcHackPlayTime( hackId, starpower.playTime );
							playTimeUpdated = true;
							continue;
						}

						const StarpowerExt &localStarpower = clientStarpower.at( hackId );
						const RhdcHackProgress &clientProgress = localStarpower.progress;
						const RhdcHackProgress &serverProgress = starpower.progress;

						const RhdcHackProgress newProgress = {
							serverProgress.rating,
							serverProgress.difficulty,
							std::max( clientProgress.stars, serverProgress.stars ),
							clientProgress.completed || serverProgress.completed
						};

						if( clientProgress != newProgress ) {
							DataProvider::updateRhdcProgress( hackId, newProgress );
						}

						if( serverProgress != newProgress ) {
							if( localStarpower.starCount > 0 ) {
								RhdcApi::submitStarProgressAsync( hackId, newProgress.stars, [](){}, RhdcApi::logApiError( "Failed to submit hack progress" ) );
							} else {
								RhdcApi::submitCompletionAsync( hackId, newProgress.completed, [](){}, RhdcApi::logApiError( "Failed to submit hack progress" ) );
							}
						}

						if( starpower.playTime < localStarpower.playTime ) {
							RhdcApi::submitPlayTimeAsync( hackId, localStarpower.playTime, [](){}, [](ApiErrorType){} );
						} else if( starpower.playTime > localStarpower.playTime ) {
							playTimeUpdated = true;
							DataProvider::suggestRhdcHackPlayTime( hackId, starpower.playTime );
						}
					}
					transaction.commit();

					callback( (playTimeUpdated || downloadedNewHacks) ? RequiredAction::RefetchAll : RequiredAction::RefetchRhdc );
				},
				[callback](ApiErrorType) {
					logError( "Failed to sync progress with romhacking.com" );
					ToastMessageManager::display( ToastType::Error, QCoreApplication::translate( "RhdcSync", "Failed to sync progress with romhacking.com" ) );
					callback( RequiredAction::RefetchRhdc );
				}
			);
		},
		[callback](ApiErrorType err) {
			if( err != ApiErrorType::NotAuthorized && err != ApiErrorType::RegistrationRequired ) {
				ToastMessageManager::display( ToastType::Error, QCoreApplication::translate( "RhdcSync", "Failed to connect to romhacking.com" ) );
			}
			callback( RequiredAction::None );
		}
	);
}

void RHDC::moveRhdcFolder( const fs::path &oldDir, const fs::path &newDir ) {
	fs::error_code err;
	fs::create_directories( newDir, err );
	for( const auto &p : fs::directory_iterator( oldDir ) ) {
		if( !fs::isRegularFileSafe( p.path() ) ) continue;
		if( p.path().extension() != ".z64" ) continue;
		fs::rename( p.path(), newDir / p.path().filename(), err );
	}
}
