/*
 * This file is part of LSX
 *
 * Copyright (C) 2026 Sergey Desyatkov
 *
 * LSX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version
 *
 * LSX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details
 *
 * You should have received a copy of the GNU General Public License
 * along with LSX. If not, see <https://www.gnu.org/licenses/>
 */

use chrono::{DateTime, Local};
use serde::Serialize;
use std::{
    fs::Metadata,
    os::unix::fs::{FileTypeExt, PermissionsExt},
    time::SystemTime,
};
use tabled::Tabled;
use users::get_user_by_uid;

/// Contains data for JSON output
#[derive(Serialize)]
pub struct Entry {
    pub permissions: String,
    pub owner_uid: u32,
    pub owner: String,
    pub size_in_bytes: u64,
    pub date_modified: u64,
    pub name: String,
}

/// Contains data for table view output
#[derive(Tabled)]
pub struct EntryHuman {
    #[tabled{rename="Permissions"}]
    pub permissions: String,
    #[tabled{rename="Owner"}]
    pub owner: String,
    #[tabled{rename="Size"}]
    pub size: String,
    #[tabled{rename="Date Modified"}]
    pub date_modified: String,
    #[tabled{rename="Name"}]
    pub name: String,
}

/// Creates a permissions string from entry metadata
pub fn get_permissions_string(meta: &Metadata) -> String {
    fn bit(x: u32, bit: u32, c: char) -> char {
        if x & bit != 0 { c } else { '-' }
    }

    let mut s = String::new();

    let mode = meta.permissions().mode();
    let file_type = meta.file_type();
    let type_char = if file_type.is_block_device() {
        'b'
    } else if file_type.is_char_device() {
        'c'
    } else if file_type.is_dir() {
        'd'
    } else if file_type.is_symlink() {
        'l'
    } else if file_type.is_fifo() {
        'p'
    } else if file_type.is_socket() {
        's'
    } else {
        '-'
    };

    s.push(type_char);
    s.push(bit(mode, 0o400, 'r'));
    s.push(bit(mode, 0o200, 'w'));
    s.push(if mode & 0o4000 != 0 {
        if mode & 0o100 != 0 { 's' } else { 'S' }
    } else {
        bit(mode, 0o100, 'x')
    });
    s.push(bit(mode, 0o040, 'r'));
    s.push(bit(mode, 0o020, 'w'));
    s.push(if mode & 0o2000 != 0 {
        if mode & 0o010 != 0 { 's' } else { 'S' }
    } else {
        bit(mode, 0o010, 'x')
    });
    s.push(bit(mode, 0o004, 'r'));
    s.push(bit(mode, 0o002, 'w'));
    s.push(if mode & 0o1000 != 0 {
        if mode & 0o001 != 0 { 't' } else { 'T' }
    } else {
        bit(mode, 0o001, 'x')
    });

    s
}

/// Parses owner username by UID
pub fn get_owner(uid: u32) -> String {
    get_user_by_uid(uid)
        .unwrap()
        .name()
        .to_str()
        .unwrap()
        .to_string()
}

/// Converts bytes to human-readable `String`
pub fn bytes_to_human_size(bytes: u64) -> String {
    const UNITS: [&str; 7] = ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB"];

    let mut size = bytes as f64;
    let mut unit = 0;

    while size >= 1024.0 && unit < UNITS.len() - 1 {
        size /= 1024.0;
        unit += 1;
    }

    if size < 10.0 {
        format!("{:.2} {}", size, UNITS[unit])
    } else if size < 100.0 {
        format!("{:.1} {}", size, UNITS[unit])
    } else {
        format!("{:.0} {}", size, UNITS[unit])
    }
}

/// Converts `SystemTime` to human-readable `String`
pub fn system_time_to_human_time(time: SystemTime) -> String {
    DateTime::<Local>::from(time)
        .format("%d %b %H:%M")
        .to_string()
}

/// Returns an icon according to entry type (directory, file, etc...)
pub fn get_icon(perms: &String) -> String {
    match perms.chars().nth(0).unwrap() {
        'b' => String::from("󰜫"),
        'c' => String::from("󰕣"),
        'd' => String::from("󰉋"),
        'l' => String::from("󰌷"),
        'p' => String::from("󰆍"),
        's' => String::from("󰆨"),
        _ => String::from("󰈙"),
    }
}
