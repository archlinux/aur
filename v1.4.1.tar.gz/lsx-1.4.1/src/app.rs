/*
 * This file is part of LSX
 *
 * Copyright (C) 2026 Sergey Desyatkov
 *
 * LSX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version
 *
 * LSX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details
 *
 * You should have received a copy of the GNU General Public License
 * along with LSX. If not, see <https://www.gnu.org/licenses/>
 */

use crate::cli::Cli;
use crate::utils::{
    Entry, EntryHuman, bytes_to_human_size, get_icon, get_owner, get_permissions_string,
    system_time_to_human_time,
};
use colored::Colorize;
use std::{
    cmp::Ordering,
    env,
    fs::{self},
    io::Result,
    os::unix::fs::MetadataExt,
    time::UNIX_EPOCH,
};
use tabled::{
    Table,
    settings::{Color, Remove, Style, location::ByColumnName, object::Rows},
};

/// Main logic
pub fn run(args: &Cli) -> Result<()> {
    let mut entries_array = Vec::new();
    let mut entries_human_array = Vec::new();

    if let Ok(exists) = fs::exists(
        &args
            .directory
            .clone()
            .unwrap_or_else(|| env::current_dir().unwrap()),
    ) {
        if exists {
            let mut entries: Vec<_> = fs::read_dir(
                &args
                    .directory
                    .clone()
                    .unwrap_or_else(|| env::current_dir().unwrap()),
            )
            .unwrap()
            .filter_map(|e| e.ok())
            .collect();

            if args.group_directories_first || args.group_directories_last {
                entries.sort_by(|a, b| {
                    let a_name = a.file_name();
                    let b_name = b.file_name();

                    let a_meta = a.metadata();
                    let b_meta = b.metadata();

                    let a_is_dir = a_meta.map(|m| m.is_dir()).unwrap_or(false);
                    let b_is_dir = b_meta.map(|m| m.is_dir()).unwrap_or(false);

                    if args.group_directories_first {
                        match (a_is_dir, b_is_dir) {
                            (true, false) => Ordering::Less,
                            (false, true) => Ordering::Greater,
                            _ => a_name.to_string_lossy().cmp(&b_name.to_string_lossy()),
                        }
                    } else {
                        match (a_is_dir, b_is_dir) {
                            (true, false) => Ordering::Greater,
                            (false, true) => Ordering::Less,
                            _ => a_name.to_string_lossy().cmp(&b_name.to_string_lossy()),
                        }
                    }
                });
            }

            let mut count = 0;

            for entry in entries {
                let permissions_human = get_permissions_string(&entry.metadata().unwrap());
                let owner_uid = entry.metadata().map(|m| m.uid()).unwrap();
                let owner_human = get_owner(owner_uid);
                let size_in_bytes = entry.metadata().map(|m| m.size()).unwrap();
                let size_human = bytes_to_human_size(size_in_bytes);
                let date_modified = entry
                    .metadata()
                    .map(|m| m.modified())
                    .unwrap()
                    .unwrap()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_secs();
                let date_modified_human = system_time_to_human_time(
                    entry.metadata().map(|m| m.modified()).unwrap().unwrap(),
                );
                let icon = get_icon(&permissions_human);
                let name = entry.file_name().to_string_lossy().to_string();

                if args.all || !name.starts_with('.') {
                    if !args.table && !args.json {
                        if args.colors {
                            if args.show_all_columns || args.show_permissions {
                                print!("{} ", permissions_human.red());
                            }

                            if args.show_all_columns || args.show_owner {
                                print!("{} ", owner_human.green());
                            }

                            if args.show_all_columns || args.show_size {
                                print!("{} ", size_human.yellow());
                            }

                            if args.show_all_columns || args.show_date_modified {
                                print!("{} ", date_modified_human.magenta());
                            }

                            if args.icons {
                                println!("{} {}", icon.cyan(), name.cyan());
                            } else {
                                println!("{}", name.cyan());
                            }
                        } else {
                            if args.show_all_columns || args.show_permissions {
                                print!("{permissions_human} ");
                            }

                            if args.show_all_columns || args.show_owner {
                                print!("{owner_human} ");
                            }

                            if args.show_all_columns || args.show_size {
                                print!("{size_human} ");
                            }

                            if args.show_all_columns || args.show_date_modified {
                                print!("{date_modified_human} ");
                            }

                            if args.icons {
                                println!("{icon} {name}");
                            } else {
                                println!("{name}");
                            }
                        }
                    }

                    entries_array.push(Entry {
                        permissions: String::from(&permissions_human),
                        owner_uid: owner_uid,
                        owner: String::from(&owner_human),
                        size_in_bytes: size_in_bytes,
                        date_modified: date_modified,
                        name: String::from(&name),
                    });

                    entries_human_array.push(EntryHuman {
                        permissions: String::from(&permissions_human),
                        owner: String::from(&owner_human),
                        size: size_human,
                        date_modified: date_modified_human,
                        name: if args.icons {
                            format!("{} {}", &icon, &name)
                        } else {
                            String::from(&name)
                        },
                    });

                    count += 1;
                }
            }

            if args.table && !args.json && !entries_array.is_empty() {
                let mut table_instance = Table::new(&entries_human_array);

                table_instance.with(Style::rounded());

                if !args.show_all_columns && !args.show_permissions {
                    table_instance.with(Remove::column(ByColumnName::new("Permissions")));
                }

                if !args.show_all_columns && !args.show_owner {
                    table_instance.with(Remove::column(ByColumnName::new("Owner")));
                }

                if !args.show_all_columns && !args.show_size {
                    table_instance.with(Remove::column(ByColumnName::new("Size")));
                }

                if !args.show_all_columns && !args.show_date_modified {
                    table_instance.with(Remove::column(ByColumnName::new("Date Modified")));
                }

                if args.colors {
                    table_instance.modify(ByColumnName::new("Permissions"), Color::FG_RED);
                    table_instance.modify(ByColumnName::new("Owner"), Color::FG_GREEN);
                    table_instance.modify(ByColumnName::new("Size"), Color::FG_YELLOW);
                    table_instance.modify(ByColumnName::new("Date Modified"), Color::FG_MAGENTA);
                    table_instance.modify(ByColumnName::new("Name"), Color::FG_CYAN);
                    table_instance.modify(Rows::first(), Color::FG_BLUE);
                }

                println!("{table_instance}");
            }

            if args.json && !args.table {
                println!("{}", serde_json::to_string_pretty(&entries_array).unwrap());
            }

            if (!args.table && !args.json) && (args.show_all_columns || args.show_total) {
                println!("-------{}", "-".repeat(count.to_string().len()));
                println!("Total: {count}");
            }
        } else {
            eprintln!("{} no such file or directory", "error:".red().bold());
        }
    }

    Ok(())
}
