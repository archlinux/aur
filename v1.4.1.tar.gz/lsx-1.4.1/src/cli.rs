/*
 * This file is part of LSX
 *
 * Copyright (C) 2026 Sergey Desyatkov
 *
 * LSX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version
 *
 * LSX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details
 *
 * You should have received a copy of the GNU General Public License
 * along with LSX. If not, see <https://www.gnu.org/licenses/>
 */

use clap::Parser;
use std::path::PathBuf;

/// CLI options and arguments
#[derive(Debug, Parser)]
#[command(name = "LSX", about = "Imagine ls command, but better", version)]
pub struct Cli {
    /// Do not ignore entries starting with `.`
    #[arg(short = 'a', long = "all")]
    pub all: bool,
    /// List directories before other files
    #[arg(
        long = "group-directories-first",
        conflicts_with = "group_directories_last"
    )]
    pub group_directories_first: bool,
    /// List directories after other files
    #[arg(
        long = "group-directories-last",
        conflicts_with = "group_directories_first"
    )]
    pub group_directories_last: bool,
    /// Enable every `--show-*` option below
    #[arg(long = "show-all-columns")]
    pub show_all_columns: bool,
    /// Show entry permissions column
    #[arg(long = "show-permissions")]
    pub show_permissions: bool,
    /// Show entry owner column
    #[arg(long = "show-owner")]
    pub show_owner: bool,
    /// Show entry size column
    #[arg(long = "show-size")]
    pub show_size: bool,
    /// Show entry date modified column
    #[arg(long = "show-date-modified")]
    pub show_date_modified: bool,
    /// Show total entries count
    #[arg(long = "show-total")]
    pub show_total: bool,
    /// Colorize output
    #[arg(short = 'c', long = "colors")]
    pub colors: bool,
    /// Use Nerd Font icons
    #[arg(short = 'i', long = "icons")]
    pub icons: bool,
    /// Use table view
    #[arg(short = 't', long = "table", conflicts_with = "json")]
    pub table: bool,
    /// JSON output
    #[arg(short = 'j', long = "json", conflicts_with = "table")]
    pub json: bool,
    /// Directory to list items from
    #[arg(value_name = "PATH", value_parser = clap::value_parser!(PathBuf))]
    pub directory: Option<PathBuf>,
}
