/*
 * This file is part of LSX
 *
 * Copyright (C) 2026 Sergey Desyatkov
 *
 * LSX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation, either version 3 of the License,
 * or (at your option) any later version
 *
 * LSX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details
 *
 * You should have received a copy of the GNU General Public License
 * along with LSX. If not, see <https://www.gnu.org/licenses/>
 */

mod app;
mod cli;
mod utils;

use clap::Parser;
use cli::Cli;
use std::io::Result;

/// Entry point
fn main() -> Result<()> {
    let args = Cli::parse();

    app::run(&args)
}
