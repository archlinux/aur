application=
{
    description="FLV Playback Sample",
    name="flvplayback",
    protocol="dynamiclinklibrary",
    mediaFolder="/var/lib/crtmpserver/mediaFolder",
    aliases=
    {
        "simpleLive",
        "vod",
        "live",
        "WeeklyQuest",
        "SOSample",
        "oflaDemo",
    },
    acceptors =
    {
        {
            ip="0.0.0.0",
            port=6666,
            protocol="inboundLiveFlv",
            waitForMetadata=true,
        },
        {
            ip="0.0.0.0",
            port=9999,
            protocol="inboundTcpTs"
        },
        {
            ip="0.0.0.0",
            port=10000,
            protocol="inboundUdpTs"
        },
        --[[{
            ip="0.0.0.0",
            port=7654,
            protocol="inboundRawHttpStream",
            crossDomainFile="/tmp/crossdomain.xml"
        },]]--
        {
            ip="0.0.0.0",
            port=554,
            protocol="inboundRtsp"
        },
    },
    externalStreams =
    {
        --[[
        {
            uri="rtsp://fms20.mediadirect.ro/live2/realitatea/realitatea",
            localStreamName="rtsp_test",
            forceTcp=true
        },
        {
            uri="rtmp://edge01.fms.dutchview.nl/botr/bunny",
            localStreamName="rtmp_test",
            swfUrl="http://www.example.com/example.swf";
            pageUrl="http://www.example.com/";
            emulateUserAgent="MAC 10,1,82,76",
        }]]--
    },
    validateHandshake=false,
    keyframeSeek=true,
    seekGranularity=1.5, --in seconds, between 0.1 and 600
    clientSideBuffer=12, --in seconds, between 5 and 30
    --generateMetaFiles=true, --this will generate seek/meta files on application startup
    --renameBadFiles=false,
    --enableCheckBandwidth=true,
    --[[authentication=
    {
        rtmp={
            type="adobe",
            encoderAgents=
            {
                "FMLE/3.0 (compatible; FMSc/1.0)",
                "My user agent",
            },
            usersFile="/etc/crtmpserver/conf.d/users.lua"
        },
        rtsp={
            usersFile="/etc/crtmpserver/conf.d/users.lua"
        }
    }, --]]
    --[[mediaStorage = {
        namedStorage1={
            --this storage contains all properties with their
            --default values. The only mandatory property is
            --mediaFolder
            description="Some storage",
            mediaFolder="/Volumes/Storage/media/",
            metaFolder="/tmp/metadata",
            enableStats=false,
            clientSideBuffer=15,
            keyframeSeek=false,
            seekGranularity=0.1,
        },
        namedStorage2={
            mediaFolder="/Volumes/Storage/media/mp4",
            metaFolder="/tmp/metadata",
            seekGranularity=0.2,
            enableStats=true,
        },
        namedStorage3={
            mediaFolder="/Volumes/Storage/media/flv",
            metaFolder="/tmp/metadata",
        },
        {
            --this one doesn't have a name
            mediaFolder="/Volumes/Storage/media/mp3",
        }
    },]]--
}

