#include "system_info.h"
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>

std::string SystemInfo::read_file(const std::string& path) {
    std::ifstream file(path);
    if (!file) return "";

    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

std::string SystemInfo::exec_command(const std::string& cmd) {
    FILE* pipe = popen((cmd + " 2>/dev/null").c_str(), "r");
    if (!pipe) return "";

    std::string result;
    char buffer[512];
    while (fgets(buffer, sizeof(buffer), pipe)) {
        result += buffer;
    }
    pclose(pipe);
    return result;
}

std::vector<std::string> SystemInfo::split_string(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(str);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

double SystemInfo::get_cpu_temperature() {
    // Try thermal zones
    for (int i = 0; i < 10; i++) {
        std::string path = "/sys/class/thermal/thermal_zone" + std::to_string(i) + "/temp";
        std::string temp_str = read_file(path);
        if (!temp_str.empty()) {
            try {
                return std::stod(temp_str) / 1000.0;  // Convert from millidegrees
            } catch (...) {}
        }
    }

    // Try hwmon
    DIR* dir = opendir("/sys/class/hwmon");
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir))) {
            if (entry->d_type == DT_DIR || entry->d_type == DT_LNK) {
                std::string hwmon_path = "/sys/class/hwmon/" + std::string(entry->d_name) + "/temp1_input";
                std::string temp_str = read_file(hwmon_path);
                if (!temp_str.empty()) {
                    try {
                        closedir(dir);
                        return std::stod(temp_str) / 1000.0;
                    } catch (...) {}
                }
            }
        }
        closedir(dir);
    }

    return 0.0;
}

std::map<std::string, std::string> SystemInfo::parse_lscpu() {
    std::map<std::string, std::string> info;
    std::string output = exec_command("lscpu");
    std::istringstream iss(output);
    std::string line;

    while (std::getline(iss, line)) {
        size_t colon = line.find(':');
        if (colon != std::string::npos) {
            std::string key = line.substr(0, colon);
            std::string value = line.substr(colon + 1);
            // Trim leading whitespace from value
            size_t start = value.find_first_not_of(" \t");
            if (start != std::string::npos) {
                value = value.substr(start);
            }
            info[key] = value;
        }
    }

    return info;
}

std::string SystemInfo::format_uptime(double seconds) {
    int days = static_cast<int>(seconds / 86400);
    seconds -= days * 86400;
    int hours = static_cast<int>(seconds / 3600);
    seconds -= hours * 3600;
    int minutes = static_cast<int>(seconds / 60);
    seconds -= minutes * 60;
    int secs = static_cast<int>(seconds);

    char buffer[64];
    if (days > 0) {
        snprintf(buffer, sizeof(buffer), "%d:%02d:%02d:%02d", days, hours, minutes, secs);
    } else if (hours > 0) {
        snprintf(buffer, sizeof(buffer), "%d:%02d:%02d", hours, minutes, secs);
    } else {
        snprintf(buffer, sizeof(buffer), "%d:%02d", minutes, secs);
    }

    return std::string(buffer);
}

std::string SystemInfo::format_bytes(std::uint64_t bytes) {
    const char* units[] = {"B", "KiB", "MiB", "GiB", "TiB"};
    int unit_index = 0;
    double size = static_cast<double>(bytes);

    while (size >= 1024.0 && unit_index < 4) {
        size /= 1024.0;
        unit_index++;
    }

    char buffer[64];
    snprintf(buffer, sizeof(buffer), "%.2f %s", size, units[unit_index]);
    return std::string(buffer);
}

CPUInfo SystemInfo::get_cpu_info() {
    CPUInfo cpu;
    auto lscpu = parse_lscpu();

    // Read /proc/cpuinfo
    std::ifstream cpuinfo("/proc/cpuinfo");
    std::string line;
    bool first_processor = true;

    while (std::getline(cpuinfo, line)) {
        if (line.find("vendor_id") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                cpu.vendor = line.substr(colon + 2);
            }
        } else if (line.find("model name") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                cpu.model_name = line.substr(colon + 2);
                cpu.specification = cpu.model_name;  // Specification is the full model name
            }
        } else if (line.find("cpu family") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                try {
                    cpu.family = std::stoi(line.substr(colon + 2));
                    cpu.disp_family = cpu.family;
                } catch (...) {}
            }
        } else if (line.find("model") != std::string::npos && line.find("model name") == std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                try {
                    cpu.model = std::stoi(line.substr(colon + 2));
                    cpu.disp_model = cpu.model;
                } catch (...) {}
            }
        } else if (line.find("stepping") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                try {
                    cpu.stepping = std::stoi(line.substr(colon + 2));
                } catch (...) {}
            }
        } else if (line.find("microcode") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                cpu.microcode = line.substr(colon + 2);
            }
        } else if (line.find("flags") != std::string::npos && first_processor) {
            size_t colon = line.find(':');
            if (colon != std::string::npos) {
                std::string flags_str = line.substr(colon + 2);
                cpu.flags = split_string(flags_str, ' ');
            }
            first_processor = false;
        }
    }

    // Determine code name based on family/model
    if (cpu.vendor.find("Intel") != std::string::npos) {
        if (cpu.family == 6) {
            switch (cpu.model) {
                case 0x2A: case 0x2D: cpu.code_name = "Sandy Bridge"; break;
                case 0x3A: case 0x3E: cpu.code_name = "Ivy Bridge"; break;
                case 0x3C: case 0x3F: case 0x45: case 0x46: cpu.code_name = "Haswell"; break;
                case 0x3D: case 0x47: case 0x4F: case 0x56: cpu.code_name = "Broadwell"; break;
                case 0x4E: case 0x5E: case 0x8E: case 0x9E: cpu.code_name = "Skylake"; break;
                case 0x55: cpu.code_name = "Skylake-X"; break;
                case 0x7D: case 0x7E: cpu.code_name = "Ice Lake"; break;
                case 0x8C: case 0x8D: cpu.code_name = "Tiger Lake"; break;
                case 0x8F: case 0xA7: cpu.code_name = "Alder Lake"; break;
                case 0x97: case 0x9A: case 0xB7: case 0xBA: cpu.code_name = "Alder Lake"; break;
                case 0xBF: cpu.code_name = "Raptor Lake"; break;
                default: cpu.code_name = "Unknown Intel";
            }
        }
    } else if (cpu.vendor.find("AMD") != std::string::npos || cpu.vendor.find("AuthenticAMD") != std::string::npos) {
        if (cpu.family == 0x17) {
            cpu.code_name = "Zen/Zen+/Zen2";
        } else if (cpu.family == 0x19) {
            cpu.code_name = "Zen3/Zen4";
        }
    }

    // Determine package type (simplified)
    if (cpu.model_name.find("Mobile") != std::string::npos || cpu.model_name.find("M ") != std::string::npos) {
        cpu.package = "Mobile (rPGA/BGA)";
    } else if (cpu.model_name.find("Xeon") != std::string::npos) {
        cpu.package = "LGA (Server)";
    } else {
        cpu.package = "LGA/PGA (Desktop)";
    }

    // Determine technology node (very approximate based on generation)
    if (cpu.vendor.find("Intel") != std::string::npos) {
        if (cpu.model == 0x2A || cpu.model == 0x2D) cpu.technology = "32 nm";
        else if (cpu.model == 0x3A || cpu.model == 0x3E) cpu.technology = "22 nm";
        else if (cpu.model >= 0x3C && cpu.model <= 0x46) cpu.technology = "22 nm";
        else if (cpu.model >= 0x4E && cpu.model <= 0x9E) cpu.technology = "14 nm";
        else if (cpu.model >= 0x7D && cpu.model <= 0x8D) cpu.technology = "10 nm";
        else if (cpu.model >= 0x8F) cpu.technology = "Intel 7 (10 nm)";
    } else if (cpu.vendor.find("AMD") != std::string::npos) {
        if (cpu.family == 0x17) cpu.technology = "14nm/12nm/7nm";
        else if (cpu.family == 0x19) cpu.technology = "7nm/5nm";
    }

    // Create instructions summary from flags
    std::vector<std::string> important_instructions;
    for (const auto& flag : cpu.flags) {
        if (flag == "ht") important_instructions.push_back("HT");
        else if (flag == "mmx") important_instructions.push_back("MMX");
        else if (flag == "sse") important_instructions.push_back("SSE(1)");
        else if (flag == "sse2") important_instructions.push_back("SSE(2)");
        else if (flag == "sse3" || flag == "pni") important_instructions.push_back("SSE(3)");
        else if (flag == "ssse3") important_instructions.push_back("SSE(3S)");
        else if (flag == "sse4_1") important_instructions.push_back("SSE(4.1)");
        else if (flag == "sse4_2") important_instructions.push_back("SSE(4.2)");
        else if (flag == "avx") important_instructions.push_back("AVX(1)");
        else if (flag == "avx2") important_instructions.push_back("AVX(2)");
        else if (flag == "avx512f") important_instructions.push_back("AVX-512");
        else if (flag == "aes") important_instructions.push_back("AES");
        else if (flag == "pclmulqdq") important_instructions.push_back("CLMUL");
        else if (flag == "vmx") important_instructions.push_back("VT-x");
        else if (flag == "svm") important_instructions.push_back("AMD-V");
        else if (flag == "lm") important_instructions.push_back("x86-64");
        else if (flag == "sha_ni") important_instructions.push_back("SHA");
    }

    // Join instructions with commas
    cpu.instructions_summary = "";
    for (size_t i = 0; i < important_instructions.size(); i++) {
        cpu.instructions_summary += important_instructions[i];
        if (i < important_instructions.size() - 1) {
            cpu.instructions_summary += ", ";
        }
    }

    // Voltage - typically requires root access to read, leave blank
    cpu.voltage = "";
    
    // Get core counts
    cpu.physical_cores = std::stoi(lscpu.count("Core(s) per socket") ? lscpu["Core(s) per socket"] : "0");
    cpu.logical_cores = std::stoi(lscpu.count("CPU(s)") ? lscpu["CPU(s)"] : "0");
    cpu.architecture = lscpu.count("Architecture") ? lscpu["Architecture"] : "unknown";
    
    // Get frequencies
    std::string freq_str = read_file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
    if (!freq_str.empty()) {
        try {
            cpu.current_freq_mhz = std::stod(freq_str) / 1000.0;
        } catch (...) {}
    }
    
    freq_str = read_file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq");
    if (!freq_str.empty()) {
        try {
            cpu.max_freq_mhz = std::stod(freq_str) / 1000.0;
        } catch (...) {}
    }
    
    freq_str = read_file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq");
    if (!freq_str.empty()) {
        try {
            cpu.min_freq_mhz = std::stod(freq_str) / 1000.0;
        } catch (...) {}
    }
    
    // Get cache info from lscpu
    cpu.cache_l1d = lscpu.count("L1d cache") ? lscpu["L1d cache"] : "";
    cpu.cache_l1i = lscpu.count("L1i cache") ? lscpu["L1i cache"] : "";
    cpu.cache_l2 = lscpu.count("L2 cache") ? lscpu["L2 cache"] : "";
    cpu.cache_l3 = lscpu.count("L3 cache") ? lscpu["L3 cache"] : "";
    
    // Get temperature
    cpu.temperature = get_cpu_temperature();
    
    return cpu;
}

MemoryInfo SystemInfo::get_memory_info() {
    MemoryInfo mem = {};
    
    std::ifstream meminfo("/proc/meminfo");
    std::string line;
    
    while (std::getline(meminfo, line)) {
        std::istringstream iss(line);
        std::string key;
        uint64_t value;
        iss >> key >> value;
        
        if (key == "MemTotal:") mem.total_ram = value * 1024;
        else if (key == "MemAvailable:") mem.available_ram = value * 1024;
        else if (key == "Cached:") mem.cached_ram = value * 1024;
        else if (key == "Buffers:") mem.buffers_ram = value * 1024;
        else if (key == "SwapTotal:") mem.total_swap = value * 1024;
        else if (key == "SwapFree:") mem.free_swap = value * 1024;
    }
    
    mem.used_ram = mem.total_ram - mem.available_ram;
    mem.used_swap = mem.total_swap - mem.free_swap;
    
    return mem;
}

OSInfo SystemInfo::get_os_info() {
    OSInfo os;
    
    // Get distro info
    std::string os_release = read_file("/etc/os-release");
    std::istringstream iss(os_release);
    std::string line;
    
    while (std::getline(iss, line)) {
        if (line.find("PRETTY_NAME=") == 0) {
            os.distro_name = line.substr(13);
            // Remove quotes
            if (os.distro_name.front() == '"') os.distro_name = os.distro_name.substr(1);
            if (os.distro_name.back() == '"') os.distro_name.pop_back();
        } else if (line.find("VERSION_ID=") == 0) {
            os.distro_version = line.substr(12);
            if (os.distro_version.front() == '"') os.distro_version = os.distro_version.substr(1);
            if (os.distro_version.back() == '"') os.distro_version.pop_back();
        }
    }
    
    // Get kernel version
    struct utsname uts;
    if (uname(&uts) == 0) {
        os.kernel_version = uts.release;
        os.hostname = uts.nodename;
        os.architecture = uts.machine;
    }
    
    // Get desktop environment
    const char* desktop = getenv("XDG_CURRENT_DESKTOP");
    if (desktop) {
        os.desktop_environment = desktop;
    } else {
        desktop = getenv("DESKTOP_SESSION");
        if (desktop) os.desktop_environment = desktop;
    }
    
    // Get uptime
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        os.uptime = format_uptime(si.uptime);
    }
    
    return os;
}

MotherboardInfo SystemInfo::get_motherboard_info() {
    MotherboardInfo mb;
    
    mb.manufacturer = read_file("/sys/devices/virtual/dmi/id/board_vendor");
    mb.product_name = read_file("/sys/devices/virtual/dmi/id/board_name");
    mb.version = read_file("/sys/devices/virtual/dmi/id/board_version");
    mb.serial = read_file("/sys/devices/virtual/dmi/id/board_serial");
    mb.bios_vendor = read_file("/sys/devices/virtual/dmi/id/bios_vendor");
    mb.bios_version = read_file("/sys/devices/virtual/dmi/id/bios_version");
    mb.bios_date = read_file("/sys/devices/virtual/dmi/id/bios_date");
    
    // Trim newlines
    auto trim = [](std::string& s) {
        s.erase(s.find_last_not_of(" \n\r\t") + 1);
    };
    
    trim(mb.manufacturer);
    trim(mb.product_name);
    trim(mb.version);
    trim(mb.serial);
    trim(mb.bios_vendor);
    trim(mb.bios_version);
    trim(mb.bios_date);
    
    return mb;
}

std::vector<GPUInfo> SystemInfo::get_gpu_info() {
    std::vector<GPUInfo> gpus;
    
    // Use lspci to find GPUs
    std::string lspci_output = exec_command("lspci | grep -i 'vga\\|3d\\|display'");
    std::istringstream iss(lspci_output);
    std::string line;
    
    while (std::getline(iss, line)) {
        GPUInfo gpu;
        
        // Extract GPU model from lspci line
        size_t colon = line.find(':');
        if (colon != std::string::npos && colon + 2 < line.length()) {
            gpu.model = line.substr(colon + 2);
            
            // Determine vendor
            if (line.find("NVIDIA") != std::string::npos || line.find("nVidia") != std::string::npos) {
                gpu.vendor = "NVIDIA";
            } else if (line.find("AMD") != std::string::npos || line.find("ATI") != std::string::npos) {
                gpu.vendor = "AMD";
            } else if (line.find("Intel") != std::string::npos) {
                gpu.vendor = "Intel";
            }
        }
        
        // Try to get driver info
        std::string glxinfo = exec_command("glxinfo 2>/dev/null | grep -i 'OpenGL version\\|OpenGL renderer'");
        std::istringstream glx_iss(glxinfo);
        std::string glx_line;
        
        while (std::getline(glx_iss, glx_line)) {
            if (glx_line.find("OpenGL version") != std::string::npos) {
                size_t pos = glx_line.find(':');
                if (pos != std::string::npos) {
                    gpu.opengl_version = glx_line.substr(pos + 2);
                }
            } else if (glx_line.find("OpenGL renderer") != std::string::npos) {
                size_t pos = glx_line.find(':');
                if (pos != std::string::npos) {
                    std::string renderer = glx_line.substr(pos + 2);
                    if (renderer.find("Mesa") != std::string::npos) {
                        gpu.driver = "Mesa";
                        // Extract Mesa version
                        size_t mesa_pos = renderer.find("Mesa ");
                        if (mesa_pos != std::string::npos) {
                            gpu.driver_version = renderer.substr(mesa_pos + 5);
                        }
                    }
                }
            }
        }
        
        // Try vulkaninfo for Vulkan version
        std::string vulkan_output = exec_command("vulkaninfo --summary 2>/dev/null | grep 'apiVersion'");
        if (!vulkan_output.empty()) {
            size_t pos = vulkan_output.find('=');
            if (pos != std::string::npos) {
                gpu.vulkan_version = vulkan_output.substr(pos + 2);
            }
        }
        
        gpus.push_back(gpu);
    }
    
    return gpus;
}

std::vector<DiskInfo> SystemInfo::get_disk_info() {
    std::vector<DiskInfo> disks;
    
    DIR* dir = opendir("/sys/block");
    if (!dir) return disks;
    
    struct dirent* entry;
    while ((entry = readdir(dir))) {
        std::string device_name = entry->d_name;
        
        // Skip loop devices, ram disks, etc
        if (device_name.find("loop") == 0 || device_name.find("ram") == 0 || 
            device_name[0] == '.') {
            continue;
        }
        
        DiskInfo disk;
        disk.device = "/dev/" + device_name;
        
        // Get size
        std::string size_path = "/sys/block/" + device_name + "/size";
        std::string size_str = read_file(size_path);
        if (!size_str.empty()) {
            try {
                disk.size_bytes = std::stoull(size_str) * 512;  // Sectors to bytes
            } catch (...) {}
        }
        
        // Try to determine if SSD or HDD
        std::string rotational_path = "/sys/block/" + device_name + "/queue/rotational";
        std::string rotational = read_file(rotational_path);
        disk.type = (rotational == "0\n") ? "SSD" : "HDD";
        
        // Get model
        std::string model_path = "/sys/block/" + device_name + "/device/model";
        disk.model = read_file(model_path);
        if (!disk.model.empty()) {
            disk.model.erase(disk.model.find_last_not_of(" \n\r\t") + 1);
        }
        
        // Try to get temperature
        std::string smartctl_output = exec_command("smartctl -A " + disk.device + " 2>/dev/null | grep Temperature");
        if (!smartctl_output.empty()) {
            std::istringstream iss(smartctl_output);
            std::string word;
            while (iss >> word) {
                try {
                    double temp = std::stod(word);
                    if (temp > 0 && temp < 100) {
                        disk.temperature = temp;
                        break;
                    }
                } catch (...) {}
            }
        }
        
        disks.push_back(disk);
    }
    
    closedir(dir);
    return disks;
}