#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <map>

struct CPUInfo {
    std::string vendor;
    std::string model_name;
    std::string code_name;
    std::string package;
    std::string technology;
    std::string specification;
    std::string voltage;
    std::string architecture;
    int physical_cores;
    int logical_cores;
    double current_freq_mhz;
    double max_freq_mhz;
    double min_freq_mhz;
    std::string cache_l1d;
    std::string cache_l1i;
    std::string cache_l2;
    std::string cache_l3;
    std::vector<std::string> flags;
    std::string instructions_summary;  // Human-readable instruction summary
    double temperature;
    int family;
    int disp_family;
    int model;
    int disp_model;
    int stepping;
    std::string microcode;
};

struct MemoryInfo {
    uint64_t total_ram;
    uint64_t available_ram;
    uint64_t used_ram;
    uint64_t cached_ram;
    uint64_t buffers_ram;
    uint64_t total_swap;
    uint64_t used_swap;
    uint64_t free_swap;
};

struct OSInfo {
    std::string distro_name;
    std::string distro_version;
    std::string kernel_version;
    std::string hostname;
    std::string desktop_environment;
    std::string uptime;
    std::string architecture;
};

struct MotherboardInfo {
    std::string manufacturer;
    std::string product_name;
    std::string version;
    std::string serial;
    std::string bios_vendor;
    std::string bios_version;
    std::string bios_date;
};

struct GPUInfo {
    std::string vendor;
    std::string model;
    std::string driver;
    std::string driver_version;
    std::string opengl_version;
    std::string vulkan_version;
    double temperature;
    int memory_total_mb;
    int memory_used_mb;
};

struct DiskInfo {
    std::string device;
    std::string model;
    uint64_t size_bytes;
    std::string type;  // SSD/HDD
    double temperature;
};

class SystemInfo {
public:
    static CPUInfo get_cpu_info();
    static MemoryInfo get_memory_info();
    static OSInfo get_os_info();
    static MotherboardInfo get_motherboard_info();
    static std::vector<GPUInfo> get_gpu_info();
    static std::vector<DiskInfo> get_disk_info();
    static std::string format_bytes(std::uint64_t bytes);
    static std::string format_uptime(double seconds);

private:
    static std::string read_file(const std::string& path);
    static std::string exec_command(const std::string& cmd);
    static std::vector<std::string> split_string(const std::string& str, char delimiter);
    static double get_cpu_temperature();
    static std::map<std::string, std::string> parse_lscpu();
};