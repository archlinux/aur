#include <signal.h>

int SYS_SIGRTMIN() {
    return SIGRTMIN;
}
