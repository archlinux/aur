#![allow(clippy::all)]
include!(concat!(env!("OUT_DIR"), "/dbus_machine1.rs"));
