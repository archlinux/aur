var FullscreenClosePlugin = function () {
	return {
		init : function () {
			var container = document.getElementById('full-screen-close-container');

			if(gBrowser) gBrowser.addEventListener("DOMContentLoaded", FullscreenClosePlugin.onLoad);
			document.getElementById('main-window').addEventListener("mousemove", FullscreenClosePlugin.showButton, false);
			FullscreenClosePlugin.timeout = null;
			container.setAttribute("close-out", "true");
		},

		onLoad : function () {
			var container = document.getElementById('full-screen-close-container');
			var player = content.document.getElementById('SLPlayer');

			/* hide the close button if the Silverlight player exists */
			if(player) container.hidden = true;
		},

		showButton : function () {
			var container = document.getElementById('full-screen-close-container');
			var player = content.document.getElementById('SLPlayer');

			if(player) return; /* do not show the button if the Silverlight player exists */
			container.hidden = false;
			container.removeAttribute("fade-close-out");
			container.setAttribute("fade-close-in", "true");
			clearTimeout(FullscreenClosePlugin.timeout);
			FullscreenClosePlugin.timeout = setTimeout(FullscreenClosePlugin.buttonVisible, 500);
		},

		buttonVisible : function () {
			var container = document.getElementById('full-screen-close-container');

			container.removeAttribute("close-out");
			container.removeAttribute("fade-close-in");
			clearTimeout(FullscreenClosePlugin.timeout);
			FullscreenClosePlugin.timeout = setTimeout(FullscreenClosePlugin.hideButton, 1000);
		},

		hideButton : function () {
			var container = document.getElementById('full-screen-close-container');

			container.removeAttribute("fade-close-in");
			container.setAttribute("fade-close-out", "true");
			FullscreenClosePlugin.timeout = setTimeout(FullscreenClosePlugin.buttonHidden, 500);
		},

		buttonHidden : function () {
			var container = document.getElementById('full-screen-close-container');

			container.hidden = true;
			container.setAttribute("close-out", "true");
		}
	};
}();
window.addEventListener("load", FullscreenClosePlugin.init, false);
