"""This is the list of plugin ciphergui's."""


cipherGUIList = []
cipherGUIList.append(("Identity", "Identity", "_Identity", "An identity cipher"))
