"""This file contains the Identity class."""


class Identity:

    """This is an identity cipher."""

    def encrypt(self, s):
        """Just return s."""
        return s

    def decrypt(self, s):
        """Just return s."""
        return s


# Do some testing.
if __name__ == '__main__':
    cipher = Identity()
    assert cipher.encrypt("aAbB zZ") == "aAbB zZ"
    assert cipher.decrypt("aAbB zZ") == "aAbB zZ"
