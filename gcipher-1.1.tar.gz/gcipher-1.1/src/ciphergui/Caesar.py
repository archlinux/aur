import cipher.Caesar
class Caesar(cipher.Caesar.Caesar): pass
