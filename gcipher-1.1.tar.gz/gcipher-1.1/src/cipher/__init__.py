from __main__ import getPluginsPath
__path__.append(getPluginsPath("cipher"))
