from Rot import Rot
class Caesar(Rot):
    def __init__(self): 
        self.key = 3
