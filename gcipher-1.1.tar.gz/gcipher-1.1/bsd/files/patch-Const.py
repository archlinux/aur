diff -ur ../gcipher-1.0.orig/src/Const.py ./src/Const.py
--- ../gcipher-1.0.orig/src/Const.py	Wed Jun 25 14:03:43 2003
+++ ./src/Const.py	Wed Jun 25 14:05:59 2003
@@ -9,4 +9,4 @@
 Read Help/Contents to learn how to use gcipher
 as a command line filter or as a network proxy."""
 AUTHORS = ["Shannon -jj Behrens <jjinux@yahoo.com>"]
-GLADEDIR = "."
+GLADEDIR = "/usr/X11R6/share/gnome/gcipher/lib"
