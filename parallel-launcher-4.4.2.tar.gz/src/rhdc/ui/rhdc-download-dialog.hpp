#ifndef SRC_RHDC_UI_RHDC_DOWNLOAD_DIALOG_HPP_
#define SRC_RHDC_UI_RHDC_DOWNLOAD_DIALOG_HPP_

#include <memory>
#include <QDialog>
#include "src/rhdc/web/api.hpp"

namespace Ui {
	class RhdcDownloadDialog;
}

class RhdcDownloadDialog : private QDialog {
	Q_OBJECT

	private:
	Ui::RhdcDownloadDialog *m_ui;

	RhdcDownloadDialog();
	~RhdcDownloadDialog();

	static void downloadHack(
		const std::shared_ptr<bool> &dialogExists,
		RhdcDownloadDialog *dialog,
		HashMap<string,FollowedHack>::const_iterator current,
		size_t romsDownloaded,
		size_t totalRoms
	);

	public:
	static void run( const HashMap<string,FollowedHack> &hacks );

};



#endif /* SRC_RHDC_UI_RHDC_DOWNLOAD_DIALOG_HPP_ */
