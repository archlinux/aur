#include "src/core/migration.hpp"

#include "src/core/file-controller.hpp"
#include "src/db/transaction.hpp"
#include "src/db/sqlite.hpp"

// Migration 01: added rom-specific options for ParaLLEl and GLideN64
inline static void migration_01() {
	SqlCommand checkCmd( R"#(
SELECT 1
FROM pragma_table_info('ROMS')
WHERE name = 'upscale_texrects'
)#"
	);

	if( checkCmd.execQuery().moveNext() ) {
		return;
	}

	SqlTransaction transaction;

	SqlBatch( R"#(
DROP VIEW TAGGED_ROMS;
DROP INDEX ix_rom_by_crc;

CREATE TABLE ROMS_v2(
	sha1 TEXT NOT NULL PRIMARY KEY,
	name TEXT NOT NULL,
	internal_name TEXT NOT NULL,
	emulator INTEGER NOT NULL,
	parallel_plugin INTEGER NOT NULL,
	mupen_plugin INTEGER NOT NULL,
	upscale_texrects INTEGER NOT NULL,
	emulate_framebuffer INTEGER NOT NULL,
	n64_depth_compare INTEGER NOT NULL,
	overclock_cpu INTEGER NOT NULL,
	overclock_vi INTEGER NOT NULL,
	widescreen INTEGER NOT NULL,
	input_mode_id BLOB NOT NULL,
	last_played INTEGER NOT NULL,
	play_time INTEGER NOT NULL,
	crc32 INTEGER NOT NULL
);
)#"
	).execNonQuery();

	SqlCommand migration( R"#(
INSERT INTO ROMS_v2(
	sha1,
	name,
	internal_name,
	emulator,
	parallel_plugin,
	mupen_plugin,
	upscale_texrects,
	emulate_framebuffer,
	n64_depth_compare,
	overclock_cpu,
	overclock_vi,
	widescreen,
	input_mode_id,
	last_played,
	play_time,
	crc32
)
SELECT
	sha1,
	name,
	internal_name,
	emulator,
	parallel_plugin,
	mupen_plugin,
	?1 AS upscale_texrects,
	?2 AS emulate_framebuffer,
	?3 AS n64_depth_compare,
	overclock_cpu,
	overclock_vi,
	widescreen,
	input_mode_id,
	last_played,
	play_time,
	crc32
FROM ROMS
)#"
	);

	const AppSettings &settings = FileController::loadAppSettings();
	migration.addParameter( settings.parallelTexRectUpscaling );
	migration.addParameter( settings.glidenFramebufferEmulation );
	migration.addParameter( settings.glidenCorrectDepthCompare );
	migration.execNonQuery();

	SqlCommand( "DROP TABLE ROMS" ).execNonQuery();

	SqlCommand( R"#(
ALTER TABLE ROMS_v2 RENAME TO ROMS;
CREATE INDEX ix_rom_by_crc ON ROMS( crc32 );
)#"
	).execNonQuery();

	SqlCommand( R"#(
CREATE VIEW TAGGED_ROMS AS
SELECT ROMS.*, group_concat( group_name, x'0A' ) AS groups
FROM ROMS LEFT JOIN ROM_GROUPS USING( sha1 )
GROUP BY sha1
)#"
	).execNonQuery();

	transaction.commit();
}

void Migration::updateDatabaseSchema() {
	migration_01();
}
