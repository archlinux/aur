#include "src/ui/download-dialog.hpp"

#if QT_VERSION >= QT_VERSION_CHECK( 5, 15, 0 )
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::errorOccurred )
#else
	#define ON_NETWORK_ERROR QOverload<QNetworkReply::NetworkError>::of( &QNetworkReply::error )
#endif

DownloadDialog::DownloadDialog(
	const QString label,
	const QUrl &url,
	const QString &filePath
) : QProgressDialog() {
	m_networkManager = new QNetworkAccessManager();
	m_stream = m_networkManager->get( QNetworkRequest( url ) );

	m_file = new QFile( filePath );
	m_file->open( QIODevice::WriteOnly | QIODevice::Truncate );

	setLabelText( label );
	setRange( 0, 1 );
	setValue( 0 );

	connect( m_stream, &QNetworkReply::readyRead, this, &DownloadDialog::dataReceived );
	connect( m_stream, &QNetworkReply::downloadProgress, this, &DownloadDialog::onDownloadProgress );
	connect( m_stream, ON_NETWORK_ERROR, this, &DownloadDialog::onDownloadFailed );
	connect( m_stream, &QNetworkReply::finished, this, &DownloadDialog::onDownloadFinished );
}

DownloadDialog::~DownloadDialog() {
	m_stream->deleteLater();
	m_networkManager->deleteLater();
	m_file->close();
	m_file->deleteLater();
	m_file = nullptr;
}

void DownloadDialog::onDownloadProgress( qint64 downloaded, qint64 total ) {
	setMaximum( (int)total );
	setValue( (int)downloaded );
}

void DownloadDialog::onDownloadFailed( [[maybe_unused]] QNetworkReply::NetworkError error ) {
	reject();
}

void DownloadDialog::dataReceived() {
	if( m_file != nullptr ) {
		m_file->write( m_stream->readAll() );
	}
}

void DownloadDialog::onDownloadFinished() {
	if( m_stream->error() == QNetworkReply::NoError ) {
		accept();
	} else {
		reject();
	}
}

bool DownloadDialog::download(
	const string &label,
	const string &url,
	const fs::path &filePath
) {
	fs::create_directories( filePath.parent_path() );
	DownloadDialog dialog( tr( label.c_str() ), QUrl( url.c_str() ), filePath.u8string().c_str() );
	return dialog.exec() == QDialog::Accepted;
}
