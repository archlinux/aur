/* fortunes_gtk-window.c
 *
 * Copyright 2023 root https://codeberg.org/realroot
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fortunes_gtk-config.h"
#include "fortunes_gtk-window.h"

struct _FortunesGtkWindow
{
  GtkApplicationWindow  parent_instance;

  /* Template widgets */
  GtkHeaderBar *header_bar;
  GtkTextView *main_text_view;
  GtkButton *another_button;
  GtkButton *save_button;
};

G_DEFINE_TYPE (FortunesGtkWindow, fortunes_gtk_window, GTK_TYPE_APPLICATION_WINDOW)

static void
fortunes_gtk_window__another_fortune  (GSimpleAction *simple, GVariant *parameter, gpointer user_data)
{
  FortunesGtkWindow *self = FORTUNES_GTK_WINDOW (user_data);

  FILE* pfid = popen("fortune -a", "r");
  fflush(pfid);
  char* message = (char*)calloc(4096, 1);
  fread(message, 4096, 1, pfid);
  // Retrieve the GtkTextBuffer instance that stores the
  // text displayed by the GtkTextView widget
  GtkTextBuffer *buffer = gtk_text_view_get_buffer (self->main_text_view);

  // Set the text using the contents of the file
  gtk_text_buffer_set_text (buffer, message, -1);
}

static void
save_file_complete (GObject      *source_object,
                    GAsyncResult *result,
                    gpointer      user_data)
{
  GFile *file = G_FILE (source_object);

  g_autoptr (GError) error =  NULL;
  g_file_replace_contents_finish (file, result, NULL, &error);

  // Query the display name for the file
  g_autofree char *display_name = NULL;
  g_autoptr (GFileInfo) info =
  g_file_query_info (file,
                     "standard::display-name",
                     G_FILE_QUERY_INFO_NONE,
                     NULL,
                     NULL);
  if (info != NULL)
    {
      display_name =
        g_strdup (g_file_info_get_attribute_string (info, "standard::display-name"));
    }
  else
    {
      display_name = g_file_get_basename (file);
    }

  if (error != NULL)
    {
      g_printerr ("Unable to save “%s”: %s\n",
                  display_name,
                  error->message);
    }
}

static void
save_file (FortunesGtkWindow *self,
          GFile            *file)
{
   GtkTextBuffer *buffer = gtk_text_view_get_buffer (self->main_text_view);

   // Retrieve the iterator at the start of the buffer
   GtkTextIter start;
   gtk_text_buffer_get_start_iter (buffer, &start);

   // Retrieve the iterator at the end of the buffer
   GtkTextIter end;
   gtk_text_buffer_get_end_iter (buffer, &end);

   // Retrieve all the visible text between the two bounds
   char *text = gtk_text_buffer_get_text (buffer, &start, &end, FALSE);

   // If there is nothing to save, return early
   if (text == NULL)
     return;

   g_autoptr(GBytes) bytes = g_bytes_new_take (text, strlen (text));

   // Start the asynchronous operation to save the data into the file
   g_file_replace_contents_bytes_async (file,
                                        bytes,
                                        NULL,
                                        FALSE,
                                        G_FILE_CREATE_NONE,
                                        NULL,
                                        save_file_complete,
                                        self);
}

static void
on_save_response (GtkNative        *native,
                  int               response,
                  FortunesGtkWindow *self)
{
  if (response == GTK_RESPONSE_ACCEPT)
    {
      g_autoptr (GFile) file =
        gtk_file_chooser_get_file (GTK_FILE_CHOOSER (native));

      save_file (self, file);
    }

  g_object_unref (native);
}

static void
fortunes_gtk_window__save_file_dialog (GAction          *action G_GNUC_UNUSED,
                                      GVariant         *param G_GNUC_UNUSED,
                                      FortunesGtkWindow *self)
{
  GtkFileChooserNative *native =
    gtk_file_chooser_native_new ("Save File As",
                                 GTK_WINDOW (self),
                                 GTK_FILE_CHOOSER_ACTION_SAVE,
                                 "_Save",
                                 "_Cancel");

  g_signal_connect (native, "response", G_CALLBACK (on_save_response), self);
  gtk_native_dialog_show (GTK_NATIVE_DIALOG (native));
}

static void
fortunes_gtk_window_class_init (FortunesGtkWindowClass *klass)
{
  GtkWidgetClass *widget_class = GTK_WIDGET_CLASS (klass);

  gtk_widget_class_set_template_from_resource (widget_class, "/com/root/FortunesGtk/fortunes_gtk-window.ui");
  gtk_widget_class_bind_template_child (widget_class, FortunesGtkWindow, header_bar);
  gtk_widget_class_bind_template_child (widget_class, FortunesGtkWindow, main_text_view);
  gtk_widget_class_bind_template_child (widget_class, FortunesGtkWindow, another_button);
  gtk_widget_class_bind_template_child (widget_class, FortunesGtkWindow, save_button);
}

static void
fortunes_gtk_window_init (FortunesGtkWindow *self)
{
  gtk_widget_init_template (GTK_WIDGET (self));

  g_autoptr (GSimpleAction) another_action = g_simple_action_new ("another", NULL);
  g_signal_connect (another_action, "activate", G_CALLBACK (fortunes_gtk_window__another_fortune), self);
  g_action_map_add_action (G_ACTION_MAP (self), G_ACTION (another_action));

  g_autoptr (GSimpleAction) save_action = g_simple_action_new ("save-as", NULL);
  g_signal_connect (save_action, "activate", G_CALLBACK (fortunes_gtk_window__save_file_dialog), self);
  g_action_map_add_action (G_ACTION_MAP (self), G_ACTION (save_action));

  FILE* pfid = popen("fortune -a", "r");
  fflush(pfid);
  char* message = (char*)calloc(4096, 1);
  fread(message, 4096, 1, pfid);
  GtkTextBuffer *buffer = gtk_text_view_get_buffer (self->main_text_view);
  gtk_text_buffer_set_text (buffer, message, -1);
}
