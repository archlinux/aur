# fortunes-gtk

The Fortune Cookie program's graphical user interface, made with gtk.

It was made with `gnome-builder` initially.<br>
To compile it run:
```
meson build/
ninja -C build/

```
The executable will be in `build/src/`.
To install it:
```
meson install
```
It needs the `fortune-mod` package.

Keyboard shortcuts:
```
Ctrl + ? Show Shortcuts
Ctrl + Q Quit
Space    Next
Ctrl + S Save
```
