# owlry-plugins

Official plugins and script runtimes for [owlry](https://somegit.dev/Owlibou/owlry).

## Plugins

| Plugin | Description |
|--------|-------------|
| calculator | Mathematical expression evaluation |
| bookmarks | Browser bookmark search (Firefox, Chrome) |
| clipboard | Clipboard history via cliphist |
| emoji | Emoji picker |
| filesearch | File search via fd/locate |
| media | MPRIS media player widget |
| pomodoro | Pomodoro timer widget |
| scripts | User script launcher |
| ssh | SSH host quick-connect |
| system | Power and session management |
| systemd | systemd user service control |
| weather | Weather widget |
| websearch | Web search with configurable engines |

## Runtimes

| Runtime | Description |
|---------|-------------|
| owlry-lua | Lua 5.4 scripting runtime for user plugins |
| owlry-rune | Rune scripting runtime for user plugins |

## Building

```bash
just build          # Debug build
just release        # Release build (optimized)
just plugin calc    # Build a single plugin
just check          # cargo check + clippy
just test           # Run tests
```

## Installation

```bash
just install-local  # Install all plugins and runtimes to /usr/lib/owlry/
```

Plugins are compiled as `.so` files and installed to `/usr/lib/owlry/plugins/`.
Runtimes are installed to `/usr/lib/owlry/runtimes/`.

## Development

See [docs/PLUGIN_DEVELOPMENT.md](docs/PLUGIN_DEVELOPMENT.md) for plugin authoring guide.

Plugins depend on `owlry-plugin-api` from the core repo for the ABI-stable interface.

## License

GPL-3.0-or-later
