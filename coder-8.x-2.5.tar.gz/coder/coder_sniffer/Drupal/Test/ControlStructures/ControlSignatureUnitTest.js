do i++;
while (TRUE);

do i++; while (i < 5);

do i++;while(i<5);
