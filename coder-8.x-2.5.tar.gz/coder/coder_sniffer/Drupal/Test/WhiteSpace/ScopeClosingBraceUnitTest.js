if ( jQuery('.mortgage-calculator').size() == 0 ) {
    return; }
