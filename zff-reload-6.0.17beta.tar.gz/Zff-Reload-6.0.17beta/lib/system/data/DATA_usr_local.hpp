/*
Normal installation to /usr/share/zff_reload/
To enable this, replace this file to DATA.hpp
*/

#ifndef DATA_H
#define DATA_H

#define DATAPATH "/usr/local/share/zff_reload/"

#endif