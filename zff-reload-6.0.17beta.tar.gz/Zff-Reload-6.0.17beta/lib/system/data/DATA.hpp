/*
Normal installation to here.
*/

#ifndef DATA_H
#define DATA_H

#define DATAPATH "./"

#endif