# ez
"ez" ( easy ) Is a script for Arch-Linux based system, that uses pacman/yaourt/pbget/makepkg to:
1. Install packages
2. Create folders if needed
3. Auto download other dependencies for different tasks ( i.e pbget and yaourt )
4. Compile in /home/$USER/abs and automate script that adds a line in /usr/bin/makepkg ( removes if afterwords ) so that pacman -U package.pkg.tar runs automatically.

The script is not finished.

My first git experience :D

Bye.

