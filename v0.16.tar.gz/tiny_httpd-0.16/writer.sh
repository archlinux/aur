#!/bin/sh
exec dune exec --display=quiet -- examples/writer.exe $@
