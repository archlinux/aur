module A = Tiny_httpd_atomic_

let spf = Printf.sprintf
