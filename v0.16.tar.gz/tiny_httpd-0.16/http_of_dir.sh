#!/bin/sh
exec dune exec ./src/bin/http_of_dir.exe -- $@
